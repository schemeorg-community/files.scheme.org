/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:53
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: csc.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -output-file csc.c
   used units: library eval data_structures ports srfi_1 srfi_13 utils files extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[423];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1034)
static void C_ccall f_1034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1046)
static void C_ccall f_1046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5830)
static void C_ccall f5830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5483)
static void C_ccall f5483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4614)
static void C_ccall f_4614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5826)
static void C_ccall f5826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5478)
static void C_ccall f5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5473)
static void C_ccall f5473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1138)
static void C_ccall f_1138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5468)
static void C_ccall f5468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5463)
static void C_ccall f5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5458)
static void C_ccall f5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5453)
static void C_ccall f5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5448)
static void C_ccall f5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5443)
static void C_ccall f5443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_fcall f_1181(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5822)
static void C_ccall f5822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5438)
static void C_ccall f5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1240)
static void C_fcall f_1240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_ccall f_1247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1255)
static void C_fcall f_1255(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4429)
static void C_ccall f_4429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_fcall f_1457(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_fcall f_2066(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_fcall f_2273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_fcall f_2509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2512)
static void C_fcall f_2512(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_fcall f_2568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_fcall f_2577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_fcall f_2851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_fcall f_2655(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_fcall f_2688(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static C_word C_fcall f_2519(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2429)
static void C_ccall f_2429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2103)
static void C_ccall f_2103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_fcall f_1868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5429)
static void C_ccall f5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_fcall f_1611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_fcall f_1614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_fcall f_3040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5423)
static void C_ccall f5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5418)
static void C_ccall f5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_fcall f_3091(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_fcall f_3101(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_fcall f_3017(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1478)
static void C_ccall f_1478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_fcall f_1481(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_fcall f_3337(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_fcall f_3345(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5401)
static void C_ccall f5401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5396)
static void C_ccall f5396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_fcall f_3310(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_fcall f_3186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3254)
static void C_fcall f_3254(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3262)
static void C_fcall f_3262(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5389)
static void C_ccall f5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5384)
static void C_ccall f5384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_fcall f_3227(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_fcall f_3204(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5375)
static void C_ccall f5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5370)
static void C_ccall f5370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_fcall f_3734(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5363)
static void C_ccall f5363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5358)
static void C_ccall f5358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3711)
static void C_ccall f_3711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5353)
static void C_ccall f5353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5348)
static void C_ccall f5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5343)
static void C_ccall f5343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3650)
static void C_ccall f_3650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5338)
static void C_ccall f5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_ccall f_3594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3547)
static void C_fcall f_3547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5333)
static void C_ccall f5333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3570)
static void C_ccall f_3570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3566)
static void C_ccall f_3566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5328)
static void C_ccall f5328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5323)
static void C_ccall f5323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_fcall f_3511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_fcall f_3479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_fcall f_3487(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static C_word C_fcall f_1440(C_word *a);
C_noret_decl(f_1414)
static void C_fcall f_1414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_fcall f_1375(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1368)
static void C_fcall f_1368(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_fcall f_4248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_fcall f_4115(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4145)
static void C_fcall f_4145(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4138)
static void C_ccall f_4138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_fcall f_4019(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_fcall f_4038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_fcall f_3967(C_word t0) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_fcall f_3982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_fcall f_3870(C_word t0) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_fcall f_3885(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_fcall f_3926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_fcall f_3830(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5304)
static void C_ccall f5304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5299)
static void C_ccall f5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_fcall f_3785(C_word t0) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_fcall f_3404(C_word t0) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_fcall f_3418(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_fcall f_1072(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1181)
static void C_fcall trf_1181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1181(t0,t1);}

C_noret_decl(trf_1240)
static void C_fcall trf_1240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1240(t0,t1);}

C_noret_decl(trf_1255)
static void C_fcall trf_1255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1255(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1255(t0,t1);}

C_noret_decl(trf_1457)
static void C_fcall trf_1457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1457(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1457(t0,t1,t2);}

C_noret_decl(trf_2066)
static void C_fcall trf_2066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2066(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2066(t0,t1);}

C_noret_decl(trf_2273)
static void C_fcall trf_2273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2273(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2273(t0,t1);}

C_noret_decl(trf_2509)
static void C_fcall trf_2509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2509(t0,t1);}

C_noret_decl(trf_2512)
static void C_fcall trf_2512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2512(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2512(t0,t1);}

C_noret_decl(trf_2568)
static void C_fcall trf_2568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2568(t0,t1);}

C_noret_decl(trf_2577)
static void C_fcall trf_2577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2577(t0,t1);}

C_noret_decl(trf_2851)
static void C_fcall trf_2851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2851(t0,t1);}

C_noret_decl(trf_2655)
static void C_fcall trf_2655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2655(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2655(t0,t1);}

C_noret_decl(trf_2688)
static void C_fcall trf_2688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2688(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2688(t0,t1,t2);}

C_noret_decl(trf_1868)
static void C_fcall trf_1868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1868(t0,t1);}

C_noret_decl(trf_1611)
static void C_fcall trf_1611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1611(t0,t1);}

C_noret_decl(trf_1614)
static void C_fcall trf_1614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1614(t0,t1);}

C_noret_decl(trf_3040)
static void C_fcall trf_3040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3040(t0,t1,t2);}

C_noret_decl(trf_3091)
static void C_fcall trf_3091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3091(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3091(t0,t1);}

C_noret_decl(trf_3101)
static void C_fcall trf_3101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3101(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3101(t0,t1,t2);}

C_noret_decl(trf_3017)
static void C_fcall trf_3017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3017(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3017(t0,t1,t2);}

C_noret_decl(trf_1481)
static void C_fcall trf_1481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1481(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1481(t0,t1);}

C_noret_decl(trf_3337)
static void C_fcall trf_3337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3337(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3337(t0,t1,t2);}

C_noret_decl(trf_3345)
static void C_fcall trf_3345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3345(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3345(t0,t1,t2);}

C_noret_decl(trf_3310)
static void C_fcall trf_3310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3310(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3310(t0,t1);}

C_noret_decl(trf_3186)
static void C_fcall trf_3186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3186(t0,t1);}

C_noret_decl(trf_3254)
static void C_fcall trf_3254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3254(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3254(t0,t1,t2);}

C_noret_decl(trf_3262)
static void C_fcall trf_3262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3262(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3262(t0,t1,t2);}

C_noret_decl(trf_3227)
static void C_fcall trf_3227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3227(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3227(t0,t1,t2);}

C_noret_decl(trf_3204)
static void C_fcall trf_3204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3204(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3204(t0,t1,t2);}

C_noret_decl(trf_3734)
static void C_fcall trf_3734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3734(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3734(t0,t1,t2);}

C_noret_decl(trf_3547)
static void C_fcall trf_3547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3547(t0,t1);}

C_noret_decl(trf_3511)
static void C_fcall trf_3511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3511(t0,t1);}

C_noret_decl(trf_3479)
static void C_fcall trf_3479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3479(t0,t1);}

C_noret_decl(trf_3487)
static void C_fcall trf_3487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3487(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3487(t0,t1,t2);}

C_noret_decl(trf_1414)
static void C_fcall trf_1414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1414(t0,t1);}

C_noret_decl(trf_1375)
static void C_fcall trf_1375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1375(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1375(t0,t1,t2,t3);}

C_noret_decl(trf_1368)
static void C_fcall trf_1368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1368(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1368(t0,t1);}

C_noret_decl(trf_4248)
static void C_fcall trf_4248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4248(t0,t1);}

C_noret_decl(trf_4115)
static void C_fcall trf_4115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4115(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4115(t0,t1,t2);}

C_noret_decl(trf_4145)
static void C_fcall trf_4145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4145(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4145(t0,t1);}

C_noret_decl(trf_4019)
static void C_fcall trf_4019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4019(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4019(t0,t1);}

C_noret_decl(trf_4038)
static void C_fcall trf_4038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4038(t0,t1);}

C_noret_decl(trf_3967)
static void C_fcall trf_3967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3967(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3967(t0);}

C_noret_decl(trf_3982)
static void C_fcall trf_3982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3982(t0,t1);}

C_noret_decl(trf_3870)
static void C_fcall trf_3870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3870(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3870(t0);}

C_noret_decl(trf_3885)
static void C_fcall trf_3885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3885(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3885(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3926)
static void C_fcall trf_3926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3926(t0,t1);}

C_noret_decl(trf_3830)
static void C_fcall trf_3830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3830(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3830(t0,t1,t2);}

C_noret_decl(trf_3785)
static void C_fcall trf_3785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3785(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3785(t0);}

C_noret_decl(trf_3404)
static void C_fcall trf_3404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3404(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3404(t0);}

C_noret_decl(trf_3418)
static void C_fcall trf_3418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3418(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3418(t0,t1,t2);}

C_noret_decl(trf_1072)
static void C_fcall trf_1072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1072(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1072(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2797)){
C_save(t1);
C_rereclaim2(2797*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,423);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"mingw32");
lf[4]=C_h_intern(&lf[4],4,"msvc");
lf[6]=C_h_intern(&lf[6],6,"macosx");
lf[9]=C_h_intern(&lf[9],6,"netbsd");
lf[11]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005linux\376\003\000\000\002\376\001\000\000\006netbsd\376\003\000\000\002\376\001\000\000\007freebsd\376\003\000\000\002\376\001\000\000\007solaris\376\003\000\000\002\376\001\000\000\007openb"
"sd\376\377\016");
lf[14]=C_h_intern(&lf[14],4,"exit");
lf[15]=C_h_intern(&lf[15],7,"fprintf");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\010~a: ~\077~%");
lf[17]=C_h_intern(&lf[17],17,"\003syspeek-c-string");
lf[18]=C_h_intern(&lf[18],18,"current-error-port");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[25]=C_h_intern(&lf[25],2,"qs");
lf[26]=C_h_intern(&lf[26],18,"normalize-pathname");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\003obj");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\005-out:");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\003-Fo");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[50]=C_h_intern(&lf[50],26,"\003sysload-dynamic-extension");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[105]=C_h_intern(&lf[105],18,"string-intersperse");
lf[107]=C_h_intern(&lf[107],6,"append");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[110]=C_h_intern(&lf[110],13,"make-pathname");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[114]=C_h_intern(&lf[114],17,"get-output-string");
lf[115]=C_h_intern(&lf[115],7,"display");
lf[116]=C_h_intern(&lf[116],19,"\003syswrite-char/port");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\007copy /Y");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\002cp");
lf[119]=C_h_intern(&lf[119],18,"open-output-string");
lf[121]=C_h_intern(&lf[121],7,"reverse");
lf[122]=C_h_intern(&lf[122],6,"static");
lf[123]=C_h_intern(&lf[123],14,"static-options");
lf[124]=C_h_intern(&lf[124],21,"extension-information");
lf[125]=C_h_intern(&lf[125],15,"repository-path");
lf[127]=C_h_intern(&lf[127],13,"string-append");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[131]=C_h_intern(&lf[131],9,"\003syserror");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[136]=C_h_intern(&lf[136],17,"string-translate*");
lf[137]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[138]=C_h_intern(&lf[138],16,"\003syslist->string");
lf[139]=C_h_intern(&lf[139],5,"cons*");
lf[140]=C_h_intern(&lf[140],16,"\003sysstring->list");
lf[141]=C_h_intern(&lf[141],10,"string-any");
lf[142]=C_h_intern(&lf[142],6,"char=\077");
lf[144]=C_h_intern(&lf[144],19,"\003sysstandard-output");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[146]=C_h_intern(&lf[146],5,"write");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000;\012Error: shell command terminated with non-zero exit status ");
lf[148]=C_h_intern(&lf[148],6,"system");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[151]=C_h_intern(&lf[151],5,"print");
lf[153]=C_h_intern(&lf[153],11,"delete-file");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[155]=C_h_intern(&lf[155],25,"\003sysimplicit-exit-handler");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\004-dll");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\026-DC_PRIVATE_REPOSITORY");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\031-framework CoreFoundation");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\032</string>\012</dict>\012</plist>");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\001\262<\077xml version=\0421.0\042 encoding=\042UTF-8\042\077>\012<!DOCTYPE plist SYSTEM \042file://local"
"host/System/Library/DTDs/PropertyList.dtd\042>\012<plist version=\0420.9\042>\012<dict>\012\011<key>C"
"FBundlePackageType</key>\012\011<string>APPL</string>\012\011<key>CFBundleIconFile</key>\012\011<s"
"tring>CHICKEN.icns</string>\012        <key>CFBundleGetInfoString</key>\012\011<string>Cr"
"eated by CHICKEN</string>\012\011<key>CFBundleSignature</key>\012\011<string>\077\077\077\077</string>\012\011"
"<key>CFBundleExecutable</key>\012\011<string>");
lf[168]=C_h_intern(&lf[168],19,"\003sysprint-to-string");
lf[169]=C_h_intern(&lf[169],19,"with-output-to-file");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\013generating ");
lf[171]=C_h_intern(&lf[171],12,"file-exists\077");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\012Info.plist");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\024chicken/CHICKEN.icns");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\014CHICKEN.icns");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\022Contents/Resources");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\010Contents");
lf[178]=C_h_intern(&lf[178],13,"pathname-file");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\012libchicken");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\005dylib");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\003dll");
lf[182]=C_h_intern(&lf[182],4,"conc");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\003so.");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\005mac.r");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000 /Developer/Tools/Rez -t APPL -o ");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000+install_name_tool -change libchicken.dylib ");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\020libchicken.dylib");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\020@executable_path");
lf[191]=C_h_intern(&lf[191],16,"create-directory");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\006mkdir ");
lf[193]=C_h_intern(&lf[193],17,"directory-exists\077");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\017Contents/MacOS/");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\022Contents/Resources");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\011mkdir -p ");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\011mkdir -p ");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\003app");
lf[200]=C_h_intern(&lf[200],24,"pathname-strip-extension");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\004.old");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\004move");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\002mv");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\005.old\047");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\030\047 - renaming source to `");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: output file will overwrite source file `");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\001\232\042\042 type=\042\042win32\042\042/>\134r\134n\042\012  \042  <ms_asmv2:trustInfo xmlns:ms_asmv2=\042\042urn:sche"
"mas-microsoft-com:asm.v2\042\042>\134r\134n\042\012  \042    <ms_asmv2:security>\134r\134n\042\012  \042      <ms_as"
"mv2:requestedPrivileges>\134r\134n\042\012  \042        <ms_asmv2:requestedExecutionLevel level"
"=\042\042asInvoker\042\042 uiAccess=\042\042false\042\042/>\134r\134n\042\012  \042      </ms_asmv2:requestedPrivileges"
">\134r\134n\042\012  \042    </ms_asmv2:security>\134r\134n\042\012  \042  </ms_asmv2:trustInfo>\134r\134n\042\012  \042</ass"
"embly>\134r\134n\042\012END");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\001\0031 24 MOVEABLE PURE\012BEGIN\012  \042<\077xml version=\042\0421.0\042\042 encoding=\042\042UTF-8\042\042 standa"
"lone=\042\042yes\042\042\077>\134r\134n\042\012  \042<assembly xmlns=\042\042urn:schemas-microsoft-com:asm.v1\042\042 mani"
"festVersion=\042\0421.0\042\042>\134r\134n\042\012  \042  <assemblyIdentity version=\042\0421.0.0.0\042\042 processorAr"
"chitecture=\042\042*\042\042 name=\042\042");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\013generating ");
lf[211]=C_h_intern(&lf[211],26,"pathname-replace-extension");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\002rc");
lf[213]=C_h_intern(&lf[213],7,"windows");
lf[214]=C_h_intern(&lf[214],13,"software-type");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[216]=C_h_intern(&lf[216],4,"last");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[219]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[225]=C_h_intern(&lf[225],7,"newline");
lf[226]=C_h_intern(&lf[226],6,"print*");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\010 -Wl,-R\042");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\010\134$ORIGIN");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[236]=C_h_intern(&lf[236],5,"-help");
lf[237]=C_h_intern(&lf[237],6,"--help");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\003\047.\012");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\047\225\047 is a driver program for the CHICKEN compiler. Files given on the\012  comman"
"d line are translated, compiled or linked as needed.\012\012  FILENAME is a Scheme sou"
"rce file name with optional extension or a\012  C/C++/Objective-C source, object or"
" library file name with extension. OPTION\012  may be one of the following:\012\012  Gene"
"ral options:\012\012    -h  -help                      display this text and exit\012    "
"-v                             show intermediate compilation stages\012    -vv  -ve"
"rbose                  display information about translation\012                   "
"                 progress\012    -vvv                           display information"
" about all compilation\012                                    stages\012    -V  -versi"
"on                   display Scheme compiler version and exit\012    -release      "
"                 display release number and exit\012\012  File and pathname options:\012\012"
"    -o -output-file FILENAME       specifies target executable name\012    -I -incl"
"ude-path PATHNAME      specifies alternative path for included\012                 "
"                   files\012    -to-stdout                     write compiler to st"
"dout (implies -t)\012    -s -shared -dynamic            generate dynamically loadab"
"le shared object\012                                    file\012\012  Language options:\012\012"
"    -D  -DSYMBOL  -feature SYMBOL  register feature identifier\012    -c++         "
"                  compile via a C++ source file (.cpp) \012    -objc               "
"           compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012"
"    -i -case-insensitive           don\047t preserve case of read symbols    \012    -"
"K  -keyword-style STYLE       enable alternative keyword-syntax\012                "
"                    (prefix, suffix or none)\012        -no-parentheses-synonyms   "
"disables list delimiter synonyms\012        -no-symbol-escape          disables sup"
"port for escaped symbols\012        -r5rs-syntax               disables the Chicken"
" extensions to\012                                    R5RS syntax\012    -compile-synt"
"ax                macros are made available at run-time\012    -j -emit-import-libr"
"ary MODULE write compile-time module information into\012                          "
"          separate file\012    -J -emit-all-import-libraries  emit import-libraries"
" for all defined modules\012    -no-compiler-syntax            disable expansion of"
" compiler-macros\012\012  Translation options:\012\012    -x  -explicit-use              do "
"not use units `library\047 and `eval\047 by\012                                    defaul"
"t\012    -P  -check-syntax              stop compilation after macro-expansion\012    "
"-A  -analyze-only              stop compilation after first analysis pass\012\012  Deb"
"ugging options:\012\012    -w  -no-warnings               disable warnings\012    -disabl"
"e-warning CLASS         disable specific class of warnings\012    -d0 -d1 -d2 -debu"
"g-level NUMBER\012                                   set level of available debuggi"
"ng information\012    -no-trace                      disable rudimentary debugging "
"information\012    -profile                       executable emits profiling inform"
"ation \012    -accumulate-profile            executable emits profiling information"
" in\012                                    append mode\012    -profile-name FILENAME  "
"       name of the generated profile information\012                               "
"     file\012    -S  -scrutinize                perform local flow analysis\012    -ty"
"pes FILENAME                load additional type database\012\012  Optimization option"
"s:\012\012    -O -O1 -O2 -O3 -O4 -O5 -optimize-level NUMBER\012                          "
"         enable certain sets of optimization options\012    -optimize-leaf-routines"
"        enable leaf routine optimization\012    -N  -no-usual-integrations     stan"
"dard procedures may be redefined\012    -u  -unsafe                    disable safe"
"ty checks\012    -local                         assume globals are only modified in"
" current\012                                    file\012    -b  -block                "
"     enable block-compilation\012    -disable-interrupts            disable interru"
"pts in compiled code\012    -f  -fixnum-arithmetic         assume all numbers are f"
"ixnums\012    -lambda-lift                   perform lambda-lifting\012    -disable-st"
"ack-overflow-checks disables detection of stack-overflows\012    -inline           "
"             enable inlining\012    -inline-limit                  set inlining thr"
"eshold\012    -inline-global                 enable cross-module inlining\012    -unbo"
"xing                      use unboxed temporaries if possible\012    -n -emit-inlin"
"e-file FILENAME  generate file with globally inlinable\012                         "
"           procedures (implies -inline -local)\012    -consult-inline-file FILENAME"
"  explicitly load inline file\012    -no-argc-checks                disable argumen"
"t count checks\012    -no-bound-checks               disable bound variable checks\012"
"    -no-procedure-checks           disable procedure call checks\012    -no-procedu"
"re-checks-for-usual-bindings\012                                   disable procedur"
"e call checks only for usual\012                                    bindings\012\012  Con"
"figuration options:\012\012    -unit NAME                     compile file as a librar"
"y unit\012    -uses NAME                     declare library unit as used.\012    -hea"
"p-size NUMBER              specifies heap-size of compiled executable\012    -heap-"
"initial-size NUMBER      specifies heap-size at startup time\012    -heap-growth PE"
"RCENTAGE        specifies growth-rate of expanding heap\012    -heap-shrinkage PERC"
"ENTAGE     specifies shrink-rate of contracting heap\012    -nursery NUMBER  -stack"
"-size NUMBER\012                                   specifies nursery size of compil"
"ed\012                                   executable\012    -X -extend FILENAME        "
"    load file before compilation commences\012    -prelude EXPRESSION            ad"
"d expression to beginning of source file\012    -postlude EXPRESSION           add "
"expression to end of source file\012    -prologue FILENAME             include file"
" before main source file\012    -epilogue FILENAME             include file after m"
"ain source file\012\012    -e  -embedded                  compile as embedded\012        "
"                            (don\047t generate `main()\047)\012    -gui                  "
"         compile as GUI application\012    -R  -require-extension NAME    require e"
"xtension and import in compiled\012                                    code\012    -dl"
"l -library                  compile multiple units into a dynamic\012              "
"                      library\012    -deploy                        deploy self-con"
"tained application bundle\012\012  Options to other passes:\012\012    -C OPTION            "
"          pass option to C compiler\012    -L OPTION                      pass opti"
"on to linker\012    -I<DIR>                        pass \134\042-I<DIR>\134\042 to C compiler\012 "
"                                   (add include path)\012    -L<DIR>               "
"         pass \134\042-L<DIR>\134\042 to linker\012                                    (add lib"
"rary path)\012    -k                             keep intermediate files\012    -c    "
"                         stop after compilation to object files\012    -t          "
"                   stop after translation to C\012    -cc COMPILER                 "
"  select other C compiler than the default\012    -cxx COMPILER                  se"
"lect other C++ compiler than the default\012    -ld COMPILER                   sele"
"ct other linker than the default \012    -lLIBNAME                      link with g"
"iven library\012                                    (`libLIBNAME\047 on UNIX,\012        "
"                             `LIBNAME.lib\047 on Windows)\012    -static-libs         "
"          link with static CHICKEN libraries\012    -static                        "
"generate completely statically linked\012                                    execut"
"able\012    -static-extension NAME         link extension NAME statically\012         "
"                           (if available)\012    -F<DIR>                        pas"
"s \134\042-F<DIR>\134\042 to C compiler\012                                    (add framework h"
"eader path on Mac OS X)\012    -framework NAME                passed to linker on M"
"ac OS X\012    -rpath PATHNAME                add directory to runtime library sear"
"ch path\012    -Wl,...                        pass linker options\012    -strip       "
"                  strip resulting binary\012\012  Inquiry options:\012\012    -home         "
"                 show home-directory (where support files go)\012    -cflags       "
"                 show required C-compiler flags and exit\012    -ldflags           "
"            show required linker flags and exit\012    -libs                       "
"   show required libraries and exit\012    -cc-name                       show name"
" of default C compiler used\012    -cxx-name                      show name of defa"
"ult C++ compiler used\012    -ld-name                       show name of default li"
"nker used\012    -dry-run                       just show commands executed, don\047t "
"run them\012                                    (implies `-v\047)\012\012  Obscure options:\012"
"\012    -debug MODES                   display debugging output for the given modes"
"\012    -compiler PATHNAME             use other compiler than default `chicken\047\012  "
"  -raw                           do not generate implicit init- and exit code\012  "
"  -emit-external-prototypes-first\012                                   emit protot"
"ypes for callbacks before foreign\012                                    declaratio"
"ns\012    -ignore-repository             do not refer to repository for extensions\012"
"    -keep-shadowed-macros          do not remove shadowed macro\012    -host       "
"                   compile for host when configured for\012                        "
"            cross-compiling\012    -private-repository            load extensions f"
"rom executable path\012    -deployed                      compile support file to b"
"e used from a deployed \012                                    executable\012    -no-e"
"levation                  embed manifest on Windows to supress elevation\012       "
"                             warnings for programs named `install\047 or `setup\047\012\012 "
" Options can be collapsed if unambiguous, so\012\012    -vkfO\012\012  is the same as\012\012    -"
"v -k -fixnum-arithmetic -optimize\012\012  The contents of the environment variable CS"
"C_OPTIONS are implicitly passed to\012  every invocation of `");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\033 FILENAME | OPTION ...\012\012  `");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\007Usage: ");
lf[242]=C_h_intern(&lf[242],8,"-release");
lf[243]=C_h_intern(&lf[243],15,"chicken-version");
lf[244]=C_h_intern(&lf[244],8,"-version");
lf[245]=C_h_intern(&lf[245],7,"sprintf");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[247]=C_h_intern(&lf[247],4,"-c++");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[249]=C_h_intern(&lf[249],5,"-objc");
lf[250]=C_h_intern(&lf[250],7,"-static");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[253]=C_h_intern(&lf[253],12,"-static-libs");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[256]=C_h_intern(&lf[256],7,"-cflags");
lf[257]=C_h_intern(&lf[257],8,"-ldflags");
lf[258]=C_h_intern(&lf[258],8,"-cc-name");
lf[259]=C_h_intern(&lf[259],9,"-cxx-name");
lf[260]=C_h_intern(&lf[260],8,"-ld-name");
lf[261]=C_h_intern(&lf[261],5,"-home");
lf[262]=C_h_intern(&lf[262],5,"-libs");
lf[263]=C_h_intern(&lf[263],2,"-v");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010-VERBOSE");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[269]=C_h_intern(&lf[269],2,"-w");
lf[270]=C_h_intern(&lf[270],12,"-no-warnings");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[273]=C_h_intern(&lf[273],2,"-A");
lf[274]=C_h_intern(&lf[274],13,"-analyze-only");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[276]=C_h_intern(&lf[276],2,"-P");
lf[277]=C_h_intern(&lf[277],13,"-check-syntax");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[279]=C_h_intern(&lf[279],2,"-k");
lf[280]=C_h_intern(&lf[280],2,"-c");
lf[281]=C_h_intern(&lf[281],2,"-t");
lf[282]=C_h_intern(&lf[282],2,"-e");
lf[283]=C_h_intern(&lf[283],9,"-embedded");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[285]=C_h_intern(&lf[285],18,"-require-extension");
lf[286]=C_h_intern(&lf[286],2,"-R");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[288]=C_h_intern(&lf[288],17,"-static-extension");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\021-static-extension");
lf[290]=C_h_intern(&lf[290],19,"-private-repository");
lf[291]=C_h_intern(&lf[291],13,"-no-elevation");
lf[292]=C_h_intern(&lf[292],4,"-gui");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\007-DC_GUI");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\014kernel32.lib");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\012user32.lib");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\011gdi32.lib");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\012chicken.rc");
lf[302]=C_h_intern(&lf[302],7,"-deploy");
lf[303]=C_h_intern(&lf[303],9,"-deployed");
lf[304]=C_h_intern(&lf[304],10,"-framework");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[306]=C_h_intern(&lf[306],2,"-o");
lf[307]=C_h_intern(&lf[307],2,"-O");
lf[308]=C_h_intern(&lf[308],3,"-O1");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[311]=C_h_intern(&lf[311],3,"-O2");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[314]=C_h_intern(&lf[314],3,"-O3");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[317]=C_h_intern(&lf[317],3,"-O4");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\0014");
lf[320]=C_h_intern(&lf[320],3,"-O5");
lf[321]=C_h_intern(&lf[321],6,"cygwin");
lf[322]=C_h_intern(&lf[322],3,"gnu");
lf[323]=C_h_intern(&lf[323],5,"clang");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\003-O3");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\024-fomit-frame-pointer");
lf[326]=C_h_intern(&lf[326],14,"build-platform");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\0015");
lf[329]=C_h_intern(&lf[329],3,"-d0");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[332]=C_h_intern(&lf[332],3,"-d1");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[335]=C_h_intern(&lf[335],3,"-d2");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[338]=C_h_intern(&lf[338],8,"-dry-run");
lf[339]=C_h_intern(&lf[339],2,"-s");
lf[340]=C_h_intern(&lf[340],4,"-dll");
lf[341]=C_h_intern(&lf[341],8,"-library");
lf[342]=C_h_intern(&lf[342],9,"-compiler");
lf[343]=C_h_intern(&lf[343],3,"-cc");
lf[344]=C_h_intern(&lf[344],4,"-cxx");
lf[345]=C_h_intern(&lf[345],3,"-ld");
lf[346]=C_h_intern(&lf[346],2,"-I");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[348]=C_h_intern(&lf[348],2,"-C");
lf[349]=C_h_intern(&lf[349],12,"string-split");
lf[350]=C_h_intern(&lf[350],6,"-strip");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[352]=C_h_intern(&lf[352],2,"-L");
lf[353]=C_h_intern(&lf[353],6,"-rpath");
lf[354]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003gnu\376\003\000\000\002\376\001\000\000\005clang\376\377\016");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[356]=C_h_intern(&lf[356],5,"-host");
lf[357]=C_h_intern(&lf[357],1,"-");
lf[358]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[360]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-S\376\003\000\000\002\376B\000\000\013-scrutinize\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-feature\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensi"
"tive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-e"
"xtend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-N\376\003\000\000\002\376B\000\000\026-no-usual-integrations\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-J\376\003\000"
"\000\002\376B\000\000\032-emit-all-import-libraries\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-j\376\003\000\000\002\376B\000\000\024-emit-import-libr"
"ary\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-n\376\003\000\000\002\376B\000\000\021-emit-inline-file\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-b\376\003\000\000\002\376B\000\000\006"
"-block\376\377\016\376\377\016");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000\000\017-compile-syntax\376\003\000\000\002\376\001\000"
"\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\010-dynamic\376\003\000\000\002\376\001\000\000\036-disable-stac"
"k-overflow-checks\376\003\000\000\002\376\001\000\000\006-local\376\003\000\000\002\376\001\000\000\037-emit-external-prototypes-first\376\003\000\000\002\376"
"\001\000\000\007-inline\376\003\000\000\002\376\001\000\000\010-release\376\003\000\000\002\376\001\000\000\013-scrutinize\376\003\000\000\002\376\001\000\000\015-analyze-only\376\003\000\000\002\376\001"
"\000\000\025-keep-shadowed-macros\376\003\000\000\002\376\001\000\000\016-inline-global\376\003\000\000\002\376\001\000\000\022-ignore-repository\376\003\000\000"
"\002\376\001\000\000\021-no-symbol-escape\376\003\000\000\002\376\001\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376\001\000\000\014-r5rs-syntax\376"
"\003\000\000\002\376\001\000\000\017-no-argc-checks\376\003\000\000\002\376\001\000\000\020-no-bound-checks\376\003\000\000\002\376\001\000\000\024-no-procedure-checks"
"\376\003\000\000\002\376\001\000\000\023-no-compiler-syntax\376\003\000\000\002\376\001\000\000\032-emit-all-import-libraries\376\003\000\000\002\376\001\000\000\013-setu"
"p-mode\376\003\000\000\002\376\001\000\000\011-unboxing\376\003\000\000\002\376\001\000\000\015-no-elevation\376\003\000\000\002\376\001\000\000\047-no-procedure-checks-f"
"or-usual-bindings\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\014-output-file\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000"
"\002\376\001\000\000\013-stack-size\376\003\000\000\002\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-key"
"word-style\376\003\000\000\002\376\001\000\000\017-optimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-si"
"ze\376\003\000\000\002\376\001\000\000\007-extend\376\003\000\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002"
"\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\020-disable-w"
"arning\376\003\000\000\002\376\001\000\000\021-emit-inline-file\376\003\000\000\002\376\001\000\000\006-types\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000\002\376\001\000\000\014-de"
"bug-level\376\003\000\000\002\376\001\000\000\014-heap-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap-initial-"
"size\376\003\000\000\002\376\001\000\000\024-consult-inline-file\376\003\000\000\002\376\001\000\000\024-emit-import-library\376\003\000\000\002\376\001\000\000\021-stati"
"c-extension\376\377\016");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[364]=C_h_intern(&lf[364],9,"substring");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[367]=C_h_intern(&lf[367],15,"lset-difference");
lf[368]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000S\376\003\000\000\002\376\377\012\000\000J\376\377\016");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[371]=C_h_intern(&lf[371],18,"decompose-pathname");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\002rc");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[387]=C_h_intern(&lf[387],15,"-optimize-level");
lf[388]=C_h_intern(&lf[388],15,"-benchmark-mode");
lf[389]=C_h_intern(&lf[389],10,"-to-stdout");
lf[390]=C_h_intern(&lf[390],7,"-shared");
lf[391]=C_h_intern(&lf[391],8,"-dynamic");
lf[392]=C_h_intern(&lf[392],8,"-windows");
lf[393]=C_h_intern(&lf[393],2,"-W");
lf[394]=C_h_intern(&lf[394],14,"string->symbol");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[396]=C_h_intern(&lf[396],24,"get-environment-variable");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\003-I\042");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[405]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011-lchicken\376\377\016");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\022libchicken-static.");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[410]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[411]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[412]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[413]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[420]=C_h_intern(&lf[420],22,"command-line-arguments");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[422]=C_h_intern(&lf[422],16,"software-version");
C_register_lf2(lf,423,create_ptable());
t2=C_mutate(&lf[0] /* (set! c56 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1022,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1020 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1023 in k1020 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1026 in k1023 in k1020 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1037,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 65   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[326]))(2,*((C_word*)lf[326]+1),t2);}

/* k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4652,2,t0,t1);}
t2=C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3] /* (set! mingw ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 66   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[326]))(2,*((C_word*)lf[326]+1),t4);}

/* k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=C_eqp(t1,lf[4]);
t3=C_mutate(&lf[5] /* (set! msvc ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 67   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[422]))(2,*((C_word*)lf[422]+1),t4);}

/* k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4644,2,t0,t1);}
t2=C_eqp(t1,lf[6]);
t3=C_mutate(&lf[7] /* (set! osx ...) */,t2);
t4=C_retrieve2(lf[3],"mingw");
t5=(C_truep(C_retrieve2(lf[3],"mingw"))?C_retrieve2(lf[3],"mingw"):C_retrieve2(lf[5],"msvc"));
t6=C_mutate(&lf[8] /* (set! win ...) */,t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 69   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[422]))(2,*((C_word*)lf[422]+1),t7);}

/* k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4640,2,t0,t1);}
t2=C_eqp(t1,lf[9]);
t3=C_mutate(&lf[10] /* (set! netbsd ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 72   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[422]))(2,*((C_word*)lf[422]+1),t4);}

/* k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4636,2,t0,t1);}
t2=C_i_memq(t1,lf[11]);
t3=C_mutate(&lf[12] /* (set! elf ...) */,t2);
t4=C_mutate(&lf[13] /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1072,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1091,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 78   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[396]))(3,*((C_word*)lf[396]+1),t5,lf[421]);}

/* k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1091,2,t0,t1);}
t2=C_mutate(&lf[19] /* (set! chicken-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1095,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 79   command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[420]))(2,*((C_word*)lf[420]+1),t3);}

/* k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
t2=C_mutate(&lf[20] /* (set! arguments ...) */,t1);
t3=C_i_member(lf[21],C_retrieve2(lf[20],"arguments"));
t4=C_mutate(&lf[22] /* (set! host-mode ...) */,t3);
t5=C_fudge(C_fix(39));
t6=C_mutate(&lf[23] /* (set! cross-chicken ...) */,t5);
t7=C_mutate(&lf[24] /* (set! quotewrap ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1118,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4622,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4626,a[2]=t8,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t11=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t11=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k4624 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4626,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[418]);
/* csc.scm: 85   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[3],t2,lf[419]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}}

/* f5830 in k4624 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4620 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5483,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5483 in k4620 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1130,2,t0,t1);}
t2=C_mutate(&lf[27] /* (set! home ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1134,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4606,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4610,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4614,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}

/* k4612 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4618,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k4616 in k4612 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 98   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4608 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4610,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[416]);
/* csc.scm: 85   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[3],t2,lf[417]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5826,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}}

/* f5826 in k4608 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4604 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5478,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5478 in k4604 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1134,2,t0,t1);}
t2=C_mutate(&lf[28] /* (set! translator ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1138,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4596,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k4594 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5473,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5473 in k4594 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1138,2,t0,t1);}
t2=C_mutate(&lf[29] /* (set! compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1142,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4586,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k4584 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5468 in k4584 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1142,2,t0,t1);}
t2=C_mutate(&lf[30] /* (set! c++-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4576,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_RC_COMPILER),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_RC_COMPILER),C_fix(0));}}

/* k4574 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5463 in k4574 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1146,2,t0,t1);}
t2=C_mutate(&lf[31] /* (set! rc-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1150,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4563,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5458,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,lf[415]);}
else{
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}}

/* f5458 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4561 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5453,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5453 in k4561 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1150,2,t0,t1);}
t2=C_mutate(&lf[32] /* (set! linker ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1154,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4550,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5448,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,lf[414]);}
else{
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}}

/* f5448 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4548 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5443 in k4548 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1154,2,t0,t1);}
t2=C_mutate(&lf[33] /* (set! c++-linker ...) */,t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[34]:lf[35]);
t4=C_mutate(&lf[36] /* (set! object-extension ...) */,t3);
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[37]:lf[38]);
t6=C_mutate(&lf[39] /* (set! library-extension ...) */,t5);
t7=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[40]:lf[41]);
t8=C_mutate(&lf[42] /* (set! link-output-flag ...) */,t7);
t9=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[43]:lf[44]);
t10=C_mutate(&lf[45] /* (set! executable-extension ...) */,t9);
t11=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[46]:lf[47]);
t12=C_mutate(&lf[48] /* (set! compile-output-flag ...) */,t11);
t13=C_mutate(&lf[49] /* (set! shared-library-extension ...) */,C_retrieve(lf[50]));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1181,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t15=C_retrieve2(lf[3],"mingw");
if(C_truep(C_retrieve2(lf[3],"mingw"))){
t16=C_retrieve2(lf[3],"mingw");
t17=t14;
f_1181(t17,(C_truep(C_retrieve2(lf[3],"mingw"))?lf[410]:lf[411]));}
else{
t16=C_retrieve2(lf[5],"msvc");
t17=t14;
f_1181(t17,(C_truep(C_retrieve2(lf[5],"msvc"))?lf[412]:lf[413]));}}

/* k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1181,NULL,2,t0,t1);}
t2=C_mutate(&lf[51] /* (set! pic-options ...) */,t1);
t3=C_mutate(&lf[52] /* (set! windows-shell ...) */,C_mk_bool(C_WINDOWS_SHELL));
t4=lf[53] /* generate-manifest */ =C_SCHEME_FALSE;;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
/* csc.scm: 120  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t5,lf[408],C_retrieve2(lf[39],"library-extension"));}
else{
/* csc.scm: 120  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t5,lf[409],C_retrieve2(lf[39],"library-extension"));}}

/* k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1187,2,t0,t1);}
t2=C_mutate(&lf[54] /* (set! default-library ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1191,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4533,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k4531 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 124  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),((C_word*)t0)[2],t1);}

/* k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1191,2,t0,t1);}
t2=C_mutate(&lf[55] /* (set! default-compilation-optimization-options ...) */,t1);
t3=C_mutate(&lf[56] /* (set! best-compilation-optimization-options ...) */,C_retrieve2(lf[55],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1196,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4523,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k4521 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 126  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),((C_word*)t0)[2],t1);}

/* k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
t2=C_mutate(&lf[57] /* (set! default-linking-optimization-options ...) */,t1);
t3=C_mutate(&lf[58] /* (set! best-linking-optimization-options ...) */,C_retrieve2(lf[57],"default-linking-optimization-options"));
t4=lf[59] /* scheme-files */ =C_SCHEME_END_OF_LIST;;
t5=lf[60] /* c-files */ =C_SCHEME_END_OF_LIST;;
t6=lf[61] /* rc-files */ =C_SCHEME_END_OF_LIST;;
t7=lf[62] /* generated-c-files */ =C_SCHEME_END_OF_LIST;;
t8=lf[63] /* generated-rc-files */ =C_SCHEME_END_OF_LIST;;
t9=lf[64] /* object-files */ =C_SCHEME_END_OF_LIST;;
t10=lf[65] /* generated-object-files */ =C_SCHEME_END_OF_LIST;;
t11=lf[66] /* cpp-mode */ =C_SCHEME_FALSE;;
t12=lf[67] /* objc-mode */ =C_SCHEME_FALSE;;
t13=lf[68] /* embedded */ =C_SCHEME_FALSE;;
t14=lf[69] /* inquiry-only */ =C_SCHEME_FALSE;;
t15=lf[70] /* show-cflags */ =C_SCHEME_FALSE;;
t16=lf[71] /* show-ldflags */ =C_SCHEME_FALSE;;
t17=lf[72] /* show-libs */ =C_SCHEME_FALSE;;
t18=lf[73] /* dry-run */ =C_SCHEME_FALSE;;
t19=lf[74] /* gui */ =C_SCHEME_FALSE;;
t20=lf[75] /* deploy */ =C_SCHEME_FALSE;;
t21=lf[76] /* deployed */ =C_SCHEME_FALSE;;
t22=lf[77] /* rpath */ =C_SCHEME_FALSE;;
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1228,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t24=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t24+1)))(4,t24,t23,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t24=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t24+1)))(4,t24,t23,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1228,2,t0,t1);}
t2=C_mutate(&lf[78] /* (set! extra-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1232,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1232,2,t0,t1);}
t2=C_mutate(&lf[79] /* (set! extra-shared-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4485,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4489,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4493,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4497,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k4495 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4501,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 210  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t2,lf[407],C_retrieve2(lf[54],"default-library"));}

/* k4499 in k4495 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 208  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4491 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
t2=C_retrieve2(lf[54],"default-library");
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t3=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[406]);
/* csc.scm: 85   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[3],t3,C_retrieve2(lf[54],"default-library"));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5822,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t3,t1);}}

/* f5822 in k4491 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4487 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5438,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5438 in k4487 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4485,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[80] /* (set! default-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1240,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4481,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 214  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t5,lf[404],C_retrieve2(lf[39],"library-extension"));}
else{
t5=t4;
f_1240(t5,lf[405]);}}

/* k4479 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4481,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1240(t2,C_a_i_list(&a,1,t1));}

/* k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1240(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1240,NULL,2,t0,t1);}
t2=C_mutate(&lf[81] /* (set! default-shared-library-files ...) */,t1);
t3=C_mutate(&lf[82] /* (set! library-files ...) */,C_retrieve2(lf[80],"default-library-files"));
t4=C_mutate(&lf[83] /* (set! shared-library-files ...) */,C_retrieve2(lf[81],"default-shared-library-files"));
t5=lf[84] /* translate-options */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1247,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4468,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k4466 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[402]);
/* csc.scm: 85   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[2],t2,lf[403]);}
else{
t2=((C_word*)t0)[2];
f_1247(2,t2,t1);}}

/* k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1247,2,t0,t1);}
t2=C_i_member(t1,lf[85]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[86] /* (set! include-dir ...) */,t3);
t5=lf[87] /* compile-options */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1255,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[86],"include-dir"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4457,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 231  conc */
((C_proc5)C_retrieve_symbol_proc(lf[182]))(5,*((C_word*)lf[182]+1),t7,lf[400],C_retrieve2(lf[86],"include-dir"),lf[401]);}
else{
t7=t6;
f_1255(t7,C_SCHEME_END_OF_LIST);}}

/* k4455 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4457,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1255(t2,C_a_i_list(&a,1,t1));}

/* k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1255(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1255,NULL,2,t0,t1);}
t2=C_mutate(&lf[88] /* (set! builtin-compile-options ...) */,t1);
t3=C_mutate(&lf[89] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[55],"default-compilation-optimization-options"));
t4=C_mutate(&lf[90] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[57],"default-linking-optimization-options"));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1263,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4444,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k4442 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[398]);
/* csc.scm: 85   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[2],t2,lf[399]);}
else{
t2=((C_word*)t0)[2];
f_1263(2,t2,t1);}}

/* k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1263,2,t0,t1);}
t2=C_mutate(&lf[91] /* (set! library-dir ...) */,t1);
t3=lf[92] /* link-options */ =C_SCHEME_END_OF_LIST;;
t4=lf[93] /* target-filename */ =C_SCHEME_FALSE;;
t5=lf[94] /* verbose */ =C_SCHEME_FALSE;;
t6=lf[95] /* keep-files */ =C_SCHEME_FALSE;;
t7=lf[96] /* translate-only */ =C_SCHEME_FALSE;;
t8=lf[97] /* compile-only */ =C_SCHEME_FALSE;;
t9=lf[98] /* to-stdout */ =C_SCHEME_FALSE;;
t10=lf[99] /* shared */ =C_SCHEME_FALSE;;
t11=lf[100] /* static */ =C_SCHEME_FALSE;;
t12=lf[101] /* static-libs */ =C_SCHEME_FALSE;;
t13=lf[102] /* static-extensions */ =C_SCHEME_END_OF_LIST;;
t14=lf[103] /* required-extensions */ =C_SCHEME_END_OF_LIST;;
t15=C_mutate(&lf[104] /* (set! compiler-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3404,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[108] /* (set! lib-path ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3785,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[112] /* (set! copy-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3830,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[120] /* (set! static-extension-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3870,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[126] /* (set! linker-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3967,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[130] /* (set! linker-libraries ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4019,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[132] /* (set! constant777 ...) */,lf[133]);
t22=C_mutate(&lf[106] /* (set! quote-option ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4162,tmp=(C_word)a,a+=2,tmp));
t23=lf[143] /* last-exit-code */ =C_SCHEME_FALSE;;
t24=C_mutate(&lf[113] /* (set! command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4248,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate(&lf[152] /* (set! $delete-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4264,tmp=(C_word)a,a+=2,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4429,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4433,a[2]=t27,tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4437,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 1097 get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[396]))(3,*((C_word*)lf[396]+1),t29,lf[397]);}

/* k4435 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csc.scm: 1097 string-split */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),((C_word*)t0)[2],t2);}
else{
/* csc.scm: 1097 string-split */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),((C_word*)t0)[2],lf[395]);}}

/* k4431 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 1096 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[20],"arguments"));}

/* k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4429,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1368,tmp=(C_word)a,a+=2,tmp));
t11=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1375,tmp=(C_word)a,a+=2,tmp));
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1414,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1440,tmp=(C_word)a,a+=2,tmp));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1457,a[2]=t7,a[3]=t5,a[4]=t3,a[5]=t15,a[6]=t9,tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_1457(t17,((C_word*)t0)[2],t1);}

/* loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1457(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1457,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1468,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 508  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[87],"compile-options"),C_retrieve2(lf[88],"builtin-compile-options"));}
else{
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1694,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,a[8]=t1,a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* csc.scm: 554  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[394]+1)))(3,*((C_word*)lf[394]+1),t7,t3);}}

/* k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(t1,lf[236]);
t4=(C_truep(t3)?t3:C_eqp(t1,lf[237]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1709,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}
else{
t5=C_eqp(t1,lf[242]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1721,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 560  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[243]))(2,*((C_word*)lf[243]+1),t7);}
else{
t6=C_eqp(t1,lf[244]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1737,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1744,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 563  sprintf */
((C_proc4)C_retrieve_proc(*((C_word*)lf[245]+1)))(4,*((C_word*)lf[245]+1),t8,C_retrieve2(lf[28],"translator"),lf[246]);}
else{
t7=C_eqp(t1,lf[247]);
if(C_truep(t7)){
t8=lf[66] /* cpp-mode */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=C_a_i_cons(&a,2,lf[248],C_retrieve2(lf[87],"compile-options"));
t10=C_mutate(&lf[87] /* (set! compile-options ...) */,t9);
/* csc.scm: 781  loop */
t11=((C_word*)((C_word*)t0)[9])[1];
f_1457(t11,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
/* csc.scm: 781  loop */
t9=((C_word*)((C_word*)t0)[9])[1];
f_1457(t9,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}}
else{
t8=C_eqp(t1,lf[249]);
if(C_truep(t8)){
t9=lf[67] /* objc-mode */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t10=((C_word*)((C_word*)t0)[9])[1];
f_1457(t10,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t9=C_eqp(t1,lf[250]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 571  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t10,lf[251],lf[252],C_retrieve2(lf[84],"translate-options"));}
else{
t10=C_eqp(t1,lf[253]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 574  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t11,lf[254],lf[255],C_retrieve2(lf[84],"translate-options"));}
else{
t11=C_eqp(t1,lf[256]);
if(C_truep(t11)){
t12=lf[69] /* inquiry-only */ =C_SCHEME_TRUE;;
t13=lf[70] /* show-cflags */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t14=((C_word*)((C_word*)t0)[9])[1];
f_1457(t14,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t12=C_eqp(t1,lf[257]);
if(C_truep(t12)){
t13=lf[69] /* inquiry-only */ =C_SCHEME_TRUE;;
t14=lf[71] /* show-ldflags */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t15=((C_word*)((C_word*)t0)[9])[1];
f_1457(t15,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t13=C_eqp(t1,lf[258]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1812,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 582  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[151]+1)))(3,*((C_word*)lf[151]+1),t14,C_retrieve2(lf[29],"compiler"));}
else{
t14=C_eqp(t1,lf[259]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1824,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 583  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[151]+1)))(3,*((C_word*)lf[151]+1),t15,C_retrieve2(lf[30],"c++-compiler"));}
else{
t15=C_eqp(t1,lf[260]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1836,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 584  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[151]+1)))(3,*((C_word*)lf[151]+1),t16,C_retrieve2(lf[32],"linker"));}
else{
t16=C_eqp(t1,lf[261]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1848,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 585  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[151]+1)))(3,*((C_word*)lf[151]+1),t17,C_retrieve2(lf[27],"home"));}
else{
t17=C_eqp(t1,lf[262]);
if(C_truep(t17)){
t18=lf[69] /* inquiry-only */ =C_SCHEME_TRUE;;
t19=lf[72] /* show-libs */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t20=((C_word*)((C_word*)t0)[9])[1];
f_1457(t20,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t18=C_eqp(t1,lf[263]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t20=C_i_numberp(C_retrieve2(lf[94],"verbose"));
t21=(C_truep(t20)?C_i_not(C_retrieve2(lf[5],"msvc")):C_SCHEME_FALSE);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1883,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 591  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t22,lf[267],lf[268],C_retrieve2(lf[87],"compile-options"));}
else{
t22=t19;
f_1868(t22,C_SCHEME_UNDEFINED);}}
else{
t19=C_eqp(t1,lf[269]);
t20=(C_truep(t19)?t19:C_eqp(t1,lf[270]));
if(C_truep(t20)){
t21=C_a_i_cons(&a,2,lf[271],C_retrieve2(lf[87],"compile-options"));
t22=C_mutate(&lf[87] /* (set! compile-options ...) */,t21);
/* csc.scm: 599  t-options */
f_1368(t2,C_a_i_list(&a,1,lf[272]));}
else{
t21=C_eqp(t1,lf[273]);
t22=(C_truep(t21)?t21:C_eqp(t1,lf[274]));
if(C_truep(t22)){
t23=lf[96] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm: 602  t-options */
f_1368(t2,C_a_i_list(&a,1,lf[275]));}
else{
t23=C_eqp(t1,lf[276]);
t24=(C_truep(t23)?t23:C_eqp(t1,lf[277]));
if(C_truep(t24)){
t25=lf[96] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm: 605  t-options */
f_1368(t2,C_a_i_list(&a,1,lf[278]));}
else{
t25=C_eqp(t1,lf[279]);
if(C_truep(t25)){
t26=lf[95] /* keep-files */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t27=((C_word*)((C_word*)t0)[9])[1];
f_1457(t27,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t26=C_eqp(t1,lf[280]);
if(C_truep(t26)){
t27=lf[97] /* compile-only */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t28=((C_word*)((C_word*)t0)[9])[1];
f_1457(t28,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t27=C_eqp(t1,lf[281]);
if(C_truep(t27)){
t28=lf[96] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t29=((C_word*)((C_word*)t0)[9])[1];
f_1457(t29,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t28=C_eqp(t1,lf[282]);
t29=(C_truep(t28)?t28:C_eqp(t1,lf[283]));
if(C_truep(t29)){
t30=lf[68] /* embedded */ =C_SCHEME_TRUE;;
t31=C_a_i_cons(&a,2,lf[284],C_retrieve2(lf[87],"compile-options"));
t32=C_mutate(&lf[87] /* (set! compile-options ...) */,t31);
/* csc.scm: 781  loop */
t33=((C_word*)((C_word*)t0)[9])[1];
f_1457(t33,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t30=C_eqp(t1,lf[285]);
t31=(C_truep(t30)?t30:C_eqp(t1,lf[286]));
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 613  check */
f_1375(t32,t1,((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t32=C_eqp(t1,lf[288]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 618  check */
f_1375(t33,t1,((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t33=C_eqp(t1,lf[290]);
if(C_truep(t33)){
t34=f_1440(C_a_i(&a,6));
/* csc.scm: 781  loop */
t35=((C_word*)((C_word*)t0)[9])[1];
f_1457(t35,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t34=C_eqp(t1,lf[291]);
if(C_truep(t34)){
t35=lf[53] /* generate-manifest */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t36=((C_word*)((C_word*)t0)[9])[1];
f_1457(t36,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t35=C_eqp(t1,lf[292]);
t36=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t35)){
t37=t36;
f_2066(t37,t35);}
else{
t37=C_eqp(t1,lf[392]);
t38=t36;
f_2066(t38,(C_truep(t37)?t37:C_eqp(t1,lf[393])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_2066(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2066,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=lf[74] /* gui */ =C_SCHEME_TRUE;;
t3=C_a_i_cons(&a,2,lf[293],C_retrieve2(lf[87],"compile-options"));
t4=C_mutate(&lf[87] /* (set! compile-options ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2103,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
t2=C_eqp(((C_word*)t0)[7],lf[302]);
if(C_truep(t2)){
t3=lf[75] /* deploy */ =C_SCHEME_TRUE;;
t4=lf[76] /* deployed */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t5=((C_word*)((C_word*)t0)[10])[1];
f_1457(t5,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1]);}
else{
t3=C_eqp(((C_word*)t0)[7],lf[303]);
if(C_truep(t3)){
t4=lf[76] /* deployed */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t5=((C_word*)((C_word*)t0)[10])[1];
f_1457(t5,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=C_eqp(((C_word*)t0)[7],lf[304]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 650  check */
f_1375(t5,((C_word*)t0)[7],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t5=C_eqp(((C_word*)t0)[7],lf[306]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 655  check */
f_1375(t6,((C_word*)t0)[7],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t6=C_eqp(((C_word*)t0)[7],lf[307]);
t7=(C_truep(t6)?t6:C_eqp(((C_word*)t0)[7],lf[308]));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2172,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 659  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t8,lf[309],lf[310],((C_word*)((C_word*)t0)[8])[1]);}
else{
t8=C_eqp(((C_word*)t0)[7],lf[311]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2182,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 660  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t9,lf[312],lf[313],((C_word*)((C_word*)t0)[8])[1]);}
else{
t9=C_eqp(((C_word*)t0)[7],lf[314]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 661  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t10,lf[315],lf[316],((C_word*)((C_word*)t0)[8])[1]);}
else{
t10=C_eqp(((C_word*)t0)[7],lf[317]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 662  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t11,lf[318],lf[319],((C_word*)((C_word*)t0)[8])[1]);}
else{
t11=C_eqp(((C_word*)t0)[7],lf[320]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 664  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t12,lf[327],lf[328],((C_word*)((C_word*)t0)[8])[1]);}
else{
t12=C_eqp(((C_word*)t0)[7],lf[329]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 668  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t13,lf[330],lf[331],((C_word*)((C_word*)t0)[8])[1]);}
else{
t13=C_eqp(((C_word*)t0)[7],lf[332]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 669  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t14,lf[333],lf[334],((C_word*)((C_word*)t0)[8])[1]);}
else{
t14=C_eqp(((C_word*)t0)[7],lf[335]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 670  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t15,lf[336],lf[337],((C_word*)((C_word*)t0)[8])[1]);}
else{
t15=C_eqp(((C_word*)t0)[7],lf[338]);
if(C_truep(t15)){
t16=lf[94] /* verbose */ =C_SCHEME_TRUE;;
t17=lf[73] /* dry-run */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t18=((C_word*)((C_word*)t0)[10])[1];
f_1457(t18,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1]);}
else{
t16=C_eqp(((C_word*)t0)[7],lf[339]);
t17=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t16)){
t18=t17;
f_2273(t18,t16);}
else{
t18=C_eqp(((C_word*)t0)[7],lf[390]);
t19=t17;
f_2273(t19,(C_truep(t18)?t18:C_eqp(((C_word*)t0)[7],lf[391])));}}}}}}}}}}}}}}}}

/* k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_2273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2273,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 675  shared-build */
f_1414(((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[8],lf[340]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[8],lf[341]));
if(C_truep(t3)){
/* csc.scm: 677  shared-build */
f_1414(((C_word*)t0)[9],C_SCHEME_TRUE);}
else{
t4=C_eqp(((C_word*)t0)[8],lf[342]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2297,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 679  check */
f_1375(t5,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t5=C_eqp(((C_word*)t0)[8],lf[343]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2314,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 683  check */
f_1375(t6,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t6=C_eqp(((C_word*)t0)[8],lf[344]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 687  check */
f_1375(t7,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t7=C_eqp(((C_word*)t0)[8],lf[345]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 691  check */
f_1375(t8,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t8=C_eqp(((C_word*)t0)[8],lf[346]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 695  check */
f_1375(t9,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t9=C_eqp(((C_word*)t0)[8],lf[348]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 698  check */
f_1375(t10,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t10=C_eqp(((C_word*)t0)[8],lf[350]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=C_a_i_list(&a,1,lf[351]);
/* csc.scm: 702  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t11,C_retrieve2(lf[92],"link-options"),t12);}
else{
t11=C_eqp(((C_word*)t0)[8],lf[352]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2425,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 704  check */
f_1375(t12,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t12=C_eqp(((C_word*)t0)[8],lf[353]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 708  check */
f_1375(t13,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t13=C_eqp(((C_word*)t0)[8],lf[356]);
if(C_truep(t13)){
/* csc.scm: 781  loop */
t14=((C_word*)((C_word*)t0)[6])[1];
f_1457(t14,((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);}
else{
t14=C_eqp(((C_word*)t0)[8],lf[357]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2502,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 716  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[110]))(5,*((C_word*)lf[110]+1),t15,C_SCHEME_FALSE,lf[359],C_retrieve2(lf[45],"executable-extension"));}
else{
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t16=C_eqp(((C_word*)t0)[8],lf[389]);
if(C_truep(t16)){
t17=lf[98] /* to-stdout */ =C_SCHEME_TRUE;;
t18=lf[96] /* translate-only */ =C_SCHEME_TRUE;;
t19=t15;
f_2509(t19,t18);}
else{
t17=t15;
f_2509(t17,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}

/* k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_2509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2509,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[9];
if(C_truep((C_truep(C_eqp(t3,lf[387]))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,lf[388]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[89] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[56],"best-compilation-optimization-options"));
t5=C_mutate(&lf[90] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[58],"best-linking-optimization-options"));
t6=t2;
f_2512(t6,t5);}
else{
t4=t2;
f_2512(t4,C_SCHEME_UNDEFINED);}}

/* k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_2512(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2512,NULL,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[9],lf[360]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=f_2519(C_a_i(&a,3),t3,t2);
/* csc.scm: 781  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1457(t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[8])[1]);}
else{
if(C_truep(C_i_memq(((C_word*)t0)[9],lf[361]))){
/* csc.scm: 726  t-options */
f_1368(((C_word*)t0)[4],C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep(C_i_memq(((C_word*)t0)[9],lf[362]))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 728  check */
f_1375(t3,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=C_i_string_length(((C_word*)t0)[3]);
if(C_truep(C_i_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 733  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[364]+1)))(5,*((C_word*)lf[364]+1),t5,((C_word*)t0)[3],C_fix(0),C_fix(2));}
else{
t5=t3;
f_2568(t5,C_SCHEME_FALSE);}}}}}

/* k2945 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2568(t2,C_i_string_equal_p(lf[386],t1));}

/* k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_2568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2568,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 734  t-options */
f_1368(((C_word*)t0)[7],C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=C_i_string_length(((C_word*)t0)[6]);
if(C_truep(C_i_greaterp(t3,C_fix(1)))){
t4=C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t5=t2;
f_2577(t5,C_eqp(C_make_character(45),t4));}
else{
t4=t2;
f_2577(t4,C_SCHEME_FALSE);}}}

/* k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_2577(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2577,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t3=C_eqp(C_make_character(108),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t5=C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm: 738  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t4,C_retrieve2(lf[92],"link-options"),t5);}
else{
t4=C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t5=C_eqp(C_make_character(76),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t7=C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm: 740  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t6,C_retrieve2(lf[92],"link-options"),t7);}
else{
t6=C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t7=C_eqp(C_make_character(73),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2615,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t9=C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm: 742  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t8,C_retrieve2(lf[87],"compile-options"),t9);}
else{
t8=C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t9=C_eqp(C_make_character(68),t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 744  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[364]+1)))(4,*((C_word*)lf[364]+1),t10,((C_word*)t0)[8],C_fix(2));}
else{
t10=C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t11=C_eqp(C_make_character(70),t10);
if(C_truep(t11)){
if(C_truep(C_retrieve2(lf[7],"osx"))){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2645,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t13=C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm: 747  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t12,C_retrieve2(lf[87],"compile-options"),t13);}
else{
/* csc.scm: 781  loop */
t12=((C_word*)((C_word*)t0)[7])[1];
f_1457(t12,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);}}
else{
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t13=C_i_string_length(((C_word*)t0)[8]);
if(C_truep(C_i_greaterp(t13,C_fix(3)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2758,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 748  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[364]+1)))(5,*((C_word*)lf[364]+1),t14,((C_word*)t0)[8],C_fix(0),C_fix(4));}
else{
t14=t12;
f_2655(t14,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 757  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),t2,((C_word*)t0)[8]);}}

/* k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2910,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 777  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t2,((C_word*)t0)[6],lf[385]);}}

/* k2908 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* csc.scm: 778  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),t2,t1);}

/* k2914 in k2908 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
/* csc.scm: 781  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_1457(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[6])[1]);}
else{
/* csc.scm: 780  quit */
f_1072(((C_word*)t0)[3],lf[384],C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a2798 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2799,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep(C_i_equalp(t6,lf[372]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t6,lf[373]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2824,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 762  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t7,C_retrieve2(lf[60],"c-files"),t8);}
else{
if(C_truep(C_i_string_ci_equal_p(t4,lf[374]))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2838,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 764  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t7,C_retrieve2(lf[61],"rc-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep(C_i_equalp(t7,lf[375]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[376]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[377]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[378]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[379]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=C_a_i_cons(&a,2,lf[380],C_retrieve2(lf[87],"compile-options"));
t10=C_mutate(&lf[87] /* (set! compile-options ...) */,t9);
t11=t8;
f_2851(t11,t10);}
else{
t9=t8;
f_2851(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep(C_i_equalp(t8,lf[381]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t8,lf[382]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t8,lf[383]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[67] /* objc-mode */ =C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2875,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 771  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t10,C_retrieve2(lf[60],"c-files"),t11);}
else{
t9=C_i_string_equal_p(t4,C_retrieve2(lf[36],"object-extension"));
t10=(C_truep(t9)?t9:C_i_string_equal_p(t4,C_retrieve2(lf[39],"library-extension")));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2892,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 774  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t11,C_retrieve2(lf[64],"object-files"),t12);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2900,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 775  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t11,C_retrieve2(lf[59],"scheme-files"),t12);}}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2810,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 760  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t6,C_retrieve2(lf[59],"scheme-files"),t7);}}

/* k2808 in a2798 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[59] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2898 in a2798 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[59] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2890 in a2798 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[64] /* (set! object-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2873 in a2798 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2849 in a2798 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_2851(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2851,NULL,2,t0,t1);}
t2=lf[66] /* cpp-mode */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 768  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[60],"c-files"),t4);}

/* k2854 in k2849 in a2798 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2836 in a2798 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61] /* (set! rc-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2822 in a2798 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a2792 in k2786 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2793,2,t0,t1);}
/* csc.scm: 758  decompose-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[371]))(3,*((C_word*)lf[371]+1),t1,((C_word*)t0)[2]);}

/* k2756 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2655(t2,C_i_string_equal_p(lf[370],t1));}

/* k2653 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_2655(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2655,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list(&a,1,((C_word*)t0)[4]);
/* csc.scm: 749  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,C_retrieve2(lf[92],"link-options"),t3);}
else{
t2=C_i_string_length(((C_word*)t0)[4]);
if(C_truep(C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2741,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* string->list */
t4=C_retrieve(lf[140]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
/* csc.scm: 756  quit */
f_1072(((C_word*)t0)[3],lf[369],C_a_i_list(&a,1,((C_word*)t0)[2]));}}}

/* k2739 in k2653 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2741,2,t0,t1);}
t2=C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csc.scm: 752  lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[367]))(5,*((C_word*)lf[367]+1),t3,*((C_word*)lf[142]+1),t2,lf[368]);}

/* k2735 in k2739 in k2653 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2737,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2688,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2688(t11,t7,((C_word*)t0)[4]);}
else{
/* csc.scm: 755  quit */
f_1072(((C_word*)t0)[3],lf[366],C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* loop344 in k2735 in k2739 in k2653 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_2688(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2688,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2726,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_string(&a,1,t4);
/* csc.scm: 754  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t3,lf[365],t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2724 in loop344 in k2735 in k2739 in k2653 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2726,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop344357 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2688(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop344357 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2688(t6,((C_word*)t0)[3],t5);}}

/* k2684 in k2735 in k2739 in k2653 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 754  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2680 in k2735 in k2739 in k2653 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1457(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2657 in k2653 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* (set! link-options ...) */,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1457(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2643 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87] /* (set! compile-options ...) */,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1457(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2630 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
/* csc.scm: 744  t-options */
f_1368(((C_word*)t0)[2],C_a_i_list(&a,2,lf[363],t1));}

/* k2613 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87] /* (set! compile-options ...) */,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1457(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2599 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* (set! link-options ...) */,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1457(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2585 in k2575 in k2566 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* (set! link-options ...) */,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1457(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2547 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=C_i_car(((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2555,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csc.scm: 730  string->number */
C_string_to_number(3,0,t3,t2);}

/* k2553 in k2547 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 731  t-options */
f_1368(t2,C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2556 in k2553 in k2547 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm: 781  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1457(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* g319 in k2510 in k2507 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static C_word C_fcall f_2519(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t2=C_i_cadr(t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
return(t4);}

/* k2500 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2502,2,t0,t1);}
t2=C_mutate(&lf[93] /* (set! target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 717  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[59],"scheme-files"),lf[358]);}

/* k2504 in k2500 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[59] /* (set! scheme-files ...) */,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1457(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2448 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[77] /* (set! rpath ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 710  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[326]))(2,*((C_word*)lf[326]+1),t4);}

/* k2484 in k2448 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2486,2,t0,t1);}
t2=C_i_memq(t1,lf[354]);
t3=(C_truep(t2)?C_i_not(C_retrieve2(lf[3],"mingw")):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2476,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 712  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t5,lf[355],C_retrieve2(lf[77],"rpath"));}
else{
/* csc.scm: 781  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1457(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}}

/* k2474 in k2484 in k2448 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2476,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* csc.scm: 712  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[92],"link-options"),t2);}

/* k2462 in k2484 in k2448 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[92] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm: 781  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1457(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2423 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2437,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 705  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t3,t4);}

/* k2435 in k2423 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 705  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[92],"link-options"),t1);}

/* k2427 in k2423 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[92] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm: 781  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1457(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2410 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* (set! link-options ...) */,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1457(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2384 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2398,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 699  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t3,t4);}

/* k2396 in k2384 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 699  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[87],"compile-options"),t1);}

/* k2388 in k2384 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[87] /* (set! compile-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm: 781  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1457(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2363 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 696  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t2,lf[347],t3,t4);}

/* k2367 in k2363 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1457(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2346 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[32] /* (set! linker ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm: 781  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1457(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2329 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[30] /* (set! c++-compiler ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm: 781  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1457(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2312 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[29] /* (set! compiler ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm: 781  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1457(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2295 in k2271 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[28] /* (set! translator ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm: 781  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1457(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2254 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1457(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2244 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1457(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2234 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1457(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2210 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2226,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 665  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[326]))(2,*((C_word*)lf[326]+1),t3);}

/* k2224 in k2210 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2226,2,t0,t1);}
if(C_truep((C_truep(C_eqp(t1,lf[2]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[321]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[322]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[323]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 667  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t2,lf[324],lf[325],C_retrieve2(lf[87],"compile-options"));}
else{
/* csc.scm: 781  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1457(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2220 in k2224 in k2210 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87] /* (set! compile-options ...) */,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1457(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2200 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1457(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2190 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1457(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2180 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1457(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2170 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1457(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2149 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=C_mutate(&lf[93] /* (set! target-filename ...) */,t2);
/* csc.scm: 781  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1457(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2125 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2127,2,t0,t1);}
if(C_truep(C_retrieve2(lf[7],"osx"))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 652  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t2,lf[305],t3,C_retrieve2(lf[92],"link-options"));}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm: 781  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1457(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}}

/* k2136 in k2125 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[92] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm: 781  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1457(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2101 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 631  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[110]))(5,*((C_word*)lf[110]+1),((C_word*)t0)[2],t1,lf[301],C_retrieve2(lf[36],"object-extension"));}

/* k2097 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2099,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[64],"object-files"));
t3=C_mutate(&lf[64] /* (set! object-files ...) */,t2);
t4=C_retrieve2(lf[5],"msvc");
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?C_retrieve2(lf[5],"msvc"):C_retrieve2(lf[3],"mingw"));
if(C_truep(t5)){
if(C_truep(C_retrieve2(lf[3],"mingw"))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 639  cons* */
((C_proc7)C_retrieve_symbol_proc(lf[139]))(7,*((C_word*)lf[139]+1),t6,lf[294],lf[295],lf[296],lf[297],C_retrieve2(lf[92],"link-options"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 643  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[139]))(6,*((C_word*)lf[139]+1),t6,lf[298],lf[299],lf[300],C_retrieve2(lf[92],"link-options"));}
else{
/* csc.scm: 781  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1457(t6,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}}
else{
/* csc.scm: 781  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1457(t6,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2093 in k2097 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* (set! link-options ...) */,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1457(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2086 in k2097 in k2064 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* (set! link-options ...) */,t1);
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1457(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2016 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t4=C_a_i_list(&a,1,t3);
/* csc.scm: 619  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,C_retrieve2(lf[102],"static-extensions"),t4);}

/* k2020 in k2016 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2022,2,t0,t1);}
t2=C_mutate(&lf[102] /* (set! static-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[5])[1]);
/* csc.scm: 620  t-options */
f_1368(t3,C_a_i_list(&a,2,lf[289],t4));}

/* k2023 in k2020 in k2016 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm: 781  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1457(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1984 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t4=C_a_i_list(&a,1,t3);
/* csc.scm: 614  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,C_retrieve2(lf[103],"required-extensions"),t4);}

/* k1988 in k1984 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
t2=C_mutate(&lf[103] /* (set! required-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[5])[1]);
/* csc.scm: 615  t-options */
f_1368(t3,C_a_i_list(&a,2,lf[287],t4));}

/* k1991 in k1988 in k1984 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm: 781  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1457(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1881 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=C_mutate(&lf[87] /* (set! compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?C_a_i_cons(&a,2,lf[265],C_retrieve2(lf[92],"link-options")):C_a_i_cons(&a,2,lf[266],C_retrieve2(lf[92],"link-options")));
t4=C_mutate(&lf[92] /* (set! link-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1868(t5,t4);}

/* k1866 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1868,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[94],"verbose"))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1874,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 594  t-options */
f_1368(t2,C_a_i_list(&a,1,lf[264]));}
else{
t2=lf[94] /* verbose */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1457(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k1872 in k1866 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[94] /* verbose */ =C_fix(2);;
/* csc.scm: 781  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1457(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1846 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 585  exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_fix(0));}

/* k1834 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 584  exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_fix(0));}

/* k1822 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 583  exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_fix(0));}

/* k1810 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 582  exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_fix(0));}

/* k1784 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[84] /* (set! translate-options ...) */,t1);
t3=lf[101] /* static-libs */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1457(t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1773 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[84] /* (set! translate-options ...) */,t1);
t3=lf[100] /* static */ =C_SCHEME_TRUE;;
/* csc.scm: 781  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1457(t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1742 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 563  system */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),((C_word*)t0)[2],t1);}

/* k1735 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 564  exit */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k1726 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 560  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[151]+1)))(3,*((C_word*)lf[151]+1),((C_word*)t0)[2],t1);}

/* k1719 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 561  exit */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k1326 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[238],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,lf[239],t4);
t6=C_a_i_cons(&a,2,t1,t5);
t7=C_a_i_cons(&a,2,lf[240],t6);
t8=C_a_i_cons(&a,2,t1,t7);
t9=C_a_i_cons(&a,2,lf[241],t8);
/* csc.scm: 277  ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[168]))(3,*((C_word*)lf[168]+1),t2,t9);}

/* k1333 in k1326 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 278  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[151]+1)))(3,*((C_word*)lf[151]+1),((C_word*)t0)[2],t1);}

/* k1707 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 558  exit */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k1695 in k1692 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 781  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1457(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1468,2,t0,t1);}
t2=C_mutate(&lf[87] /* (set! compile-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[12],"elf"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1277,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 249  conc */
((C_proc5)C_retrieve_symbol_proc(lf[182]))(5,*((C_word*)lf[182]+1),t4,lf[232],C_retrieve2(lf[91],"library-dir"),lf[233]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1311,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 259  conc */
((C_proc5)C_retrieve_symbol_proc(lf[182]))(5,*((C_word*)lf[182]+1),t4,lf[234],C_retrieve2(lf[91],"library-dir"),lf[235]);}}

/* k1309 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* csc.scm: 509  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[92],"link-options"),t2);}

/* k1275 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[76],"deployed"))?C_i_not(C_retrieve2(lf[10],"netbsd")):C_SCHEME_FALSE);
if(C_truep(t4)){
/* csc.scm: 250  conc */
((C_proc5)C_retrieve_symbol_proc(lf[182]))(5,*((C_word*)lf[182]+1),t2,lf[227],lf[229],lf[228]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1295,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}}

/* k1293 in k1275 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1295,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[230]);
/* csc.scm: 85   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[3],t2,lf[231]);}
else{
/* csc.scm: 250  conc */
((C_proc5)C_retrieve_symbol_proc(lf[182]))(5,*((C_word*)lf[182]+1),((C_word*)t0)[2],lf[227],t1,lf[228]);}}

/* k1283 in k1275 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 250  conc */
((C_proc5)C_retrieve_symbol_proc(lf[182]))(5,*((C_word*)lf[182]+1),((C_word*)t0)[2],lf[227],t1,lf[228]);}

/* k1279 in k1275 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* csc.scm: 509  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[92],"link-options"),t2);}

/* k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1472,2,t0,t1);}
t2=C_mutate(&lf[92] /* (set! link-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[69],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1648,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[70],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1681,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 512  compiler-options */
f_3404(t5);}
else{
t5=t4;
f_1648(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1475(2,t4,C_SCHEME_UNDEFINED);}}

/* k1679 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 512  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[226]+1)))(4,*((C_word*)lf[226]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1646 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1651,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[71],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1674,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 513  linker-options */
f_3967(t3);}
else{
t3=t2;
f_1651(2,t3,C_SCHEME_UNDEFINED);}}

/* k1672 in k1646 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 513  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[226]+1)))(4,*((C_word*)lf[226]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1649 in k1646 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[72],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1667,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 514  linker-libraries */
f_4019(t3,C_a_i_list(&a,1,C_SCHEME_TRUE));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5429,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 515  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[225]+1)))(2,*((C_word*)lf[225]+1),t3);}}

/* f5429 in k1649 in k1646 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 516  exit */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k1665 in k1649 in k1646 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 514  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[226]+1)))(4,*((C_word*)lf[226]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1652 in k1649 in k1646 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 515  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[225]+1)))(2,*((C_word*)lf[225]+1),t2);}

/* k1655 in k1652 in k1649 in k1646 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 516  exit */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[59],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1573,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[60],"c-files")))){
if(C_truep(C_i_nullp(C_retrieve2(lf[64],"object-files")))){
/* csc.scm: 520  quit */
f_1072(t3,lf[217],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_1573(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1573(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1611,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[99],"shared"))?C_i_not(C_retrieve2(lf[68],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_a_i_cons(&a,2,lf[224],C_retrieve2(lf[84],"translate-options"));
t6=C_mutate(&lf[84] /* (set! translate-options ...) */,t5);
t7=t3;
f_1611(t7,t6);}
else{
t5=t3;
f_1611(t5,C_SCHEME_UNDEFINED);}}}

/* k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1611,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[93],"target-filename"))){
t3=t2;
f_1614(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1621,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[99],"shared"))){
t4=C_i_car(C_retrieve2(lf[59],"scheme-files"));
/* csc.scm: 533  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t3,t4,C_retrieve2(lf[49],"shared-library-extension"));}
else{
t4=C_i_car(C_retrieve2(lf[59],"scheme-files"));
/* csc.scm: 534  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t3,t4,C_retrieve2(lf[45],"executable-extension"));}}}

/* k1619 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[93] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1614(t3,t2);}

/* k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1614,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3040,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3040(t6,t2,C_retrieve2(lf[59],"scheme-files"));}

/* loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3040,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3052,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_length(C_retrieve2(lf[59],"scheme-files"));
t6=C_i_nequalp(C_fix(1),t5);
t7=(C_truep(t6)?C_retrieve2(lf[93],"target-filename"):t3);
if(C_truep(C_retrieve2(lf[66],"cpp-mode"))){
/* csc.scm: 789  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t4,t7,lf[221]);}
else{
if(C_truep(C_retrieve2(lf[67],"objc-mode"))){
/* csc.scm: 789  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t4,t7,lf[222]);}
else{
/* csc.scm: 789  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t4,t7,lf[223]);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3055,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3075,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3079,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3083,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5423,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,((C_word*)t0)[2]);}

/* f5423 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3081 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3087,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[98],"to-stdout"))){
t4=t3;
f_3091(t4,lf[219]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3145,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5418,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,t5);}}

/* f5418 in k3081 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3143 in k3081 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3145,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
f_3091(t3,C_a_i_cons(&a,2,lf[220],t2));}

/* k3089 in k3081 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3091(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3091,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3095,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3099,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 803  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t7,C_retrieve2(lf[84],"translate-options"),C_SCHEME_END_OF_LIST);}

/* k3097 in k3089 in k3081 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3099,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3101,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3101(t5,((C_word*)t0)[2],t1);}

/* loop431 in k3097 in k3089 in k3081 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3101(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3101,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[106],"quote-option");
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3130,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g447448 */
t6=C_retrieve2(lf[106],"quote-option");
f_4162(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3128 in loop431 in k3097 in k3089 in k3081 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3130,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop431444 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3101(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop431444 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3101(t6,((C_word*)t0)[3],t5);}}

/* k3093 in k3089 in k3081 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 799  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3085 in k3081 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 798  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),((C_word*)t0)[3],C_retrieve2(lf[28],"translator"),((C_word*)t0)[2],t1);}

/* k3077 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 797  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[105]))(4,*((C_word*)lf[105]+1),((C_word*)t0)[2],t1,lf[218]);}

/* k3073 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 796  command */
f_4248(((C_word*)t0)[2],t1);}

/* k3053 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 805  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t2,t3,C_retrieve2(lf[60],"c-files"));}

/* k3057 in k3053 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
t2=C_mutate(&lf[60] /* (set! c-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 806  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,t4,C_retrieve2(lf[62],"generated-c-files"));}

/* k3061 in k3057 in k3053 in k3050 in loop408 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[62] /* (set! generated-c-files ...) */,t1);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3040(t4,((C_word*)t0)[2],t3);}

/* k3007 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3009,2,t0,t1);}
if(C_truep(C_retrieve2(lf[95],"keep-files"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_1478(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3017,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3017(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* loop460 in k3007 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3017(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3017,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[152],"$delete-file");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3027,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g467468 */
t6=C_retrieve2(lf[152],"$delete-file");
f_4264(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3025 in loop460 in k3007 in k1612 in k1609 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3017(t3,((C_word*)t0)[2],t2);}

/* k1571 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[60],"c-files")))){
t3=C_retrieve2(lf[64],"object-files");
/* csc.scm: 521  last */
((C_proc3)C_retrieve_symbol_proc(lf[216]))(3,*((C_word*)lf[216]+1),t2,t3);}
else{
t3=C_retrieve2(lf[60],"c-files");
/* csc.scm: 521  last */
((C_proc3)C_retrieve_symbol_proc(lf[216]))(3,*((C_word*)lf[216]+1),t2,t3);}}

/* k1574 in k1571 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1576,2,t0,t1);}
if(C_truep(C_retrieve2(lf[93],"target-filename"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_1478(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[99],"shared"))){
/* csc.scm: 525  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t2,t1,C_retrieve2(lf[49],"shared-library-extension"));}
else{
/* csc.scm: 526  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t2,t1,C_retrieve2(lf[45],"executable-extension"));}}}

/* k1581 in k1574 in k1571 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[93] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1478(2,t3,t2);}

/* k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[75],"deploy"))){
t3=C_retrieve2(lf[99],"shared");
t4=t2;
f_1481(t4,(C_truep(t3)?C_SCHEME_UNDEFINED:f_1440(C_a_i(&a,6))));}
else{
t3=t2;
f_1481(t3,C_SCHEME_UNDEFINED);}}

/* k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1481(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1481,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[96],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3183,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3337,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3337(t9,t5,C_retrieve2(lf[60],"c-files"));}}

/* loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3337(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3337,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3345,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3391,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g483484 */
t6=t3;
f_3345(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3389 in loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3337(t3,((C_word*)t0)[2],t2);}

/* g483 in loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3345(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3345,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3349,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 817  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t3,t2,C_retrieve2(lf[36],"object-extension"));}

/* k3347 in g483 in loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3352,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3364,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[66],"cpp-mode"))?C_retrieve2(lf[30],"c++-compiler"):C_retrieve2(lf[29],"compiler"));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3376,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5401,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t7,t6);}

/* f5401 in k3347 in g483 in loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3374 in k3347 in g483 in loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3388,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5396,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,t4);}

/* f5396 in k3374 in k3347 in g483 in loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3386 in k3374 in k3347 in g483 in loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 823  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),((C_word*)t0)[2],C_retrieve2(lf[48],"compile-output-flag"),t1);}

/* k3378 in k3374 in k3347 in g483 in loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 825  compiler-options */
f_3404(t2);}

/* k3382 in k3378 in k3374 in k3347 in g483 in loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[215],t1);
/* csc.scm: 819  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[105]))(3,*((C_word*)lf[105]+1),((C_word*)t0)[2],t2);}

/* k3362 in k3347 in g483 in loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 818  command */
f_4248(((C_word*)t0)[2],t1);}

/* k3350 in k3347 in g483 in loop476 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3352,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[65],"generated-object-files"));
t3=C_mutate(&lf[65] /* (set! generated-object-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3310,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[53],"generate-manifest"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3335,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 829  software-type */
((C_proc2)C_retrieve_symbol_proc(lf[214]))(2,*((C_word*)lf[214]+1),t4);}
else{
t4=t3;
f_3310(t4,C_SCHEME_FALSE);}}

/* k3333 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3310(t2,C_eqp(lf[213],t1));}

/* k3308 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3310(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3310,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 830  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[211]))(4,*((C_word*)lf[211]+1),t2,C_retrieve2(lf[93],"target-filename"),lf[212]);}
else{
t2=((C_word*)t0)[2];
f_3186(t2,C_SCHEME_UNDEFINED);}}

/* k3311 in k3308 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3328,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 831  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[178]))(3,*((C_word*)lf[178]+1),t3,C_retrieve2(lf[93],"target-filename"));}

/* k3326 in k3311 in k3308 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3328,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4388,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[94],"verbose"))){
/* csc.scm: 1071 print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[151]+1)))(4,*((C_word*)lf[151]+1),t3,lf[210],t2);}
else{
t4=t3;
f_4388(2,t4,C_SCHEME_UNDEFINED);}}

/* k4386 in k3326 in k3311 in k3308 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4393,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 1072 with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4392 in k4386 in k3326 in k3311 in k3308 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4401,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[208],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,lf[209],t4);
/* csc.scm: 1072 ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[168]))(3,*((C_word*)lf[168]+1),t2,t5);}

/* k4399 in a4392 in k4386 in k3326 in k3311 in k3308 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 1074 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[151]+1)))(3,*((C_word*)lf[151]+1),((C_word*)t0)[2],t1);}

/* k3314 in k3311 in k3308 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3316,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve2(lf[61],"rc-files"));
t3=C_mutate(&lf[61] /* (set! rc-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve2(lf[63],"generated-rc-files"));
t5=C_mutate(&lf[63] /* (set! generated-rc-files ...) */,t4);
t6=((C_word*)t0)[2];
f_3186(t6,t5);}

/* k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3186,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3254,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3254(t6,t2,C_retrieve2(lf[61],"rc-files"));}

/* loop506 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3254(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3254,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3262,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3296,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g513514 */
t6=t3;
f_3262(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3294 in loop506 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3254(t3,((C_word*)t0)[2],t2);}

/* g513 in loop506 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3262(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3262,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3266,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 836  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[127]+1)))(5,*((C_word*)lf[127]+1),t3,t2,lf[207],C_retrieve2(lf[36],"object-extension"));}

/* k3264 in g513 in loop506 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3281,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3289,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5389,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,t5);}

/* f5389 in k3264 in g513 in loop506 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3287 in k3264 in g513 in loop506 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3293,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5384,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,t3);}

/* f5384 in k3287 in k3264 in g513 in loop506 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3291 in k3287 in k3264 in g513 in loop506 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3293,2,t0,t1);}
t2=C_a_i_list(&a,3,C_retrieve2(lf[31],"rc-compiler"),((C_word*)t0)[3],t1);
/* csc.scm: 838  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[105]))(3,*((C_word*)lf[105]+1),((C_word*)t0)[2],t2);}

/* k3279 in k3264 in g513 in loop506 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 837  command */
f_4248(((C_word*)t0)[2],t1);}

/* k3267 in k3264 in g513 in loop506 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3269,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[65],"generated-object-files"));
t3=C_mutate(&lf[65] /* (set! generated-object-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3187 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3193,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3252,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 843  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[121]+1)))(3,*((C_word*)lf[121]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k3250 in k3187 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 843  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[64],"object-files"));}

/* k3191 in k3187 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3193,2,t0,t1);}
t2=C_mutate(&lf[64] /* (set! object-files ...) */,t1);
if(C_truep(C_retrieve2(lf[95],"keep-files"))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_1487(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3199,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3227,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3227(t7,t3,C_retrieve2(lf[62],"generated-c-files"));}}

/* loop525 in k3191 in k3187 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3227(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3227,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[152],"$delete-file");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3237,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g532533 */
t6=C_retrieve2(lf[152],"$delete-file");
f_4264(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3235 in loop525 in k3191 in k3187 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3227(t3,((C_word*)t0)[2],t2);}

/* k3197 in k3191 in k3187 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3199,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3204,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3204(t5,((C_word*)t0)[2],C_retrieve2(lf[63],"generated-rc-files"));}

/* loop538 in k3197 in k3191 in k3187 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3204(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3204,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[152],"$delete-file");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3214,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g545546 */
t6=C_retrieve2(lf[152],"$delete-file");
f_4264(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3212 in loop538 in k3197 in k3191 in k3187 in k3184 in k3181 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3204(t3,((C_word*)t0)[2],t2);}

/* k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1487,2,t0,t1);}
if(C_truep(C_retrieve2(lf[97],"compile-only"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_member(C_retrieve2(lf[93],"target-filename"),C_retrieve2(lf[59],"scheme-files")))){
t3=*((C_word*)lf[144]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1502,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t4,lf[206],t3);}
else{
t3=t2;
f_1493(2,t3,C_SCHEME_UNDEFINED);}}}

/* k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,C_retrieve2(lf[93],"target-filename"),((C_word*)t0)[2]);}

/* k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,lf[205],((C_word*)t0)[2]);}

/* k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,C_retrieve2(lf[93],"target-filename"),((C_word*)t0)[2]);}

/* k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,lf[204],((C_word*)t0)[2]);}

/* k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[116]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[119]))(2,*((C_word*)lf[119]+1),t2);}

/* k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1527,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[52],"windows-shell"))){
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,lf[202],t1);}
else{
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,lf[203],t1);}}

/* k1525 in k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[116]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k1528 in k1525 in k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1554,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[93],"target-filename");
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5375,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,t4);}

/* f5375 in k1528 in k1525 in k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k1552 in k1528 in k1525 in k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1531 in k1528 in k1525 in k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[116]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k1534 in k1531 in k1528 in k1525 in k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1550,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 549  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t4,C_retrieve2(lf[93],"target-filename"),lf[201]);}

/* k1548 in k1534 in k1531 in k1528 in k1525 in k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5370 in k1548 in k1534 in k1531 in k1528 in k1525 in k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k1544 in k1534 in k1531 in k1528 in k1525 in k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2]);}

/* k1540 in k1537 in k1534 in k1531 in k1528 in k1525 in k1522 in k1515 in k1512 in k1509 in k1506 in k1503 in k1500 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 544  command */
f_4248(((C_word*)t0)[2],t1);}

/* k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1493,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3464,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3732,a[2]=t7,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3771,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3773,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3779,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t9,t10,t11);}

/* a3778 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3779r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3779r(t0,t1,t2);}}

static void C_ccall f_3779r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_list_ref(t2,C_fix(0)));}

/* a3772 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3773,2,t0,t1);}
/* csc.scm: 862  static-extension-info */
f_3870(t1);}

/* k3769 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 861  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[64],"object-files"),t1);}

/* k3730 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3732,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3734(t5,((C_word*)t0)[2],t1);}

/* loop588 in k3730 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3734(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3734,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[24],"quotewrap");
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3763,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5363,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f5363 in loop588 in k3730 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3761 in loop588 in k3730 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3763,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop588601 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3734(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop588601 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3734(t6,((C_word*)t0)[3],t5);}}

/* k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3467,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[93],"target-filename");
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,t3);}

/* f5358 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3467,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3470,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[75],"deploy"))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3630,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 866  pathname-strip-extension */
((C_proc3)C_retrieve_symbol_proc(lf[200]))(3,*((C_word*)lf[200]+1),t7,C_retrieve2(lf[93],"target-filename"));}
else{
t7=t6;
f_3470(2,t7,C_SCHEME_UNDEFINED);}}

/* k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3630,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3633,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[74],"gui"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3680,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 868  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[110]))(5,*((C_word*)lf[110]+1),t5,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[4])[1],lf[199]);}
else{
t5=t3;
f_3633(2,t5,C_SCHEME_UNDEFINED);}}

/* k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3680,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3711,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[119]))(2,*((C_word*)lf[119]+1),t4);}

/* k3709 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3714,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,lf[198],t1);}

/* k3712 in k3709 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3728,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 869  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t4,((C_word*)((C_word*)t0)[2])[1],lf[197]);}

/* k3726 in k3712 in k3709 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5353 in k3726 in k3712 in k3709 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3722 in k3712 in k3709 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3715 in k3712 in k3709 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3720,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2]);}

/* k3718 in k3715 in k3712 in k3709 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 869  command */
f_4248(((C_word*)t0)[2],t1);}

/* k3681 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[119]))(2,*((C_word*)lf[119]+1),t2);}

/* k3688 in k3681 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3693,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,lf[196],t1);}

/* k3691 in k3688 in k3681 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3707,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 870  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t4,((C_word*)((C_word*)t0)[2])[1],lf[195]);}

/* k3705 in k3691 in k3688 in k3681 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5348 in k3705 in k3691 in k3688 in k3681 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3701 in k3691 in k3688 in k3681 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3694 in k3691 in k3688 in k3681 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3699,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2]);}

/* k3697 in k3694 in k3691 in k3688 in k3681 in k3678 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 870  command */
f_4248(((C_word*)t0)[2],t1);}

/* k3631 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3660,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[74],"gui"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 875  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[178]))(3,*((C_word*)lf[178]+1),t5,C_retrieve2(lf[93],"target-filename"));}
else{
/* csc.scm: 876  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[178]))(3,*((C_word*)lf[178]+1),t3,C_retrieve2(lf[93],"target-filename"));}}

/* k3668 in k3631 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 875  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),((C_word*)t0)[2],lf[194],t1);}

/* k3658 in k3631 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 872  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3635 in k3631 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3637,2,t0,t1);}
t2=C_mutate(&lf[93] /* (set! target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_retrieve2(lf[93],"target-filename");
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5343,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,t4);}

/* f5343 in k3635 in k3631 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3639 in k3635 in k3631 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3641,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 878  directory-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[193]))(3,*((C_word*)lf[193]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k3645 in k3639 in k3635 in k3631 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3647,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_3470(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[94],"verbose"))){
/* csc.scm: 880  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[151]+1)))(4,*((C_word*)lf[151]+1),t2,lf[192],((C_word*)((C_word*)t0)[2])[1]);}
else{
/* csc.scm: 881  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[191]))(3,*((C_word*)lf[191]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}}

/* k3648 in k3645 in k3639 in k3635 in k3631 in k3628 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 881  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[191]))(3,*((C_word*)lf[191]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3594,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3598,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[66],"cpp-mode"))?C_retrieve2(lf[33],"c++-linker"):C_retrieve2(lf[32],"linker"));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3606,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3614,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3626,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_retrieve2(lf[93],"target-filename");
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5338,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t10,t9);}

/* f5338 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3624 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 888  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),((C_word*)t0)[2],C_retrieve2(lf[42],"link-output-flag"),t1);}

/* k3612 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 889  linker-options */
f_3967(t2);}

/* k3616 in k3612 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 890  linker-libraries */
f_4019(t2,C_a_i_list(&a,1,C_SCHEME_FALSE));}

/* k3620 in k3616 in k3612 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3622,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],t1);
/* csc.scm: 886  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3604 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 884  cons* */
((C_proc4)C_retrieve_symbol_proc(lf[139]))(4,*((C_word*)lf[139]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3596 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 883  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[105]))(3,*((C_word*)lf[105]+1),((C_word*)t0)[2],t1);}

/* k3592 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 882  command */
f_4248(((C_word*)t0)[2],t1);}

/* k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3547,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=C_i_not(C_retrieve2(lf[23],"cross-chicken"));
if(C_truep(t4)){
t5=t3;
f_3547(t5,t4);}
else{
t5=C_retrieve2(lf[22],"host-mode");
t6=t3;
f_3547(t6,C_retrieve2(lf[22],"host-mode"));}}
else{
t4=t3;
f_3547(t4,C_SCHEME_FALSE);}}

/* k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3547,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3566,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3570,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=lf[189];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3574,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[76],"deployed"))){
/* csc.scm: 898  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t6,lf[190],t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3584,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 900  lib-path */
f_3785(t7);}}
else{
t2=((C_word*)t0)[2];
f_3476(2,t2,C_SCHEME_UNDEFINED);}}

/* k3582 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 899  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3572 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5333 in k3572 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3568 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 893  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[127]+1)))(6,*((C_word*)lf[127]+1),((C_word*)t0)[3],lf[187],t1,lf[188],((C_word*)((C_word*)t0)[2])[1]);}

/* k3564 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 892  command */
f_4248(((C_word*)t0)[2],t1);}

/* k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3550,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[74],"gui"))?C_i_not(C_retrieve2(lf[75],"deploy")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4287,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[119]))(2,*((C_word*)lf[119]+1),t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_3476(2,t4,t3);}}

/* k4285 in k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4290,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,lf[186],t1);}

/* k4288 in k4285 in k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4314,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5328,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,((C_word*)t0)[2]);}

/* f5328 in k4288 in k4285 in k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4312 in k4288 in k4285 in k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4291 in k4288 in k4285 in k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[116]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k4294 in k4291 in k4288 in k4285 in k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4310,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 1034 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t4,C_retrieve2(lf[27],"home"),lf[185]);}

/* k4308 in k4294 in k4291 in k4288 in k4285 in k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5323,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5323 in k4308 in k4294 in k4291 in k4288 in k4285 in k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4304 in k4294 in k4291 in k4288 in k4285 in k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4297 in k4294 in k4291 in k4288 in k4285 in k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4302,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2]);}

/* k4300 in k4297 in k4294 in k4291 in k4288 in k4285 in k3548 in k3545 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 1031 command */
f_4248(((C_word*)t0)[2],t1);}

/* k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3479,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3511,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[75],"deploy"))){
t4=C_retrieve2(lf[100],"static");
if(C_truep(t4)){
t5=t3;
f_3511(t5,C_i_not(t4));}
else{
t5=C_retrieve2(lf[101],"static-libs");
t6=t3;
f_3511(t6,C_i_not(t5));}}
else{
t4=t3;
f_3511(t4,C_SCHEME_FALSE);}}

/* k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3511(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3511,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3531,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=C_retrieve2(lf[74],"gui");
if(C_truep(t4)){
/* csc.scm: 909  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t3,((C_word*)((C_word*)t0)[3])[1],lf[184]);}
else{
t5=t3;
f_3531(2,t5,((C_word*)((C_word*)t0)[3])[1]);}}
else{
t4=t3;
f_3531(2,t4,((C_word*)((C_word*)t0)[3])[1]);}}
else{
t2=((C_word*)t0)[2];
f_3479(t2,C_SCHEME_UNDEFINED);}}

/* k3529 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3811,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3818,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 928  lib-path */
f_3785(t3);}

/* k3816 in k3529 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3822,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
/* csc.scm: 927  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[110]))(5,*((C_word*)lf[110]+1),((C_word*)t0)[2],t1,lf[179],lf[180]);}
else{
if(C_truep(C_retrieve2(lf[8],"win"))){
/* csc.scm: 927  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[110]))(5,*((C_word*)lf[110]+1),((C_word*)t0)[2],t1,lf[179],lf[181]);}
else{
/* csc.scm: 932  conc */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t2,lf[183],C_fix((C_word)C_BINARY_VERSION));}}}

/* k3820 in k3816 in k3529 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 927  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[110]))(5,*((C_word*)lf[110]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[179],t1);}

/* k3809 in k3529 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 933  copy-files */
f_3830(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3514,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[74],"gui"):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 913  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[178]))(3,*((C_word*)lf[178]+1),t3,C_retrieve2(lf[93],"target-filename"));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_3479(t4,t3);}}

/* k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3527,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[3])[1];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4320,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 1037 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t3,t2,lf[177]);}

/* k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 1038 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t2,((C_word*)t0)[2],lf[176]);}

/* k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 1039 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t2,((C_word*)t0)[2],lf[175]);}

/* k4324 in k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4329,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 1040 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t2,t1,lf[174]);}

/* k4327 in k4324 in k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4332,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4375,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 1041 file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),t3,t1);}

/* k4373 in k4327 in k4324 in k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4375,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_4332(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 1043 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t2,C_retrieve2(lf[27],"home"),lf[173]);}}

/* k4380 in k4373 in k4327 in k4324 in k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 1042 copy-files */
f_3830(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4330 in k4327 in k4324 in k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4335,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 1045 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t2,((C_word*)t0)[2],lf[172]);}

/* k4333 in k4330 in k4327 in k4324 in k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4338,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4341,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 1046 file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),t3,t1);}

/* k4339 in k4333 in k4330 in k4327 in k4324 in k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4341,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_3479(t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[94],"verbose"))){
/* csc.scm: 1047 print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[151]+1)))(4,*((C_word*)lf[151]+1),t2,lf[170],((C_word*)t0)[2]);}
else{
t3=t2;
f_4344(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4342 in k4339 in k4333 in k4330 in k4327 in k4324 in k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 1048 with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4348 in k4342 in k4339 in k4333 in k4330 in k4327 in k4324 in k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
t2=*((C_word*)lf[151]+1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4357,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,lf[166],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=C_a_i_cons(&a,2,lf[167],t5);
/* csc.scm: 1045 ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[168]))(3,*((C_word*)lf[168]+1),t3,t6);}

/* k4355 in a4348 in k4342 in k4339 in k4333 in k4330 in k4327 in k4324 in k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g878879 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4336 in k4333 in k4330 in k4327 in k4324 in k4321 in k4318 in k3525 in k3512 in k3509 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3479(t2,((C_word*)t0)[2]);}

/* k3477 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3479,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[95],"keep-files"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3487,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3487(t5,((C_word*)t0)[2],C_retrieve2(lf[65],"generated-object-files"));}}

/* loop688 in k3477 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3487(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3487,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[152],"$delete-file");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3497,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g695696 */
t6=C_retrieve2(lf[152],"$delete-file");
f_4264(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3495 in loop688 in k3477 in k3474 in k3471 in k3468 in k3465 in k3462 in k1491 in k1485 in k1479 in k1476 in k1473 in k1470 in k1466 in loop in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3487(t3,((C_word*)t0)[2],t2);}

/* use-private-repository in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static C_word C_fcall f_1440(C_word *a){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_check;
t1=C_a_i_cons(&a,2,lf[164],C_retrieve2(lf[87],"compile-options"));
t2=C_mutate(&lf[87] /* (set! compile-options ...) */,t1);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t3=C_a_i_cons(&a,2,lf[165],C_retrieve2(lf[92],"link-options"));
t4=C_mutate(&lf[92] /* (set! link-options ...) */,t3);
return(t4);}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* shared-build in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1414(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1414,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1419,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 491  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t3,lf[162],lf[163],C_retrieve2(lf[84],"translate-options"));}

/* k1417 in shared-build in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1419,2,t0,t1);}
t2=C_mutate(&lf[84] /* (set! translate-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 492  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[51],"pic-options"),lf[161],C_retrieve2(lf[87],"compile-options"));}

/* k1421 in k1417 in shared-build in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=C_mutate(&lf[87] /* (set! compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[7],"osx"))?(C_truep(((C_word*)t0)[3])?C_a_i_cons(&a,2,lf[157],C_retrieve2(lf[92],"link-options")):C_a_i_cons(&a,2,lf[158],C_retrieve2(lf[92],"link-options"))):(C_truep(C_retrieve2(lf[5],"msvc"))?C_a_i_cons(&a,2,lf[159],C_retrieve2(lf[92],"link-options")):C_a_i_cons(&a,2,lf[160],C_retrieve2(lf[92],"link-options"))));
t4=C_mutate(&lf[92] /* (set! link-options ...) */,t3);
t5=lf[99] /* shared */ =C_SCHEME_TRUE;;
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* check in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1375(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1375,NULL,4,t1,t2,t3,t4);}
t5=C_i_length(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1393,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
if(C_truep(C_i_greater_or_equalp(t5,C_fix(1)))){
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* csc.scm: 488  quit */
f_1072(t1,lf[156],C_a_i_list(&a,1,t2));}}
else{
t7=C_i_cdr(t4);
if(C_truep(C_i_nullp(t7))){
t8=t6;
f_1393(2,t8,C_i_car(t4));}
else{
/* ##sys#error */
t8=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k1391 in check in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1393,2,t0,t1);}
if(C_truep(C_i_greater_or_equalp(((C_word*)t0)[4],t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csc.scm: 488  quit */
f_1072(((C_word*)t0)[3],lf[156],C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* t-options in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1368(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1368,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 484  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_retrieve2(lf[84],"translate-options"),t2);}

/* k1371 in t-options in k4427 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[84] /* (set! translate-options ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4417 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4422,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4425,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[155]))(2,*((C_word*)lf[155]+1),t3);}

/* k4423 in k4417 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4420 in k4417 in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* $delete-file in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4264,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4268,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[94],"verbose"))){
/* csc.scm: 1026 print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[151]+1)))(4,*((C_word*)lf[151]+1),t3,lf[154],t2);}
else{
if(C_truep(C_retrieve2(lf[73],"dry-run"))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* csc.scm: 1027 delete-file */
((C_proc3)C_retrieve_symbol_proc(lf[153]))(3,*((C_word*)lf[153]+1),t1,t2);}}}

/* k4266 in $delete-file in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve2(lf[73],"dry-run"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csc.scm: 1027 delete-file */
((C_proc3)C_retrieve_symbol_proc(lf[153]))(3,*((C_word*)lf[153]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* command in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_4248(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4248,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4203,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[94],"verbose"))){
/* csc.scm: 1009 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[151]+1)))(3,*((C_word*)lf[151]+1),t3,t2);}
else{
t4=t3;
f_4203(2,t4,C_SCHEME_UNDEFINED);}}

/* k4201 in command in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4206,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[52],"windows-shell"))){
/* csc.scm: 1011 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[127]+1)))(5,*((C_word*)lf[127]+1),t2,lf[149],((C_word*)t0)[2],lf[150]);}
else{
t3=t2;
f_4206(2,t3,((C_word*)t0)[2]);}}

/* k4204 in k4201 in command in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4209,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[73],"dry-run"))){
t3=t2;
f_4209(2,t3,C_fix(0));}
else{
/* csc.scm: 1013 system */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),t2,t1);}}

/* k4207 in k4204 in k4201 in command in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4212,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_zerop(t1))){
t3=t2;
f_4212(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[144]+1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4225,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t4,lf[147],t3);}}

/* k4223 in k4207 in k4204 in k4201 in command in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[146]+1)))(4,*((C_word*)lf[146]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4226 in k4223 in k4207 in k4204 in k4201 in command in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,lf[145],((C_word*)t0)[3]);}

/* k4229 in k4226 in k4223 in k4207 in k4204 in k4201 in command in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4232 in k4229 in k4226 in k4223 in k4207 in k4204 in k4201 in command in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[116]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k4210 in k4207 in k4204 in k4201 in command in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(C_i_zerop(((C_word*)t0)[3]))){
t2=lf[143] /* last-exit-code */ =C_fix(0);;
t3=C_retrieve2(lf[143],"last-exit-code");
if(C_truep(C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* csc.scm: 1022 exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_retrieve2(lf[143],"last-exit-code"));}}
else{
t2=lf[143] /* last-exit-code */ =C_fix(1);;
t3=C_retrieve2(lf[143],"last-exit-code");
if(C_truep(C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* csc.scm: 1022 exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_retrieve2(lf[143],"last-exit-code"));}}}

/* quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4162,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4169,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4192,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 999  string-any */
((C_proc4)C_retrieve_symbol_proc(lf[141]))(4,*((C_word*)lf[141]+1),t3,t4,t2);}

/* a4191 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4192,3,t0,t1,t2);}
t3=*((C_word*)lf[142]+1);
/* g811812 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(34),t2);}

/* k4167 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4169,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4180,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 1000 string-any */
((C_proc4)C_retrieve_symbol_proc(lf[141]))(4,*((C_word*)lf[141]+1),t2,t3,((C_word*)t0)[3]);}}

/* a4179 in k4167 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4180,3,t0,t1,t2);}
t3=C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_i_memq(t2,lf[132])));}

/* k4173 in k4167 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4175,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4095,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4109,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4113,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_retrieve(lf[140]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k4111 in k4173 in k4167 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4113,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4115(t5,((C_word*)t0)[2],t1);}

/* fold in k4111 in k4173 in k4167 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_4115(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4115,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
if(C_truep(C_i_memq(t3,lf[132]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4138,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(t2);
/* csc.scm: 990  fold */
t9=t4;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4145,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_4145(t6,t5);}
else{
t5=t4;
f_4145(t5,C_SCHEME_UNDEFINED);}}}}

/* k4143 in fold in k4111 in k4173 in k4167 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_4145(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4145,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4152,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* csc.scm: 993  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4115(t4,t2,t3);}

/* k4150 in k4143 in fold in k4111 in k4173 in k4167 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4152,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4136 in fold in k4111 in k4173 in k4167 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 990  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),((C_word*)t0)[3],C_make_character(92),((C_word*)t0)[2],t1);}

/* k4107 in k4173 in k4167 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_retrieve(lf[138]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4093 in k4173 in k4167 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4105,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 995  string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t2,t1,lf[137]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4103 in k4093 in k4173 in k4167 in quote-option in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 995  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[127]+1)))(5,*((C_word*)lf[127]+1),((C_word*)t0)[2],lf[134],t1,lf[135]);}

/* linker-libraries in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_4019(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4019,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4023,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_4023(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_4023(2,t5,C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4021 in linker-libraries in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4034,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4059,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4065,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}
else{
t4=t3;
f_4034(2,t4,C_SCHEME_END_OF_LIST);}}

/* a4064 in k4021 in linker-libraries in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4065r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4065r(t0,t1,t2);}}

static void C_ccall f_4065r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_list_ref(t2,C_fix(0)));}

/* a4058 in k4021 in linker-libraries in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
/* csc.scm: 970  static-extension-info */
f_3870(t1);}

/* k4032 in k4021 in linker-libraries in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4038,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[100],"static");
if(C_truep(t3)){
t4=t2;
f_4038(t4,(C_truep(t3)?C_retrieve2(lf[82],"library-files"):C_retrieve2(lf[83],"shared-library-files")));}
else{
t4=C_retrieve2(lf[101],"static-libs");
t5=t2;
f_4038(t5,(C_truep(t4)?C_retrieve2(lf[82],"library-files"):C_retrieve2(lf[83],"shared-library-files")));}}

/* k4036 in k4032 in k4021 in linker-libraries in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_4038(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4038,NULL,2,t0,t1);}
t2=C_retrieve2(lf[100],"static");
if(C_truep(t2)){
t3=(C_truep(t2)?C_a_i_list(&a,1,C_retrieve2(lf[78],"extra-libraries")):C_a_i_list(&a,1,C_retrieve2(lf[79],"extra-shared-libraries")));
/* csc.scm: 969  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,t3);}
else{
t3=C_retrieve2(lf[101],"static-libs");
t4=(C_truep(t3)?C_a_i_list(&a,1,C_retrieve2(lf[78],"extra-libraries")):C_a_i_list(&a,1,C_retrieve2(lf[79],"extra-shared-libraries")));
/* csc.scm: 969  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,t4);}}

/* k4028 in k4021 in linker-libraries in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 968  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[105]))(3,*((C_word*)lf[105]+1),((C_word*)t0)[2],t1);}

/* linker-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3967(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3967,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3975,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4001,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4005,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4007,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4013,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a4012 in linker-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4013r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4013r(t0,t1,t2);}}

static void C_ccall f_4013r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_list_ref(t2,C_fix(1)));}

/* a4006 in linker-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
/* csc.scm: 964  static-extension-info */
f_3870(t1);}

/* k4003 in linker-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 963  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),((C_word*)t0)[2],C_retrieve2(lf[90],"linking-optimization-options"),C_retrieve2(lf[92],"link-options"),t1);}

/* k3999 in linker-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 962  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[105]))(3,*((C_word*)lf[105]+1),((C_word*)t0)[2],t1);}

/* k3973 in linker-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3982,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[100],"static"))){
t3=C_retrieve2(lf[3],"mingw");
if(C_truep(C_retrieve2(lf[3],"mingw"))){
t4=t2;
f_3982(t4,C_SCHEME_FALSE);}
else{
t4=C_retrieve2(lf[5],"msvc");
t5=t2;
f_3982(t5,(C_truep(C_retrieve2(lf[5],"msvc"))?C_SCHEME_FALSE:C_i_not(C_retrieve2(lf[7],"osx"))));}}
else{
t3=t2;
f_3982(t3,C_SCHEME_FALSE);}}

/* k3980 in k3973 in linker-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 961  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[128]);}
else{
/* csc.scm: 961  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[129]);}}

/* static-extension-info in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3870(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3870,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3874,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 945  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[125]))(2,*((C_word*)lf[125]+1),t2);}

/* k3872 in static-extension-info in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
t2=(C_truep(t1)?C_i_pairp(C_retrieve2(lf[102],"static-extensions")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3885,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3885(t6,((C_word*)t0)[2],C_retrieve2(lf[102],"static-extensions"),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* csc.scm: 958  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* loop in k3872 in static-extension-info in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3885(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3885,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3899,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 949  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[121]+1)))(3,*((C_word*)lf[121]+1),t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=C_i_car(t2);
/* csc.scm: 950  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[124]))(3,*((C_word*)lf[124]+1),t5,t6);}}

/* k3904 in loop in k3872 in static-extension-info in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(lf[122],t1);
t3=C_i_assq(lf[123],t1);
t4=C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3926,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(t2);
/* csc.scm: 955  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t6,((C_word*)t0)[2],t7);}
else{
t6=t5;
f_3926(t6,((C_word*)t0)[3]);}}
else{
t2=C_i_cdr(((C_word*)t0)[7]);
/* csc.scm: 957  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3885(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[6]);}}

/* k3942 in k3904 in loop in k3872 in static-extension-info in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3944,2,t0,t1);}
t2=((C_word*)t0)[3];
f_3926(t2,C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k3924 in k3904 in loop in k3872 in static-extension-info in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3926,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=C_i_cadr(((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
/* csc.scm: 954  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3885(t4,((C_word*)t0)[3],((C_word*)t0)[2],t1,t3);}
else{
t2=((C_word*)t0)[5];
/* csc.scm: 954  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3885(t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}}

/* k3897 in loop in k3872 in static-extension-info in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3903,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 949  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[121]+1)))(3,*((C_word*)lf[121]+1),t2,((C_word*)t0)[2]);}

/* k3901 in k3897 in loop in k3872 in static-extension-info in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 949  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3830(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3830,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3838,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[119]))(2,*((C_word*)lf[119]+1),t4);}

/* k3836 in copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[52],"windows-shell"))){
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,lf[117],t1);}
else{
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,lf[118],t1);}}

/* k3839 in k3836 in copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[116]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k3842 in k3839 in k3836 in copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3864,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5304,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,t4);}

/* f5304 in k3842 in k3839 in k3836 in copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3862 in k3842 in k3839 in k3836 in copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3845 in k3842 in k3839 in k3836 in copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[116]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k3848 in k3845 in k3842 in k3839 in k3836 in copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3860,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5299,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,t4);}

/* f5299 in k3848 in k3845 in k3842 in k3839 in k3836 in copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3858 in k3848 in k3845 in k3842 in k3839 in k3836 in copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3851 in k3848 in k3845 in k3842 in k3839 in k3836 in copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3856,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2]);}

/* k3854 in k3851 in k3848 in k3845 in k3842 in k3839 in k3836 in copy-files in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 936  command */
f_4248(((C_word*)t0)[2],t1);}

/* lib-path in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3785(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3785,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3793,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[8],"win"))){
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}}

/* k3791 in lib-path in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3793,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t3=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[109]);
/* csc.scm: 85   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t2,t3,lf[111]);}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* compiler-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3404(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3404,NULL,1,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3412,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3416,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=C_retrieve2(lf[100],"static");
t9=(C_truep(t8)?t8:C_retrieve2(lf[101],"static-libs"));
if(C_truep(t9)){
/* csc.scm: 851  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),t7,C_SCHEME_END_OF_LIST,C_retrieve2(lf[89],"compilation-optimization-options"),C_retrieve2(lf[87],"compile-options"));}
else{
/* csc.scm: 851  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[107]+1)))(5,*((C_word*)lf[107]+1),t7,C_SCHEME_END_OF_LIST,C_retrieve2(lf[89],"compilation-optimization-options"),C_retrieve2(lf[87],"compile-options"));}}

/* k3414 in compiler-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3416,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3418(t5,((C_word*)t0)[2],t1);}

/* loop557 in k3414 in compiler-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_3418(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3418,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[106],"quote-option");
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3447,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g573574 */
t6=C_retrieve2(lf[106],"quote-option");
f_4162(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3445 in loop557 in k3414 in compiler-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3447,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop557570 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3418(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop557570 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3418(t6,((C_word*)t0)[3],t5);}}

/* k3410 in compiler-options in k1261 in k1253 in k1245 in k1238 in k4483 in k1230 in k1226 in k1194 in k1189 in k1185 in k1179 in k1152 in k1148 in k1144 in k1140 in k1136 in k1132 in k1128 in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 849  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[105]))(3,*((C_word*)lf[105]+1),((C_word*)t0)[2],t1);}

/* quotewrap in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1118,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1126,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 89   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t3,t2);}

/* k1124 in quotewrap in k1093 in k1089 in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 89   qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* quit in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_fcall f_1072(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1072,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1076,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1083,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 75   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[18]))(2,*((C_word*)lf[18]+1),t5);}

/* k1081 in quit in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k1085 in k1081 in quit in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 75   fprintf */
((C_proc7)C_retrieve_symbol_proc(lf[15]))(7,*((C_word*)lf[15]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[16],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1074 in quit in k4634 in k4638 in k4642 in k4646 in k4650 in k1044 in k1041 in k1038 in k1035 in k1032 in k1029 in k1026 in k1023 in k1020 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 76   exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[445] = {
{"toplevel:csc_scm",(void*)C_toplevel},
{"f_1022:csc_scm",(void*)f_1022},
{"f_1025:csc_scm",(void*)f_1025},
{"f_1028:csc_scm",(void*)f_1028},
{"f_1031:csc_scm",(void*)f_1031},
{"f_1034:csc_scm",(void*)f_1034},
{"f_1037:csc_scm",(void*)f_1037},
{"f_1040:csc_scm",(void*)f_1040},
{"f_1043:csc_scm",(void*)f_1043},
{"f_1046:csc_scm",(void*)f_1046},
{"f_4652:csc_scm",(void*)f_4652},
{"f_4648:csc_scm",(void*)f_4648},
{"f_4644:csc_scm",(void*)f_4644},
{"f_4640:csc_scm",(void*)f_4640},
{"f_4636:csc_scm",(void*)f_4636},
{"f_1091:csc_scm",(void*)f_1091},
{"f_1095:csc_scm",(void*)f_1095},
{"f_4626:csc_scm",(void*)f_4626},
{"f5830:csc_scm",(void*)f5830},
{"f_4622:csc_scm",(void*)f_4622},
{"f5483:csc_scm",(void*)f5483},
{"f_1130:csc_scm",(void*)f_1130},
{"f_4614:csc_scm",(void*)f_4614},
{"f_4618:csc_scm",(void*)f_4618},
{"f_4610:csc_scm",(void*)f_4610},
{"f5826:csc_scm",(void*)f5826},
{"f_4606:csc_scm",(void*)f_4606},
{"f5478:csc_scm",(void*)f5478},
{"f_1134:csc_scm",(void*)f_1134},
{"f_4596:csc_scm",(void*)f_4596},
{"f5473:csc_scm",(void*)f5473},
{"f_1138:csc_scm",(void*)f_1138},
{"f_4586:csc_scm",(void*)f_4586},
{"f5468:csc_scm",(void*)f5468},
{"f_1142:csc_scm",(void*)f_1142},
{"f_4576:csc_scm",(void*)f_4576},
{"f5463:csc_scm",(void*)f5463},
{"f_1146:csc_scm",(void*)f_1146},
{"f5458:csc_scm",(void*)f5458},
{"f_4563:csc_scm",(void*)f_4563},
{"f5453:csc_scm",(void*)f5453},
{"f_1150:csc_scm",(void*)f_1150},
{"f5448:csc_scm",(void*)f5448},
{"f_4550:csc_scm",(void*)f_4550},
{"f5443:csc_scm",(void*)f5443},
{"f_1154:csc_scm",(void*)f_1154},
{"f_1181:csc_scm",(void*)f_1181},
{"f_1187:csc_scm",(void*)f_1187},
{"f_4533:csc_scm",(void*)f_4533},
{"f_1191:csc_scm",(void*)f_1191},
{"f_4523:csc_scm",(void*)f_4523},
{"f_1196:csc_scm",(void*)f_1196},
{"f_1228:csc_scm",(void*)f_1228},
{"f_1232:csc_scm",(void*)f_1232},
{"f_4497:csc_scm",(void*)f_4497},
{"f_4501:csc_scm",(void*)f_4501},
{"f_4493:csc_scm",(void*)f_4493},
{"f5822:csc_scm",(void*)f5822},
{"f_4489:csc_scm",(void*)f_4489},
{"f5438:csc_scm",(void*)f5438},
{"f_4485:csc_scm",(void*)f_4485},
{"f_4481:csc_scm",(void*)f_4481},
{"f_1240:csc_scm",(void*)f_1240},
{"f_4468:csc_scm",(void*)f_4468},
{"f_1247:csc_scm",(void*)f_1247},
{"f_4457:csc_scm",(void*)f_4457},
{"f_1255:csc_scm",(void*)f_1255},
{"f_4444:csc_scm",(void*)f_4444},
{"f_1263:csc_scm",(void*)f_1263},
{"f_4437:csc_scm",(void*)f_4437},
{"f_4433:csc_scm",(void*)f_4433},
{"f_4429:csc_scm",(void*)f_4429},
{"f_1457:csc_scm",(void*)f_1457},
{"f_1694:csc_scm",(void*)f_1694},
{"f_2066:csc_scm",(void*)f_2066},
{"f_2273:csc_scm",(void*)f_2273},
{"f_2509:csc_scm",(void*)f_2509},
{"f_2512:csc_scm",(void*)f_2512},
{"f_2947:csc_scm",(void*)f_2947},
{"f_2568:csc_scm",(void*)f_2568},
{"f_2577:csc_scm",(void*)f_2577},
{"f_2788:csc_scm",(void*)f_2788},
{"f_2910:csc_scm",(void*)f_2910},
{"f_2916:csc_scm",(void*)f_2916},
{"f_2799:csc_scm",(void*)f_2799},
{"f_2810:csc_scm",(void*)f_2810},
{"f_2900:csc_scm",(void*)f_2900},
{"f_2892:csc_scm",(void*)f_2892},
{"f_2875:csc_scm",(void*)f_2875},
{"f_2851:csc_scm",(void*)f_2851},
{"f_2856:csc_scm",(void*)f_2856},
{"f_2838:csc_scm",(void*)f_2838},
{"f_2824:csc_scm",(void*)f_2824},
{"f_2793:csc_scm",(void*)f_2793},
{"f_2758:csc_scm",(void*)f_2758},
{"f_2655:csc_scm",(void*)f_2655},
{"f_2741:csc_scm",(void*)f_2741},
{"f_2737:csc_scm",(void*)f_2737},
{"f_2688:csc_scm",(void*)f_2688},
{"f_2726:csc_scm",(void*)f_2726},
{"f_2686:csc_scm",(void*)f_2686},
{"f_2682:csc_scm",(void*)f_2682},
{"f_2659:csc_scm",(void*)f_2659},
{"f_2645:csc_scm",(void*)f_2645},
{"f_2632:csc_scm",(void*)f_2632},
{"f_2615:csc_scm",(void*)f_2615},
{"f_2601:csc_scm",(void*)f_2601},
{"f_2587:csc_scm",(void*)f_2587},
{"f_2549:csc_scm",(void*)f_2549},
{"f_2555:csc_scm",(void*)f_2555},
{"f_2558:csc_scm",(void*)f_2558},
{"f_2519:csc_scm",(void*)f_2519},
{"f_2502:csc_scm",(void*)f_2502},
{"f_2506:csc_scm",(void*)f_2506},
{"f_2450:csc_scm",(void*)f_2450},
{"f_2486:csc_scm",(void*)f_2486},
{"f_2476:csc_scm",(void*)f_2476},
{"f_2464:csc_scm",(void*)f_2464},
{"f_2425:csc_scm",(void*)f_2425},
{"f_2437:csc_scm",(void*)f_2437},
{"f_2429:csc_scm",(void*)f_2429},
{"f_2412:csc_scm",(void*)f_2412},
{"f_2386:csc_scm",(void*)f_2386},
{"f_2398:csc_scm",(void*)f_2398},
{"f_2390:csc_scm",(void*)f_2390},
{"f_2365:csc_scm",(void*)f_2365},
{"f_2369:csc_scm",(void*)f_2369},
{"f_2348:csc_scm",(void*)f_2348},
{"f_2331:csc_scm",(void*)f_2331},
{"f_2314:csc_scm",(void*)f_2314},
{"f_2297:csc_scm",(void*)f_2297},
{"f_2256:csc_scm",(void*)f_2256},
{"f_2246:csc_scm",(void*)f_2246},
{"f_2236:csc_scm",(void*)f_2236},
{"f_2212:csc_scm",(void*)f_2212},
{"f_2226:csc_scm",(void*)f_2226},
{"f_2222:csc_scm",(void*)f_2222},
{"f_2202:csc_scm",(void*)f_2202},
{"f_2192:csc_scm",(void*)f_2192},
{"f_2182:csc_scm",(void*)f_2182},
{"f_2172:csc_scm",(void*)f_2172},
{"f_2151:csc_scm",(void*)f_2151},
{"f_2127:csc_scm",(void*)f_2127},
{"f_2138:csc_scm",(void*)f_2138},
{"f_2103:csc_scm",(void*)f_2103},
{"f_2099:csc_scm",(void*)f_2099},
{"f_2095:csc_scm",(void*)f_2095},
{"f_2088:csc_scm",(void*)f_2088},
{"f_2018:csc_scm",(void*)f_2018},
{"f_2022:csc_scm",(void*)f_2022},
{"f_2025:csc_scm",(void*)f_2025},
{"f_1986:csc_scm",(void*)f_1986},
{"f_1990:csc_scm",(void*)f_1990},
{"f_1993:csc_scm",(void*)f_1993},
{"f_1883:csc_scm",(void*)f_1883},
{"f_1868:csc_scm",(void*)f_1868},
{"f_1874:csc_scm",(void*)f_1874},
{"f_1848:csc_scm",(void*)f_1848},
{"f_1836:csc_scm",(void*)f_1836},
{"f_1824:csc_scm",(void*)f_1824},
{"f_1812:csc_scm",(void*)f_1812},
{"f_1786:csc_scm",(void*)f_1786},
{"f_1775:csc_scm",(void*)f_1775},
{"f_1744:csc_scm",(void*)f_1744},
{"f_1737:csc_scm",(void*)f_1737},
{"f_1728:csc_scm",(void*)f_1728},
{"f_1721:csc_scm",(void*)f_1721},
{"f_1328:csc_scm",(void*)f_1328},
{"f_1335:csc_scm",(void*)f_1335},
{"f_1709:csc_scm",(void*)f_1709},
{"f_1697:csc_scm",(void*)f_1697},
{"f_1468:csc_scm",(void*)f_1468},
{"f_1311:csc_scm",(void*)f_1311},
{"f_1277:csc_scm",(void*)f_1277},
{"f_1295:csc_scm",(void*)f_1295},
{"f_1285:csc_scm",(void*)f_1285},
{"f_1281:csc_scm",(void*)f_1281},
{"f_1472:csc_scm",(void*)f_1472},
{"f_1681:csc_scm",(void*)f_1681},
{"f_1648:csc_scm",(void*)f_1648},
{"f_1674:csc_scm",(void*)f_1674},
{"f_1651:csc_scm",(void*)f_1651},
{"f5429:csc_scm",(void*)f5429},
{"f_1667:csc_scm",(void*)f_1667},
{"f_1654:csc_scm",(void*)f_1654},
{"f_1657:csc_scm",(void*)f_1657},
{"f_1475:csc_scm",(void*)f_1475},
{"f_1611:csc_scm",(void*)f_1611},
{"f_1621:csc_scm",(void*)f_1621},
{"f_1614:csc_scm",(void*)f_1614},
{"f_3040:csc_scm",(void*)f_3040},
{"f_3052:csc_scm",(void*)f_3052},
{"f5423:csc_scm",(void*)f5423},
{"f_3083:csc_scm",(void*)f_3083},
{"f5418:csc_scm",(void*)f5418},
{"f_3145:csc_scm",(void*)f_3145},
{"f_3091:csc_scm",(void*)f_3091},
{"f_3099:csc_scm",(void*)f_3099},
{"f_3101:csc_scm",(void*)f_3101},
{"f_3130:csc_scm",(void*)f_3130},
{"f_3095:csc_scm",(void*)f_3095},
{"f_3087:csc_scm",(void*)f_3087},
{"f_3079:csc_scm",(void*)f_3079},
{"f_3075:csc_scm",(void*)f_3075},
{"f_3055:csc_scm",(void*)f_3055},
{"f_3059:csc_scm",(void*)f_3059},
{"f_3063:csc_scm",(void*)f_3063},
{"f_3009:csc_scm",(void*)f_3009},
{"f_3017:csc_scm",(void*)f_3017},
{"f_3027:csc_scm",(void*)f_3027},
{"f_1573:csc_scm",(void*)f_1573},
{"f_1576:csc_scm",(void*)f_1576},
{"f_1583:csc_scm",(void*)f_1583},
{"f_1478:csc_scm",(void*)f_1478},
{"f_1481:csc_scm",(void*)f_1481},
{"f_3337:csc_scm",(void*)f_3337},
{"f_3391:csc_scm",(void*)f_3391},
{"f_3345:csc_scm",(void*)f_3345},
{"f_3349:csc_scm",(void*)f_3349},
{"f5401:csc_scm",(void*)f5401},
{"f_3376:csc_scm",(void*)f_3376},
{"f5396:csc_scm",(void*)f5396},
{"f_3388:csc_scm",(void*)f_3388},
{"f_3380:csc_scm",(void*)f_3380},
{"f_3384:csc_scm",(void*)f_3384},
{"f_3364:csc_scm",(void*)f_3364},
{"f_3352:csc_scm",(void*)f_3352},
{"f_3183:csc_scm",(void*)f_3183},
{"f_3335:csc_scm",(void*)f_3335},
{"f_3310:csc_scm",(void*)f_3310},
{"f_3313:csc_scm",(void*)f_3313},
{"f_3328:csc_scm",(void*)f_3328},
{"f_4388:csc_scm",(void*)f_4388},
{"f_4393:csc_scm",(void*)f_4393},
{"f_4401:csc_scm",(void*)f_4401},
{"f_3316:csc_scm",(void*)f_3316},
{"f_3186:csc_scm",(void*)f_3186},
{"f_3254:csc_scm",(void*)f_3254},
{"f_3296:csc_scm",(void*)f_3296},
{"f_3262:csc_scm",(void*)f_3262},
{"f_3266:csc_scm",(void*)f_3266},
{"f5389:csc_scm",(void*)f5389},
{"f_3289:csc_scm",(void*)f_3289},
{"f5384:csc_scm",(void*)f5384},
{"f_3293:csc_scm",(void*)f_3293},
{"f_3281:csc_scm",(void*)f_3281},
{"f_3269:csc_scm",(void*)f_3269},
{"f_3189:csc_scm",(void*)f_3189},
{"f_3252:csc_scm",(void*)f_3252},
{"f_3193:csc_scm",(void*)f_3193},
{"f_3227:csc_scm",(void*)f_3227},
{"f_3237:csc_scm",(void*)f_3237},
{"f_3199:csc_scm",(void*)f_3199},
{"f_3204:csc_scm",(void*)f_3204},
{"f_3214:csc_scm",(void*)f_3214},
{"f_1487:csc_scm",(void*)f_1487},
{"f_1502:csc_scm",(void*)f_1502},
{"f_1505:csc_scm",(void*)f_1505},
{"f_1508:csc_scm",(void*)f_1508},
{"f_1511:csc_scm",(void*)f_1511},
{"f_1514:csc_scm",(void*)f_1514},
{"f_1517:csc_scm",(void*)f_1517},
{"f_1524:csc_scm",(void*)f_1524},
{"f_1527:csc_scm",(void*)f_1527},
{"f_1530:csc_scm",(void*)f_1530},
{"f5375:csc_scm",(void*)f5375},
{"f_1554:csc_scm",(void*)f_1554},
{"f_1533:csc_scm",(void*)f_1533},
{"f_1536:csc_scm",(void*)f_1536},
{"f_1550:csc_scm",(void*)f_1550},
{"f5370:csc_scm",(void*)f5370},
{"f_1546:csc_scm",(void*)f_1546},
{"f_1539:csc_scm",(void*)f_1539},
{"f_1542:csc_scm",(void*)f_1542},
{"f_1493:csc_scm",(void*)f_1493},
{"f_3779:csc_scm",(void*)f_3779},
{"f_3773:csc_scm",(void*)f_3773},
{"f_3771:csc_scm",(void*)f_3771},
{"f_3732:csc_scm",(void*)f_3732},
{"f_3734:csc_scm",(void*)f_3734},
{"f5363:csc_scm",(void*)f5363},
{"f_3763:csc_scm",(void*)f_3763},
{"f_3464:csc_scm",(void*)f_3464},
{"f5358:csc_scm",(void*)f5358},
{"f_3467:csc_scm",(void*)f_3467},
{"f_3630:csc_scm",(void*)f_3630},
{"f_3680:csc_scm",(void*)f_3680},
{"f_3711:csc_scm",(void*)f_3711},
{"f_3714:csc_scm",(void*)f_3714},
{"f_3728:csc_scm",(void*)f_3728},
{"f5353:csc_scm",(void*)f5353},
{"f_3724:csc_scm",(void*)f_3724},
{"f_3717:csc_scm",(void*)f_3717},
{"f_3720:csc_scm",(void*)f_3720},
{"f_3683:csc_scm",(void*)f_3683},
{"f_3690:csc_scm",(void*)f_3690},
{"f_3693:csc_scm",(void*)f_3693},
{"f_3707:csc_scm",(void*)f_3707},
{"f5348:csc_scm",(void*)f5348},
{"f_3703:csc_scm",(void*)f_3703},
{"f_3696:csc_scm",(void*)f_3696},
{"f_3699:csc_scm",(void*)f_3699},
{"f_3633:csc_scm",(void*)f_3633},
{"f_3670:csc_scm",(void*)f_3670},
{"f_3660:csc_scm",(void*)f_3660},
{"f_3637:csc_scm",(void*)f_3637},
{"f5343:csc_scm",(void*)f5343},
{"f_3641:csc_scm",(void*)f_3641},
{"f_3647:csc_scm",(void*)f_3647},
{"f_3650:csc_scm",(void*)f_3650},
{"f_3470:csc_scm",(void*)f_3470},
{"f5338:csc_scm",(void*)f5338},
{"f_3626:csc_scm",(void*)f_3626},
{"f_3614:csc_scm",(void*)f_3614},
{"f_3618:csc_scm",(void*)f_3618},
{"f_3622:csc_scm",(void*)f_3622},
{"f_3606:csc_scm",(void*)f_3606},
{"f_3598:csc_scm",(void*)f_3598},
{"f_3594:csc_scm",(void*)f_3594},
{"f_3473:csc_scm",(void*)f_3473},
{"f_3547:csc_scm",(void*)f_3547},
{"f_3584:csc_scm",(void*)f_3584},
{"f_3574:csc_scm",(void*)f_3574},
{"f5333:csc_scm",(void*)f5333},
{"f_3570:csc_scm",(void*)f_3570},
{"f_3566:csc_scm",(void*)f_3566},
{"f_3550:csc_scm",(void*)f_3550},
{"f_4287:csc_scm",(void*)f_4287},
{"f_4290:csc_scm",(void*)f_4290},
{"f5328:csc_scm",(void*)f5328},
{"f_4314:csc_scm",(void*)f_4314},
{"f_4293:csc_scm",(void*)f_4293},
{"f_4296:csc_scm",(void*)f_4296},
{"f_4310:csc_scm",(void*)f_4310},
{"f5323:csc_scm",(void*)f5323},
{"f_4306:csc_scm",(void*)f_4306},
{"f_4299:csc_scm",(void*)f_4299},
{"f_4302:csc_scm",(void*)f_4302},
{"f_3476:csc_scm",(void*)f_3476},
{"f_3511:csc_scm",(void*)f_3511},
{"f_3531:csc_scm",(void*)f_3531},
{"f_3818:csc_scm",(void*)f_3818},
{"f_3822:csc_scm",(void*)f_3822},
{"f_3811:csc_scm",(void*)f_3811},
{"f_3514:csc_scm",(void*)f_3514},
{"f_3527:csc_scm",(void*)f_3527},
{"f_4320:csc_scm",(void*)f_4320},
{"f_4323:csc_scm",(void*)f_4323},
{"f_4326:csc_scm",(void*)f_4326},
{"f_4329:csc_scm",(void*)f_4329},
{"f_4375:csc_scm",(void*)f_4375},
{"f_4382:csc_scm",(void*)f_4382},
{"f_4332:csc_scm",(void*)f_4332},
{"f_4335:csc_scm",(void*)f_4335},
{"f_4341:csc_scm",(void*)f_4341},
{"f_4344:csc_scm",(void*)f_4344},
{"f_4349:csc_scm",(void*)f_4349},
{"f_4357:csc_scm",(void*)f_4357},
{"f_4338:csc_scm",(void*)f_4338},
{"f_3479:csc_scm",(void*)f_3479},
{"f_3487:csc_scm",(void*)f_3487},
{"f_3497:csc_scm",(void*)f_3497},
{"f_1440:csc_scm",(void*)f_1440},
{"f_1414:csc_scm",(void*)f_1414},
{"f_1419:csc_scm",(void*)f_1419},
{"f_1423:csc_scm",(void*)f_1423},
{"f_1375:csc_scm",(void*)f_1375},
{"f_1393:csc_scm",(void*)f_1393},
{"f_1368:csc_scm",(void*)f_1368},
{"f_1373:csc_scm",(void*)f_1373},
{"f_4419:csc_scm",(void*)f_4419},
{"f_4425:csc_scm",(void*)f_4425},
{"f_4422:csc_scm",(void*)f_4422},
{"f_4264:csc_scm",(void*)f_4264},
{"f_4268:csc_scm",(void*)f_4268},
{"f_4248:csc_scm",(void*)f_4248},
{"f_4203:csc_scm",(void*)f_4203},
{"f_4206:csc_scm",(void*)f_4206},
{"f_4209:csc_scm",(void*)f_4209},
{"f_4225:csc_scm",(void*)f_4225},
{"f_4228:csc_scm",(void*)f_4228},
{"f_4231:csc_scm",(void*)f_4231},
{"f_4234:csc_scm",(void*)f_4234},
{"f_4212:csc_scm",(void*)f_4212},
{"f_4162:csc_scm",(void*)f_4162},
{"f_4192:csc_scm",(void*)f_4192},
{"f_4169:csc_scm",(void*)f_4169},
{"f_4180:csc_scm",(void*)f_4180},
{"f_4175:csc_scm",(void*)f_4175},
{"f_4113:csc_scm",(void*)f_4113},
{"f_4115:csc_scm",(void*)f_4115},
{"f_4145:csc_scm",(void*)f_4145},
{"f_4152:csc_scm",(void*)f_4152},
{"f_4138:csc_scm",(void*)f_4138},
{"f_4109:csc_scm",(void*)f_4109},
{"f_4095:csc_scm",(void*)f_4095},
{"f_4105:csc_scm",(void*)f_4105},
{"f_4019:csc_scm",(void*)f_4019},
{"f_4023:csc_scm",(void*)f_4023},
{"f_4065:csc_scm",(void*)f_4065},
{"f_4059:csc_scm",(void*)f_4059},
{"f_4034:csc_scm",(void*)f_4034},
{"f_4038:csc_scm",(void*)f_4038},
{"f_4030:csc_scm",(void*)f_4030},
{"f_3967:csc_scm",(void*)f_3967},
{"f_4013:csc_scm",(void*)f_4013},
{"f_4007:csc_scm",(void*)f_4007},
{"f_4005:csc_scm",(void*)f_4005},
{"f_4001:csc_scm",(void*)f_4001},
{"f_3975:csc_scm",(void*)f_3975},
{"f_3982:csc_scm",(void*)f_3982},
{"f_3870:csc_scm",(void*)f_3870},
{"f_3874:csc_scm",(void*)f_3874},
{"f_3885:csc_scm",(void*)f_3885},
{"f_3906:csc_scm",(void*)f_3906},
{"f_3944:csc_scm",(void*)f_3944},
{"f_3926:csc_scm",(void*)f_3926},
{"f_3899:csc_scm",(void*)f_3899},
{"f_3903:csc_scm",(void*)f_3903},
{"f_3830:csc_scm",(void*)f_3830},
{"f_3838:csc_scm",(void*)f_3838},
{"f_3841:csc_scm",(void*)f_3841},
{"f_3844:csc_scm",(void*)f_3844},
{"f5304:csc_scm",(void*)f5304},
{"f_3864:csc_scm",(void*)f_3864},
{"f_3847:csc_scm",(void*)f_3847},
{"f_3850:csc_scm",(void*)f_3850},
{"f5299:csc_scm",(void*)f5299},
{"f_3860:csc_scm",(void*)f_3860},
{"f_3853:csc_scm",(void*)f_3853},
{"f_3856:csc_scm",(void*)f_3856},
{"f_3785:csc_scm",(void*)f_3785},
{"f_3793:csc_scm",(void*)f_3793},
{"f_3404:csc_scm",(void*)f_3404},
{"f_3416:csc_scm",(void*)f_3416},
{"f_3418:csc_scm",(void*)f_3418},
{"f_3447:csc_scm",(void*)f_3447},
{"f_3412:csc_scm",(void*)f_3412},
{"f_1118:csc_scm",(void*)f_1118},
{"f_1126:csc_scm",(void*)f_1126},
{"f_1072:csc_scm",(void*)f_1072},
{"f_1083:csc_scm",(void*)f_1083},
{"f_1087:csc_scm",(void*)f_1087},
{"f_1076:csc_scm",(void*)f_1076},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
