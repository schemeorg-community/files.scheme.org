/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:54
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: c-backend.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[862];
static double C_possibly_force_alignment;


#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2460(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2460(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2456(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2456(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10296)
static void C_ccall f_10296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10299)
static void C_ccall f_10299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10326)
static void C_ccall f_10326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10322)
static void C_ccall f_10322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10302)
static void C_ccall f_10302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10305)
static void C_ccall f_10305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10318)
static void C_ccall f_10318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10308)
static void C_ccall f_10308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10311)
static void C_ccall f_10311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10314)
static void C_ccall f_10314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9996)
static void C_ccall f_9996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10272)
static void C_ccall f_10272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10270)
static void C_ccall f_10270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10258)
static void C_ccall f_10258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10228)
static void C_ccall f_10228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10189)
static void C_ccall f_10189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10176)
static void C_ccall f_10176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10172)
static void C_ccall f_10172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10058)
static void C_ccall f_10058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10005)
static C_word C_fcall f_10005(C_word *a,C_word t0);
C_noret_decl(f_9389)
static void C_ccall f_9389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9500)
static void C_fcall f_9500(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9665)
static void C_ccall f_9665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9692)
static void C_fcall f_9692(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9870)
static void C_ccall f_9870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9873)
static void C_ccall f_9873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9876)
static void C_ccall f_9876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9879)
static void C_ccall f_9879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9849)
static void C_ccall f_9849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9852)
static void C_ccall f_9852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9855)
static void C_ccall f_9855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9858)
static void C_ccall f_9858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9828)
static void C_ccall f_9828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9831)
static void C_ccall f_9831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9834)
static void C_ccall f_9834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9837)
static void C_ccall f_9837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9791)
static void C_ccall f_9791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9794)
static void C_ccall f_9794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9797)
static void C_ccall f_9797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9800)
static void C_ccall f_9800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9770)
static void C_ccall f_9770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9773)
static void C_ccall f_9773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9776)
static void C_ccall f_9776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9779)
static void C_ccall f_9779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9749)
static void C_ccall f_9749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9752)
static void C_ccall f_9752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9755)
static void C_ccall f_9755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9758)
static void C_ccall f_9758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9728)
static void C_ccall f_9728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9731)
static void C_ccall f_9731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9734)
static void C_ccall f_9734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9737)
static void C_ccall f_9737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9707)
static void C_ccall f_9707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9710)
static void C_ccall f_9710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9716)
static void C_ccall f_9716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9669)
static void C_fcall f_9669(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9635)
static void C_ccall f_9635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9638)
static void C_ccall f_9638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9641)
static void C_ccall f_9641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9644)
static void C_ccall f_9644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9614)
static void C_ccall f_9614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9617)
static void C_ccall f_9617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9620)
static void C_ccall f_9620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9623)
static void C_ccall f_9623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9593)
static void C_ccall f_9593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9596)
static void C_ccall f_9596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9599)
static void C_ccall f_9599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9602)
static void C_ccall f_9602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9569)
static void C_ccall f_9569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9572)
static void C_ccall f_9572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9575)
static void C_ccall f_9575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9578)
static void C_ccall f_9578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9548)
static void C_ccall f_9548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9551)
static void C_ccall f_9551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9554)
static void C_ccall f_9554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9557)
static void C_ccall f_9557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9524)
static void C_ccall f_9524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9527)
static void C_ccall f_9527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9530)
static void C_ccall f_9530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9533)
static void C_ccall f_9533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9503)
static void C_ccall f_9503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9506)
static void C_ccall f_9506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9509)
static void C_ccall f_9509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9479)
static void C_ccall f_9479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9482)
static void C_ccall f_9482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9485)
static void C_ccall f_9485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9488)
static void C_ccall f_9488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9458)
static void C_ccall f_9458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9461)
static void C_ccall f_9461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9464)
static void C_ccall f_9464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9467)
static void C_ccall f_9467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9391)
static void C_fcall f_9391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8899)
static void C_ccall f_8899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8929)
static void C_fcall f_8929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8956)
static void C_fcall f_8956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9151)
static void C_fcall f_9151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9160)
static void C_fcall f_9160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9169)
static void C_ccall f_9169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9196)
static void C_fcall f_9196(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9273)
static void C_ccall f_9273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8901)
static void C_fcall f_8901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8015)
static void C_ccall f_8015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8092)
static void C_fcall f_8092(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8194)
static void C_fcall f_8194(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8227)
static void C_fcall f_8227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8323)
static void C_fcall f_8323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8335)
static void C_fcall f_8335(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8350)
static void C_ccall f_8350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8395)
static void C_fcall f_8395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8412)
static void C_fcall f_8412(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8429)
static void C_fcall f_8429(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8468)
static void C_fcall f_8468(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8485)
static void C_fcall f_8485(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8502)
static void C_fcall f_8502(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8519)
static void C_fcall f_8519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8536)
static void C_fcall f_8536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8553)
static void C_fcall f_8553(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8570)
static void C_fcall f_8570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8582)
static void C_ccall f_8582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8589)
static void C_ccall f_8589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8599)
static void C_fcall f_8599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8639)
static void C_ccall f_8639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8609)
static void C_fcall f_8609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8597)
static void C_ccall f_8597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8593)
static void C_ccall f_8593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8560)
static void C_ccall f_8560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8543)
static void C_ccall f_8543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8526)
static void C_ccall f_8526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8509)
static void C_ccall f_8509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8492)
static void C_ccall f_8492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8475)
static void C_ccall f_8475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8440)
static void C_ccall f_8440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8450)
static void C_ccall f_8450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8448)
static void C_ccall f_8448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8444)
static void C_ccall f_8444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8436)
static void C_ccall f_8436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8423)
static void C_ccall f_8423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8406)
static void C_ccall f_8406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8354)
static void C_fcall f_8354(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8022)
static void C_fcall f_8022(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8017)
static void C_fcall f_8017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7957)
static void C_ccall f_7957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7960)
static void C_ccall f_7960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7963)
static void C_ccall f_7963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7969)
static void C_ccall f_7969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7972)
static void C_ccall f_7972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7980)
static void C_ccall f_7980(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8001)
static void C_ccall f_8001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7462)
static void C_fcall f_7462(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7937)
static void C_ccall f_7937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_fcall f_7470(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7480)
static void C_ccall f_7480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7483)
static void C_ccall f_7483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7934)
static void C_ccall f_7934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7841)
static void C_ccall f_7841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7844)
static void C_ccall f_7844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7883)
static void C_fcall f_7883(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7899)
static void C_ccall f_7899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7902)
static void C_ccall f_7902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7853)
static void C_ccall f_7853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7859)
static void C_ccall f_7859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7862)
static void C_ccall f_7862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7491)
static void C_ccall f_7491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7501)
static void C_fcall f_7501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7510)
static void C_fcall f_7510(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7522)
static void C_fcall f_7522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7534)
static void C_fcall f_7534(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7540)
static void C_ccall f_7540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7579)
static void C_fcall f_7579(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7544)
static void C_fcall f_7544(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7142)
static void C_ccall f_7142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7148)
static void C_fcall f_7148(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7443)
static void C_ccall f_7443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7156)
static void C_fcall f_7156(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7163)
static void C_ccall f_7163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7166)
static void C_ccall f_7166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7172)
static void C_ccall f_7172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7175)
static void C_ccall f_7175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7178)
static void C_ccall f_7178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7181)
static void C_ccall f_7181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7184)
static void C_ccall f_7184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7187)
static void C_ccall f_7187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7190)
static void C_ccall f_7190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7193)
static void C_ccall f_7193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7196)
static void C_ccall f_7196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7199)
static void C_ccall f_7199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7429)
static void C_ccall f_7429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7202)
static void C_ccall f_7202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7205)
static void C_ccall f_7205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7211)
static void C_ccall f_7211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7214)
static void C_ccall f_7214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7220)
static void C_ccall f_7220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7322)
static void C_fcall f_7322(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7329)
static void C_fcall f_7329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7356)
static void C_ccall f_7356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7362)
static void C_ccall f_7362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7350)
static void C_ccall f_7350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7338)
static void C_ccall f_7338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7342)
static void C_ccall f_7342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7346)
static void C_ccall f_7346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7226)
static void C_ccall f_7226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_ccall f_7229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7259)
static void C_ccall f_7259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7262)
static void C_ccall f_7262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7300)
static void C_ccall f_7300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7265)
static void C_ccall f_7265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7268)
static void C_ccall f_7268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7271)
static void C_ccall f_7271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_ccall f_7238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7241)
static void C_ccall f_7241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7232)
static void C_ccall f_7232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7102)
static void C_ccall f_7102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7108)
static void C_fcall f_7108(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7123)
static void C_ccall f_7123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7129)
static void C_ccall f_7129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7048)
static void C_ccall f_7048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7052)
static void C_ccall f_7052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7057)
static void C_fcall f_7057(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7086)
static void C_ccall f_7086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7032)
static void C_ccall f_7032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7038)
static void C_ccall f_7038(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6936)
static void C_fcall f_6936(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6965)
static void C_fcall f_6965(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6975)
static void C_ccall f_6975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6854)
static void C_ccall f_6854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6868)
static void C_fcall f_6868(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6881)
static void C_ccall f_6881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6884)
static void C_ccall f_6884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6887)
static void C_ccall f_6887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6860)
static void C_ccall f_6860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6821)
static void C_ccall f_6821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6824)
static void C_ccall f_6824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6827)
static void C_ccall f_6827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6830)
static void C_ccall f_6830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6833)
static void C_ccall f_6833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6836)
static void C_ccall f_6836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6839)
static void C_ccall f_6839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6845)
static void C_ccall f_6845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6032)
static void C_fcall f_6032(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_fcall f_6038(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6046)
static void C_fcall f_6046(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6068)
static void C_fcall f_6068(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6080)
static void C_ccall f_6080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6083)
static void C_ccall f_6083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6095)
static void C_ccall f_6095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6098)
static void C_ccall f_6098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6104)
static void C_ccall f_6104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6107)
static void C_ccall f_6107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6769)
static void C_ccall f_6769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6730)
static void C_ccall f_6730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6733)
static void C_ccall f_6733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6736)
static void C_ccall f_6736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6702)
static void C_fcall f_6702(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6705)
static void C_ccall f_6705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static void C_ccall f_6131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_fcall f_6137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6662)
static void C_fcall f_6662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6664)
static void C_fcall f_6664(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6674)
static void C_ccall f_6674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6615)
static void C_ccall f_6615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6620)
static void C_fcall f_6620(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6647)
static void C_ccall f_6647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6564)
static void C_fcall f_6564(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6576)
static void C_ccall f_6576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6486)
static void C_ccall f_6486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6528)
static void C_fcall f_6528(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6489)
static void C_ccall f_6489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_fcall f_6495(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6425)
static void C_ccall f_6425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6449)
static void C_fcall f_6449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6440)
static void C_ccall f_6440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6376)
static void C_ccall f_6376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6379)
static void C_ccall f_6379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6382)
static void C_ccall f_6382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6169)
static void C_fcall f_6169(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6274)
static void C_ccall f_6274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6277)
static void C_ccall f_6277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6289)
static void C_ccall f_6289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6175)
static void C_ccall f_6175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6178)
static void C_ccall f_6178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6261)
static void C_ccall f_6261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6181)
static void C_ccall f_6181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6184)
static void C_ccall f_6184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6187)
static void C_ccall f_6187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6251)
static void C_ccall f_6251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6202)
static void C_ccall f_6202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6226)
static void C_fcall f_6226(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6236)
static void C_ccall f_6236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6211)
static void C_ccall f_6211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6159)
static void C_ccall f_6159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5984)
static void C_fcall f_5984(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5907)
static void C_fcall f_5907(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5922)
static void C_fcall f_5922(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5978)
static void C_ccall f_5978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5974)
static void C_ccall f_5974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5959)
static void C_ccall f_5959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5938)
static void C_fcall f_5938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_fcall f_5765(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5905)
static void C_ccall f_5905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5772)
static void C_fcall f_5772(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5861)
static void C_fcall f_5861(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5874)
static void C_ccall f_5874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5571)
static void C_fcall f_5571(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5687)
static void C_ccall f_5687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5734)
static void C_fcall f_5734(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5712)
static void C_ccall f_5712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_fcall f_5648(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_fcall f_5516(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_fcall f_5522(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5196)
static void C_fcall f_5196(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_fcall f_5385(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5393)
static void C_fcall f_5393(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5406)
static void C_ccall f_5406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_fcall f_5412(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_fcall f_5415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5489)
static void C_ccall f_5489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5461)
static void C_fcall f_5461(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5334)
static void C_fcall f_5334(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5342)
static void C_fcall f_5342(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5369)
static void C_ccall f_5369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5365)
static void C_ccall f_5365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5235)
static void C_fcall f_5235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5237)
static void C_ccall f_5237(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_ccall f_5256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5271)
static void C_ccall f_5271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5288)
static void C_ccall f_5288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5284)
static void C_ccall f_5284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5277)
static void C_ccall f_5277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_fcall f_5199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5212)
static void C_fcall f_5212(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4862)
static void C_fcall f_4862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_fcall f_4935(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_fcall f_4943(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4953)
static void C_fcall f_4953(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_fcall f_4974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_fcall f_5114(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5140)
static void C_ccall f_5140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_fcall f_5122(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5076)
static void C_ccall f_5076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_fcall f_5039(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5010)
static void C_ccall f_5010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_fcall f_4874(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4898)
static void C_fcall f_4898(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_fcall f_4691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_fcall f_4834(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_fcall f_4781(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_fcall f_4754(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_fcall f_4522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_fcall f_4595(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_fcall f_4525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_fcall f_2641(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4490)
static void C_fcall f_4490(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_fcall f_2644(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_fcall f_4382(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4210)
static void C_ccall f_4210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11141)
static void C_ccall f11141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_fcall f_3917(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_fcall f_3925(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_fcall f_3875(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_fcall f_3401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_fcall f_3407(C_word t0,C_word t1) C_noret;
C_noret_decl(f11133)
static void C_ccall f11133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3617)
static void C_fcall f_3617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3727)
static void C_fcall f_3727(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3611)
static void C_ccall f_3611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11128)
static void C_ccall f11128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_fcall f_3518(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3526)
static void C_fcall f_3526(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_fcall f_3476(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11120)
static void C_ccall f11120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11115)
static void C_ccall f11115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11110)
static void C_ccall f11110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3114)
static void C_fcall f_3114(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_fcall f_3122(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_fcall f_2841(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_fcall f_2599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_fcall f_2564(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2517)
static void C_fcall f_2517(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9500)
static void C_fcall trf_9500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9500(t0,t1);}

C_noret_decl(trf_9692)
static void C_fcall trf_9692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9692(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9692(t0,t1);}

C_noret_decl(trf_9669)
static void C_fcall trf_9669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9669(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9669(t0,t1,t2);}

C_noret_decl(trf_9391)
static void C_fcall trf_9391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9391(t0,t1);}

C_noret_decl(trf_8929)
static void C_fcall trf_8929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8929(t0,t1);}

C_noret_decl(trf_8956)
static void C_fcall trf_8956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8956(t0,t1);}

C_noret_decl(trf_9151)
static void C_fcall trf_9151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9151(t0,t1);}

C_noret_decl(trf_9160)
static void C_fcall trf_9160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9160(t0,t1);}

C_noret_decl(trf_9196)
static void C_fcall trf_9196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9196(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9196(t0,t1);}

C_noret_decl(trf_8901)
static void C_fcall trf_8901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8901(t0,t1);}

C_noret_decl(trf_8092)
static void C_fcall trf_8092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8092(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8092(t0,t1);}

C_noret_decl(trf_8194)
static void C_fcall trf_8194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8194(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8194(t0,t1);}

C_noret_decl(trf_8227)
static void C_fcall trf_8227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8227(t0,t1);}

C_noret_decl(trf_8323)
static void C_fcall trf_8323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8323(t0,t1);}

C_noret_decl(trf_8335)
static void C_fcall trf_8335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8335(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8335(t0,t1);}

C_noret_decl(trf_8395)
static void C_fcall trf_8395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8395(t0,t1);}

C_noret_decl(trf_8412)
static void C_fcall trf_8412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8412(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8412(t0,t1);}

C_noret_decl(trf_8429)
static void C_fcall trf_8429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8429(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8429(t0,t1);}

C_noret_decl(trf_8468)
static void C_fcall trf_8468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8468(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8468(t0,t1);}

C_noret_decl(trf_8485)
static void C_fcall trf_8485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8485(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8485(t0,t1);}

C_noret_decl(trf_8502)
static void C_fcall trf_8502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8502(t0,t1);}

C_noret_decl(trf_8519)
static void C_fcall trf_8519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8519(t0,t1);}

C_noret_decl(trf_8536)
static void C_fcall trf_8536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8536(t0,t1);}

C_noret_decl(trf_8553)
static void C_fcall trf_8553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8553(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8553(t0,t1);}

C_noret_decl(trf_8570)
static void C_fcall trf_8570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8570(t0,t1);}

C_noret_decl(trf_8599)
static void C_fcall trf_8599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8599(t0,t1,t2);}

C_noret_decl(trf_8609)
static void C_fcall trf_8609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8609(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8609(t0,t1);}

C_noret_decl(trf_8354)
static void C_fcall trf_8354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8354(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8354(t0,t1,t2);}

C_noret_decl(trf_8022)
static void C_fcall trf_8022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8022(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8022(t0,t1,t2);}

C_noret_decl(trf_8017)
static void C_fcall trf_8017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8017(t0,t1);}

C_noret_decl(trf_7462)
static void C_fcall trf_7462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7462(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7462(t0,t1,t2);}

C_noret_decl(trf_7470)
static void C_fcall trf_7470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7470(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7470(t0,t1,t2);}

C_noret_decl(trf_7883)
static void C_fcall trf_7883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7883(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7883(t0,t1,t2,t3);}

C_noret_decl(trf_7501)
static void C_fcall trf_7501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7501(t0,t1);}

C_noret_decl(trf_7510)
static void C_fcall trf_7510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7510(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7510(t0,t1);}

C_noret_decl(trf_7522)
static void C_fcall trf_7522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7522(t0,t1);}

C_noret_decl(trf_7534)
static void C_fcall trf_7534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7534(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7534(t0,t1);}

C_noret_decl(trf_7579)
static void C_fcall trf_7579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7579(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7579(t0,t1);}

C_noret_decl(trf_7544)
static void C_fcall trf_7544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7544(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7544(t0,t1,t2);}

C_noret_decl(trf_7148)
static void C_fcall trf_7148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7148(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7148(t0,t1,t2);}

C_noret_decl(trf_7156)
static void C_fcall trf_7156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7156(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7156(t0,t1,t2);}

C_noret_decl(trf_7322)
static void C_fcall trf_7322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7322(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7322(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7329)
static void C_fcall trf_7329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7329(t0,t1);}

C_noret_decl(trf_7108)
static void C_fcall trf_7108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7108(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7108(t0,t1,t2);}

C_noret_decl(trf_7057)
static void C_fcall trf_7057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7057(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7057(t0,t1,t2);}

C_noret_decl(trf_6936)
static void C_fcall trf_6936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6936(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6936(t0,t1,t2);}

C_noret_decl(trf_6965)
static void C_fcall trf_6965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6965(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6965(t0,t1);}

C_noret_decl(trf_6868)
static void C_fcall trf_6868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6868(t0,t1,t2);}

C_noret_decl(trf_6032)
static void C_fcall trf_6032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6032(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6032(t0,t1);}

C_noret_decl(trf_6038)
static void C_fcall trf_6038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6038(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6038(t0,t1,t2);}

C_noret_decl(trf_6046)
static void C_fcall trf_6046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6046(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6046(t0,t1,t2);}

C_noret_decl(trf_6068)
static void C_fcall trf_6068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6068(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6068(t0,t1);}

C_noret_decl(trf_6702)
static void C_fcall trf_6702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6702(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6702(t0,t1);}

C_noret_decl(trf_6137)
static void C_fcall trf_6137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6137(t0,t1);}

C_noret_decl(trf_6662)
static void C_fcall trf_6662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6662(t0,t1);}

C_noret_decl(trf_6664)
static void C_fcall trf_6664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6664(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6664(t0,t1,t2,t3);}

C_noret_decl(trf_6620)
static void C_fcall trf_6620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6620(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6620(t0,t1,t2);}

C_noret_decl(trf_6564)
static void C_fcall trf_6564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6564(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6564(t0,t1);}

C_noret_decl(trf_6528)
static void C_fcall trf_6528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6528(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6528(t0,t1);}

C_noret_decl(trf_6495)
static void C_fcall trf_6495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6495(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6495(t0,t1);}

C_noret_decl(trf_6449)
static void C_fcall trf_6449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6449(t0,t1);}

C_noret_decl(trf_6169)
static void C_fcall trf_6169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6169(t0,t1);}

C_noret_decl(trf_6226)
static void C_fcall trf_6226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6226(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6226(t0,t1,t2,t3);}

C_noret_decl(trf_5984)
static void C_fcall trf_5984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5984(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5984(t0,t1,t2,t3);}

C_noret_decl(trf_5907)
static void C_fcall trf_5907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5907(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5907(t0,t1,t2);}

C_noret_decl(trf_5922)
static void C_fcall trf_5922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5922(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5922(t0,t1,t2,t3);}

C_noret_decl(trf_5938)
static void C_fcall trf_5938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5938(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5938(t0,t1);}

C_noret_decl(trf_5765)
static void C_fcall trf_5765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5765(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5765(t0,t1,t2,t3);}

C_noret_decl(trf_5772)
static void C_fcall trf_5772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5772(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5772(t0,t1);}

C_noret_decl(trf_5861)
static void C_fcall trf_5861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5861(t0,t1);}

C_noret_decl(trf_5571)
static void C_fcall trf_5571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5571(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5571(t0,t1,t2);}

C_noret_decl(trf_5734)
static void C_fcall trf_5734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5734(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5734(t0,t1,t2,t3);}

C_noret_decl(trf_5648)
static void C_fcall trf_5648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5648(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5648(t0,t1,t2);}

C_noret_decl(trf_5516)
static void C_fcall trf_5516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5516(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5516(t0,t1);}

C_noret_decl(trf_5522)
static void C_fcall trf_5522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5522(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5522(t0,t1,t2,t3);}

C_noret_decl(trf_5196)
static void C_fcall trf_5196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5196(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5196(t0,t1);}

C_noret_decl(trf_5385)
static void C_fcall trf_5385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5385(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5385(t0,t1,t2);}

C_noret_decl(trf_5393)
static void C_fcall trf_5393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5393(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5393(t0,t1,t2);}

C_noret_decl(trf_5412)
static void C_fcall trf_5412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5412(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5412(t0,t1);}

C_noret_decl(trf_5415)
static void C_fcall trf_5415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5415(t0,t1);}

C_noret_decl(trf_5461)
static void C_fcall trf_5461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5461(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5461(t0,t1);}

C_noret_decl(trf_5334)
static void C_fcall trf_5334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5334(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5334(t0,t1,t2);}

C_noret_decl(trf_5342)
static void C_fcall trf_5342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5342(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5342(t0,t1,t2);}

C_noret_decl(trf_5235)
static void C_fcall trf_5235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5235(t0,t1,t2);}

C_noret_decl(trf_5199)
static void C_fcall trf_5199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5199(t0,t1);}

C_noret_decl(trf_5212)
static void C_fcall trf_5212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5212(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5212(t0,t1,t2,t3);}

C_noret_decl(trf_4862)
static void C_fcall trf_4862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4862(t0,t1);}

C_noret_decl(trf_4935)
static void C_fcall trf_4935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4935(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4935(t0,t1,t2);}

C_noret_decl(trf_4943)
static void C_fcall trf_4943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4943(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4943(t0,t1,t2);}

C_noret_decl(trf_4953)
static void C_fcall trf_4953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4953(t0,t1);}

C_noret_decl(trf_4974)
static void C_fcall trf_4974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4974(t0,t1);}

C_noret_decl(trf_5114)
static void C_fcall trf_5114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5114(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5114(t0,t1,t2);}

C_noret_decl(trf_5122)
static void C_fcall trf_5122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5122(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5122(t0,t1,t2);}

C_noret_decl(trf_5039)
static void C_fcall trf_5039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5039(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5039(t0,t1);}

C_noret_decl(trf_4874)
static void C_fcall trf_4874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4874(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4874(t0,t1,t2);}

C_noret_decl(trf_4898)
static void C_fcall trf_4898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4898(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4898(t0,t1,t2);}

C_noret_decl(trf_4691)
static void C_fcall trf_4691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4691(t0,t1);}

C_noret_decl(trf_4834)
static void C_fcall trf_4834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4834(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4834(t0,t1,t2);}

C_noret_decl(trf_4712)
static void C_fcall trf_4712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4712(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4712(t0,t1,t2,t3);}

C_noret_decl(trf_4781)
static void C_fcall trf_4781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4781(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4781(t0,t1,t2);}

C_noret_decl(trf_4754)
static void C_fcall trf_4754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4754(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4754(t0,t1,t2);}

C_noret_decl(trf_4522)
static void C_fcall trf_4522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4522(t0,t1);}

C_noret_decl(trf_4595)
static void C_fcall trf_4595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4595(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4595(t0,t1,t2);}

C_noret_decl(trf_4525)
static void C_fcall trf_4525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4525(t0,t1);}

C_noret_decl(trf_2641)
static void C_fcall trf_2641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2641(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2641(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4490)
static void C_fcall trf_4490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4490(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4490(t0,t1,t2,t3);}

C_noret_decl(trf_2644)
static void C_fcall trf_2644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2644(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2644(t0,t1,t2,t3);}

C_noret_decl(trf_4382)
static void C_fcall trf_4382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4382(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4382(t0,t1,t2,t3);}

C_noret_decl(trf_3917)
static void C_fcall trf_3917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3917(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3917(t0,t1,t2,t3);}

C_noret_decl(trf_3925)
static void C_fcall trf_3925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3925(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3925(t0,t1,t2,t3);}

C_noret_decl(trf_3875)
static void C_fcall trf_3875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3875(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3875(t0,t1,t2,t3);}

C_noret_decl(trf_3401)
static void C_fcall trf_3401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3401(t0,t1);}

C_noret_decl(trf_3407)
static void C_fcall trf_3407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3407(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3407(t0,t1);}

C_noret_decl(trf_3617)
static void C_fcall trf_3617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3617(t0,t1);}

C_noret_decl(trf_3727)
static void C_fcall trf_3727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3727(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3727(t0,t1);}

C_noret_decl(trf_3518)
static void C_fcall trf_3518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3518(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3518(t0,t1,t2,t3);}

C_noret_decl(trf_3526)
static void C_fcall trf_3526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3526(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3526(t0,t1,t2,t3);}

C_noret_decl(trf_3476)
static void C_fcall trf_3476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3476(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3476(t0,t1,t2,t3);}

C_noret_decl(trf_3114)
static void C_fcall trf_3114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3114(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3114(t0,t1,t2,t3);}

C_noret_decl(trf_3122)
static void C_fcall trf_3122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3122(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3122(t0,t1,t2,t3);}

C_noret_decl(trf_2841)
static void C_fcall trf_2841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2841(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2841(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2599)
static void C_fcall trf_2599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2599(t0,t1,t2);}

C_noret_decl(trf_2564)
static void C_fcall trf_2564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2564(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2564(t0,t1,t2);}

C_noret_decl(trf_2517)
static void C_fcall trf_2517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2517(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2517(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2502)){
C_save(t1);
C_rereclaim2(2502*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,862);
lf[0]=C_h_intern(&lf[0],15,"\010compileroutput");
lf[1]=C_h_intern(&lf[1],12,"\010compilergen");
lf[2]=C_h_intern(&lf[2],7,"newline");
lf[3]=C_h_intern(&lf[3],7,"display");
lf[4]=C_h_intern(&lf[4],17,"\010compilergen-list");
lf[5]=C_h_intern(&lf[5],11,"intersperse");
lf[6]=C_h_intern(&lf[6],18,"\010compilerunique-id");
lf[7]=C_h_intern(&lf[7],22,"\010compilergenerate-code");
lf[8]=C_h_intern(&lf[8],13,"\010compilerbomb");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[10]=C_h_intern(&lf[10],17,"lambda-literal-id");
lf[11]=C_h_intern(&lf[11],4,"find");
lf[12]=C_h_intern(&lf[12],14,"\004coreimmediate");
lf[13]=C_h_intern(&lf[13],4,"bool");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[16]=C_h_intern(&lf[16],4,"char");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[18]=C_h_intern(&lf[18],3,"nil");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[20]=C_h_intern(&lf[20],3,"fix");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[22]=C_h_intern(&lf[22],3,"eof");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[25]=C_h_intern(&lf[25],12,"\004coreliteral");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[29]=C_h_intern(&lf[29],2,"if");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[33]=C_h_intern(&lf[33],9,"\004coreproc");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[35]=C_h_intern(&lf[35],9,"\004corebind");
lf[36]=C_h_intern(&lf[36],16,"\004corelet_unboxed");
lf[37]=C_h_intern(&lf[37],8,"\004coreref");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[40]=C_h_intern(&lf[40],10,"\004coreunbox");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[43]=C_h_intern(&lf[43],13,"\004coreupdate_i");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[45]=C_h_intern(&lf[45],11,"\004coreupdate");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[49]=C_h_intern(&lf[49],16,"\004coreupdatebox_i");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[52]=C_h_intern(&lf[52],14,"\004coreupdatebox");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[55]=C_h_intern(&lf[55],12,"\004coreclosure");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[60]=C_h_intern(&lf[60],4,"iota");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[62]=C_h_intern(&lf[62],8,"\004corebox");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[65]=C_h_intern(&lf[65],10,"\004corelocal");
lf[66]=C_h_intern(&lf[66],13,"\004coresetlocal");
lf[67]=C_h_intern(&lf[67],11,"\004coreglobal");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[72]=C_h_intern(&lf[72],21,"\010compilerc-ify-string");
lf[73]=C_h_intern(&lf[73],14,"symbol->string");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[78]=C_h_intern(&lf[78],14,"\004coresetglobal");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\012 /* (set! ");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) */,");
lf[81]=C_h_intern(&lf[81],17,"string-translate*");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[83]=C_h_intern(&lf[83],8,"->string");
lf[84]=C_h_intern(&lf[84],28,"\003syssymbol->qualified-string");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[89]=C_h_intern(&lf[89],16,"\004coresetglobal_i");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\005 */ =");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\006 */,0,");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[98]=C_h_intern(&lf[98],14,"\004coreundefined");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[100]=C_h_intern(&lf[100],9,"\004corecall");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[106]=C_h_intern(&lf[106],26,"lambda-literal-temporaries");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[108]=C_h_intern(&lf[108],22,"lambda-literal-looping");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\030C_retrieve2_symbol_proc(");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[115]=C_h_intern(&lf[115],13,"string-append");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\032C_retrieve_symbol_proc(lf[");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[131]=C_h_intern(&lf[131],6,"unsafe");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[136]=C_h_intern(&lf[136],28,"\010compilerno-procedure-checks");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[139]=C_h_intern(&lf[139],24,"\010compileremit-trace-info");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[142]=C_h_intern(&lf[142],16,"string-translate");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[148]=C_h_intern(&lf[148],27,"lambda-literal-closure-size");
lf[149]=C_h_intern(&lf[149],28,"\010compilersource-info->string");
lf[150]=C_h_intern(&lf[150],12,"\004corerecurse");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[154]=C_h_intern(&lf[154],16,"\004coredirect_call");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[156]=C_h_intern(&lf[156],13,"\004corecallunit");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[161]=C_h_intern(&lf[161],11,"\004corereturn");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[164]=C_h_intern(&lf[164],11,"\004coreinline");
lf[165]=C_h_intern(&lf[165],20,"\004coreinline_allocate");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[167]=C_h_intern(&lf[167],15,"\004coreinline_ref");
lf[168]=C_h_intern(&lf[168],34,"\010compilerforeign-result-conversion");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[170]=C_h_intern(&lf[170],18,"\004coreinline_update");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[173]=C_h_intern(&lf[173],36,"\010compilerforeign-argument-conversion");
lf[174]=C_h_intern(&lf[174],33,"\010compilerforeign-type-declaration");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[176]=C_h_intern(&lf[176],19,"\004coreinline_loc_ref");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[182]=C_h_intern(&lf[182],22,"\004coreinline_loc_update");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[188]=C_h_intern(&lf[188],16,"\004coreunboxed_ref");
lf[189]=C_h_intern(&lf[189],17,"\004coreunboxed_set!");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\002((");
lf[192]=C_h_intern(&lf[192],19,"\004coreinline_unboxed");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[194]=C_h_intern(&lf[194],11,"\004coreswitch");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[199]=C_h_intern(&lf[199],9,"\004corecond");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[203]=C_h_intern(&lf[203],13,"pair-for-each");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[205]=C_h_intern(&lf[205],30,"\010compilerexternal-protos-first");
lf[206]=C_h_intern(&lf[206],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[207]=C_h_intern(&lf[207],22,"foreign-callback-stubs");
lf[208]=C_h_intern(&lf[208],29,"\010compilerforeign-declarations");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[211]=C_h_intern(&lf[211],28,"\010compilertarget-include-file");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[213]=C_h_intern(&lf[213],18,"\010compilerunit-name");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[215]=C_h_intern(&lf[215],19,"\010compilerused-units");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[217]=C_h_intern(&lf[217],27,"\010compilercompiler-arguments");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[223]=C_h_intern(&lf[223],18,"string-intersperse");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[227]=C_h_intern(&lf[227],7,"\003sysmap");
lf[228]=C_h_intern(&lf[228],12,"string-split");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[230]=C_h_intern(&lf[230],15,"chicken-version");
lf[231]=C_h_intern(&lf[231],18,"\003sysdecode-seconds");
lf[232]=C_h_intern(&lf[232],15,"current-seconds");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[237]=C_h_intern(&lf[237],23,"\003syslambda-info->string");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[247]=C_h_intern(&lf[247],9,"make-list");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[251]=C_h_intern(&lf[251],4,"none");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[262]=C_h_intern(&lf[262],8,"toplevel");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[276]=C_h_intern(&lf[276],21,"small-parameter-limit");
lf[277]=C_h_intern(&lf[277],11,"lset-adjoin");
lf[278]=C_h_intern(&lf[278],1,"=");
lf[279]=C_h_intern(&lf[279],32,"lambda-literal-callee-signatures");
lf[280]=C_h_intern(&lf[280],24,"lambda-literal-allocated");
lf[281]=C_h_intern(&lf[281],21,"lambda-literal-direct");
lf[282]=C_h_intern(&lf[282],33,"lambda-literal-rest-argument-mode");
lf[283]=C_h_intern(&lf[283],28,"lambda-literal-rest-argument");
lf[284]=C_h_intern(&lf[284],27,"\010compilermake-variable-list");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[286]=C_h_intern(&lf[286],27,"lambda-literal-customizable");
lf[287]=C_h_intern(&lf[287],29,"lambda-literal-argument-count");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[294]=C_h_intern(&lf[294],27,"\010compilermake-argument-list");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[315]=C_h_intern(&lf[315],12,"\003sysfor-each");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[335]=C_h_intern(&lf[335],23,"lambda-literal-external");
lf[336]=C_h_intern(&lf[336],17,"get-output-string");
lf[337]=C_h_intern(&lf[337],19,"\003syswrite-char/port");
lf[338]=C_h_intern(&lf[338],5,"write");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[340]=C_h_intern(&lf[340],18,"open-output-string");
lf[341]=C_h_intern(&lf[341],25,"\010compilerwords-per-flonum");
lf[342]=C_h_intern(&lf[342],6,"reduce");
lf[343]=C_h_intern(&lf[343],1,"+");
lf[344]=C_h_intern(&lf[344],12,"vector->list");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[346]=C_h_intern(&lf[346],14,"\010compilerwords");
lf[347]=C_h_intern(&lf[347],15,"\003sysbytevector\077");
lf[348]=C_h_intern(&lf[348],32,"\010compilerblock-variable-literal\077");
lf[349]=C_h_intern(&lf[349],19,"\010compilerimmediate\077");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[352]=C_h_intern(&lf[352],19,"\003sysundefined-value");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[363]=C_h_intern(&lf[363],23,"\010compilerencode-literal");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[365]=C_h_intern(&lf[365],20,"\010compilerbig-fixnum\077");
lf[366]=C_h_intern(&lf[366],6,"modulo");
lf[367]=C_h_intern(&lf[367],3,"fx/");
lf[368]=C_h_intern(&lf[368],14,"\003syscopy-bytes");
lf[369]=C_h_intern(&lf[369],11,"make-string");
lf[370]=C_h_intern(&lf[370],19,"lambda-literal-body");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[419]=C_h_intern(&lf[419],26,"\010compilertarget-stack-size");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[422]=C_h_intern(&lf[422],30,"\010compilertarget-heap-shrinkage");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[424]=C_h_intern(&lf[424],27,"\010compilertarget-heap-growth");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[426]=C_h_intern(&lf[426],33,"\010compilertarget-initial-heap-size");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[429]=C_h_intern(&lf[429],25,"\010compilertarget-heap-size");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[433]=C_h_intern(&lf[433],40,"\010compilerdisable-stack-overflow-checking");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[439]=C_h_intern(&lf[439],4,"fold");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[442]=C_h_intern(&lf[442],28,"\010compilerinsert-timer-checks");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[447]=C_h_intern(&lf[447],23,"\010compilerno-argc-checks");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[473]=C_h_intern(&lf[473],6,"fixnum");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[475]=C_h_intern(&lf[475],6,"flonum");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[478]=C_h_intern(&lf[478],7,"pointer");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid unboxed type");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[484]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[503]=C_h_intern(&lf[503],16,"\010compilercleanup");
lf[504]=C_h_intern(&lf[504],18,"\010compilerdebugging");
lf[505]=C_h_intern(&lf[505],1,"o");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[509]=C_h_intern(&lf[509],34,"lambda-literal-unboxed-temporaries");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[512]=C_h_intern(&lf[512],18,"\010compilerreal-name");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[514]=C_h_intern(&lf[514],25,"emit-procedure-table-info");
lf[515]=C_h_intern(&lf[515],31,"generate-foreign-callback-stubs");
lf[516]=C_h_intern(&lf[516],31,"\010compilergenerate-foreign-stubs");
lf[517]=C_h_intern(&lf[517],29,"\010compilerforeign-lambda-stubs");
lf[518]=C_h_intern(&lf[518],36,"\010compilergenerate-external-variables");
lf[519]=C_h_intern(&lf[519],27,"\010compilerexternal-variables");
lf[520]=C_h_intern(&lf[520],1,"p");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[538]=C_h_intern(&lf[538],29,"\010compilerstring->c-identifier");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[542]=C_h_intern(&lf[542],11,"string-copy");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[544]=C_h_intern(&lf[544],13,"list-tabulate");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[547]=C_h_intern(&lf[547],41,"\010compilergenerate-foreign-callback-header");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[560]=C_h_intern(&lf[560],4,"void");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[569]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[571]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[574]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[579]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[580]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[581]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[582]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[583]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[584]=C_h_intern(&lf[584],21,"foreign-stub-callback");
lf[585]=C_h_intern(&lf[585],16,"foreign-stub-cps");
lf[586]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[587]=C_h_intern(&lf[587],27,"foreign-stub-argument-names");
lf[588]=C_h_intern(&lf[588],17,"foreign-stub-body");
lf[589]=C_h_intern(&lf[589],17,"foreign-stub-name");
lf[590]=C_h_intern(&lf[590],24,"foreign-stub-return-type");
lf[591]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[592]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[593]=C_h_intern(&lf[593],27,"foreign-stub-argument-types");
lf[594]=C_h_intern(&lf[594],19,"\010compilerreal-name2");
lf[595]=C_h_intern(&lf[595],15,"foreign-stub-id");
lf[596]=C_h_intern(&lf[596],5,"float");
lf[597]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[598]=C_h_intern(&lf[598],8,"c-string");
lf[599]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[600]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[601]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[602]=C_h_intern(&lf[602],16,"nonnull-c-string");
lf[603]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[604]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[605]=C_h_intern(&lf[605],3,"ref");
lf[606]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[607]=C_h_intern(&lf[607],5,"const");
lf[608]=C_h_intern(&lf[608],9,"c-pointer");
lf[609]=C_h_intern(&lf[609],15,"nonnull-pointer");
lf[610]=C_h_intern(&lf[610],17,"nonnull-c-pointer");
lf[611]=C_h_intern(&lf[611],8,"function");
lf[612]=C_h_intern(&lf[612],8,"instance");
lf[613]=C_h_intern(&lf[613],16,"nonnull-instance");
lf[614]=C_h_intern(&lf[614],12,"instance-ref");
lf[615]=C_h_intern(&lf[615],18,"\003syshash-table-ref");
lf[616]=C_h_intern(&lf[616],27,"\010compilerforeign-type-table");
lf[617]=C_h_intern(&lf[617],17,"nonnull-c-string*");
lf[618]=C_h_intern(&lf[618],25,"nonnull-unsigned-c-string");
lf[619]=C_h_intern(&lf[619],26,"nonnull-unsigned-c-string*");
lf[620]=C_h_intern(&lf[620],6,"symbol");
lf[621]=C_h_intern(&lf[621],9,"c-string*");
lf[622]=C_h_intern(&lf[622],17,"unsigned-c-string");
lf[623]=C_h_intern(&lf[623],18,"unsigned-c-string*");
lf[624]=C_h_intern(&lf[624],6,"double");
lf[625]=C_h_intern(&lf[625],16,"unsigned-integer");
lf[626]=C_h_intern(&lf[626],18,"unsigned-integer32");
lf[627]=C_h_intern(&lf[627],4,"long");
lf[628]=C_h_intern(&lf[628],7,"integer");
lf[629]=C_h_intern(&lf[629],9,"integer32");
lf[630]=C_h_intern(&lf[630],13,"unsigned-long");
lf[631]=C_h_intern(&lf[631],6,"number");
lf[632]=C_h_intern(&lf[632],9,"integer64");
lf[633]=C_h_intern(&lf[633],13,"c-string-list");
lf[634]=C_h_intern(&lf[634],14,"c-string-list*");
lf[635]=C_h_intern(&lf[635],3,"int");
lf[636]=C_h_intern(&lf[636],5,"int32");
lf[637]=C_h_intern(&lf[637],5,"short");
lf[638]=C_h_intern(&lf[638],14,"unsigned-short");
lf[639]=C_h_intern(&lf[639],13,"scheme-object");
lf[640]=C_h_intern(&lf[640],13,"unsigned-char");
lf[641]=C_h_intern(&lf[641],12,"unsigned-int");
lf[642]=C_h_intern(&lf[642],14,"unsigned-int32");
lf[643]=C_h_intern(&lf[643],4,"byte");
lf[644]=C_h_intern(&lf[644],13,"unsigned-byte");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[652]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[653]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[657]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[658]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[660]=C_h_intern(&lf[660],36,"foreign-callback-stub-argument-types");
lf[661]=C_h_intern(&lf[661],33,"foreign-callback-stub-return-type");
lf[662]=C_h_intern(&lf[662],24,"foreign-callback-stub-id");
lf[663]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[664]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[665]=C_h_intern(&lf[665],32,"foreign-callback-stub-qualifiers");
lf[666]=C_h_intern(&lf[666],26,"foreign-callback-stub-name");
lf[667]=C_h_intern(&lf[667],4,"quit");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[669]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[670]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[672]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[673]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[675]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[676]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[679]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[683]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[687]=C_h_intern(&lf[687],11,"byte-vector");
lf[688]=C_h_intern(&lf[688],19,"nonnull-byte-vector");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[690]=C_h_intern(&lf[690],4,"blob");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[692]=C_h_intern(&lf[692],9,"u16vector");
lf[693]=C_h_intern(&lf[693],17,"nonnull-u16vector");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[695]=C_h_intern(&lf[695],8,"s8vector");
lf[696]=C_h_intern(&lf[696],16,"nonnull-s8vector");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[698]=C_h_intern(&lf[698],9,"u32vector");
lf[699]=C_h_intern(&lf[699],17,"nonnull-u32vector");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[701]=C_h_intern(&lf[701],9,"s16vector");
lf[702]=C_h_intern(&lf[702],17,"nonnull-s16vector");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[704]=C_h_intern(&lf[704],9,"s32vector");
lf[705]=C_h_intern(&lf[705],17,"nonnull-s32vector");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[707]=C_h_intern(&lf[707],9,"f32vector");
lf[708]=C_h_intern(&lf[708],17,"nonnull-f32vector");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[710]=C_h_intern(&lf[710],9,"f64vector");
lf[711]=C_h_intern(&lf[711],17,"nonnull-f64vector");
lf[712]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[713]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[732]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[736]=C_h_intern(&lf[736],3,"...");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[741]=C_h_intern(&lf[741],9,"\003syserror");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[743]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[744]=C_h_intern(&lf[744],4,"enum");
lf[745]=C_h_intern(&lf[745],5,"union");
lf[746]=C_h_intern(&lf[746],6,"struct");
lf[747]=C_h_intern(&lf[747],8,"template");
lf[748]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c"
"-pointer\376\377\016");
lf[749]=C_h_intern(&lf[749],12,"nonnull-blob");
lf[750]=C_h_intern(&lf[750],8,"u8vector");
lf[751]=C_h_intern(&lf[751],16,"nonnull-u8vector");
lf[752]=C_h_intern(&lf[752],14,"scheme-pointer");
lf[753]=C_h_intern(&lf[753],22,"nonnull-scheme-pointer");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[816]=C_decode_literal(C_heaptop,"\376B\000\000\012C_flonum(&");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\012C_number(&");
lf[818]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[819]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[821]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[822]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[823]=C_decode_literal(C_heaptop,"\376B\000\000\023C_a_double_to_num(&");
lf[824]=C_decode_literal(C_heaptop,"\376B\000\000\027C_unsigned_int_to_num(&");
lf[825]=C_decode_literal(C_heaptop,"\376B\000\000\017C_long_to_num(&");
lf[826]=C_decode_literal(C_heaptop,"\376B\000\000\030C_unsigned_long_to_num(&");
lf[827]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[828]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[829]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[830]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[831]=C_decode_literal(C_heaptop,"\376B\000\000\011,(void*)&");
lf[832]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[833]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[834]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[835]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[836]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[837]=C_decode_literal(C_heaptop,"\376B\000\000\011,(void*)&");
lf[838]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[839]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[840]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[841]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[842]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[843]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[844]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[845]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[846]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[847]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[848]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[849]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[850]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[851]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[852]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[853]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[854]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[855]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[856]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid literal - cannot encode");
lf[857]=C_h_intern(&lf[857],17,"\003sysstring-append");
lf[858]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[859]=C_h_intern(&lf[859],5,"cons*");
lf[860]=C_h_intern(&lf[860],6,"random");
lf[861]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
C_register_lf2(lf,862,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2505,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2503 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2506 in k2503 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=C_set_block_item(lf[0] /* output */,0,C_SCHEME_FALSE);
t3=C_mutate((C_word*)lf[1]+1 /* (set! ##compiler#gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2511,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[4]+1 /* (set! ##compiler#gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2554,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10296,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t6);}

/* k10294 in k2506 in k2503 */
static void C_ccall f_10296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10299,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[861],t1);}

/* k10297 in k10294 in k2506 in k2503 */
static void C_ccall f_10299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10322,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10326,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 57   random */
((C_proc3)C_retrieve_symbol_proc(lf[860]))(3,*((C_word*)lf[860]+1),t4,C_fix(16777216));}

/* k10324 in k10297 in k10294 in k2506 in k2503 */
static void C_ccall f_10326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* number->string */
C_number_to_string(4,0,((C_word*)t0)[2],t1,C_fix(16));}

/* k10320 in k10297 in k10294 in k2506 in k2503 */
static void C_ccall f_10322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10300 in k10297 in k10294 in k2506 in k2503 */
static void C_ccall f_10302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(95),((C_word*)t0)[2]);}

/* k10303 in k10300 in k10297 in k10294 in k2506 in k2503 */
static void C_ccall f_10305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10318,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 57   current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[232]))(2,*((C_word*)lf[232]+1),t3);}

/* k10316 in k10303 in k10300 in k10297 in k10294 in k2506 in k2503 */
static void C_ccall f_10318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10306 in k10303 in k10300 in k10297 in k10294 in k2506 in k2503 */
static void C_ccall f_10308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(95),((C_word*)t0)[2]);}

/* k10309 in k10306 in k10303 in k10300 in k10297 in k10294 in k2506 in k2503 */
static void C_ccall f_10311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10314,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),t2,((C_word*)t0)[2]);}

/* k10312 in k10309 in k10306 in k10303 in k10300 in k10297 in k10294 in k2506 in k2503 */
static void C_ccall f_10314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 56   string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[538]))(3,*((C_word*)lf[538]+1),((C_word*)t0)[2],t1);}

/* k2592 in k2506 in k2503 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1 /* (set! ##compiler#unique-id ...) */,t1);
t3=C_mutate((C_word*)lf[7]+1 /* (set! ##compiler#generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2596,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[514]+1 /* (set! emit-procedure-table-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6850,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[503]+1 /* (set! ##compiler#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6927,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[284]+1 /* (set! ##compiler#make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7016,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[294]+1 /* (set! ##compiler#make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7032,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[518]+1 /* (set! ##compiler#generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7048,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[206]+1 /* (set! ##compiler#generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7102,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[516]+1 /* (set! ##compiler#generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7142,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[515]+1 /* (set! generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7456,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[547]+1 /* (set! ##compiler#generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7950,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[174]+1 /* (set! ##compiler#foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8015,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[173]+1 /* (set! ##compiler#foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8899,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[168]+1 /* (set! ##compiler#foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9389,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[363]+1 /* (set! ##compiler#encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9996,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k2592 in k2506 in k2503 */
static void C_ccall f_9996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9996,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10005,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10058,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t5)){
t6=t1;
t7=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1392 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t6,t7,lf[844]);}
else{
t6=C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t6)){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1392 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t7,t8,lf[845]);}
else{
if(C_truep(C_charp(t2))){
t7=C_fix(C_character_code(t2));
t8=f_10005(C_a_i(&a,4),t7);
/* c-backend.scm: 1396 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t4,lf[846],t8);}
else{
if(C_truep(C_i_nullp(t2))){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1392 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t7,t8,lf[847]);}
else{
if(C_truep(C_eofp(t2))){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1392 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t7,t8,lf[848]);}
else{
t7=C_retrieve(lf[352]);
t8=C_eqp(t7,t2);
if(C_truep(t8)){
t9=t1;
t10=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1392 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t9,t10,lf[849]);}
else{
if(C_truep(C_fixnump(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10176,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1401 big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[365]))(3,*((C_word*)lf[365]+1),t9,t2);}
else{
if(C_truep(C_i_numberp(t2))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10189,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1410 number->string */
C_number_to_string(3,0,t9,t2);}
else{
if(C_truep(C_i_symbolp(t2))){
t9=C_slot(t2,C_fix(1));
t10=C_i_string_length(t9);
t11=f_10005(C_a_i(&a,4),t10);
/* c-backend.scm: 1413 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),t4,lf[855],t11,t9);}
else{
if(C_truep(C_immp(t2))){
/* c-backend.scm: 1418 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t4,lf[856],t2);}
else{
if(C_truep(C_byteblockp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10228,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=stub2456(C_SCHEME_UNDEFINED,t10);
t12=C_make_character(C_unfix(t11));
t13=C_a_i_string(&a,1,t12);
t14=t2;
t15=stub2460(C_SCHEME_UNDEFINED,t14);
t16=f_10005(C_a_i(&a,4),t15);
/* c-backend.scm: 1421 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t9,t13,t16);}
else{
t9=t2;
t10=stub2460(C_SCHEME_UNDEFINED,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10258,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t12=t2;
t13=stub2456(C_SCHEME_UNDEFINED,t12);
t14=C_make_character(C_unfix(t13));
t15=C_a_i_string(&a,1,t14);
t16=f_10005(C_a_i(&a,4),t10);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10270,a[2]=t16,a[3]=t15,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10272,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1431 list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[544]))(4,*((C_word*)lf[544]+1),t17,t10,t18);}}}}}}}}}}}}

/* a10271 in ##compiler#encode-literal in k2592 in k2506 in k2503 */
static void C_ccall f_10272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10272,3,t0,t1,t2);}
t3=C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1431 encode-literal */
((C_proc3)C_retrieve_symbol_proc(lf[363]))(3,*((C_word*)lf[363]+1),t1,t3);}

/* k10268 in ##compiler#encode-literal in k2592 in k2506 in k2503 */
static void C_ccall f_10270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1428 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[859]))(5,*((C_word*)lf[859]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10256 in ##compiler#encode-literal in k2592 in k2506 in k2503 */
static void C_ccall f_10258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1427 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[223]))(4,*((C_word*)lf[223]+1),((C_word*)t0)[2],t1,lf[858]);}

/* k10226 in ##compiler#encode-literal in k2592 in k2506 in k2503 */
static void C_ccall f_10228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1420 ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[857]))(4,*((C_word*)lf[857]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10187 in ##compiler#encode-literal in k2592 in k2506 in k2503 */
static void C_ccall f_10189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1410 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[2],lf[853],t1,lf[854]);}

/* k10174 in ##compiler#encode-literal in k2592 in k2506 in k2503 */
static void C_ccall f_10176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10176,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10172,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1408 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=C_fixnum_and(C_fix(255),t2);
t4=C_make_character(C_unfix(t3));
t5=C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=C_fixnum_and(C_fix(255),t5);
t7=C_make_character(C_unfix(t6));
t8=C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=C_fixnum_and(C_fix(255),t8);
t10=C_make_character(C_unfix(t9));
t11=C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=C_make_character(C_unfix(t11));
t13=C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1402 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[852],t13);}}

/* k10170 in k10174 in ##compiler#encode-literal in k2592 in k2506 in k2503 */
static void C_ccall f_10172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1408 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[2],lf[850],t1,lf[851]);}

/* k10056 in ##compiler#encode-literal in k2592 in k2506 in k2503 */
static void C_ccall f_10058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10058,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1392 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k2592 in k2506 in k2503 */
static C_word C_fcall f_10005(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=C_fixnum_shift_right(t1,C_fix(16));
t3=C_fixnum_and(C_fix(255),t2);
t4=C_make_character(C_unfix(t3));
t5=C_fixnum_shift_right(t1,C_fix(8));
t6=C_fixnum_and(C_fix(255),t5);
t7=C_make_character(C_unfix(t6));
t8=C_fixnum_and(C_fix(255),t1);
t9=C_make_character(C_unfix(t8));
return(C_a_i_string(&a,3,t4,t7,t9));}

/* ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9389,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9391,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=C_eqp(t5,lf[16]);
t7=(C_truep(t6)?t6:C_eqp(t5,lf[640]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[809]);}
else{
t8=C_eqp(t5,lf[635]);
t9=(C_truep(t8)?t8:C_eqp(t5,lf[636]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[810]);}
else{
t10=C_eqp(t5,lf[641]);
t11=(C_truep(t10)?t10:C_eqp(t5,lf[642]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[811]);}
else{
t12=C_eqp(t5,lf[637]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[812]);}
else{
t13=C_eqp(t5,lf[638]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[813]);}
else{
t14=C_eqp(t5,lf[643]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[814]);}
else{
t15=C_eqp(t5,lf[644]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[815]);}
else{
t16=C_eqp(t5,lf[596]);
t17=(C_truep(t16)?t16:C_eqp(t5,lf[624]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9458,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t18);}
else{
t18=C_eqp(t5,lf[631]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9479,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t19);}
else{
t19=C_eqp(t5,lf[602]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9500,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_9500(t21,t19);}
else{
t21=C_eqp(t5,lf[598]);
if(C_truep(t21)){
t22=t20;
f_9500(t22,t21);}
else{
t22=C_eqp(t5,lf[610]);
if(C_truep(t22)){
t23=t20;
f_9500(t23,t22);}
else{
t23=C_eqp(t5,lf[621]);
if(C_truep(t23)){
t24=t20;
f_9500(t24,t23);}
else{
t24=C_eqp(t5,lf[617]);
if(C_truep(t24)){
t25=t20;
f_9500(t25,t24);}
else{
t25=C_eqp(t5,lf[622]);
if(C_truep(t25)){
t26=t20;
f_9500(t26,t25);}
else{
t26=C_eqp(t5,lf[623]);
if(C_truep(t26)){
t27=t20;
f_9500(t27,t26);}
else{
t27=C_eqp(t5,lf[618]);
if(C_truep(t27)){
t28=t20;
f_9500(t28,t27);}
else{
t28=C_eqp(t5,lf[619]);
if(C_truep(t28)){
t29=t20;
f_9500(t29,t28);}
else{
t29=C_eqp(t5,lf[620]);
if(C_truep(t29)){
t30=t20;
f_9500(t30,t29);}
else{
t30=C_eqp(t5,lf[633]);
t31=t20;
f_9500(t31,(C_truep(t30)?t30:C_eqp(t5,lf[634])));}}}}}}}}}}}}}}}}}}}}

/* k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_fcall f_9500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9500,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9503,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9524,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t3);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[628]);
t4=(C_truep(t3)?t3:C_eqp(((C_word*)t0)[4],lf[629]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9548,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t5);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[632]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9569,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t6);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[625]);
t7=(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[626]));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9593,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t8);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[627]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9614,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t9);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[630]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9635,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t10);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[13]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[827]);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[560]);
t12=(C_truep(t11)?t11:C_eqp(((C_word*)t0)[4],lf[639]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[828]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1345 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[615]))(4,*((C_word*)lf[615]+1),t13,C_retrieve(lf[616]),((C_word*)t0)[3]);}
else{
t14=t13;
f_9665(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9665,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9669,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* g23652366 */
t3=t2;
f_9669(t3,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9692,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t3=C_i_length(((C_word*)t0)[3]);
t4=t2;
f_9692(t4,C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_9692(t3,C_SCHEME_FALSE);}}}

/* k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_fcall f_9692(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9692,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_eqp(t2,lf[609]);
t4=(C_truep(t3)?t3:C_eqp(t2,lf[610]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9707,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t5);}
else{
t5=C_eqp(t2,lf[605]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t6);}
else{
t6=C_eqp(t2,lf[612]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t7);}
else{
t7=C_eqp(t2,lf[613]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t8);}
else{
t8=C_eqp(t2,lf[614]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t9);}
else{
t9=C_eqp(t2,lf[607]);
if(C_truep(t9)){
t10=C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1360 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),((C_word*)t0)[4],t10,((C_word*)t0)[3]);}
else{
t10=C_eqp(t2,lf[478]);
t11=(C_truep(t10)?t10:C_eqp(t2,lf[608]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t12);}
else{
t12=C_eqp(t2,lf[611]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t13);}
else{
t13=C_eqp(t2,lf[744]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t14);}
else{
/* c-backend.scm: 1365 err */
t14=((C_word*)t0)[2];
f_9391(t14,((C_word*)t0)[4]);}}}}}}}}}}
else{
/* c-backend.scm: 1366 err */
t2=((C_word*)t0)[2];
f_9391(t2,((C_word*)t0)[4]);}}

/* k9868 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9873,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[843],t1);}

/* k9871 in k9868 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9874 in k9871 in k9868 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9877 in k9874 in k9871 in k9868 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9847 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9852,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[842],t1);}

/* k9850 in k9847 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9855,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9853 in k9850 in k9847 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[841],((C_word*)t0)[2]);}

/* k9856 in k9853 in k9850 in k9847 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9826 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9831,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[840],t1);}

/* k9829 in k9826 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9832 in k9829 in k9826 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[839],((C_word*)t0)[2]);}

/* k9835 in k9832 in k9829 in k9826 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9789 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9794,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[838],t1);}

/* k9792 in k9789 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9795 in k9792 in k9789 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[837],((C_word*)t0)[2]);}

/* k9798 in k9795 in k9792 in k9789 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9768 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9773,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[836],t1);}

/* k9771 in k9768 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9774 in k9771 in k9768 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[835],((C_word*)t0)[2]);}

/* k9777 in k9774 in k9771 in k9768 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9747 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9752,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[834],t1);}

/* k9750 in k9747 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9755,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9753 in k9750 in k9747 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[833],((C_word*)t0)[2]);}

/* k9756 in k9753 in k9750 in k9747 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9726 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9731,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[832],t1);}

/* k9729 in k9726 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9732 in k9729 in k9726 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[831],((C_word*)t0)[2]);}

/* k9735 in k9732 in k9729 in k9726 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9705 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9710,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[830],t1);}

/* k9708 in k9705 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9713,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9711 in k9708 in k9705 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[829],((C_word*)t0)[2]);}

/* k9714 in k9711 in k9708 in k9705 in k9690 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* g2365 in k9663 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_fcall f_9669(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9669,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm: 1347 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t1,t3,((C_word*)t0)[2]);}
else{
t3=t2;
/* c-backend.scm: 1347 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t1,t3,((C_word*)t0)[2]);}}

/* k9633 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9638,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[826],t1);}

/* k9636 in k9633 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9639 in k9636 in k9633 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9642 in k9639 in k9636 in k9633 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9612 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9617,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[825],t1);}

/* k9615 in k9612 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9618 in k9615 in k9612 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9621 in k9618 in k9615 in k9612 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9591 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9596,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[824],t1);}

/* k9594 in k9591 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9597 in k9594 in k9591 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9600 in k9597 in k9594 in k9591 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9567 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9572,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[823],t1);}

/* k9570 in k9567 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9573 in k9570 in k9567 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9576 in k9573 in k9570 in k9567 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9546 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9551,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[822],t1);}

/* k9549 in k9546 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9552 in k9549 in k9546 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9555 in k9552 in k9549 in k9546 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9522 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9527,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[821],t1);}

/* k9525 in k9522 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9528 in k9525 in k9522 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[820],((C_word*)t0)[2]);}

/* k9531 in k9528 in k9525 in k9522 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9501 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9506,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[819],t1);}

/* k9504 in k9501 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9507 in k9504 in k9501 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[818],((C_word*)t0)[2]);}

/* k9510 in k9507 in k9504 in k9501 in k9498 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9477 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9482,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[817],t1);}

/* k9480 in k9477 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9483 in k9480 in k9477 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9486 in k9483 in k9480 in k9477 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9456 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9461,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[816],t1);}

/* k9459 in k9456 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9462 in k9459 in k9456 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9465 in k9462 in k9459 in k9456 in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-result-conversion in k2592 in k2506 in k2503 */
static void C_fcall f_9391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9391,NULL,2,t0,t1);}
/* c-backend.scm: 1321 quit */
((C_proc4)C_retrieve_symbol_proc(lf[667]))(4,*((C_word*)lf[667]+1),t1,lf[808],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_8899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8899,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8901,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=C_eqp(t4,lf[639]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[755]);}
else{
t6=C_eqp(t4,lf[16]);
t7=(C_truep(t6)?t6:C_eqp(t4,lf[640]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[756]);}
else{
t8=C_eqp(t4,lf[643]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8929,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_8929(t10,t8);}
else{
t10=C_eqp(t4,lf[635]);
if(C_truep(t10)){
t11=t9;
f_8929(t11,t10);}
else{
t11=C_eqp(t4,lf[641]);
if(C_truep(t11)){
t12=t9;
f_8929(t12,t11);}
else{
t12=C_eqp(t4,lf[642]);
t13=t9;
f_8929(t13,(C_truep(t12)?t12:C_eqp(t4,lf[644])));}}}}}}

/* k8927 in ##compiler#foreign-argument-conversion in k2592 in k2506 in k2503 */
static void C_fcall f_8929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8929,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[757]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[637]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[758]);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[638]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[759]);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[630]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[760]);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[624]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_8956(t7,t5);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[631]);
t8=t6;
f_8956(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[4],lf[596])));}}}}}}

/* k8954 in k8927 in ##compiler#foreign-argument-conversion in k2592 in k2506 in k2503 */
static void C_fcall f_8956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8956,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[761]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[628]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[629]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[762]);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[632]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[763]);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[627]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[764]);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[625]);
t7=(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[626]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[765]);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[478]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[766]);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[609]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[767]);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[752]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[768]);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[753]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[769]);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[770]);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[610]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[771]);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[690]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[772]);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[749]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[773]);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[687]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[774]);}
else{
t17=C_eqp(((C_word*)t0)[4],lf[688]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[775]);}
else{
t18=C_eqp(((C_word*)t0)[4],lf[750]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[776]);}
else{
t19=C_eqp(((C_word*)t0)[4],lf[751]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[777]);}
else{
t20=C_eqp(((C_word*)t0)[4],lf[692]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[778]);}
else{
t21=C_eqp(((C_word*)t0)[4],lf[693]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[779]);}
else{
t22=C_eqp(((C_word*)t0)[4],lf[698]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[780]);}
else{
t23=C_eqp(((C_word*)t0)[4],lf[699]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[781]);}
else{
t24=C_eqp(((C_word*)t0)[4],lf[695]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[782]);}
else{
t25=C_eqp(((C_word*)t0)[4],lf[696]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[783]);}
else{
t26=C_eqp(((C_word*)t0)[4],lf[701]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[784]);}
else{
t27=C_eqp(((C_word*)t0)[4],lf[702]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[785]);}
else{
t28=C_eqp(((C_word*)t0)[4],lf[704]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[786]);}
else{
t29=C_eqp(((C_word*)t0)[4],lf[705]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[787]);}
else{
t30=C_eqp(((C_word*)t0)[4],lf[707]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[788]);}
else{
t31=C_eqp(((C_word*)t0)[4],lf[708]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[789]);}
else{
t32=C_eqp(((C_word*)t0)[4],lf[710]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[790]);}
else{
t33=C_eqp(((C_word*)t0)[4],lf[711]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[791]);}
else{
t34=C_eqp(((C_word*)t0)[4],lf[598]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_9151(t36,t34);}
else{
t36=C_eqp(((C_word*)t0)[4],lf[621]);
if(C_truep(t36)){
t37=t35;
f_9151(t37,t36);}
else{
t37=C_eqp(((C_word*)t0)[4],lf[622]);
t38=t35;
f_9151(t38,(C_truep(t37)?t37:C_eqp(((C_word*)t0)[4],lf[623])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k9149 in k8954 in k8927 in ##compiler#foreign-argument-conversion in k2592 in k2506 in k2503 */
static void C_fcall f_9151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9151,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[792]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[602]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9160(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[617]);
if(C_truep(t4)){
t5=t3;
f_9160(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[618]);
if(C_truep(t5)){
t6=t3;
f_9160(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[619]);
t7=t3;
f_9160(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[620])));}}}}}

/* k9158 in k9149 in k8954 in k8927 in ##compiler#foreign-argument-conversion in k2592 in k2506 in k2503 */
static void C_fcall f_9160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9160,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[793]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[13]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[794]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1294 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[615]))(4,*((C_word*)lf[615]+1),t3,C_retrieve(lf[616]),((C_word*)t0)[3]);}
else{
t4=t3;
f_9169(2,t4,C_SCHEME_FALSE);}}}}

/* k9167 in k9158 in k9149 in k8954 in k8927 in ##compiler#foreign-argument-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9169,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=t1;
if(C_truep(C_i_vectorp(t3))){
t4=C_i_vector_ref(t3,C_fix(0));
/* c-backend.scm: 1296 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,t4);}
else{
/* c-backend.scm: 1296 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t3=C_i_length(((C_word*)t0)[3]);
t4=t2;
f_9196(t4,C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_9196(t3,C_SCHEME_FALSE);}}}

/* k9194 in k9167 in k9158 in k9149 in k8954 in k8927 in ##compiler#foreign-argument-conversion in k2592 in k2506 in k2503 */
static void C_fcall f_9196(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9196,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[4]);
t3=C_eqp(t2,lf[478]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[795]);}
else{
t4=C_eqp(t2,lf[609]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[796]);}
else{
t5=C_eqp(t2,lf[608]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[797]);}
else{
t6=C_eqp(t2,lf[610]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[798]);}
else{
t7=C_eqp(t2,lf[612]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[799]);}
else{
t8=C_eqp(t2,lf[613]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[800]);}
else{
t9=C_eqp(t2,lf[611]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[801]);}
else{
t10=C_eqp(t2,lf[607]);
if(C_truep(t10)){
t11=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1307 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),((C_word*)t0)[3],t11);}
else{
t11=C_eqp(t2,lf[744]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[802]);}
else{
t12=C_eqp(t2,lf[605]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9273,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t14=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1310 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t13,t14,lf[805]);}
else{
t13=C_eqp(t2,lf[614]);
if(C_truep(t13)){
t14=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1313 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[806],t14,lf[807]);}
else{
/* c-backend.scm: 1314 err */
t14=((C_word*)t0)[2];
f_8901(t14,((C_word*)t0)[3]);}}}}}}}}}}}}
else{
/* c-backend.scm: 1315 err */
t2=((C_word*)t0)[2];
f_8901(t2,((C_word*)t0)[3]);}}

/* k9271 in k9194 in k9167 in k9158 in k9149 in k8954 in k8927 in ##compiler#foreign-argument-conversion in k2592 in k2506 in k2503 */
static void C_ccall f_9273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1310 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[2],lf[803],t1,lf[804]);}

/* err in ##compiler#foreign-argument-conversion in k2592 in k2506 in k2503 */
static void C_fcall f_8901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8901,NULL,2,t0,t1);}
/* c-backend.scm: 1248 quit */
((C_proc4)C_retrieve_symbol_proc(lf[667]))(4,*((C_word*)lf[667]+1),t1,lf[754],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8015,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8017,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8022,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=C_eqp(t6,lf[639]);
if(C_truep(t7)){
/* c-backend.scm: 1155 str */
t8=t5;
f_8022(t8,t1,lf[670]);}
else{
t8=C_eqp(t6,lf[16]);
t9=(C_truep(t8)?t8:C_eqp(t6,lf[643]));
if(C_truep(t9)){
/* c-backend.scm: 1156 str */
t10=t5;
f_8022(t10,t1,lf[671]);}
else{
t10=C_eqp(t6,lf[640]);
t11=(C_truep(t10)?t10:C_eqp(t6,lf[644]));
if(C_truep(t11)){
/* c-backend.scm: 1157 str */
t12=t5;
f_8022(t12,t1,lf[672]);}
else{
t12=C_eqp(t6,lf[641]);
t13=(C_truep(t12)?t12:C_eqp(t6,lf[625]));
if(C_truep(t13)){
/* c-backend.scm: 1158 str */
t14=t5;
f_8022(t14,t1,lf[673]);}
else{
t14=C_eqp(t6,lf[642]);
t15=(C_truep(t14)?t14:C_eqp(t6,lf[626]));
if(C_truep(t15)){
/* c-backend.scm: 1159 str */
t16=t5;
f_8022(t16,t1,lf[674]);}
else{
t16=C_eqp(t6,lf[635]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8092,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_8092(t18,t16);}
else{
t18=C_eqp(t6,lf[628]);
t19=t17;
f_8092(t19,(C_truep(t18)?t18:C_eqp(t6,lf[13])));}}}}}}}

/* k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8092(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8092,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1160 str */
t2=((C_word*)t0)[7];
f_8022(t2,((C_word*)t0)[6],lf[675]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[636]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[5],lf[629]));
if(C_truep(t3)){
/* c-backend.scm: 1161 str */
t4=((C_word*)t0)[7];
f_8022(t4,((C_word*)t0)[6],lf[676]);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[632]);
if(C_truep(t4)){
/* c-backend.scm: 1162 str */
t5=((C_word*)t0)[7];
f_8022(t5,((C_word*)t0)[6],lf[677]);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[637]);
if(C_truep(t5)){
/* c-backend.scm: 1163 str */
t6=((C_word*)t0)[7];
f_8022(t6,((C_word*)t0)[6],lf[678]);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[627]);
if(C_truep(t6)){
/* c-backend.scm: 1164 str */
t7=((C_word*)t0)[7];
f_8022(t7,((C_word*)t0)[6],lf[679]);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[638]);
if(C_truep(t7)){
/* c-backend.scm: 1165 str */
t8=((C_word*)t0)[7];
f_8022(t8,((C_word*)t0)[6],lf[680]);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[630]);
if(C_truep(t8)){
/* c-backend.scm: 1166 str */
t9=((C_word*)t0)[7];
f_8022(t9,((C_word*)t0)[6],lf[681]);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[596]);
if(C_truep(t9)){
/* c-backend.scm: 1167 str */
t10=((C_word*)t0)[7];
f_8022(t10,((C_word*)t0)[6],lf[682]);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[624]);
t11=(C_truep(t10)?t10:C_eqp(((C_word*)t0)[5],lf[631]));
if(C_truep(t11)){
/* c-backend.scm: 1168 str */
t12=((C_word*)t0)[7];
f_8022(t12,((C_word*)t0)[6],lf[683]);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[478]);
t13=(C_truep(t12)?t12:C_eqp(((C_word*)t0)[5],lf[609]));
if(C_truep(t13)){
/* c-backend.scm: 1170 str */
t14=((C_word*)t0)[7];
f_8022(t14,((C_word*)t0)[6],lf[684]);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[608]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_8194(t16,t14);}
else{
t16=C_eqp(((C_word*)t0)[5],lf[610]);
if(C_truep(t16)){
t17=t15;
f_8194(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[5],lf[752]);
t18=t15;
f_8194(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[5],lf[753])));}}}}}}}}}}}}}

/* k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8194(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8194,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1171 str */
t2=((C_word*)t0)[7];
f_8022(t2,((C_word*)t0)[6],lf[685]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[633]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[5],lf[634]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[686]);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[687]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[688]));
if(C_truep(t5)){
/* c-backend.scm: 1174 str */
t6=((C_word*)t0)[7];
f_8022(t6,((C_word*)t0)[6],lf[689]);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[690]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_8227(t8,t6);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[749]);
if(C_truep(t8)){
t9=t7;
f_8227(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[750]);
t10=t7;
f_8227(t10,(C_truep(t9)?t9:C_eqp(((C_word*)t0)[5],lf[751])));}}}}}}

/* k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8227,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1175 str */
t2=((C_word*)t0)[7];
f_8022(t2,((C_word*)t0)[6],lf[691]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[692]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[5],lf[693]));
if(C_truep(t3)){
/* c-backend.scm: 1176 str */
t4=((C_word*)t0)[7];
f_8022(t4,((C_word*)t0)[6],lf[694]);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[695]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[696]));
if(C_truep(t5)){
/* c-backend.scm: 1177 str */
t6=((C_word*)t0)[7];
f_8022(t6,((C_word*)t0)[6],lf[697]);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[698]);
t7=(C_truep(t6)?t6:C_eqp(((C_word*)t0)[5],lf[699]));
if(C_truep(t7)){
/* c-backend.scm: 1178 str */
t8=((C_word*)t0)[7];
f_8022(t8,((C_word*)t0)[6],lf[700]);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[701]);
t9=(C_truep(t8)?t8:C_eqp(((C_word*)t0)[5],lf[702]));
if(C_truep(t9)){
/* c-backend.scm: 1179 str */
t10=((C_word*)t0)[7];
f_8022(t10,((C_word*)t0)[6],lf[703]);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[704]);
t11=(C_truep(t10)?t10:C_eqp(((C_word*)t0)[5],lf[705]));
if(C_truep(t11)){
/* c-backend.scm: 1180 str */
t12=((C_word*)t0)[7];
f_8022(t12,((C_word*)t0)[6],lf[706]);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[707]);
t13=(C_truep(t12)?t12:C_eqp(((C_word*)t0)[5],lf[708]));
if(C_truep(t13)){
/* c-backend.scm: 1181 str */
t14=((C_word*)t0)[7];
f_8022(t14,((C_word*)t0)[6],lf[709]);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[710]);
t15=(C_truep(t14)?t14:C_eqp(((C_word*)t0)[5],lf[711]));
if(C_truep(t15)){
/* c-backend.scm: 1182 str */
t16=((C_word*)t0)[7];
f_8022(t16,((C_word*)t0)[6],lf[712]);}
else{
t16=C_eqp(((C_word*)t0)[5],lf[602]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_8323(t18,t16);}
else{
t18=C_eqp(((C_word*)t0)[5],lf[598]);
if(C_truep(t18)){
t19=t17;
f_8323(t19,t18);}
else{
t19=C_eqp(((C_word*)t0)[5],lf[617]);
if(C_truep(t19)){
t20=t17;
f_8323(t20,t19);}
else{
t20=C_eqp(((C_word*)t0)[5],lf[621]);
t21=t17;
f_8323(t21,(C_truep(t20)?t20:C_eqp(((C_word*)t0)[5],lf[620])));}}}}}}}}}}}}

/* k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8323,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1184 str */
t2=((C_word*)t0)[7];
f_8022(t2,((C_word*)t0)[6],lf[713]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[618]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_8335(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[619]);
if(C_truep(t4)){
t5=t3;
f_8335(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[622]);
t6=t3;
f_8335(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[5],lf[623])));}}}}

/* k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8335(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8335,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1186 str */
t2=((C_word*)t0)[7];
f_8022(t2,((C_word*)t0)[6],lf[714]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[560]);
if(C_truep(t2)){
/* c-backend.scm: 1187 str */
t3=((C_word*)t0)[7];
f_8022(t3,((C_word*)t0)[6],lf[715]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1189 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[615]))(4,*((C_word*)lf[615]+1),t3,C_retrieve(lf[616]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8350(2,t4,C_SCHEME_FALSE);}}}}

/* k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8350,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8354,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* g19931994 */
t3=t2;
f_8354(t3,((C_word*)t0)[5],t1);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1192 str */
t2=((C_word*)t0)[3];
f_8022(t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[4]))){
t2=C_i_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8395,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t4=C_eqp(C_fix(2),t2);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[4]);
t6=t3;
f_8395(t6,C_i_memq(t5,lf[748]));}
else{
t5=t3;
f_8395(t5,C_SCHEME_FALSE);}}
else{
/* c-backend.scm: 1242 err */
t2=((C_word*)t0)[2];
f_8017(t2,((C_word*)t0)[5]);}}}}

/* k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8395,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8406,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1199 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t3,lf[716],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_eqp(C_fix(2),((C_word*)t0)[2]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[7]);
t5=t2;
f_8412(t5,C_eqp(lf[605],t4));}
else{
t4=t2;
f_8412(t4,C_SCHEME_FALSE);}}}

/* k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8412(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8412,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8423,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1202 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t3,lf[717],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[2],C_fix(2)))){
t3=C_i_car(((C_word*)t0)[7]);
t4=t2;
f_8429(t4,C_eqp(lf[747],t3));}
else{
t3=t2;
f_8429(t3,C_SCHEME_FALSE);}}}

/* k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8429(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8429,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8436,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8440,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1207 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t3,t4,lf[722]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[5]);
t5=t2;
f_8468(t5,C_eqp(lf[607],t4));}
else{
t4=t2;
f_8468(t4,C_SCHEME_FALSE);}}}

/* k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8468(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8468,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8475,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1214 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[5]);
t5=t2;
f_8485(t5,C_eqp(lf[746],t4));}
else{
t4=t2;
f_8485(t4,C_SCHEME_FALSE);}}}

/* k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8485(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8485,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8492,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1216 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8502(t5,C_eqp(lf[745],t4));}
else{
t4=t2;
f_8502(t4,C_SCHEME_FALSE);}}}

/* k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8502(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8502,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8509,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1218 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8519(t5,C_eqp(lf[744],t4));}
else{
t4=t2;
f_8519(t4,C_SCHEME_FALSE);}}}

/* k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8519,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8526,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1220 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8536(t5,C_i_memq(t4,lf[743]));}
else{
t4=t2;
f_8536(t4,C_SCHEME_FALSE);}}}

/* k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8536,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8543,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1222 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=t2;
f_8553(t5,C_eqp(lf[614],t4));}
else{
t4=t2;
f_8553(t4,C_SCHEME_FALSE);}}}

/* k8551 in k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8553(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8553,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8560,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1224 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(3)))){
t3=C_i_car(((C_word*)t0)[4]);
t4=t2;
f_8570(t4,C_eqp(lf[611],t3));}
else{
t3=t2;
f_8570(t3,C_SCHEME_FALSE);}}}

/* k8568 in k8551 in k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8570,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_i_caddr(((C_word*)t0)[5]);
t4=C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8582,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_8582(2,t6,lf[740]);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_8582(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[741]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[742],t4);}}}
else{
/* c-backend.scm: 1241 err */
t2=((C_word*)t0)[2];
f_8017(t2,((C_word*)t0)[4]);}}

/* k8580 in k8568 in k8551 in k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8589,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1230 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t2,((C_word*)t0)[2],lf[739]);}

/* k8587 in k8580 in k8568 in k8551 in k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8597,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8599,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_8599(t11,t7,((C_word*)t0)[2]);}

/* loop2054 in k8587 in k8580 in k8568 in k8551 in k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8599,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8609,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8639,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_slot(t2,C_fix(0));
t6=C_eqp(lf[736],t5);
if(C_truep(t6)){
t7=t3;
f_8609(t7,C_a_i_cons(&a,2,lf[737],C_SCHEME_END_OF_LIST));}
else{
/* c-backend.scm: 1237 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t4,t5,lf[738]);}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8637 in loop2054 in k8587 in k8580 in k8568 in k8551 in k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8639,2,t0,t1);}
t2=((C_word*)t0)[2];
f_8609(t2,C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k8607 in loop2054 in k8587 in k8580 in k8568 in k8551 in k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop20542067 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8599(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop20542067 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8599(t5,((C_word*)t0)[3],t4);}}

/* k8595 in k8587 in k8580 in k8568 in k8551 in k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1233 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[223]))(4,*((C_word*)lf[223]+1),((C_word*)t0)[2],t1,lf[735]);}

/* k8591 in k8587 in k8580 in k8568 in k8551 in k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1229 string-append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[115]+1)))(9,*((C_word*)lf[115]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[732],((C_word*)t0)[2],lf[733],t1,lf[734]);}

/* k8558 in k8551 in k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1224 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[3],t1,lf[731],((C_word*)t0)[2]);}

/* k8541 in k8534 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1222 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[3],t1,lf[730],((C_word*)t0)[2]);}

/* k8524 in k8517 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1220 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[115]+1)))(6,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[728],t1,lf[729],((C_word*)t0)[2]);}

/* k8507 in k8500 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1218 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[115]+1)))(6,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[726],t1,lf[727],((C_word*)t0)[2]);}

/* k8490 in k8483 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1216 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[115]+1)))(6,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[724],t1,lf[725],((C_word*)t0)[2]);}

/* k8473 in k8466 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1214 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[2],lf[723],t1);}

/* k8438 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8444,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8448,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8450,tmp=(C_word)a,a+=2,tmp);
t5=C_i_cddr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[227]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8449 in k8438 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8450,3,t0,t1,t2);}
t3=C_retrieve(lf[174]);
/* g20282029 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[721]);}

/* k8446 in k8438 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1209 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[223]))(4,*((C_word*)lf[223]+1),((C_word*)t0)[2],t1,lf[720]);}

/* k8442 in k8438 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1206 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[115]+1)))(6,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[718],t1,lf[719]);}

/* k8434 in k8427 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1205 str */
t2=((C_word*)t0)[3];
f_8022(t2,((C_word*)t0)[2],t1);}

/* k8421 in k8410 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1202 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8404 in k8393 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_ccall f_8406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1199 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g1993 in k8348 in k8333 in k8321 in k8225 in k8192 in k8090 in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8354(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8354,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm: 1191 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t1,t3,((C_word*)t0)[2]);}
else{
t3=t2;
/* c-backend.scm: 1191 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t1,t3,((C_word*)t0)[2]);}}

/* str in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8022(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8022,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1153 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),t1,t2,lf[669],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k2592 in k2506 in k2503 */
static void C_fcall f_8017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8017,NULL,2,t0,t1);}
/* c-backend.scm: 1152 quit */
((C_proc4)C_retrieve_symbol_proc(lf[667]))(4,*((C_word*)lf[667]+1),t1,lf[668],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7950,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7954,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1134 foreign-callback-stub-name */
((C_proc3)C_retrieve_symbol_proc(lf[666]))(3,*((C_word*)lf[666]+1),t4,t3);}

/* k7952 in ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7957,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1135 foreign-callback-stub-qualifiers */
((C_proc3)C_retrieve_symbol_proc(lf[665]))(3,*((C_word*)lf[665]+1),t2,((C_word*)t0)[2]);}

/* k7955 in k7952 in ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_7957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1136 foreign-callback-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[661]))(3,*((C_word*)lf[661]+1),t2,((C_word*)t0)[2]);}

/* k7958 in k7955 in k7952 in ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_7960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7963,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1137 foreign-callback-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[660]))(3,*((C_word*)lf[660]+1),t2,((C_word*)t0)[2]);}

/* k7961 in k7958 in k7955 in k7952 in ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_7963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7963,2,t0,t1);}
t2=C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1139 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[294]))(4,*((C_word*)lf[294]+1),t3,t2,lf[664]);}

/* k7967 in k7961 in k7958 in k7955 in k7952 in ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_7969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7972,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1140 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t3,((C_word*)t0)[2],lf[663]);}

/* k8011 in k7967 in k7961 in k7958 in k7955 in k7952 in ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1140 gen */
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k7970 in k7967 in k7961 in k7958 in k7955 in k7952 in ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_7972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7975,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7980,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1141 pair-for-each */
((C_proc5)C_retrieve_symbol_proc(lf[203]))(5,*((C_word*)lf[203]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7979 in k7970 in k7967 in k7961 in k7958 in k7955 in k7952 in ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_7980(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7980,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7984,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8001,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_i_car(t3);
t7=C_i_car(t2);
/* c-backend.scm: 1143 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t5,t6,t7);}

/* k7999 in a7979 in k7970 in k7967 in k7961 in k7958 in k7955 in k7952 in ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_8001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1143 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* k7982 in a7979 in k7970 in k7967 in k7961 in k7958 in k7955 in k7952 in ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
if(C_truep(C_i_pairp(t2))){
/* c-backend.scm: 1144 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7973 in k7970 in k7967 in k7961 in k7958 in k7955 in k7952 in ##compiler#generate-foreign-callback-header in k2592 in k2506 in k2503 */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1146 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7456,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7462,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7462(t7,t1,t2);}

/* loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7462(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7462,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7470,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7937,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g15201521 */
t6=t3;
f_7470(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7935 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7462(t3,((C_word*)t0)[2],t2);}

/* g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7470(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7470,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7474,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1081 foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[662]))(3,*((C_word*)lf[662]+1),t3,t2);}

/* k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7477,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1082 real-name2 */
((C_proc4)C_retrieve_symbol_proc(lf[594]))(4,*((C_word*)lf[594]+1),t2,t1,((C_word*)t0)[2]);}

/* k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7480,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1083 foreign-callback-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[661]))(3,*((C_word*)lf[661]+1),t2,((C_word*)t0)[2]);}

/* k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1084 foreign-callback-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[660]))(3,*((C_word*)lf[660]+1),t2,((C_word*)t0)[3]);}

/* k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7483,2,t0,t1);}
t2=C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1086 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[294]))(4,*((C_word*)lf[294]+1),t3,t2,lf[659]);}

/* k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7489,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7491,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1113 fold */
((C_proc6)C_retrieve_symbol_proc(lf[439]))(6,*((C_word*)lf[439]+1),t5,((C_word*)t3)[1],lf[658],((C_word*)t0)[4],t1);}

/* k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1114 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7934,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1116 cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[503]))(3,*((C_word*)lf[503]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_7841(2,t3,C_SCHEME_UNDEFINED);}}

/* k7932 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1116 gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[656],t1,lf[657]);}

/* k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7844,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1117 generate-foreign-callback-header */
((C_proc4)C_retrieve_symbol_proc(lf[547]))(4,*((C_word*)lf[547]+1),t2,lf[655],((C_word*)t0)[2]);}

/* k7842 in k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1118 gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_make_character(123),C_SCHEME_TRUE,lf[653],((C_word*)t0)[2],lf[654]);}

/* k7845 in k7842 in k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1119 gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[652]);}

/* k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7853,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7883,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7883(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1767 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7883(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7883,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7902,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7899,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1122 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t9,t8,lf[651]);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7897 in loop1767 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1122 gen */
((C_proc9)C_retrieve_proc(*((C_word*)lf[1]+1)))(9,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[648],t1,((C_word*)t0)[2],lf[649],C_SCHEME_TRUE,lf[650]);}

/* k7900 in loop1767 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7883(t4,((C_word*)t0)[2],t2,t3);}

/* k7851 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_eqp(lf[560],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_7856(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7881,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1127 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t4,((C_word*)t0)[4]);}}

/* k7879 in k7851 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1127 gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[647],t1);}

/* k7854 in k7851 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7859,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1128 gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,lf[646],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k7857 in k7854 in k7851 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7862,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_eqp(lf[560],((C_word*)t0)[2]);
if(C_truep(t3)){
/* c-backend.scm: 1130 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[645]);}
else{
/* c-backend.scm: 1129 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k7860 in k7857 in k7854 in k7851 in k7848 in k7845 in k7842 in k7839 in k7836 in k7833 in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1130 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[645]);}

/* compute-size in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7491,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=C_eqp(t5,lf[16]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7501,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7501(t8,t6);}
else{
t8=C_eqp(t5,lf[635]);
if(C_truep(t8)){
t9=t7;
f_7501(t9,t8);}
else{
t9=C_eqp(t5,lf[636]);
if(C_truep(t9)){
t10=t7;
f_7501(t10,t9);}
else{
t10=C_eqp(t5,lf[637]);
if(C_truep(t10)){
t11=t7;
f_7501(t11,t10);}
else{
t11=C_eqp(t5,lf[13]);
if(C_truep(t11)){
t12=t7;
f_7501(t12,t11);}
else{
t12=C_eqp(t5,lf[560]);
if(C_truep(t12)){
t13=t7;
f_7501(t13,t12);}
else{
t13=C_eqp(t5,lf[638]);
if(C_truep(t13)){
t14=t7;
f_7501(t14,t13);}
else{
t14=C_eqp(t5,lf[639]);
if(C_truep(t14)){
t15=t7;
f_7501(t15,t14);}
else{
t15=C_eqp(t5,lf[640]);
if(C_truep(t15)){
t16=t7;
f_7501(t16,t15);}
else{
t16=C_eqp(t5,lf[641]);
if(C_truep(t16)){
t17=t7;
f_7501(t17,t16);}
else{
t17=C_eqp(t5,lf[642]);
if(C_truep(t17)){
t18=t7;
f_7501(t18,t17);}
else{
t18=C_eqp(t5,lf[643]);
t19=t7;
f_7501(t19,(C_truep(t18)?t18:C_eqp(t5,lf[644])));}}}}}}}}}}}}

/* k7499 in compute-size in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7501,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[596]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7510(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[624]);
if(C_truep(t4)){
t5=t3;
f_7510(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[608]);
if(C_truep(t5)){
t6=t3;
f_7510(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[625]);
if(C_truep(t6)){
t7=t3;
f_7510(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[626]);
if(C_truep(t7)){
t8=t3;
f_7510(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[627]);
if(C_truep(t8)){
t9=t3;
f_7510(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[628]);
if(C_truep(t9)){
t10=t3;
f_7510(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[629]);
if(C_truep(t10)){
t11=t3;
f_7510(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[5],lf[630]);
if(C_truep(t11)){
t12=t3;
f_7510(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[610]);
if(C_truep(t12)){
t13=t3;
f_7510(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[5],lf[631]);
if(C_truep(t13)){
t14=t3;
f_7510(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[632]);
if(C_truep(t14)){
t15=t3;
f_7510(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[5],lf[633]);
t16=t3;
f_7510(t16,(C_truep(t15)?t15:C_eqp(((C_word*)t0)[5],lf[634])));}}}}}}}}}}}}}}

/* k7508 in k7499 in compute-size in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7510(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7510,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1095 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[597]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[598]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7522(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[621]);
if(C_truep(t4)){
t5=t3;
f_7522(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[622]);
if(C_truep(t5)){
t6=t3;
f_7522(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[622]);
t7=t3;
f_7522(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[5],lf[623])));}}}}}

/* k7520 in k7508 in k7499 in compute-size in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7522,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1097 string-append */
((C_proc8)C_retrieve_proc(*((C_word*)lf[115]+1)))(8,*((C_word*)lf[115]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[599],((C_word*)t0)[5],lf[600],((C_word*)t0)[5],lf[601]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[602]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_7534(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[617]);
if(C_truep(t4)){
t5=t3;
f_7534(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[618]);
if(C_truep(t5)){
t6=t3;
f_7534(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[619]);
t7=t3;
f_7534(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[620])));}}}}}

/* k7532 in k7520 in k7508 in k7499 in compute-size in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7534(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7534,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1099 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[115]+1)))(6,*((C_word*)lf[115]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[603],((C_word*)t0)[4],lf[604]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1101 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[615]))(4,*((C_word*)lf[615]+1),t2,C_retrieve(lf[616]),((C_word*)t0)[2]);}
else{
t3=t2;
f_7540(2,t3,C_SCHEME_FALSE);}}}

/* k7538 in k7532 in k7520 in k7508 in k7499 in compute-size in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7540,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7544,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* g17141715 */
t3=t2;
f_7544(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[605]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7579,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_7579(t5,t3);}
else{
t5=C_eqp(t2,lf[478]);
if(C_truep(t5)){
t6=t4;
f_7579(t6,t5);}
else{
t6=C_eqp(t2,lf[608]);
if(C_truep(t6)){
t7=t4;
f_7579(t7,t6);}
else{
t7=C_eqp(t2,lf[609]);
if(C_truep(t7)){
t8=t4;
f_7579(t8,t7);}
else{
t8=C_eqp(t2,lf[610]);
if(C_truep(t8)){
t9=t4;
f_7579(t9,t8);}
else{
t9=C_eqp(t2,lf[611]);
if(C_truep(t9)){
t10=t4;
f_7579(t10,t9);}
else{
t10=C_eqp(t2,lf[612]);
if(C_truep(t10)){
t11=t4;
f_7579(t11,t10);}
else{
t11=C_eqp(t2,lf[613]);
t12=t4;
f_7579(t12,(C_truep(t11)?t11:C_eqp(t2,lf[614])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}}

/* k7577 in k7538 in k7532 in k7520 in k7508 in k7499 in compute-size in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1108 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[606]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[607]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1109 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7491(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* g1714 in k7538 in k7532 in k7520 in k7508 in k7499 in compute-size in k7487 in k7481 in k7478 in k7475 in k7472 in g1520 in loop1513 in generate-foreign-callback-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7544(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7544,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm: 1103 compute-size */
t4=((C_word*)((C_word*)t0)[4])[1];
f_7491(5,t4,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
/* c-backend.scm: 1103 compute-size */
t4=((C_word*)((C_word*)t0)[4])[1];
f_7491(5,t4,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7142,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7148,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7148(t7,t1,t2);}

/* loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7148(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7148,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7156,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7443,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g14091410 */
t6=t3;
f_7156(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7441 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7148(t3,((C_word*)t0)[2],t2);}

/* g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7156(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7156,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7160,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1014 foreign-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[595]))(3,*((C_word*)lf[595]+1),t3,t2);}

/* k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7163,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1015 real-name2 */
((C_proc4)C_retrieve_symbol_proc(lf[594]))(4,*((C_word*)lf[594]+1),t2,t1,((C_word*)t0)[2]);}

/* k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7166,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1016 foreign-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[593]))(3,*((C_word*)lf[593]+1),t2,((C_word*)t0)[2]);}

/* k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7166,2,t0,t1);}
t2=C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7440,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1018 make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[284]))(4,*((C_word*)lf[284]+1),t4,t2,lf[592]);}

/* k7438 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7440,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[591],t1);
/* c-backend.scm: 1018 intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t2,C_make_character(44));}

/* k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1019 foreign-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[590]))(3,*((C_word*)lf[590]+1),t2,((C_word*)t0)[2]);}

/* k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1020 foreign-stub-name */
((C_proc3)C_retrieve_symbol_proc(lf[589]))(3,*((C_word*)lf[589]+1),t2,((C_word*)t0)[2]);}

/* k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1021 foreign-stub-body */
((C_proc3)C_retrieve_symbol_proc(lf[588]))(3,*((C_word*)lf[588]+1),t2,((C_word*)t0)[2]);}

/* k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1022 foreign-stub-argument-names */
((C_proc3)C_retrieve_symbol_proc(lf[587]))(3,*((C_word*)lf[587]+1),t2,((C_word*)t0)[2]);}

/* k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_7187(2,t3,t1);}
else{
/* c-backend.scm: 1022 make-list */
((C_proc4)C_retrieve_symbol_proc(lf[247]))(4,*((C_word*)lf[247]+1),t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 1023 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t2,((C_word*)t0)[9],lf[586]);}

/* k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1024 foreign-stub-cps */
((C_proc3)C_retrieve_symbol_proc(lf[585]))(3,*((C_word*)lf[585]+1),t2,((C_word*)t0)[2]);}

/* k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1025 foreign-stub-callback */
((C_proc3)C_retrieve_symbol_proc(lf[584]))(3,*((C_word*)lf[584]+1),t2,((C_word*)t0)[2]);}

/* k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1026 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7429,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1028 cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[503]))(3,*((C_word*)lf[503]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_7202(2,t3,C_SCHEME_UNDEFINED);}}

/* k7427 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1028 gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[582],t1,lf[583]);}

/* k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1030 gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[580],((C_word*)t0)[6],lf[581]);}
else{
t3=t2;
f_7205(2,t3,C_SCHEME_UNDEFINED);}}

/* k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1033 gen */
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[575],((C_word*)t0)[2],lf[576],C_SCHEME_TRUE,lf[577],((C_word*)t0)[2],lf[578]);}
else{
/* c-backend.scm: 1035 gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[579],((C_word*)t0)[2],C_make_character(40));}}

/* k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[3]);}

/* k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1038 gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,lf[570],C_SCHEME_TRUE,lf[571],((C_word*)t0)[2],lf[572]);}
else{
/* c-backend.scm: 1039 gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,lf[573],C_SCHEME_TRUE,lf[574],((C_word*)t0)[2],C_make_character(40));}}

/* k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1041 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[569]);}

/* k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1042 gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[568]);}

/* k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7226,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1051 iota */
((C_proc3)C_retrieve_symbol_proc(lf[60]))(3,*((C_word*)lf[60]+1),t3,((C_word*)t0)[6]);}

/* k7318 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7320,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7322,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7322(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop1436 in k7318 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7322(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7322,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7329,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_pairp(t3);
t7=t5;
f_7329(t7,(C_truep(t6)?C_i_pairp(t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_7329(t6,C_SCHEME_FALSE);}}

/* k7327 in loop1436 in k7318 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_fcall f_7329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7329,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(0));
t4=C_slot(((C_word*)t0)[5],C_fix(0));
t5=C_slot(((C_word*)t0)[4],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7338,a[2]=t3,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7350,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
/* c-backend.scm: 1048 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t7,t5);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7356,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t8);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k7354 in k7327 in loop1436 in k7318 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7359,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(116),t1);}

/* k7357 in k7354 in k7327 in loop1436 in k7318 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k7360 in k7357 in k7354 in k7327 in loop1436 in k7318 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7348 in k7327 in loop1436 in k7318 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1046 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7336 in k7327 in loop1436 in k7318 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1049 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t2,((C_word*)t0)[2],lf[567]);}

/* k7340 in k7336 in k7327 in loop1436 in k7318 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7346,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1050 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2]);}

/* k7344 in k7340 in k7336 in k7327 in loop1436 in k7318 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1045 gen */
((C_proc11)C_retrieve_proc(*((C_word*)lf[1]+1)))(11,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[564],((C_word*)t0)[3],C_make_character(41),t1,lf[565],((C_word*)t0)[2],lf[566]);}

/* k7366 in k7327 in loop1436 in k7318 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_7322(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1052 gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[563]);}
else{
t3=t2;
f_7229(2,t3,C_SCHEME_UNDEFINED);}}

/* k7227 in k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7232,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7238,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1054 gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[554]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7259,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_eqp(((C_word*)t0)[5],lf[560]);
if(C_truep(t4)){
/* c-backend.scm: 1065 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1064 gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[562],((C_word*)t0)[2]);}}}

/* k7257 in k7227 in k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7262,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1066 gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(40));}

/* k7260 in k7257 in k7227 in k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7296,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7300,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1067 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[294]))(4,*((C_word*)lf[294]+1),t4,((C_word*)t0)[2],lf[561]);}

/* k7298 in k7260 in k7257 in k7227 in k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1067 intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k7294 in k7260 in k7257 in k7227 in k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k7263 in k7260 in k7257 in k7227 in k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7268,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(((C_word*)t0)[2],lf[560]);
if(C_truep(t3)){
t4=t2;
f_7268(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1068 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k7266 in k7263 in k7260 in k7257 in k7227 in k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1069 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[559]);}

/* k7269 in k7266 in k7263 in k7260 in k7257 in k7227 in k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1071 gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[555],C_SCHEME_TRUE,lf[556]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1073 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[557]);}
else{
/* c-backend.scm: 1074 gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[558]);}}}

/* k7236 in k7227 in k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1056 gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[553],C_SCHEME_TRUE);}

/* k7239 in k7236 in k7227 in k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1058 gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[549],C_SCHEME_TRUE,lf[550]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1060 gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[551]);}
else{
/* c-backend.scm: 1061 gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[552]);}}}

/* k7230 in k7227 in k7224 in k7221 in k7218 in k7215 in k7212 in k7209 in k7206 in k7203 in k7200 in k7197 in k7194 in k7191 in k7188 in k7185 in k7182 in k7179 in k7176 in k7173 in k7170 in k7164 in k7161 in k7158 in g1409 in loop1402 in ##compiler#generate-foreign-stubs in k2592 in k2506 in k2503 */
static void C_ccall f_7232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1075 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2592 in k2506 in k2503 */
static void C_ccall f_7102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7102,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7108,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7108(t6,t1,t2);}

/* loop1383 in ##compiler#generate-foreign-callback-stub-prototypes in k2592 in k2506 in k2503 */
static void C_fcall f_7108(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7108,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7129,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7120,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1006 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7118 in loop1383 in ##compiler#generate-foreign-callback-stub-prototypes in k2592 in k2506 in k2503 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7123,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1007 generate-foreign-callback-header */
((C_proc4)C_retrieve_symbol_proc(lf[547]))(4,*((C_word*)lf[547]+1),t2,lf[548],((C_word*)t0)[2]);}

/* k7121 in k7118 in loop1383 in ##compiler#generate-foreign-callback-stub-prototypes in k2592 in k2506 in k2503 */
static void C_ccall f_7123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1008 gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k7127 in loop1383 in ##compiler#generate-foreign-callback-stub-prototypes in k2592 in k2506 in k2503 */
static void C_ccall f_7129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7108(t3,((C_word*)t0)[2],t2);}

/* ##compiler#generate-external-variables in k2592 in k2506 in k2503 */
static void C_ccall f_7048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7048,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7052,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 991  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}

/* k7050 in ##compiler#generate-external-variables in k2592 in k2506 in k2503 */
static void C_ccall f_7052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7052,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7057,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7057(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1363 in k7050 in ##compiler#generate-external-variables in k2592 in k2506 in k2503 */
static void C_fcall f_7057(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7057,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7089,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_vector_ref(t4,C_fix(0));
t6=C_i_vector_ref(t4,C_fix(1));
t7=C_i_vector_ref(t4,C_fix(2));
t8=(C_truep(t7)?lf[545]:lf[546]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7086,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 997  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t9,t6,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7084 in loop1363 in k7050 in ##compiler#generate-external-variables in k2592 in k2506 in k2503 */
static void C_ccall f_7086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 997  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* k7087 in loop1363 in k7050 in ##compiler#generate-external-variables in k2592 in k2506 in k2503 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7057(t3,((C_word*)t0)[2],t2);}

/* ##compiler#make-argument-list in k2592 in k2506 in k2503 */
static void C_ccall f_7032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7032,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7038,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 983  list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[544]))(4,*((C_word*)lf[544]+1),t1,t2,t4);}

/* a7037 in ##compiler#make-argument-list in k2592 in k2506 in k2503 */
static void C_ccall f_7038(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7038,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7046,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 985  number->string */
C_number_to_string(3,0,t3,t2);}

/* k7044 in a7037 in ##compiler#make-argument-list in k2592 in k2506 in k2503 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 985  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k2592 in k2506 in k2503 */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7016,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7022,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 978  list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[544]))(4,*((C_word*)lf[544]+1),t1,t2,t4);}

/* a7021 in ##compiler#make-variable-list in k2592 in k2506 in k2503 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7022,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7030,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 980  number->string */
C_number_to_string(3,0,t3,t2);}

/* k7028 in a7021 in ##compiler#make-variable-list in k2592 in k2506 in k2503 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 980  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[543],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k2592 in k2506 in k2503 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6927,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6936,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6936(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k2592 in k2506 in k2503 */
static void C_fcall f_6936(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6936,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=C_i_string_ref(((C_word*)t0)[3],t2);
t5=C_fixnum_lessp(t4,C_make_character(32));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6965,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_6965(t7,t5);}
else{
t7=C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t7)){
t8=t6;
f_6965(t8,t7);}
else{
t8=C_eqp(t4,C_make_character(42));
if(C_truep(t8)){
t9=C_fixnum_decrease(((C_word*)t0)[5]);
t10=t2;
if(C_truep(C_fixnum_lessp(t10,t9))){
t11=C_fixnum_increase(t2);
t12=C_i_string_ref(((C_word*)t0)[3],t11);
t13=t6;
f_6965(t13,C_eqp(C_make_character(47),t12));}
else{
t11=t6;
f_6965(t11,C_SCHEME_FALSE);}}
else{
t9=t6;
f_6965(t9,C_SCHEME_FALSE);}}}}}

/* k6963 in loop in ##compiler#cleanup in k2592 in k2506 in k2503 */
static void C_fcall f_6965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6965,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=C_i_string_set(((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_make_character(126));
t3=C_fixnum_increase(((C_word*)t0)[6]);
/* c-backend.scm: 972  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_6936(t4,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6975,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 969  string-copy */
((C_proc3)C_retrieve_symbol_proc(lf[542]))(3,*((C_word*)lf[542]+1),t2,((C_word*)t0)[3]);}}
else{
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=C_i_string_set(((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[2]);
t3=C_fixnum_increase(((C_word*)t0)[6]);
/* c-backend.scm: 972  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_6936(t4,((C_word*)t0)[4],t3);}
else{
t2=C_fixnum_increase(((C_word*)t0)[6]);
/* c-backend.scm: 972  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6936(t3,((C_word*)t0)[4],t2);}}}

/* k6973 in k6963 in loop in ##compiler#cleanup in k2592 in k2506 in k2503 */
static void C_ccall f_6975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_make_character(126));
t4=C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 972  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6936(t5,((C_word*)t0)[2],t4);}

/* emit-procedure-table-info in k2592 in k2506 in k2503 */
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6850,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6854,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_length(t2);
t6=C_fixnum_increase(t5);
/* c-backend.scm: 934  gen */
((C_proc9)C_retrieve_proc(*((C_word*)lf[1]+1)))(9,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[539],C_SCHEME_TRUE,lf[540],t6,lf[541]);}

/* k6852 in emit-procedure-table-info in k2592 in k2506 in k2503 */
static void C_ccall f_6854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6857,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6868,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6868(t6,t2,((C_word*)t0)[2]);}

/* doloop1305 in k6852 in emit-procedure-table-info in k2592 in k2506 in k2503 */
static void C_fcall f_6868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6868,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* c-backend.scm: 938  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,lf[531]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6881,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
/* c-backend.scm: 939  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t3,t4);}}

/* k6879 in doloop1305 in k6852 in emit-procedure-table-info in k2592 in k2506 in k2503 */
static void C_ccall f_6881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6884,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6913,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 940  string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[538]))(3,*((C_word*)lf[538]+1),t3,((C_word*)t0)[2]);}

/* k6911 in k6879 in doloop1305 in k6852 in emit-procedure-table-info in k2592 in k2506 in k2503 */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 940  gen */
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[536],((C_word*)t0)[2],C_make_character(58),t1,lf[537]);}

/* k6882 in k6879 in doloop1305 in k6852 in emit-procedure-table-info in k2592 in k2506 in k2503 */
static void C_ccall f_6884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6887,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(lf[262],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[213]))){
/* c-backend.scm: 943  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[532],C_retrieve(lf[213]),lf[533]);}
else{
/* c-backend.scm: 944  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[534]);}}
else{
/* c-backend.scm: 945  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[535]);}}

/* k6885 in k6882 in k6879 in doloop1305 in k6852 in emit-procedure-table-info in k2592 in k2506 in k2503 */
static void C_ccall f_6887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6868(t3,((C_word*)t0)[2],t2);}

/* k6855 in k6852 in emit-procedure-table-info in k2592 in k2506 in k2503 */
static void C_ccall f_6857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6860,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 946  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[530]);}

/* k6858 in k6855 in k6852 in emit-procedure-table-info in k2592 in k2506 in k2503 */
static void C_ccall f_6860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6863,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 947  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[529]);}

/* k6861 in k6858 in k6855 in k6852 in emit-procedure-table-info in k2592 in k2506 in k2503 */
static void C_ccall f_6863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 948  gen */
((C_proc15)C_retrieve_proc(*((C_word*)lf[1]+1)))(15,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[522],C_SCHEME_TRUE,lf[523],C_SCHEME_TRUE,lf[524],C_SCHEME_TRUE,lf[525],C_SCHEME_TRUE,lf[526],C_SCHEME_TRUE,lf[527],C_SCHEME_TRUE,lf[528]);}

/* ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word ab[78],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_2596,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t34=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2641,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4522,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t36=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4691,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t37=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4862,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t38=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5196,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t39=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5516,a[2]=t2,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t40=C_set_block_item(t24,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5571,a[2]=t24,tmp=(C_word)a,a+=3,tmp));
t41=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5765,a[2]=t28,tmp=(C_word)a,a+=3,tmp));
t42=C_set_block_item(t28,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5907,a[2]=t30,tmp=(C_word)a,a+=3,tmp));
t43=C_set_block_item(t30,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5984,tmp=(C_word)a,a+=2,tmp));
t44=C_set_block_item(t32,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6032,a[2]=t4,a[3]=t8,a[4]=t24,a[5]=t22,a[6]=t2,a[7]=t12,tmp=(C_word)a,a+=8,tmp));
t45=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6817,a[2]=t14,a[3]=t16,a[4]=t18,a[5]=t8,a[6]=t20,a[7]=t32,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 917  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[504]))(4,*((C_word*)lf[504]+1),t45,lf[520],lf[521]);}

/* k6815 in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6817,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##compiler#output ...) */,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6821,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 919  header */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4522(t4,t3);}

/* k6819 in k6815 in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 920  declarations */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4691(t3,t2);}

/* k6822 in k6819 in k6815 in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 921  generate-external-variables */
((C_proc3)C_retrieve_symbol_proc(lf[518]))(3,*((C_word*)lf[518]+1),t2,C_retrieve(lf[519]));}

/* k6825 in k6822 in k6819 in k6815 in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 922  generate-foreign-stubs */
((C_proc4)C_retrieve_symbol_proc(lf[516]))(4,*((C_word*)lf[516]+1),t2,C_retrieve(lf[517]),((C_word*)t0)[3]);}

/* k6828 in k6825 in k6822 in k6819 in k6815 in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 923  prototypes */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4862(t3,t2);}

/* k6831 in k6828 in k6825 in k6822 in k6819 in k6815 in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 924  generate-foreign-callback-stubs */
((C_proc4)C_retrieve_symbol_proc(lf[515]))(4,*((C_word*)lf[515]+1),t2,C_retrieve(lf[207]),((C_word*)t0)[2]);}

/* k6834 in k6831 in k6828 in k6825 in k6822 in k6819 in k6815 in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 925  trampolines */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5196(t3,t2);}

/* k6837 in k6834 in k6831 in k6828 in k6825 in k6822 in k6819 in k6815 in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 926  procedures */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6032(t3,t2);}

/* k6840 in k6837 in k6834 in k6831 in k6828 in k6825 in k6822 in k6819 in k6815 in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6845,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 927  emit-procedure-table-info */
((C_proc4)C_retrieve_symbol_proc(lf[514]))(4,*((C_word*)lf[514]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6843 in k6840 in k6837 in k6834 in k6831 in k6828 in k6825 in k6822 in k6819 in k6815 in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 488  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[513],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6032,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6038,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_6038(t5,t1,((C_word*)t0)[2]);}

/* loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6038(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6038,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6046,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6803,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g10241025 */
t6=t3;
f_6046(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6801 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6038(t3,((C_word*)t0)[2],t2);}

/* g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6046(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6046,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 736  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),t3,t2);}

/* k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 737  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[6]);}

/* k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6056,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 738  real-name */
((C_proc4)C_retrieve_symbol_proc(lf[512]))(4,*((C_word*)lf[512]+1),t2,t1,((C_word*)t0)[2]);}

/* k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6059,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 739  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[280]))(3,*((C_word*)lf[280]+1),t2,((C_word*)t0)[6]);}

/* k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 740  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t2,((C_word*)t0)[7]);}

/* k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6062,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 741  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),t4,((C_word*)t0)[8]);}

/* k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6800,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 742  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_6068(t3,C_SCHEME_FALSE);}}

/* k6798 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6068(t2,C_eqp(t1,C_fix(0)));}

/* k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6068(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6068,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fixnum_difference(((C_word*)t0)[13],C_fix(1)):C_a_i_minus(&a,2,((C_word*)t0)[13],C_fix(0)));
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6074,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 744  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[284]))(4,*((C_word*)lf[284]+1),t3,((C_word*)t0)[13],lf[511]);}

/* k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6077,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 745  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[294]))(4,*((C_word*)lf[294]+1),t2,((C_word*)t0)[13],lf[510]);}

/* k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6080,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=C_i_cdr(((C_word*)t0)[2]);
/* c-backend.scm: 746  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,t3,C_make_character(44));}
else{
t3=((C_word*)t0)[2];
/* c-backend.scm: 746  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,t3,C_make_character(44));}}

/* k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6083,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=C_i_cdr(((C_word*)t0)[2]);
/* c-backend.scm: 747  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,t3,C_make_character(44));}
else{
t3=((C_word*)t0)[2];
/* c-backend.scm: 747  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t2,t3,C_make_character(44));}}

/* k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_6086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 748  lambda-literal-external */
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),t2,((C_word*)t0)[12]);}

/* k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_6089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 749  lambda-literal-looping */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t2,((C_word*)t0)[13]);}

/* k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_6092,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 750  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t2,((C_word*)t0)[14]);}

/* k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_6095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 751  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t2,((C_word*)t0)[15]);}

/* k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_6098,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 752  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),t2,((C_word*)t0)[16]);}

/* k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_6101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 753  lambda-literal-unboxed-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[509]))(3,*((C_word*)lf[509]+1),t2,((C_word*)t0)[17]);}

/* k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6104,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(C_retrieve(lf[213]))){
/* c-backend.scm: 755  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t2,C_retrieve(lf[213]),lf[507]);}
else{
t3=t2;
f_6104(2,t3,lf[508]);}}

/* k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_6107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[6])){
/* c-backend.scm: 757  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[504]))(5,*((C_word*)lf[504]+1),t2,lf[505],lf[506],((C_word*)t0)[15]);}
else{
t3=t2;
f_6107(2,t3,C_SCHEME_UNDEFINED);}}

/* k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_6110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* c-backend.scm: 758  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],tmp=(C_word)a,a+=24,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6769,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 759  cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[503]))(3,*((C_word*)lf[503]+1),t3,((C_word*)t0)[2]);}

/* k6767 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 759  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[501],t1,lf[502],C_SCHEME_TRUE);}

/* k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=C_eqp(lf[262],((C_word*)t0)[15]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6752,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 768  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t4,lf[495]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6730,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[15],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 761  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t4,lf[500]);}}

/* k6728 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 762  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[498]);}
else{
/* c-backend.scm: 762  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[499]);}}

/* k6731 in k6728 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6736,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 764  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[496]);}
else{
/* c-backend.scm: 765  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[497]);}}

/* k6734 in k6731 in k6728 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 766  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6750 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[213]))){
t3=t2;
f_6755(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 770  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[494]);}}

/* k6753 in k6750 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 771  gen */
((C_proc16)C_retrieve_proc(*((C_word*)lf[1]+1)))(16,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[488],C_SCHEME_TRUE,lf[489],C_SCHEME_TRUE,lf[490],C_SCHEME_TRUE,lf[491],((C_word*)t0)[2],lf[492],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[493],((C_word*)t0)[2]);}

/* k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 776  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[12])){
t3=t2;
f_6122(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 777  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[487]);}}

/* k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6702,a[2]=t2,a[3]=((C_word*)t0)[16],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[11])){
t4=C_eqp(((C_word*)t0)[18],C_fix(0));
t5=t3;
f_6702(t5,C_i_not(t4));}
else{
t4=t3;
f_6702(t4,C_SCHEME_FALSE);}}

/* k6700 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6702(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6702,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 779  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[486]);}
else{
t2=((C_word*)t0)[2];
f_6125(2,t2,C_SCHEME_UNDEFINED);}}

/* k6703 in k6700 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 780  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_6125(2,t3,t2);}}

/* k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[16]);}

/* k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)((C_word*)t0)[22])[1])){
/* c-backend.scm: 782  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[485]);}
else{
t3=t2;
f_6131(2,t3,C_SCHEME_UNDEFINED);}}

/* k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 783  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[484]);}

/* k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=C_eqp(((C_word*)t0)[3],lf[251]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[22],0,C_SCHEME_FALSE);
t5=t2;
f_6137(t5,t4);}
else{
t4=t2;
f_6137(t4,C_SCHEME_UNDEFINED);}}

/* k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6137,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 785  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[483]);}

/* k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_6143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[22])[1])){
/* c-backend.scm: 787  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[472],((C_word*)t0)[21],C_make_character(59));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6615,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6662,a[2]=((C_word*)t0)[21],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=C_fixnum_decrease(((C_word*)t0)[21]);
t6=t4;
f_6662(t6,C_fixnum_plus(((C_word*)t0)[17],t5));}
else{
t5=t4;
f_6662(t5,((C_word*)t0)[17]);}}}

/* k6660 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6662,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6664,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6664(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* doloop1077 in k6660 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6664(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6664,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6674,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 792  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[482],t2,C_make_character(59));}}

/* k6672 in doloop1077 in k6660 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_increase(((C_word*)t0)[5]);
t3=C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_6664(t4,((C_word*)t0)[2],t2,t3);}

/* k6613 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6615,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6620,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6620(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1087 in k6613 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6620(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6620,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6647,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6636,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t4);
t7=C_eqp(t6,lf[473]);
if(C_truep(t7)){
t8=C_i_car(t4);
/* c-backend.scm: 795  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[474],C_make_character(32),t8,C_make_character(59));}
else{
t8=C_eqp(t6,lf[475]);
if(C_truep(t8)){
t9=C_i_car(t4);
/* c-backend.scm: 795  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[476],C_make_character(32),t9,C_make_character(59));}
else{
t9=C_eqp(t6,lf[16]);
if(C_truep(t9)){
t10=C_i_car(t4);
/* c-backend.scm: 795  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[477],C_make_character(32),t10,C_make_character(59));}
else{
t10=C_eqp(t6,lf[478]);
if(C_truep(t10)){
t11=C_i_car(t4);
/* c-backend.scm: 795  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[479],C_make_character(32),t11,C_make_character(59));}
else{
t11=C_eqp(t6,lf[13]);
if(C_truep(t11)){
t12=C_i_car(t4);
/* c-backend.scm: 795  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[480],C_make_character(32),t12,C_make_character(59));}
else{
/* c-backend.scm: 731  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t5,lf[481],t6);}}}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6634 in loop1087 in k6613 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 795  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,t1,C_make_character(32),t2,C_make_character(59));}

/* k6645 in loop1087 in k6613 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6620(t3,((C_word*)t0)[2],t2);}

/* k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6146,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[16],a[10]=((C_word*)t0)[17],a[11]=((C_word*)t0)[18],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[20],a[14]=((C_word*)t0)[21],a[15]=((C_word*)t0)[22],tmp=(C_word)a,a+=16,tmp);
t3=C_eqp(lf[262],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6333,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6408,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 798  fold */
((C_proc5)C_retrieve_symbol_proc(lf[439]))(5,*((C_word*)lf[439]+1),t4,t5,C_fix(0),((C_word*)t0)[8]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6422,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 832  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[453]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6486,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t2,a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6564,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[10];
if(C_truep(t6)){
t7=t5;
f_6564(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_6564(t8,C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k6562 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6564,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 846  gen */
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[463],C_SCHEME_TRUE,lf[464],C_SCHEME_TRUE,lf[465],((C_word*)t0)[3],lf[466]);}
else{
/* c-backend.scm: 849  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[467],((C_word*)t0)[3],lf[468]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6576,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_6576(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 851  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[471]);}}}

/* k6574 in k6562 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 852  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[470]);}
else{
t3=t2;
f_6579(2,t3,C_SCHEME_UNDEFINED);}}

/* k6577 in k6574 in k6562 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
t2=C_retrieve(lf[131]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_6486(2,t4,t3);}
else{
t3=C_retrieve(lf[433]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
f_6486(2,t5,t4);}
else{
/* c-backend.scm: 856  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[469]);}}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_6486(2,t3,t2);}}

/* k6484 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6489,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6528,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[131]);
if(C_truep(t4)){
t5=t3;
f_6528(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[447]);
t6=t3;
f_6528(t6,(C_truep(t5)?C_SCHEME_FALSE:C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_6528(t4,C_SCHEME_FALSE);}}

/* k6526 in k6484 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6528(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[4],lf[251]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep(C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 860  gen */
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[457],((C_word*)t0)[3],lf[458],((C_word*)t0)[3],lf[459]);}
else{
t4=((C_word*)t0)[2];
f_6489(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 861  gen */
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[460],((C_word*)t0)[3],lf[461],((C_word*)t0)[3],lf[462]);}}
else{
t2=((C_word*)t0)[2];
f_6489(2,t2,C_SCHEME_UNDEFINED);}}

/* k6487 in k6484 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6495,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_6495(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=((C_word*)t0)[2];
t5=t2;
f_6495(t5,t4);}
else{
t4=((C_word*)t0)[5];
t5=t2;
f_6495(t5,C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k6493 in k6487 in k6484 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6495(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6495,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[442]))){
/* c-backend.scm: 863  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[456]);}
else{
t3=t2;
f_6498(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_6146(2,t2,C_SCHEME_UNDEFINED);}}

/* k6496 in k6493 in k6487 in k6484 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=((C_word*)t0)[3];
if(C_truep(C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 865  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[454]);}
else{
/* c-backend.scm: 866  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[455]);}}
else{
/* c-backend.scm: 866  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[455]);}}

/* k6420 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 833  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[452]);}

/* k6423 in k6420 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 834  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[451]);}

/* k6426 in k6423 in k6420 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
t4=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 836  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 837  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[450]);}}

/* k6429 in k6426 in k6423 in k6420 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 838  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[448],((C_word*)t0)[3],lf[449]);}

/* k6432 in k6429 in k6426 in k6423 in k6420 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6437,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6449,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[131]);
if(C_truep(t4)){
t5=t3;
f_6449(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[447]);
if(C_truep(t5)){
t6=t3;
f_6449(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_6449(t8,(C_truep(t7)?C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k6447 in k6432 in k6429 in k6426 in k6423 in k6420 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 840  gen */
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[444],((C_word*)t0)[2],lf[445],((C_word*)t0)[2],lf[446]);}
else{
t2=((C_word*)t0)[3];
f_6437(2,t2,C_SCHEME_UNDEFINED);}}

/* k6435 in k6432 in k6429 in k6426 in k6423 in k6420 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[442]))){
/* c-backend.scm: 841  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[443]);}
else{
/* c-backend.scm: 842  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[440],((C_word*)t0)[2],lf[441]);}}

/* k6438 in k6435 in k6432 in k6429 in k6426 in k6423 in k6420 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 842  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[440],((C_word*)t0)[2],lf[441]);}

/* a6407 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6408,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6416,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 798  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5571(t5,t4,t2);}

/* k6414 in a6407 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6339,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 800  gen */
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[435],C_SCHEME_TRUE,lf[436],C_SCHEME_TRUE,lf[437],((C_word*)t0)[2],lf[438]);}

/* k6337 in k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[433]))){
/* c-backend.scm: 804  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[434]);}
else{
t3=t2;
f_6342(2,t3,C_SCHEME_UNDEFINED);}}

/* k6340 in k6337 in k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[213]))){
t3=t2;
f_6345(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6376,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[426]))){
/* c-backend.scm: 807  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[427],C_retrieve(lf[426]),lf[428]);}
else{
if(C_truep(C_retrieve(lf[429]))){
/* c-backend.scm: 809  gen */
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[430],C_retrieve(lf[429]),lf[431],C_SCHEME_TRUE,lf[432]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t3;
f_6376(2,t5,t4);}}}}

/* k6374 in k6340 in k6337 in k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[424]))){
/* c-backend.scm: 812  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[425],C_retrieve(lf[424]),C_make_character(59));}
else{
t3=t2;
f_6379(2,t3,C_SCHEME_UNDEFINED);}}

/* k6377 in k6374 in k6340 in k6337 in k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[422]))){
/* c-backend.scm: 814  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[423],C_retrieve(lf[422]),C_make_character(59));}
else{
t3=t2;
f_6382(2,t3,C_SCHEME_UNDEFINED);}}

/* k6380 in k6377 in k6374 in k6340 in k6337 in k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve(lf[419]))){
/* c-backend.scm: 816  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[420],C_retrieve(lf[419]),lf[421]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_6345(2,t3,t2);}}

/* k6343 in k6340 in k6337 in k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 817  gen */
((C_proc16)C_retrieve_proc(*((C_word*)lf[1]+1)))(16,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[412],((C_word*)t0)[3],lf[413],C_SCHEME_TRUE,lf[414],((C_word*)t0)[3],lf[415],C_SCHEME_TRUE,lf[416],C_SCHEME_TRUE,lf[417],C_SCHEME_TRUE,lf[418]);}

/* k6346 in k6343 in k6340 in k6337 in k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 822  gen */
((C_proc14)C_retrieve_proc(*((C_word*)lf[1]+1)))(14,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[406],((C_word*)t0)[2],lf[407],C_SCHEME_TRUE,lf[408],C_SCHEME_TRUE,lf[409],((C_word*)t0)[2],lf[410],C_SCHEME_TRUE,lf[411]);}

/* k6349 in k6346 in k6343 in k6340 in k6337 in k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6354,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 826  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[404],((C_word*)t0)[2],lf[405]);}

/* k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6354,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_6146(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 828  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[402],((C_word*)t0)[4],lf[403]);}}

/* k6361 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 829  literal-frame */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5516(t3,t2);}

/* k6364 in k6361 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6331 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 830  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[400],((C_word*)t0)[2],lf[401]);}

/* k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6149,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6169,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[13],a[9]=t2,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[14],tmp=(C_word)a,a+=12,tmp);
t4=C_eqp(lf[262],((C_word*)t0)[7]);
if(C_truep(t4)){
t5=t3;
f_6169(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_6169(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[14])[1];
if(C_truep(t6)){
t7=t3;
f_6169(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=((C_word*)t0)[2];
t8=t3;
f_6169(t8,t7);}
else{
t7=((C_word*)t0)[10];
t8=t3;
f_6169(t8,C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6169,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[11])[1])){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0)))){
/* c-backend.scm: 877  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[391],lf[392],((C_word*)t0)[8],C_make_character(114));}
else{
/* c-backend.scm: 877  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[393],lf[392],((C_word*)t0)[8],C_make_character(114));}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6274,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0)))){
/* c-backend.scm: 900  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[397],lf[398]);}
else{
/* c-backend.scm: 900  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[399],lf[398]);}}}
else{
t2=((C_word*)t0)[9];
f_6149(2,t2,C_SCHEME_UNDEFINED);}}

/* k6272 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6277,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 902  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[3],lf[395]);}
else{
/* c-backend.scm: 903  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[396],((C_word*)t0)[3]);}}

/* k6275 in k6272 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6280,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6289,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 905  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
/* c-backend.scm: 907  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[4],lf[394]);}}

/* k6287 in k6275 in k6272 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k6278 in k6275 in k6272 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 907  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[394]);}

/* k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 878  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[389],((C_word*)t0)[4],lf[390]);}

/* k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6181,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6261,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 880  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_6181(2,t3,C_SCHEME_UNDEFINED);}}

/* k6259 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 882  gen */
((C_proc9)C_retrieve_proc(*((C_word*)lf[1]+1)))(9,*((C_word*)lf[1]+1),t2,lf[385],C_SCHEME_TRUE,lf[386],C_SCHEME_TRUE,lf[387],((C_word*)t0)[5],lf[388]);}

/* k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 885  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[383],((C_word*)t0)[5],lf[384]);}

/* k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 886  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[382]);}

/* k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6251,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6255,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 887  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[294]))(4,*((C_word*)lf[294]+1),t4,((C_word*)t0)[5],lf[381]);}

/* k6253 in k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 887  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k6249 in k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k6191 in k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 888  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[379],((C_word*)t0)[5],lf[380]);}

/* k6194 in k6191 in k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 890  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[377],((C_word*)t0)[2],lf[378]);}

/* k6197 in k6194 in k6191 in k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k6200 in k6197 in k6194 in k6191 in k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 892  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[375],((C_word*)t0)[3],lf[376]);}

/* k6203 in k6200 in k6197 in k6194 in k6191 in k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 893  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[374]);}

/* k6206 in k6203 in k6200 in k6197 in k6194 in k6191 in k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6211,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6226,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_6226(t7,t2,t3,((C_word*)t0)[2]);}

/* doloop1227 in k6206 in k6203 in k6200 in k6197 in k6194 in k6191 in k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_6226(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6226,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6236,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 897  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[373],t2,C_make_character(59));}}

/* k6234 in doloop1227 in k6206 in k6203 in k6200 in k6197 in k6194 in k6191 in k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6226(t4,((C_word*)t0)[2],t2,t3);}

/* k6209 in k6206 in k6203 in k6200 in k6197 in k6194 in k6191 in k6188 in k6185 in k6182 in k6179 in k6176 in k6173 in k6167 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep(C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 898  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[371],((C_word*)t0)[3],lf[372]);}
else{
t3=((C_word*)t0)[2];
f_6149(2,t3,C_SCHEME_UNDEFINED);}}

/* k6147 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6152,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6159,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 909  lambda-literal-body */
((C_proc3)C_retrieve_symbol_proc(lf[370]))(3,*((C_word*)lf[370]+1),t3,((C_word*)t0)[2]);}

/* k6157 in k6147 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_fixnum_increase(((C_word*)t0)[5]);
/* c-backend.scm: 908  expression */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2641(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
/* c-backend.scm: 908  expression */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2641(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}}

/* k6150 in k6147 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6123 in k6120 in k6117 in k6114 in k6111 in k6108 in k6105 in k6102 in k6099 in k6096 in k6093 in k6090 in k6087 in k6084 in k6081 in k6078 in k6075 in k6072 in k6066 in k6063 in k6060 in k6057 in k6054 in k6051 in k6048 in g1024 in loop1017 in procedures in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 914  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* string-like-substring in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5984(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5984,NULL,4,t1,t2,t3,t4);}
t5=C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5991,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 720  make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[369]+1)))(3,*((C_word*)lf[369]+1),t6,t5);}

/* k5989 in string-like-substring in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5994,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 721  ##sys#copy-bytes */
((C_proc7)C_retrieve_symbol_proc(lf[368]))(7,*((C_word*)lf[368]+1),t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5992 in k5989 in string-like-substring in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* gen-string-constant in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5907(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5907,NULL,3,t0,t1,t2);}
t3=C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5914,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 709  fx/ */
((C_proc4)C_retrieve_proc(*((C_word*)lf[367]+1)))(4,*((C_word*)lf[367]+1),t4,t3,C_fix(80));}

/* k5912 in gen-string-constant in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5917,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 710  modulo */
((C_proc4)C_retrieve_proc(*((C_word*)lf[366]+1)))(4,*((C_word*)lf[366]+1),t2,((C_word*)t0)[5],C_fix(80));}

/* k5915 in k5912 in gen-string-constant in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5917,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5922,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5922(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop987 in k5915 in k5912 in gen-string-constant in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5922(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5922,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5938,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5938(t7,t5);}
else{
t7=C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_5938(t8,C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5959,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5974,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5978,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 716  string-like-substring */
f_5984(t7,((C_word*)t0)[4],t3,t8);}}

/* k5976 in doloop987 in k5915 in k5912 in gen-string-constant in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 716  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k5972 in doloop987 in k5915 in k5912 in gen-string-constant in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 716  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k5957 in doloop987 in k5915 in k5912 in gen-string-constant in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_decrease(((C_word*)t0)[5]);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5922(t4,((C_word*)t0)[2],t2,t3);}

/* k5936 in doloop987 in k5915 in k5912 in gen-string-constant in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5938(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5938,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5945,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5949,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 715  string-like-substring */
f_5984(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5947 in k5936 in doloop987 in k5915 in k5912 in gen-string-constant in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 715  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k5943 in k5936 in doloop987 in k5915 in k5912 in gen-string-constant in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 715  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* gen-lit in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5765(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5765,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5772,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5905,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 682  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[365]))(3,*((C_word*)lf[365]+1),t5,t2);}
else{
t5=t4;
f_5772(t5,C_SCHEME_FALSE);}}

/* k5903 in gen-lit in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5772(t2,C_i_not(t1));}

/* k5770 in gen-lit in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5772(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5772,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 683  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[350],((C_word*)t0)[3],lf[351]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 684  block-variable-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[348]))(3,*((C_word*)lf[348]+1),t2,((C_word*)t0)[3]);}}

/* k5776 in k5770 in gen-lit in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5778,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[352]);
t3=C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t3)){
/* c-backend.scm: 686  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],lf[353]);}
else{
if(C_truep(C_booleanp(((C_word*)t0)[4]))){
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 688  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],C_make_character(61),lf[354],C_make_character(59));}
else{
/* c-backend.scm: 688  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],C_make_character(61),lf[355],C_make_character(59));}}
else{
if(C_truep(C_charp(((C_word*)t0)[4]))){
t4=C_fix(C_character_code(((C_word*)t0)[4]));
/* c-backend.scm: 690  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],lf[356],t4,lf[357]);}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
t4=C_slot(((C_word*)t0)[4],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 693  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t5,t4);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
/* c-backend.scm: 698  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],lf[361]);}
else{
t4=C_immp(((C_word*)t0)[4]);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_lambdainfop(((C_word*)t0)[4]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_fixnump(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_5861(t8,t6);}
else{
t8=C_immp(((C_word*)t0)[4]);
t9=t7;
f_5861(t9,C_i_not(t8));}}}}}}}}}

/* k5859 in k5776 in k5770 in gen-lit in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5861,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 702  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[364]);}
else{
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[3];
/* c-backend.scm: 659  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t2,lf[345],t3);}}

/* k5862 in k5859 in k5776 in k5770 in gen-lit in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5874,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 703  encode-literal */
((C_proc3)C_retrieve_symbol_proc(lf[363]))(3,*((C_word*)lf[363]+1),t3,((C_word*)t0)[2]);}

/* k5872 in k5862 in k5859 in k5776 in k5770 in gen-lit in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 703  gen-string-constant */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5907(t2,((C_word*)t0)[2],t1);}

/* k5865 in k5862 in k5859 in k5776 in k5770 in gen-lit in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 704  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[362]);}

/* k5826 in k5776 in k5770 in gen-lit in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5828,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5834,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 695  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[360]);}

/* k5832 in k5826 in k5776 in k5770 in gen-lit in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 696  gen */
((C_proc9)C_retrieve_proc(*((C_word*)lf[1]+1)))(9,*((C_word*)lf[1]+1),((C_word*)t0)[5],lf[358],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[359]);}

/* literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5571(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5571,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5578,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 662  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t3,t2);}

/* k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5578,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep(C_i_numberp(((C_word*)t0)[3]))){
t2=C_retrieve(lf[341]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 666  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5571(t4,t2,t3);}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
t2=C_i_vector_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5638,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5642,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5646,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 667  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[344]+1)))(3,*((C_word*)lf[344]+1),t9,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 668  block-variable-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[348]))(3,*((C_word*)lf[348]+1),t2,((C_word*)t0)[3]);}}}}}}}

/* k5685 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5687,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep(C_immp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
/* c-backend.scm: 659  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t2,lf[345],t3);}
else{
if(C_truep(C_lambdainfop(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 671  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[347]+1)))(3,*((C_word*)lf[347]+1),t2,((C_word*)t0)[3]);}}}}

/* k5703 in k5685 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5705,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5712,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* c-backend.scm: 671  words */
((C_proc3)C_retrieve_symbol_proc(lf[346]))(3,*((C_word*)lf[346]+1),t2,t3);}
else{
if(C_truep(C_structurep(((C_word*)t0)[3]))){
t2=C_block_size(((C_word*)t0)[3]);
t3=C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5734(t7,((C_word*)t0)[4],C_fix(0),t3);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
/* c-backend.scm: 659  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t2,lf[345],t3);}}}

/* loop in k5703 in k5685 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5734(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5734,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5756,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 677  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_5571(t8,t6,t7);}}

/* k5754 in loop in k5703 in k5685 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 677  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5734(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5710 in k5703 in k5685 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fixnum_plus(C_fix(2),t1));}

/* k5644 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5648(t5,((C_word*)t0)[2],t1);}

/* loop922 in k5644 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5648(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5648,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5677,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g938939 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5571(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5675 in loop922 in k5644 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5677,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop922935 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5648(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop922935 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5648(t6,((C_word*)t0)[3],t5);}}

/* k5640 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 667  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[342]))(5,*((C_word*)lf[342]+1),((C_word*)t0)[2],*((C_word*)lf[343]+1),C_fix(0),t1);}

/* k5636 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fixnum_plus(C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k5607 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5613,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 666  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5571(t4,t2,t3);}

/* k5611 in k5607 in k5576 in literal-size in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fixnum_plus(C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5516(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5516,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5522,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5522(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* doloop896 in literal-frame in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5522(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5522,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5532,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5551,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[340]))(2,*((C_word*)lf[340]+1),t6);}}

/* k5549 in doloop896 in literal-frame in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t2,lf[339],t1);}

/* k5552 in k5549 in doloop896 in literal-frame in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[338]+1)))(4,*((C_word*)lf[338]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5555 in k5552 in k5549 in doloop896 in literal-frame in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[337]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(93),((C_word*)t0)[2]);}

/* k5558 in k5555 in k5552 in k5549 in doloop896 in literal-frame in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[336]))(3,*((C_word*)lf[336]+1),t2,((C_word*)t0)[2]);}

/* k5561 in k5558 in k5555 in k5552 in k5549 in doloop896 in literal-frame in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 656  gen-lit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5765(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5530 in doloop896 in literal-frame in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_increase(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_5522(t4,((C_word*)t0)[2],t2,t3);}

/* trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5196(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5196,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5199,tmp=(C_word)a,a+=2,tmp));
t11=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5235,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5315,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5385,a[2]=t14,a[3]=t3,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_5385(t16,t12,((C_word*)t0)[2]);}

/* loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5385(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5385,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5393,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5503,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g817818 */
t6=t3;
f_5393(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5501 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5385(t3,((C_word*)t0)[2],t2);}

/* g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5393(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5393,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5397,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 617  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),t3,t2);}

/* k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5397,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 618  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t4,((C_word*)t0)[2]);}

/* k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5403,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 619  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t2,((C_word*)t0)[2]);}

/* k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5406,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 620  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[2]);}

/* k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 621  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),t2,((C_word*)t0)[2]);}

/* k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5500,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 622  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_5412(t3,C_SCHEME_FALSE);}}

/* k5498 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5412(t2,C_eqp(t1,C_fix(0)));}

/* k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5412(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5412,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=C_fixnum_decrease(((C_word*)((C_word*)t0)[9])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[9])+1,t3);
t5=t2;
f_5415(t5,t4);}
else{
t3=t2;
f_5415(t3,C_SCHEME_UNDEFINED);}}

/* k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5415,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 624  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t2,((C_word*)t0)[2]);}

/* k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5421,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(((C_word*)t0)[10])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5427,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 626  gen */
((C_proc11)C_retrieve_proc(*((C_word*)lf[1]+1)))(11,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[331],((C_word*)t0)[8],lf[332],C_SCHEME_TRUE,lf[333],((C_word*)t0)[8],lf[334]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_5455(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5489,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 634  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[280]))(3,*((C_word*)lf[280]+1),t3,((C_word*)t0)[2]);}}}}

/* k5487 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_5455(2,t3,t2);}
else{
/* c-backend.scm: 634  lambda-literal-external */
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5453 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5455,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=C_eqp(((C_word*)t0)[2],lf[251]);
t4=t2;
f_5461(t4,C_i_not(t3));}
else{
t3=t2;
f_5461(t3,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5459 in k5453 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5461(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5461,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5465,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 636  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[277]))(5,*((C_word*)lf[277]+1),t2,*((C_word*)lf[278]+1),((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5469,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 637  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[277]))(5,*((C_word*)lf[277]+1),t2,*((C_word*)lf[278]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]);}}

/* k5467 in k5459 in k5453 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5463 in k5459 in k5453 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5425 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 628  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[329],((C_word*)t0)[3],lf[330]);}

/* k5428 in k5425 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 629  restore */
f_5199(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k5431 in k5428 in k5425 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 630  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k5434 in k5431 in k5428 in k5425 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5439,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 631  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[294]))(4,*((C_word*)lf[294]+1),t2,((C_word*)((C_word*)t0)[2])[1],lf[328]);}

/* k5437 in k5434 in k5431 in k5428 in k5425 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5449,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 632  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,t1,C_make_character(44));}

/* k5447 in k5437 in k5434 in k5431 in k5428 in k5425 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5419 in k5413 in k5410 in k5407 in k5404 in k5401 in k5398 in k5395 in g817 in loop779 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 633  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[327]);}

/* k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5318,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5334,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5334(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop862 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5334(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5334,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5342,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5372,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g869870 */
t6=t3;
f_5342(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5370 in loop862 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5334(t3,((C_word*)t0)[2],t2);}

/* g869 in loop862 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5342(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5342,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 641  gen */
((C_proc13)C_retrieve_proc(*((C_word*)lf[1]+1)))(13,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[322],t2,lf[323],C_SCHEME_TRUE,lf[324],t2,lf[325],t2,lf[326]);}

/* k5344 in g869 in loop862 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 643  gen */
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[319],((C_word*)t0)[3],lf[320],((C_word*)t0)[3],lf[321]);}

/* k5347 in k5344 in g869 in loop862 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5352,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 644  restore */
f_5199(t2,((C_word*)t0)[3]);}

/* k5350 in k5347 in k5344 in g869 in loop862 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 645  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[318],((C_word*)t0)[2],C_make_character(44));}

/* k5353 in k5350 in k5347 in k5344 in g869 in loop862 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5358,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5365,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5369,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 646  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[294]))(4,*((C_word*)lf[294]+1),t4,((C_word*)t0)[2],lf[317]);}

/* k5367 in k5353 in k5350 in k5347 in k5344 in g869 in loop862 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 646  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k5363 in k5353 in k5350 in k5347 in k5344 in g869 in loop862 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k5356 in k5353 in k5350 in k5347 in k5344 in g869 in loop862 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 647  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[316]);}

/* k5316 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5321,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5332,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 649  emitter */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5235(t4,t3,C_SCHEME_FALSE);}

/* k5330 in k5316 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[315]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5319 in k5316 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5328,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 650  emitter */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5235(t3,t2,C_SCHEME_TRUE);}

/* k5326 in k5319 in k5316 in k5313 in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[315]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* emitter in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5235,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5237,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_5237 in emitter in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5237(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5237,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[310]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[311]);
/* c-backend.scm: 595  gen */
((C_proc14)C_retrieve_proc(*((C_word*)lf[1]+1)))(14,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[312],t2,C_make_character(114),t4,lf[313],C_SCHEME_TRUE,lf[314],t2,C_make_character(114),t5);}

/* k5239 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 597  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[308],((C_word*)t0)[4],lf[309]);}

/* k5242 in k5239 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 598  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[307],((C_word*)t0)[4],C_make_character(114));}

/* k5245 in k5242 in k5239 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 599  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(118));}
else{
t3=t2;
f_5250(2,t3,C_SCHEME_UNDEFINED);}}

/* k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 600  gen */
((C_proc11)C_retrieve_proc(*((C_word*)lf[1]+1)))(11,*((C_word*)lf[1]+1),t2,lf[303],((C_word*)t0)[4],lf[304],C_SCHEME_TRUE,lf[305],C_SCHEME_TRUE,lf[306],((C_word*)t0)[4],C_make_character(59));}

/* k5251 in k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5256,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 603  restore */
f_5199(t2,((C_word*)t0)[4]);}

/* k5254 in k5251 in k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 604  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[302]);}

/* k5257 in k5254 in k5251 in k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 606  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[300]);}
else{
/* c-backend.scm: 607  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[301]);}}

/* k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 608  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[299]);}

/* k5263 in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5268,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 609  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[298]);}
else{
t3=t2;
f_5268(2,t3,C_SCHEME_UNDEFINED);}}

/* k5266 in k5263 in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 610  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[297]);}

/* k5269 in k5266 in k5263 in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 611  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[296]);}

/* k5272 in k5269 in k5266 in k5263 in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5277,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5284,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5288,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 612  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[294]))(4,*((C_word*)lf[294]+1),t4,t5,lf[295]);}

/* k5286 in k5272 in k5269 in k5266 in k5263 in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 612  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k5282 in k5272 in k5269 in k5266 in k5263 in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k5275 in k5272 in k5269 in k5266 in k5263 in k5260 in k5257 in k5254 in k5251 in k5248 in k5245 in k5242 in k5239 */
static void C_ccall f_5277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 613  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[293]);}

/* restore in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5199(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5199,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5203,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5212,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_5212(t8,t3,t4,C_fix(0));}

/* doloop787 in restore in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5212(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5212,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5222,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 590  gen */
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[290],t2,lf[291],t3,lf[292]);}}

/* k5220 in doloop787 in restore in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5212(t4,((C_word*)t0)[2],t2,t3);}

/* k5201 in restore in trampolines in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 591  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[288],((C_word*)t0)[2],lf[289]);}

/* prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4862,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4866,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 521  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE);}

/* k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4935,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4935(t6,t2,((C_word*)t0)[2]);}

/* loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4935(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4935,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4943,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5183,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g665666 */
t6=t3;
f_4943(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5181 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4935(t3,((C_word*)t0)[2],t2);}

/* g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4943(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4943,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4947,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 524  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),t3,t2);}

/* k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 525  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),t2,((C_word*)t0)[2]);}

/* k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5180,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 526  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4953(t3,C_SCHEME_FALSE);}}

/* k5178 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4953(t2,C_eqp(t1,C_fix(0)));}

/* k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4953,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5166,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=C_fixnum_decrease(((C_word*)t0)[5]);
/* c-backend.scm: 527  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[284]))(4,*((C_word*)lf[284]+1),t3,t4,lf[285]);}
else{
t4=((C_word*)t0)[5];
/* c-backend.scm: 527  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[284]))(4,*((C_word*)lf[284]+1),t3,t4,lf[285]);}}

/* k5164 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 527  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 528  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[2]);}

/* k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 529  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t2,((C_word*)t0)[2]);}

/* k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 530  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t2,((C_word*)t0)[2]);}

/* k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 531  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t2,((C_word*)t0)[2]);}

/* k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 532  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[280]))(3,*((C_word*)lf[280]+1),t2,((C_word*)t0)[2]);}

/* k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[276]);
if(C_truep(C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5158,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 534  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[277]))(5,*((C_word*)lf[277]+1),t5,*((C_word*)lf[278]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_4974(t5,C_SCHEME_UNDEFINED);}}

/* k5156 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4974(t3,t2);}

/* k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4974,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 535  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5112,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 540  lambda-literal-callee-signatures */
((C_proc3)C_retrieve_symbol_proc(lf[279]))(3,*((C_word*)lf[279]+1),t3,((C_word*)t0)[2]);}

/* k5110 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5112,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5114,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5114(t5,((C_word*)t0)[2],t1);}

/* loop684 in k5110 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5114(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5114,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5140,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g691692 */
t6=t3;
f_5122(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5138 in loop684 in k5110 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5114(t3,((C_word*)t0)[2],t2);}

/* g691 in loop684 in k5110 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5122(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5122,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[276]);
if(C_truep(C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5133,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=C_fixnum_increase(t2);
/* c-backend.scm: 539  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[277]))(5,*((C_word*)lf[277]+1),t5,*((C_word*)lf[278]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k5131 in g691 in loop684 in k5110 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_eqp(lf[262],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5092,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[213]))){
/* c-backend.scm: 550  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),t4,C_retrieve(lf[213]),lf[267]);}
else{
t5=t4;
f_5092(2,t5,lf[268]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 542  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t4,lf[274],((C_word*)t0)[5],lf[275],C_SCHEME_TRUE);}}

/* k5065 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 543  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[273]);}

/* k5068 in k5065 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5073,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 544  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[271]);}
else{
/* c-backend.scm: 544  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[272]);}}

/* k5071 in k5068 in k5065 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 546  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[269]);}
else{
/* c-backend.scm: 547  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[270]);}}

/* k5074 in k5071 in k5068 in k5065 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 548  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5090 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5095,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 551  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,lf[265],t1,lf[266],C_SCHEME_TRUE);}

/* k5093 in k5090 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 552  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[264]);}

/* k5096 in k5093 in k5090 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 553  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[263],((C_word*)t0)[2]);}

/* k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 554  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4989(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 555  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[261]);}}

/* k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5039,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_5039(t5,C_i_not(t4));}
else{
t4=t3;
f_5039(t4,C_SCHEME_FALSE);}}

/* k5037 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_5039(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5039,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 557  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[260]);}
else{
t2=((C_word*)t0)[2];
f_4992(2,t2,C_SCHEME_UNDEFINED);}}

/* k5040 in k5037 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 558  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_4992(2,t3,t2);}}

/* k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[4]);}

/* k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4995,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 561  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[258]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 569  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k5025 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 572  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_make_character(59));}
else{
/* c-backend.scm: 571  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[259]);}}

/* k5028 in k5025 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 572  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k4999 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5001,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[6],lf[251]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 564  gen */
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[254],((C_word*)t0)[2],lf[255],C_SCHEME_TRUE,lf[256],((C_word*)t0)[2],lf[257]);}}

/* k5008 in k4999 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k5011 in k5008 in k4999 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4951 in k4948 in k4945 in g665 in loop658 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 567  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[252],t2,lf[253]);}

/* k4867 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4869,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4874,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4874(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* loop745 in k4867 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4874(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4874,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4922,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4886,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 576  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[249],t4,lf[250]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4884 in loop745 in k4867 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4889,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4896,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 577  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[247]))(4,*((C_word*)lf[247]+1),t3,((C_word*)t0)[2],lf[248]);}

/* k4894 in k4884 in loop745 in k4867 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4898,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4898(t5,((C_word*)t0)[2],t1);}

/* loop757 in k4894 in k4884 in loop745 in k4867 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4898(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4898,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[1]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4908,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g764765 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4906 in loop757 in k4894 in k4884 in loop745 in k4867 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4898(t3,((C_word*)t0)[2],t2);}

/* k4887 in k4884 in loop745 in k4867 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 578  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[246]);}

/* k4920 in loop745 in k4867 in k4864 in prototypes in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4874(t3,((C_word*)t0)[2],t2);}

/* declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4691,NULL,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4698,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 492  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[245]);}

/* k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4834,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4834(t6,t2,C_retrieve(lf[215]));}

/* loop609 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4834(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4834,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4849,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm: 495  gen */
((C_proc10)C_retrieve_proc(*((C_word*)lf[1]+1)))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[241],t4,lf[242],C_SCHEME_TRUE,lf[243],t4,lf[244]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4847 in loop609 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4834(t3,((C_word*)t0)[2],t2);}

/* k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_4704(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 499  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[239],((C_word*)t0)[2],lf[240]);}}

/* k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 500  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[238]);}

/* k4705 in k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4712,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4712(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* doloop623 in k4705 in k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4712(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4712,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4722,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* c-backend.scm: 504  ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t4,t5);}}

/* k4720 in doloop623 in k4705 in k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4722,2,t0,t1);}
t2=C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4728,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=C_fixnum_shift_right(t2,C_fix(16));
t5=C_fixnum_shift_right(t2,C_fix(8));
t6=C_fixnum_and(C_fix(255),t5);
t7=C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 506  gen */
((C_proc12)C_retrieve_proc(*((C_word*)lf[1]+1)))(12,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[235],((C_word*)t0)[5],lf[236],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k4726 in k4720 in doloop623 in k4705 in k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4781(t6,t2,C_fix(0));}

/* doloop632 in k4726 in k4720 in doloop623 in k4705 in k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4781(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4781,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4791,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_i_string_ref(((C_word*)t0)[2],t2);
t6=C_fix(C_character_code(t5));
/* c-backend.scm: 513  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t4,C_make_character(44),t6);}}

/* k4789 in doloop632 in k4726 in k4720 in doloop623 in k4705 in k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4781(t3,((C_word*)t0)[2],t2);}

/* k4729 in k4726 in k4720 in doloop623 in k4705 in k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=C_fixnum_and(C_fix(16777208),t3);
t5=C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4754,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4754(t9,t2,t5);}

/* doloop639 in k4729 in k4726 in k4720 in doloop623 in k4705 in k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4754(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4754,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4764,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 516  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t4,lf[234]);}}

/* k4762 in doloop639 in k4729 in k4726 in k4720 in doloop623 in k4705 in k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4754(t3,((C_word*)t0)[2],t2);}

/* k4732 in k4729 in k4726 in k4720 in doloop623 in k4705 in k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 517  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[233]);}

/* k4735 in k4732 in k4729 in k4726 in k4720 in doloop623 in k4705 in k4702 in k4699 in k4696 in declarations in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_increase(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4712(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4522,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4525,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4542,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4683,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 458  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[232]))(2,*((C_word*)lf[232]+1),t4);}

/* k4681 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 458  ##sys#decode-seconds */
((C_proc4)C_retrieve_symbol_proc(lf[231]))(4,*((C_word*)lf[231]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4542,2,t0,t1);}
t2=C_i_vector_ref(t1,C_fix(1));
t3=C_i_vector_ref(t1,C_fix(2));
t4=C_i_vector_ref(t1,C_fix(3));
t5=C_i_vector_ref(t1,C_fix(4));
t6=C_i_vector_ref(t1,C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4641,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=C_fixnum_increase(t5);
/* c-backend.scm: 466  pad0 */
f_4525(t9,t10);}

/* k4639 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 466  pad0 */
f_4525(t2,((C_word*)t0)[2]);}

/* k4643 in k4639 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4649,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 466  pad0 */
f_4525(t2,((C_word*)t0)[2]);}

/* k4647 in k4643 in k4639 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4653,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 466  pad0 */
f_4525(t2,((C_word*)t0)[2]);}

/* k4651 in k4647 in k4643 in k4639 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4657,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4661,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4663,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4671,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4675,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 469  chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[230]))(3,*((C_word*)lf[230]+1),t6,C_SCHEME_TRUE);}

/* k4673 in k4651 in k4647 in k4643 in k4639 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 469  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[228]))(4,*((C_word*)lf[228]+1),((C_word*)t0)[2],t1,lf[229]);}

/* k4669 in k4651 in k4647 in k4643 in k4639 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[227]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4662 in k4651 in k4647 in k4643 in k4639 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4663,3,t0,t1,t2);}
t3=*((C_word*)lf[115]+1);
/* g568569 */
t4=t3;
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[225],t2,lf[226]);}

/* k4659 in k4651 in k4647 in k4643 in k4639 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 467  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[223]))(4,*((C_word*)lf[223]+1),((C_word*)t0)[2],t1,lf[224]);}

/* k4655 in k4651 in k4647 in k4643 in k4639 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 464  gen */
((C_proc21)C_retrieve_proc(*((C_word*)lf[1]+1)))(21,*((C_word*)lf[1]+1),((C_word*)t0)[8],lf[218],((C_word*)t0)[7],lf[219],C_SCHEME_TRUE,lf[220],C_SCHEME_TRUE,lf[221],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[222]);}

/* k4558 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 472  gen-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),t2,C_retrieve(lf[217]));}

/* k4561 in k4558 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 473  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4564 in k4561 in k4558 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[213]))){
/* c-backend.scm: 474  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,lf[214],C_retrieve(lf[213]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4630,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 476  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,lf[216]);}}

/* k4628 in k4564 in k4561 in k4558 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 477  gen-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),((C_word*)t0)[2],C_retrieve(lf[215]));}

/* k4567 in k4564 in k4561 in k4558 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 478  gen */
((C_proc9)C_retrieve_proc(*((C_word*)lf[1]+1)))(9,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[209],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[210],C_retrieve(lf[211]),lf[212]);}

/* k4570 in k4567 in k4564 in k4561 in k4558 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4575,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[205]))){
/* c-backend.scm: 480  generate-foreign-callback-stub-prototypes */
((C_proc3)C_retrieve_symbol_proc(lf[206]))(3,*((C_word*)lf[206]+1),t2,C_retrieve(lf[207]));}
else{
t3=t2;
f_4575(2,t3,C_SCHEME_UNDEFINED);}}

/* k4573 in k4570 in k4567 in k4564 in k4561 in k4558 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(C_retrieve(lf[208])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4590,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 482  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
if(C_truep(C_retrieve(lf[205]))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* c-backend.scm: 485  generate-foreign-callback-stub-prototypes */
((C_proc3)C_retrieve_symbol_proc(lf[206]))(3,*((C_word*)lf[206]+1),((C_word*)t0)[2],C_retrieve(lf[207]));}}}

/* k4588 in k4573 in k4570 in k4567 in k4564 in k4561 in k4558 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4590,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4595,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4595(t5,((C_word*)t0)[2],C_retrieve(lf[208]));}

/* loop583 in k4588 in k4573 in k4570 in k4567 in k4564 in k4561 in k4558 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4595(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4595,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4610,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm: 483  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4608 in loop583 in k4588 in k4573 in k4570 in k4567 in k4564 in k4561 in k4558 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4595(t3,((C_word*)t0)[2],t2);}

/* k4576 in k4573 in k4570 in k4567 in k4564 in k4561 in k4558 in k4540 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve(lf[205]))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* c-backend.scm: 485  generate-foreign-callback-stub-prototypes */
((C_proc3)C_retrieve_symbol_proc(lf[206]))(3,*((C_word*)lf[206]+1),((C_word*)t0)[2],C_retrieve(lf[207]));}}

/* pad0 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4525(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4525,NULL,2,t1,t2);}
t3=t2;
if(C_truep(C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4539,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 456  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4537 in pad0 in header in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 456  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[2],lf[204],t1);}

/* expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_2641(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2641,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4490,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 451  expr */
t11=((C_word*)t6)[1];
f_2644(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4490(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4490,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4496,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 445  pair-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[203]))(4,*((C_word*)lf[203]+1),t1,t4,t2);}

/* a4495 in expr-args in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4496,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4500,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_i_car(t2);
/* c-backend.scm: 448  expr */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2644(t6,t1,t5,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 447  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}}

/* k4498 in a4495 in expr-args in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 448  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2644(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_2644(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2644,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[12]);
if(C_truep(t10)){
t11=C_i_car(t7);
t12=C_eqp(t11,lf[13]);
if(C_truep(t12)){
if(C_truep(C_i_cadr(t7))){
/* c-backend.scm: 84   gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t1,lf[14]);}
else{
/* c-backend.scm: 84   gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t1,lf[15]);}}
else{
t13=C_eqp(t11,lf[16]);
if(C_truep(t13)){
t14=C_i_cadr(t7);
t15=C_fix(C_character_code(t14));
/* c-backend.scm: 85   gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[17],t15,C_make_character(41));}
else{
t14=C_eqp(t11,lf[18]);
if(C_truep(t14)){
/* c-backend.scm: 86   gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t1,lf[19]);}
else{
t15=C_eqp(t11,lf[20]);
if(C_truep(t15)){
t16=C_i_cadr(t7);
/* c-backend.scm: 87   gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[21],t16,C_make_character(41));}
else{
t16=C_eqp(t11,lf[22]);
if(C_truep(t16)){
/* c-backend.scm: 88   gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t1,lf[23]);}
else{
/* c-backend.scm: 89   bomb */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t1,lf[24]);}}}}}}
else{
t11=C_eqp(t9,lf[25]);
if(C_truep(t11)){
t12=C_i_car(t7);
if(C_truep(C_i_vectorp(t12))){
t13=C_i_vector_ref(t12,C_fix(0));
/* c-backend.scm: 94   gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[26],t13,lf[27]);}
else{
t13=C_i_car(t7);
/* c-backend.scm: 95   gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[28],t13,C_make_character(93));}}
else{
t12=C_eqp(t9,lf[29]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2783,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 98   gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t13,C_SCHEME_TRUE,lf[32]);}
else{
t13=C_eqp(t9,lf[33]);
if(C_truep(t13)){
t14=C_i_car(t7);
/* c-backend.scm: 107  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t1,lf[34],t14);}
else{
t14=C_eqp(t9,lf[35]);
if(C_truep(t14)){
t15=C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[5],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_2841(t19,t1,t5,t3,t15);}
else{
t15=C_eqp(t9,lf[36]);
if(C_truep(t15)){
t16=C_i_car(t7);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2895,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 120  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t17,C_SCHEME_TRUE,t16,C_make_character(61));}
else{
t16=C_eqp(t9,lf[37]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2921,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 126  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t17,lf[39]);}
else{
t17=C_eqp(t9,lf[40]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2948,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 131  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t18,lf[42]);}
else{
t18=C_eqp(t9,lf[43]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2967,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 136  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t19,lf[44]);}
else{
t19=C_eqp(t9,lf[45]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3000,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 143  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t20,lf[48]);}
else{
t20=C_eqp(t9,lf[49]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3037,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 150  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t21,lf[51]);}
else{
t21=C_eqp(t9,lf[52]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3066,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 157  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t22,lf[54]);}
else{
t22=C_eqp(t9,lf[55]);
if(C_truep(t22)){
t23=C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3098,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t23,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 165  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t24,lf[61],t23,C_make_character(44));}
else{
t23=C_eqp(t9,lf[62]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3169,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 175  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t24,lf[64]);}
else{
t24=C_eqp(t9,lf[65]);
if(C_truep(t24)){
t25=C_i_car(t7);
/* c-backend.scm: 179  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t1,C_make_character(116),t25);}
else{
t25=C_eqp(t9,lf[66]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3201,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t27=C_i_car(t7);
/* c-backend.scm: 182  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t26,C_make_character(116),t27,C_make_character(61));}
else{
t26=C_eqp(t9,lf[67]);
if(C_truep(t26)){
t27=C_i_car(t7);
t28=C_i_cadr(t7);
if(C_truep(C_i_caddr(t7))){
if(C_truep(t28)){
/* c-backend.scm: 191  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[68],t27,lf[69]);}
else{
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3243,a[2]=t27,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3247,a[2]=t29,tmp=(C_word)a,a+=3,tmp);
t31=C_i_cadddr(t7);
/* c-backend.scm: 192  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t30,t31);}}
else{
if(C_truep(t28)){
/* c-backend.scm: 193  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[74],t27,lf[75]);}
else{
/* c-backend.scm: 194  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t1,lf[76],t27,lf[77]);}}}
else{
t27=C_eqp(t9,lf[78]);
if(C_truep(t27)){
t28=C_i_car(t7);
t29=C_i_cadr(t7);
t30=C_i_caddr(t7);
t31=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3278,a[2]=t30,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t29)){
/* c-backend.scm: 201  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t31,lf[85],t28,lf[86]);}
else{
/* c-backend.scm: 202  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t31,lf[87],t28,lf[88]);}}
else{
t28=C_eqp(t9,lf[89]);
if(C_truep(t28)){
t29=C_i_car(t7);
t30=C_i_cadr(t7);
t31=C_i_caddr(t7);
if(C_truep(t30)){
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3326,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3340,a[2]=t29,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3344,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 213  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t34,t31);}
else{
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3347,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3361,a[2]=t29,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3365,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 218  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t34,t31);}}
else{
t29=C_eqp(t9,lf[98]);
if(C_truep(t29)){
/* c-backend.scm: 222  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t1,lf[99]);}
else{
t30=C_eqp(t9,lf[100]);
if(C_truep(t30)){
t31=C_i_cdr(t5);
t32=C_i_length(t31);
t33=t3;
t34=C_fixnum_increase(t32);
t35=C_i_cdr(t7);
t36=C_i_pairp(t35);
t37=(C_truep(t36)?C_i_cadr(t7):C_SCHEME_FALSE);
t38=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3398,a[2]=t36,a[3]=((C_word*)t0)[2],a[4]=t37,a[5]=t33,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=t32,a[9]=t34,a[10]=t3,a[11]=t31,a[12]=((C_word*)t0)[4],a[13]=t1,a[14]=t5,a[15]=t7,tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 231  source-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[149]))(3,*((C_word*)lf[149]+1),t38,t37);}
else{
t31=C_eqp(t9,lf[150]);
if(C_truep(t31)){
t32=C_i_length(t5);
t33=C_fixnum_increase(t32);
t34=C_i_car(t7);
t35=C_i_cadr(t7);
t36=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3986,a[2]=t35,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t33,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=t32,a[10]=t1,a[11]=t34,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 315  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),t36,((C_word*)t0)[3]);}
else{
t32=C_eqp(t9,lf[154]);
if(C_truep(t32)){
t33=C_i_cdr(t5);
t34=C_i_length(t33);
t35=C_fixnum_increase(t34);
t36=C_i_caddr(t7);
t37=C_i_cadddr(t7);
t38=C_eqp(t37,C_fix(0));
t39=C_i_not(t38);
t40=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4071,a[2]=t36,a[3]=t37,a[4]=t39,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t33,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t41=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4075,a[2]=t40,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 343  find-lambda */
t42=((C_word*)((C_word*)t0)[2])[1];
f_2599(t42,t41,t36);}
else{
t33=C_eqp(t9,lf[156]);
if(C_truep(t33)){
t34=C_i_length(t5);
t35=C_fixnum_plus(t34,C_fix(1));
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4094,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=C_i_car(t7);
/* c-backend.scm: 360  gen */
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t36,C_SCHEME_TRUE,lf[158],t37,lf[159],t35,lf[160]);}
else{
t34=C_eqp(t9,lf[161]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4113,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 365  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t35,C_SCHEME_TRUE,lf[163]);}
else{
t35=C_eqp(t9,lf[164]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4132,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=C_i_car(t7);
/* c-backend.scm: 370  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t36,t37,C_make_character(40));}
else{
t36=C_eqp(t9,lf[165]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4151,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t38=C_i_car(t7);
t39=C_i_length(t5);
/* c-backend.scm: 375  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t37,t38,lf[166],t39);}
else{
t37=C_eqp(t9,lf[167]);
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4187,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t39=C_i_cadr(t7);
/* c-backend.scm: 383  foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t38,t39,lf[169]);}
else{
t38=C_eqp(t9,lf[170]);
if(C_truep(t38)){
t39=C_i_cadr(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4207,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=C_i_car(t7);
t42=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4225,a[2]=t39,a[3]=t41,a[4]=t40,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 387  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t42,t39,lf[175]);}
else{
t39=C_eqp(t9,lf[176]);
if(C_truep(t39)){
t40=C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4241,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t42=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4255,a[2]=t40,a[3]=t41,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 393  foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t42,t40,lf[181]);}
else{
t40=C_eqp(t9,lf[182]);
if(C_truep(t40)){
t41=C_i_car(t7);
t42=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4271,a[2]=t41,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t43=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4299,a[2]=t42,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 399  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t43,t41,lf[187]);}
else{
t41=C_eqp(t9,lf[188]);
if(C_truep(t41)){
t42=C_i_car(t7);
/* c-backend.scm: 406  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t1,t42);}
else{
t42=C_eqp(t9,lf[189]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4321,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t44=C_i_car(t7);
/* c-backend.scm: 409  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t43,lf[191],t44,C_make_character(61));}
else{
t43=C_eqp(t9,lf[192]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4344,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t45=C_i_car(t7);
/* c-backend.scm: 414  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t44,t45,lf[193]);}
else{
t44=C_eqp(t9,lf[194]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4363,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 419  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t45,C_SCHEME_TRUE,lf[198]);}
else{
t45=C_eqp(t9,lf[199]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4446,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 434  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t46,lf[201]);}
else{
t46=t2;
t47=C_slot(t46,C_fix(1));
/* c-backend.scm: 442  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t1,lf[202],t47);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4444 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 435  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k4447 in k4444 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 436  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[200]);}

/* k4450 in k4447 in k4444 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 437  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k4453 in k4450 in k4447 in k4444 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 438  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k4456 in k4453 in k4450 in k4447 in k4444 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4461,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 439  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k4459 in k4456 in k4453 in k4450 in k4447 in k4444 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 440  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k4361 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 420  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2644(t4,t2,t3,((C_word*)t0)[3]);}

/* k4364 in k4361 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 421  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[197]);}

/* k4367 in k4364 in k4361 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4382,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4382(t7,((C_word*)t0)[2],t2,t3);}

/* doloop509 in k4367 in k4364 in k4361 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_4382(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4382,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 425  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[195]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 428  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[196]);}}

/* k4403 in doloop509 in k4367 in k4364 in k4361 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 429  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k4406 in k4403 in doloop509 in k4367 in k4364 in k4361 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 430  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k4409 in k4406 in k4403 in doloop509 in k4367 in k4364 in k4361 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 431  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k4412 in k4409 in k4406 in k4403 in doloop509 in k4367 in k4364 in k4361 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_decrease(((C_word*)t0)[5]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4382(t4,((C_word*)t0)[2],t2,t3);}

/* k4390 in doloop509 in k4367 in k4364 in k4361 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 426  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k4393 in k4390 in doloop509 in k4367 in k4364 in k4361 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 427  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* k4342 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4347,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 415  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4490(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4345 in k4342 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 416  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k4319 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4324,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 410  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k4322 in k4319 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 411  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[190]);}

/* k4297 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 399  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[185],t1,lf[186]);}

/* k4269 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 400  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2644(t4,t2,t3,((C_word*)t0)[3]);}

/* k4272 in k4269 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4291,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 401  foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t3,((C_word*)t0)[2]);}

/* k4289 in k4272 in k4269 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 401  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[184],t1);}

/* k4275 in k4272 in k4269 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 402  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k4278 in k4275 in k4272 in k4269 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 403  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[183]);}

/* k4253 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4259,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 393  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),t2,((C_word*)t0)[2],lf[180]);}

/* k4257 in k4253 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 393  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[178],t1,lf[179]);}

/* k4239 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4244,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 394  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k4242 in k4239 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 395  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[177]);}

/* k4223 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4229,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 387  foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2]);}

/* k4227 in k4223 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 387  gen */
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[172],((C_word*)t0)[2],C_make_character(41),t1);}

/* k4205 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4210,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 388  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k4208 in k4205 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 389  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[171]);}

/* k4185 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 383  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k4149 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 378  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}
else{
/* c-backend.scm: 380  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_make_character(41));}}

/* k4161 in k4149 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 379  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4490(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4152 in k4149 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 380  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k4130 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 371  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4490(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4133 in k4130 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 372  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k4111 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4116,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 366  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k4114 in k4111 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 367  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[162]);}

/* k4092 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 361  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4490(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4095 in k4092 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 362  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[157]);}

/* k4073 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 343  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),((C_word*)t0)[2],t1);}

/* k4069 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4071,2,t0,t1);}
t2=C_eqp(t1,C_fix(0));
t3=C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 345  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t4,((C_word*)t0)[2],C_make_character(40));}

/* k4017 in k4069 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 347  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t3,lf[155],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_4022(2,t3,C_SCHEME_UNDEFINED);}}

/* k4050 in k4017 in k4069 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_not(((C_word*)t0)[4]);
if(C_truep(t2)){
if(C_truep(t2)){
/* c-backend.scm: 348  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_make_character(44));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_4022(2,t4,t3);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
/* c-backend.scm: 348  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_make_character(44));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_4022(2,t4,t3);}}}

/* k4020 in k4017 in k4069 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4025,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_4025(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4040,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 350  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k4038 in k4020 in k4017 in k4069 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 351  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_4025(2,t3,t2);}}

/* k4023 in k4020 in k4017 in k4069 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 352  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4490(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
/* c-backend.scm: 353  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_make_character(41));}}

/* k4026 in k4023 in k4020 in k4017 in k4069 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 353  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3986,2,t0,t1);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3857,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 317  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3970,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 330  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t3,((C_word*)t0)[2],C_make_character(40));}}

/* k3968 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11141,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 332  expr-args */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4490(t4,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 331  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[153]);}}

/* f11141 in k3968 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f11141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 333  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3971 in k3968 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3976,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 332  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4490(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3974 in k3971 in k3968 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 333  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 318  iota */
((C_proc5)C_retrieve_symbol_proc(lf[60]))(5,*((C_word*)lf[60]+1),t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k3858 in k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3863,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3917,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3917(t6,t2,((C_word*)t0)[2],t1);}

/* loop407 in k3858 in k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3917(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3917,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3938,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g418419 */
t10=t6;
f_3925(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3936 in loop407 in k3858 in k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3917(t4,((C_word*)t0)[2],t2,t3);}

/* g418 in loop407 in k3858 in k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3925(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3925,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 321  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3927 in g418 in loop407 in k3858 in k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3932,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 322  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2644(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3930 in k3927 in g418 in loop407 in k3858 in k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 323  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3861 in k3858 in k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3873,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 327  iota */
((C_proc5)C_retrieve_symbol_proc(lf[60]))(5,*((C_word*)lf[60]+1),t3,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3871 in k3861 in k3858 in k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3873,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3875,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3875(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop428 in k3871 in k3861 in k3858 in k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3875(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3875,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3890,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm: 326  gen */
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t6,C_SCHEME_TRUE,C_make_character(116),t8,lf[152],t7,C_make_character(59));}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3888 in loop428 in k3871 in k3861 in k3858 in k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3875(t4,((C_word*)t0)[2],t2,t3);}

/* k3864 in k3861 in k3858 in k3855 in k3984 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 328  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[151]);}

/* k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3401,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_i_cddr(((C_word*)t0)[15]);
t4=C_i_pairp(t3);
t5=t2;
f_3401(t5,(C_truep(t4)?C_i_caddr(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3401(t3,C_SCHEME_FALSE);}}

/* k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3401,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_i_cadddr(((C_word*)t0)[15]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3803,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3807,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 234  find-lambda */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2599(t6,t5,t1);}
else{
t4=t3;
f_3407(t4,C_SCHEME_FALSE);}}

/* k3805 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 234  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),((C_word*)t0)[2],t1);}

/* k3801 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3407(t2,C_eqp(t1,C_fix(0)));}

/* k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3407,NULL,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(C_retrieve(lf[139]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3789,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2629,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 71   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3796,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11133,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 72   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t6,t5);}}
else{
t4=t3;
f_3413(2,t4,C_SCHEME_UNDEFINED);}}

/* f11133 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f11133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 72   string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1,lf[147]);}

/* k3794 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[145],t1,lf[146]);}

/* k2627 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 71   string-translate */
((C_proc5)C_retrieve_symbol_proc(lf[142]))(5,*((C_word*)lf[142]+1),((C_word*)t0)[2],t1,lf[143],lf[144]);}

/* k3787 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 238  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[140],t1,lf[141]);}

/* k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3413,2,t0,t1);}
t2=C_slot(((C_word*)t0)[15],C_fix(1));
t3=C_eqp(lf[33],t2);
if(C_truep(t3)){
t4=C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t4);
/* c-backend.scm: 242  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[102]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3611,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 246  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3617,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
t5=C_slot(((C_word*)t0)[15],C_fix(1));
t6=C_eqp(lf[67],t5);
if(C_truep(t6)){
t7=C_retrieve(lf[131]);
if(C_truep(t7)){
t8=t4;
f_3617(t8,C_SCHEME_FALSE);}
else{
t8=C_retrieve(lf[136]);
if(C_truep(t8)){
t9=t4;
f_3617(t9,C_SCHEME_FALSE);}
else{
t9=C_i_car(((C_word*)t0)[2]);
t10=t4;
f_3617(t10,C_i_not(t9));}}}
else{
t7=t4;
f_3617(t7,C_SCHEME_FALSE);}}}}

/* k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3617,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[10],C_fix(2));
t3=C_i_car(t2);
t4=C_i_cadr(t2);
t5=C_i_caddr(t2);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3637,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 280  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t8,C_SCHEME_TRUE,lf[126],((C_word*)t0)[5],lf[127]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 299  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}

/* k3704 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 300  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2644(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k3707 in k3704 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 301  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,C_make_character(59),C_SCHEME_TRUE,lf[137],((C_word*)t0)[4],lf[138]);}

/* k3710 in k3707 in k3704 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[131]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3727,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3727(t5,t3);}
else{
t5=C_retrieve(lf[136]);
t6=t4;
f_3727(t6,(C_truep(t5)?t5:C_i_car(((C_word*)t0)[2])));}}

/* k3725 in k3710 in k3707 in k3704 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 304  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[132],((C_word*)t0)[2],lf[133]);}
else{
/* c-backend.scm: 305  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[134],((C_word*)t0)[2],lf[135]);}}

/* k3713 in k3710 in k3707 in k3704 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 306  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,lf[129],((C_word*)t0)[3],lf[130],((C_word*)t0)[2],C_make_character(44));}

/* k3716 in k3713 in k3710 in k3707 in k3704 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 307  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4490(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3719 in k3716 in k3713 in k3710 in k3707 in k3704 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 308  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[128]);}

/* k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3640,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3653,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3678,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 282  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3685,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3692,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 289  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3696,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3703,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 293  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}}}

/* k3701 in k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 293  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[2],lf[124],t1,lf[125]);}

/* k3694 in k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* c-backend.scm: 294  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[122],((C_word*)t0)[2],lf[123]);}

/* k3690 in k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 289  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[2],lf[120],t1,lf[121]);}

/* k3683 in k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
/* c-backend.scm: 290  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[118],((C_word*)((C_word*)t0)[3])[1],lf[119]);}

/* k3676 in k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 282  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[2],lf[116],t1,lf[117]);}

/* k3651 in k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 284  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[111],((C_word*)((C_word*)t0)[5])[1],lf[112]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3666,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadddr(((C_word*)t0)[2]);
/* c-backend.scm: 286  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t4,t5);}}

/* k3668 in k3651 in k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 286  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k3664 in k3651 in k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 285  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[113],((C_word*)((C_word*)t0)[2])[1],lf[114],t1,C_make_character(41));}

/* k3638 in k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3643,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 295  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),t2,lf[110],((C_word*)t0)[3],C_make_character(44),((C_word*)((C_word*)t0)[2])[1],C_make_character(44));}

/* k3641 in k3638 in k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3646,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 296  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4490(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3644 in k3641 in k3638 in k3635 in k3615 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 297  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[109]);}

/* k3609 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 247  lambda-literal-looping */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_3449(2,t3,C_SCHEME_FALSE);}}

/* k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 248  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3571(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3595,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 263  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k3593 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 264  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2644(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3596 in k3593 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 265  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3569 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 266  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3572 in k3569 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3577,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3577(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 267  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(44));}}

/* k3575 in k3572 in k3569 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3580,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11128,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 269  expr-args */
t4=((C_word*)((C_word*)t0)[6])[1];
f_4490(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
/* c-backend.scm: 268  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* f11128 in k3575 in k3572 in k3569 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f11128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 270  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[107]);}

/* k3578 in k3575 in k3572 in k3569 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3583,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 269  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4490(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3581 in k3578 in k3575 in k3572 in k3569 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 270  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[107]);}

/* k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 249  iota */
((C_proc5)C_retrieve_symbol_proc(lf[60]))(5,*((C_word*)lf[60]+1),t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3458,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3518,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3518(t6,t2,((C_word*)t0)[2],t1);}

/* loop286 in k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3518(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3518,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3526,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3539,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g297298 */
t10=t6;
f_3526(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3537 in loop286 in k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3518(t4,((C_word*)t0)[2],t2,t3);}

/* g297 in loop286 in k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3526(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3526,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3530,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 252  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3528 in g297 in loop286 in k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3533,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 253  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2644(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3531 in k3528 in g297 in loop286 in k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 254  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3456 in k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3461,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 258  iota */
((C_proc5)C_retrieve_symbol_proc(lf[60]))(5,*((C_word*)lf[60]+1),t3,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3472 in k3456 in k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3476,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3476(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop307 in k3472 in k3456 in k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3476(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3476,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3491,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm: 257  gen */
((C_proc8)C_retrieve_proc(*((C_word*)lf[1]+1)))(8,*((C_word*)lf[1]+1),t6,C_SCHEME_TRUE,C_make_character(116),t8,lf[105],t7,C_make_character(59));}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3489 in loop307 in k3472 in k3456 in k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3476(t4,((C_word*)t0)[2],t2,t3);}

/* k3459 in k3456 in k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 260  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[103]);}
else{
/* c-backend.scm: 259  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[104],((C_word*)t0)[2],C_make_character(59));}}

/* k3462 in k3459 in k3456 in k3453 in k3450 in k3447 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 260  gen */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[103]);}

/* k3428 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 243  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4490(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3431 in k3428 in k3411 in k3405 in k3399 in k3396 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 244  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[101]);}

/* k3363 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 72   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t1);}

/* f11120 in k3363 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f11120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 72   string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1,lf[97]);}

/* k3359 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 217  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[94],((C_word*)t0)[2],lf[95],t1,lf[96]);}

/* k3345 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3350,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 219  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k3348 in k3345 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 220  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3342 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11115,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 72   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t1);}

/* f11115 in k3342 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f11115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 72   string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1,lf[93]);}

/* k3338 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 212  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[90],((C_word*)t0)[2],lf[91],t1,lf[92]);}

/* k3324 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3329,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 214  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k3327 in k3324 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 215  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3276 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3281,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3295,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3299,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 203  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),t4,((C_word*)t0)[2]);}

/* k3297 in k3276 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11110,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 72   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,t1);}

/* f11110 in k3297 in k3276 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f11110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 72   string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[2],t1,lf[82]);}

/* k3293 in k3276 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 203  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[79],t1,lf[80]);}

/* k3279 in k3276 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 204  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k3282 in k3279 in k3276 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 205  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3245 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 192  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k3241 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 192  gen */
((C_proc7)C_retrieve_proc(*((C_word*)lf[1]+1)))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[70],((C_word*)t0)[2],lf[71],t1,C_make_character(41));}

/* k3199 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 183  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2644(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k3167 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 176  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k3170 in k3167 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 177  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[63]);}

/* k3096 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3101,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3112,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 171  iota */
((C_proc5)C_retrieve_symbol_proc(lf[60]))(5,*((C_word*)lf[60]+1),t3,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k3110 in k3096 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3112,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3114,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3114(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop182 in k3110 in k3096 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3114(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3114,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3135,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g193194 */
t10=t6;
f_3122(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3133 in loop182 in k3110 in k3096 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3114(t4,((C_word*)t0)[2],t2,t3);}

/* g193 in loop182 in k3110 in k3096 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_3122(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3122,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3126,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 168  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t4,lf[58],t3,lf[59]);}

/* k3124 in g193 in loop182 in k3110 in k3096 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 169  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2644(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3127 in k3124 in g193 in loop182 in k3110 in k3096 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 170  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}

/* k3099 in k3096 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 172  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[56],t2,lf[57]);}

/* k3064 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 158  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k3067 in k3064 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 159  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[53]);}

/* k3070 in k3067 in k3064 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3075,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 160  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k3073 in k3070 in k3067 in k3064 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 161  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3035 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 151  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k3038 in k3035 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 152  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[50]);}

/* k3041 in k3038 in k3035 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 153  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k3044 in k3041 in k3038 in k3035 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 154  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2998 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 144  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2644(t4,t2,t3,((C_word*)t0)[3]);}

/* k3001 in k2998 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[2]);
t4=C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 145  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,lf[46],t4,lf[47]);}

/* k3004 in k3001 in k2998 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 146  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k3007 in k3004 in k3001 in k2998 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 147  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2965 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 137  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2644(t4,t2,t3,((C_word*)t0)[3]);}

/* k2968 in k2965 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 138  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_make_character(44),t3,C_make_character(44));}

/* k2971 in k2968 in k2965 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 139  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k2974 in k2971 in k2968 in k2965 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 140  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2946 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 132  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k2949 in k2946 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 133  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[41]);}

/* k2919 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 127  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k2922 in k2919 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_car(((C_word*)t0)[3]);
t3=C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 128  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[38],t3,C_make_character(93));}

/* k2893 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 121  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k2896 in k2893 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 122  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(59));}

/* k2899 in k2896 in k2893 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 123  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2644(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* loop in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_2841(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2841,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 112  gen */
((C_proc6)C_retrieve_proc(*((C_word*)lf[1]+1)))(6,*((C_word*)lf[1]+1),t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=C_i_car(t2);
/* c-backend.scm: 116  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2644(t7,t1,t6,t3);}}

/* k2849 in loop in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 113  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2644(t4,t2,t3,((C_word*)t0)[6]);}

/* k2852 in k2849 in loop in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 114  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,C_make_character(59));}

/* k2855 in k2852 in k2849 in loop in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[6]);
t3=C_fixnum_increase(((C_word*)t0)[5]);
t4=C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 115  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2841(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k2781 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 99   expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k2784 in k2781 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 100  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),t2,lf[31]);}

/* k2787 in k2784 in k2781 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 101  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k2790 in k2787 in k2784 in k2781 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 102  gen */
((C_proc5)C_retrieve_proc(*((C_word*)lf[1]+1)))(5,*((C_word*)lf[1]+1),t2,C_make_character(125),C_SCHEME_TRUE,lf[30]);}

/* k2793 in k2790 in k2787 in k2784 in k2781 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 103  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2644(t4,t2,t3,((C_word*)t0)[2]);}

/* k2796 in k2793 in k2790 in k2787 in k2784 in k2781 in expr in expression in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 104  gen */
((C_proc3)C_retrieve_proc(*((C_word*)lf[1]+1)))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* find-lambda in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_fcall f_2599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2599,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2603,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2611,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 68   find */
((C_proc4)C_retrieve_symbol_proc(lf[11]))(4,*((C_word*)lf[11]+1),t3,t4,((C_word*)t0)[2]);}

/* a2610 in find-lambda in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2611,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 68   lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t3,t2);}

/* k2617 in a2610 in find-lambda in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[2],t1));}

/* k2601 in find-lambda in ##compiler#generate-code in k2592 in k2506 in k2503 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* c-backend.scm: 69   bomb */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[9],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k2506 in k2503 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2554,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2562,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 50   intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[5]))(4,*((C_word*)lf[5]+1),t3,t2,C_make_character(32));}

/* k2560 in ##compiler#gen-list in k2506 in k2503 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2562,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2564,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2564(t5,((C_word*)t0)[2],t1);}

/* loop50 in k2560 in ##compiler#gen-list in k2506 in k2503 */
static void C_fcall f_2564(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2564,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2579,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm: 49   display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t3,t4,*((C_word*)lf[0]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2577 in loop50 in k2560 in ##compiler#gen-list in k2506 in k2503 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2564(t3,((C_word*)t0)[2],t2);}

/* ##compiler#gen in k2506 in k2503 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2511r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2511r(t0,t1,t2);}}

static void C_ccall f_2511r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2517(t6,t1,t2);}

/* loop34 in ##compiler#gen in k2506 in k2503 */
static void C_fcall f_2517(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2517,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2541,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_eqp(C_SCHEME_TRUE,t4);
if(C_truep(t5)){
/* c-backend.scm: 43   newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t3,*((C_word*)lf[0]+1));}
else{
/* c-backend.scm: 44   display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t3,t4,*((C_word*)lf[0]+1));}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2539 in loop34 in ##compiler#gen in k2506 in k2503 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2517(t3,((C_word*)t0)[2],t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[793] = {
{"toplevel:c_backend_scm",(void*)C_backend_toplevel},
{"f_2505:c_backend_scm",(void*)f_2505},
{"f_2508:c_backend_scm",(void*)f_2508},
{"f_10296:c_backend_scm",(void*)f_10296},
{"f_10299:c_backend_scm",(void*)f_10299},
{"f_10326:c_backend_scm",(void*)f_10326},
{"f_10322:c_backend_scm",(void*)f_10322},
{"f_10302:c_backend_scm",(void*)f_10302},
{"f_10305:c_backend_scm",(void*)f_10305},
{"f_10318:c_backend_scm",(void*)f_10318},
{"f_10308:c_backend_scm",(void*)f_10308},
{"f_10311:c_backend_scm",(void*)f_10311},
{"f_10314:c_backend_scm",(void*)f_10314},
{"f_2594:c_backend_scm",(void*)f_2594},
{"f_9996:c_backend_scm",(void*)f_9996},
{"f_10272:c_backend_scm",(void*)f_10272},
{"f_10270:c_backend_scm",(void*)f_10270},
{"f_10258:c_backend_scm",(void*)f_10258},
{"f_10228:c_backend_scm",(void*)f_10228},
{"f_10189:c_backend_scm",(void*)f_10189},
{"f_10176:c_backend_scm",(void*)f_10176},
{"f_10172:c_backend_scm",(void*)f_10172},
{"f_10058:c_backend_scm",(void*)f_10058},
{"f_10005:c_backend_scm",(void*)f_10005},
{"f_9389:c_backend_scm",(void*)f_9389},
{"f_9500:c_backend_scm",(void*)f_9500},
{"f_9665:c_backend_scm",(void*)f_9665},
{"f_9692:c_backend_scm",(void*)f_9692},
{"f_9870:c_backend_scm",(void*)f_9870},
{"f_9873:c_backend_scm",(void*)f_9873},
{"f_9876:c_backend_scm",(void*)f_9876},
{"f_9879:c_backend_scm",(void*)f_9879},
{"f_9849:c_backend_scm",(void*)f_9849},
{"f_9852:c_backend_scm",(void*)f_9852},
{"f_9855:c_backend_scm",(void*)f_9855},
{"f_9858:c_backend_scm",(void*)f_9858},
{"f_9828:c_backend_scm",(void*)f_9828},
{"f_9831:c_backend_scm",(void*)f_9831},
{"f_9834:c_backend_scm",(void*)f_9834},
{"f_9837:c_backend_scm",(void*)f_9837},
{"f_9791:c_backend_scm",(void*)f_9791},
{"f_9794:c_backend_scm",(void*)f_9794},
{"f_9797:c_backend_scm",(void*)f_9797},
{"f_9800:c_backend_scm",(void*)f_9800},
{"f_9770:c_backend_scm",(void*)f_9770},
{"f_9773:c_backend_scm",(void*)f_9773},
{"f_9776:c_backend_scm",(void*)f_9776},
{"f_9779:c_backend_scm",(void*)f_9779},
{"f_9749:c_backend_scm",(void*)f_9749},
{"f_9752:c_backend_scm",(void*)f_9752},
{"f_9755:c_backend_scm",(void*)f_9755},
{"f_9758:c_backend_scm",(void*)f_9758},
{"f_9728:c_backend_scm",(void*)f_9728},
{"f_9731:c_backend_scm",(void*)f_9731},
{"f_9734:c_backend_scm",(void*)f_9734},
{"f_9737:c_backend_scm",(void*)f_9737},
{"f_9707:c_backend_scm",(void*)f_9707},
{"f_9710:c_backend_scm",(void*)f_9710},
{"f_9713:c_backend_scm",(void*)f_9713},
{"f_9716:c_backend_scm",(void*)f_9716},
{"f_9669:c_backend_scm",(void*)f_9669},
{"f_9635:c_backend_scm",(void*)f_9635},
{"f_9638:c_backend_scm",(void*)f_9638},
{"f_9641:c_backend_scm",(void*)f_9641},
{"f_9644:c_backend_scm",(void*)f_9644},
{"f_9614:c_backend_scm",(void*)f_9614},
{"f_9617:c_backend_scm",(void*)f_9617},
{"f_9620:c_backend_scm",(void*)f_9620},
{"f_9623:c_backend_scm",(void*)f_9623},
{"f_9593:c_backend_scm",(void*)f_9593},
{"f_9596:c_backend_scm",(void*)f_9596},
{"f_9599:c_backend_scm",(void*)f_9599},
{"f_9602:c_backend_scm",(void*)f_9602},
{"f_9569:c_backend_scm",(void*)f_9569},
{"f_9572:c_backend_scm",(void*)f_9572},
{"f_9575:c_backend_scm",(void*)f_9575},
{"f_9578:c_backend_scm",(void*)f_9578},
{"f_9548:c_backend_scm",(void*)f_9548},
{"f_9551:c_backend_scm",(void*)f_9551},
{"f_9554:c_backend_scm",(void*)f_9554},
{"f_9557:c_backend_scm",(void*)f_9557},
{"f_9524:c_backend_scm",(void*)f_9524},
{"f_9527:c_backend_scm",(void*)f_9527},
{"f_9530:c_backend_scm",(void*)f_9530},
{"f_9533:c_backend_scm",(void*)f_9533},
{"f_9503:c_backend_scm",(void*)f_9503},
{"f_9506:c_backend_scm",(void*)f_9506},
{"f_9509:c_backend_scm",(void*)f_9509},
{"f_9512:c_backend_scm",(void*)f_9512},
{"f_9479:c_backend_scm",(void*)f_9479},
{"f_9482:c_backend_scm",(void*)f_9482},
{"f_9485:c_backend_scm",(void*)f_9485},
{"f_9488:c_backend_scm",(void*)f_9488},
{"f_9458:c_backend_scm",(void*)f_9458},
{"f_9461:c_backend_scm",(void*)f_9461},
{"f_9464:c_backend_scm",(void*)f_9464},
{"f_9467:c_backend_scm",(void*)f_9467},
{"f_9391:c_backend_scm",(void*)f_9391},
{"f_8899:c_backend_scm",(void*)f_8899},
{"f_8929:c_backend_scm",(void*)f_8929},
{"f_8956:c_backend_scm",(void*)f_8956},
{"f_9151:c_backend_scm",(void*)f_9151},
{"f_9160:c_backend_scm",(void*)f_9160},
{"f_9169:c_backend_scm",(void*)f_9169},
{"f_9196:c_backend_scm",(void*)f_9196},
{"f_9273:c_backend_scm",(void*)f_9273},
{"f_8901:c_backend_scm",(void*)f_8901},
{"f_8015:c_backend_scm",(void*)f_8015},
{"f_8092:c_backend_scm",(void*)f_8092},
{"f_8194:c_backend_scm",(void*)f_8194},
{"f_8227:c_backend_scm",(void*)f_8227},
{"f_8323:c_backend_scm",(void*)f_8323},
{"f_8335:c_backend_scm",(void*)f_8335},
{"f_8350:c_backend_scm",(void*)f_8350},
{"f_8395:c_backend_scm",(void*)f_8395},
{"f_8412:c_backend_scm",(void*)f_8412},
{"f_8429:c_backend_scm",(void*)f_8429},
{"f_8468:c_backend_scm",(void*)f_8468},
{"f_8485:c_backend_scm",(void*)f_8485},
{"f_8502:c_backend_scm",(void*)f_8502},
{"f_8519:c_backend_scm",(void*)f_8519},
{"f_8536:c_backend_scm",(void*)f_8536},
{"f_8553:c_backend_scm",(void*)f_8553},
{"f_8570:c_backend_scm",(void*)f_8570},
{"f_8582:c_backend_scm",(void*)f_8582},
{"f_8589:c_backend_scm",(void*)f_8589},
{"f_8599:c_backend_scm",(void*)f_8599},
{"f_8639:c_backend_scm",(void*)f_8639},
{"f_8609:c_backend_scm",(void*)f_8609},
{"f_8597:c_backend_scm",(void*)f_8597},
{"f_8593:c_backend_scm",(void*)f_8593},
{"f_8560:c_backend_scm",(void*)f_8560},
{"f_8543:c_backend_scm",(void*)f_8543},
{"f_8526:c_backend_scm",(void*)f_8526},
{"f_8509:c_backend_scm",(void*)f_8509},
{"f_8492:c_backend_scm",(void*)f_8492},
{"f_8475:c_backend_scm",(void*)f_8475},
{"f_8440:c_backend_scm",(void*)f_8440},
{"f_8450:c_backend_scm",(void*)f_8450},
{"f_8448:c_backend_scm",(void*)f_8448},
{"f_8444:c_backend_scm",(void*)f_8444},
{"f_8436:c_backend_scm",(void*)f_8436},
{"f_8423:c_backend_scm",(void*)f_8423},
{"f_8406:c_backend_scm",(void*)f_8406},
{"f_8354:c_backend_scm",(void*)f_8354},
{"f_8022:c_backend_scm",(void*)f_8022},
{"f_8017:c_backend_scm",(void*)f_8017},
{"f_7950:c_backend_scm",(void*)f_7950},
{"f_7954:c_backend_scm",(void*)f_7954},
{"f_7957:c_backend_scm",(void*)f_7957},
{"f_7960:c_backend_scm",(void*)f_7960},
{"f_7963:c_backend_scm",(void*)f_7963},
{"f_7969:c_backend_scm",(void*)f_7969},
{"f_8013:c_backend_scm",(void*)f_8013},
{"f_7972:c_backend_scm",(void*)f_7972},
{"f_7980:c_backend_scm",(void*)f_7980},
{"f_8001:c_backend_scm",(void*)f_8001},
{"f_7984:c_backend_scm",(void*)f_7984},
{"f_7975:c_backend_scm",(void*)f_7975},
{"f_7456:c_backend_scm",(void*)f_7456},
{"f_7462:c_backend_scm",(void*)f_7462},
{"f_7937:c_backend_scm",(void*)f_7937},
{"f_7470:c_backend_scm",(void*)f_7470},
{"f_7474:c_backend_scm",(void*)f_7474},
{"f_7477:c_backend_scm",(void*)f_7477},
{"f_7480:c_backend_scm",(void*)f_7480},
{"f_7483:c_backend_scm",(void*)f_7483},
{"f_7489:c_backend_scm",(void*)f_7489},
{"f_7835:c_backend_scm",(void*)f_7835},
{"f_7838:c_backend_scm",(void*)f_7838},
{"f_7934:c_backend_scm",(void*)f_7934},
{"f_7841:c_backend_scm",(void*)f_7841},
{"f_7844:c_backend_scm",(void*)f_7844},
{"f_7847:c_backend_scm",(void*)f_7847},
{"f_7850:c_backend_scm",(void*)f_7850},
{"f_7883:c_backend_scm",(void*)f_7883},
{"f_7899:c_backend_scm",(void*)f_7899},
{"f_7902:c_backend_scm",(void*)f_7902},
{"f_7853:c_backend_scm",(void*)f_7853},
{"f_7881:c_backend_scm",(void*)f_7881},
{"f_7856:c_backend_scm",(void*)f_7856},
{"f_7859:c_backend_scm",(void*)f_7859},
{"f_7862:c_backend_scm",(void*)f_7862},
{"f_7491:c_backend_scm",(void*)f_7491},
{"f_7501:c_backend_scm",(void*)f_7501},
{"f_7510:c_backend_scm",(void*)f_7510},
{"f_7522:c_backend_scm",(void*)f_7522},
{"f_7534:c_backend_scm",(void*)f_7534},
{"f_7540:c_backend_scm",(void*)f_7540},
{"f_7579:c_backend_scm",(void*)f_7579},
{"f_7544:c_backend_scm",(void*)f_7544},
{"f_7142:c_backend_scm",(void*)f_7142},
{"f_7148:c_backend_scm",(void*)f_7148},
{"f_7443:c_backend_scm",(void*)f_7443},
{"f_7156:c_backend_scm",(void*)f_7156},
{"f_7160:c_backend_scm",(void*)f_7160},
{"f_7163:c_backend_scm",(void*)f_7163},
{"f_7166:c_backend_scm",(void*)f_7166},
{"f_7440:c_backend_scm",(void*)f_7440},
{"f_7172:c_backend_scm",(void*)f_7172},
{"f_7175:c_backend_scm",(void*)f_7175},
{"f_7178:c_backend_scm",(void*)f_7178},
{"f_7181:c_backend_scm",(void*)f_7181},
{"f_7184:c_backend_scm",(void*)f_7184},
{"f_7187:c_backend_scm",(void*)f_7187},
{"f_7190:c_backend_scm",(void*)f_7190},
{"f_7193:c_backend_scm",(void*)f_7193},
{"f_7196:c_backend_scm",(void*)f_7196},
{"f_7199:c_backend_scm",(void*)f_7199},
{"f_7429:c_backend_scm",(void*)f_7429},
{"f_7202:c_backend_scm",(void*)f_7202},
{"f_7205:c_backend_scm",(void*)f_7205},
{"f_7208:c_backend_scm",(void*)f_7208},
{"f_7211:c_backend_scm",(void*)f_7211},
{"f_7214:c_backend_scm",(void*)f_7214},
{"f_7217:c_backend_scm",(void*)f_7217},
{"f_7220:c_backend_scm",(void*)f_7220},
{"f_7223:c_backend_scm",(void*)f_7223},
{"f_7320:c_backend_scm",(void*)f_7320},
{"f_7322:c_backend_scm",(void*)f_7322},
{"f_7329:c_backend_scm",(void*)f_7329},
{"f_7356:c_backend_scm",(void*)f_7356},
{"f_7359:c_backend_scm",(void*)f_7359},
{"f_7362:c_backend_scm",(void*)f_7362},
{"f_7350:c_backend_scm",(void*)f_7350},
{"f_7338:c_backend_scm",(void*)f_7338},
{"f_7342:c_backend_scm",(void*)f_7342},
{"f_7346:c_backend_scm",(void*)f_7346},
{"f_7368:c_backend_scm",(void*)f_7368},
{"f_7226:c_backend_scm",(void*)f_7226},
{"f_7229:c_backend_scm",(void*)f_7229},
{"f_7259:c_backend_scm",(void*)f_7259},
{"f_7262:c_backend_scm",(void*)f_7262},
{"f_7300:c_backend_scm",(void*)f_7300},
{"f_7296:c_backend_scm",(void*)f_7296},
{"f_7265:c_backend_scm",(void*)f_7265},
{"f_7268:c_backend_scm",(void*)f_7268},
{"f_7271:c_backend_scm",(void*)f_7271},
{"f_7238:c_backend_scm",(void*)f_7238},
{"f_7241:c_backend_scm",(void*)f_7241},
{"f_7232:c_backend_scm",(void*)f_7232},
{"f_7102:c_backend_scm",(void*)f_7102},
{"f_7108:c_backend_scm",(void*)f_7108},
{"f_7120:c_backend_scm",(void*)f_7120},
{"f_7123:c_backend_scm",(void*)f_7123},
{"f_7129:c_backend_scm",(void*)f_7129},
{"f_7048:c_backend_scm",(void*)f_7048},
{"f_7052:c_backend_scm",(void*)f_7052},
{"f_7057:c_backend_scm",(void*)f_7057},
{"f_7086:c_backend_scm",(void*)f_7086},
{"f_7089:c_backend_scm",(void*)f_7089},
{"f_7032:c_backend_scm",(void*)f_7032},
{"f_7038:c_backend_scm",(void*)f_7038},
{"f_7046:c_backend_scm",(void*)f_7046},
{"f_7016:c_backend_scm",(void*)f_7016},
{"f_7022:c_backend_scm",(void*)f_7022},
{"f_7030:c_backend_scm",(void*)f_7030},
{"f_6927:c_backend_scm",(void*)f_6927},
{"f_6936:c_backend_scm",(void*)f_6936},
{"f_6965:c_backend_scm",(void*)f_6965},
{"f_6975:c_backend_scm",(void*)f_6975},
{"f_6850:c_backend_scm",(void*)f_6850},
{"f_6854:c_backend_scm",(void*)f_6854},
{"f_6868:c_backend_scm",(void*)f_6868},
{"f_6881:c_backend_scm",(void*)f_6881},
{"f_6913:c_backend_scm",(void*)f_6913},
{"f_6884:c_backend_scm",(void*)f_6884},
{"f_6887:c_backend_scm",(void*)f_6887},
{"f_6857:c_backend_scm",(void*)f_6857},
{"f_6860:c_backend_scm",(void*)f_6860},
{"f_6863:c_backend_scm",(void*)f_6863},
{"f_2596:c_backend_scm",(void*)f_2596},
{"f_6817:c_backend_scm",(void*)f_6817},
{"f_6821:c_backend_scm",(void*)f_6821},
{"f_6824:c_backend_scm",(void*)f_6824},
{"f_6827:c_backend_scm",(void*)f_6827},
{"f_6830:c_backend_scm",(void*)f_6830},
{"f_6833:c_backend_scm",(void*)f_6833},
{"f_6836:c_backend_scm",(void*)f_6836},
{"f_6839:c_backend_scm",(void*)f_6839},
{"f_6842:c_backend_scm",(void*)f_6842},
{"f_6845:c_backend_scm",(void*)f_6845},
{"f_6032:c_backend_scm",(void*)f_6032},
{"f_6038:c_backend_scm",(void*)f_6038},
{"f_6803:c_backend_scm",(void*)f_6803},
{"f_6046:c_backend_scm",(void*)f_6046},
{"f_6050:c_backend_scm",(void*)f_6050},
{"f_6053:c_backend_scm",(void*)f_6053},
{"f_6056:c_backend_scm",(void*)f_6056},
{"f_6059:c_backend_scm",(void*)f_6059},
{"f_6062:c_backend_scm",(void*)f_6062},
{"f_6065:c_backend_scm",(void*)f_6065},
{"f_6800:c_backend_scm",(void*)f_6800},
{"f_6068:c_backend_scm",(void*)f_6068},
{"f_6074:c_backend_scm",(void*)f_6074},
{"f_6077:c_backend_scm",(void*)f_6077},
{"f_6080:c_backend_scm",(void*)f_6080},
{"f_6083:c_backend_scm",(void*)f_6083},
{"f_6086:c_backend_scm",(void*)f_6086},
{"f_6089:c_backend_scm",(void*)f_6089},
{"f_6092:c_backend_scm",(void*)f_6092},
{"f_6095:c_backend_scm",(void*)f_6095},
{"f_6098:c_backend_scm",(void*)f_6098},
{"f_6101:c_backend_scm",(void*)f_6101},
{"f_6104:c_backend_scm",(void*)f_6104},
{"f_6107:c_backend_scm",(void*)f_6107},
{"f_6110:c_backend_scm",(void*)f_6110},
{"f_6769:c_backend_scm",(void*)f_6769},
{"f_6113:c_backend_scm",(void*)f_6113},
{"f_6730:c_backend_scm",(void*)f_6730},
{"f_6733:c_backend_scm",(void*)f_6733},
{"f_6736:c_backend_scm",(void*)f_6736},
{"f_6752:c_backend_scm",(void*)f_6752},
{"f_6755:c_backend_scm",(void*)f_6755},
{"f_6116:c_backend_scm",(void*)f_6116},
{"f_6119:c_backend_scm",(void*)f_6119},
{"f_6122:c_backend_scm",(void*)f_6122},
{"f_6702:c_backend_scm",(void*)f_6702},
{"f_6705:c_backend_scm",(void*)f_6705},
{"f_6125:c_backend_scm",(void*)f_6125},
{"f_6128:c_backend_scm",(void*)f_6128},
{"f_6131:c_backend_scm",(void*)f_6131},
{"f_6134:c_backend_scm",(void*)f_6134},
{"f_6137:c_backend_scm",(void*)f_6137},
{"f_6140:c_backend_scm",(void*)f_6140},
{"f_6662:c_backend_scm",(void*)f_6662},
{"f_6664:c_backend_scm",(void*)f_6664},
{"f_6674:c_backend_scm",(void*)f_6674},
{"f_6615:c_backend_scm",(void*)f_6615},
{"f_6620:c_backend_scm",(void*)f_6620},
{"f_6636:c_backend_scm",(void*)f_6636},
{"f_6647:c_backend_scm",(void*)f_6647},
{"f_6143:c_backend_scm",(void*)f_6143},
{"f_6564:c_backend_scm",(void*)f_6564},
{"f_6576:c_backend_scm",(void*)f_6576},
{"f_6579:c_backend_scm",(void*)f_6579},
{"f_6486:c_backend_scm",(void*)f_6486},
{"f_6528:c_backend_scm",(void*)f_6528},
{"f_6489:c_backend_scm",(void*)f_6489},
{"f_6495:c_backend_scm",(void*)f_6495},
{"f_6498:c_backend_scm",(void*)f_6498},
{"f_6422:c_backend_scm",(void*)f_6422},
{"f_6425:c_backend_scm",(void*)f_6425},
{"f_6428:c_backend_scm",(void*)f_6428},
{"f_6431:c_backend_scm",(void*)f_6431},
{"f_6434:c_backend_scm",(void*)f_6434},
{"f_6449:c_backend_scm",(void*)f_6449},
{"f_6437:c_backend_scm",(void*)f_6437},
{"f_6440:c_backend_scm",(void*)f_6440},
{"f_6408:c_backend_scm",(void*)f_6408},
{"f_6416:c_backend_scm",(void*)f_6416},
{"f_6333:c_backend_scm",(void*)f_6333},
{"f_6339:c_backend_scm",(void*)f_6339},
{"f_6342:c_backend_scm",(void*)f_6342},
{"f_6376:c_backend_scm",(void*)f_6376},
{"f_6379:c_backend_scm",(void*)f_6379},
{"f_6382:c_backend_scm",(void*)f_6382},
{"f_6345:c_backend_scm",(void*)f_6345},
{"f_6348:c_backend_scm",(void*)f_6348},
{"f_6351:c_backend_scm",(void*)f_6351},
{"f_6354:c_backend_scm",(void*)f_6354},
{"f_6363:c_backend_scm",(void*)f_6363},
{"f_6366:c_backend_scm",(void*)f_6366},
{"f_6146:c_backend_scm",(void*)f_6146},
{"f_6169:c_backend_scm",(void*)f_6169},
{"f_6274:c_backend_scm",(void*)f_6274},
{"f_6277:c_backend_scm",(void*)f_6277},
{"f_6289:c_backend_scm",(void*)f_6289},
{"f_6280:c_backend_scm",(void*)f_6280},
{"f_6175:c_backend_scm",(void*)f_6175},
{"f_6178:c_backend_scm",(void*)f_6178},
{"f_6261:c_backend_scm",(void*)f_6261},
{"f_6181:c_backend_scm",(void*)f_6181},
{"f_6184:c_backend_scm",(void*)f_6184},
{"f_6187:c_backend_scm",(void*)f_6187},
{"f_6190:c_backend_scm",(void*)f_6190},
{"f_6255:c_backend_scm",(void*)f_6255},
{"f_6251:c_backend_scm",(void*)f_6251},
{"f_6193:c_backend_scm",(void*)f_6193},
{"f_6196:c_backend_scm",(void*)f_6196},
{"f_6199:c_backend_scm",(void*)f_6199},
{"f_6202:c_backend_scm",(void*)f_6202},
{"f_6205:c_backend_scm",(void*)f_6205},
{"f_6208:c_backend_scm",(void*)f_6208},
{"f_6226:c_backend_scm",(void*)f_6226},
{"f_6236:c_backend_scm",(void*)f_6236},
{"f_6211:c_backend_scm",(void*)f_6211},
{"f_6149:c_backend_scm",(void*)f_6149},
{"f_6159:c_backend_scm",(void*)f_6159},
{"f_6152:c_backend_scm",(void*)f_6152},
{"f_5984:c_backend_scm",(void*)f_5984},
{"f_5991:c_backend_scm",(void*)f_5991},
{"f_5994:c_backend_scm",(void*)f_5994},
{"f_5907:c_backend_scm",(void*)f_5907},
{"f_5914:c_backend_scm",(void*)f_5914},
{"f_5917:c_backend_scm",(void*)f_5917},
{"f_5922:c_backend_scm",(void*)f_5922},
{"f_5978:c_backend_scm",(void*)f_5978},
{"f_5974:c_backend_scm",(void*)f_5974},
{"f_5959:c_backend_scm",(void*)f_5959},
{"f_5938:c_backend_scm",(void*)f_5938},
{"f_5949:c_backend_scm",(void*)f_5949},
{"f_5945:c_backend_scm",(void*)f_5945},
{"f_5765:c_backend_scm",(void*)f_5765},
{"f_5905:c_backend_scm",(void*)f_5905},
{"f_5772:c_backend_scm",(void*)f_5772},
{"f_5778:c_backend_scm",(void*)f_5778},
{"f_5861:c_backend_scm",(void*)f_5861},
{"f_5864:c_backend_scm",(void*)f_5864},
{"f_5874:c_backend_scm",(void*)f_5874},
{"f_5867:c_backend_scm",(void*)f_5867},
{"f_5828:c_backend_scm",(void*)f_5828},
{"f_5834:c_backend_scm",(void*)f_5834},
{"f_5571:c_backend_scm",(void*)f_5571},
{"f_5578:c_backend_scm",(void*)f_5578},
{"f_5687:c_backend_scm",(void*)f_5687},
{"f_5705:c_backend_scm",(void*)f_5705},
{"f_5734:c_backend_scm",(void*)f_5734},
{"f_5756:c_backend_scm",(void*)f_5756},
{"f_5712:c_backend_scm",(void*)f_5712},
{"f_5646:c_backend_scm",(void*)f_5646},
{"f_5648:c_backend_scm",(void*)f_5648},
{"f_5677:c_backend_scm",(void*)f_5677},
{"f_5642:c_backend_scm",(void*)f_5642},
{"f_5638:c_backend_scm",(void*)f_5638},
{"f_5609:c_backend_scm",(void*)f_5609},
{"f_5613:c_backend_scm",(void*)f_5613},
{"f_5516:c_backend_scm",(void*)f_5516},
{"f_5522:c_backend_scm",(void*)f_5522},
{"f_5551:c_backend_scm",(void*)f_5551},
{"f_5554:c_backend_scm",(void*)f_5554},
{"f_5557:c_backend_scm",(void*)f_5557},
{"f_5560:c_backend_scm",(void*)f_5560},
{"f_5563:c_backend_scm",(void*)f_5563},
{"f_5532:c_backend_scm",(void*)f_5532},
{"f_5196:c_backend_scm",(void*)f_5196},
{"f_5385:c_backend_scm",(void*)f_5385},
{"f_5503:c_backend_scm",(void*)f_5503},
{"f_5393:c_backend_scm",(void*)f_5393},
{"f_5397:c_backend_scm",(void*)f_5397},
{"f_5400:c_backend_scm",(void*)f_5400},
{"f_5403:c_backend_scm",(void*)f_5403},
{"f_5406:c_backend_scm",(void*)f_5406},
{"f_5409:c_backend_scm",(void*)f_5409},
{"f_5500:c_backend_scm",(void*)f_5500},
{"f_5412:c_backend_scm",(void*)f_5412},
{"f_5415:c_backend_scm",(void*)f_5415},
{"f_5421:c_backend_scm",(void*)f_5421},
{"f_5489:c_backend_scm",(void*)f_5489},
{"f_5455:c_backend_scm",(void*)f_5455},
{"f_5461:c_backend_scm",(void*)f_5461},
{"f_5469:c_backend_scm",(void*)f_5469},
{"f_5465:c_backend_scm",(void*)f_5465},
{"f_5427:c_backend_scm",(void*)f_5427},
{"f_5430:c_backend_scm",(void*)f_5430},
{"f_5433:c_backend_scm",(void*)f_5433},
{"f_5436:c_backend_scm",(void*)f_5436},
{"f_5439:c_backend_scm",(void*)f_5439},
{"f_5449:c_backend_scm",(void*)f_5449},
{"f_5442:c_backend_scm",(void*)f_5442},
{"f_5315:c_backend_scm",(void*)f_5315},
{"f_5334:c_backend_scm",(void*)f_5334},
{"f_5372:c_backend_scm",(void*)f_5372},
{"f_5342:c_backend_scm",(void*)f_5342},
{"f_5346:c_backend_scm",(void*)f_5346},
{"f_5349:c_backend_scm",(void*)f_5349},
{"f_5352:c_backend_scm",(void*)f_5352},
{"f_5355:c_backend_scm",(void*)f_5355},
{"f_5369:c_backend_scm",(void*)f_5369},
{"f_5365:c_backend_scm",(void*)f_5365},
{"f_5358:c_backend_scm",(void*)f_5358},
{"f_5318:c_backend_scm",(void*)f_5318},
{"f_5332:c_backend_scm",(void*)f_5332},
{"f_5321:c_backend_scm",(void*)f_5321},
{"f_5328:c_backend_scm",(void*)f_5328},
{"f_5235:c_backend_scm",(void*)f_5235},
{"f_5237:c_backend_scm",(void*)f_5237},
{"f_5241:c_backend_scm",(void*)f_5241},
{"f_5244:c_backend_scm",(void*)f_5244},
{"f_5247:c_backend_scm",(void*)f_5247},
{"f_5250:c_backend_scm",(void*)f_5250},
{"f_5253:c_backend_scm",(void*)f_5253},
{"f_5256:c_backend_scm",(void*)f_5256},
{"f_5259:c_backend_scm",(void*)f_5259},
{"f_5262:c_backend_scm",(void*)f_5262},
{"f_5265:c_backend_scm",(void*)f_5265},
{"f_5268:c_backend_scm",(void*)f_5268},
{"f_5271:c_backend_scm",(void*)f_5271},
{"f_5274:c_backend_scm",(void*)f_5274},
{"f_5288:c_backend_scm",(void*)f_5288},
{"f_5284:c_backend_scm",(void*)f_5284},
{"f_5277:c_backend_scm",(void*)f_5277},
{"f_5199:c_backend_scm",(void*)f_5199},
{"f_5212:c_backend_scm",(void*)f_5212},
{"f_5222:c_backend_scm",(void*)f_5222},
{"f_5203:c_backend_scm",(void*)f_5203},
{"f_4862:c_backend_scm",(void*)f_4862},
{"f_4866:c_backend_scm",(void*)f_4866},
{"f_4935:c_backend_scm",(void*)f_4935},
{"f_5183:c_backend_scm",(void*)f_5183},
{"f_4943:c_backend_scm",(void*)f_4943},
{"f_4947:c_backend_scm",(void*)f_4947},
{"f_4950:c_backend_scm",(void*)f_4950},
{"f_5180:c_backend_scm",(void*)f_5180},
{"f_4953:c_backend_scm",(void*)f_4953},
{"f_5166:c_backend_scm",(void*)f_5166},
{"f_4956:c_backend_scm",(void*)f_4956},
{"f_4959:c_backend_scm",(void*)f_4959},
{"f_4962:c_backend_scm",(void*)f_4962},
{"f_4965:c_backend_scm",(void*)f_4965},
{"f_4968:c_backend_scm",(void*)f_4968},
{"f_4971:c_backend_scm",(void*)f_4971},
{"f_5158:c_backend_scm",(void*)f_5158},
{"f_4974:c_backend_scm",(void*)f_4974},
{"f_4977:c_backend_scm",(void*)f_4977},
{"f_5112:c_backend_scm",(void*)f_5112},
{"f_5114:c_backend_scm",(void*)f_5114},
{"f_5140:c_backend_scm",(void*)f_5140},
{"f_5122:c_backend_scm",(void*)f_5122},
{"f_5133:c_backend_scm",(void*)f_5133},
{"f_4980:c_backend_scm",(void*)f_4980},
{"f_5067:c_backend_scm",(void*)f_5067},
{"f_5070:c_backend_scm",(void*)f_5070},
{"f_5073:c_backend_scm",(void*)f_5073},
{"f_5076:c_backend_scm",(void*)f_5076},
{"f_5092:c_backend_scm",(void*)f_5092},
{"f_5095:c_backend_scm",(void*)f_5095},
{"f_5098:c_backend_scm",(void*)f_5098},
{"f_4983:c_backend_scm",(void*)f_4983},
{"f_4986:c_backend_scm",(void*)f_4986},
{"f_4989:c_backend_scm",(void*)f_4989},
{"f_5039:c_backend_scm",(void*)f_5039},
{"f_5042:c_backend_scm",(void*)f_5042},
{"f_4992:c_backend_scm",(void*)f_4992},
{"f_4995:c_backend_scm",(void*)f_4995},
{"f_5027:c_backend_scm",(void*)f_5027},
{"f_5030:c_backend_scm",(void*)f_5030},
{"f_5001:c_backend_scm",(void*)f_5001},
{"f_5010:c_backend_scm",(void*)f_5010},
{"f_5013:c_backend_scm",(void*)f_5013},
{"f_4869:c_backend_scm",(void*)f_4869},
{"f_4874:c_backend_scm",(void*)f_4874},
{"f_4886:c_backend_scm",(void*)f_4886},
{"f_4896:c_backend_scm",(void*)f_4896},
{"f_4898:c_backend_scm",(void*)f_4898},
{"f_4908:c_backend_scm",(void*)f_4908},
{"f_4889:c_backend_scm",(void*)f_4889},
{"f_4922:c_backend_scm",(void*)f_4922},
{"f_4691:c_backend_scm",(void*)f_4691},
{"f_4698:c_backend_scm",(void*)f_4698},
{"f_4834:c_backend_scm",(void*)f_4834},
{"f_4849:c_backend_scm",(void*)f_4849},
{"f_4701:c_backend_scm",(void*)f_4701},
{"f_4704:c_backend_scm",(void*)f_4704},
{"f_4707:c_backend_scm",(void*)f_4707},
{"f_4712:c_backend_scm",(void*)f_4712},
{"f_4722:c_backend_scm",(void*)f_4722},
{"f_4728:c_backend_scm",(void*)f_4728},
{"f_4781:c_backend_scm",(void*)f_4781},
{"f_4791:c_backend_scm",(void*)f_4791},
{"f_4731:c_backend_scm",(void*)f_4731},
{"f_4754:c_backend_scm",(void*)f_4754},
{"f_4764:c_backend_scm",(void*)f_4764},
{"f_4734:c_backend_scm",(void*)f_4734},
{"f_4737:c_backend_scm",(void*)f_4737},
{"f_4522:c_backend_scm",(void*)f_4522},
{"f_4683:c_backend_scm",(void*)f_4683},
{"f_4542:c_backend_scm",(void*)f_4542},
{"f_4641:c_backend_scm",(void*)f_4641},
{"f_4645:c_backend_scm",(void*)f_4645},
{"f_4649:c_backend_scm",(void*)f_4649},
{"f_4653:c_backend_scm",(void*)f_4653},
{"f_4675:c_backend_scm",(void*)f_4675},
{"f_4671:c_backend_scm",(void*)f_4671},
{"f_4663:c_backend_scm",(void*)f_4663},
{"f_4661:c_backend_scm",(void*)f_4661},
{"f_4657:c_backend_scm",(void*)f_4657},
{"f_4560:c_backend_scm",(void*)f_4560},
{"f_4563:c_backend_scm",(void*)f_4563},
{"f_4566:c_backend_scm",(void*)f_4566},
{"f_4630:c_backend_scm",(void*)f_4630},
{"f_4569:c_backend_scm",(void*)f_4569},
{"f_4572:c_backend_scm",(void*)f_4572},
{"f_4575:c_backend_scm",(void*)f_4575},
{"f_4590:c_backend_scm",(void*)f_4590},
{"f_4595:c_backend_scm",(void*)f_4595},
{"f_4610:c_backend_scm",(void*)f_4610},
{"f_4578:c_backend_scm",(void*)f_4578},
{"f_4525:c_backend_scm",(void*)f_4525},
{"f_4539:c_backend_scm",(void*)f_4539},
{"f_2641:c_backend_scm",(void*)f_2641},
{"f_4490:c_backend_scm",(void*)f_4490},
{"f_4496:c_backend_scm",(void*)f_4496},
{"f_4500:c_backend_scm",(void*)f_4500},
{"f_2644:c_backend_scm",(void*)f_2644},
{"f_4446:c_backend_scm",(void*)f_4446},
{"f_4449:c_backend_scm",(void*)f_4449},
{"f_4452:c_backend_scm",(void*)f_4452},
{"f_4455:c_backend_scm",(void*)f_4455},
{"f_4458:c_backend_scm",(void*)f_4458},
{"f_4461:c_backend_scm",(void*)f_4461},
{"f_4363:c_backend_scm",(void*)f_4363},
{"f_4366:c_backend_scm",(void*)f_4366},
{"f_4369:c_backend_scm",(void*)f_4369},
{"f_4382:c_backend_scm",(void*)f_4382},
{"f_4405:c_backend_scm",(void*)f_4405},
{"f_4408:c_backend_scm",(void*)f_4408},
{"f_4411:c_backend_scm",(void*)f_4411},
{"f_4414:c_backend_scm",(void*)f_4414},
{"f_4392:c_backend_scm",(void*)f_4392},
{"f_4395:c_backend_scm",(void*)f_4395},
{"f_4344:c_backend_scm",(void*)f_4344},
{"f_4347:c_backend_scm",(void*)f_4347},
{"f_4321:c_backend_scm",(void*)f_4321},
{"f_4324:c_backend_scm",(void*)f_4324},
{"f_4299:c_backend_scm",(void*)f_4299},
{"f_4271:c_backend_scm",(void*)f_4271},
{"f_4274:c_backend_scm",(void*)f_4274},
{"f_4291:c_backend_scm",(void*)f_4291},
{"f_4277:c_backend_scm",(void*)f_4277},
{"f_4280:c_backend_scm",(void*)f_4280},
{"f_4255:c_backend_scm",(void*)f_4255},
{"f_4259:c_backend_scm",(void*)f_4259},
{"f_4241:c_backend_scm",(void*)f_4241},
{"f_4244:c_backend_scm",(void*)f_4244},
{"f_4225:c_backend_scm",(void*)f_4225},
{"f_4229:c_backend_scm",(void*)f_4229},
{"f_4207:c_backend_scm",(void*)f_4207},
{"f_4210:c_backend_scm",(void*)f_4210},
{"f_4187:c_backend_scm",(void*)f_4187},
{"f_4151:c_backend_scm",(void*)f_4151},
{"f_4163:c_backend_scm",(void*)f_4163},
{"f_4154:c_backend_scm",(void*)f_4154},
{"f_4132:c_backend_scm",(void*)f_4132},
{"f_4135:c_backend_scm",(void*)f_4135},
{"f_4113:c_backend_scm",(void*)f_4113},
{"f_4116:c_backend_scm",(void*)f_4116},
{"f_4094:c_backend_scm",(void*)f_4094},
{"f_4097:c_backend_scm",(void*)f_4097},
{"f_4075:c_backend_scm",(void*)f_4075},
{"f_4071:c_backend_scm",(void*)f_4071},
{"f_4019:c_backend_scm",(void*)f_4019},
{"f_4052:c_backend_scm",(void*)f_4052},
{"f_4022:c_backend_scm",(void*)f_4022},
{"f_4040:c_backend_scm",(void*)f_4040},
{"f_4025:c_backend_scm",(void*)f_4025},
{"f_4028:c_backend_scm",(void*)f_4028},
{"f_3986:c_backend_scm",(void*)f_3986},
{"f_3970:c_backend_scm",(void*)f_3970},
{"f11141:c_backend_scm",(void*)f11141},
{"f_3973:c_backend_scm",(void*)f_3973},
{"f_3976:c_backend_scm",(void*)f_3976},
{"f_3857:c_backend_scm",(void*)f_3857},
{"f_3860:c_backend_scm",(void*)f_3860},
{"f_3917:c_backend_scm",(void*)f_3917},
{"f_3938:c_backend_scm",(void*)f_3938},
{"f_3925:c_backend_scm",(void*)f_3925},
{"f_3929:c_backend_scm",(void*)f_3929},
{"f_3932:c_backend_scm",(void*)f_3932},
{"f_3863:c_backend_scm",(void*)f_3863},
{"f_3873:c_backend_scm",(void*)f_3873},
{"f_3875:c_backend_scm",(void*)f_3875},
{"f_3890:c_backend_scm",(void*)f_3890},
{"f_3866:c_backend_scm",(void*)f_3866},
{"f_3398:c_backend_scm",(void*)f_3398},
{"f_3401:c_backend_scm",(void*)f_3401},
{"f_3807:c_backend_scm",(void*)f_3807},
{"f_3803:c_backend_scm",(void*)f_3803},
{"f_3407:c_backend_scm",(void*)f_3407},
{"f11133:c_backend_scm",(void*)f11133},
{"f_3796:c_backend_scm",(void*)f_3796},
{"f_2629:c_backend_scm",(void*)f_2629},
{"f_3789:c_backend_scm",(void*)f_3789},
{"f_3413:c_backend_scm",(void*)f_3413},
{"f_3617:c_backend_scm",(void*)f_3617},
{"f_3706:c_backend_scm",(void*)f_3706},
{"f_3709:c_backend_scm",(void*)f_3709},
{"f_3712:c_backend_scm",(void*)f_3712},
{"f_3727:c_backend_scm",(void*)f_3727},
{"f_3715:c_backend_scm",(void*)f_3715},
{"f_3718:c_backend_scm",(void*)f_3718},
{"f_3721:c_backend_scm",(void*)f_3721},
{"f_3637:c_backend_scm",(void*)f_3637},
{"f_3703:c_backend_scm",(void*)f_3703},
{"f_3696:c_backend_scm",(void*)f_3696},
{"f_3692:c_backend_scm",(void*)f_3692},
{"f_3685:c_backend_scm",(void*)f_3685},
{"f_3678:c_backend_scm",(void*)f_3678},
{"f_3653:c_backend_scm",(void*)f_3653},
{"f_3670:c_backend_scm",(void*)f_3670},
{"f_3666:c_backend_scm",(void*)f_3666},
{"f_3640:c_backend_scm",(void*)f_3640},
{"f_3643:c_backend_scm",(void*)f_3643},
{"f_3646:c_backend_scm",(void*)f_3646},
{"f_3611:c_backend_scm",(void*)f_3611},
{"f_3449:c_backend_scm",(void*)f_3449},
{"f_3595:c_backend_scm",(void*)f_3595},
{"f_3598:c_backend_scm",(void*)f_3598},
{"f_3571:c_backend_scm",(void*)f_3571},
{"f_3574:c_backend_scm",(void*)f_3574},
{"f_3577:c_backend_scm",(void*)f_3577},
{"f11128:c_backend_scm",(void*)f11128},
{"f_3580:c_backend_scm",(void*)f_3580},
{"f_3583:c_backend_scm",(void*)f_3583},
{"f_3452:c_backend_scm",(void*)f_3452},
{"f_3455:c_backend_scm",(void*)f_3455},
{"f_3518:c_backend_scm",(void*)f_3518},
{"f_3539:c_backend_scm",(void*)f_3539},
{"f_3526:c_backend_scm",(void*)f_3526},
{"f_3530:c_backend_scm",(void*)f_3530},
{"f_3533:c_backend_scm",(void*)f_3533},
{"f_3458:c_backend_scm",(void*)f_3458},
{"f_3474:c_backend_scm",(void*)f_3474},
{"f_3476:c_backend_scm",(void*)f_3476},
{"f_3491:c_backend_scm",(void*)f_3491},
{"f_3461:c_backend_scm",(void*)f_3461},
{"f_3464:c_backend_scm",(void*)f_3464},
{"f_3430:c_backend_scm",(void*)f_3430},
{"f_3433:c_backend_scm",(void*)f_3433},
{"f_3365:c_backend_scm",(void*)f_3365},
{"f11120:c_backend_scm",(void*)f11120},
{"f_3361:c_backend_scm",(void*)f_3361},
{"f_3347:c_backend_scm",(void*)f_3347},
{"f_3350:c_backend_scm",(void*)f_3350},
{"f_3344:c_backend_scm",(void*)f_3344},
{"f11115:c_backend_scm",(void*)f11115},
{"f_3340:c_backend_scm",(void*)f_3340},
{"f_3326:c_backend_scm",(void*)f_3326},
{"f_3329:c_backend_scm",(void*)f_3329},
{"f_3278:c_backend_scm",(void*)f_3278},
{"f_3299:c_backend_scm",(void*)f_3299},
{"f11110:c_backend_scm",(void*)f11110},
{"f_3295:c_backend_scm",(void*)f_3295},
{"f_3281:c_backend_scm",(void*)f_3281},
{"f_3284:c_backend_scm",(void*)f_3284},
{"f_3247:c_backend_scm",(void*)f_3247},
{"f_3243:c_backend_scm",(void*)f_3243},
{"f_3201:c_backend_scm",(void*)f_3201},
{"f_3169:c_backend_scm",(void*)f_3169},
{"f_3172:c_backend_scm",(void*)f_3172},
{"f_3098:c_backend_scm",(void*)f_3098},
{"f_3112:c_backend_scm",(void*)f_3112},
{"f_3114:c_backend_scm",(void*)f_3114},
{"f_3135:c_backend_scm",(void*)f_3135},
{"f_3122:c_backend_scm",(void*)f_3122},
{"f_3126:c_backend_scm",(void*)f_3126},
{"f_3129:c_backend_scm",(void*)f_3129},
{"f_3101:c_backend_scm",(void*)f_3101},
{"f_3066:c_backend_scm",(void*)f_3066},
{"f_3069:c_backend_scm",(void*)f_3069},
{"f_3072:c_backend_scm",(void*)f_3072},
{"f_3075:c_backend_scm",(void*)f_3075},
{"f_3037:c_backend_scm",(void*)f_3037},
{"f_3040:c_backend_scm",(void*)f_3040},
{"f_3043:c_backend_scm",(void*)f_3043},
{"f_3046:c_backend_scm",(void*)f_3046},
{"f_3000:c_backend_scm",(void*)f_3000},
{"f_3003:c_backend_scm",(void*)f_3003},
{"f_3006:c_backend_scm",(void*)f_3006},
{"f_3009:c_backend_scm",(void*)f_3009},
{"f_2967:c_backend_scm",(void*)f_2967},
{"f_2970:c_backend_scm",(void*)f_2970},
{"f_2973:c_backend_scm",(void*)f_2973},
{"f_2976:c_backend_scm",(void*)f_2976},
{"f_2948:c_backend_scm",(void*)f_2948},
{"f_2951:c_backend_scm",(void*)f_2951},
{"f_2921:c_backend_scm",(void*)f_2921},
{"f_2924:c_backend_scm",(void*)f_2924},
{"f_2895:c_backend_scm",(void*)f_2895},
{"f_2898:c_backend_scm",(void*)f_2898},
{"f_2901:c_backend_scm",(void*)f_2901},
{"f_2841:c_backend_scm",(void*)f_2841},
{"f_2851:c_backend_scm",(void*)f_2851},
{"f_2854:c_backend_scm",(void*)f_2854},
{"f_2857:c_backend_scm",(void*)f_2857},
{"f_2783:c_backend_scm",(void*)f_2783},
{"f_2786:c_backend_scm",(void*)f_2786},
{"f_2789:c_backend_scm",(void*)f_2789},
{"f_2792:c_backend_scm",(void*)f_2792},
{"f_2795:c_backend_scm",(void*)f_2795},
{"f_2798:c_backend_scm",(void*)f_2798},
{"f_2599:c_backend_scm",(void*)f_2599},
{"f_2611:c_backend_scm",(void*)f_2611},
{"f_2619:c_backend_scm",(void*)f_2619},
{"f_2603:c_backend_scm",(void*)f_2603},
{"f_2554:c_backend_scm",(void*)f_2554},
{"f_2562:c_backend_scm",(void*)f_2562},
{"f_2564:c_backend_scm",(void*)f_2564},
{"f_2579:c_backend_scm",(void*)f_2579},
{"f_2511:c_backend_scm",(void*)f_2511},
{"f_2517:c_backend_scm",(void*)f_2517},
{"f_2541:c_backend_scm",(void*)f_2541},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
