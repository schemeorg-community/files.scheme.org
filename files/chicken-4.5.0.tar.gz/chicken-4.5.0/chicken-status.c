/* Generated from chicken-status.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:53
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: chicken-status.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -ignore-repository -output-file chicken-status.c
   used units: library eval srfi_1 posix data_structures utils ports regex files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[56];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_383)
static void C_ccall f_383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_747)
static void C_fcall f_747(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_791)
static void C_fcall f_791(C_word t0,C_word t1) C_noret;
C_noret_decl(f_836)
static void C_fcall f_836(C_word t0,C_word t1) C_noret;
C_noret_decl(f1019)
static void C_ccall f1019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_885)
static void C_ccall f_885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_845)
static void C_ccall f_845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1014)
static void C_ccall f1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_868)
static void C_ccall f_868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_862)
static void C_ccall f_862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_830)
static void C_ccall f_830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_823)
static void C_ccall f_823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1009)
static void C_ccall f1009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_ccall f_474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_470)
static void C_ccall f_470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_431)
static void C_ccall f_431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_433)
static void C_fcall f_433(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_462)
static void C_ccall f_462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_423)
static void C_ccall f_423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_421)
static void C_ccall f_421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_417)
static void C_ccall f_417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_757)
static void C_ccall f_757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_941)
static void C_ccall f_941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_938)
static void C_ccall f_938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_678)
static void C_ccall f_678(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_715)
static void C_ccall f_715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_729)
static void C_ccall f_729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_713)
static void C_ccall f_713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_686)
static void C_ccall f_686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_688)
static void C_fcall f_688(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_560)
static void C_ccall f_560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_566)
static void C_ccall f_566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_586)
static void C_ccall f_586(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_586)
static void C_ccall f_586r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_580)
static void C_ccall f_580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_569)
static void C_ccall f_569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_676)
static void C_ccall f_676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_596)
static void C_ccall f_596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_603)
static void C_ccall f_603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_605)
static void C_fcall f_605(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_657)
static void C_ccall f_657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_613)
static void C_fcall f_613(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_654)
static void C_ccall f_654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_647)
static void C_ccall f_647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_627)
static void C_ccall f_627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_635)
static void C_ccall f_635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_631)
static void C_ccall f_631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_476)
static void C_fcall f_476(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_508)
static void C_fcall f_508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_503)
static void C_fcall f_503(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_478)
static void C_fcall f_478(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_485)
static void C_ccall f_485(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_747)
static void C_fcall trf_747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_747(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_747(t0,t1,t2,t3);}

C_noret_decl(trf_791)
static void C_fcall trf_791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_791(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_791(t0,t1);}

C_noret_decl(trf_836)
static void C_fcall trf_836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_836(t0,t1);}

C_noret_decl(trf_433)
static void C_fcall trf_433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_433(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_433(t0,t1,t2);}

C_noret_decl(trf_688)
static void C_fcall trf_688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_688(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_688(t0,t1,t2);}

C_noret_decl(trf_605)
static void C_fcall trf_605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_605(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_605(t0,t1,t2);}

C_noret_decl(trf_613)
static void C_fcall trf_613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_613(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_613(t0,t1,t2);}

C_noret_decl(trf_476)
static void C_fcall trf_476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_476(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_476(t0,t1,t2,t3);}

C_noret_decl(trf_508)
static void C_fcall trf_508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_508(t0,t1);}

C_noret_decl(trf_503)
static void C_fcall trf_503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_503(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_503(t0,t1,t2);}

C_noret_decl(trf_478)
static void C_fcall trf_478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_478(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_478(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(379)){
C_save(t1);
C_rereclaim2(379*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,56);
lf[1]=C_h_intern(&lf[1],13,"string-append");
lf[2]=C_h_intern(&lf[2],11,"make-string");
lf[3]=C_h_intern(&lf[3],5,"fxmax");
lf[4]=C_h_intern(&lf[4],9,"\003syserror");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[7]=C_h_intern(&lf[7],7,"version");
lf[8]=C_h_intern(&lf[8],5,"print");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\012 version: ");
lf[10]=C_h_intern(&lf[10],8,"->string");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[12]=C_h_intern(&lf[12],19,"setup-api#read-info");
lf[13]=C_h_intern(&lf[13],4,"sort");
lf[14]=C_h_intern(&lf[14],8,"string<\077");
lf[15]=C_h_intern(&lf[15],3,"min");
lf[16]=C_h_intern(&lf[16],13,"terminal-size");
lf[17]=C_h_intern(&lf[17],14,"terminal-port\077");
lf[18]=C_h_intern(&lf[18],19,"current-output-port");
lf[20]=C_h_intern(&lf[20],5,"files");
lf[21]=C_h_intern(&lf[21],10,"append-map");
lf[22]=C_h_intern(&lf[22],25,"\003sysimplicit-exit-handler");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\006(none)");
lf[24]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002.*\376\377\016");
lf[25]=C_h_intern(&lf[25],17,"delete-duplicates");
lf[26]=C_h_intern(&lf[26],8,"string=\077");
lf[27]=C_h_intern(&lf[27],11,"concatenate");
lf[28]=C_h_intern(&lf[28],4,"grep");
lf[29]=C_h_intern(&lf[29],7,"\003sysmap");
lf[30]=C_h_intern(&lf[30],13,"pathname-file");
lf[31]=C_h_intern(&lf[31],4,"glob");
lf[32]=C_h_intern(&lf[32],13,"make-pathname");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[35]=C_h_intern(&lf[35],15,"repository-path");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[37]=C_h_intern(&lf[37],4,"exit");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\312usage: chicken-status [OPTION | PATTERN] ...\012\012  -h   -help                 "
"   show this message\012  -v   -version                 show version and exit\012  -f "
"  -files                   list installed files");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\002-f");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\006-files");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[43]=C_h_intern(&lf[43],15,"chicken-version");
lf[44]=C_h_intern(&lf[44],6,"append");
lf[45]=C_h_intern(&lf[45],6,"string");
lf[46]=C_h_intern(&lf[46],4,"memq");
lf[47]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000f\376\377\016");
lf[48]=C_h_intern(&lf[48],5,"every");
lf[49]=C_h_intern(&lf[49],16,"\003sysstring->list");
lf[50]=C_h_intern(&lf[50],9,"substring");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[53]=C_h_intern(&lf[53],22,"command-line-arguments");
lf[54]=C_h_intern(&lf[54],11,"\003sysrequire");
lf[55]=C_h_intern(&lf[55],9,"setup-api");
C_register_lf2(lf,56,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_377,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k375 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k378 in k375 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k381 in k378 in k375 */
static void C_ccall f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k384 in k381 in k378 in k375 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t2,lf[55]);}

/* k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_404,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_476,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[6] /* (set! main#list-installed-eggs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_592,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[19] /* (set! main#list-installed-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_678,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_935,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_945,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 131  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t6);}

/* k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_747,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_747(t7,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_fcall f_747(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_747,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_757,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_nullp(t3);
t6=(C_truep(t5)?lf[24]:t3);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_410,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_431,a[2]=t11,a[3]=t8,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_470,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_474,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 38   repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[35]))(2,*((C_word*)lf[35]+1),t14);}
else{
t4=C_i_car(t2);
t5=C_i_string_equal_p(t4,lf[36]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_791,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_791(t7,t5);}
else{
t7=C_i_string_equal_p(t4,lf[51]);
t8=t6;
f_791(t8,(C_truep(t7)?t7:C_i_string_equal_p(t4,lf[52])));}}}

/* k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_fcall f_791(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_791,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1009,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 89   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t3,lf[38]);}
else{
t2=C_i_string_equal_p(((C_word*)t0)[6],lf[39]);
t3=(C_truep(t2)?t2:C_i_string_equal_p(((C_word*)t0)[6],lf[40]));
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t5=C_i_cdr(((C_word*)t0)[4]);
/* chicken-status.scm: 117  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_747(t6,((C_word*)t0)[7],t5,((C_word*)t0)[2]);}
else{
t4=C_i_string_equal_p(((C_word*)t0)[6],lf[41]);
t5=(C_truep(t4)?t4:C_i_string_equal_p(((C_word*)t0)[6],lf[42]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_823,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_830,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 119  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[43]))(2,*((C_word*)lf[43]+1),t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_836,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=C_i_string_length(((C_word*)t0)[6]);
if(C_truep(C_i_positivep(t7))){
t8=C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t9=t6;
f_836(t9,C_eqp(C_make_character(45),t8));}
else{
t8=t6;
f_836(t8,C_SCHEME_FALSE);}}}}}

/* k834 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_fcall f_836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_836,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_string_length(((C_word*)t0)[6]);
if(C_truep(C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_885,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 124  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1019,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 89   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t4,lf[38]);}}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[3]);
/* chicken-status.scm: 129  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_747(t4,((C_word*)t0)[4],t2,t3);}}

/* f1019 in k834 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f1019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 97   exit */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],C_fix(1));}

/* k883 in k834 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[49]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k843 in k834 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_851,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_877,tmp=(C_word)a,a+=2,tmp);
/* chicken-status.scm: 125  every */
((C_proc4)C_retrieve_symbol_proc(lf[48]))(4,*((C_word*)lf[48]+1),t2,t3,t1);}

/* a876 in k843 in k834 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_877,3,t0,t1,t2);}
t3=*((C_word*)lf[46]+1);
/* g326327 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[47]);}

/* k849 in k843 in k834 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_851,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_858,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_862,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_868,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1014,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 89   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t3,lf[38]);}}

/* f1014 in k849 in k843 in k834 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 97   exit */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],C_fix(1));}

/* a867 in k849 in k843 in k834 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_868,3,t0,t1,t2);}
t3=*((C_word*)lf[45]+1);
/* g347348 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(45),t2);}

/* k860 in k849 in k843 in k834 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
/* chicken-status.scm: 126  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[44]+1)))(4,*((C_word*)lf[44]+1),((C_word*)t0)[2],t1,t2);}

/* k856 in k849 in k843 in k834 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 126  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_747(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k828 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 119  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],t1);}

/* k821 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 120  exit */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],C_fix(0));}

/* f1009 in k789 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f1009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 97   exit */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],C_fix(0));}

/* k472 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 38   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],t1,lf[33],lf[34]);}

/* k468 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 38   glob */
((C_proc3)C_retrieve_symbol_proc(lf[31]))(3,*((C_word*)lf[31]+1),((C_word*)t0)[2],t1);}

/* k429 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_431,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_433,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_433(t5,((C_word*)t0)[2],t1);}

/* loop155 in k429 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_fcall f_433(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_433,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[30]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_462,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g171172 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k460 in loop155 in k429 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_462,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop155168 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_433(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop155168 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_433(t6,((C_word*)t0)[3],t5);}}

/* k408 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_417,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_421,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_423,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a422 in k408 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_423,3,t0,t1,t2);}
t3=C_retrieve(lf[28]);
/* g195196 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* k419 in k408 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 40   concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),((C_word*)t0)[2],t1);}

/* k415 in k408 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 39   delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[25]))(4,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1,*((C_word*)lf[26]+1));}

/* k755 in loop in k943 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(C_i_nullp(t1))){
/* chicken-status.scm: 107  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[23]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=C_retrieve2(lf[19],"main#list-installed-files");
t3=C_retrieve2(lf[19],"main#list-installed-files");
/* g285286 */
t4=C_retrieve2(lf[19],"main#list-installed-files");
f_678(3,t4,((C_word*)t0)[3],t1);}
else{
t2=C_retrieve2(lf[6],"main#list-installed-eggs");
t3=C_retrieve2(lf[6],"main#list-installed-eggs");
/* g285286 */
t4=C_retrieve2(lf[6],"main#list-installed-eggs");
f_592(3,t4,((C_word*)t0)[3],t1);}}}

/* k933 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_938,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_941,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t3);}

/* k939 in k933 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k936 in k933 in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#list-installed-files in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_678(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_678,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_686,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_713,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_715,tmp=(C_word)a,a+=2,tmp);
/* chicken-status.scm: 79   append-map */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t4,t5,t2);}

/* a714 in main#list-installed-files in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_715,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_729,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 81   setup-api#read-info */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),t3,t2);}

/* k727 in a714 in main#list-installed-files in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_assq(lf[20],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_i_cdr(t2):C_SCHEME_END_OF_LIST));}

/* k711 in main#list-installed-files in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 78   sort */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1,*((C_word*)lf[14]+1));}

/* k684 in main#list-installed-files in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_686,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_688,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_688(t5,((C_word*)t0)[2],t1);}

/* loop262 in k684 in main#list-installed-files in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_fcall f_688(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_688,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[8]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_698,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g269270 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k696 in loop262 in k684 in main#list-installed-files in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_688(t3,((C_word*)t0)[2],t2);}

/* main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_592,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_596,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_676,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_560,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 53   current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[18]+1)))(2,*((C_word*)lf[18]+1),t5);}

/* k558 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_566,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-status.scm: 54   terminal-port? */
((C_proc3)C_retrieve_symbol_proc(lf[17]))(3,*((C_word*)lf[17]+1),t2,t1);}

/* k564 in k558 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_566,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_580,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_586,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}
else{
t2=((C_word*)t0)[4];
f_596(2,t2,C_fix(39));}}

/* a585 in k564 in k558 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_586(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_586r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_586r(t0,t1,t2);}}

static void C_ccall f_586r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_list_ref(t2,C_fix(1)));}

/* a579 in k564 in k558 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_580,2,t0,t1);}
/* chicken-status.scm: 55   terminal-size */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t1,((C_word*)t0)[2]);}

/* k567 in k564 in k558 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_zerop(t1))){
t2=((C_word*)t0)[3];
f_596(2,t2,C_fix(39));}
else{
/* chicken-status.scm: 58   min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),((C_word*)t0)[2],C_fix(80),t1);}}

/* k674 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_676,2,t0,t1);}
t2=C_a_i_minus(&a,2,t1,C_fix(2));
C_quotient(4,0,((C_word*)t0)[2],t2,C_fix(2));}

/* k594 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_603,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 73   sort */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t2,((C_word*)t0)[2],*((C_word*)lf[14]+1));}

/* k601 in k594 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_603,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_605,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_605(t5,((C_word*)t0)[2],t1);}

/* loop245 in k601 in k594 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_fcall f_605(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_605,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_613,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_657,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g252253 */
t6=t3;
f_613(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k655 in loop245 in k601 in k594 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_605(t3,((C_word*)t0)[2],t2);}

/* g252 in loop245 in k601 in k594 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_fcall f_613(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_613,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_654,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-status.scm: 65   setup-api#read-info */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),t3,t2);}

/* k652 in g252 in loop245 in k601 in k594 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_654,2,t0,t1);}
t2=C_i_assq(lf[7],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_627,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_647,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 68   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t4,((C_word*)t0)[2],lf[11]);}
else{
/* chicken-status.scm: 72   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k645 in k652 in g252 in loop245 in k601 in k594 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_647,2,t0,t1);}
/* chicken-status.scm: 68   format-string */
f_476(((C_word*)t0)[3],t1,((C_word*)t0)[2],C_a_i_list(&a,2,C_SCHEME_FALSE,C_make_character(46)));}

/* k625 in k652 in g252 in loop245 in k601 in k594 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_631,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_635,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_639,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* chicken-status.scm: 70   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[10]))(3,*((C_word*)lf[10]+1),t4,t5);}

/* k637 in k625 in k652 in g252 in loop245 in k601 in k594 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 70   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[9],t1);}

/* k633 in k625 in k652 in g252 in loop245 in k601 in k594 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_635,2,t0,t1);}
/* chicken-status.scm: 69   format-string */
f_476(((C_word*)t0)[3],t1,((C_word*)t0)[2],C_a_i_list(&a,2,C_SCHEME_TRUE,C_make_character(46)));}

/* k629 in k625 in k652 in g252 in loop245 in k601 in k594 in main#list-installed-eggs in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 67   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* main#format-string in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_fcall f_476(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_476,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_478,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_503,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_508,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-right214228 */
t8=t7;
f_508(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* def-padc215226 */
t10=t6;
f_503(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body212220 */
t12=t5;
f_478(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[5],t11);}}}}

/* def-right214 in main#format-string in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_fcall f_508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_508,NULL,2,t0,t1);}
/* def-padc215226 */
t2=((C_word*)t0)[2];
f_503(t2,t1,C_SCHEME_FALSE);}

/* def-padc215 in main#format-string in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_fcall f_503(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_503,NULL,3,t0,t1,t2);}
/* body212220 */
t3=((C_word*)t0)[2];
f_478(t3,t1,t2,C_make_character(32));}

/* body212 in main#format-string in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_fcall f_478(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_478,NULL,4,t0,t1,t2,t3);}
t4=C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_485,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_498,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_fixnum_difference(((C_word*)t0)[2],t4);
/* chicken-status.scm: 45   fxmax */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t6,C_fix(0),t7);}

/* k496 in body212 in main#format-string in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 45   make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[2]+1)))(4,*((C_word*)lf[2]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k483 in body212 in main#format-string in k402 in k399 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 */
static void C_ccall f_485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-status.scm: 47   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-status.scm: 48   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[72] = {
{"toplevel:chicken_status_scm",(void*)C_toplevel},
{"f_377:chicken_status_scm",(void*)f_377},
{"f_380:chicken_status_scm",(void*)f_380},
{"f_383:chicken_status_scm",(void*)f_383},
{"f_386:chicken_status_scm",(void*)f_386},
{"f_389:chicken_status_scm",(void*)f_389},
{"f_392:chicken_status_scm",(void*)f_392},
{"f_395:chicken_status_scm",(void*)f_395},
{"f_398:chicken_status_scm",(void*)f_398},
{"f_401:chicken_status_scm",(void*)f_401},
{"f_404:chicken_status_scm",(void*)f_404},
{"f_945:chicken_status_scm",(void*)f_945},
{"f_747:chicken_status_scm",(void*)f_747},
{"f_791:chicken_status_scm",(void*)f_791},
{"f_836:chicken_status_scm",(void*)f_836},
{"f1019:chicken_status_scm",(void*)f1019},
{"f_885:chicken_status_scm",(void*)f_885},
{"f_845:chicken_status_scm",(void*)f_845},
{"f_877:chicken_status_scm",(void*)f_877},
{"f_851:chicken_status_scm",(void*)f_851},
{"f1014:chicken_status_scm",(void*)f1014},
{"f_868:chicken_status_scm",(void*)f_868},
{"f_862:chicken_status_scm",(void*)f_862},
{"f_858:chicken_status_scm",(void*)f_858},
{"f_830:chicken_status_scm",(void*)f_830},
{"f_823:chicken_status_scm",(void*)f_823},
{"f1009:chicken_status_scm",(void*)f1009},
{"f_474:chicken_status_scm",(void*)f_474},
{"f_470:chicken_status_scm",(void*)f_470},
{"f_431:chicken_status_scm",(void*)f_431},
{"f_433:chicken_status_scm",(void*)f_433},
{"f_462:chicken_status_scm",(void*)f_462},
{"f_410:chicken_status_scm",(void*)f_410},
{"f_423:chicken_status_scm",(void*)f_423},
{"f_421:chicken_status_scm",(void*)f_421},
{"f_417:chicken_status_scm",(void*)f_417},
{"f_757:chicken_status_scm",(void*)f_757},
{"f_935:chicken_status_scm",(void*)f_935},
{"f_941:chicken_status_scm",(void*)f_941},
{"f_938:chicken_status_scm",(void*)f_938},
{"f_678:chicken_status_scm",(void*)f_678},
{"f_715:chicken_status_scm",(void*)f_715},
{"f_729:chicken_status_scm",(void*)f_729},
{"f_713:chicken_status_scm",(void*)f_713},
{"f_686:chicken_status_scm",(void*)f_686},
{"f_688:chicken_status_scm",(void*)f_688},
{"f_698:chicken_status_scm",(void*)f_698},
{"f_592:chicken_status_scm",(void*)f_592},
{"f_560:chicken_status_scm",(void*)f_560},
{"f_566:chicken_status_scm",(void*)f_566},
{"f_586:chicken_status_scm",(void*)f_586},
{"f_580:chicken_status_scm",(void*)f_580},
{"f_569:chicken_status_scm",(void*)f_569},
{"f_676:chicken_status_scm",(void*)f_676},
{"f_596:chicken_status_scm",(void*)f_596},
{"f_603:chicken_status_scm",(void*)f_603},
{"f_605:chicken_status_scm",(void*)f_605},
{"f_657:chicken_status_scm",(void*)f_657},
{"f_613:chicken_status_scm",(void*)f_613},
{"f_654:chicken_status_scm",(void*)f_654},
{"f_647:chicken_status_scm",(void*)f_647},
{"f_627:chicken_status_scm",(void*)f_627},
{"f_639:chicken_status_scm",(void*)f_639},
{"f_635:chicken_status_scm",(void*)f_635},
{"f_631:chicken_status_scm",(void*)f_631},
{"f_476:chicken_status_scm",(void*)f_476},
{"f_508:chicken_status_scm",(void*)f_508},
{"f_503:chicken_status_scm",(void*)f_503},
{"f_478:chicken_status_scm",(void*)f_478},
{"f_498:chicken_status_scm",(void*)f_498},
{"f_485:chicken_status_scm",(void*)f_485},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
