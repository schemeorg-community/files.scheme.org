/* Generated from chicken-profile.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-05-11 12:52
   Version 4.4.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-11 on galinha (Linux)
   command line: chicken-profile.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -output-file chicken-profile.c
   used units: library eval srfi_1 srfi_13 srfi_69 posix utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[84];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_370)
static void C_ccall f_370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_373)
static void C_ccall f_373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_376)
static void C_ccall f_376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_385)
static void C_ccall f_385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_388)
static void C_ccall f_388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_fcall f_443(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_645)
static void C_fcall f_645(C_word t0,C_word t1) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_796)
static void C_fcall f_796(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_598)
static void C_ccall f_598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_581)
static void C_ccall f_581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_574)
static void C_ccall f_574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_565)
static void C_ccall f_565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_558)
static void C_ccall f_558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_540)
static void C_ccall f_540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_517)
static void C_fcall f_517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_537)
static void C_ccall f_537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_521)
static void C_ccall f_521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_fcall f_498(C_word t0,C_word t1) C_noret;
C_noret_decl(f_460)
static void C_ccall f_460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_478)
static void C_ccall f_478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_486)
static void C_ccall f_486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_490)
static void C_ccall f_490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_476)
static void C_ccall f_476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_463)
static void C_ccall f_463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_453)
static void C_fcall f_453(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1106)
static void C_ccall f_1106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1496)
static void C_fcall f_1496(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_fcall f_1523(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1541)
static void C_fcall f_1541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_fcall f_1548(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1482)
static void C_ccall f_1482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1115)
static void C_fcall f_1115(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_fcall f_1372(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1119)
static void C_ccall f_1119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1325)
static void C_fcall f_1325(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_fcall f_1276(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1289)
static void C_fcall f_1289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1211)
static void C_ccall f_1211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1252)
static void C_ccall f_1252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1244)
static void C_ccall f_1244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1219)
static void C_fcall f_1219(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_fcall f_1133(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1147)
static void C_fcall f_1147(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1154)
static void C_fcall f_1154(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1160)
static void C_fcall f_1160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1145)
static void C_ccall f_1145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1141)
static void C_ccall f_1141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_fcall f_1043(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1066)
static void C_ccall f_1066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_995)
static void C_fcall f_995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_fcall f_990(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_965)
static void C_fcall f_965(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_848)
static void C_ccall f_848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_862)
static void C_ccall f_862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_864)
static void C_fcall f_864(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_899)
static void C_fcall f_899(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_909)
static void C_fcall f_909(C_word t0,C_word t1) C_noret;
C_noret_decl(f_912)
static void C_fcall f_912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_881)
static void C_ccall f_881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_855)
static void C_ccall f_855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_706)
static void C_ccall f_706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_396)
static void C_fcall f_396(C_word t0) C_noret;
C_noret_decl(f_407)
static void C_ccall f_407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_443)
static void C_fcall trf_443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_443(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_443(t0,t1,t2);}

C_noret_decl(trf_645)
static void C_fcall trf_645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_645(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_645(t0,t1);}

C_noret_decl(trf_796)
static void C_fcall trf_796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_796(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_796(t0,t1,t2);}

C_noret_decl(trf_517)
static void C_fcall trf_517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_517(t0,t1);}

C_noret_decl(trf_498)
static void C_fcall trf_498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_498(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_498(t0,t1);}

C_noret_decl(trf_453)
static void C_fcall trf_453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_453(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_453(t0,t1);}

C_noret_decl(trf_1496)
static void C_fcall trf_1496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1496(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1496(t0,t1,t2);}

C_noret_decl(trf_1523)
static void C_fcall trf_1523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1523(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1523(t0,t1,t2);}

C_noret_decl(trf_1541)
static void C_fcall trf_1541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1541(t0,t1);}

C_noret_decl(trf_1548)
static void C_fcall trf_1548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1548(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1548(t0,t1);}

C_noret_decl(trf_1115)
static void C_fcall trf_1115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1115(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1115(t0,t1);}

C_noret_decl(trf_1372)
static void C_fcall trf_1372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1372(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1372(t0,t1,t2);}

C_noret_decl(trf_1325)
static void C_fcall trf_1325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1325(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1325(t0,t1,t2);}

C_noret_decl(trf_1276)
static void C_fcall trf_1276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1276(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1276(t0,t1,t2,t3);}

C_noret_decl(trf_1289)
static void C_fcall trf_1289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1289(t0,t1);}

C_noret_decl(trf_1219)
static void C_fcall trf_1219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1219(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1219(t0,t1,t2);}

C_noret_decl(trf_1133)
static void C_fcall trf_1133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1133(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1133(t0,t1,t2);}

C_noret_decl(trf_1147)
static void C_fcall trf_1147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1147(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1147(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1154)
static void C_fcall trf_1154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1154(t0,t1);}

C_noret_decl(trf_1160)
static void C_fcall trf_1160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1160(t0,t1);}

C_noret_decl(trf_1043)
static void C_fcall trf_1043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1043(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1043(t0,t1,t2);}

C_noret_decl(trf_995)
static void C_fcall trf_995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_995(t0,t1);}

C_noret_decl(trf_990)
static void C_fcall trf_990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_990(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_990(t0,t1,t2);}

C_noret_decl(trf_965)
static void C_fcall trf_965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_965(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_965(t0,t1,t2,t3);}

C_noret_decl(trf_864)
static void C_fcall trf_864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_864(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_864(t0,t1,t2);}

C_noret_decl(trf_899)
static void C_fcall trf_899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_899(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_899(t0,t1,t2,t3);}

C_noret_decl(trf_909)
static void C_fcall trf_909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_909(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_909(t0,t1);}

C_noret_decl(trf_912)
static void C_fcall trf_912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_912(t0,t1);}

C_noret_decl(trf_396)
static void C_fcall trf_396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_396(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_396(t0);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(356)){
C_save(t1);
C_rereclaim2(356*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,84);
lf[7]=C_h_intern(&lf[7],4,"exit");
lf[8]=C_h_intern(&lf[8],7,"display");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\001\242)\012 -no-unused                remove procedures that are never called\012 -top "
"N                    display only the top N entries\012 -help                     s"
"how this text and exit\012 -version                  show version and exit\012 -releas"
"e                  show release number and exit\012\012 FILENAME defaults to the `PROF"
"ILE.<number>\047, selecting the one with\012 the highest modification time, in case mu"
"ltiple profiles exist.\012");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\001\315Usage: chicken-profile [FILENAME | OPTION] ...\012\012 -sort-by-calls            "
"sort output by call frequency\012 -sort-by-time             sort output by procedur"
"e execution time\012 -sort-by-avg              sort output by average procedure exe"
"cution time\012 -sort-by-name             sort output alphabetically by procedure n"
"ame\012 -decimals DDD             set number of decimals for seconds, average and\012 "
"                          percent columns (three digits, default: ");
lf[13]=C_h_intern(&lf[13],19,"\003sysprint-to-string");
lf[16]=C_h_intern(&lf[16],17,"hash-table->alist");
lf[17]=C_h_intern(&lf[17],4,"read");
lf[18]=C_h_intern(&lf[18],15,"hash-table-set!");
lf[19]=C_h_intern(&lf[19],22,"hash-table-ref/default");
lf[20]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\000\376\377\016");
lf[21]=C_h_intern(&lf[21],15,"make-hash-table");
lf[22]=C_h_intern(&lf[22],3,"eq\077");
lf[24]=C_h_intern(&lf[24],13,"string-append");
lf[25]=C_h_intern(&lf[25],11,"make-string");
lf[26]=C_h_intern(&lf[26],5,"fxmax");
lf[27]=C_h_intern(&lf[27],9,"\003syserror");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[32]=C_h_intern(&lf[32],9,"substring");
lf[33]=C_h_intern(&lf[33],8,"truncate");
lf[34]=C_h_intern(&lf[34],4,"expt");
lf[35]=C_h_intern(&lf[35],25,"\003sysimplicit-exit-handler");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\011procedure");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\005calls");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\007seconds");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\007average");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\007percent");
lf[41]=C_h_intern(&lf[41],5,"print");
lf[42]=C_h_intern(&lf[42],11,"string-join");
lf[43]=C_h_intern(&lf[43],6,"reduce");
lf[44]=C_h_intern(&lf[44],1,"+");
lf[45]=C_h_intern(&lf[45],3,"max");
lf[46]=C_h_intern(&lf[46],13,"string-length");
lf[47]=C_h_intern(&lf[47],4,"fold");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\010overflow");
lf[49]=C_h_intern(&lf[49],28,"\003syssymbol->qualified-string");
lf[50]=C_h_intern(&lf[50],6,"remove");
lf[51]=C_h_intern(&lf[51],4,"take");
lf[52]=C_h_intern(&lf[52],4,"sort");
lf[53]=C_h_intern(&lf[53],6,"append");
lf[54]=C_h_intern(&lf[54],20,"with-input-from-file");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\011reading `");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\006\047 ...\012");
lf[57]=C_h_intern(&lf[57],5,"error");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\021no PROFILEs found");
lf[59]=C_h_intern(&lf[59],22,"file-modification-time");
lf[60]=C_h_intern(&lf[60],4,"glob");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\011PROFILE.*");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\032missing argument to option");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid argument to option");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\032chicken-profile - Version ");
lf[70]=C_h_intern(&lf[70],15,"chicken-version");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\012-no-unused");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\004-top");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\016-sort-by-calls");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-time");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\014-sort-by-avg");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-name");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\011-decimals");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[83]=C_h_intern(&lf[83],22,"command-line-arguments");
C_register_lf2(lf,84,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_370,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k368 */
static void C_ccall f_370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k371 in k368 */
static void C_ccall f_373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k374 in k371 in k368 */
static void C_ccall f_376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k377 in k374 in k371 in k368 */
static void C_ccall f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_388,2,t0,t1);}
t2=lf[0] /* file */ =C_SCHEME_FALSE;;
t3=lf[1] /* no-unused */ =C_SCHEME_FALSE;;
t4=lf[2] /* seconds-digits */ =C_fix(3);;
t5=lf[3] /* average-digits */ =C_fix(3);;
t6=lf[4] /* percent-digits */ =C_fix(3);;
t7=lf[5] /* top */ =C_fix(0);;
t8=C_mutate(&lf[6] /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_396,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[14] /* (set! sort-by-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_706,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[15] /* (set! read-profile ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_848,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[23] /* (set! format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_963,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[29] /* (set! format-real ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1043,tmp=(C_word)a,a+=2,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1600,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 234  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t14);}

/* k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_443,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_443(t5,((C_word*)t0)[2],t1);}

/* loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_443(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
loop:
a=C_alloc(24);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_443,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_453,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(lf[0])){
t4=t3;
f_453(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_460,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 73   glob */
((C_proc3)C_retrieve_symbol_proc(lf[60]))(3,*((C_word*)lf[60]+1),t4,lf[61]);}}
else{
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_498,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t11=t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_517,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_540,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_truep(C_i_equalp(t3,lf[64]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[65]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[66]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-profile.scm: 93   print-usage */
f_396(t12);}
else{
if(C_truep((C_truep(C_i_equalp(t3,lf[67]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[68]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_558,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_565,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 95   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),t14);}
else{
if(C_truep(C_i_string_equal_p(t3,lf[71]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_574,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_581,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 98   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),t14);}
else{
if(C_truep(C_i_string_equal_p(t3,lf[72]))){
t13=lf[1] /* no-unused */ =C_SCHEME_TRUE;;
/* chicken-profile.scm: 111  loop */
t26=t1;
t27=((C_word*)t6)[1];
t1=t26;
t2=t27;
goto loop;}
else{
if(C_truep(C_i_string_equal_p(t3,lf[73]))){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_598,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 101  next-number */
t14=t9;
f_517(t14,t13);}
else{
if(C_truep(C_i_string_equal_p(t3,lf[74]))){
/* chicken-profile.scm: 111  loop */
t26=t1;
t27=((C_word*)t6)[1];
t1=t26;
t2=t27;
goto loop;}
else{
if(C_truep(C_i_string_equal_p(t3,lf[75]))){
/* chicken-profile.scm: 111  loop */
t26=t1;
t27=((C_word*)t6)[1];
t1=t26;
t2=t27;
goto loop;}
else{
if(C_truep(C_i_string_equal_p(t3,lf[76]))){
/* chicken-profile.scm: 111  loop */
t26=t1;
t27=((C_word*)t6)[1];
t1=t26;
t2=t27;
goto loop;}
else{
if(C_truep(C_i_string_equal_p(t3,lf[77]))){
/* chicken-profile.scm: 111  loop */
t26=t1;
t27=((C_word*)t6)[1];
t1=t26;
t2=t27;
goto loop;}
else{
if(C_truep(C_i_string_equal_p(t3,lf[78]))){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_639,a[2]=t12,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 106  next-arg */
t14=((C_word*)t8)[1];
f_498(t14,t13);}
else{
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_645,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
t14=C_i_string_length(t3);
if(C_truep(C_i_greaterp(t14,C_fix(1)))){
t15=C_i_string_ref(t3,C_fix(0));
t16=t13;
f_645(t16,C_eqp(C_make_character(45),t15));}
else{
t15=t13;
f_645(t15,C_SCHEME_FALSE);}}}}}}}}}}}}}

/* k643 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_645(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* chicken-profile.scm: 108  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[57]+1)))(4,*((C_word*)lf[57]+1),((C_word*)t0)[6],lf[82],((C_word*)t0)[5]);}
else{
if(C_truep(lf[0])){
/* chicken-profile.scm: 109  print-usage */
f_396(((C_word*)t0)[6]);}
else{
t2=C_mutate(&lf[0] /* (set! file ...) */,((C_word*)t0)[5]);
/* chicken-profile.scm: 111  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_443(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}}

/* k637 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_639,2,t0,t1);}
t2=C_i_string_length(t1);
if(C_truep(C_i_nequalp(t2,C_fix(3)))){
t3=C_mutate(&lf[79] /* (set! arg-digit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_796,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 148  arg-digit */
t5=C_retrieve2(lf[79],"arg-digit");
f_796(t5,t4,C_fix(0));}
else{
/* chicken-profile.scm: 151  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[57]+1)))(4,*((C_word*)lf[57]+1),((C_word*)t0)[2],lf[81],t1);}}

/* k829 in k637 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_831,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! seconds-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 149  arg-digit */
t4=C_retrieve2(lf[79],"arg-digit");
f_796(t4,t3,C_fix(1));}

/* k833 in k829 in k637 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_835,2,t0,t1);}
t2=C_mutate(&lf[3] /* (set! average-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 150  arg-digit */
t4=C_retrieve2(lf[79],"arg-digit");
f_796(t4,t3,C_fix(2));}

/* k837 in k833 in k829 in k637 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[4] /* (set! percent-digits ...) */,t1);
/* chicken-profile.scm: 111  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_443(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* arg-digit in k637 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_796(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_796,NULL,3,t0,t1,t2);}
t3=C_i_string_ref(((C_word*)t0)[2],t2);
t4=C_fix(C_character_code(t3));
t5=C_a_i_minus(&a,2,t4,C_fix(48));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_806,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 145  <= */
C_less_or_equal_p(5,0,t6,C_fix(0),t5,C_fix(9));}

/* k804 in arg-digit in k637 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_nequalp(((C_word*)t0)[4],C_fix(9));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_fix(8):((C_word*)t0)[4]));}
else{
/* chicken-profile.scm: 147  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[57]+1)))(4,*((C_word*)lf[57]+1),((C_word*)t0)[3],lf[80],((C_word*)t0)[2]);}}

/* k596 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[5] /* (set! top ...) */,t1);
/* chicken-profile.scm: 111  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_443(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k579 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 98   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),((C_word*)t0)[2],t1);}

/* k572 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 99   exit */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),((C_word*)t0)[2]);}

/* k563 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 95   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),((C_word*)t0)[2],lf[69],t1);}

/* k556 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 96   exit */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),((C_word*)t0)[2]);}

/* k538 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 111  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_443(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* next-number in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_517,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_521,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_537,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 90   next-arg */
t4=((C_word*)((C_word*)t0)[2])[1];
f_498(t4,t3);}

/* k535 in next-number in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 90   string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k519 in next-number in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
if(C_truep(C_i_greaterp(t1,C_fix(0)))){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* chicken-profile.scm: 91   error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[57]+1)))(4,*((C_word*)lf[57]+1),((C_word*)t0)[3],lf[63],((C_word*)t0)[2]);}}
else{
/* chicken-profile.scm: 91   error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[57]+1)))(4,*((C_word*)lf[57]+1),((C_word*)t0)[3],lf[63],((C_word*)t0)[2]);}}

/* next-arg in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_498(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_498,NULL,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* chicken-profile.scm: 85   error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[57]+1)))(4,*((C_word*)lf[57]+1),t1,lf[62],((C_word*)t0)[2]);}
else{
t2=C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k458 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t1))){
/* chicken-profile.scm: 75   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[57]+1)))(3,*((C_word*)lf[57]+1),t2,lf[58]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_476,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_478,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 76   sort */
((C_proc4)C_retrieve_symbol_proc(lf[52]))(4,*((C_word*)lf[52]+1),t3,t1,t4);}}

/* a477 in k458 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_478,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_486,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 78   file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[59]))(3,*((C_word*)lf[59]+1),t4,t2);}

/* k484 in a477 in k458 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_490,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 79   file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[59]))(3,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2]);}

/* k488 in k484 in a477 in k458 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_greaterp(((C_word*)t0)[2],t1));}

/* k474 in k458 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_car(t1);
t3=C_mutate(&lf[0] /* (set! file ...) */,t2);
t4=((C_word*)t0)[2];
f_453(t4,t3);}

/* k461 in k458 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[0] /* (set! file ...) */,t1);
t3=((C_word*)t0)[2];
f_453(t3,t2);}

/* k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_453(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_453,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1103,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 184  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),t3,lf[55],lf[0],lf[56]);}

/* k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1106,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 185  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[54]))(4,*((C_word*)lf[54]+1),t2,lf[0],lf[15]);}

/* k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1109,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1579,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 186  fold */
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,t3,C_fix(0),t1);}

/* a1578 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1579,4,t0,t1,t2,t3);}
t4=C_i_caddr(t2);
/* chicken-profile.scm: 187  max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),t1,t4,t3);}

/* k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1112,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1494,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1496,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_1496(t11,t7,((C_word*)t0)[2]);}

/* loop154 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1496(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1496,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1573,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g170171 */
t6=t3;
f_1523(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1571 in loop154 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1573,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop154167 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1496(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop154167 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1496(t6,((C_word*)t0)[3],t5);}}

/* g170 in loop154 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1523(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1523,NULL,3,t0,t1,t2);}
t3=C_i_cadr(t2);
t4=C_i_caddr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1541,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=C_i_greaterp(t3,C_fix(0));
t7=t5;
f_1541(t7,(C_truep(t6)?C_a_i_divide(&a,2,t4,t3):C_SCHEME_FALSE));}
else{
t6=t5;
f_1541(t6,C_SCHEME_FALSE);}}

/* k1539 in g170 in loop154 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1541,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t4=C_a_i_divide(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t5=t3;
f_1548(t5,C_a_i_times(&a,2,t4,C_fix(100)));}
else{
t4=t3;
f_1548(t4,C_SCHEME_FALSE);}}

/* k1546 in k1539 in g170 in loop154 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1548(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1548,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)t0)[4],t2);
/* chicken-profile.scm: 191  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=C_a_i_list(&a,2,((C_word*)t0)[4],C_fix(0));
/* chicken-profile.scm: 191  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k1492 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 190  sort */
((C_proc4)C_retrieve_symbol_proc(lf[52]))(4,*((C_word*)lf[52]+1),((C_word*)t0)[2],t1,lf[14]);}

/* k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1112,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1115,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1482,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_i_length(((C_word*)t3)[1]);
/* chicken-profile.scm: 200  < */
C_lessp(5,0,t5,C_fix(0),lf[5],t6);}

/* k1480 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1482,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 201  take */
((C_proc4)C_retrieve_symbol_proc(lf[51]))(4,*((C_word*)lf[51]+1),t2,((C_word*)((C_word*)t0)[3])[1],lf[5]);}
else{
t2=((C_word*)t0)[2];
f_1115(t2,C_SCHEME_UNDEFINED);}}

/* k1484 in k1480 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1115(t3,t2);}

/* k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1115(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1115,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1370,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1462,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 212  remove */
((C_proc4)C_retrieve_symbol_proc(lf[50]))(4,*((C_word*)lf[50]+1),t7,t8,((C_word*)((C_word*)t0)[3])[1]);}

/* a1461 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1462,3,t0,t1,t2);}
if(C_truep(C_i_cadr(t2))){
t3=C_i_cadr(t2);
t4=C_i_zerop(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[1]:C_SCHEME_FALSE));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1368 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1370,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1372,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1372(t5,((C_word*)t0)[2],t1);}

/* loop196 in k1368 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1372(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1372,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_i_caddr(t3);
t6=C_i_cadddr(t3);
t7=C_i_list_ref(t3,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1419,a[2]=t4,a[3]=t5,a[4]=t6,a[5]=t7,a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[3],a[9]=t2,a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
t9=C_i_car(t3);
/* chicken-profile.scm: 207  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t8,t9);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1417 in loop196 in k1368 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken-profile.scm: 208  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1423(2,t3,lf[48]);}}

/* k1421 in k1417 in loop196 in k1368 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 209  format-real */
f_1043(t2,t3,lf[2]);}

/* k1425 in k1421 in k1417 in loop196 in k1368 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 210  format-real */
f_1043(t2,t3,lf[3]);}

/* k1429 in k1425 in k1421 in k1417 in loop196 in k1368 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* chicken-profile.scm: 211  format-real */
f_1043(t2,((C_word*)t0)[2],lf[4]);}

/* k1433 in k1429 in k1425 in k1421 in k1417 in loop196 in k1368 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
t2=C_a_i_list(&a,5,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t4=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t6=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop196209 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_1372(t7,((C_word*)t0)[3],t6);}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t6=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop196209 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_1372(t7,((C_word*)t0)[3],t6);}}

/* k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1119,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=C_a_i_list(&a,5,lf[36],lf[37],lf[38],lf[39],lf[40]);
t4=C_a_i_list(&a,5,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1128,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 220  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[25]+1)))(4,*((C_word*)lf[25]+1),t5,C_fix(2),C_make_character(32));}

/* k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1266,tmp=(C_word)a,a+=2,tmp);
t4=C_a_i_list(&a,5,C_fix(0),C_fix(0),C_fix(0),C_fix(0),C_fix(0));
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
/* chicken-profile.scm: 221  fold */
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,t3,t4,t5);}

/* a1265 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1266,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1274,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1325,a[2]=t9,a[3]=t14,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t16=((C_word*)t14)[1];
f_1325(t16,t12,t2);}

/* loop262 in a1265 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1325,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[46]+1);
t4=C_slot(t2,C_fix(0));
t5=C_i_string_length(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop262275 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop262275 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1272 in a1265 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1274,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1276,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1276(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop235 in k1272 in a1265 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1276(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1276,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[45]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g255256 */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k1307 in loop235 in k1272 in a1265 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1289,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_1289(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_1289(t5,t4);}}

/* k1287 in k1307 in loop235 in k1272 in a1265 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop235249 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1276(t5,((C_word*)t0)[2],t3,t4);}

/* k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1133,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1211,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm: 228  print-row */
t4=t2;
f_1133(t4,t3,((C_word*)t0)[2]);}

/* k1209 in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1214,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1244,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1252,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 229  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[43]))(5,*((C_word*)lf[43]+1),t4,*((C_word*)lf[44]+1),C_fix(0),((C_word*)t0)[2]);}

/* k1250 in k1209 in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1252,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[3]);
t3=C_a_i_minus(&a,2,t2,C_fix(1));
t4=C_a_i_times(&a,2,C_fix(2),t3);
t5=C_a_i_plus(&a,2,t1,t4);
/* chicken-profile.scm: 229  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[25]+1)))(4,*((C_word*)lf[25]+1),((C_word*)t0)[2],t5,C_make_character(45));}

/* k1242 in k1209 in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 229  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),((C_word*)t0)[2],t1);}

/* k1212 in k1209 in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1214,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1219,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1219(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* loop318 in k1212 in k1209 in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1219(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1219,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1229,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g325326 */
t5=((C_word*)t0)[2];
f_1133(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1227 in loop318 in k1212 in k1209 in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1219(t3,((C_word*)t0)[2],t2);}

/* print-row in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1133(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1133,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1141,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1145,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1147,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_1147(t12,t8,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop287 in print-row in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1147(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1147,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1154,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_pairp(t3);
t7=t5;
f_1154(t7,(C_truep(t6)?C_i_pairp(t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_1154(t6,C_SCHEME_FALSE);}}

/* k1152 in loop287 in print-row in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1154,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=lf[23];
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=C_slot(((C_word*)t0)[7],C_fix(0));
t5=C_slot(((C_word*)t0)[6],C_fix(0));
t6=C_slot(((C_word*)t0)[5],C_fix(0));
/* g311312 */
t7=lf[23];
f_963(5,t7,t3,t4,t5,t6);}
else{
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1182 in k1152 in loop287 in print-row in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1184,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1160,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t4=t3;
f_1160(t4,C_i_setslot(((C_word*)((C_word*)t0)[8])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_1160(t5,t4);}}

/* k1158 in k1182 in k1152 in loop287 in print-row in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=C_slot(((C_word*)t0)[6],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop287302 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1147(t6,((C_word*)t0)[2],t3,t4,t5);}

/* k1143 in print-row in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 227  string-join */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1139 in print-row in k1129 in k1126 in k1117 in k1113 in k1110 in k1107 in k1104 in k1101 in k451 in loop in k1598 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 227  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),((C_word*)t0)[2],t1);}

/* k1588 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1593,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1596,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[35]))(2,*((C_word*)lf[35]+1),t3);}

/* k1594 in k1588 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1591 in k1588 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1043(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1043,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1097,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 172  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t4,t2);}

/* k1095 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1097,2,t0,t1);}
t2=C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1054,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 174  number->string */
C_number_to_string(3,0,t3,t2);}

/* k1052 in k1095 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
t2=C_i_greaterp(((C_word*)t0)[5],C_fix(0));
t3=(C_truep(t2)?lf[30]:lf[31]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1062,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1066,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1078,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1086,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 180  - */
C_minus(5,0,t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(-1));}

/* k1084 in k1052 in k1095 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1090,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 180  expt */
((C_proc4)C_retrieve_proc(*((C_word*)lf[34]+1)))(4,*((C_word*)lf[34]+1),t2,C_fix(10),((C_word*)t0)[2]);}

/* k1088 in k1084 in k1052 in k1095 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1090,2,t0,t1);}
t2=C_a_i_times(&a,2,((C_word*)t0)[3],t1);
/* chicken-profile.scm: 179  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t2);}

/* k1076 in k1052 in k1095 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_inexact_to_exact(t1);
/* chicken-profile.scm: 177  number->string */
C_number_to_string(3,0,((C_word*)t0)[2],t2);}

/* k1064 in k1052 in k1095 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1066,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* chicken-profile.scm: 176  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[32]+1)))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],t1,C_fix(1),t2);}

/* k1060 in k1052 in k1095 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 173  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[24]+1)))(5,*((C_word*)lf[24]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* format-string in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_963r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_963r(t0,t1,t2,t3,t4);}}

static void C_ccall f_963r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_965,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_990,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_995,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-right121135 */
t8=t7;
f_995(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* def-padc122133 */
t10=t6;
f_990(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body119127 */
t12=t5;
f_965(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[28],t11);}}}}

/* def-right121 in format-string in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_995,NULL,2,t0,t1);}
/* def-padc122133 */
t2=((C_word*)t0)[2];
f_990(t2,t1,C_SCHEME_FALSE);}

/* def-padc122 in format-string in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_990(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_990,NULL,3,t0,t1,t2);}
/* body119127 */
t3=((C_word*)t0)[2];
f_965(t3,t1,t2,C_make_character(32));}

/* body119 in format-string in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_965(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_965,NULL,4,t0,t1,t2,t3);}
t4=C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_972,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_985,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_fixnum_difference(((C_word*)t0)[2],t4);
/* chicken-profile.scm: 166  fxmax */
((C_proc4)C_retrieve_proc(*((C_word*)lf[26]+1)))(4,*((C_word*)lf[26]+1),t6,C_fix(0),t7);}

/* k983 in body119 in format-string in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 166  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[25]+1)))(4,*((C_word*)lf[25]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k970 in body119 in format-string in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-profile.scm: 168  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-profile.scm: 169  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[24]+1)))(4,*((C_word*)lf[24]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

/* read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_852,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 154  make-hash-table */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t2,*((C_word*)lf[22]+1));}

/* k850 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_855,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_862,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 155  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[17]+1)))(2,*((C_word*)lf[17]+1),t3);}

/* k860 in k850 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_862,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_864,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_864(t5,((C_word*)t0)[2],t1);}

/* doloop63 in k860 in k850 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_864(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_864,NULL,3,t0,t1,t2);}
if(C_truep(C_eofp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_874,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_889,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_893,a[2]=t9,a[3]=t6,a[4]=t8,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t11=C_i_car(t2);
/* chicken-profile.scm: 160  hash-table-ref/default */
((C_proc5)C_retrieve_symbol_proc(lf[19]))(5,*((C_word*)lf[19]+1),t10,((C_word*)t0)[2],t11,lf[20]);}}

/* k891 in doloop63 in k860 in k850 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_893,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_899,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_899(t6,((C_word*)t0)[2],t1,t2);}

/* loop70 in k891 in doloop63 in k860 in k850 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_899(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_899,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_909,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
if(C_truep(t7)){
if(C_truep(t8)){
t9=C_a_i_plus(&a,2,t7,t8);
t10=t6;
f_909(t10,C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}
else{
t9=t6;
f_909(t9,C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST));}}
else{
t9=t6;
f_909(t9,C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST));}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k907 in loop70 in k891 in doloop63 in k860 in k850 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_909(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_909,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t3=t2;
f_912(t3,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t1));}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t4=t2;
f_912(t4,t3);}}

/* k910 in k907 in loop70 in k891 in doloop63 in k860 in k850 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop7084 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_899(t5,((C_word*)t0)[2],t3,t4);}

/* k887 in doloop63 in k860 in k850 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 157  hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[18]))(5,*((C_word*)lf[18]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k872 in doloop63 in k860 in k850 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 155  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[17]+1)))(2,*((C_word*)lf[17]+1),t2);}

/* k879 in k872 in doloop63 in k860 in k850 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_864(t2,((C_word*)t0)[2],t1);}

/* k853 in k850 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 162  hash-table->alist */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* sort-by-time in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_706(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_706,4,t0,t1,t2,t3);}
t4=C_i_caddr(t2);
t5=C_i_caddr(t3);
if(C_truep(C_i_nequalp(t4,t5))){
t6=C_i_cadr(t2);
t7=C_i_cadr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_greaterp(t4,t5));}}

/* print-usage in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_396(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_396,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_400,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_407,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,lf[9],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[4],t4);
t6=C_a_i_cons(&a,2,lf[10],t5);
t7=C_a_i_cons(&a,2,lf[3],t6);
t8=C_a_i_cons(&a,2,lf[11],t7);
t9=C_a_i_cons(&a,2,lf[2],t8);
t10=C_a_i_cons(&a,2,lf[12],t9);
/* chicken-profile.scm: 45   ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[13]))(3,*((C_word*)lf[13]+1),t3,t10);}

/* k405 in print-usage in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 45   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],t1);}

/* k398 in print-usage in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 65   exit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[112] = {
{"toplevel:chicken_profile_scm",(void*)C_toplevel},
{"f_370:chicken_profile_scm",(void*)f_370},
{"f_373:chicken_profile_scm",(void*)f_373},
{"f_376:chicken_profile_scm",(void*)f_376},
{"f_379:chicken_profile_scm",(void*)f_379},
{"f_382:chicken_profile_scm",(void*)f_382},
{"f_385:chicken_profile_scm",(void*)f_385},
{"f_388:chicken_profile_scm",(void*)f_388},
{"f_1600:chicken_profile_scm",(void*)f_1600},
{"f_443:chicken_profile_scm",(void*)f_443},
{"f_645:chicken_profile_scm",(void*)f_645},
{"f_639:chicken_profile_scm",(void*)f_639},
{"f_831:chicken_profile_scm",(void*)f_831},
{"f_835:chicken_profile_scm",(void*)f_835},
{"f_839:chicken_profile_scm",(void*)f_839},
{"f_796:chicken_profile_scm",(void*)f_796},
{"f_806:chicken_profile_scm",(void*)f_806},
{"f_598:chicken_profile_scm",(void*)f_598},
{"f_581:chicken_profile_scm",(void*)f_581},
{"f_574:chicken_profile_scm",(void*)f_574},
{"f_565:chicken_profile_scm",(void*)f_565},
{"f_558:chicken_profile_scm",(void*)f_558},
{"f_540:chicken_profile_scm",(void*)f_540},
{"f_517:chicken_profile_scm",(void*)f_517},
{"f_537:chicken_profile_scm",(void*)f_537},
{"f_521:chicken_profile_scm",(void*)f_521},
{"f_498:chicken_profile_scm",(void*)f_498},
{"f_460:chicken_profile_scm",(void*)f_460},
{"f_478:chicken_profile_scm",(void*)f_478},
{"f_486:chicken_profile_scm",(void*)f_486},
{"f_490:chicken_profile_scm",(void*)f_490},
{"f_476:chicken_profile_scm",(void*)f_476},
{"f_463:chicken_profile_scm",(void*)f_463},
{"f_453:chicken_profile_scm",(void*)f_453},
{"f_1103:chicken_profile_scm",(void*)f_1103},
{"f_1106:chicken_profile_scm",(void*)f_1106},
{"f_1579:chicken_profile_scm",(void*)f_1579},
{"f_1109:chicken_profile_scm",(void*)f_1109},
{"f_1496:chicken_profile_scm",(void*)f_1496},
{"f_1573:chicken_profile_scm",(void*)f_1573},
{"f_1523:chicken_profile_scm",(void*)f_1523},
{"f_1541:chicken_profile_scm",(void*)f_1541},
{"f_1548:chicken_profile_scm",(void*)f_1548},
{"f_1494:chicken_profile_scm",(void*)f_1494},
{"f_1112:chicken_profile_scm",(void*)f_1112},
{"f_1482:chicken_profile_scm",(void*)f_1482},
{"f_1486:chicken_profile_scm",(void*)f_1486},
{"f_1115:chicken_profile_scm",(void*)f_1115},
{"f_1462:chicken_profile_scm",(void*)f_1462},
{"f_1370:chicken_profile_scm",(void*)f_1370},
{"f_1372:chicken_profile_scm",(void*)f_1372},
{"f_1419:chicken_profile_scm",(void*)f_1419},
{"f_1423:chicken_profile_scm",(void*)f_1423},
{"f_1427:chicken_profile_scm",(void*)f_1427},
{"f_1431:chicken_profile_scm",(void*)f_1431},
{"f_1435:chicken_profile_scm",(void*)f_1435},
{"f_1119:chicken_profile_scm",(void*)f_1119},
{"f_1128:chicken_profile_scm",(void*)f_1128},
{"f_1266:chicken_profile_scm",(void*)f_1266},
{"f_1325:chicken_profile_scm",(void*)f_1325},
{"f_1274:chicken_profile_scm",(void*)f_1274},
{"f_1276:chicken_profile_scm",(void*)f_1276},
{"f_1309:chicken_profile_scm",(void*)f_1309},
{"f_1289:chicken_profile_scm",(void*)f_1289},
{"f_1131:chicken_profile_scm",(void*)f_1131},
{"f_1211:chicken_profile_scm",(void*)f_1211},
{"f_1252:chicken_profile_scm",(void*)f_1252},
{"f_1244:chicken_profile_scm",(void*)f_1244},
{"f_1214:chicken_profile_scm",(void*)f_1214},
{"f_1219:chicken_profile_scm",(void*)f_1219},
{"f_1229:chicken_profile_scm",(void*)f_1229},
{"f_1133:chicken_profile_scm",(void*)f_1133},
{"f_1147:chicken_profile_scm",(void*)f_1147},
{"f_1154:chicken_profile_scm",(void*)f_1154},
{"f_1184:chicken_profile_scm",(void*)f_1184},
{"f_1160:chicken_profile_scm",(void*)f_1160},
{"f_1145:chicken_profile_scm",(void*)f_1145},
{"f_1141:chicken_profile_scm",(void*)f_1141},
{"f_1590:chicken_profile_scm",(void*)f_1590},
{"f_1596:chicken_profile_scm",(void*)f_1596},
{"f_1593:chicken_profile_scm",(void*)f_1593},
{"f_1043:chicken_profile_scm",(void*)f_1043},
{"f_1097:chicken_profile_scm",(void*)f_1097},
{"f_1054:chicken_profile_scm",(void*)f_1054},
{"f_1086:chicken_profile_scm",(void*)f_1086},
{"f_1090:chicken_profile_scm",(void*)f_1090},
{"f_1078:chicken_profile_scm",(void*)f_1078},
{"f_1066:chicken_profile_scm",(void*)f_1066},
{"f_1062:chicken_profile_scm",(void*)f_1062},
{"f_963:chicken_profile_scm",(void*)f_963},
{"f_995:chicken_profile_scm",(void*)f_995},
{"f_990:chicken_profile_scm",(void*)f_990},
{"f_965:chicken_profile_scm",(void*)f_965},
{"f_985:chicken_profile_scm",(void*)f_985},
{"f_972:chicken_profile_scm",(void*)f_972},
{"f_848:chicken_profile_scm",(void*)f_848},
{"f_852:chicken_profile_scm",(void*)f_852},
{"f_862:chicken_profile_scm",(void*)f_862},
{"f_864:chicken_profile_scm",(void*)f_864},
{"f_893:chicken_profile_scm",(void*)f_893},
{"f_899:chicken_profile_scm",(void*)f_899},
{"f_909:chicken_profile_scm",(void*)f_909},
{"f_912:chicken_profile_scm",(void*)f_912},
{"f_889:chicken_profile_scm",(void*)f_889},
{"f_874:chicken_profile_scm",(void*)f_874},
{"f_881:chicken_profile_scm",(void*)f_881},
{"f_855:chicken_profile_scm",(void*)f_855},
{"f_706:chicken_profile_scm",(void*)f_706},
{"f_396:chicken_profile_scm",(void*)f_396},
{"f_407:chicken_profile_scm",(void*)f_407},
{"f_400:chicken_profile_scm",(void*)f_400},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
