/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: posixwin.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file uposixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>
#include <utime.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_test_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

/* It is assumed that 'int' is-a 'long' */
#define C_ftell(p)          C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_num_to_int(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set(v) (C_tm_set_08(v), &C_tm)

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_a_mktime(ptr, c, v)  C_flonum(ptr, mktime(C_tm_set(v)))

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static int set_file_mtime(char *filename, C_word tm)
{
  struct _utimbuf tb;

  tb.actime = tb.modtime = C_num_to_int(tm);
  return _utime(filename, &tb);
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[394];
static double C_possibly_force_alignment;


/* from k4735 */
static C_word C_fcall stub1006(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub1006(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from current-process-id in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static C_word C_fcall stub981(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub981(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k4377 */
static C_word C_fcall stub855(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub855(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k4371 */
static C_word C_fcall stub845(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub845(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from ex0 */
static C_word C_fcall stub742(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub742(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub737(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub737(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (_daylight ? _tzname[1] : _tzname[0]);
return(z);
C_ret:
#undef return

return C_r;}

/* from strftime */
static C_word C_fcall stub707(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub707(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub701(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub701(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub681(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub681(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from get */
static C_word C_fcall stub634(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub634(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k5781 in k5800 in a5769 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static C_word C_fcall stub123(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub123(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_fix((C_word)set_file_mtime(t0,t1));
return C_r;}

/* from strerror */
static C_word C_fcall stub12(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub12(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_fcall f_5789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5764)
static void C_ccall f_5764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5768)
static void C_ccall f_5768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5727)
static void C_ccall f_5727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5731)
static void C_ccall f_5731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5680)
static void C_ccall f_5680(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5674)
static void C_ccall f_5674(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5650)
static void C_ccall f_5650(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5644)
static void C_ccall f_5644(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5482)
static void C_ccall f_5482(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5446)
static void C_ccall f_5446(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5380)
static void C_fcall f_5380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5375)
static void C_fcall f_5375(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5370)
static void C_fcall f_5370(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5205)
static void C_fcall f_5205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5365)
static void C_ccall f_5365(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5212)
static void C_fcall f_5212(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5339)
static void C_ccall f_5339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5224)
static void C_fcall f_5224(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5325)
static void C_ccall f_5325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5145)
static void C_ccall f_5145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5142)
static void C_ccall f_5142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5085)
static void C_ccall f_5085(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5085)
static void C_ccall f_5085r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5013)
static void C_fcall f_5013(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_fcall f_5008(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5003)
static void C_fcall f_5003(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4998)
static void C_fcall f_4998(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4936)
static void C_fcall f_4936(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_fcall f_4931(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4926)
static void C_fcall f_4926(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4921)
static void C_fcall f_4921(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4857)
static void C_fcall f_4857(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4878)
static void C_ccall f_4878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_fcall f_4859(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4759)
static void C_ccall f_4759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_4759)
static void C_ccall f_4759r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_ccall f_4806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4673)
static void C_ccall f_4673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4589)
static void C_fcall f_4589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_fcall f_4584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4579)
static void C_fcall f_4579(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4567)
static void C_fcall f_4567(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4505)
static void C_fcall f_4505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_fcall f_4500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4495)
static void C_fcall f_4495(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4483)
static void C_fcall f_4483(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4466)
static void C_fcall f_4466(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_fcall f_4430(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4453)
static void C_ccall f_4453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_fcall f_4380(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4392)
static void C_fcall f_4392(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4374)
static void C_ccall f_4374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4289)
static void C_fcall f_4289(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4332)
static void C_fcall f_4332(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_fcall f_4294(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_fcall f_4303(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4178)
static void C_fcall f_4178(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_fcall f_4215(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4236)
static void C_fcall f_4236(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4123)
static void C_ccall f_4123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_fcall f_4132(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4107)
static void C_ccall f_4107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_fcall f_3879(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3819)
static void C_fcall f_3819(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3831)
static void C_fcall f_3831(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3758)
static void C_fcall f_3758(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3716)
static void C_ccall f_3716(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_fcall f_3670(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_fcall f_3633(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3588)
static void C_fcall f_3588(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3366)
static void C_ccall f_3366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3342)
static void C_ccall f_3342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_fcall f_3214(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_fcall f_2985(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_fcall f_3015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_fcall f_3057(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_fcall f_2855(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_ccall f_2868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_fcall f_2783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2647)
static void C_fcall f_2647(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_fcall f_2642(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2541)
static void C_fcall f_2541(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_fcall f_2575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_fcall f_2597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2607)
static void C_ccall f_2607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2369)
static void C_fcall f_2369(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_fcall f_2377(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_fcall f_2411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f6406)
static void C_ccall f6406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f6412)
static void C_ccall f6412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f6418)
static void C_ccall f6418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f6424)
static void C_ccall f6424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_fcall f_2129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_5789)
static void C_fcall trf_5789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5789(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5789(t0,t1);}

C_noret_decl(trf_5380)
static void C_fcall trf_5380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5380(t0,t1);}

C_noret_decl(trf_5375)
static void C_fcall trf_5375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5375(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5375(t0,t1,t2);}

C_noret_decl(trf_5370)
static void C_fcall trf_5370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5370(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5370(t0,t1,t2,t3);}

C_noret_decl(trf_5205)
static void C_fcall trf_5205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5205(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5205(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5212)
static void C_fcall trf_5212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5212(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5212(t0,t1);}

C_noret_decl(trf_5224)
static void C_fcall trf_5224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5224(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5224(t0,t1,t2,t3);}

C_noret_decl(trf_5013)
static void C_fcall trf_5013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5013(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5013(t0,t1);}

C_noret_decl(trf_5008)
static void C_fcall trf_5008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5008(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5008(t0,t1,t2);}

C_noret_decl(trf_5003)
static void C_fcall trf_5003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5003(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5003(t0,t1,t2,t3);}

C_noret_decl(trf_4998)
static void C_fcall trf_4998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4998(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4998(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4936)
static void C_fcall trf_4936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4936(t0,t1);}

C_noret_decl(trf_4931)
static void C_fcall trf_4931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4931(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4931(t0,t1,t2);}

C_noret_decl(trf_4926)
static void C_fcall trf_4926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4926(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4926(t0,t1,t2,t3);}

C_noret_decl(trf_4921)
static void C_fcall trf_4921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4921(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4921(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4857)
static void C_fcall trf_4857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4857(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4857(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4859)
static void C_fcall trf_4859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4859(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4859(t0,t1,t2);}

C_noret_decl(trf_4589)
static void C_fcall trf_4589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4589(t0,t1);}

C_noret_decl(trf_4584)
static void C_fcall trf_4584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4584(t0,t1,t2);}

C_noret_decl(trf_4579)
static void C_fcall trf_4579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4579(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4579(t0,t1,t2,t3);}

C_noret_decl(trf_4567)
static void C_fcall trf_4567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4567(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4567(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4505)
static void C_fcall trf_4505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4505(t0,t1);}

C_noret_decl(trf_4500)
static void C_fcall trf_4500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4500(t0,t1,t2);}

C_noret_decl(trf_4495)
static void C_fcall trf_4495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4495(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4495(t0,t1,t2,t3);}

C_noret_decl(trf_4483)
static void C_fcall trf_4483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4483(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4483(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4466)
static void C_fcall trf_4466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4466(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4466(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4430)
static void C_fcall trf_4430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4430(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4430(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4380)
static void C_fcall trf_4380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4380(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4380(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4392)
static void C_fcall trf_4392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4392(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4392(t0,t1,t2,t3);}

C_noret_decl(trf_4289)
static void C_fcall trf_4289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4289(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4289(t0,t1,t2,t3);}

C_noret_decl(trf_4332)
static void C_fcall trf_4332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4332(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4332(t0,t1,t2,t3);}

C_noret_decl(trf_4294)
static void C_fcall trf_4294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4294(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4294(t0,t1,t2);}

C_noret_decl(trf_4303)
static void C_fcall trf_4303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4303(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4303(t0,t1,t2);}

C_noret_decl(trf_4178)
static void C_fcall trf_4178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4178(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4178(t0,t1,t2);}

C_noret_decl(trf_4215)
static void C_fcall trf_4215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4215(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4215(t0,t1,t2);}

C_noret_decl(trf_4236)
static void C_fcall trf_4236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4236(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4236(t0,t1,t2);}

C_noret_decl(trf_4132)
static void C_fcall trf_4132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4132(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4132(t0,t1);}

C_noret_decl(trf_3879)
static void C_fcall trf_3879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3879(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3879(t0,t1,t2);}

C_noret_decl(trf_3819)
static void C_fcall trf_3819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3819(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3819(t0,t1,t2);}

C_noret_decl(trf_3831)
static void C_fcall trf_3831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3831(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3831(t0,t1,t2);}

C_noret_decl(trf_3758)
static void C_fcall trf_3758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3758(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3758(t0,t1);}

C_noret_decl(trf_3670)
static void C_fcall trf_3670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3670(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3670(t0,t1,t2,t3);}

C_noret_decl(trf_3633)
static void C_fcall trf_3633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3633(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3633(t0,t1,t2);}

C_noret_decl(trf_3588)
static void C_fcall trf_3588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3588(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3588(t0,t1,t2,t3);}

C_noret_decl(trf_3214)
static void C_fcall trf_3214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3214(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3214(t0,t1,t2,t3);}

C_noret_decl(trf_2985)
static void C_fcall trf_2985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2985(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2985(t0,t1);}

C_noret_decl(trf_3015)
static void C_fcall trf_3015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3015(t0,t1);}

C_noret_decl(trf_3057)
static void C_fcall trf_3057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3057(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3057(t0,t1);}

C_noret_decl(trf_2855)
static void C_fcall trf_2855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2855(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2855(t0,t1,t2,t3);}

C_noret_decl(trf_2783)
static void C_fcall trf_2783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2783(t0,t1);}

C_noret_decl(trf_2647)
static void C_fcall trf_2647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2647(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2647(t0,t1);}

C_noret_decl(trf_2642)
static void C_fcall trf_2642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2642(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2642(t0,t1,t2);}

C_noret_decl(trf_2541)
static void C_fcall trf_2541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2541(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2541(t0,t1,t2,t3);}

C_noret_decl(trf_2575)
static void C_fcall trf_2575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2575(t0,t1);}

C_noret_decl(trf_2597)
static void C_fcall trf_2597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2597(t0,t1);}

C_noret_decl(trf_2369)
static void C_fcall trf_2369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2369(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2369(t0,t1,t2);}

C_noret_decl(trf_2377)
static void C_fcall trf_2377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2377(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2377(t0,t1,t2);}

C_noret_decl(trf_2411)
static void C_fcall trf_2411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2411(t0,t1);}

C_noret_decl(trf_2129)
static void C_fcall trf_2129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2129(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr9rv)
static void C_fcall tr9rv(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9rv(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n+1);
t9=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3084)){
C_save(t1);
C_rereclaim2(3084*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,394);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000/this function is not available on this platform");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],8,"pipe/buf");
lf[10]=C_h_intern(&lf[10],11,"open/rdonly");
lf[11]=C_h_intern(&lf[11],11,"open/wronly");
lf[12]=C_h_intern(&lf[12],9,"open/rdwr");
lf[13]=C_h_intern(&lf[13],9,"open/read");
lf[14]=C_h_intern(&lf[14],10,"open/write");
lf[15]=C_h_intern(&lf[15],10,"open/creat");
lf[16]=C_h_intern(&lf[16],11,"open/append");
lf[17]=C_h_intern(&lf[17],9,"open/excl");
lf[18]=C_h_intern(&lf[18],10,"open/trunc");
lf[19]=C_h_intern(&lf[19],11,"open/binary");
lf[20]=C_h_intern(&lf[20],9,"open/text");
lf[21]=C_h_intern(&lf[21],14,"open/noinherit");
lf[22]=C_h_intern(&lf[22],10,"perm/irusr");
lf[23]=C_h_intern(&lf[23],10,"perm/iwusr");
lf[24]=C_h_intern(&lf[24],10,"perm/ixusr");
lf[25]=C_h_intern(&lf[25],10,"perm/irgrp");
lf[26]=C_h_intern(&lf[26],10,"perm/iwgrp");
lf[27]=C_h_intern(&lf[27],10,"perm/ixgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iroth");
lf[29]=C_h_intern(&lf[29],10,"perm/iwoth");
lf[30]=C_h_intern(&lf[30],10,"perm/ixoth");
lf[31]=C_h_intern(&lf[31],10,"perm/irwxu");
lf[32]=C_h_intern(&lf[32],10,"perm/irwxg");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxo");
lf[34]=C_h_intern(&lf[34],9,"file-open");
lf[35]=C_h_intern(&lf[35],11,"\000file-error");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[37]=C_h_intern(&lf[37],17,"\003sysmake-c-string");
lf[38]=C_h_intern(&lf[38],20,"\003sysexpand-home-path");
lf[39]=C_h_intern(&lf[39],10,"file-close");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[41]=C_h_intern(&lf[41],11,"make-string");
lf[42]=C_h_intern(&lf[42],9,"file-read");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[44]=C_h_intern(&lf[44],11,"\000type-error");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[46]=C_h_intern(&lf[46],10,"file-write");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[49]=C_h_intern(&lf[49],13,"string-length");
lf[50]=C_h_intern(&lf[50],12,"file-mkstemp");
lf[51]=C_h_intern(&lf[51],13,"\003syssubstring");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[53]=C_h_intern(&lf[53],8,"seek/set");
lf[54]=C_h_intern(&lf[54],8,"seek/end");
lf[55]=C_h_intern(&lf[55],8,"seek/cur");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[59]=C_h_intern(&lf[59],9,"file-stat");
lf[60]=C_h_intern(&lf[60],9,"file-size");
lf[61]=C_h_intern(&lf[61],22,"file-modification-time");
lf[62]=C_h_intern(&lf[62],16,"file-access-time");
lf[63]=C_h_intern(&lf[63],16,"file-change-time");
lf[64]=C_h_intern(&lf[64],10,"file-owner");
lf[65]=C_h_intern(&lf[65],16,"file-permissions");
lf[66]=C_h_intern(&lf[66],13,"regular-file\077");
lf[67]=C_h_intern(&lf[67],13,"\003sysfile-info");
lf[68]=C_h_intern(&lf[68],14,"symbolic-link\077");
lf[69]=C_h_intern(&lf[69],17,"character-device\077");
lf[70]=C_h_intern(&lf[70],13,"block-device\077");
lf[71]=C_h_intern(&lf[71],5,"fifo\077");
lf[72]=C_h_intern(&lf[72],7,"socket\077");
lf[73]=C_h_intern(&lf[73],18,"set-file-position!");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[75]=C_h_intern(&lf[75],6,"stream");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[77]=C_h_intern(&lf[77],5,"port\077");
lf[78]=C_h_intern(&lf[78],13,"\000bounds-error");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[80]=C_h_intern(&lf[80],13,"file-position");
lf[81]=C_h_intern(&lf[81],16,"create-directory");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[83]=C_h_intern(&lf[83],12,"file-exists\077");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[85]=C_h_intern(&lf[85],12,"string-split");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[87]=C_h_intern(&lf[87],16,"change-directory");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[89]=C_h_intern(&lf[89],16,"delete-directory");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[91]=C_h_intern(&lf[91],6,"string");
lf[92]=C_h_intern(&lf[92],9,"directory");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[94]=C_h_intern(&lf[94],16,"\003sysmake-pointer");
lf[95]=C_h_intern(&lf[95],17,"current-directory");
lf[96]=C_h_intern(&lf[96],10,"directory\077");
lf[97]=C_h_intern(&lf[97],27,"\003sysplatform-fixup-pathname");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[99]=C_h_intern(&lf[99],5,"null\077");
lf[100]=C_h_intern(&lf[100],6,"char=\077");
lf[101]=C_h_intern(&lf[101],8,"string=\077");
lf[102]=C_h_intern(&lf[102],16,"char-alphabetic\077");
lf[103]=C_h_intern(&lf[103],10,"string-ref");
lf[104]=C_h_intern(&lf[104],17,"current-user-name");
lf[105]=C_h_intern(&lf[105],9,"condition");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\003c:\134");
lf[107]=C_h_intern(&lf[107],22,"with-exception-handler");
lf[108]=C_h_intern(&lf[108],30,"call-with-current-continuation");
lf[109]=C_h_intern(&lf[109],14,"canonical-path");
lf[110]=C_h_intern(&lf[110],18,"string-intersperse");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[113]=C_h_intern(&lf[113],7,"reverse");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\027Documents and Settings\134");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[124]=C_h_intern(&lf[124],13,"\003sysmake-port");
lf[125]=C_h_intern(&lf[125],21,"\003sysstream-port-class");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[127]=C_h_intern(&lf[127],15,"open-input-pipe");
lf[128]=C_h_intern(&lf[128],5,"\000text");
lf[129]=C_h_intern(&lf[129],7,"\000binary");
lf[130]=C_h_intern(&lf[130],9,"\003syserror");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[132]=C_h_intern(&lf[132],16,"open-output-pipe");
lf[133]=C_h_intern(&lf[133],16,"close-input-pipe");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[135]=C_h_intern(&lf[135],14,"\003syscheck-port");
lf[136]=C_h_intern(&lf[136],17,"close-output-pipe");
lf[137]=C_h_intern(&lf[137],20,"call-with-input-pipe");
lf[138]=C_h_intern(&lf[138],21,"call-with-output-pipe");
lf[139]=C_h_intern(&lf[139],20,"with-input-from-pipe");
lf[140]=C_h_intern(&lf[140],18,"\003sysstandard-input");
lf[141]=C_h_intern(&lf[141],19,"with-output-to-pipe");
lf[142]=C_h_intern(&lf[142],19,"\003sysstandard-output");
lf[143]=C_h_intern(&lf[143],11,"create-pipe");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[145]=C_h_intern(&lf[145],11,"signal/term");
lf[146]=C_h_intern(&lf[146],10,"signal/int");
lf[147]=C_h_intern(&lf[147],10,"signal/fpe");
lf[148]=C_h_intern(&lf[148],10,"signal/ill");
lf[149]=C_h_intern(&lf[149],11,"signal/segv");
lf[150]=C_h_intern(&lf[150],11,"signal/abrt");
lf[151]=C_h_intern(&lf[151],12,"signal/break");
lf[152]=C_h_intern(&lf[152],11,"signal/alrm");
lf[153]=C_h_intern(&lf[153],11,"signal/chld");
lf[154]=C_h_intern(&lf[154],11,"signal/cont");
lf[155]=C_h_intern(&lf[155],10,"signal/hup");
lf[156]=C_h_intern(&lf[156],9,"signal/io");
lf[157]=C_h_intern(&lf[157],11,"signal/kill");
lf[158]=C_h_intern(&lf[158],11,"signal/pipe");
lf[159]=C_h_intern(&lf[159],11,"signal/prof");
lf[160]=C_h_intern(&lf[160],11,"signal/quit");
lf[161]=C_h_intern(&lf[161],11,"signal/stop");
lf[162]=C_h_intern(&lf[162],11,"signal/trap");
lf[163]=C_h_intern(&lf[163],11,"signal/tstp");
lf[164]=C_h_intern(&lf[164],10,"signal/urg");
lf[165]=C_h_intern(&lf[165],11,"signal/usr1");
lf[166]=C_h_intern(&lf[166],11,"signal/usr2");
lf[167]=C_h_intern(&lf[167],13,"signal/vtalrm");
lf[168]=C_h_intern(&lf[168],12,"signal/winch");
lf[169]=C_h_intern(&lf[169],11,"signal/xcpu");
lf[170]=C_h_intern(&lf[170],11,"signal/xfsz");
lf[171]=C_h_intern(&lf[171],12,"signals-list");
lf[172]=C_h_intern(&lf[172],18,"\003sysinterrupt-hook");
lf[173]=C_h_intern(&lf[173],14,"signal-handler");
lf[174]=C_h_intern(&lf[174],19,"set-signal-handler!");
lf[175]=C_h_intern(&lf[175],10,"errno/perm");
lf[176]=C_h_intern(&lf[176],11,"errno/noent");
lf[177]=C_h_intern(&lf[177],10,"errno/srch");
lf[178]=C_h_intern(&lf[178],10,"errno/intr");
lf[179]=C_h_intern(&lf[179],8,"errno/io");
lf[180]=C_h_intern(&lf[180],12,"errno/noexec");
lf[181]=C_h_intern(&lf[181],10,"errno/badf");
lf[182]=C_h_intern(&lf[182],11,"errno/child");
lf[183]=C_h_intern(&lf[183],11,"errno/nomem");
lf[184]=C_h_intern(&lf[184],11,"errno/acces");
lf[185]=C_h_intern(&lf[185],11,"errno/fault");
lf[186]=C_h_intern(&lf[186],10,"errno/busy");
lf[187]=C_h_intern(&lf[187],11,"errno/exist");
lf[188]=C_h_intern(&lf[188],12,"errno/notdir");
lf[189]=C_h_intern(&lf[189],11,"errno/isdir");
lf[190]=C_h_intern(&lf[190],11,"errno/inval");
lf[191]=C_h_intern(&lf[191],11,"errno/mfile");
lf[192]=C_h_intern(&lf[192],11,"errno/nospc");
lf[193]=C_h_intern(&lf[193],11,"errno/spipe");
lf[194]=C_h_intern(&lf[194],10,"errno/pipe");
lf[195]=C_h_intern(&lf[195],11,"errno/again");
lf[196]=C_h_intern(&lf[196],10,"errno/rofs");
lf[197]=C_h_intern(&lf[197],10,"errno/nxio");
lf[198]=C_h_intern(&lf[198],10,"errno/2big");
lf[199]=C_h_intern(&lf[199],10,"errno/xdev");
lf[200]=C_h_intern(&lf[200],11,"errno/nodev");
lf[201]=C_h_intern(&lf[201],11,"errno/nfile");
lf[202]=C_h_intern(&lf[202],11,"errno/notty");
lf[203]=C_h_intern(&lf[203],10,"errno/fbig");
lf[204]=C_h_intern(&lf[204],11,"errno/mlink");
lf[205]=C_h_intern(&lf[205],9,"errno/dom");
lf[206]=C_h_intern(&lf[206],11,"errno/range");
lf[207]=C_h_intern(&lf[207],12,"errno/deadlk");
lf[208]=C_h_intern(&lf[208],17,"errno/nametoolong");
lf[209]=C_h_intern(&lf[209],11,"errno/nolck");
lf[210]=C_h_intern(&lf[210],11,"errno/nosys");
lf[211]=C_h_intern(&lf[211],14,"errno/notempty");
lf[212]=C_h_intern(&lf[212],11,"errno/ilseq");
lf[213]=C_h_intern(&lf[213],16,"change-file-mode");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[215]=C_h_intern(&lf[215],17,"file-read-access\077");
lf[216]=C_h_intern(&lf[216],18,"file-write-access\077");
lf[217]=C_h_intern(&lf[217],20,"file-execute-access\077");
lf[218]=C_h_intern(&lf[218],12,"fileno/stdin");
lf[219]=C_h_intern(&lf[219],13,"fileno/stdout");
lf[220]=C_h_intern(&lf[220],13,"fileno/stderr");
lf[221]=C_h_intern(&lf[221],7,"\000append");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[229]=C_h_intern(&lf[229],16,"open-input-file*");
lf[230]=C_h_intern(&lf[230],17,"open-output-file*");
lf[231]=C_h_intern(&lf[231],12,"port->fileno");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[234]=C_h_intern(&lf[234],25,"\003syspeek-unsigned-integer");
lf[235]=C_h_intern(&lf[235],16,"duplicate-fileno");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[237]=C_h_intern(&lf[237],6,"setenv");
lf[238]=C_h_intern(&lf[238],8,"unsetenv");
lf[239]=C_h_intern(&lf[239],9,"substring");
lf[240]=C_h_intern(&lf[240],25,"get-environment-variables");
lf[241]=C_h_intern(&lf[241],19,"current-environment");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[244]=C_h_intern(&lf[244],19,"seconds->local-time");
lf[245]=C_h_intern(&lf[245],18,"\003sysdecode-seconds");
lf[246]=C_h_intern(&lf[246],15,"current-seconds");
lf[247]=C_h_intern(&lf[247],17,"seconds->utc-time");
lf[248]=C_h_intern(&lf[248],15,"seconds->string");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[250]=C_h_intern(&lf[250],12,"time->string");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[253]=C_h_intern(&lf[253],19,"local-time->seconds");
lf[254]=C_decode_literal(C_heaptop,"\376U-1.0\000");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[256]=C_h_intern(&lf[256],27,"local-timezone-abbreviation");
lf[257]=C_h_intern(&lf[257],5,"_exit");
lf[258]=C_h_intern(&lf[258],14,"terminal-port\077");
lf[259]=C_h_intern(&lf[259],19,"set-buffering-mode!");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[261]=C_h_intern(&lf[261],5,"\000full");
lf[262]=C_h_intern(&lf[262],5,"\000line");
lf[263]=C_h_intern(&lf[263],5,"\000none");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[265]=C_h_intern(&lf[265],6,"regexp");
lf[266]=C_h_intern(&lf[266],12,"string-match");
lf[267]=C_h_intern(&lf[267],12,"glob->regexp");
lf[268]=C_h_intern(&lf[268],13,"make-pathname");
lf[269]=C_h_intern(&lf[269],18,"decompose-pathname");
lf[270]=C_h_intern(&lf[270],4,"glob");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[273]=C_h_intern(&lf[273],13,"spawn/overlay");
lf[274]=C_h_intern(&lf[274],10,"spawn/wait");
lf[275]=C_h_intern(&lf[275],12,"spawn/nowait");
lf[276]=C_h_intern(&lf[276],13,"spawn/nowaito");
lf[277]=C_h_intern(&lf[277],12,"spawn/detach");
lf[278]=C_h_intern(&lf[278],16,"char-whitespace\077");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[282]=C_h_intern(&lf[282],24,"pathname-strip-directory");
lf[285]=C_h_intern(&lf[285],15,"process-execute");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[287]=C_h_intern(&lf[287],13,"process-spawn");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[289]=C_h_intern(&lf[289],18,"current-process-id");
lf[290]=C_h_intern(&lf[290],17,"\003sysshell-command");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[292]=C_h_intern(&lf[292],24,"get-environment-variable");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[294]=C_h_intern(&lf[294],27,"\003sysshell-command-arguments");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[296]=C_h_intern(&lf[296],11,"process-run");
lf[297]=C_h_intern(&lf[297],11,"\003sysprocess");
lf[298]=C_h_intern(&lf[298],14,"\000process-error");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[300]=C_h_intern(&lf[300],17,"\003sysmake-locative");
lf[301]=C_h_intern(&lf[301],8,"location");
lf[302]=C_h_intern(&lf[302],7,"process");
lf[303]=C_h_intern(&lf[303],8,"process*");
lf[304]=C_h_intern(&lf[304],16,"\003syscheck-string");
lf[305]=C_h_intern(&lf[305],12,"\003sysfor-each");
lf[306]=C_h_intern(&lf[306],16,"\003sysprocess-wait");
lf[307]=C_h_intern(&lf[307],12,"process-wait");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[309]=C_h_intern(&lf[309],5,"sleep");
lf[310]=C_h_intern(&lf[310],13,"get-host-name");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[312]=C_h_intern(&lf[312],18,"system-information");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[316]=C_h_intern(&lf[316],13,"pathname-file");
lf[317]=C_h_intern(&lf[317],10,"find-files");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[321]=C_h_intern(&lf[321],16,"\003sysdynamic-wind");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[323]=C_h_intern(&lf[323],7,"regexp\077");
lf[324]=C_h_intern(&lf[324],17,"change-file-owner");
lf[325]=C_h_intern(&lf[325],5,"error");
lf[326]=C_h_intern(&lf[326],11,"create-fifo");
lf[327]=C_h_intern(&lf[327],14,"create-session");
lf[328]=C_h_intern(&lf[328],20,"create-symbolic-link");
lf[329]=C_h_intern(&lf[329],26,"current-effective-group-id");
lf[330]=C_h_intern(&lf[330],25,"current-effective-user-id");
lf[331]=C_h_intern(&lf[331],27,"current-effective-user-name");
lf[332]=C_h_intern(&lf[332],16,"current-group-id");
lf[333]=C_h_intern(&lf[333],15,"current-user-id");
lf[334]=C_h_intern(&lf[334],18,"map-file-to-memory");
lf[335]=C_h_intern(&lf[335],9,"file-link");
lf[336]=C_h_intern(&lf[336],9,"file-lock");
lf[337]=C_h_intern(&lf[337],18,"file-lock/blocking");
lf[338]=C_h_intern(&lf[338],11,"file-select");
lf[339]=C_h_intern(&lf[339],14,"file-test-lock");
lf[340]=C_h_intern(&lf[340],13,"file-truncate");
lf[341]=C_h_intern(&lf[341],11,"file-unlock");
lf[342]=C_h_intern(&lf[342],10,"get-groups");
lf[343]=C_h_intern(&lf[343],17,"group-information");
lf[344]=C_h_intern(&lf[344],17,"initialize-groups");
lf[345]=C_h_intern(&lf[345],26,"memory-mapped-file-pointer");
lf[346]=C_h_intern(&lf[346],17,"parent-process-id");
lf[347]=C_h_intern(&lf[347],12,"process-fork");
lf[348]=C_h_intern(&lf[348],16,"process-group-id");
lf[349]=C_h_intern(&lf[349],14,"process-signal");
lf[350]=C_h_intern(&lf[350],18,"read-symbolic-link");
lf[351]=C_h_intern(&lf[351],10,"set-alarm!");
lf[352]=C_h_intern(&lf[352],13,"set-group-id!");
lf[353]=C_h_intern(&lf[353],11,"set-groups!");
lf[354]=C_h_intern(&lf[354],21,"set-process-group-id!");
lf[355]=C_h_intern(&lf[355],19,"set-root-directory!");
lf[356]=C_h_intern(&lf[356],16,"set-signal-mask!");
lf[357]=C_h_intern(&lf[357],12,"set-user-id!");
lf[358]=C_h_intern(&lf[358],11,"signal-mask");
lf[359]=C_h_intern(&lf[359],12,"signal-mask!");
lf[360]=C_h_intern(&lf[360],14,"signal-masked\077");
lf[361]=C_h_intern(&lf[361],14,"signal-unmask!");
lf[362]=C_h_intern(&lf[362],13,"terminal-name");
lf[363]=C_h_intern(&lf[363],13,"terminal-size");
lf[364]=C_h_intern(&lf[364],22,"unmap-file-from-memory");
lf[365]=C_h_intern(&lf[365],16,"user-information");
lf[366]=C_h_intern(&lf[366],17,"utc-time->seconds");
lf[367]=C_h_intern(&lf[367],12,"string->time");
lf[368]=C_h_intern(&lf[368],16,"errno/wouldblock");
lf[369]=C_h_intern(&lf[369],19,"memory-mapped-file\077");
lf[370]=C_h_intern(&lf[370],13,"map/anonymous");
lf[371]=C_h_intern(&lf[371],8,"map/file");
lf[372]=C_h_intern(&lf[372],9,"map/fixed");
lf[373]=C_h_intern(&lf[373],11,"map/private");
lf[374]=C_h_intern(&lf[374],10,"map/shared");
lf[375]=C_h_intern(&lf[375],10,"open/fsync");
lf[376]=C_h_intern(&lf[376],11,"open/noctty");
lf[377]=C_h_intern(&lf[377],13,"open/nonblock");
lf[378]=C_h_intern(&lf[378],9,"open/sync");
lf[379]=C_h_intern(&lf[379],10,"perm/isgid");
lf[380]=C_h_intern(&lf[380],10,"perm/isuid");
lf[381]=C_h_intern(&lf[381],10,"perm/isvtx");
lf[382]=C_h_intern(&lf[382],9,"prot/exec");
lf[383]=C_h_intern(&lf[383],9,"prot/none");
lf[384]=C_h_intern(&lf[384],9,"prot/read");
lf[385]=C_h_intern(&lf[385],10,"prot/write");
lf[386]=C_h_intern(&lf[386],11,"make-vector");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[389]=C_h_intern(&lf[389],18,"getter-with-setter");
lf[390]=C_h_intern(&lf[390],26,"set-file-modification-time");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000!cannot set file modification-time");
lf[392]=C_h_intern(&lf[392],17,"register-feature!");
lf[393]=C_h_intern(&lf[393],5,"posix");
C_register_lf2(lf,394,create_ptable());
t2=C_mutate(&lf[0] /* (set! c1367 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1874,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1872 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1875 in k1872 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1878 in k1875 in k1872 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 939  register-feature! */
t3=*((C_word*)lf[392]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[393]);}

/* k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1899,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[10]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[11]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[12]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[13]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[14]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[15]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[16]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[17]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[18]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[19]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[20]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[21]+1 /* (set! open/noinherit ...) */,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[22]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[23]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[24]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[25]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[26]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[27]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[28]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[29]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[30]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[31]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[32]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[33]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_u_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[34]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1945,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[39]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1986,tmp=(C_word)a,a+=2,tmp));
t34=*((C_word*)lf[41]+1);
t35=C_mutate((C_word*)lf[42]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2004,a[2]=t34,tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[46]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2049,tmp=(C_word)a,a+=2,tmp));
t37=*((C_word*)lf[49]+1);
t38=C_mutate((C_word*)lf[50]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2091,a[2]=t37,tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[53]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[54]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[55]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[56] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2129,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[59]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2167,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[60]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2191,tmp=(C_word)a,a+=2,tmp));
t45=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t46=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5764,tmp=(C_word)a,a+=2,tmp);
t47=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5770,tmp=(C_word)a,a+=2,tmp);
/* posixwin.scm: 1105 getter-with-setter */
t48=*((C_word*)lf[389]+1);
((C_proc4)(void*)(*((C_word*)t48+1)))(4,t48,t45,t46,t47);}

/* a5769 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5770,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[390]);
t5=(C_word)C_i_check_number_2(t3,lf[390]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5789,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5802,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1112 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5800 in a5769 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5783,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
/* ##sys#make-c-string */
t4=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}
else{
t4=((C_word*)t0)[2];
f_5789(t4,(C_word)stub123(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t2));}}

/* k5781 in k5800 in a5769 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5789(t2,(C_word)stub123(C_SCHEME_UNDEFINED,t1,((C_word*)t0)[2]));}

/* k5787 in a5769 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_5789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixwin.scm: 1115 posix-error */
t2=lf[3];
f_1899(7,t2,((C_word*)t0)[4],lf[35],lf[390],lf[391],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* a5763 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5764,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5768,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1107 ##sys#stat */
f_2129(t3,t2);}

/* k5766 in a5763 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5768,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2199,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! file-modification-time ...) */,t1);
t3=C_mutate((C_word*)lf[62]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2201,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[63]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2207,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[64]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2213,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[65]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2219,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[66]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2225,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[68]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2248,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f6424,tmp=(C_word)a,a+=2,tmp);
t10=C_mutate((C_word*)lf[69]+1 /* (set! character-device? ...) */,t9);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f6418,tmp=(C_word)a,a+=2,tmp);
t12=C_mutate((C_word*)lf[70]+1 /* (set! block-device? ...) */,t11);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f6412,tmp=(C_word)a,a+=2,tmp);
t14=C_mutate((C_word*)lf[71]+1 /* (set! fifo? ...) */,t13);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f6406,tmp=(C_word)a,a+=2,tmp);
t16=C_mutate((C_word*)lf[72]+1 /* (set! socket? ...) */,t15);
t17=C_mutate((C_word*)lf[73]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2277,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5727,tmp=(C_word)a,a+=2,tmp);
/* posixwin.scm: 1160 getter-with-setter */
t20=*((C_word*)lf[389]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t18,t19,*((C_word*)lf[73]+1));}

/* a5726 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5727,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5731,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5743,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1162 port? */
t5=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5741 in a5726 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[75]);
if(C_truep(t3)){
t4=(C_word)C_ftell(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
f_5731(2,t5,t4);}
else{
t4=((C_word*)t0)[2];
f_5731(2,t4,C_fix(-1));}}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR));
t3=((C_word*)t0)[2];
f_5731(2,t3,t2);}
else{
/* posixwin.scm: 1169 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[44],lf[80],lf[388],((C_word*)t0)[3]);}}}

/* k5729 in a5726 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5734,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_lessp(t1,C_fix(0)))){
/* posixwin.scm: 1171 posix-error */
t3=lf[3];
f_1899(6,t3,t2,lf[35],lf[80],lf[387],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k5732 in k5729 in a5726 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word ab[80],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! file-position ...) */,t1);
t3=C_mutate((C_word*)lf[81]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2339,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[87]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2489,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[89]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2514,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[2]+1);
t7=*((C_word*)lf[41]+1);
t8=*((C_word*)lf[91]+1);
t9=C_mutate((C_word*)lf[92]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2539,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[96]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2696,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[41]+1);
t12=C_mutate((C_word*)lf[95]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2723,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[99]+1);
t14=*((C_word*)lf[100]+1);
t15=*((C_word*)lf[101]+1);
t16=*((C_word*)lf[102]+1);
t17=*((C_word*)lf[103]+1);
t18=*((C_word*)lf[2]+1);
t19=*((C_word*)lf[104]+1);
t20=*((C_word*)lf[95]+1);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2783,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[109]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2839,a[2]=t16,a[3]=t14,a[4]=t19,a[5]=t21,a[6]=t15,a[7]=t13,a[8]=t17,a[9]=t18,tmp=(C_word)a,a+=10,tmp));
t23=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3214,tmp=(C_word)a,a+=2,tmp);
t24=C_mutate((C_word*)lf[127]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3232,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[132]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[133]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3304,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[136]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[133]+1));
t28=*((C_word*)lf[127]+1);
t29=*((C_word*)lf[132]+1);
t30=*((C_word*)lf[133]+1);
t31=*((C_word*)lf[136]+1);
t32=C_mutate((C_word*)lf[137]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3323,a[2]=t28,a[3]=t30,tmp=(C_word)a,a+=4,tmp));
t33=C_mutate((C_word*)lf[138]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3347,a[2]=t29,a[3]=t31,tmp=(C_word)a,a+=4,tmp));
t34=C_mutate((C_word*)lf[139]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3371,a[2]=t28,a[3]=t30,tmp=(C_word)a,a+=4,tmp));
t35=C_mutate((C_word*)lf[141]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3391,a[2]=t29,a[3]=t31,tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[143]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3411,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[145]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t38=C_mutate((C_word*)lf[146]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t39=C_mutate((C_word*)lf[147]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t40=C_mutate((C_word*)lf[148]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t41=C_mutate((C_word*)lf[149]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t42=C_mutate((C_word*)lf[150]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t43=C_mutate((C_word*)lf[151]+1 /* (set! signal/break ...) */,C_fix((C_word)SIGBREAK));
t44=C_set_block_item(lf[152] /* signal/alrm */,0,C_fix(0));
t45=C_set_block_item(lf[153] /* signal/chld */,0,C_fix(0));
t46=C_set_block_item(lf[154] /* signal/cont */,0,C_fix(0));
t47=C_set_block_item(lf[155] /* signal/hup */,0,C_fix(0));
t48=C_set_block_item(lf[156] /* signal/io */,0,C_fix(0));
t49=C_set_block_item(lf[157] /* signal/kill */,0,C_fix(0));
t50=C_set_block_item(lf[158] /* signal/pipe */,0,C_fix(0));
t51=C_set_block_item(lf[159] /* signal/prof */,0,C_fix(0));
t52=C_set_block_item(lf[160] /* signal/quit */,0,C_fix(0));
t53=C_set_block_item(lf[161] /* signal/stop */,0,C_fix(0));
t54=C_set_block_item(lf[162] /* signal/trap */,0,C_fix(0));
t55=C_set_block_item(lf[163] /* signal/tstp */,0,C_fix(0));
t56=C_set_block_item(lf[164] /* signal/urg */,0,C_fix(0));
t57=C_set_block_item(lf[165] /* signal/usr1 */,0,C_fix(0));
t58=C_set_block_item(lf[166] /* signal/usr2 */,0,C_fix(0));
t59=C_set_block_item(lf[167] /* signal/vtalrm */,0,C_fix(0));
t60=C_set_block_item(lf[168] /* signal/winch */,0,C_fix(0));
t61=C_set_block_item(lf[169] /* signal/xcpu */,0,C_fix(0));
t62=C_set_block_item(lf[170] /* signal/xfsz */,0,C_fix(0));
t63=(C_word)C_a_i_list(&a,7,*((C_word*)lf[145]+1),*((C_word*)lf[146]+1),*((C_word*)lf[147]+1),*((C_word*)lf[148]+1),*((C_word*)lf[149]+1),*((C_word*)lf[150]+1),*((C_word*)lf[151]+1));
t64=C_mutate((C_word*)lf[171]+1 /* (set! signals-list ...) */,t63);
t65=*((C_word*)lf[172]+1);
t66=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[2],a[3]=t65,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1495 make-vector */
t67=*((C_word*)lf[386]+1);
((C_proc4)(void*)(*((C_word*)t67+1)))(4,t67,t66,C_fix(256),C_SCHEME_FALSE);}

/* k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word t181;
C_word t182;
C_word t183;
C_word t184;
C_word t185;
C_word t186;
C_word t187;
C_word ab[230],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3478,2,t0,t1);}
t2=C_mutate((C_word*)lf[173]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3480,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[174]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3489,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[172]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3502,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[175]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[176]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[177]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[178]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[179]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[180]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[181]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[182]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[183]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[184]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[185]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[186]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[187]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[188]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[189]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[190]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[191]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[192]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[193]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[194]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[195]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[196]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[197]+1 /* (set! errno/nxio ...) */,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[198]+1 /* (set! errno/2big ...) */,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[199]+1 /* (set! errno/xdev ...) */,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[200]+1 /* (set! errno/nodev ...) */,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[201]+1 /* (set! errno/nfile ...) */,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[202]+1 /* (set! errno/notty ...) */,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[203]+1 /* (set! errno/fbig ...) */,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[204]+1 /* (set! errno/mlink ...) */,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[205]+1 /* (set! errno/dom ...) */,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[206]+1 /* (set! errno/range ...) */,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[207]+1 /* (set! errno/deadlk ...) */,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[208]+1 /* (set! errno/nametoolong ...) */,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[209]+1 /* (set! errno/nolck ...) */,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[210]+1 /* (set! errno/nosys ...) */,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[211]+1 /* (set! errno/notempty ...) */,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[212]+1 /* (set! errno/ilseq ...) */,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[213]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3558,tmp=(C_word)a,a+=2,tmp));
t44=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3588,tmp=(C_word)a,a+=2,tmp);
t45=C_mutate((C_word*)lf[215]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3612,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[216]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3618,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[217]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3624,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[218]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[219]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[220]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)2));
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_SCHEME_UNDEFINED;
t54=(*a=C_VECTOR_TYPE|1,a[1]=t53,tmp=(C_word)a,a+=2,tmp);
t55=C_set_block_item(t52,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3633,tmp=(C_word)a,a+=2,tmp));
t56=C_set_block_item(t54,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3670,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[229]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3688,a[2]=t52,a[3]=t54,tmp=(C_word)a,a+=4,tmp));
t58=C_mutate((C_word*)lf[230]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3702,a[2]=t52,a[3]=t54,tmp=(C_word)a,a+=4,tmp));
t59=C_mutate((C_word*)lf[231]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3716,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[235]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3751,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[237]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3781,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[238]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3798,tmp=(C_word)a,a+=2,tmp));
t63=*((C_word*)lf[239]+1);
t64=C_mutate((C_word*)lf[240]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3813,a[2]=t63,tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[241]+1 /* (set! current-environment ...) */,*((C_word*)lf[240]+1));
t66=C_mutate(&lf[242] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3879,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[244]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3898,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[247]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3925,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[248]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3957,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[250]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4008,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[253]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4068,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[256]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4083,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[257]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4091,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[258]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4107,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[259]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4113,tmp=(C_word)a,a+=2,tmp));
t76=*((C_word*)lf[265]+1);
t77=*((C_word*)lf[266]+1);
t78=*((C_word*)lf[267]+1);
t79=*((C_word*)lf[92]+1);
t80=*((C_word*)lf[268]+1);
t81=*((C_word*)lf[269]+1);
t82=C_mutate((C_word*)lf[270]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4172,a[2]=t78,a[3]=t76,a[4]=t79,a[5]=t77,a[6]=t80,a[7]=t81,tmp=(C_word)a,a+=8,tmp));
t83=C_mutate((C_word*)lf[273]+1 /* (set! spawn/overlay ...) */,C_fix((C_word)P_OVERLAY));
t84=C_mutate((C_word*)lf[274]+1 /* (set! spawn/wait ...) */,C_fix((C_word)P_WAIT));
t85=C_mutate((C_word*)lf[275]+1 /* (set! spawn/nowait ...) */,C_fix((C_word)P_NOWAIT));
t86=C_mutate((C_word*)lf[276]+1 /* (set! spawn/nowaito ...) */,C_fix((C_word)P_NOWAITO));
t87=C_mutate((C_word*)lf[277]+1 /* (set! spawn/detach ...) */,C_fix((C_word)P_DETACH));
t88=*((C_word*)lf[278]+1);
t89=*((C_word*)lf[49]+1);
t90=*((C_word*)lf[103]+1);
t91=*((C_word*)lf[2]+1);
t92=C_mutate(&lf[279] /* (set! $quote-args-list ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4289,a[2]=t91,a[3]=t89,a[4]=t90,a[5]=t88,tmp=(C_word)a,a+=6,tmp));
t93=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4368,tmp=(C_word)a,a+=2,tmp);
t94=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4374,tmp=(C_word)a,a+=2,tmp);
t95=*((C_word*)lf[282]+1);
t96=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4380,tmp=(C_word)a,a+=2,tmp);
t97=C_mutate(&lf[283] /* (set! $exec-setup ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4430,a[2]=t95,a[3]=t93,a[4]=t94,a[5]=t96,tmp=(C_word)a,a+=6,tmp));
t98=C_mutate(&lf[284] /* (set! $exec-teardown ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4466,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[285]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4481,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[287]+1 /* (set! process-spawn ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4565,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[289]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4649,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[290]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4652,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[294]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4673,tmp=(C_word)a,a+=2,tmp));
t104=*((C_word*)lf[287]+1);
t105=*((C_word*)lf[292]+1);
t106=C_mutate((C_word*)lf[296]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4679,a[2]=t104,tmp=(C_word)a,a+=3,tmp));
t107=C_mutate((C_word*)lf[297]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4759,tmp=(C_word)a,a+=2,tmp));
t108=C_set_block_item(lf[302] /* process */,0,C_SCHEME_UNDEFINED);
t109=C_set_block_item(lf[303] /* process* */,0,C_SCHEME_UNDEFINED);
t110=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4857,tmp=(C_word)a,a+=2,tmp);
t111=C_mutate((C_word*)lf[302]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4919,a[2]=t110,tmp=(C_word)a,a+=3,tmp));
t112=C_mutate((C_word*)lf[303]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4996,a[2]=t110,tmp=(C_word)a,a+=3,tmp));
t113=C_mutate((C_word*)lf[306]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5073,tmp=(C_word)a,a+=2,tmp));
t114=C_mutate((C_word*)lf[307]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5085,tmp=(C_word)a,a+=2,tmp));
t115=C_mutate((C_word*)lf[309]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5142,tmp=(C_word)a,a+=2,tmp));
t116=C_mutate((C_word*)lf[310]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5145,tmp=(C_word)a,a+=2,tmp));
t117=C_mutate((C_word*)lf[312]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5157,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[104]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5188,tmp=(C_word)a,a+=2,tmp));
t119=*((C_word*)lf[270]+1);
t120=*((C_word*)lf[266]+1);
t121=*((C_word*)lf[268]+1);
t122=*((C_word*)lf[316]+1);
t123=*((C_word*)lf[96]+1);
t124=C_mutate((C_word*)lf[317]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5203,a[2]=t123,a[3]=t122,a[4]=t121,a[5]=t119,a[6]=t120,tmp=(C_word)a,a+=7,tmp));
t125=C_mutate((C_word*)lf[324]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5446,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[326]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5452,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[327]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5458,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[328]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5464,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[329]+1 /* (set! current-effective-group-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5470,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[330]+1 /* (set! current-effective-user-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5476,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[331]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5482,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[332]+1 /* (set! current-group-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5488,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[333]+1 /* (set! current-user-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5494,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[334]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5500,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[335]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5506,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[336]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5512,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[337]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5518,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[338]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5524,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[339]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5530,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[340]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5536,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[341]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5542,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[342]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5548,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[343]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5554,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[344]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5560,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[345]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5566,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[346]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5572,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[347]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5578,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[348]+1 /* (set! process-group-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5584,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[349]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5590,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[350]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5596,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[351]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5602,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[352]+1 /* (set! set-group-id! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5608,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[353]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5614,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[354]+1 /* (set! set-process-group-id! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5620,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[355]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5626,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[356]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5632,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[357]+1 /* (set! set-user-id! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5638,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[358]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5644,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[359]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5650,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[360]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5656,tmp=(C_word)a,a+=2,tmp));
t161=C_mutate((C_word*)lf[361]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5662,tmp=(C_word)a,a+=2,tmp));
t162=C_mutate((C_word*)lf[362]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5668,tmp=(C_word)a,a+=2,tmp));
t163=C_mutate((C_word*)lf[363]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5674,tmp=(C_word)a,a+=2,tmp));
t164=C_mutate((C_word*)lf[364]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5680,tmp=(C_word)a,a+=2,tmp));
t165=C_mutate((C_word*)lf[365]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5686,tmp=(C_word)a,a+=2,tmp));
t166=C_mutate((C_word*)lf[366]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5692,tmp=(C_word)a,a+=2,tmp));
t167=C_mutate((C_word*)lf[367]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5698,tmp=(C_word)a,a+=2,tmp));
t168=C_set_block_item(lf[368] /* errno/wouldblock */,0,C_fix(0));
t169=C_mutate((C_word*)lf[71]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5705,tmp=(C_word)a,a+=2,tmp));
t170=C_mutate((C_word*)lf[369]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5708,tmp=(C_word)a,a+=2,tmp));
t171=C_set_block_item(lf[370] /* map/anonymous */,0,C_fix(0));
t172=C_set_block_item(lf[371] /* map/file */,0,C_fix(0));
t173=C_set_block_item(lf[372] /* map/fixed */,0,C_fix(0));
t174=C_set_block_item(lf[373] /* map/private */,0,C_fix(0));
t175=C_set_block_item(lf[374] /* map/shared */,0,C_fix(0));
t176=C_set_block_item(lf[375] /* open/fsync */,0,C_fix(0));
t177=C_set_block_item(lf[376] /* open/noctty */,0,C_fix(0));
t178=C_set_block_item(lf[377] /* open/nonblock */,0,C_fix(0));
t179=C_set_block_item(lf[378] /* open/sync */,0,C_fix(0));
t180=C_set_block_item(lf[379] /* perm/isgid */,0,C_fix(0));
t181=C_set_block_item(lf[380] /* perm/isuid */,0,C_fix(0));
t182=C_set_block_item(lf[381] /* perm/isvtx */,0,C_fix(0));
t183=C_set_block_item(lf[382] /* prot/exec */,0,C_fix(0));
t184=C_set_block_item(lf[383] /* prot/none */,0,C_fix(0));
t185=C_set_block_item(lf[384] /* prot/read */,0,C_fix(0));
t186=C_set_block_item(lf[385] /* prot/write */,0,C_fix(0));
t187=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t187+1)))(2,t187,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5708,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5705,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* string->time in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5698,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[367],lf[0]);}

/* utc-time->seconds in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5692,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[366],lf[0]);}

/* user-information in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5686,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[365],lf[0]);}

/* unmap-file-from-memory in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5680(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5680,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[364],lf[0]);}

/* terminal-size in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5674(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5674,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[363],lf[0]);}

/* terminal-name in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5668,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[362],lf[0]);}

/* signal-unmask! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5662(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5662,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[361],lf[0]);}

/* signal-masked? in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5656(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5656,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[360],lf[0]);}

/* signal-mask! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5650(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5650,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[359],lf[0]);}

/* signal-mask in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5644(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5644,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[358],lf[0]);}

/* set-user-id! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[357],lf[0]);}

/* set-signal-mask! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[356],lf[0]);}

/* set-root-directory! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5626,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[355],lf[0]);}

/* set-process-group-id! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5620,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[354],lf[0]);}

/* set-groups! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5614,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[353],lf[0]);}

/* set-group-id! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5608,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[352],lf[0]);}

/* set-alarm! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5602,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[351],lf[0]);}

/* read-symbolic-link in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5596,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[350],lf[0]);}

/* process-signal in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5590,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[349],lf[0]);}

/* process-group-id in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5584(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5584,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[348],lf[0]);}

/* process-fork in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5578,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[347],lf[0]);}

/* parent-process-id in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5572,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[346],lf[0]);}

/* memory-mapped-file-pointer in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5566,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[345],lf[0]);}

/* initialize-groups in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5560,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[344],lf[0]);}

/* group-information in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[343],lf[0]);}

/* get-groups in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[342],lf[0]);}

/* file-unlock in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[341],lf[0]);}

/* file-truncate in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5536,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[340],lf[0]);}

/* file-test-lock in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5530,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[339],lf[0]);}

/* file-select in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5524,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[338],lf[0]);}

/* file-lock/blocking in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5518,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[337],lf[0]);}

/* file-lock in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5512,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[336],lf[0]);}

/* file-link in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[335],lf[0]);}

/* map-file-to-memory in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[334],lf[0]);}

/* current-user-id in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[333],lf[0]);}

/* current-group-id in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5488,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[332],lf[0]);}

/* current-effective-user-name in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5482(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5482,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[331],lf[0]);}

/* current-effective-user-id in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5476,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[330],lf[0]);}

/* current-effective-group-id in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5470,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[329],lf[0]);}

/* create-symbolic-link in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5464,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[328],lf[0]);}

/* create-session in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5458,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[327],lf[0]);}

/* create-fifo in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5452,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[326],lf[0]);}

/* change-file-owner in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5446(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5446,2,t0,t1);}
/* error */
t2=*((C_word*)lf[325]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[324],lf[0]);}

/* find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_5203r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5203r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5203r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5370,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5375,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5380,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action12541319 */
t9=t8;
f_5380(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id12551317 */
t11=t7;
f_5375(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit12561314 */
t13=t6;
f_5370(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body12521261 */
t15=t5;
f_5205(t15,t1,t9,t11,t13);}}}}

/* def-action1254 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_5380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5380,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5386,tmp=(C_word)a,a+=2,tmp);
/* def-id12551317 */
t3=((C_word*)t0)[2];
f_5375(t3,t1,t2);}

/* a5385 in def-action1254 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5386,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1255 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_5375(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5375,NULL,3,t0,t1,t2);}
/* def-limit12561314 */
t3=((C_word*)t0)[2];
f_5370(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1256 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_5370(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5370,NULL,4,t0,t1,t2,t3);}
/* body12521261 */
t4=((C_word*)t0)[2];
f_5205(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_5205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5205,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[8],lf[317]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5212,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=t7,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
t9=t4;
if(C_truep(t9)){
if(C_truep((C_word)C_fixnump(t4))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5365,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t11=t8;
f_5212(t11,t10);}
else{
t10=t4;
t11=t8;
f_5212(t11,t10);}}
else{
t10=t8;
f_5212(t10,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5357,tmp=(C_word)a,a+=2,tmp));}}

/* f_5357 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5357(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5357,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_5365 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5365(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5365,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_5212(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5212,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=t3;
f_5345(2,t4,t2);}
else{
/* posixwin.scm: 2077 regexp? */
t4=*((C_word*)lf[323]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[12]);}}

/* k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5345,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t2,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5339,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2080 make-pathname */
t5=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[322]);}

/* k5337 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2080 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5222,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5224,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5224(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_5224(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5224,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t4,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=t5,a[12]=t1,a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* posixwin.scm: 2086 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5243,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 2087 pathname-file */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5325,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 2094 pproc */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}}

/* k5323 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5325,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5332,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 2094 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 2095 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5224(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k5330 in k5323 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2094 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5224(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5319,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[318]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[319]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 2087 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_5224(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixwin.scm: 2088 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k5256 in k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5258,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5268,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5270,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5299,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[321]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5309,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5312,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 2093 pproc */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}}

/* k5310 in k5256 in k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 2093 action */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[5];
/* posixwin.scm: 2093 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5224(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k5307 in k5256 in k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2093 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5224(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5298 in k5256 in k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5299,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a5274 in k5256 in k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5283,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5297,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2091 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],lf[320]);}

/* k5295 in a5274 in k5256 in k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2091 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5281 in a5274 in k5256 in k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5287,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5290,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 2092 pproc */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k5288 in k5281 in a5274 in k5256 in k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 2092 action */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[5];
/* posixwin.scm: 2091 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5224(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k5285 in k5281 in a5274 in k5256 in k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2091 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5224(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5269 in k5256 in k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5270,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k5266 in k5256 in k5317 in k5241 in loop in k5220 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2089 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5224(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_5346 in k5343 in k5210 in body1252 in find-files in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5346,3,t0,t1,t2);}
/* posixwin.scm: 2078 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5188,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5198,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2052 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5196 in current-user-name in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2053 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[104],lf[315]);}

/* system-information in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5157,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5168,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5183,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2043 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5181 in system-information in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2044 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[312],lf[314]);}

/* k5166 in system-information in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5172,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k5170 in k5166 in system-information in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5176,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k5174 in k5170 in k5166 in system-information in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5180,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k5178 in k5174 in k5170 in k5166 in system-information in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5180,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[313],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5145,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 2033 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[310],lf[311]);}}

/* sleep in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5142,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5085(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5085r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5085r(t0,t1,t2,t3);}}

static void C_ccall f_5085r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_check_exact_2(t2,lf[307]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5103,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5109,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a5108 in process-wait in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5109,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2015 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 2017 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k5117 in a5108 in process-wait in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2016 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[298],lf[307],lf[308],((C_word*)t0)[2]);}

/* a5102 in process-wait in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5103,2,t0,t1);}
/* posixwin.scm: 2012 ##sys#process-wait */
t2=*((C_word*)lf[306]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_5073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5073,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 2005 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 2006 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_4996r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4996r(t0,t1,t2,t3);}}

static void C_ccall f_4996r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4998,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5003,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5008,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5013,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args11881204 */
t8=t7;
f_5013(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env11891202 */
t10=t6;
f_5008(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf11901199 */
t12=t5;
f_5003(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body11861195 */
t14=t4;
f_4998(t14,t1,t8,t10,t12);}}}}

/* def-args1188 in process* in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_5013(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5013,NULL,2,t0,t1);}
/* def-env11891202 */
t2=((C_word*)t0)[2];
f_5008(t2,t1,C_SCHEME_FALSE);}

/* def-env1189 in process* in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_5008(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5008,NULL,3,t0,t1,t2);}
/* def-exactf11901199 */
t3=((C_word*)t0)[2];
f_5003(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1190 in process* in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_5003(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5003,NULL,4,t0,t1,t2,t3);}
/* body11861195 */
t4=((C_word*)t0)[2];
f_4998(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1186 in process* in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4998(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4998,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1999 %process */
f_4857(t1,lf[303],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_4919r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4919r(t0,t1,t2,t3);}}

static void C_ccall f_4919r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4921,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4926,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4931,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4936,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args11491165 */
t8=t7;
f_4936(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env11501163 */
t10=t6;
f_4931(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf11511160 */
t12=t5;
f_4926(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body11471156 */
t14=t4;
f_4921(t14,t1,t8,t10,t12);}}}}

/* def-args1149 in process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4936,NULL,2,t0,t1);}
/* def-env11501163 */
t2=((C_word*)t0)[2];
f_4931(t2,t1,C_SCHEME_FALSE);}

/* def-env1150 in process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4931(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4931,NULL,3,t0,t1,t2);}
/* def-exactf11511160 */
t3=((C_word*)t0)[2];
f_4926(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf1151 in process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4926(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4926,NULL,4,t0,t1,t2,t3);}
/* body11471156 */
t4=((C_word*)t0)[2];
f_4921(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1147 in process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4921(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4921,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1996 %process */
f_4857(t1,lf[302],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4857(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4857,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4859,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4878,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1984 chkstrlst */
t14=t11;
f_4859(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4913,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1987 ##sys#shell-command-arguments */
t16=*((C_word*)lf[294]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,((C_word*)t8)[1]);}}

/* k4911 in %process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1988 ##sys#shell-command */
t4=*((C_word*)lf[290]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4915 in k4911 in %process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4878(2,t3,t2);}

/* k4876 in %process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
/* posixwin.scm: 1989 chkstrlst */
t3=((C_word*)t0)[2];
f_4859(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_4881(2,t3,C_SCHEME_UNDEFINED);}}

/* k4879 in k4876 in %process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4892,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4891 in k4879 in k4876 in %process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4892,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1992 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1993 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a4885 in k4879 in k4876 in %process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4886,2,t0,t1);}
/* posixwin.scm: 1990 ##sys#process */
t2=*((C_word*)lf[297]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4859(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4859,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a4867 in chkstrlst in %process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4868,3,t0,t1,t2);}
t3=*((C_word*)lf[304]+1);
/* g11171118 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr9rv,(void*)f_4759r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest_vector(a,C_rest_count(0));
f_4759r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_4759r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(14);
t10=(C_word)C_vemptyp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:(C_word)C_slot(t9,C_fix(0)));
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4766,a[2]=t2,a[3]=t6,a[4]=t7,a[5]=t8,a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4838,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_a_i_cons(&a,2,t3,t4);
/* posixwin.scm: 1956 $quote-args-list */
t15=lf[279];
f_4289(t15,t13,t14,t11);}

/* k4836 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1956 string-intersperse */
t2=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=((*(int *)C_data_pointer(t2))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t5=((*(int *)C_data_pointer(t4))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t7=((*(int *)C_data_pointer(t6))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=((*(int *)C_data_pointer(t8))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t10=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4806,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
t11=*((C_word*)lf[300]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,t2,C_fix(0),C_SCHEME_FALSE,lf[301]);}

/* k4804 in k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[300]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[301]);}

/* k4808 in k4804 in k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[300]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[301]);}

/* k4812 in k4808 in k4804 in k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[300]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[301]);}

/* k4816 in k4812 in k4808 in k4804 in k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
if(C_truep(((C_word*)t0)[8])){
/* posixwin.scm: 1963 + */
C_plus(5,0,t2,t3,t4,C_fix(0));}
else{
/* posixwin.scm: 1963 + */
C_plus(5,0,t2,t3,t4,C_fix(4));}}

/* k4820 in k4816 in k4812 in k4808 in k4804 in k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4713,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t9=t8;
f_4713(2,t9,C_SCHEME_FALSE);}}

/* k4711 in k4820 in k4816 in k4812 in k4808 in k4804 in k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_4717(2,t3,C_SCHEME_FALSE);}}

/* k4715 in k4711 in k4820 in k4816 in k4812 in k4808 in k4804 in k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4717,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
if(C_truep((C_word)stub1006(C_SCHEME_UNDEFINED,((C_word*)t0)[13],t1,C_SCHEME_FALSE,t2,t3,t4,t5,((C_word*)t0)[12]))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1966 open-input-file* */
t7=*((C_word*)lf[229]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t7=t6;
f_4779(2,t7,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1971 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4797 in k4715 in k4711 in k4820 in k4816 in k4812 in k4808 in k4804 in k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1972 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[298],((C_word*)t0)[3],lf[299],((C_word*)t0)[2]);}

/* k4777 in k4715 in k4711 in k4820 in k4816 in k4812 in k4808 in k4804 in k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1967 open-output-file* */
t3=*((C_word*)lf[230]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_4783(2,t3,C_SCHEME_FALSE);}}

/* k4781 in k4777 in k4715 in k4711 in k4820 in k4816 in k4812 in k4808 in k4804 in k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4787,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1969 open-input-file* */
t3=*((C_word*)lf[229]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixwin.scm: 1965 values */
C_values(6,0,((C_word*)t0)[6],((C_word*)t0)[5],t1,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))),C_SCHEME_FALSE);}}

/* k4785 in k4781 in k4777 in k4715 in k4711 in k4820 in k4816 in k4812 in k4808 in k4804 in k4764 in ##sys#process in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1965 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* process-run in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4679r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4679r(t0,t1,t2,t3);}}

static void C_ccall f_4679r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1927 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,*((C_word*)lf[275]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4696,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1928 ##sys#shell-command */
t7=*((C_word*)lf[290]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4694 in process-run in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4700,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1928 ##sys#shell-command-arguments */
t3=*((C_word*)lf[294]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4698 in k4694 in process-run in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1928 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[275]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4673,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[295],t2));}

/* ##sys#shell-command in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4656,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1911 get-environment-variable */
t3=*((C_word*)lf[292]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[293]);}

/* k4654 in ##sys#shell-command in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4656,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1915 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k4666 in k4654 in ##sys#shell-command in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1916 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[290],lf[291]);}

/* current-process-id in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub981(C_SCHEME_UNDEFINED));}

/* process-spawn in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_4565r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4565r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4565r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4567,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4579,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4584,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4589,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst957974 */
t9=t8;
f_4589(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst958972 */
t11=t7;
f_4584(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf959969 */
t13=t6;
f_4579(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body955964 */
t15=t5;
f_4567(t15,t1,t9,t11,t13);}}}}

/* def-arglst957 in process-spawn in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4589,NULL,2,t0,t1);}
/* def-envlst958972 */
t2=((C_word*)t0)[2];
f_4584(t2,t1,C_SCHEME_FALSE);}

/* def-envlst958 in process-spawn in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4584,NULL,3,t0,t1,t2);}
/* def-exactf959969 */
t3=((C_word*)t0)[2];
f_4579(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf959 in process-spawn in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4579(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4579,NULL,4,t0,t1,t2,t3);}
/* body955964 */
t4=((C_word*)t0)[2];
f_4567(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body955 in process-spawn in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4567(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4567,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4571,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1902 $exec-setup */
t6=lf[283];
f_4430(t6,t5,lf[287],((C_word*)t0)[2],t2,t3,t4);}

/* k4569 in body955 in process-spawn in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_spawnvpe(((C_word*)t0)[4],t1);
/* posixwin.scm: 1903 $exec-teardown */
f_4466(((C_word*)t0)[3],lf[287],lf[288],((C_word*)t0)[2],t2);}
else{
t2=(C_word)C_spawnvp(((C_word*)t0)[4],t1);
/* posixwin.scm: 1903 $exec-teardown */
f_4466(((C_word*)t0)[3],lf[287],lf[288],((C_word*)t0)[2],t2);}}

/* process-execute in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_4481r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4481r(t0,t1,t2,t3);}}

static void C_ccall f_4481r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4483,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4495,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4500,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4505,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst915932 */
t8=t7;
f_4505(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst916930 */
t10=t6;
f_4500(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf917927 */
t12=t5;
f_4495(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body913922 */
t14=t4;
f_4483(t14,t1,t8,t10,t12);}}}}

/* def-arglst915 in process-execute in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4505,NULL,2,t0,t1);}
/* def-envlst916930 */
t2=((C_word*)t0)[2];
f_4500(t2,t1,C_SCHEME_FALSE);}

/* def-envlst916 in process-execute in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4500,NULL,3,t0,t1,t2);}
/* def-exactf917927 */
t3=((C_word*)t0)[2];
f_4495(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf917 in process-execute in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4495(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4495,NULL,4,t0,t1,t2,t3);}
/* body913922 */
t4=((C_word*)t0)[2];
f_4483(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body913 in process-execute in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4483(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4483,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1897 $exec-setup */
t6=lf[283];
f_4430(t6,t5,lf[285],((C_word*)t0)[2],t2,t3,t4);}

/* k4485 in body913 in process-execute in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_execve(t1);
/* posixwin.scm: 1898 $exec-teardown */
f_4466(((C_word*)t0)[3],lf[285],lf[286],((C_word*)t0)[2],t2);}
else{
t2=(C_word)C_execvp(t1);
/* posixwin.scm: 1898 $exec-teardown */
f_4466(((C_word*)t0)[3],lf[285],lf[286],((C_word*)t0)[2],t2);}}

/* $exec-teardown in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4466(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4466,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4470,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1889 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k4468 in $exec-teardown in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1893 ##sys#error */
t5=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* $exec-setup in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4430(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4430,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4437,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1881 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}

/* k4435 in $exec-setup in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
/* posixwin.scm: 1882 setarg */
t4=((C_word*)t0)[4];
f_4368(5,t4,t2,C_fix(0),t1,t3);}

/* k4438 in k4435 in $exec-setup in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4457,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1883 $quote-args-list */
t4=lf[279];
f_4289(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1883 build-exec-argvec */
f_4380(t2,((C_word*)t0)[7],C_SCHEME_FALSE,((C_word*)t0)[4],C_fix(1));}}

/* k4455 in k4438 in k4435 in $exec-setup in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1883 build-exec-argvec */
f_4380(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k4441 in k4438 in k4435 in $exec-setup in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1884 build-exec-argvec */
f_4380(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k4444 in k4441 in k4438 in k4435 in $exec-setup in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4453,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1886 ##sys#expand-home-path */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4451 in k4444 in k4441 in k4438 in k4435 in $exec-setup in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1886 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4380(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4380,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4392,a[2]=t8,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_4392(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1878 argvec-setter */
t6=t4;
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* doloop866 in build-exec-argvec in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4392(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4392,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1874 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4411,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1877 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t3,t4,t7);}}

/* k4409 in doloop866 in build-exec-argvec in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4392(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4374,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub855(C_SCHEME_UNDEFINED,t2,t5,t4));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub855(C_SCHEME_UNDEFINED,t2,C_SCHEME_FALSE,t4));}}

/* setarg in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4368,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub845(C_SCHEME_UNDEFINED,t2,t5,t4));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub845(C_SCHEME_UNDEFINED,t2,C_SCHEME_FALSE,t4));}}

/* $quote-args-list in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4289(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4289,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4294,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4332,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4332(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4332(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4332,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1855 reverse */
t4=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4360,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4363,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t4,a[7]=t6,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1860 needs-quoting? */
t8=((C_word*)t0)[2];
f_4294(t8,t7,t4);}}

/* k4361 in loop in $quote-args-list in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4363,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1860 string-append */
t2=((C_word*)t0)[8];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],lf[280],((C_word*)t0)[6],lf[281]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
/* posixwin.scm: 1857 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4332(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k4358 in loop in $quote-args-list in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4360,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1857 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4332(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4294(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4294,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4298,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1847 string-length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4296 in needs-quoting? in $quote-args-list in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4298,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_4303(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k4296 in needs-quoting? in $quote-args-list in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4303(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4303,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4316,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4327,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1851 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k4325 in loop in k4296 in needs-quoting? in $quote-args-list in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1851 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4314 in loop in k4296 in needs-quoting? in $quote-args-list in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1852 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4303(t3,((C_word*)t0)[4],t2);}}

/* glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_4172r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4172r(t0,t1,t2);}}

static void C_ccall f_4172r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_4178(t6,t1,t2);}

/* conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4178(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4178,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4193,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a4198 in conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4199,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4278,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t7=t3;
/* posixwin.scm: 1809 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}
else{
/* posixwin.scm: 1809 make-pathname */
t7=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,C_SCHEME_FALSE,lf[272],t4);}}

/* k4276 in a4198 in conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1809 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4201 in a4198 in conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1810 regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4204 in k4201 in a4198 in conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4213,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=((C_word*)t0)[5];
/* posixwin.scm: 1811 directory */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}
else{
/* posixwin.scm: 1811 directory */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[271],C_SCHEME_TRUE);}}

/* k4211 in k4204 in k4201 in a4198 in conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4213,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4215,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_4215(t5,((C_word*)t0)[2],t1);}

/* loop in k4211 in k4204 in k4201 in a4198 in conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4215(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4215,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* posixwin.scm: 1812 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_4178(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4232,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixwin.scm: 1813 string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k4230 in loop in k4211 in k4204 in k4201 in a4198 in conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4232,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* g805806 */
t3=t2;
f_4236(t3,((C_word*)t0)[2],t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* posixwin.scm: 1815 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4215(t3,((C_word*)t0)[2],t2);}}

/* g805 in k4230 in loop in k4211 in k4204 in k4201 in a4198 in conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4236(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4236,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4244,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixwin.scm: 1814 make-pathname */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k4242 in g805 in k4230 in loop in k4211 in k4204 in k4201 in a4198 in conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4248,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1814 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4215(t4,t2,t3);}

/* k4246 in k4242 in g805 in k4230 in loop in k4211 in k4204 in k4201 in a4198 in conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4248,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a4192 in conc-loop in glob in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4193,2,t0,t1);}
/* posixwin.scm: 1808 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4113r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4113r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4113r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4117,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1780 ##sys#check-port */
t6=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[259]);}

/* k4115 in set-buffering-mode! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4117,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[261]);
if(C_truep(t6)){
t7=t5;
f_4123(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[262]);
if(C_truep(t7)){
t8=C_fix((C_word)_IOLBF);
t9=t5;
f_4123(2,t9,t8);}
else{
t8=(C_word)C_eqp(t4,lf[263]);
if(C_truep(t8)){
t9=t5;
f_4123(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1786 ##sys#error */
t9=*((C_word*)lf[130]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[259],lf[264],((C_word*)t0)[4],((C_word*)t0)[2]);}}}}

/* k4121 in k4115 in set-buffering-mode! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4123,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[259]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4132,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(7));
t5=(C_word)C_eqp(lf[75],t4);
if(C_truep(t5)){
t6=(C_word)C_setvbuf(((C_word*)t0)[2],t1,((C_word*)t0)[4]);
t7=t3;
f_4132(t7,(C_word)C_fixnum_lessp(t6,C_fix(0)));}
else{
t6=t3;
f_4132(t6,C_SCHEME_TRUE);}}

/* k4130 in k4121 in k4115 in set-buffering-mode! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_4132(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1792 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],lf[259],lf[260],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* terminal-port? in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4107,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4111,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1770 ##sys#check-port */
t4=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[258]);}

/* k4109 in terminal-port? in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* _exit in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4091r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4091r(t0,t1,t2);}}

static void C_ccall f_4091r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub742(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub742(C_SCHEME_UNDEFINED,C_fix(0)));}}

/* local-timezone-abbreviation in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4083,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub737(t2),C_fix(0));}

/* local-time->seconds in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4068,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4072,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1751 check-time-vector */
f_3879(t3,lf[253],t2);}

/* k4070 in local-time->seconds in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4072,2,t0,t1);}
t2=(C_word)C_a_mktime(&a,1,((C_word*)t0)[3]);
if(C_truep((C_word)C_flonum_equalp(t2,lf[254]))){
/* posixwin.scm: 1754 ##sys#error */
t3=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[253],lf[255],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* time->string in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4008r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4008r(t0,t1,t2,t3);}}

static void C_ccall f_4008r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4015,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1739 check-time-vector */
f_3879(t6,lf[250],t2);}

/* k4013 in time->string in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4015,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[250]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4034,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1743 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub701(t4,t3),C_fix(0));}}

/* k4035 in k4013 in time->string in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1747 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1748 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[250],lf[252],((C_word*)t0)[2]);}}

/* k4032 in k4013 in time->string in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub707(t3,t2,t1),C_fix(0));}

/* k4022 in k4013 in time->string in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixwin.scm: 1744 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[250],lf[251],((C_word*)t0)[2]);}}

/* seconds->string in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3957r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3957r(t0,t1,t2);}}

static void C_ccall f_3957r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3961,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixwin.scm: 1729 current-seconds */
t4=*((C_word*)lf[246]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=t3;
f_3961(2,t4,(C_word)C_slot(t2,C_fix(0)));}}

/* k3959 in seconds->string in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3964,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=t1;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub681(t4,t3),C_fix(0));}

/* k3962 in k3959 in seconds->string in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1732 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1733 ##sys#error */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[248],lf[249],((C_word*)t0)[2]);}}

/* seconds->utc-time in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3925r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3925r(t0,t1,t2);}}

static void C_ccall f_3925r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3929,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixwin.scm: 1723 current-seconds */
t4=*((C_word*)lf[246]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_number_2(t4,lf[247]);
/* posixwin.scm: 1725 ##sys#decode-seconds */
t6=*((C_word*)lf[245]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,C_SCHEME_TRUE);}}

/* k3927 in seconds->utc-time in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_number_2(t1,lf[247]);
/* posixwin.scm: 1725 ##sys#decode-seconds */
t3=*((C_word*)lf[245]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* seconds->local-time in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3898r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3898r(t0,t1,t2);}}

static void C_ccall f_3898r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3902,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixwin.scm: 1719 current-seconds */
t4=*((C_word*)lf[246]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_number_2(t4,lf[244]);
/* posixwin.scm: 1721 ##sys#decode-seconds */
t6=*((C_word*)lf[245]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,C_SCHEME_FALSE);}}

/* k3900 in seconds->local-time in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_number_2(t1,lf[244]);
/* posixwin.scm: 1721 ##sys#decode-seconds */
t3=*((C_word*)lf[245]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* check-time-vector in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_3879(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3879,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1717 ##sys#error */
t6=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[243],t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* get-environment-variables in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3813,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3819,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3819(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_3819(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3819,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3823,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub634(t5,t4),C_fix(0));}

/* k3821 in loop in get-environment-variables in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3823,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3831,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3831(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k3821 in loop in get-environment-variables in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_3831(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3831,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1706 substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1707 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k3855 in scan in k3821 in loop in get-environment-variables in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3861,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1706 substring */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k3859 in k3855 in scan in k3821 in loop in get-environment-variables in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3861,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3849,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1706 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3819(t5,t3,t4);}

/* k3847 in k3859 in k3855 in scan in k3821 in loop in get-environment-variables in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3798,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[238]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3806,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1694 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3804 in unsetenv in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3781,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[237]);
t5=(C_word)C_i_check_string_2(t3,lf[237]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3792,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1689 ##sys#make-c-string */
t7=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k3790 in setenv in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3796,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1689 ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3794 in k3790 in setenv in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3751r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3751r(t0,t1,t2,t3);}}

static void C_ccall f_3751r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[235]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3758,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_3758(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[235]);
t8=t5;
f_3758(t8,(C_word)C_dup2(t2,t6));}}

/* k3756 in duplicate-fileno in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_3758(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3758,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3761,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3767,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1678 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k3765 in k3756 in duplicate-fileno in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1679 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[235],lf[236],((C_word*)t0)[2]);}

/* k3759 in k3756 in duplicate-fileno in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3716(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3716,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3720,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1660 ##sys#check-port */
t4=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[231]);}

/* k3718 in port->fileno in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1661 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[234]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k3747 in k3718 in port->fileno in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3749,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1667 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[44],lf[231],lf[232],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3729,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3735,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1664 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k3733 in k3747 in k3718 in port->fileno in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1665 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[231],lf[233],((C_word*)t0)[2]);}

/* k3727 in k3747 in k3718 in port->fileno in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3702r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3702r(t0,t1,t2,t3);}}

static void C_ccall f_3702r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[230]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3714,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1656 mode */
f_3633(t5,C_SCHEME_FALSE,t3);}

/* k3712 in open-output-file* in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3714,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1656 check */
f_3670(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3688r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3688r(t0,t1,t2,t3);}}

static void C_ccall f_3688r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[229]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3700,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1652 mode */
f_3633(t5,C_SCHEME_TRUE,t3);}

/* k3698 in open-input-file* in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1652 check */
f_3670(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_3670(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3670,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3674,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1643 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3672 in check in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3674,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1645 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[35],lf[227],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3686,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1646 ##sys#make-port */
t3=*((C_word*)lf[124]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[125]+1),lf[228],lf[75]);}}

/* k3684 in k3672 in check in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* mode in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_3633(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3633,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3641,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[221]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1638 ##sys#error */
t8=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[222],t5);}
else{
/* posixwin.scm: 1634 ##sys#make-c-string */
t8=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,lf[223]);}}
else{
/* posixwin.scm: 1639 ##sys#error */
t7=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[224],t5);}}
else{
if(C_truep(t2)){
/* posixwin.scm: 1634 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[225]);}
else{
/* posixwin.scm: 1634 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[226]);}}}

/* k3639 in mode in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1634 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3624,3,t0,t1,t2);}
/* posixwin.scm: 1618 check */
f_3588(t1,t2,C_fix((C_word)2),lf[217]);}

/* file-write-access? in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3618,3,t0,t1,t2);}
/* posixwin.scm: 1617 check */
f_3588(t1,t2,C_fix((C_word)4),lf[216]);}

/* file-read-access? in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3612,3,t0,t1,t2);}
/* posixwin.scm: 1616 check */
f_3588(t1,t2,C_fix((C_word)2),lf[215]);}

/* check in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_3588(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3588,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3606,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3610,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1613 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3608 in check in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1613 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3604 in check in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(C_word)C_test_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3598,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* posixwin.scm: 1614 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3596 in k3604 in check in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3558,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[213]);
t5=(C_word)C_i_check_exact_2(t3,lf[213]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3582,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3586,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1602 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3584 in change-file-mode in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1602 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3580 in change-file-mode in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3582,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3574,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1603 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3572 in k3580 in change-file-mode in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1604 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[213],lf[214],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3502,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3512,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1510 h */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1512 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k3510 in ##sys#interrupt-hook in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1511 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3489,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[174]);
if(C_truep(t3)){
t5=t2;
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}
else{
t5=(C_word)C_establish_signal_handler(t2,C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}}

/* signal-handler in k3476 in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3480,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[173]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3411r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3411r(t0,t1,t2);}}

static void C_ccall f_3411r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?(C_word)C_u_fixnum_or(*((C_word*)lf[19]+1),*((C_word*)lf[21]+1)):(C_word)C_slot(t2,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3418,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t4),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3427,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1447 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1449 values */
C_values(4,0,t1,C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}}

/* k3425 in create-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1448 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[35],lf[143],lf[144]);}

/* k3416 in create-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1449 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3391r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3391r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3391r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[142]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3395,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k3393 in with-output-to-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3395,2,t0,t1);}
t2=C_mutate((C_word*)lf[142]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3401,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1432 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a3400 in k3393 in with-output-to-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3401r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3401r(t0,t1,t2);}}

static void C_ccall f_3401r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3405,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1434 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3403 in a3400 in k3393 in with-output-to-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[142]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3371r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3371r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3371r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[140]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3375,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k3373 in with-input-from-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=C_mutate((C_word*)lf[140]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3381,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1422 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a3380 in k3373 in with-input-from-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3381r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3381r(t0,t1,t2);}}

static void C_ccall f_3381r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3385,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1424 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3383 in a3380 in k3373 in with-input-from-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[140]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3347r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3347r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3347r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3351,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k3349 in call-with-output-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3356,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3362,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1412 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3361 in k3349 in call-with-output-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3362r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3362r(t0,t1,t2);}}

static void C_ccall f_3362r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3366,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1415 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3364 in a3361 in k3349 in call-with-output-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3355 in k3349 in call-with-output-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3356,2,t0,t1);}
/* posixwin.scm: 1413 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3323r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3323r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3323r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3327,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k3325 in call-with-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3332,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3338,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1404 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3337 in k3325 in call-with-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3338r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3338r(t0,t1,t2);}}

static void C_ccall f_3338r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3342,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1407 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3340 in a3337 in k3325 in call-with-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3331 in k3325 in call-with-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
/* posixwin.scm: 1405 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3304,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3308,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1391 ##sys#check-port */
t4=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[133]);}

/* k3306 in close-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1393 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3309 in k3306 in close-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1394 ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[35],lf[133],lf[134],((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* open-output-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_3268r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3268r(t0,t1,t2,t3);}}

static void C_ccall f_3268r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_string_2(t2,lf[132]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[128]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3282,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[128]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3289,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1386 ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[129]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3299,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1387 ##sys#make-c-string */
t11=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixwin.scm: 1361 ##sys#error */
t10=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,lf[131],t6);}}}

/* k3297 in open-output-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3299,2,t0,t1);}
t2=(C_word)open_binary_output_pipe(&a,1,t1);
/* posixwin.scm: 1383 check */
f_3214(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* k3287 in open-output-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3289,2,t0,t1);}
t2=(C_word)open_text_output_pipe(&a,1,t1);
/* posixwin.scm: 1383 check */
f_3214(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* k3280 in open-output-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1383 check */
f_3214(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_3232r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3232r(t0,t1,t2,t3);}}

static void C_ccall f_3232r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_string_2(t2,lf[127]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[128]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3246,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[128]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3253,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1376 ##sys#make-c-string */
t10=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[129]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3263,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1377 ##sys#make-c-string */
t11=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixwin.scm: 1361 ##sys#error */
t10=*((C_word*)lf[130]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,lf[131],t6);}}}

/* k3261 in open-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3263,2,t0,t1);}
t2=(C_word)open_binary_input_pipe(&a,1,t1);
/* posixwin.scm: 1373 check */
f_3214(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t2);}

/* k3251 in open-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3253,2,t0,t1);}
t2=(C_word)open_text_input_pipe(&a,1,t1);
/* posixwin.scm: 1373 check */
f_3214(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t2);}

/* k3244 in open-input-pipe in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1373 check */
f_3214(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_3214(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3214,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3218,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1363 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3216 in check in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3218,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1365 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[35],lf[123],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1366 ##sys#make-port */
t3=*((C_word*)lf[124]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[125]+1),lf[126],lf[75]);}}

/* k3228 in k3216 in check in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2839,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[109]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2846,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2979,a[2]=t4,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1300 cwd */
t8=((C_word*)t0)[5];
f_2783(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t4,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3186,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1302 sref */
t10=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_2985(t9,C_SCHEME_FALSE);}}}

/* k3184 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_2985(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2985,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2992,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2996,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1304 cwd */
t4=((C_word*)t0)[6];
f_2783(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[7]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1307 cwd */
t5=((C_word*)t0)[6];
f_2783(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3172,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1308 sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[7],C_fix(0));}}}

/* k3170 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1308 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k3159 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3161,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3168,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1309 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[4];
f_3015(t2,C_SCHEME_FALSE);}}

/* k3166 in k3159 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3015(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_3015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3015,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3038,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1311 cwd */
t4=((C_word*)t0)[5];
f_2783(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[7]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3051,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1317 cwd */
t5=((C_word*)t0)[5];
f_2783(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3133,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3154,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1318 sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[7],C_fix(0));}}}

/* k3152 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1318 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3131 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3133,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3139,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3150,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1319 sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3057(t2,C_SCHEME_FALSE);}}

/* k3148 in k3131 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1319 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3137 in k3131 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3139,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3146,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1320 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3057(t2,C_SCHEME_FALSE);}}

/* k3144 in k3137 in k3131 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3057(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_3057(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3057,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
f_2846(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3130,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1322 sref */
t5=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k3128 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1322 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k3107 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3126,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1323 sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3063(2,t2,C_SCHEME_FALSE);}}

/* k3124 in k3107 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1323 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3113 in k3107 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3115,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3122,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1324 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3063(2,t2,C_SCHEME_FALSE);}}

/* k3120 in k3113 in k3107 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1324 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3061 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3063,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1326 ##sys#substring */
t3=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],C_fix(1),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1330 sref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],C_fix(0));}}

/* k3104 in k3061 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3095,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1332 cwd */
t6=((C_word*)t0)[2];
f_2783(t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1335 cwd */
t5=((C_word*)t0)[2];
f_2783(t5,t4);}}

/* k3100 in k3104 in k3061 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1335 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[122],((C_word*)t0)[2]);}

/* k3093 in k3104 in k3061 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1332 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k3089 in k3104 in k3061 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1331 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3068 in k3061 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3074,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1328 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(3),t3);}

/* k3072 in k3068 in k3061 in k3055 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1325 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[121],t1);}

/* k3049 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1317 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[120],((C_word*)t0)[2]);}

/* k3036 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1311 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(3));}

/* k3020 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3026,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1313 user */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3024 in k3020 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3030,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1314 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k3028 in k3024 in k3020 in k3013 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1310 sappend */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[119],((C_word*)t0)[2],t1);}

/* k3007 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1307 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[118],((C_word*)t0)[2]);}

/* k2994 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1304 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k2990 in k2983 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1303 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2977 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1300 sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[117]);}

/* k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2965,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_block_size(t1);
/* posixwin.scm: 1336 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t1,C_fix(3),t4);}

/* k2963 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[85]+1);
/* g374375 */
t3=t2;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,lf[116]);}

/* k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2853,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2855(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2855(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2855,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1338 null? */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2860 in loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2868,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1339 null? */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* posixwin.scm: 1350 string=? */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[115],t4);}}

/* k2935 in k2860 in loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2937,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* posixwin.scm: 1348 loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2855(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* posixwin.scm: 1352 string=? */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[114],t3);}}

/* k2944 in k2935 in k2860 in loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2946,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
/* posixwin.scm: 1348 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2855(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[6]);
/* posixwin.scm: 1348 loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2855(t4,((C_word*)t0)[4],((C_word*)t0)[3],t3);}}

/* k2866 in k2860 in loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2868,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1340 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[6],((C_word*)t0)[5],C_fix(0),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2915,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixwin.scm: 1341 sref */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[5],t4);}}

/* k2913 in k2866 in k2860 in loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2915,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1343 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],C_fix(0),C_fix(3));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1346 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],C_fix(0),C_fix(3));}}

/* k2901 in k2913 in k2866 in k2860 in loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2907,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2911,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1347 reverse */
t4=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2909 in k2901 in k2913 in k2866 in k2860 in loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[110]+1);
/* g383384 */
t3=t2;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,lf[111]);}

/* k2905 in k2901 in k2913 in k2866 in k2860 in loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1345 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2882 in k2913 in k2866 in k2860 in loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2888,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2892,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[112],((C_word*)t0)[2]);
/* posixwin.scm: 1344 reverse */
t5=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k2890 in k2882 in k2913 in k2866 in k2860 in loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[110]+1);
/* g383384 */
t3=t2;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,lf[111]);}

/* k2886 in k2882 in k2913 in k2866 in k2860 in loop in k2851 in k2844 in canonical-path in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1342 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cwd in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2783,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2787,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a2791 in cwd in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2792,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2798,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2816,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a2815 in a2791 in cwd in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a2827 in a2815 in a2791 in cwd in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2828r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2828r(t0,t1,t2);}}

static void C_ccall f_2828r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2834,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k399404 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a2833 in a2827 in a2815 in a2791 in cwd in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2834,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2821 in a2815 in a2791 in cwd in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
/* posixwin.scm: 1295 cw */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a2797 in a2791 in cwd in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2798,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2804,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k399404 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a2803 in a2797 in a2791 in cwd in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2804,2,t0,t1);}
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[2],lf[105]))){
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[106]);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[106]);}}

/* k2785 in cwd in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g402403 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* current-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2723r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2723r(t0,t1,t2);}}

static void C_ccall f_2723r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
/* posixwin.scm: 1273 change-directory */
t5=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2736,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1274 make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}}

/* k2734 in current-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2736,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2739,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1276 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2737 in k2734 in current-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1278 ##sys#substring */
t2=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1279 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[35],lf[95],lf[98]);}}

/* directory? in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2696,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[96]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2703,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2717,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2721,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1266 ##sys#expand-home-path */
t7=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k2719 in directory? in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1266 ##sys#platform-fixup-pathname */
t2=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2715 in directory? in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1265 ##sys#file-info */
t2=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2701 in directory? in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_2539r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2539r(t0,t1,t2);}}

static void C_ccall f_2539r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2642,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2647,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec286328 */
t6=t5;
f_2647(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?287326 */
t8=t4;
f_2642(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body284292 */
t10=t3;
f_2541(t10,t1,t6,t8);}}}

/* def-spec286 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2647(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2647,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2655,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1236 current-directory */
t3=*((C_word*)lf[95]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2653 in def-spec286 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?287326 */
t2=((C_word*)t0)[3];
f_2642(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?287 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2642(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2642,NULL,3,t0,t1,t2);}
/* body284292 */
t3=((C_word*)t0)[2];
f_2541(t3,t1,t2,C_SCHEME_FALSE);}

/* body284 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2541(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2541,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[92]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2548,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1238 make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}

/* k2546 in body284 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2551,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1239 ##sys#make-pointer */
t3=*((C_word*)lf[94]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2549 in k2546 in body284 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1240 ##sys#make-pointer */
t3=*((C_word*)lf[94]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2552 in k2549 in k2546 in body284 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2641,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1241 ##sys#expand-home-path */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k2639 in k2552 in k2549 in k2546 in body284 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1241 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2556 in k2552 in k2549 in k2546 in body284 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2567,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1244 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2575(t6,((C_word*)t0)[6]);}}

/* loop in k2556 in k2552 in k2549 in k2546 in body284 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2575,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1253 ##sys#substring */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k2583 in loop in k2556 in k2552 in k2549 in k2546 in body284 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2585,2,t0,t1);}
t2=(C_word)C_subchar(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_subchar(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2597,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_2597(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
if(C_truep(t8)){
t9=(C_word)C_eqp(((C_word*)t0)[5],C_fix(2));
t10=t5;
f_2597(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}
else{
t9=t5;
f_2597(t9,(C_word)C_i_not(((C_word*)t0)[2]));}}}
else{
t7=t5;
f_2597(t7,C_SCHEME_FALSE);}}

/* k2595 in k2583 in loop in k2556 in k2552 in k2549 in k2546 in body284 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2597,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1260 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2575(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1261 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2575(t3,t2);}}

/* k2605 in k2595 in k2583 in loop in k2556 in k2552 in k2549 in k2546 in body284 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2607,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2565 in k2556 in k2552 in k2549 in k2546 in body284 in directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1245 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[92],lf[93],((C_word*)t0)[2]);}

/* delete-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2514,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2521,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2537,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1226 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2535 in delete-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1226 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2519 in delete-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2524,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(0),(C_word)C_rmdir(t1));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2530,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1228 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2528 in k2519 in delete-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1229 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[89],lf[90],((C_word*)t0)[2]);}

/* k2522 in k2519 in delete-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2489,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2512,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1216 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2510 in change-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1216 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2494 in change-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2499,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(0),(C_word)C_chdir(t1));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1218 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2503 in k2494 in change-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1219 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[87],lf[88],((C_word*)t0)[2]);}

/* k2497 in k2494 in change-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2339(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2339r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2339r(t0,t1,t2,t3);}}

static void C_ccall f_2339r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[81]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2349,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1207 ##sys#expand-home-path */
t8=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2352,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t1;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2357,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1196 string-split */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[86]);}
else{
t3=t1;
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2472,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1179 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k2470 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2472,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1180 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2462 in k2470 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1181 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[81],lf[82],((C_word*)t0)[2]);}

/* k2355 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_slot(t1,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2369,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2369(t9,((C_word*)t0)[2],t5);}

/* loop217 in k2355 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2369(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2369,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2377,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2439,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g224225 */
t6=t3;
f_2377(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2437 in loop217 in k2355 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2369(t3,((C_word*)t0)[2],t2);}

/* g224 in loop217 in k2355 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2377(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2377,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2382,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1200 string-append */
t4=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[84],t2);}

/* k2380 in g224 in loop217 in k2355 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2382,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
t4=((C_word*)((C_word*)t0)[3])[1];
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2411,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2395,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1185 file-exists? */
t7=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}

/* k2393 in k2380 in g224 in loop217 in k2355 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2398,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1186 ##sys#file-info */
t3=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2411(t2,C_SCHEME_FALSE);}}

/* k2396 in k2393 in k2380 in g224 in loop217 in k2355 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
f_2411(t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
f_2411(t2,C_SCHEME_FALSE);}}

/* k2409 in k2380 in g224 in loop217 in k2355 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2411,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1179 ##sys#make-c-string */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k2428 in k2409 in k2380 in g224 in loop217 in k2355 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1180 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2420 in k2428 in k2409 in k2380 in g224 in loop217 in k2355 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1181 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[81],lf[82],((C_word*)t0)[2]);}

/* k2350 in k2347 in create-directory in k2335 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* set-file-position! in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2277r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2277r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2277r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[73]);
t8=(C_word)C_i_check_exact_2(t6,lf[73]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2290,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_negativep(t3))){
/* posixwin.scm: 1149 ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[78],lf[73],lf[79],t3,t2);}
else{
t10=t9;
f_2290(2,t10,C_SCHEME_UNDEFINED);}}

/* k2288 in set-file-position! in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2302,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1150 port? */
t4=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k2300 in k2288 in set-file-position! in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[75]);
if(C_truep(t3)){
t4=(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
f_2296(2,t5,t4);}
else{
t4=((C_word*)t0)[2];
f_2296(2,t4,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2296(2,t3,t2);}
else{
/* posixwin.scm: 1156 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[44],lf[73],lf[76],((C_word*)t0)[5]);}}}

/* k2294 in k2288 in set-file-position! in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixwin.scm: 1157 posix-error */
t2=lf[3];
f_1899(7,t2,((C_word*)t0)[4],lf[35],lf[73],lf[74],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f6406 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f6406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f6406,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[72]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* f6412 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f6412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f6412,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* f6418 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f6418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f6418,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[70]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* f6424 in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f6424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f6424,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[69]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* symbolic-link? in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2248,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[68]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2225,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[66]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2232,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2246,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1126 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2244 in regular-file? in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1126 ##sys#file-info */
t2=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2230 in regular-file? in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2219,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2223,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1122 ##sys#stat */
f_2129(t3,t2);}

/* k2221 in file-permissions in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2213,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2217,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1121 ##sys#stat */
f_2129(t3,t2);}

/* k2215 in file-owner in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2207,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2211,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1120 ##sys#stat */
f_2129(t3,t2);}

/* k2209 in file-change-time in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2211,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2201,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2205,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1119 ##sys#stat */
f_2129(t3,t2);}

/* k2203 in file-access-time in k2197 in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2205,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-size in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2191,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2195,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1102 ##sys#stat */
f_2129(t3,t2);}

/* k2193 in file-size in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2167r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2167r(t0,t1,t2,t3);}}

static void C_ccall f_2167r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2174,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1096 ##sys#stat */
f_2129(t6,t2);}

/* k2172 in file-stat in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2174,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_fcall f_2129(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2129,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2133,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2133(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2158,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2162,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1089 ##sys#expand-home-path */
t6=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1090 ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[44],lf[58],t2);}}}

/* k2160 in ##sys#stat in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1089 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2156 in ##sys#stat in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_stat(t1);
t3=((C_word*)t0)[2];
f_2133(2,t3,t2);}

/* k2131 in ##sys#stat in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2133,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1092 ##sys#update-errno */
t3=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2140 in k2131 in ##sys#stat in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1093 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[35],lf[57],((C_word*)t0)[2]);}

/* file-mkstemp in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2091,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[50]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1058 ##sys#make-c-string */
t5=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2096 in file-mkstemp in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2101,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1060 string-length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k2099 in k2096 in file-mkstemp in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1062 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2104(2,t4,C_SCHEME_UNDEFINED);}}

/* k2119 in k2099 in k2096 in file-mkstemp in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1063 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[50],lf[52],((C_word*)t0)[2]);}

/* k2102 in k2099 in k2096 in file-mkstemp in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1064 ##sys#substring */
t4=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2109 in k2102 in k2099 in k2096 in file-mkstemp in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1064 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2049r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2049r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2049r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[46]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2056,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_byteblockp(t3))){
t7=t6;
f_2056(2,t7,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1045 ##sys#signal-hook */
t7=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[44],lf[46],lf[48],t3);}}
else{
/* posixwin.scm: 1045 ##sys#signal-hook */
t7=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[44],lf[46],lf[48],t3);}}

/* k2054 in file-write in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[46]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2065,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2071,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1050 ##sys#update-errno */
t9=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t5);}}

/* k2069 in k2054 in file-write in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1051 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[46],lf[47],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2063 in k2054 in file-write in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2004r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2004r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2004r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[42]);
t6=(C_word)C_i_check_exact_2(t3,lf[42]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2014,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_2014(2,t8,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixwin.scm: 1032 make-string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k2012 in file-read in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(t1))){
if(C_truep((C_word)C_byteblockp(t1))){
t3=t2;
f_2017(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1034 ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[44],lf[42],lf[45],t1);}}
else{
/* posixwin.scm: 1034 ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[44],lf[42],lf[45],t1);}}

/* k2015 in k2012 in file-read in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2020,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1037 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2));}}

/* k2027 in k2015 in k2012 in file-read in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1038 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[35],lf[42],lf[43],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2018 in k2015 in k2012 in file-read in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1986,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[39]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1999,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1024 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1997 in file-close in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1025 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[35],lf[39],lf[40],((C_word*)t0)[2]);}

/* file-open in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1945r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1945r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1945r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[34]);
t8=(C_word)C_i_check_exact_2(t3,lf[34]);
t9=(C_word)C_i_check_exact_2(t6,lf[34]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1962,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1978,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1014 ##sys#expand-home-path */
t12=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k1976 in file-open in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1014 ##sys#make-c-string */
t2=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1960 in file-open in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1965,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1016 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k1969 in k1960 in file-open in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1017 ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[35],lf[34],lf[36],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1963 in k1960 in file-open in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1899r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1899r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1899r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1903,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 945  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1901 in posix-error in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1910,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub12(t4,t1),C_fix(0));}

/* k1912 in k1901 in posix-error in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 946  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k1908 in k1901 in posix-error in k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1872 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[463] = {
{"toplevel:posixwin_scm",(void*)C_posix_toplevel},
{"f_1874:posixwin_scm",(void*)f_1874},
{"f_1877:posixwin_scm",(void*)f_1877},
{"f_1880:posixwin_scm",(void*)f_1880},
{"f_1883:posixwin_scm",(void*)f_1883},
{"f_1886:posixwin_scm",(void*)f_1886},
{"f_1889:posixwin_scm",(void*)f_1889},
{"f_1892:posixwin_scm",(void*)f_1892},
{"f_5770:posixwin_scm",(void*)f_5770},
{"f_5802:posixwin_scm",(void*)f_5802},
{"f_5783:posixwin_scm",(void*)f_5783},
{"f_5789:posixwin_scm",(void*)f_5789},
{"f_5764:posixwin_scm",(void*)f_5764},
{"f_5768:posixwin_scm",(void*)f_5768},
{"f_2199:posixwin_scm",(void*)f_2199},
{"f_5727:posixwin_scm",(void*)f_5727},
{"f_5743:posixwin_scm",(void*)f_5743},
{"f_5731:posixwin_scm",(void*)f_5731},
{"f_5734:posixwin_scm",(void*)f_5734},
{"f_2337:posixwin_scm",(void*)f_2337},
{"f_3478:posixwin_scm",(void*)f_3478},
{"f_5708:posixwin_scm",(void*)f_5708},
{"f_5705:posixwin_scm",(void*)f_5705},
{"f_5698:posixwin_scm",(void*)f_5698},
{"f_5692:posixwin_scm",(void*)f_5692},
{"f_5686:posixwin_scm",(void*)f_5686},
{"f_5680:posixwin_scm",(void*)f_5680},
{"f_5674:posixwin_scm",(void*)f_5674},
{"f_5668:posixwin_scm",(void*)f_5668},
{"f_5662:posixwin_scm",(void*)f_5662},
{"f_5656:posixwin_scm",(void*)f_5656},
{"f_5650:posixwin_scm",(void*)f_5650},
{"f_5644:posixwin_scm",(void*)f_5644},
{"f_5638:posixwin_scm",(void*)f_5638},
{"f_5632:posixwin_scm",(void*)f_5632},
{"f_5626:posixwin_scm",(void*)f_5626},
{"f_5620:posixwin_scm",(void*)f_5620},
{"f_5614:posixwin_scm",(void*)f_5614},
{"f_5608:posixwin_scm",(void*)f_5608},
{"f_5602:posixwin_scm",(void*)f_5602},
{"f_5596:posixwin_scm",(void*)f_5596},
{"f_5590:posixwin_scm",(void*)f_5590},
{"f_5584:posixwin_scm",(void*)f_5584},
{"f_5578:posixwin_scm",(void*)f_5578},
{"f_5572:posixwin_scm",(void*)f_5572},
{"f_5566:posixwin_scm",(void*)f_5566},
{"f_5560:posixwin_scm",(void*)f_5560},
{"f_5554:posixwin_scm",(void*)f_5554},
{"f_5548:posixwin_scm",(void*)f_5548},
{"f_5542:posixwin_scm",(void*)f_5542},
{"f_5536:posixwin_scm",(void*)f_5536},
{"f_5530:posixwin_scm",(void*)f_5530},
{"f_5524:posixwin_scm",(void*)f_5524},
{"f_5518:posixwin_scm",(void*)f_5518},
{"f_5512:posixwin_scm",(void*)f_5512},
{"f_5506:posixwin_scm",(void*)f_5506},
{"f_5500:posixwin_scm",(void*)f_5500},
{"f_5494:posixwin_scm",(void*)f_5494},
{"f_5488:posixwin_scm",(void*)f_5488},
{"f_5482:posixwin_scm",(void*)f_5482},
{"f_5476:posixwin_scm",(void*)f_5476},
{"f_5470:posixwin_scm",(void*)f_5470},
{"f_5464:posixwin_scm",(void*)f_5464},
{"f_5458:posixwin_scm",(void*)f_5458},
{"f_5452:posixwin_scm",(void*)f_5452},
{"f_5446:posixwin_scm",(void*)f_5446},
{"f_5203:posixwin_scm",(void*)f_5203},
{"f_5380:posixwin_scm",(void*)f_5380},
{"f_5386:posixwin_scm",(void*)f_5386},
{"f_5375:posixwin_scm",(void*)f_5375},
{"f_5370:posixwin_scm",(void*)f_5370},
{"f_5205:posixwin_scm",(void*)f_5205},
{"f_5357:posixwin_scm",(void*)f_5357},
{"f_5365:posixwin_scm",(void*)f_5365},
{"f_5212:posixwin_scm",(void*)f_5212},
{"f_5345:posixwin_scm",(void*)f_5345},
{"f_5339:posixwin_scm",(void*)f_5339},
{"f_5222:posixwin_scm",(void*)f_5222},
{"f_5224:posixwin_scm",(void*)f_5224},
{"f_5243:posixwin_scm",(void*)f_5243},
{"f_5325:posixwin_scm",(void*)f_5325},
{"f_5332:posixwin_scm",(void*)f_5332},
{"f_5319:posixwin_scm",(void*)f_5319},
{"f_5258:posixwin_scm",(void*)f_5258},
{"f_5312:posixwin_scm",(void*)f_5312},
{"f_5309:posixwin_scm",(void*)f_5309},
{"f_5299:posixwin_scm",(void*)f_5299},
{"f_5275:posixwin_scm",(void*)f_5275},
{"f_5297:posixwin_scm",(void*)f_5297},
{"f_5283:posixwin_scm",(void*)f_5283},
{"f_5290:posixwin_scm",(void*)f_5290},
{"f_5287:posixwin_scm",(void*)f_5287},
{"f_5270:posixwin_scm",(void*)f_5270},
{"f_5268:posixwin_scm",(void*)f_5268},
{"f_5346:posixwin_scm",(void*)f_5346},
{"f_5188:posixwin_scm",(void*)f_5188},
{"f_5198:posixwin_scm",(void*)f_5198},
{"f_5157:posixwin_scm",(void*)f_5157},
{"f_5183:posixwin_scm",(void*)f_5183},
{"f_5168:posixwin_scm",(void*)f_5168},
{"f_5172:posixwin_scm",(void*)f_5172},
{"f_5176:posixwin_scm",(void*)f_5176},
{"f_5180:posixwin_scm",(void*)f_5180},
{"f_5145:posixwin_scm",(void*)f_5145},
{"f_5142:posixwin_scm",(void*)f_5142},
{"f_5085:posixwin_scm",(void*)f_5085},
{"f_5109:posixwin_scm",(void*)f_5109},
{"f_5119:posixwin_scm",(void*)f_5119},
{"f_5103:posixwin_scm",(void*)f_5103},
{"f_5073:posixwin_scm",(void*)f_5073},
{"f_4996:posixwin_scm",(void*)f_4996},
{"f_5013:posixwin_scm",(void*)f_5013},
{"f_5008:posixwin_scm",(void*)f_5008},
{"f_5003:posixwin_scm",(void*)f_5003},
{"f_4998:posixwin_scm",(void*)f_4998},
{"f_4919:posixwin_scm",(void*)f_4919},
{"f_4936:posixwin_scm",(void*)f_4936},
{"f_4931:posixwin_scm",(void*)f_4931},
{"f_4926:posixwin_scm",(void*)f_4926},
{"f_4921:posixwin_scm",(void*)f_4921},
{"f_4857:posixwin_scm",(void*)f_4857},
{"f_4913:posixwin_scm",(void*)f_4913},
{"f_4917:posixwin_scm",(void*)f_4917},
{"f_4878:posixwin_scm",(void*)f_4878},
{"f_4881:posixwin_scm",(void*)f_4881},
{"f_4892:posixwin_scm",(void*)f_4892},
{"f_4886:posixwin_scm",(void*)f_4886},
{"f_4859:posixwin_scm",(void*)f_4859},
{"f_4868:posixwin_scm",(void*)f_4868},
{"f_4759:posixwin_scm",(void*)f_4759},
{"f_4838:posixwin_scm",(void*)f_4838},
{"f_4766:posixwin_scm",(void*)f_4766},
{"f_4806:posixwin_scm",(void*)f_4806},
{"f_4810:posixwin_scm",(void*)f_4810},
{"f_4814:posixwin_scm",(void*)f_4814},
{"f_4818:posixwin_scm",(void*)f_4818},
{"f_4822:posixwin_scm",(void*)f_4822},
{"f_4713:posixwin_scm",(void*)f_4713},
{"f_4717:posixwin_scm",(void*)f_4717},
{"f_4799:posixwin_scm",(void*)f_4799},
{"f_4779:posixwin_scm",(void*)f_4779},
{"f_4783:posixwin_scm",(void*)f_4783},
{"f_4787:posixwin_scm",(void*)f_4787},
{"f_4679:posixwin_scm",(void*)f_4679},
{"f_4696:posixwin_scm",(void*)f_4696},
{"f_4700:posixwin_scm",(void*)f_4700},
{"f_4673:posixwin_scm",(void*)f_4673},
{"f_4652:posixwin_scm",(void*)f_4652},
{"f_4656:posixwin_scm",(void*)f_4656},
{"f_4668:posixwin_scm",(void*)f_4668},
{"f_4649:posixwin_scm",(void*)f_4649},
{"f_4565:posixwin_scm",(void*)f_4565},
{"f_4589:posixwin_scm",(void*)f_4589},
{"f_4584:posixwin_scm",(void*)f_4584},
{"f_4579:posixwin_scm",(void*)f_4579},
{"f_4567:posixwin_scm",(void*)f_4567},
{"f_4571:posixwin_scm",(void*)f_4571},
{"f_4481:posixwin_scm",(void*)f_4481},
{"f_4505:posixwin_scm",(void*)f_4505},
{"f_4500:posixwin_scm",(void*)f_4500},
{"f_4495:posixwin_scm",(void*)f_4495},
{"f_4483:posixwin_scm",(void*)f_4483},
{"f_4487:posixwin_scm",(void*)f_4487},
{"f_4466:posixwin_scm",(void*)f_4466},
{"f_4470:posixwin_scm",(void*)f_4470},
{"f_4430:posixwin_scm",(void*)f_4430},
{"f_4437:posixwin_scm",(void*)f_4437},
{"f_4440:posixwin_scm",(void*)f_4440},
{"f_4457:posixwin_scm",(void*)f_4457},
{"f_4443:posixwin_scm",(void*)f_4443},
{"f_4446:posixwin_scm",(void*)f_4446},
{"f_4453:posixwin_scm",(void*)f_4453},
{"f_4380:posixwin_scm",(void*)f_4380},
{"f_4392:posixwin_scm",(void*)f_4392},
{"f_4411:posixwin_scm",(void*)f_4411},
{"f_4374:posixwin_scm",(void*)f_4374},
{"f_4368:posixwin_scm",(void*)f_4368},
{"f_4289:posixwin_scm",(void*)f_4289},
{"f_4332:posixwin_scm",(void*)f_4332},
{"f_4363:posixwin_scm",(void*)f_4363},
{"f_4360:posixwin_scm",(void*)f_4360},
{"f_4294:posixwin_scm",(void*)f_4294},
{"f_4298:posixwin_scm",(void*)f_4298},
{"f_4303:posixwin_scm",(void*)f_4303},
{"f_4327:posixwin_scm",(void*)f_4327},
{"f_4316:posixwin_scm",(void*)f_4316},
{"f_4172:posixwin_scm",(void*)f_4172},
{"f_4178:posixwin_scm",(void*)f_4178},
{"f_4199:posixwin_scm",(void*)f_4199},
{"f_4278:posixwin_scm",(void*)f_4278},
{"f_4203:posixwin_scm",(void*)f_4203},
{"f_4206:posixwin_scm",(void*)f_4206},
{"f_4213:posixwin_scm",(void*)f_4213},
{"f_4215:posixwin_scm",(void*)f_4215},
{"f_4232:posixwin_scm",(void*)f_4232},
{"f_4236:posixwin_scm",(void*)f_4236},
{"f_4244:posixwin_scm",(void*)f_4244},
{"f_4248:posixwin_scm",(void*)f_4248},
{"f_4193:posixwin_scm",(void*)f_4193},
{"f_4113:posixwin_scm",(void*)f_4113},
{"f_4117:posixwin_scm",(void*)f_4117},
{"f_4123:posixwin_scm",(void*)f_4123},
{"f_4132:posixwin_scm",(void*)f_4132},
{"f_4107:posixwin_scm",(void*)f_4107},
{"f_4111:posixwin_scm",(void*)f_4111},
{"f_4091:posixwin_scm",(void*)f_4091},
{"f_4083:posixwin_scm",(void*)f_4083},
{"f_4068:posixwin_scm",(void*)f_4068},
{"f_4072:posixwin_scm",(void*)f_4072},
{"f_4008:posixwin_scm",(void*)f_4008},
{"f_4015:posixwin_scm",(void*)f_4015},
{"f_4037:posixwin_scm",(void*)f_4037},
{"f_4034:posixwin_scm",(void*)f_4034},
{"f_4024:posixwin_scm",(void*)f_4024},
{"f_3957:posixwin_scm",(void*)f_3957},
{"f_3961:posixwin_scm",(void*)f_3961},
{"f_3964:posixwin_scm",(void*)f_3964},
{"f_3925:posixwin_scm",(void*)f_3925},
{"f_3929:posixwin_scm",(void*)f_3929},
{"f_3898:posixwin_scm",(void*)f_3898},
{"f_3902:posixwin_scm",(void*)f_3902},
{"f_3879:posixwin_scm",(void*)f_3879},
{"f_3813:posixwin_scm",(void*)f_3813},
{"f_3819:posixwin_scm",(void*)f_3819},
{"f_3823:posixwin_scm",(void*)f_3823},
{"f_3831:posixwin_scm",(void*)f_3831},
{"f_3857:posixwin_scm",(void*)f_3857},
{"f_3861:posixwin_scm",(void*)f_3861},
{"f_3849:posixwin_scm",(void*)f_3849},
{"f_3798:posixwin_scm",(void*)f_3798},
{"f_3806:posixwin_scm",(void*)f_3806},
{"f_3781:posixwin_scm",(void*)f_3781},
{"f_3792:posixwin_scm",(void*)f_3792},
{"f_3796:posixwin_scm",(void*)f_3796},
{"f_3751:posixwin_scm",(void*)f_3751},
{"f_3758:posixwin_scm",(void*)f_3758},
{"f_3767:posixwin_scm",(void*)f_3767},
{"f_3761:posixwin_scm",(void*)f_3761},
{"f_3716:posixwin_scm",(void*)f_3716},
{"f_3720:posixwin_scm",(void*)f_3720},
{"f_3749:posixwin_scm",(void*)f_3749},
{"f_3735:posixwin_scm",(void*)f_3735},
{"f_3729:posixwin_scm",(void*)f_3729},
{"f_3702:posixwin_scm",(void*)f_3702},
{"f_3714:posixwin_scm",(void*)f_3714},
{"f_3688:posixwin_scm",(void*)f_3688},
{"f_3700:posixwin_scm",(void*)f_3700},
{"f_3670:posixwin_scm",(void*)f_3670},
{"f_3674:posixwin_scm",(void*)f_3674},
{"f_3686:posixwin_scm",(void*)f_3686},
{"f_3633:posixwin_scm",(void*)f_3633},
{"f_3641:posixwin_scm",(void*)f_3641},
{"f_3624:posixwin_scm",(void*)f_3624},
{"f_3618:posixwin_scm",(void*)f_3618},
{"f_3612:posixwin_scm",(void*)f_3612},
{"f_3588:posixwin_scm",(void*)f_3588},
{"f_3610:posixwin_scm",(void*)f_3610},
{"f_3606:posixwin_scm",(void*)f_3606},
{"f_3598:posixwin_scm",(void*)f_3598},
{"f_3558:posixwin_scm",(void*)f_3558},
{"f_3586:posixwin_scm",(void*)f_3586},
{"f_3582:posixwin_scm",(void*)f_3582},
{"f_3574:posixwin_scm",(void*)f_3574},
{"f_3502:posixwin_scm",(void*)f_3502},
{"f_3512:posixwin_scm",(void*)f_3512},
{"f_3489:posixwin_scm",(void*)f_3489},
{"f_3480:posixwin_scm",(void*)f_3480},
{"f_3411:posixwin_scm",(void*)f_3411},
{"f_3427:posixwin_scm",(void*)f_3427},
{"f_3418:posixwin_scm",(void*)f_3418},
{"f_3391:posixwin_scm",(void*)f_3391},
{"f_3395:posixwin_scm",(void*)f_3395},
{"f_3401:posixwin_scm",(void*)f_3401},
{"f_3405:posixwin_scm",(void*)f_3405},
{"f_3371:posixwin_scm",(void*)f_3371},
{"f_3375:posixwin_scm",(void*)f_3375},
{"f_3381:posixwin_scm",(void*)f_3381},
{"f_3385:posixwin_scm",(void*)f_3385},
{"f_3347:posixwin_scm",(void*)f_3347},
{"f_3351:posixwin_scm",(void*)f_3351},
{"f_3362:posixwin_scm",(void*)f_3362},
{"f_3366:posixwin_scm",(void*)f_3366},
{"f_3356:posixwin_scm",(void*)f_3356},
{"f_3323:posixwin_scm",(void*)f_3323},
{"f_3327:posixwin_scm",(void*)f_3327},
{"f_3338:posixwin_scm",(void*)f_3338},
{"f_3342:posixwin_scm",(void*)f_3342},
{"f_3332:posixwin_scm",(void*)f_3332},
{"f_3304:posixwin_scm",(void*)f_3304},
{"f_3308:posixwin_scm",(void*)f_3308},
{"f_3311:posixwin_scm",(void*)f_3311},
{"f_3268:posixwin_scm",(void*)f_3268},
{"f_3299:posixwin_scm",(void*)f_3299},
{"f_3289:posixwin_scm",(void*)f_3289},
{"f_3282:posixwin_scm",(void*)f_3282},
{"f_3232:posixwin_scm",(void*)f_3232},
{"f_3263:posixwin_scm",(void*)f_3263},
{"f_3253:posixwin_scm",(void*)f_3253},
{"f_3246:posixwin_scm",(void*)f_3246},
{"f_3214:posixwin_scm",(void*)f_3214},
{"f_3218:posixwin_scm",(void*)f_3218},
{"f_3230:posixwin_scm",(void*)f_3230},
{"f_2839:posixwin_scm",(void*)f_2839},
{"f_3186:posixwin_scm",(void*)f_3186},
{"f_2985:posixwin_scm",(void*)f_2985},
{"f_3172:posixwin_scm",(void*)f_3172},
{"f_3161:posixwin_scm",(void*)f_3161},
{"f_3168:posixwin_scm",(void*)f_3168},
{"f_3015:posixwin_scm",(void*)f_3015},
{"f_3154:posixwin_scm",(void*)f_3154},
{"f_3133:posixwin_scm",(void*)f_3133},
{"f_3150:posixwin_scm",(void*)f_3150},
{"f_3139:posixwin_scm",(void*)f_3139},
{"f_3146:posixwin_scm",(void*)f_3146},
{"f_3057:posixwin_scm",(void*)f_3057},
{"f_3130:posixwin_scm",(void*)f_3130},
{"f_3109:posixwin_scm",(void*)f_3109},
{"f_3126:posixwin_scm",(void*)f_3126},
{"f_3115:posixwin_scm",(void*)f_3115},
{"f_3122:posixwin_scm",(void*)f_3122},
{"f_3063:posixwin_scm",(void*)f_3063},
{"f_3106:posixwin_scm",(void*)f_3106},
{"f_3102:posixwin_scm",(void*)f_3102},
{"f_3095:posixwin_scm",(void*)f_3095},
{"f_3091:posixwin_scm",(void*)f_3091},
{"f_3070:posixwin_scm",(void*)f_3070},
{"f_3074:posixwin_scm",(void*)f_3074},
{"f_3051:posixwin_scm",(void*)f_3051},
{"f_3038:posixwin_scm",(void*)f_3038},
{"f_3022:posixwin_scm",(void*)f_3022},
{"f_3026:posixwin_scm",(void*)f_3026},
{"f_3030:posixwin_scm",(void*)f_3030},
{"f_3009:posixwin_scm",(void*)f_3009},
{"f_2996:posixwin_scm",(void*)f_2996},
{"f_2992:posixwin_scm",(void*)f_2992},
{"f_2979:posixwin_scm",(void*)f_2979},
{"f_2846:posixwin_scm",(void*)f_2846},
{"f_2965:posixwin_scm",(void*)f_2965},
{"f_2853:posixwin_scm",(void*)f_2853},
{"f_2855:posixwin_scm",(void*)f_2855},
{"f_2862:posixwin_scm",(void*)f_2862},
{"f_2937:posixwin_scm",(void*)f_2937},
{"f_2946:posixwin_scm",(void*)f_2946},
{"f_2868:posixwin_scm",(void*)f_2868},
{"f_2915:posixwin_scm",(void*)f_2915},
{"f_2903:posixwin_scm",(void*)f_2903},
{"f_2911:posixwin_scm",(void*)f_2911},
{"f_2907:posixwin_scm",(void*)f_2907},
{"f_2884:posixwin_scm",(void*)f_2884},
{"f_2892:posixwin_scm",(void*)f_2892},
{"f_2888:posixwin_scm",(void*)f_2888},
{"f_2783:posixwin_scm",(void*)f_2783},
{"f_2792:posixwin_scm",(void*)f_2792},
{"f_2816:posixwin_scm",(void*)f_2816},
{"f_2828:posixwin_scm",(void*)f_2828},
{"f_2834:posixwin_scm",(void*)f_2834},
{"f_2822:posixwin_scm",(void*)f_2822},
{"f_2798:posixwin_scm",(void*)f_2798},
{"f_2804:posixwin_scm",(void*)f_2804},
{"f_2787:posixwin_scm",(void*)f_2787},
{"f_2723:posixwin_scm",(void*)f_2723},
{"f_2736:posixwin_scm",(void*)f_2736},
{"f_2739:posixwin_scm",(void*)f_2739},
{"f_2696:posixwin_scm",(void*)f_2696},
{"f_2721:posixwin_scm",(void*)f_2721},
{"f_2717:posixwin_scm",(void*)f_2717},
{"f_2703:posixwin_scm",(void*)f_2703},
{"f_2539:posixwin_scm",(void*)f_2539},
{"f_2647:posixwin_scm",(void*)f_2647},
{"f_2655:posixwin_scm",(void*)f_2655},
{"f_2642:posixwin_scm",(void*)f_2642},
{"f_2541:posixwin_scm",(void*)f_2541},
{"f_2548:posixwin_scm",(void*)f_2548},
{"f_2551:posixwin_scm",(void*)f_2551},
{"f_2554:posixwin_scm",(void*)f_2554},
{"f_2641:posixwin_scm",(void*)f_2641},
{"f_2558:posixwin_scm",(void*)f_2558},
{"f_2575:posixwin_scm",(void*)f_2575},
{"f_2585:posixwin_scm",(void*)f_2585},
{"f_2597:posixwin_scm",(void*)f_2597},
{"f_2607:posixwin_scm",(void*)f_2607},
{"f_2567:posixwin_scm",(void*)f_2567},
{"f_2514:posixwin_scm",(void*)f_2514},
{"f_2537:posixwin_scm",(void*)f_2537},
{"f_2521:posixwin_scm",(void*)f_2521},
{"f_2530:posixwin_scm",(void*)f_2530},
{"f_2524:posixwin_scm",(void*)f_2524},
{"f_2489:posixwin_scm",(void*)f_2489},
{"f_2512:posixwin_scm",(void*)f_2512},
{"f_2496:posixwin_scm",(void*)f_2496},
{"f_2505:posixwin_scm",(void*)f_2505},
{"f_2499:posixwin_scm",(void*)f_2499},
{"f_2339:posixwin_scm",(void*)f_2339},
{"f_2349:posixwin_scm",(void*)f_2349},
{"f_2472:posixwin_scm",(void*)f_2472},
{"f_2464:posixwin_scm",(void*)f_2464},
{"f_2357:posixwin_scm",(void*)f_2357},
{"f_2369:posixwin_scm",(void*)f_2369},
{"f_2439:posixwin_scm",(void*)f_2439},
{"f_2377:posixwin_scm",(void*)f_2377},
{"f_2382:posixwin_scm",(void*)f_2382},
{"f_2395:posixwin_scm",(void*)f_2395},
{"f_2398:posixwin_scm",(void*)f_2398},
{"f_2411:posixwin_scm",(void*)f_2411},
{"f_2430:posixwin_scm",(void*)f_2430},
{"f_2422:posixwin_scm",(void*)f_2422},
{"f_2352:posixwin_scm",(void*)f_2352},
{"f_2277:posixwin_scm",(void*)f_2277},
{"f_2290:posixwin_scm",(void*)f_2290},
{"f_2302:posixwin_scm",(void*)f_2302},
{"f_2296:posixwin_scm",(void*)f_2296},
{"f6406:posixwin_scm",(void*)f6406},
{"f6412:posixwin_scm",(void*)f6412},
{"f6418:posixwin_scm",(void*)f6418},
{"f6424:posixwin_scm",(void*)f6424},
{"f_2248:posixwin_scm",(void*)f_2248},
{"f_2225:posixwin_scm",(void*)f_2225},
{"f_2246:posixwin_scm",(void*)f_2246},
{"f_2232:posixwin_scm",(void*)f_2232},
{"f_2219:posixwin_scm",(void*)f_2219},
{"f_2223:posixwin_scm",(void*)f_2223},
{"f_2213:posixwin_scm",(void*)f_2213},
{"f_2217:posixwin_scm",(void*)f_2217},
{"f_2207:posixwin_scm",(void*)f_2207},
{"f_2211:posixwin_scm",(void*)f_2211},
{"f_2201:posixwin_scm",(void*)f_2201},
{"f_2205:posixwin_scm",(void*)f_2205},
{"f_2191:posixwin_scm",(void*)f_2191},
{"f_2195:posixwin_scm",(void*)f_2195},
{"f_2167:posixwin_scm",(void*)f_2167},
{"f_2174:posixwin_scm",(void*)f_2174},
{"f_2129:posixwin_scm",(void*)f_2129},
{"f_2162:posixwin_scm",(void*)f_2162},
{"f_2158:posixwin_scm",(void*)f_2158},
{"f_2133:posixwin_scm",(void*)f_2133},
{"f_2142:posixwin_scm",(void*)f_2142},
{"f_2091:posixwin_scm",(void*)f_2091},
{"f_2098:posixwin_scm",(void*)f_2098},
{"f_2101:posixwin_scm",(void*)f_2101},
{"f_2121:posixwin_scm",(void*)f_2121},
{"f_2104:posixwin_scm",(void*)f_2104},
{"f_2111:posixwin_scm",(void*)f_2111},
{"f_2049:posixwin_scm",(void*)f_2049},
{"f_2056:posixwin_scm",(void*)f_2056},
{"f_2071:posixwin_scm",(void*)f_2071},
{"f_2065:posixwin_scm",(void*)f_2065},
{"f_2004:posixwin_scm",(void*)f_2004},
{"f_2014:posixwin_scm",(void*)f_2014},
{"f_2017:posixwin_scm",(void*)f_2017},
{"f_2029:posixwin_scm",(void*)f_2029},
{"f_2020:posixwin_scm",(void*)f_2020},
{"f_1986:posixwin_scm",(void*)f_1986},
{"f_1999:posixwin_scm",(void*)f_1999},
{"f_1945:posixwin_scm",(void*)f_1945},
{"f_1978:posixwin_scm",(void*)f_1978},
{"f_1962:posixwin_scm",(void*)f_1962},
{"f_1971:posixwin_scm",(void*)f_1971},
{"f_1965:posixwin_scm",(void*)f_1965},
{"f_1899:posixwin_scm",(void*)f_1899},
{"f_1903:posixwin_scm",(void*)f_1903},
{"f_1914:posixwin_scm",(void*)f_1914},
{"f_1910:posixwin_scm",(void*)f_1910},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
