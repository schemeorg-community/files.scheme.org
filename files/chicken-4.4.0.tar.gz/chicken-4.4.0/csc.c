/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: csc.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -output-file csc.c
   used units: library eval data_structures ports srfi_1 srfi_13 utils files extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[422];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_988)
static void C_ccall f_988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5621)
static void C_ccall f5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5298)
static void C_ccall f5298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5617)
static void C_ccall f5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5293)
static void C_ccall f5293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1084)
static void C_ccall f_1084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5288)
static void C_ccall f5288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5283)
static void C_ccall f5283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5278)
static void C_ccall f5278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5273)
static void C_ccall f5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1096)
static void C_ccall f_1096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5268)
static void C_ccall f5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5263)
static void C_ccall f5263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_fcall f_1127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4371)
static void C_ccall f_4371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1145)
static void C_ccall f_1145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5613)
static void C_ccall f5613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5258)
static void C_ccall f5258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_fcall f_1186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5609)
static void C_ccall f5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5253)
static void C_ccall f5253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_fcall f_1195(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_fcall f_1216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1412)
static void C_fcall f_1412(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_fcall f_2014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_fcall f_2215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_fcall f_2457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_fcall f_2460(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_fcall f_2463(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_fcall f_2519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_fcall f_2528(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2750)
static void C_ccall f_2750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_fcall f_2788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_fcall f_2606(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_fcall f_2639(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static C_word C_fcall f_2470(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_fcall f_1823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_ccall f_1699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5244)
static void C_ccall f5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1430)
static void C_ccall f_1430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_fcall f_1566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_fcall f_1569(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_fcall f_2989(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5238)
static void C_ccall f5238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5233)
static void C_ccall f5233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_fcall f_3040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_fcall f_3050(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_fcall f_2966(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1436)
static void C_fcall f_1436(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_fcall f_3171(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_fcall f_3179(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5216)
static void C_ccall f5216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5211)
static void C_ccall f5211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3136)
static void C_ccall f_3136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_fcall f_3144(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1482)
static void C_ccall f_1482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5204)
static void C_ccall f5204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5199)
static void C_ccall f5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_fcall f_3575(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5192)
static void C_ccall f5192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5187)
static void C_ccall f5187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5182)
static void C_ccall f5182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5177)
static void C_ccall f5177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_ccall f_3511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5172)
static void C_ccall f5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5167)
static void C_ccall f5167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_fcall f_3381(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5162)
static void C_ccall f5162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3400)
static void C_ccall f_3400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5157)
static void C_ccall f5157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4138)
static void C_ccall f_4138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5152)
static void C_ccall f5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_fcall f_3345(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_fcall f_3313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_fcall f_3321(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static C_word C_fcall f_1395(C_word *a);
C_noret_decl(f_1369)
static void C_fcall f_1369(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1374)
static void C_ccall f_1374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_fcall f_1330(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_fcall f_1323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4093)
static void C_fcall f_4093(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_fcall f_3960(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3990)
static void C_fcall f_3990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_fcall f_3864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_fcall f_3883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3812)
static void C_fcall f_3812(C_word t0) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_fcall f_3827(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_fcall f_3715(C_word t0) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3730)
static void C_fcall f_3730(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_fcall f_3771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_fcall f_3675(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5133)
static void C_ccall f5133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5128)
static void C_ccall f5128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_fcall f_3626(C_word t0) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_fcall f_3238(C_word t0) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_fcall f_3252(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_fcall f_1022(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1127)
static void C_fcall trf_1127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1127(t0,t1);}

C_noret_decl(trf_1186)
static void C_fcall trf_1186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1186(t0,t1);}

C_noret_decl(trf_1195)
static void C_fcall trf_1195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1195(t0,t1);}

C_noret_decl(trf_1216)
static void C_fcall trf_1216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1216(t0,t1);}

C_noret_decl(trf_1412)
static void C_fcall trf_1412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1412(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1412(t0,t1,t2);}

C_noret_decl(trf_2014)
static void C_fcall trf_2014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2014(t0,t1);}

C_noret_decl(trf_2215)
static void C_fcall trf_2215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2215(t0,t1);}

C_noret_decl(trf_2457)
static void C_fcall trf_2457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2457(t0,t1);}

C_noret_decl(trf_2460)
static void C_fcall trf_2460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2460(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2460(t0,t1);}

C_noret_decl(trf_2463)
static void C_fcall trf_2463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2463(t0,t1);}

C_noret_decl(trf_2519)
static void C_fcall trf_2519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2519(t0,t1);}

C_noret_decl(trf_2528)
static void C_fcall trf_2528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2528(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2528(t0,t1);}

C_noret_decl(trf_2788)
static void C_fcall trf_2788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2788(t0,t1);}

C_noret_decl(trf_2606)
static void C_fcall trf_2606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2606(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2606(t0,t1);}

C_noret_decl(trf_2639)
static void C_fcall trf_2639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2639(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2639(t0,t1,t2);}

C_noret_decl(trf_1823)
static void C_fcall trf_1823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1823(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1823(t0,t1);}

C_noret_decl(trf_1566)
static void C_fcall trf_1566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1566(t0,t1);}

C_noret_decl(trf_1569)
static void C_fcall trf_1569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1569(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1569(t0,t1);}

C_noret_decl(trf_2989)
static void C_fcall trf_2989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2989(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2989(t0,t1,t2);}

C_noret_decl(trf_3040)
static void C_fcall trf_3040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3040(t0,t1);}

C_noret_decl(trf_3050)
static void C_fcall trf_3050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3050(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3050(t0,t1,t2);}

C_noret_decl(trf_2966)
static void C_fcall trf_2966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2966(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2966(t0,t1,t2);}

C_noret_decl(trf_1436)
static void C_fcall trf_1436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1436(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1436(t0,t1);}

C_noret_decl(trf_3171)
static void C_fcall trf_3171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3171(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3171(t0,t1,t2);}

C_noret_decl(trf_3179)
static void C_fcall trf_3179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3179(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3179(t0,t1,t2);}

C_noret_decl(trf_3144)
static void C_fcall trf_3144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3144(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3144(t0,t1,t2);}

C_noret_decl(trf_3575)
static void C_fcall trf_3575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3575(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3575(t0,t1,t2);}

C_noret_decl(trf_3381)
static void C_fcall trf_3381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3381(t0,t1);}

C_noret_decl(trf_3345)
static void C_fcall trf_3345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3345(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3345(t0,t1);}

C_noret_decl(trf_3313)
static void C_fcall trf_3313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3313(t0,t1);}

C_noret_decl(trf_3321)
static void C_fcall trf_3321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3321(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3321(t0,t1,t2);}

C_noret_decl(trf_1369)
static void C_fcall trf_1369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1369(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1369(t0,t1);}

C_noret_decl(trf_1330)
static void C_fcall trf_1330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1330(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1330(t0,t1,t2,t3);}

C_noret_decl(trf_1323)
static void C_fcall trf_1323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1323(t0,t1);}

C_noret_decl(trf_4093)
static void C_fcall trf_4093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4093(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4093(t0,t1);}

C_noret_decl(trf_3960)
static void C_fcall trf_3960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3960(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3960(t0,t1,t2);}

C_noret_decl(trf_3990)
static void C_fcall trf_3990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3990(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3990(t0,t1);}

C_noret_decl(trf_3864)
static void C_fcall trf_3864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3864(t0,t1);}

C_noret_decl(trf_3883)
static void C_fcall trf_3883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3883(t0,t1);}

C_noret_decl(trf_3812)
static void C_fcall trf_3812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3812(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3812(t0);}

C_noret_decl(trf_3827)
static void C_fcall trf_3827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3827(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3827(t0,t1);}

C_noret_decl(trf_3715)
static void C_fcall trf_3715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3715(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3715(t0);}

C_noret_decl(trf_3730)
static void C_fcall trf_3730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3730(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3730(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3771)
static void C_fcall trf_3771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3771(t0,t1);}

C_noret_decl(trf_3675)
static void C_fcall trf_3675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3675(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3675(t0,t1,t2);}

C_noret_decl(trf_3626)
static void C_fcall trf_3626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3626(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3626(t0);}

C_noret_decl(trf_3238)
static void C_fcall trf_3238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3238(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3238(t0);}

C_noret_decl(trf_3252)
static void C_fcall trf_3252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3252(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3252(t0,t1,t2);}

C_noret_decl(trf_1022)
static void C_fcall trf_1022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1022(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1022(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2728)){
C_save(t1);
C_rereclaim2(2728*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,422);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"mingw32");
lf[4]=C_h_intern(&lf[4],4,"msvc");
lf[6]=C_h_intern(&lf[6],6,"macosx");
lf[9]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005linux\376\003\000\000\002\376\001\000\000\007freebsd\376\003\000\000\002\376\001\000\000\007solaris\376\003\000\000\002\376\001\000\000\007openbsd\376\377\016");
lf[12]=C_h_intern(&lf[12],4,"exit");
lf[13]=C_h_intern(&lf[13],7,"fprintf");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\010~a: ~\077~%");
lf[15]=C_h_intern(&lf[15],17,"\003syspeek-c-string");
lf[16]=C_h_intern(&lf[16],18,"current-error-port");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[23]=C_h_intern(&lf[23],2,"qs");
lf[24]=C_h_intern(&lf[24],18,"normalize-pathname");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\003obj");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\005-out:");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\003-Fo");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[47]=C_h_intern(&lf[47],26,"\003sysload-dynamic-extension");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[102]=C_h_intern(&lf[102],18,"string-intersperse");
lf[104]=C_h_intern(&lf[104],6,"append");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[107]=C_h_intern(&lf[107],13,"make-pathname");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[111]=C_h_intern(&lf[111],17,"get-output-string");
lf[112]=C_h_intern(&lf[112],7,"display");
lf[113]=C_h_intern(&lf[113],19,"\003syswrite-char/port");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\007copy /Y");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\002cp");
lf[116]=C_h_intern(&lf[116],18,"open-output-string");
lf[118]=C_h_intern(&lf[118],7,"reverse");
lf[119]=C_h_intern(&lf[119],6,"static");
lf[120]=C_h_intern(&lf[120],14,"static-options");
lf[121]=C_h_intern(&lf[121],21,"extension-information");
lf[122]=C_h_intern(&lf[122],15,"repository-path");
lf[124]=C_h_intern(&lf[124],13,"string-append");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[128]=C_h_intern(&lf[128],9,"\003syserror");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[133]=C_h_intern(&lf[133],17,"string-translate*");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[135]=C_h_intern(&lf[135],16,"\003syslist->string");
lf[136]=C_h_intern(&lf[136],5,"cons*");
lf[137]=C_h_intern(&lf[137],16,"\003sysstring->list");
lf[138]=C_h_intern(&lf[138],10,"string-any");
lf[139]=C_h_intern(&lf[139],6,"char=\077");
lf[141]=C_h_intern(&lf[141],19,"\003sysstandard-output");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[143]=C_h_intern(&lf[143],5,"write");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000;\012Error: shell command terminated with non-zero exit status ");
lf[145]=C_h_intern(&lf[145],6,"system");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[148]=C_h_intern(&lf[148],5,"print");
lf[150]=C_h_intern(&lf[150],11,"delete-file");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[152]=C_h_intern(&lf[152],25,"\003sysimplicit-exit-handler");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\004-dll");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\026-DC_PRIVATE_REPOSITORY");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\031-framework CoreFoundation");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\032</string>\012</dict>\012</plist>");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\001\262<\077xml version=\0421.0\042 encoding=\042UTF-8\042\077>\012<!DOCTYPE plist SYSTEM \042file://local"
"host/System/Library/DTDs/PropertyList.dtd\042>\012<plist version=\0420.9\042>\012<dict>\012\011<key>C"
"FBundlePackageType</key>\012\011<string>APPL</string>\012\011<key>CFBundleIconFile</key>\012\011<s"
"tring>CHICKEN.icns</string>\012        <key>CFBundleGetInfoString</key>\012\011<string>Cr"
"eated by CHICKEN</string>\012\011<key>CFBundleSignature</key>\012\011<string>\077\077\077\077</string>\012\011"
"<key>CFBundleExecutable</key>\012\011<string>");
lf[165]=C_h_intern(&lf[165],19,"\003sysprint-to-string");
lf[166]=C_h_intern(&lf[166],19,"with-output-to-file");
lf[167]=C_h_intern(&lf[167],12,"file-exists\077");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\012Info.plist");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\024chicken/CHICKEN.icns");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\014CHICKEN.icns");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\022Contents/Resources");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\010Contents");
lf[174]=C_h_intern(&lf[174],13,"pathname-file");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\013libuchicken");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\012libchicken");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\005dylib");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\003dll");
lf[179]=C_h_intern(&lf[179],4,"conc");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\003so.");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\005mac.r");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000 /Developer/Tools/Rez -t APPL -o ");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\001u");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\035install_name_tool -change lib");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\016chicken.dylib ");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\021libuchicken.dylib");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\020libchicken.dylib");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\020@executable_path");
lf[192]=C_h_intern(&lf[192],16,"create-directory");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\006mkdir ");
lf[194]=C_h_intern(&lf[194],17,"directory-exists\077");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\017Contents/MacOS/");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\022Contents/Resources");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\011mkdir -p ");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\011mkdir -p ");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\003app");
lf[201]=C_h_intern(&lf[201],24,"pathname-strip-extension");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\004.old");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\004move");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\002mv");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\005.old\047");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\030\047 - renaming source to `");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: output file will overwrite source file `");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[209]=C_h_intern(&lf[209],26,"pathname-replace-extension");
lf[210]=C_h_intern(&lf[210],4,"last");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[213]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[219]=C_h_intern(&lf[219],7,"newline");
lf[220]=C_h_intern(&lf[220],6,"print*");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\010 -Wl,-R\042");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\010\134$ORIGIN");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[230]=C_h_intern(&lf[230],5,"-help");
lf[231]=C_h_intern(&lf[231],6,"--help");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\003\047.\012");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\0471\047 is a driver program for the CHICKEN compiler. Files given on the\012  comman"
"d line are translated, compiled or linked as needed.\012\012  FILENAME is a Scheme sou"
"rce file name with optional extension or a\012  C/C++/Objective-C source, object or"
" library file name with extension. OPTION\012  may be one of the following:\012\012  Gene"
"ral options:\012\012    -h  -help                      display this text and exit\012    "
"-v                             show intermediate compilation stages\012    -vv  -ve"
"rbose                  display information about translation\012                   "
"                 progress\012    -vvv                           display information"
" about all compilation\012                                    stages\012    -V  -versi"
"on                   display Scheme compiler version and exit\012    -release      "
"                 display release number and exit\012\012  File and pathname options:\012\012"
"    -o -output-file FILENAME       specifies target executable name\012    -I -incl"
"ude-path PATHNAME      specifies alternative path for included\012                 "
"                   files\012    -to-stdout                     write compiler to st"
"dout (implies -t)\012    -s -shared -dynamic            generate dynamically loadab"
"le shared object\012                                    file\012\012  Language options:\012\012"
"    -D  -DSYMBOL  -feature SYMBOL  register feature identifier\012    -c++         "
"                  compile via a C++ source file (.cpp) \012    -objc               "
"           compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012"
"    -i -case-insensitive           don\047t preserve case of read symbols    \012    -"
"k  -keyword-style STYLE       enable alternative keyword-syntax\012                "
"                    (prefix, suffix or none)\012        -no-parentheses-synonyms   "
"disables list delimiter synonyms\012        -no-symbol-escape          disables sup"
"port for escaped symbols\012        -r5rs-syntax               disables the Chicken"
" extensions to\012                                    R5RS syntax\012    -compile-synt"
"ax                macros are made available at run-time\012    -j -emit-import-libr"
"ary MODULE write compile-time module information into\012                          "
"          separate file\012    -J -emit-all-import-libraries  emit import-libraries"
" for all defined modules\012    -no-compiler-syntax            disable expansion of"
" compiler-macros\012\012  Translation options:\012\012    -x  -explicit-use              do "
"not use units `library\047 and `eval\047 by\012                                    defaul"
"t\012    -P  -check-syntax              stop compilation after macro-expansion\012    "
"-A  -analyze-only              stop compilation after first analysis pass\012\012  Deb"
"ugging options:\012\012    -w  -no-warnings               disable warnings\012    -disabl"
"e-warning CLASS         disable specific class of warnings\012    -d0 -d1 -d2 -debu"
"g-level NUMBER\012                                   set level of available debuggi"
"ng information\012    -no-trace                      disable rudimentary debugging "
"information\012    -profile                       executable emits profiling inform"
"ation \012    -accumulate-profile            executable emits profiling information"
" in\012                                    append mode\012    -profile-name FILENAME  "
"       name of the generated profile information\012                               "
"     file\012    -S  -scrutinize                perform local flow analysis\012    -ty"
"pes FILENAME                load additional type database\012\012  Optimization option"
"s:\012\012    -O -O1 -O2 -O3 -O4 -O5 -optimize-level NUMBER\012                          "
"         enable certain sets of optimization options\012    -optimize-leaf-routines"
"        enable leaf routine optimization\012    -N  -no-usual-integrations     stan"
"dard procedures may be redefined\012    -u  -unsafe                    disable safe"
"ty checks\012    -local                         assume globals are only modified in"
" current\012                                    file\012    -b  -block                "
"     enable block-compilation\012    -disable-interrupts            disable interru"
"pts in compiled code\012    -f  -fixnum-arithmetic         assume all numbers are f"
"ixnums\012    -lambda-lift                   perform lambda-lifting\012    -unsafe-lib"
"raries              link with unsafe runtime system\012    -disable-stack-overflow-"
"checks disables detection of stack-overflows\012    -inline                        "
"enable inlining\012    -inline-limit                  set inlining threshold\012    -i"
"nline-global                 enable cross-module inlining\012    -unboxing         "
"             use unboxed temporaries if possible\012    -n -emit-inline-file FILENA"
"ME  generate file with globally inlinable\012                                    pr"
"ocedures (implies -inline -local)\012    -consult-inline-file FILENAME  explicitly "
"load inline file\012    -no-argc-checks                disable argument count check"
"s\012    -no-bound-checks               disable bound variable checks\012    -no-proce"
"dure-checks           disable procedure call checks\012    -no-procedure-checks-for"
"-usual-bindings\012                                   disable procedure call checks"
" only for usual\012                                    bindings\012\012  Configuration op"
"tions:\012\012    -unit NAME                     compile file as a library unit\012    -u"
"ses NAME                     declare library unit as used.\012    -heap-size NUMBER"
"              specifies heap-size of compiled executable\012    -heap-initial-size "
"NUMBER      specifies heap-size at startup time\012    -heap-growth PERCENTAGE     "
"   specifies growth-rate of expanding heap\012    -heap-shrinkage PERCENTAGE     sp"
"ecifies shrink-rate of contracting heap\012    -nursery NUMBER  -stack-size NUMBER\012"
"                                   specifies nursery size of compiled\012          "
"                         executable\012    -X -extend FILENAME            load file"
" before compilation commences\012    -prelude EXPRESSION            add expression "
"to beginning of source file\012    -postlude EXPRESSION           add expression to"
" end of source file\012    -prologue FILENAME             include file before main "
"source file\012    -epilogue FILENAME             include file after main source fi"
"le\012\012    -e  -embedded                  compile as embedded\012                     "
"               (don\047t generate `main()\047)\012    -gui                           comp"
"ile as GUI application\012    -R  -require-extension NAME    require extension and "
"import in compiled\012                                    code\012    -dll -library   "
"               compile multiple units into a dynamic\012                           "
"         library\012    -deploy                        deploy self-contained applic"
"ation bundle\012\012  Options to other passes:\012\012    -C OPTION                      pas"
"s option to C compiler\012    -L OPTION                      pass option to linker\012"
"    -I<DIR>                        pass \134\042-I<DIR>\134\042 to C compiler\012              "
"                      (add include path)\012    -L<DIR>                        pass"
" \134\042-L<DIR>\134\042 to linker\012                                    (add library path)\012  "
"  -k                             keep intermediate files\012    -c                 "
"            stop after compilation to object files\012    -t                       "
"      stop after translation to C\012    -cc COMPILER                   select othe"
"r C compiler than the default\012    -cxx COMPILER                  select other C+"
"+ compiler than the default\012    -ld COMPILER                   select other link"
"er than the default \012    -lLIBNAME                      link with given library\012"
"                                    (`libLIBNAME\047 on UNIX,\012                     "
"                `LIBNAME.lib\047 on Windows)\012    -static-libs                   lin"
"k with static CHICKEN libraries\012    -static                        generate comp"
"letely statically linked\012                                    executable\012    -sta"
"tic-extension NAME         link extension NAME statically\012                      "
"              (if available)\012    -F<DIR>                        pass \134\042-F<DIR>\134\042"
" to C compiler\012                                    (add framework header path on"
" Mac OS X)\012    -framework NAME                passed to linker on Mac OS X\012    -"
"rpath PATHNAME                add directory to runtime library search path\012    -"
"Wl,...                        pass linker options\012    -strip                    "
"     strip resulting binary\012\012  Inquiry options:\012\012    -home                      "
"    show home-directory (where support files go)\012    -cflags                    "
"    show required C-compiler flags and exit\012    -ldflags                       s"
"how required linker flags and exit\012    -libs                          show requi"
"red libraries and exit\012    -cc-name                       show name of default C"
" compiler used\012    -cxx-name                      show name of default C++ compi"
"ler used\012    -ld-name                       show name of default linker used\012   "
" -dry-run                       just show commands executed, don\047t run them\012    "
"                                (implies `-v\047)\012\012  Obscure options:\012\012    -debug M"
"ODES                   display debugging output for the given modes\012    -compile"
"r PATHNAME             use other compiler than default `chicken\047\012    -raw       "
"                    do not generate implicit init- and exit code\012    -emit-exter"
"nal-prototypes-first\012                                   emit prototypes for call"
"backs before foreign\012                                    declarations\012    -ignor"
"e-repository             do not refer to repository for extensions\012    -keep-sha"
"dowed-macros          do not remove shadowed macro\012    -host                    "
"      compile for host when configured for\012                                    c"
"ross-compiling\012    -private-repository            load extensions from executabl"
"e path\012    -deployed                      compile support file to be used from a"
" deployed \012                                    executable\012\012  Options can be coll"
"apsed if unambiguous, so\012\012    -vkfO\012\012  is the same as\012\012    -v -k -fixnum-arithme"
"tic -optimize\012\012  The contents of the environment variable CSC_OPTIONS are implic"
"itly passed to\012  every invocation of `");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\033 FILENAME | OPTION ...\012\012  `");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\007Usage: ");
lf[236]=C_h_intern(&lf[236],8,"-release");
lf[237]=C_h_intern(&lf[237],15,"chicken-version");
lf[238]=C_h_intern(&lf[238],8,"-version");
lf[239]=C_h_intern(&lf[239],7,"sprintf");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[241]=C_h_intern(&lf[241],4,"-c++");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[243]=C_h_intern(&lf[243],5,"-objc");
lf[244]=C_h_intern(&lf[244],7,"-static");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[247]=C_h_intern(&lf[247],12,"-static-libs");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[250]=C_h_intern(&lf[250],7,"-cflags");
lf[251]=C_h_intern(&lf[251],8,"-ldflags");
lf[252]=C_h_intern(&lf[252],8,"-cc-name");
lf[253]=C_h_intern(&lf[253],9,"-cxx-name");
lf[254]=C_h_intern(&lf[254],8,"-ld-name");
lf[255]=C_h_intern(&lf[255],5,"-home");
lf[256]=C_h_intern(&lf[256],5,"-libs");
lf[257]=C_h_intern(&lf[257],2,"-v");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\010-VERBOSE");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[263]=C_h_intern(&lf[263],2,"-w");
lf[264]=C_h_intern(&lf[264],12,"-no-warnings");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[267]=C_h_intern(&lf[267],2,"-A");
lf[268]=C_h_intern(&lf[268],13,"-analyze-only");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[270]=C_h_intern(&lf[270],2,"-P");
lf[271]=C_h_intern(&lf[271],13,"-check-syntax");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[273]=C_h_intern(&lf[273],2,"-k");
lf[274]=C_h_intern(&lf[274],2,"-c");
lf[275]=C_h_intern(&lf[275],2,"-t");
lf[276]=C_h_intern(&lf[276],2,"-e");
lf[277]=C_h_intern(&lf[277],9,"-embedded");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[279]=C_h_intern(&lf[279],18,"-require-extension");
lf[280]=C_h_intern(&lf[280],2,"-R");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[282]=C_h_intern(&lf[282],17,"-static-extension");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\021-static-extension");
lf[284]=C_h_intern(&lf[284],19,"-private-repository");
lf[285]=C_h_intern(&lf[285],4,"-gui");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\007-DC_GUI");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\014kernel32.lib");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\012user32.lib");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\011gdi32.lib");
lf[294]=C_h_intern(&lf[294],7,"-deploy");
lf[295]=C_h_intern(&lf[295],9,"-deployed");
lf[296]=C_h_intern(&lf[296],10,"-framework");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[298]=C_h_intern(&lf[298],2,"-o");
lf[299]=C_h_intern(&lf[299],2,"-O");
lf[300]=C_h_intern(&lf[300],3,"-O1");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[303]=C_h_intern(&lf[303],3,"-O2");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[306]=C_h_intern(&lf[306],3,"-O3");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[309]=C_h_intern(&lf[309],3,"-O4");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\0014");
lf[312]=C_h_intern(&lf[312],3,"-O5");
lf[313]=C_h_intern(&lf[313],6,"cygwin");
lf[314]=C_h_intern(&lf[314],3,"gnu");
lf[315]=C_h_intern(&lf[315],5,"clang");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\003-O3");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\024-fomit-frame-pointer");
lf[318]=C_h_intern(&lf[318],14,"build-platform");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\021-unsafe-libraries");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\0015");
lf[322]=C_h_intern(&lf[322],3,"-d0");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[325]=C_h_intern(&lf[325],3,"-d1");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[328]=C_h_intern(&lf[328],3,"-d2");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[331]=C_h_intern(&lf[331],8,"-dry-run");
lf[332]=C_h_intern(&lf[332],2,"-s");
lf[333]=C_h_intern(&lf[333],4,"-dll");
lf[334]=C_h_intern(&lf[334],8,"-library");
lf[335]=C_h_intern(&lf[335],9,"-compiler");
lf[336]=C_h_intern(&lf[336],3,"-cc");
lf[337]=C_h_intern(&lf[337],4,"-cxx");
lf[338]=C_h_intern(&lf[338],3,"-ld");
lf[339]=C_h_intern(&lf[339],2,"-I");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[341]=C_h_intern(&lf[341],2,"-C");
lf[342]=C_h_intern(&lf[342],12,"string-split");
lf[343]=C_h_intern(&lf[343],6,"-strip");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[345]=C_h_intern(&lf[345],2,"-L");
lf[346]=C_h_intern(&lf[346],17,"-unsafe-libraries");
lf[347]=C_h_intern(&lf[347],6,"-rpath");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[349]=C_h_intern(&lf[349],5,"-host");
lf[350]=C_h_intern(&lf[350],1,"-");
lf[351]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-S\376\003\000\000\002\376B\000\000\013-scrutinize\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-feature\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensi"
"tive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-e"
"xtend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-N\376\003\000\000\002\376B\000\000\026-no-usual-integrations\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-J\376\003\000"
"\000\002\376B\000\000\032-emit-all-import-libraries\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-j\376\003\000\000\002\376B\000\000\024-emit-import-libr"
"ary\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-n\376\003\000\000\002\376B\000\000\021-emit-inline-file\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-b\376\003\000\000\002\376B\000\000\006"
"-block\376\377\016\376\377\016");
lf[354]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000\000\017-compile-syntax\376\003\000\000\002\376\001\000"
"\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\010-dynamic\376\003\000\000\002\376\001\000\000\036-disable-stac"
"k-overflow-checks\376\003\000\000\002\376\001\000\000\006-local\376\003\000\000\002\376\001\000\000\037-emit-external-prototypes-first\376\003\000\000\002\376"
"\001\000\000\007-inline\376\003\000\000\002\376\001\000\000\010-release\376\003\000\000\002\376\001\000\000\013-scrutinize\376\003\000\000\002\376\001\000\000\015-analyze-only\376\003\000\000\002\376\001"
"\000\000\025-keep-shadowed-macros\376\003\000\000\002\376\001\000\000\016-inline-global\376\003\000\000\002\376\001\000\000\022-ignore-repository\376\003\000\000"
"\002\376\001\000\000\021-no-symbol-escape\376\003\000\000\002\376\001\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376\001\000\000\014-r5rs-syntax\376"
"\003\000\000\002\376\001\000\000\017-no-argc-checks\376\003\000\000\002\376\001\000\000\020-no-bound-checks\376\003\000\000\002\376\001\000\000\024-no-procedure-checks"
"\376\003\000\000\002\376\001\000\000\023-no-compiler-syntax\376\003\000\000\002\376\001\000\000\032-emit-all-import-libraries\376\003\000\000\002\376\001\000\000\013-setu"
"p-mode\376\003\000\000\002\376\001\000\000\011-unboxing\376\003\000\000\002\376\001\000\000\047-no-procedure-checks-for-usual-bindings\376\377\016");
lf[355]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\014-output-file\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000"
"\002\376\001\000\000\013-stack-size\376\003\000\000\002\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-key"
"word-style\376\003\000\000\002\376\001\000\000\017-optimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-si"
"ze\376\003\000\000\002\376\001\000\000\007-extend\376\003\000\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002"
"\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\020-disable-w"
"arning\376\003\000\000\002\376\001\000\000\021-emit-inline-file\376\003\000\000\002\376\001\000\000\006-types\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000\002\376\001\000\000\014-de"
"bug-level\376\003\000\000\002\376\001\000\000\014-heap-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap-initial-"
"size\376\003\000\000\002\376\001\000\000\024-consult-inline-file\376\003\000\000\002\376\001\000\000\024-emit-import-library\376\003\000\000\002\376\001\000\000\021-stati"
"c-extension\376\377\016");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[357]=C_h_intern(&lf[357],9,"substring");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[360]=C_h_intern(&lf[360],15,"lset-difference");
lf[361]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000S\376\003\000\000\002\376\377\012\000\000J\376\377\016");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[364]=C_h_intern(&lf[364],18,"decompose-pathname");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[379]=C_h_intern(&lf[379],15,"-optimize-level");
lf[380]=C_h_intern(&lf[380],15,"-benchmark-mode");
lf[381]=C_h_intern(&lf[381],10,"-to-stdout");
lf[382]=C_h_intern(&lf[382],7,"-unsafe");
lf[383]=C_h_intern(&lf[383],7,"-shared");
lf[384]=C_h_intern(&lf[384],8,"-dynamic");
lf[385]=C_h_intern(&lf[385],8,"-windows");
lf[386]=C_h_intern(&lf[386],2,"-W");
lf[387]=C_h_intern(&lf[387],14,"string->symbol");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[389]=C_h_intern(&lf[389],24,"get-environment-variable");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\003-I\042");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[398]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-luchicken\376\377\016");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[402]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011-lchicken\376\377\016");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\023libuchicken-static.");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\022libchicken-static.");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[409]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[410]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[411]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[412]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[419]=C_h_intern(&lf[419],22,"command-line-arguments");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[421]=C_h_intern(&lf[421],16,"software-version");
C_register_lf2(lf,422,create_ptable());
t2=C_mutate(&lf[0] /* (set! c57 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_976,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k974 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_979,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k977 in k974 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_982,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k980 in k977 in k974 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_985,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k983 in k980 in k977 in k974 */
static void C_ccall f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_988,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_994,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_997,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1000,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4480,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 63   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[318]))(2,*((C_word*)lf[318]+1),t2);}

/* k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4480,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3] /* (set! mingw ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4476,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 64   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[318]))(2,*((C_word*)lf[318]+1),t4);}

/* k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4476,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[4]);
t3=C_mutate(&lf[5] /* (set! msvc ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 65   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[421]))(2,*((C_word*)lf[421]+1),t4);}

/* k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4472,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[6]);
t3=C_mutate(&lf[7] /* (set! osx ...) */,t2);
t4=lf[3];
t5=(C_truep(lf[3])?lf[3]:C_retrieve2(lf[5],"msvc"));
t6=C_mutate(&lf[8] /* (set! win ...) */,t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 69   software-version */
((C_proc2)C_retrieve_symbol_proc(lf[421]))(2,*((C_word*)lf[421]+1),t7);}

/* k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
t2=(C_word)C_i_memq(t1,lf[9]);
t3=C_mutate(&lf[10] /* (set! elf ...) */,t2);
t4=C_mutate(&lf[11] /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1022,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 75   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[389]))(3,*((C_word*)lf[389]+1),t5,lf[420]);}

/* k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1041,2,t0,t1);}
t2=C_mutate(&lf[17] /* (set! chicken-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 76   command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[419]))(2,*((C_word*)lf[419]+1),t3);}

/* k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
t2=C_mutate(&lf[18] /* (set! arguments ...) */,t1);
t3=(C_word)C_i_member(lf[19],C_retrieve2(lf[18],"arguments"));
t4=C_mutate(&lf[20] /* (set! host-mode ...) */,t3);
t5=(C_word)C_fudge(C_fix(39));
t6=C_mutate(&lf[21] /* (set! cross-chicken ...) */,t5);
t7=C_mutate(&lf[22] /* (set! quotewrap ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1068,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1080,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4454,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4458,a[2]=t8,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t11=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t11=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k4456 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4458,2,t0,t1);}
if(C_truep(C_retrieve2(lf[17],"chicken-prefix"))){
t2=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[17],"chicken-prefix"),lf[417]);
/* csc.scm: 82   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],t2,lf[418]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5621,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}}

/* f5621 in k4456 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k4452 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5298 in k4452 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1080,2,t0,t1);}
t2=C_mutate(&lf[25] /* (set! home ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1084,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4438,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4442,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4446,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}

/* k4444 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4450,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k4448 in k4444 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 95   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4440 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
if(C_truep(C_retrieve2(lf[17],"chicken-prefix"))){
t2=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[17],"chicken-prefix"),lf[415]);
/* csc.scm: 82   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],t2,lf[416]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}}

/* f5617 in k4440 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k4436 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5293,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5293 in k4436 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1084,2,t0,t1);}
t2=C_mutate(&lf[26] /* (set! translator ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4428,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k4426 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5288 in k4426 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1088,2,t0,t1);}
t2=C_mutate(&lf[27] /* (set! compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1092,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4418,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k4416 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5283,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5283 in k4416 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1092,2,t0,t1);}
t2=C_mutate(&lf[28] /* (set! c++-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1096,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4405,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5278,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t5,lf[414]);}
else{
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}}

/* f5278 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k4403 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5273,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5273 in k4403 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1096,2,t0,t1);}
t2=C_mutate(&lf[29] /* (set! linker ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4392,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5268,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t5,lf[413]);}
else{
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}}

/* f5268 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k4390 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5263,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5263 in k4390 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1100,2,t0,t1);}
t2=C_mutate(&lf[30] /* (set! c++-linker ...) */,t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[31]:lf[32]);
t4=C_mutate(&lf[33] /* (set! object-extension ...) */,t3);
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[34]:lf[35]);
t6=C_mutate(&lf[36] /* (set! library-extension ...) */,t5);
t7=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[37]:lf[38]);
t8=C_mutate(&lf[39] /* (set! link-output-flag ...) */,t7);
t9=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[40]:lf[41]);
t10=C_mutate(&lf[42] /* (set! executable-extension ...) */,t9);
t11=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[43]:lf[44]);
t12=C_mutate(&lf[45] /* (set! compile-output-flag ...) */,t11);
t13=C_mutate(&lf[46] /* (set! shared-library-extension ...) */,C_retrieve(lf[47]));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t15=lf[3];
if(C_truep(lf[3])){
t16=lf[3];
t17=t14;
f_1127(t17,(C_truep(lf[3])?lf[409]:lf[410]));}
else{
t16=C_retrieve2(lf[5],"msvc");
t17=t14;
f_1127(t17,(C_truep(C_retrieve2(lf[5],"msvc"))?lf[411]:lf[412]));}}

/* k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1127,NULL,2,t0,t1);}
t2=C_mutate(&lf[48] /* (set! pic-options ...) */,t1);
t3=C_mutate(&lf[49] /* (set! windows-shell ...) */,C_mk_bool(C_WINDOWS_SHELL));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1132,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
/* csc.scm: 115  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t4,lf[407],C_retrieve2(lf[36],"library-extension"));}
else{
/* csc.scm: 115  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t4,lf[408],C_retrieve2(lf[36],"library-extension"));}}

/* k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
t2=C_mutate(&lf[50] /* (set! default-library ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
/* csc.scm: 120  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t3,lf[405],C_retrieve2(lf[36],"library-extension"));}
else{
/* csc.scm: 120  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t3,lf[406],C_retrieve2(lf[36],"library-extension"));}}

/* k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1136,2,t0,t1);}
t2=C_mutate(&lf[51] /* (set! default-unsafe-library ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4371,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k4369 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 124  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[342]))(3,*((C_word*)lf[342]+1),((C_word*)t0)[2],t1);}

/* k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
t2=C_mutate(&lf[52] /* (set! default-compilation-optimization-options ...) */,t1);
t3=C_mutate(&lf[53] /* (set! best-compilation-optimization-options ...) */,C_retrieve2(lf[52],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1145,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4361,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k4359 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 126  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[342]))(3,*((C_word*)lf[342]+1),((C_word*)t0)[2],t1);}

/* k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1145,2,t0,t1);}
t2=C_mutate(&lf[54] /* (set! default-linking-optimization-options ...) */,t1);
t3=C_mutate(&lf[55] /* (set! best-linking-optimization-options ...) */,C_retrieve2(lf[54],"default-linking-optimization-options"));
t4=lf[56] /* scheme-files */ =C_SCHEME_END_OF_LIST;;
t5=lf[57] /* c-files */ =C_SCHEME_END_OF_LIST;;
t6=lf[58] /* generated-c-files */ =C_SCHEME_END_OF_LIST;;
t7=lf[59] /* object-files */ =C_SCHEME_END_OF_LIST;;
t8=lf[60] /* generated-object-files */ =C_SCHEME_END_OF_LIST;;
t9=lf[61] /* cpp-mode */ =C_SCHEME_FALSE;;
t10=lf[62] /* objc-mode */ =C_SCHEME_FALSE;;
t11=lf[63] /* embedded */ =C_SCHEME_FALSE;;
t12=lf[64] /* inquiry-only */ =C_SCHEME_FALSE;;
t13=lf[65] /* show-cflags */ =C_SCHEME_FALSE;;
t14=lf[66] /* show-ldflags */ =C_SCHEME_FALSE;;
t15=lf[67] /* show-libs */ =C_SCHEME_FALSE;;
t16=lf[68] /* dry-run */ =C_SCHEME_FALSE;;
t17=lf[69] /* gui */ =C_SCHEME_FALSE;;
t18=lf[70] /* deploy */ =C_SCHEME_FALSE;;
t19=lf[71] /* deployed */ =C_SCHEME_FALSE;;
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1174,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t21=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t20,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t21=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t20,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1174,2,t0,t1);}
t2=C_mutate(&lf[72] /* (set! extra-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1178,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1178,2,t0,t1);}
t2=C_mutate(&lf[73] /* (set! extra-shared-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4327,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4331,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4335,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k4333 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4339,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 207  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t2,lf[404],C_retrieve2(lf[50],"default-library"));}

/* k4337 in k4333 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 205  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4329 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4331,2,t0,t1);}
t2=C_retrieve2(lf[50],"default-library");
if(C_truep(C_retrieve2(lf[17],"chicken-prefix"))){
t3=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[17],"chicken-prefix"),lf[403]);
/* csc.scm: 82   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],t3,C_retrieve2(lf[50],"default-library"));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5613,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t3,t1);}}

/* f5613 in k4329 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k4325 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5258,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5258 in k4325 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4323,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[74] /* (set! default-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4319,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 211  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t5,lf[401],C_retrieve2(lf[36],"library-extension"));}
else{
t5=t4;
f_1186(t5,lf[402]);}}

/* k4317 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4319,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1186(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1186,NULL,2,t0,t1);}
t2=C_mutate(&lf[75] /* (set! default-shared-library-files ...) */,t1);
t3=lf[76] /* unsafe-libraries */ =C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4290,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4294,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4298,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4302,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k4300 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4306,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 222  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t2,lf[400],C_retrieve2(lf[51],"default-unsafe-library"));}

/* k4304 in k4300 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 220  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4296 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4298,2,t0,t1);}
t2=C_retrieve2(lf[51],"default-unsafe-library");
if(C_truep(C_retrieve2(lf[17],"chicken-prefix"))){
t3=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[17],"chicken-prefix"),lf[399]);
/* csc.scm: 82   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],t3,C_retrieve2(lf[51],"default-unsafe-library"));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5609,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t3,t1);}}

/* f5609 in k4296 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k4292 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5253,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5253 in k4292 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[77] /* (set! unsafe-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1195,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4286,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 226  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t5,lf[397],C_retrieve2(lf[36],"library-extension"));}
else{
t5=t4;
f_1195(t5,lf[398]);}}

/* k4284 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4286,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1195(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1195,NULL,2,t0,t1);}
t2=C_mutate(&lf[78] /* (set! unsafe-shared-library-files ...) */,t1);
t3=C_mutate(&lf[79] /* (set! library-files ...) */,C_retrieve2(lf[74],"default-library-files"));
t4=C_mutate(&lf[80] /* (set! shared-library-files ...) */,C_retrieve2(lf[75],"default-shared-library-files"));
t5=lf[81] /* translate-options */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1208,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4273,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k4271 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4273,2,t0,t1);}
if(C_truep(C_retrieve2(lf[17],"chicken-prefix"))){
t2=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[17],"chicken-prefix"),lf[395]);
/* csc.scm: 82   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],t2,lf[396]);}
else{
t2=((C_word*)t0)[2];
f_1208(2,t2,t1);}}

/* k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1208,2,t0,t1);}
t2=(C_word)C_i_member(t1,lf[82]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[83] /* (set! include-dir ...) */,t3);
t5=lf[84] /* compile-options */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[83],"include-dir"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4262,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 248  conc */
((C_proc5)C_retrieve_symbol_proc(lf[179]))(5,*((C_word*)lf[179]+1),t7,lf[393],C_retrieve2(lf[83],"include-dir"),lf[394]);}
else{
t7=t6;
f_1216(t7,C_SCHEME_END_OF_LIST);}}

/* k4260 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4262,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1216(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1216,NULL,2,t0,t1);}
t2=C_mutate(&lf[85] /* (set! builtin-compile-options ...) */,t1);
t3=C_mutate(&lf[86] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[52],"default-compilation-optimization-options"));
t4=C_mutate(&lf[87] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[54],"default-linking-optimization-options"));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4249,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k4247 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4249,2,t0,t1);}
if(C_truep(C_retrieve2(lf[17],"chicken-prefix"))){
t2=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[17],"chicken-prefix"),lf[391]);
/* csc.scm: 82   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],t2,lf[392]);}
else{
t2=((C_word*)t0)[2];
f_1224(2,t2,t1);}}

/* k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=C_mutate(&lf[88] /* (set! library-dir ...) */,t1);
t3=lf[89] /* link-options */ =C_SCHEME_END_OF_LIST;;
t4=lf[90] /* target-filename */ =C_SCHEME_FALSE;;
t5=lf[91] /* verbose */ =C_SCHEME_FALSE;;
t6=lf[92] /* keep-files */ =C_SCHEME_FALSE;;
t7=lf[93] /* translate-only */ =C_SCHEME_FALSE;;
t8=lf[94] /* compile-only */ =C_SCHEME_FALSE;;
t9=lf[95] /* to-stdout */ =C_SCHEME_FALSE;;
t10=lf[96] /* shared */ =C_SCHEME_FALSE;;
t11=lf[97] /* static */ =C_SCHEME_FALSE;;
t12=lf[98] /* static-libs */ =C_SCHEME_FALSE;;
t13=lf[99] /* static-extensions */ =C_SCHEME_END_OF_LIST;;
t14=lf[100] /* required-extensions */ =C_SCHEME_END_OF_LIST;;
t15=C_mutate(&lf[101] /* (set! compiler-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3238,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[105] /* (set! lib-path ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3626,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[109] /* (set! copy-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3675,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[117] /* (set! static-extension-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3715,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[123] /* (set! linker-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3812,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[127] /* (set! linker-libraries ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3864,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[129] /* (set! constant742 ...) */,lf[130]);
t22=C_mutate(&lf[103] /* (set! quote-option ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4007,tmp=(C_word)a,a+=2,tmp));
t23=lf[140] /* last-exit-code */ =C_SCHEME_FALSE;;
t24=C_mutate(&lf[110] /* (set! command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4093,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate(&lf[149] /* (set! $delete-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4109,tmp=(C_word)a,a+=2,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4224,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4234,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4238,a[2]=t27,tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4242,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 1075 get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[389]))(3,*((C_word*)lf[389]+1),t29,lf[390]);}

/* k4240 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csc.scm: 1075 string-split */
((C_proc3)C_retrieve_symbol_proc(lf[342]))(3,*((C_word*)lf[342]+1),((C_word*)t0)[2],t2);}
else{
/* csc.scm: 1075 string-split */
((C_proc3)C_retrieve_symbol_proc(lf[342]))(3,*((C_word*)lf[342]+1),((C_word*)t0)[2],lf[388]);}}

/* k4236 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 1074 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[18],"arguments"));}

/* k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1323,tmp=(C_word)a,a+=2,tmp));
t11=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1330,tmp=(C_word)a,a+=2,tmp));
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1369,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1395,tmp=(C_word)a,a+=2,tmp));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1412,a[2]=t7,a[3]=t5,a[4]=t3,a[5]=t15,a[6]=t9,tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_1412(t17,((C_word*)t0)[2],t1);}

/* loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1412(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1412,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 524  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t3,C_retrieve2(lf[84],"compile-options"),C_retrieve2(lf[85],"builtin-compile-options"));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1649,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,a[8]=t1,a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* csc.scm: 573  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[387]+1)))(3,*((C_word*)lf[387]+1),t7,t3);}}

/* k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1652,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[230]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[231]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1664,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1283,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}
else{
t5=(C_word)C_eqp(t1,lf[236]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1676,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1683,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 579  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[237]))(2,*((C_word*)lf[237]+1),t7);}
else{
t6=(C_word)C_eqp(t1,lf[238]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1692,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1699,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 582  sprintf */
((C_proc4)C_retrieve_proc(*((C_word*)lf[239]+1)))(4,*((C_word*)lf[239]+1),t8,C_retrieve2(lf[26],"translator"),lf[240]);}
else{
t7=(C_word)C_eqp(t1,lf[241]);
if(C_truep(t7)){
t8=lf[61] /* cpp-mode */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[242],C_retrieve2(lf[84],"compile-options"));
t10=C_mutate(&lf[84] /* (set! compile-options ...) */,t9);
/* csc.scm: 796  loop */
t11=((C_word*)((C_word*)t0)[9])[1];
f_1412(t11,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
/* csc.scm: 796  loop */
t9=((C_word*)((C_word*)t0)[9])[1];
f_1412(t9,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}}
else{
t8=(C_word)C_eqp(t1,lf[243]);
if(C_truep(t8)){
t9=lf[62] /* objc-mode */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t10=((C_word*)((C_word*)t0)[9])[1];
f_1412(t10,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t9=(C_word)C_eqp(t1,lf[244]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 590  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t10,lf[245],lf[246],C_retrieve2(lf[81],"translate-options"));}
else{
t10=(C_word)C_eqp(t1,lf[247]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 593  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t11,lf[248],lf[249],C_retrieve2(lf[81],"translate-options"));}
else{
t11=(C_word)C_eqp(t1,lf[250]);
if(C_truep(t11)){
t12=lf[64] /* inquiry-only */ =C_SCHEME_TRUE;;
t13=lf[65] /* show-cflags */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t14=((C_word*)((C_word*)t0)[9])[1];
f_1412(t14,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t12=(C_word)C_eqp(t1,lf[251]);
if(C_truep(t12)){
t13=lf[64] /* inquiry-only */ =C_SCHEME_TRUE;;
t14=lf[66] /* show-ldflags */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t15=((C_word*)((C_word*)t0)[9])[1];
f_1412(t15,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t13=(C_word)C_eqp(t1,lf[252]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1767,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 601  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),t14,C_retrieve2(lf[27],"compiler"));}
else{
t14=(C_word)C_eqp(t1,lf[253]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 602  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),t15,C_retrieve2(lf[28],"c++-compiler"));}
else{
t15=(C_word)C_eqp(t1,lf[254]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 603  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),t16,C_retrieve2(lf[29],"linker"));}
else{
t16=(C_word)C_eqp(t1,lf[255]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1803,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 604  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),t17,C_retrieve2(lf[25],"home"));}
else{
t17=(C_word)C_eqp(t1,lf[256]);
if(C_truep(t17)){
t18=lf[64] /* inquiry-only */ =C_SCHEME_TRUE;;
t19=lf[67] /* show-libs */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t20=((C_word*)((C_word*)t0)[9])[1];
f_1412(t20,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t18=(C_word)C_eqp(t1,lf[257]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_numberp(C_retrieve2(lf[91],"verbose"));
t21=(C_truep(t20)?(C_word)C_i_not(C_retrieve2(lf[5],"msvc")):C_SCHEME_FALSE);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1838,a[2]=t19,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 610  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t22,lf[261],lf[262],C_retrieve2(lf[84],"compile-options"));}
else{
t22=t19;
f_1823(t22,C_SCHEME_UNDEFINED);}}
else{
t19=(C_word)C_eqp(t1,lf[263]);
t20=(C_truep(t19)?t19:(C_word)C_eqp(t1,lf[264]));
if(C_truep(t20)){
t21=(C_word)C_a_i_cons(&a,2,lf[265],C_retrieve2(lf[84],"compile-options"));
t22=C_mutate(&lf[84] /* (set! compile-options ...) */,t21);
/* csc.scm: 618  t-options */
f_1323(t2,(C_word)C_a_i_list(&a,1,lf[266]));}
else{
t21=(C_word)C_eqp(t1,lf[267]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(t1,lf[268]));
if(C_truep(t22)){
t23=lf[93] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm: 621  t-options */
f_1323(t2,(C_word)C_a_i_list(&a,1,lf[269]));}
else{
t23=(C_word)C_eqp(t1,lf[270]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t1,lf[271]));
if(C_truep(t24)){
t25=lf[93] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm: 624  t-options */
f_1323(t2,(C_word)C_a_i_list(&a,1,lf[272]));}
else{
t25=(C_word)C_eqp(t1,lf[273]);
if(C_truep(t25)){
t26=lf[92] /* keep-files */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t27=((C_word*)((C_word*)t0)[9])[1];
f_1412(t27,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t26=(C_word)C_eqp(t1,lf[274]);
if(C_truep(t26)){
t27=lf[94] /* compile-only */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t28=((C_word*)((C_word*)t0)[9])[1];
f_1412(t28,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t27=(C_word)C_eqp(t1,lf[275]);
if(C_truep(t27)){
t28=lf[93] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t29=((C_word*)((C_word*)t0)[9])[1];
f_1412(t29,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t28=(C_word)C_eqp(t1,lf[276]);
t29=(C_truep(t28)?t28:(C_word)C_eqp(t1,lf[277]));
if(C_truep(t29)){
t30=lf[63] /* embedded */ =C_SCHEME_TRUE;;
t31=(C_word)C_a_i_cons(&a,2,lf[278],C_retrieve2(lf[84],"compile-options"));
t32=C_mutate(&lf[84] /* (set! compile-options ...) */,t31);
/* csc.scm: 796  loop */
t33=((C_word*)((C_word*)t0)[9])[1];
f_1412(t33,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t30=(C_word)C_eqp(t1,lf[279]);
t31=(C_truep(t30)?t30:(C_word)C_eqp(t1,lf[280]));
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1941,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 632  check */
f_1330(t32,t1,((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t32=(C_word)C_eqp(t1,lf[282]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 637  check */
f_1330(t33,t1,((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t33=(C_word)C_eqp(t1,lf[284]);
if(C_truep(t33)){
t34=f_1395(C_a_i(&a,6));
/* csc.scm: 796  loop */
t35=((C_word*)((C_word*)t0)[9])[1];
f_1412(t35,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t34=(C_word)C_eqp(t1,lf[285]);
t35=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t34)){
t36=t35;
f_2014(t36,t34);}
else{
t36=(C_word)C_eqp(t1,lf[385]);
t37=t35;
f_2014(t37,(C_truep(t36)?t36:(C_word)C_eqp(t1,lf[386])));}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2014,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=lf[69] /* gui */ =C_SCHEME_TRUE;;
t3=(C_word)C_a_i_cons(&a,2,lf[286],C_retrieve2(lf[84],"compile-options"));
t4=C_mutate(&lf[84] /* (set! compile-options ...) */,t3);
t5=C_retrieve2(lf[5],"msvc");
t6=(C_truep(C_retrieve2(lf[5],"msvc"))?C_retrieve2(lf[5],"msvc"):lf[3]);
if(C_truep(t6)){
if(C_truep(lf[3])){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 651  cons* */
((C_proc7)C_retrieve_symbol_proc(lf[136]))(7,*((C_word*)lf[136]+1),t7,lf[287],lf[288],lf[289],lf[290],C_retrieve2(lf[89],"link-options"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 655  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[136]))(6,*((C_word*)lf[136]+1),t7,lf[291],lf[292],lf[293],C_retrieve2(lf[89],"link-options"));}
else{
/* csc.scm: 796  loop */
t7=((C_word*)((C_word*)t0)[10])[1];
f_1412(t7,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1]);}}}
else{
/* csc.scm: 796  loop */
t7=((C_word*)((C_word*)t0)[10])[1];
f_1412(t7,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1]);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[294]);
if(C_truep(t2)){
t3=lf[70] /* deploy */ =C_SCHEME_TRUE;;
t4=lf[71] /* deployed */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t5=((C_word*)((C_word*)t0)[10])[1];
f_1412(t5,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[295]);
if(C_truep(t3)){
t4=lf[71] /* deployed */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t5=((C_word*)((C_word*)t0)[10])[1];
f_1412(t5,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[296]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 662  check */
f_1330(t5,((C_word*)t0)[7],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[298]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2087,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 667  check */
f_1330(t6,((C_word*)t0)[7],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[299]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[7],lf[300]));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2108,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 671  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t8,lf[301],lf[302],((C_word*)((C_word*)t0)[8])[1]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[7],lf[303]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2118,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 672  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t9,lf[304],lf[305],((C_word*)((C_word*)t0)[8])[1]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[7],lf[306]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 673  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t10,lf[307],lf[308],((C_word*)((C_word*)t0)[8])[1]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[7],lf[309]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2138,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 674  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t11,lf[310],lf[311],((C_word*)((C_word*)t0)[8])[1]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[7],lf[312]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 676  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t12,lf[320],lf[321],((C_word*)((C_word*)t0)[8])[1]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[7],lf[322]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2178,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 682  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t13,lf[323],lf[324],((C_word*)((C_word*)t0)[8])[1]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[7],lf[325]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2188,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 683  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t14,lf[326],lf[327],((C_word*)((C_word*)t0)[8])[1]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[7],lf[328]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 684  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t15,lf[329],lf[330],((C_word*)((C_word*)t0)[8])[1]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[7],lf[331]);
if(C_truep(t15)){
t16=lf[91] /* verbose */ =C_SCHEME_TRUE;;
t17=lf[68] /* dry-run */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t18=((C_word*)((C_word*)t0)[10])[1];
f_1412(t18,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[7],lf[332]);
t17=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t16)){
t18=t17;
f_2215(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[7],lf[383]);
t19=t17;
f_2215(t19,(C_truep(t18)?t18:(C_word)C_eqp(((C_word*)t0)[7],lf[384])));}}}}}}}}}}}}}}}}

/* k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2215,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 689  shared-build */
f_1369(((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[8],lf[333]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[8],lf[334]));
if(C_truep(t3)){
/* csc.scm: 691  shared-build */
f_1369(((C_word*)t0)[9],C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[8],lf[335]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 693  check */
f_1330(t5,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[8],lf[336]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 697  check */
f_1330(t6,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[8],lf[337]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 701  check */
f_1330(t7,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[8],lf[338]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2290,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 705  check */
f_1330(t8,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[8],lf[339]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 709  check */
f_1330(t9,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[8],lf[341]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 712  check */
f_1330(t10,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[8],lf[343]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_a_i_list(&a,1,lf[344]);
/* csc.scm: 716  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t11,C_retrieve2(lf[89],"link-options"),t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[8],lf[345]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 718  check */
f_1330(t12,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[8],lf[346]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 722  t-options */
f_1323(t13,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t13=(C_word)C_eqp(((C_word*)t0)[8],lf[347]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2404,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 725  check */
f_1330(t14,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[8],lf[349]);
if(C_truep(t14)){
/* csc.scm: 796  loop */
t15=((C_word*)((C_word*)t0)[6])[1];
f_1412(t15,((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[8],lf[350]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 731  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[107]))(5,*((C_word*)lf[107]+1),t16,C_SCHEME_FALSE,lf[352],C_retrieve2(lf[42],"executable-extension"));}
else{
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t17=((C_word*)t0)[8];
if(C_truep((C_truep((C_word)C_eqp(t17,lf[382]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t17,lf[380]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t18=(C_word)C_eqp(((C_word*)t0)[8],lf[380]);
if(C_truep(t18)){
t19=lf[76] /* unsafe-libraries */ =C_SCHEME_TRUE;;
t20=C_mutate(&lf[79] /* (set! library-files ...) */,C_retrieve2(lf[77],"unsafe-library-files"));
t21=C_mutate(&lf[80] /* (set! shared-library-files ...) */,C_retrieve2(lf[78],"unsafe-shared-library-files"));
t22=t16;
f_2457(t22,t21);}
else{
t19=C_SCHEME_UNDEFINED;
t20=t16;
f_2457(t20,t19);}}
else{
t18=t16;
f_2457(t18,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}}

/* k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2457,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[381]);
if(C_truep(t3)){
t4=lf[95] /* to-stdout */ =C_SCHEME_TRUE;;
t5=lf[93] /* translate-only */ =C_SCHEME_TRUE;;
t6=t2;
f_2460(t6,t5);}
else{
t4=t2;
f_2460(t4,C_SCHEME_UNDEFINED);}}

/* k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2460,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[9];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[379]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[380]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[86] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[53],"best-compilation-optimization-options"));
t5=C_mutate(&lf[87] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[55],"best-linking-optimization-options"));
t6=t2;
f_2463(t6,t5);}
else{
t4=t2;
f_2463(t4,C_SCHEME_UNDEFINED);}}

/* k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2463,NULL,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[9],lf[353]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=f_2470(C_a_i(&a,3),t3,t2);
/* csc.scm: 796  loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1412(t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[8])[1]);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[9],lf[354]))){
/* csc.scm: 744  t-options */
f_1323(((C_word*)t0)[4],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[9],lf[355]))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 746  check */
f_1330(t3,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2884,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 751  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[357]+1)))(5,*((C_word*)lf[357]+1),t5,((C_word*)t0)[3],C_fix(0),C_fix(2));}
else{
t5=t3;
f_2519(t5,C_SCHEME_FALSE);}}}}}

/* k2882 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2519(t2,(C_word)C_i_string_equal_p(lf[378],t1));}

/* k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2519,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm: 752  t-options */
f_1323(((C_word*)t0)[7],(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t5=t2;
f_2528(t5,(C_word)C_eqp(C_make_character(45),t4));}
else{
t4=t2;
f_2528(t4,C_SCHEME_FALSE);}}}

/* k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2528(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2528,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_eqp(C_make_character(108),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm: 756  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t4,C_retrieve2(lf[89],"link-options"),t5);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_eqp(C_make_character(76),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm: 758  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t6,C_retrieve2(lf[89],"link-options"),t7);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t7=(C_word)C_eqp(C_make_character(73),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm: 760  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t8,C_retrieve2(lf[84],"compile-options"),t9);}
else{
t8=(C_word)C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t9=(C_word)C_eqp(C_make_character(68),t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 762  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[357]+1)))(4,*((C_word*)lf[357]+1),t10,((C_word*)t0)[8],C_fix(2));}
else{
t10=(C_word)C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t11=(C_word)C_eqp(C_make_character(70),t10);
if(C_truep(t11)){
if(C_truep(C_retrieve2(lf[7],"osx"))){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t13=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm: 765  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t12,C_retrieve2(lf[84],"compile-options"),t13);}
else{
/* csc.scm: 796  loop */
t12=((C_word*)((C_word*)t0)[7])[1];
f_1412(t12,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);}}
else{
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t13=(C_word)C_i_string_length(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_greaterp(t13,C_fix(3)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2709,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 766  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[357]+1)))(5,*((C_word*)lf[357]+1),t14,((C_word*)t0)[8],C_fix(0),C_fix(4));}
else{
t14=t12;
f_2606(t14,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 775  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),t2,((C_word*)t0)[8]);}}

/* k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2739,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2750,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 792  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t2,((C_word*)t0)[6],lf[377]);}}

/* k2845 in k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* csc.scm: 793  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),t2,t1);}

/* k2851 in k2845 in k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2853,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
/* csc.scm: 796  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_1412(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[6])[1]);}
else{
/* csc.scm: 795  quit */
f_1022(((C_word*)t0)[3],lf[376],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a2749 in k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2750(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2750,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t6,lf[365]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t6,lf[366]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2775,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 779  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t7,C_retrieve2(lf[57],"c-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t7,lf[367]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[368]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[369]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[370]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[371]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[372],C_retrieve2(lf[84],"compile-options"));
t10=C_mutate(&lf[84] /* (set! compile-options ...) */,t9);
t11=t8;
f_2788(t11,t10);}
else{
t9=t8;
f_2788(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t8,lf[373]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[374]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[375]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[62] /* objc-mode */ =C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2812,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 786  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t10,C_retrieve2(lf[57],"c-files"),t11);}
else{
t9=(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[33],"object-extension"));
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[36],"library-extension")));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2829,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 789  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t11,C_retrieve2(lf[59],"object-files"),t12);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2837,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 790  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t11,C_retrieve2(lf[56],"scheme-files"),t12);}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 777  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t6,C_retrieve2(lf[56],"scheme-files"),t7);}}

/* k2759 in a2749 in k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[56] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2835 in a2749 in k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[56] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2827 in a2749 in k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[59] /* (set! object-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2810 in a2749 in k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[57] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2786 in a2749 in k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2788,NULL,2,t0,t1);}
t2=lf[61] /* cpp-mode */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 783  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t3,C_retrieve2(lf[57],"c-files"),t4);}

/* k2791 in k2786 in a2749 in k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[57] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2773 in a2749 in k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[57] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a2743 in k2737 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2744,2,t0,t1);}
/* csc.scm: 776  decompose-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[364]))(3,*((C_word*)lf[364]+1),t1,((C_word*)t0)[2]);}

/* k2707 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2606(t2,(C_word)C_i_string_equal_p(lf[363],t1));}

/* k2604 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2606,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
/* csc.scm: 767  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t2,C_retrieve2(lf[89],"link-options"),t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2692,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* string->list */
t4=C_retrieve(lf[137]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
/* csc.scm: 774  quit */
f_1022(((C_word*)t0)[3],lf[362],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}}

/* k2690 in k2604 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2692,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csc.scm: 770  lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[360]))(5,*((C_word*)lf[360]+1),t3,*((C_word*)lf[139]+1),t2,lf[361]);}

/* k2686 in k2690 in k2604 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2633,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2639,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2639(t11,t7,((C_word*)t0)[4]);}
else{
/* csc.scm: 773  quit */
f_1022(((C_word*)t0)[3],lf[359],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* loop348 in k2686 in k2690 in k2604 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2639(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2639,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_a_i_string(&a,1,t4);
/* csc.scm: 772  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t3,lf[358],t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2675 in loop348 in k2686 in k2690 in k2604 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2677,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop348361 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2639(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop348361 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2639(t6,((C_word*)t0)[3],t5);}}

/* k2635 in k2686 in k2690 in k2604 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 772  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2631 in k2686 in k2690 in k2604 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1412(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2608 in k2604 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1412(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2594 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1412(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2581 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2583,2,t0,t1);}
/* csc.scm: 762  t-options */
f_1323(((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,lf[356],t1));}

/* k2564 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1412(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2550 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1412(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2536 in k2526 in k2517 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1412(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2498 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2500,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2506,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csc.scm: 748  string->number */
C_string_to_number(3,0,t3,t2);}

/* k2504 in k2498 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 749  t-options */
f_1323(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2507 in k2504 in k2498 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm: 796  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1412(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* g323 in k2461 in k2458 in k2455 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static C_word C_fcall f_2470(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
return(t4);}

/* k2448 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
t2=C_mutate(&lf[90] /* (set! target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 732  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t3,C_retrieve2(lf[56],"scheme-files"),lf[351]);}

/* k2452 in k2448 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[56] /* (set! scheme-files ...) */,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1412(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2402 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 726  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[318]))(2,*((C_word*)lf[318]+1),t2);}

/* k2432 in k2402 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2434,2,t0,t1);}
if(C_truep((C_truep((C_word)C_eqp(t1,lf[314]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t1,lf[315]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2426,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 727  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t3,lf[348],t4);}
else{
/* csc.scm: 796  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1412(t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}}

/* k2424 in k2432 in k2402 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2426,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* csc.scm: 727  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],C_retrieve2(lf[89],"link-options"),t2);}

/* k2412 in k2432 in k2402 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm: 796  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1412(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2390 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=lf[76] /* unsafe-libraries */ =C_SCHEME_TRUE;;
t3=C_mutate(&lf[79] /* (set! library-files ...) */,C_retrieve2(lf[77],"unsafe-library-files"));
t4=C_mutate(&lf[80] /* (set! shared-library-files ...) */,C_retrieve2(lf[78],"unsafe-shared-library-files"));
/* csc.scm: 796  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1412(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2365 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2379,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 719  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[342]))(3,*((C_word*)lf[342]+1),t3,t4);}

/* k2377 in k2365 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 719  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],C_retrieve2(lf[89],"link-options"),t1);}

/* k2369 in k2365 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm: 796  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1412(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2352 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1412(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2326 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 713  string-split */
((C_proc3)C_retrieve_symbol_proc(lf[342]))(3,*((C_word*)lf[342]+1),t3,t4);}

/* k2338 in k2326 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 713  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],C_retrieve2(lf[84],"compile-options"),t1);}

/* k2330 in k2326 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm: 796  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1412(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2305 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 710  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t2,lf[340],t3,t4);}

/* k2309 in k2305 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1412(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2288 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[29] /* (set! linker ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm: 796  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1412(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2271 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[28] /* (set! c++-compiler ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm: 796  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1412(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2254 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[27] /* (set! compiler ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm: 796  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1412(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2237 in k2213 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[26] /* (set! translator ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm: 796  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1412(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2196 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1412(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2186 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1412(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2176 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1412(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2146 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2148,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 677  t-options */
f_1323(t3,(C_word)C_a_i_list(&a,1,lf[319]));}

/* k2149 in k2146 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
t2=lf[76] /* unsafe-libraries */ =C_SCHEME_TRUE;;
t3=C_mutate(&lf[79] /* (set! library-files ...) */,C_retrieve2(lf[77],"unsafe-library-files"));
t4=C_mutate(&lf[80] /* (set! shared-library-files ...) */,C_retrieve2(lf[78],"unsafe-shared-library-files"));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 679  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[318]))(2,*((C_word*)lf[318]+1),t5);}

/* k2166 in k2149 in k2146 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
if(C_truep((C_truep((C_word)C_eqp(t1,lf[2]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t1,lf[313]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t1,lf[314]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t1,lf[315]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 681  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t2,lf[316],lf[317],C_retrieve2(lf[84],"compile-options"));}
else{
/* csc.scm: 796  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1412(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2162 in k2166 in k2149 in k2146 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1412(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2136 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1412(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2126 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1412(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2116 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1412(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2106 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1412(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2085 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=C_mutate(&lf[90] /* (set! target-filename ...) */,t2);
/* csc.scm: 796  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1412(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2061 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2063,2,t0,t1);}
if(C_truep(C_retrieve2(lf[7],"osx"))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm: 664  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t2,lf[297],t3,C_retrieve2(lf[89],"link-options"));}
else{
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm: 796  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1412(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}}

/* k2072 in k2061 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm: 796  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1412(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2037 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1412(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2030 in k2012 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1412(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1971 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* csc.scm: 638  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t2,C_retrieve2(lf[99],"static-extensions"),t4);}

/* k1975 in k1971 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
t2=C_mutate(&lf[99] /* (set! static-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
/* csc.scm: 639  t-options */
f_1323(t3,(C_word)C_a_i_list(&a,2,lf[283],t4));}

/* k1978 in k1975 in k1971 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm: 796  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1412(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1939 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* csc.scm: 633  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t2,C_retrieve2(lf[100],"required-extensions"),t4);}

/* k1943 in k1939 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=C_mutate(&lf[100] /* (set! required-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
/* csc.scm: 634  t-options */
f_1323(t3,(C_word)C_a_i_list(&a,2,lf[281],t4));}

/* k1946 in k1943 in k1939 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm: 796  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1412(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1836 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1838,2,t0,t1);}
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?(C_word)C_a_i_cons(&a,2,lf[259],C_retrieve2(lf[89],"link-options")):(C_word)C_a_i_cons(&a,2,lf[260],C_retrieve2(lf[89],"link-options")));
t4=C_mutate(&lf[89] /* (set! link-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1823(t5,t4);}

/* k1821 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1823,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[91],"verbose"))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 613  t-options */
f_1323(t2,(C_word)C_a_i_list(&a,1,lf[258]));}
else{
t2=lf[91] /* verbose */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1412(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k1827 in k1821 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[91] /* verbose */ =C_fix(2);;
/* csc.scm: 796  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1412(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1801 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 604  exit */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),((C_word*)t0)[2],C_fix(0));}

/* k1789 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 603  exit */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),((C_word*)t0)[2],C_fix(0));}

/* k1777 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 602  exit */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),((C_word*)t0)[2],C_fix(0));}

/* k1765 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 601  exit */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),((C_word*)t0)[2],C_fix(0));}

/* k1739 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=lf[98] /* static-libs */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1412(t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1728 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=lf[97] /* static */ =C_SCHEME_TRUE;;
/* csc.scm: 796  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1412(t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1697 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 582  system */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),((C_word*)t0)[2],t1);}

/* k1690 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 583  exit */
((C_proc2)C_retrieve_symbol_proc(lf[12]))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k1681 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 579  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),((C_word*)t0)[2],t1);}

/* k1674 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 580  exit */
((C_proc2)C_retrieve_symbol_proc(lf[12]))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k1281 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1290,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[232],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[233],t4);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[234],t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[235],t8);
/* csc.scm: 294  ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[165]))(3,*((C_word*)lf[165]+1),t2,t9);}

/* k1288 in k1281 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 295  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),((C_word*)t0)[2],t1);}

/* k1662 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 577  exit */
((C_proc2)C_retrieve_symbol_proc(lf[12]))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k1650 in k1647 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 796  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1412(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[10],"elf"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1238,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 266  conc */
((C_proc5)C_retrieve_symbol_proc(lf[179]))(5,*((C_word*)lf[179]+1),t4,lf[226],C_retrieve2(lf[88],"library-dir"),lf[227]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1266,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 276  conc */
((C_proc5)C_retrieve_symbol_proc(lf[179]))(5,*((C_word*)lf[179]+1),t4,lf[228],C_retrieve2(lf[88],"library-dir"),lf[229]);}}

/* k1264 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1266,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* csc.scm: 525  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],C_retrieve2(lf[89],"link-options"),t2);}

/* k1236 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1242,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1246,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[71],"deployed"))){
/* csc.scm: 267  conc */
((C_proc5)C_retrieve_symbol_proc(lf[179]))(5,*((C_word*)lf[179]+1),t2,lf[221],lf[223],lf[222]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1253,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}}

/* k1251 in k1236 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1253,2,t0,t1);}
if(C_truep(C_retrieve2(lf[17],"chicken-prefix"))){
t2=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[17],"chicken-prefix"),lf[224]);
/* csc.scm: 82   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],t2,lf[225]);}
else{
/* csc.scm: 267  conc */
((C_proc5)C_retrieve_symbol_proc(lf[179]))(5,*((C_word*)lf[179]+1),((C_word*)t0)[2],lf[221],t1,lf[222]);}}

/* k1244 in k1236 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 267  conc */
((C_proc5)C_retrieve_symbol_proc(lf[179]))(5,*((C_word*)lf[179]+1),((C_word*)t0)[2],lf[221],t1,lf[222]);}

/* k1240 in k1236 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* csc.scm: 525  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],C_retrieve2(lf[89],"link-options"),t2);}

/* k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1427,2,t0,t1);}
t2=C_mutate(&lf[89] /* (set! link-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[64],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1603,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[65],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1636,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 528  compiler-options */
f_3238(t5);}
else{
t5=t4;
f_1603(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1430(2,t4,C_SCHEME_UNDEFINED);}}

/* k1634 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 528  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1601 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1606,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[66],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1629,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 529  linker-options */
f_3812(t3);}
else{
t3=t2;
f_1606(2,t3,C_SCHEME_UNDEFINED);}}

/* k1627 in k1601 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 529  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1604 in k1601 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[67],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1622,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 530  linker-libraries */
f_3864(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5244,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 531  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[219]+1)))(2,*((C_word*)lf[219]+1),t3);}}

/* f5244 in k1604 in k1601 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 532  exit */
((C_proc2)C_retrieve_symbol_proc(lf[12]))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k1620 in k1604 in k1601 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 530  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1607 in k1604 in k1601 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1612,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 531  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[219]+1)))(2,*((C_word*)lf[219]+1),t2);}

/* k1610 in k1607 in k1604 in k1601 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 532  exit */
((C_proc2)C_retrieve_symbol_proc(lf[12]))(2,*((C_word*)lf[12]+1),((C_word*)t0)[2]);}

/* k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[56],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1528,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[57],"c-files")))){
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[59],"object-files")))){
/* csc.scm: 539  quit */
f_1022(t3,lf[211],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_1528(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1528(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1566,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[96],"shared"))?(C_word)C_i_not(C_retrieve2(lf[63],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[218],C_retrieve2(lf[81],"translate-options"));
t6=C_mutate(&lf[81] /* (set! translate-options ...) */,t5);
t7=t3;
f_1566(t7,t6);}
else{
t5=t3;
f_1566(t5,C_SCHEME_UNDEFINED);}}}

/* k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1566,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[90],"target-filename"))){
t3=t2;
f_1569(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1576,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[96],"shared"))){
t4=(C_word)C_i_car(C_retrieve2(lf[56],"scheme-files"));
/* csc.scm: 552  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),t3,t4,C_retrieve2(lf[46],"shared-library-extension"));}
else{
t4=(C_word)C_i_car(C_retrieve2(lf[56],"scheme-files"));
/* csc.scm: 553  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),t3,t4,C_retrieve2(lf[42],"executable-extension"));}}}

/* k1574 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[90] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1569(t3,t2);}

/* k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1569(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1569,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2989(t6,t2,C_retrieve2(lf[56],"scheme-files"));}

/* loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2989(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2989,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3001,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_length(C_retrieve2(lf[56],"scheme-files"));
t6=(C_word)C_i_nequalp(C_fix(1),t5);
t7=(C_truep(t6)?C_retrieve2(lf[90],"target-filename"):t3);
if(C_truep(C_retrieve2(lf[61],"cpp-mode"))){
/* csc.scm: 804  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),t4,t7,lf[215]);}
else{
if(C_truep(C_retrieve2(lf[62],"objc-mode"))){
/* csc.scm: 804  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),t4,t7,lf[216]);}
else{
/* csc.scm: 804  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),t4,t7,lf[217]);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3004,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3024,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3028,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3032,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5238,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t6,((C_word*)t0)[2]);}

/* f5238 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3030 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3036,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3040,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[95],"to-stdout"))){
t4=t3;
f_3040(t4,lf[213]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3094,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5233,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t6,t5);}}

/* f5233 in k3030 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3092 in k3030 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3094,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
f_3040(t3,(C_word)C_a_i_cons(&a,2,lf[214],t2));}

/* k3038 in k3030 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3040,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3044,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3048,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 818  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t7,C_retrieve2(lf[81],"translate-options"),C_SCHEME_END_OF_LIST);}

/* k3046 in k3038 in k3030 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3050(t5,((C_word*)t0)[2],t1);}

/* loop436 in k3046 in k3038 in k3030 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3050(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3050,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve2(lf[103],"quote-option");
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g452453 */
t6=C_retrieve2(lf[103],"quote-option");
f_4007(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3077 in loop436 in k3046 in k3038 in k3030 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3079,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop436449 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3050(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop436449 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3050(t6,((C_word*)t0)[3],t5);}}

/* k3042 in k3038 in k3030 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 814  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3034 in k3030 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 813  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),((C_word*)t0)[3],C_retrieve2(lf[26],"translator"),((C_word*)t0)[2],t1);}

/* k3026 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 812  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),((C_word*)t0)[2],t1,lf[212]);}

/* k3022 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 811  command */
f_4093(((C_word*)t0)[2],t1);}

/* k3002 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 820  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t2,t3,C_retrieve2(lf[57],"c-files"));}

/* k3006 in k3002 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3008,2,t0,t1);}
t2=C_mutate(&lf[57] /* (set! c-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm: 821  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t3,t4,C_retrieve2(lf[58],"generated-c-files"));}

/* k3010 in k3006 in k3002 in k2999 in loop413 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[58] /* (set! generated-c-files ...) */,t1);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2989(t4,((C_word*)t0)[2],t3);}

/* k2956 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2958,2,t0,t1);}
if(C_truep(C_retrieve2(lf[92],"keep-files"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_1433(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2966,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2966(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* loop465 in k2956 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_2966(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2966,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve2(lf[149],"$delete-file");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2976,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g472473 */
t6=C_retrieve2(lf[149],"$delete-file");
f_4109(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2974 in loop465 in k2956 in k1567 in k1564 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2966(t3,((C_word*)t0)[2],t2);}

/* k1526 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[57],"c-files")))){
t3=C_retrieve2(lf[59],"object-files");
/* csc.scm: 540  last */
((C_proc3)C_retrieve_symbol_proc(lf[210]))(3,*((C_word*)lf[210]+1),t2,t3);}
else{
t3=C_retrieve2(lf[57],"c-files");
/* csc.scm: 540  last */
((C_proc3)C_retrieve_symbol_proc(lf[210]))(3,*((C_word*)lf[210]+1),t2,t3);}}

/* k1529 in k1526 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1531,2,t0,t1);}
if(C_truep(C_retrieve2(lf[90],"target-filename"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_1433(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1538,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[96],"shared"))){
/* csc.scm: 544  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),t2,t1,C_retrieve2(lf[46],"shared-library-extension"));}
else{
/* csc.scm: 545  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),t2,t1,C_retrieve2(lf[42],"executable-extension"));}}}

/* k1536 in k1529 in k1526 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[90] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1433(2,t3,t2);}

/* k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1436,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[70],"deploy"))){
t3=C_retrieve2(lf[96],"shared");
t4=t2;
f_1436(t4,(C_truep(t3)?C_SCHEME_UNDEFINED:f_1395(C_a_i(&a,6))));}
else{
t3=t2;
f_1436(t3,C_SCHEME_UNDEFINED);}}

/* k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1436(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1436,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[93],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3132,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3171,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3171(t9,t5,C_retrieve2(lf[57],"c-files"));}}

/* loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3171(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3171,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3179,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3225,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g488489 */
t6=t3;
f_3179(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3223 in loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3171(t3,((C_word*)t0)[2],t2);}

/* g488 in loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3179(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3179,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3183,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 832  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),t3,t2,C_retrieve2(lf[33],"object-extension"));}

/* k3181 in g488 in loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3198,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[61],"cpp-mode"))?C_retrieve2(lf[28],"c++-compiler"):C_retrieve2(lf[27],"compiler"));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3210,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5216,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t7,t6);}

/* f5216 in k3181 in g488 in loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3208 in k3181 in g488 in loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3222,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5211,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t5,t4);}

/* f5211 in k3208 in k3181 in g488 in loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3220 in k3208 in k3181 in g488 in loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 838  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),((C_word*)t0)[2],C_retrieve2(lf[45],"compile-output-flag"),t1);}

/* k3212 in k3208 in k3181 in g488 in loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3218,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 840  compiler-options */
f_3238(t2);}

/* k3216 in k3212 in k3208 in k3181 in g488 in loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3218,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[208],t1);
/* csc.scm: 834  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[102]))(3,*((C_word*)lf[102]+1),((C_word*)t0)[2],t2);}

/* k3196 in k3181 in g488 in loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 833  command */
f_4093(((C_word*)t0)[2],t1);}

/* k3184 in k3181 in g488 in loop481 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3186,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[60],"generated-object-files"));
t3=C_mutate(&lf[60] /* (set! generated-object-files ...) */,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3130 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3136,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3169,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 844  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[118]+1)))(3,*((C_word*)lf[118]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k3167 in k3130 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 844  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[59],"object-files"));}

/* k3134 in k3130 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3136,2,t0,t1);}
t2=C_mutate(&lf[59] /* (set! object-files ...) */,t1);
if(C_truep(C_retrieve2(lf[92],"keep-files"))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_1442(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3144,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3144(t6,((C_word*)t0)[2],C_retrieve2(lf[58],"generated-c-files"));}}

/* loop506 in k3134 in k3130 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3144(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3144,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve2(lf[149],"$delete-file");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3154,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g513514 */
t6=C_retrieve2(lf[149],"$delete-file");
f_4109(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3152 in loop506 in k3134 in k3130 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3144(t3,((C_word*)t0)[2],t2);}

/* k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1442,2,t0,t1);}
if(C_truep(C_retrieve2(lf[94],"compile-only"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_member(C_retrieve2(lf[90],"target-filename"),C_retrieve2(lf[56],"scheme-files")))){
t3=*((C_word*)lf[141]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1457,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t4,lf[207],t3);}
else{
t3=t2;
f_1448(2,t3,C_SCHEME_UNDEFINED);}}}

/* k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,C_retrieve2(lf[90],"target-filename"),((C_word*)t0)[2]);}

/* k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,lf[206],((C_word*)t0)[2]);}

/* k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,C_retrieve2(lf[90],"target-filename"),((C_word*)t0)[2]);}

/* k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,lf[205],((C_word*)t0)[2]);}

/* k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[113]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1479,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[116]))(2,*((C_word*)lf[116]+1),t2);}

/* k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1482,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[49],"windows-shell"))){
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,lf[203],t1);}
else{
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,lf[204],t1);}}

/* k1480 in k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[113]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k1483 in k1480 in k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[90],"target-filename");
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5204,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t5,t4);}

/* f5204 in k1483 in k1480 in k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k1507 in k1483 in k1480 in k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1486 in k1483 in k1480 in k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[113]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k1489 in k1486 in k1483 in k1480 in k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1505,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 568  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),t4,C_retrieve2(lf[90],"target-filename"),lf[202]);}

/* k1503 in k1489 in k1486 in k1483 in k1480 in k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5199,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5199 in k1503 in k1489 in k1486 in k1483 in k1480 in k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k1499 in k1489 in k1486 in k1483 in k1480 in k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1492 in k1489 in k1486 in k1483 in k1480 in k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),t2,((C_word*)t0)[2]);}

/* k1495 in k1492 in k1489 in k1486 in k1483 in k1480 in k1477 in k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 563  command */
f_4093(((C_word*)t0)[2],t1);}

/* k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1448,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3298,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3573,a[2]=t7,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3612,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3614,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3620,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t9,t10,t11);}

/* a3619 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3620r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3620r(t0,t1,t2);}}

static void C_ccall f_3620r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a3613 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3614,2,t0,t1);}
/* csc.scm: 861  static-extension-info */
f_3715(t1);}

/* k3610 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 860  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],C_retrieve2(lf[59],"object-files"),t1);}

/* k3571 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3573,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3575,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3575(t5,((C_word*)t0)[2],t1);}

/* loop553 in k3571 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3575(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3575,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve2(lf[22],"quotewrap");
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3604,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5192,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t6,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f5192 in loop553 in k3571 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3602 in loop553 in k3571 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3604,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop553566 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3575(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop553566 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3575(t6,((C_word*)t0)[3],t5);}}

/* k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3301,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[90],"target-filename");
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5187,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t4,t3);}

/* f5187 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[70],"deploy"))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3471,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 865  pathname-strip-extension */
((C_proc3)C_retrieve_symbol_proc(lf[201]))(3,*((C_word*)lf[201]+1),t7,C_retrieve2(lf[90],"target-filename"));}
else{
t7=t6;
f_3304(2,t7,C_SCHEME_UNDEFINED);}}

/* k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3471,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[69],"gui"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3521,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 867  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[107]))(5,*((C_word*)lf[107]+1),t5,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[4])[1],lf[200]);}
else{
t5=t3;
f_3474(2,t5,C_SCHEME_UNDEFINED);}}

/* k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3521,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3524,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3552,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[116]))(2,*((C_word*)lf[116]+1),t4);}

/* k3550 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3555,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,lf[199],t1);}

/* k3553 in k3550 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3569,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 868  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t4,((C_word*)((C_word*)t0)[2])[1],lf[198]);}

/* k3567 in k3553 in k3550 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5182,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5182 in k3567 in k3553 in k3550 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3563 in k3553 in k3550 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3556 in k3553 in k3550 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3561,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),t2,((C_word*)t0)[2]);}

/* k3559 in k3556 in k3553 in k3550 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 868  command */
f_4093(((C_word*)t0)[2],t1);}

/* k3522 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[116]))(2,*((C_word*)lf[116]+1),t2);}

/* k3529 in k3522 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3534,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,lf[197],t1);}

/* k3532 in k3529 in k3522 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3548,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 869  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t4,((C_word*)((C_word*)t0)[2])[1],lf[196]);}

/* k3546 in k3532 in k3529 in k3522 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5177,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5177 in k3546 in k3532 in k3529 in k3522 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3542 in k3532 in k3529 in k3522 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3535 in k3532 in k3529 in k3522 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3540,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),t2,((C_word*)t0)[2]);}

/* k3538 in k3535 in k3532 in k3529 in k3522 in k3519 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 869  command */
f_4093(((C_word*)t0)[2],t1);}

/* k3472 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[69],"gui"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3511,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 874  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t5,C_retrieve2(lf[90],"target-filename"));}
else{
/* csc.scm: 875  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t3,C_retrieve2(lf[90],"target-filename"));}}

/* k3509 in k3472 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 874  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),((C_word*)t0)[2],lf[195],t1);}

/* k3499 in k3472 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 871  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3476 in k3472 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3478,2,t0,t1);}
t2=C_mutate(&lf[90] /* (set! target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_retrieve2(lf[90],"target-filename");
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5172,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t5,t4);}

/* f5172 in k3476 in k3472 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3480 in k3476 in k3472 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3482,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 877  directory-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[194]))(3,*((C_word*)lf[194]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k3486 in k3480 in k3476 in k3472 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_3304(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[91],"verbose"))){
/* csc.scm: 879  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,lf[193],((C_word*)((C_word*)t0)[2])[1]);}
else{
/* csc.scm: 880  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[192]))(3,*((C_word*)lf[192]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}}

/* k3489 in k3486 in k3480 in k3476 in k3472 in k3469 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 880  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[192]))(3,*((C_word*)lf[192]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3435,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3439,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[61],"cpp-mode"))?C_retrieve2(lf[30],"c++-linker"):C_retrieve2(lf[29],"linker"));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3447,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3455,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3467,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_retrieve2(lf[90],"target-filename");
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5167,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t10,t9);}

/* f5167 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3465 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 887  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),((C_word*)t0)[2],C_retrieve2(lf[39],"link-output-flag"),t1);}

/* k3453 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 888  linker-options */
f_3812(t2);}

/* k3457 in k3453 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 889  linker-libraries */
f_3864(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_FALSE));}

/* k3461 in k3457 in k3453 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3463,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],t1);
/* csc.scm: 885  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3445 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 883  cons* */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3437 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 882  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[102]))(3,*((C_word*)lf[102]+1),((C_word*)t0)[2],t1);}

/* k3433 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 881  command */
f_4093(((C_word*)t0)[2],t1);}

/* k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3381,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=(C_word)C_i_not(C_retrieve2(lf[21],"cross-chicken"));
if(C_truep(t4)){
t5=t3;
f_3381(t5,t4);}
else{
t5=C_retrieve2(lf[20],"host-mode");
t6=t3;
f_3381(t6,C_retrieve2(lf[20],"host-mode"));}}
else{
t4=t3;
f_3381(t4,C_SCHEME_FALSE);}}

/* k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3381,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3400,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[76],"unsafe-libraries"))?lf[184]:lf[185]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3408,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_truep(C_retrieve2(lf[76],"unsafe-libraries"))?lf[189]:lf[190]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3415,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[71],"deployed"))){
/* csc.scm: 897  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t7,lf[191],t6);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3425,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 899  lib-path */
f_3626(t8);}}
else{
t2=((C_word*)t0)[2];
f_3310(2,t2,C_SCHEME_UNDEFINED);}}

/* k3423 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 898  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3413 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5162,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5162 in k3413 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3406 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 892  string-append */
((C_proc8)C_retrieve_proc(*((C_word*)lf[124]+1)))(8,*((C_word*)lf[124]+1),((C_word*)t0)[4],lf[186],((C_word*)t0)[3],lf[187],t1,lf[188],((C_word*)((C_word*)t0)[2])[1]);}

/* k3398 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 891  command */
f_4093(((C_word*)t0)[2],t1);}

/* k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[69],"gui"))?(C_word)C_i_not(C_retrieve2(lf[70],"deploy")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4132,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[116]))(2,*((C_word*)lf[116]+1),t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_3310(2,t4,t3);}}

/* k4130 in k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,lf[183],t1);}

/* k4133 in k4130 in k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4138,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4159,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5157,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t4,((C_word*)t0)[2]);}

/* f5157 in k4133 in k4130 in k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k4157 in k4133 in k4130 in k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4136 in k4133 in k4130 in k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[113]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k4139 in k4136 in k4133 in k4130 in k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4151,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4155,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 1035 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t4,C_retrieve2(lf[25],"home"),lf[182]);}

/* k4153 in k4139 in k4136 in k4133 in k4130 in k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5152,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,t1);}

/* f5152 in k4153 in k4139 in k4136 in k4133 in k4130 in k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k4149 in k4139 in k4136 in k4133 in k4130 in k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4142 in k4139 in k4136 in k4133 in k4130 in k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4147,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),t2,((C_word*)t0)[2]);}

/* k4145 in k4142 in k4139 in k4136 in k4133 in k4130 in k3382 in k3379 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 1032 command */
f_4093(((C_word*)t0)[2],t1);}

/* k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3345,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[70],"deploy"))){
t4=C_retrieve2(lf[97],"static");
if(C_truep(t4)){
t5=t3;
f_3345(t5,(C_word)C_i_not(t4));}
else{
t5=C_retrieve2(lf[98],"static-libs");
t6=t3;
f_3345(t6,(C_word)C_i_not(t5));}}
else{
t4=t3;
f_3345(t4,C_SCHEME_FALSE);}}

/* k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3345(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3345,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3365,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=C_retrieve2(lf[69],"gui");
if(C_truep(t4)){
/* csc.scm: 908  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t3,((C_word*)((C_word*)t0)[3])[1],lf[181]);}
else{
t5=t3;
f_3365(2,t5,((C_word*)((C_word*)t0)[3])[1]);}}
else{
t4=t3;
f_3365(2,t4,((C_word*)((C_word*)t0)[3])[1]);}}
else{
t2=((C_word*)t0)[2];
f_3313(t2,C_SCHEME_UNDEFINED);}}

/* k3363 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3652,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3659,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 927  lib-path */
f_3626(t3);}

/* k3657 in k3363 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3659,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[76],"unsafe-libraries"))?lf[175]:lf[176]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3667,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
/* csc.scm: 926  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[107]))(5,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1,t2,lf[177]);}
else{
if(C_truep(C_retrieve2(lf[8],"win"))){
/* csc.scm: 926  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[107]))(5,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1,t2,lf[178]);}
else{
/* csc.scm: 933  conc */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t3,lf[180],C_fix((C_word)C_BINARY_VERSION));}}}

/* k3665 in k3657 in k3363 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 926  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[107]))(5,*((C_word*)lf[107]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3650 in k3363 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 934  copy-files */
f_3675(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3348,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[69],"gui"):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 912  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t3,C_retrieve2(lf[90],"target-filename"));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_3313(t4,t3);}}

/* k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3361,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[3])[1];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4165,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 1038 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t3,t2,lf[173]);}

/* k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 1039 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t2,((C_word*)t0)[2],lf[172]);}

/* k4166 in k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csc.scm: 1040 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t2,((C_word*)t0)[2],lf[171]);}

/* k4169 in k4166 in k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4174,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 1041 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t2,t1,lf[170]);}

/* k4172 in k4169 in k4166 in k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4214,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 1042 file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),t3,t1);}

/* k4212 in k4172 in k4169 in k4166 in k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4214,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_4177(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 1044 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t2,C_retrieve2(lf[25],"home"),lf[169]);}}

/* k4219 in k4212 in k4172 in k4169 in k4166 in k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 1043 copy-files */
f_3675(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4175 in k4172 in k4169 in k4166 in k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 1046 make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t2,((C_word*)t0)[2],lf[168]);}

/* k4178 in k4175 in k4172 in k4169 in k4166 in k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4186,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csc.scm: 1047 file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),t3,t1);}

/* k4184 in k4178 in k4175 in k4172 in k4169 in k4166 in k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4186,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_3313(t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4191,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 1048 with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[166]))(4,*((C_word*)lf[166]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a4190 in k4184 in k4178 in k4175 in k4172 in k4169 in k4166 in k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4191,2,t0,t1);}
t2=*((C_word*)lf[148]+1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4199,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[163],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[164],t5);
/* csc.scm: 1046 ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[165]))(3,*((C_word*)lf[165]+1),t3,t6);}

/* k4197 in a4190 in k4184 in k4178 in k4175 in k4172 in k4169 in k4166 in k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g841842 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4181 in k4178 in k4175 in k4172 in k4169 in k4166 in k4163 in k3359 in k3346 in k3343 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3313(t2,((C_word*)t0)[2]);}

/* k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3313,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[92],"keep-files"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3321,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3321(t5,((C_word*)t0)[2],C_retrieve2(lf[60],"generated-object-files"));}}

/* loop653 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3321(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3321,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve2(lf[149],"$delete-file");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3331,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g660661 */
t6=C_retrieve2(lf[149],"$delete-file");
f_4109(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3329 in loop653 in k3311 in k3308 in k3305 in k3302 in k3299 in k3296 in k1446 in k1440 in k1434 in k1431 in k1428 in k1425 in k1421 in loop in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3321(t3,((C_word*)t0)[2],t2);}

/* use-private-repository in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static C_word C_fcall f_1395(C_word *a){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_check;
t1=(C_word)C_a_i_cons(&a,2,lf[161],C_retrieve2(lf[84],"compile-options"));
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t3=(C_word)C_a_i_cons(&a,2,lf[162],C_retrieve2(lf[89],"link-options"));
t4=C_mutate(&lf[89] /* (set! link-options ...) */,t3);
return(t4);}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* shared-build in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1369(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1369,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1374,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 507  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),t3,lf[159],lf[160],C_retrieve2(lf[81],"translate-options"));}

/* k1372 in shared-build in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1374,2,t0,t1);}
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 508  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[104]+1)))(5,*((C_word*)lf[104]+1),t3,C_retrieve2(lf[48],"pic-options"),lf[158],C_retrieve2(lf[84],"compile-options"));}

/* k1376 in k1372 in shared-build in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1378,2,t0,t1);}
t2=C_mutate(&lf[84] /* (set! compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[7],"osx"))?(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_cons(&a,2,lf[154],C_retrieve2(lf[89],"link-options")):(C_word)C_a_i_cons(&a,2,lf[155],C_retrieve2(lf[89],"link-options"))):(C_truep(C_retrieve2(lf[5],"msvc"))?(C_word)C_a_i_cons(&a,2,lf[156],C_retrieve2(lf[89],"link-options")):(C_word)C_a_i_cons(&a,2,lf[157],C_retrieve2(lf[89],"link-options"))));
t4=C_mutate(&lf[89] /* (set! link-options ...) */,t3);
t5=lf[96] /* shared */ =C_SCHEME_TRUE;;
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* check in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1330(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1330,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1348,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
if(C_truep((C_word)C_i_greater_or_equalp(t5,C_fix(1)))){
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* csc.scm: 504  quit */
f_1022(t1,lf[153],(C_word)C_a_i_list(&a,1,t2));}}
else{
t7=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_1348(2,t8,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t8=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k1346 in check in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1348,2,t0,t1);}
if(C_truep((C_word)C_i_greater_or_equalp(((C_word*)t0)[4],t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csc.scm: 504  quit */
f_1022(((C_word*)t0)[3],lf[153],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* t-options in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1323(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1323,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 500  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),t3,C_retrieve2(lf[81],"translate-options"),t2);}

/* k1326 in t-options in k4232 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[81] /* (set! translate-options ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4222 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4227,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4230,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[152]))(2,*((C_word*)lf[152]+1),t3);}

/* k4228 in k4222 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4225 in k4222 in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* $delete-file in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4109,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4113,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[91],"verbose"))){
/* csc.scm: 1027 print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t3,lf[151],t2);}
else{
if(C_truep(C_retrieve2(lf[68],"dry-run"))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* csc.scm: 1028 delete-file */
((C_proc3)C_retrieve_symbol_proc(lf[150]))(3,*((C_word*)lf[150]+1),t1,t2);}}}

/* k4111 in $delete-file in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve2(lf[68],"dry-run"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csc.scm: 1028 delete-file */
((C_proc3)C_retrieve_symbol_proc(lf[150]))(3,*((C_word*)lf[150]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* command in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_4093(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4093,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4048,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[91],"verbose"))){
/* csc.scm: 1010 print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),t3,t2);}
else{
t4=t3;
f_4048(2,t4,C_SCHEME_UNDEFINED);}}

/* k4046 in command in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4051,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[49],"windows-shell"))){
/* csc.scm: 1012 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[124]+1)))(5,*((C_word*)lf[124]+1),t2,lf[146],((C_word*)t0)[2],lf[147]);}
else{
t3=t2;
f_4051(2,t3,((C_word*)t0)[2]);}}

/* k4049 in k4046 in command in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4054,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[68],"dry-run"))){
t3=t2;
f_4054(2,t3,C_fix(0));}
else{
/* csc.scm: 1014 system */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t2,t1);}}

/* k4052 in k4049 in k4046 in command in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_zerop(t1))){
t3=t2;
f_4057(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[141]+1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4070,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t4,lf[144],t3);}}

/* k4068 in k4052 in k4049 in k4046 in command in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[143]+1)))(4,*((C_word*)lf[143]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4071 in k4068 in k4052 in k4049 in k4046 in command in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,lf[142],((C_word*)t0)[3]);}

/* k4074 in k4071 in k4068 in k4052 in k4049 in k4046 in command in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4077 in k4074 in k4071 in k4068 in k4052 in k4049 in k4046 in command in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[113]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k4055 in k4052 in k4049 in k4046 in command in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep((C_word)C_i_zerop(((C_word*)t0)[3]))){
t2=lf[140] /* last-exit-code */ =C_fix(0);;
t3=C_retrieve2(lf[140],"last-exit-code");
if(C_truep((C_word)C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* csc.scm: 1023 exit */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),((C_word*)t0)[2],C_retrieve2(lf[140],"last-exit-code"));}}
else{
t2=lf[140] /* last-exit-code */ =C_fix(1);;
t3=C_retrieve2(lf[140],"last-exit-code");
if(C_truep((C_word)C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* csc.scm: 1023 exit */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),((C_word*)t0)[2],C_retrieve2(lf[140],"last-exit-code"));}}}

/* quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4007,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4014,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4037,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 1000 string-any */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t3,t4,t2);}

/* a4036 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4037,3,t0,t1,t2);}
t3=*((C_word*)lf[139]+1);
/* g776777 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(34),t2);}

/* k4012 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4014,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4025,tmp=(C_word)a,a+=2,tmp);
/* csc.scm: 1001 string-any */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t2,t3,((C_word*)t0)[3]);}}

/* a4024 in k4012 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4025,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[129])));}

/* k4018 in k4012 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3940,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3954,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3958,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_retrieve(lf[137]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k3956 in k4018 in k4012 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3958,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3960,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3960(t5,((C_word*)t0)[2],t1);}

/* fold in k3956 in k4018 in k4012 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3960(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3960,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_memq(t3,lf[129]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3983,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* csc.scm: 991  fold */
t9=t4;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_3990(t6,t5);}
else{
t5=t4;
f_3990(t5,C_SCHEME_UNDEFINED);}}}}

/* k3988 in fold in k3956 in k4018 in k4012 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3990,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3997,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csc.scm: 994  fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3960(t4,t2,t3);}

/* k3995 in k3988 in fold in k3956 in k4018 in k4012 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3981 in fold in k3956 in k4018 in k4012 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 991  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[136]))(5,*((C_word*)lf[136]+1),((C_word*)t0)[3],C_make_character(92),((C_word*)t0)[2],t1);}

/* k3952 in k4018 in k4012 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_retrieve(lf[135]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3938 in k4018 in k4012 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 996  string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[133]))(4,*((C_word*)lf[133]+1),t2,t1,lf[134]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3948 in k3938 in k4018 in k4012 in quote-option in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 996  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[124]+1)))(5,*((C_word*)lf[124]+1),((C_word*)t0)[2],lf[131],t1,lf[132]);}

/* linker-libraries in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3864(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3864,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3868(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3868(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3866 in linker-libraries in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3879,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3904,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3910,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}
else{
t4=t3;
f_3879(2,t4,C_SCHEME_END_OF_LIST);}}

/* a3909 in k3866 in linker-libraries in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3910(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3910r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3910r(t0,t1,t2);}}

static void C_ccall f_3910r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a3903 in k3866 in linker-libraries in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3904,2,t0,t1);}
/* csc.scm: 971  static-extension-info */
f_3715(t1);}

/* k3877 in k3866 in linker-libraries in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3883,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[97],"static");
if(C_truep(t3)){
t4=t2;
f_3883(t4,(C_truep(t3)?C_retrieve2(lf[79],"library-files"):C_retrieve2(lf[80],"shared-library-files")));}
else{
t4=C_retrieve2(lf[98],"static-libs");
t5=t2;
f_3883(t5,(C_truep(t4)?C_retrieve2(lf[79],"library-files"):C_retrieve2(lf[80],"shared-library-files")));}}

/* k3881 in k3877 in k3866 in linker-libraries in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3883,NULL,2,t0,t1);}
t2=C_retrieve2(lf[97],"static");
if(C_truep(t2)){
t3=(C_truep(t2)?(C_word)C_a_i_list(&a,1,C_retrieve2(lf[72],"extra-libraries")):(C_word)C_a_i_list(&a,1,C_retrieve2(lf[73],"extra-shared-libraries")));
/* csc.scm: 970  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[104]+1)))(5,*((C_word*)lf[104]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,t3);}
else{
t3=C_retrieve2(lf[98],"static-libs");
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,C_retrieve2(lf[72],"extra-libraries")):(C_word)C_a_i_list(&a,1,C_retrieve2(lf[73],"extra-shared-libraries")));
/* csc.scm: 970  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[104]+1)))(5,*((C_word*)lf[104]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,t4);}}

/* k3873 in k3866 in linker-libraries in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 969  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[102]))(3,*((C_word*)lf[102]+1),((C_word*)t0)[2],t1);}

/* linker-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3812(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3812,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3820,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3850,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3852,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3858,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a3857 in linker-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3858r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3858r(t0,t1,t2);}}

static void C_ccall f_3858r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a3851 in linker-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3852,2,t0,t1);}
/* csc.scm: 965  static-extension-info */
f_3715(t1);}

/* k3848 in linker-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 964  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[104]+1)))(5,*((C_word*)lf[104]+1),((C_word*)t0)[2],C_retrieve2(lf[87],"linking-optimization-options"),C_retrieve2(lf[89],"link-options"),t1);}

/* k3844 in linker-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 963  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[102]))(3,*((C_word*)lf[102]+1),((C_word*)t0)[2],t1);}

/* k3818 in linker-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3827,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[97],"static"))){
t3=lf[3];
if(C_truep(lf[3])){
t4=t2;
f_3827(t4,C_SCHEME_FALSE);}
else{
t4=C_retrieve2(lf[5],"msvc");
t5=t2;
f_3827(t5,(C_truep(C_retrieve2(lf[5],"msvc"))?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve2(lf[7],"osx"))));}}
else{
t3=t2;
f_3827(t3,C_SCHEME_FALSE);}}

/* k3825 in k3818 in linker-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3827(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm: 962  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[125]);}
else{
/* csc.scm: 962  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[124]+1)))(4,*((C_word*)lf[124]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[126]);}}

/* static-extension-info in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3715(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3715,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3719,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 946  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[122]))(2,*((C_word*)lf[122]+1),t2);}

/* k3717 in static-extension-info in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3719,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_pairp(C_retrieve2(lf[99],"static-extensions")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3730,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3730(t6,((C_word*)t0)[2],C_retrieve2(lf[99],"static-extensions"),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* csc.scm: 959  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* loop in k3717 in static-extension-info in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3730(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3730,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3744,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 950  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[118]+1)))(3,*((C_word*)lf[118]+1),t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3751,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
/* csc.scm: 951  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[121]))(3,*((C_word*)lf[121]+1),t5,t6);}}

/* k3749 in loop in k3717 in static-extension-info in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3751,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[119],t1);
t3=(C_word)C_i_assq(lf[120],t1);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3771,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3789,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
/* csc.scm: 956  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t6,((C_word*)t0)[2],t7);}
else{
t6=t5;
f_3771(t6,((C_word*)t0)[3]);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csc.scm: 958  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3730(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[6]);}}

/* k3787 in k3749 in loop in k3717 in static-extension-info in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3789,2,t0,t1);}
t2=((C_word*)t0)[3];
f_3771(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k3769 in k3749 in loop in k3717 in static-extension-info in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3771,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
/* csc.scm: 955  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3730(t4,((C_word*)t0)[3],((C_word*)t0)[2],t1,t3);}
else{
t2=((C_word*)t0)[5];
/* csc.scm: 955  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3730(t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}}

/* k3742 in loop in k3717 in static-extension-info in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3748,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm: 950  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[118]+1)))(3,*((C_word*)lf[118]+1),t2,((C_word*)t0)[2]);}

/* k3746 in k3742 in loop in k3717 in static-extension-info in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 950  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3675(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3675,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3683,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[116]))(2,*((C_word*)lf[116]+1),t4);}

/* k3681 in copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[49],"windows-shell"))){
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,lf[114],t1);}
else{
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,lf[115],t1);}}

/* k3684 in k3681 in copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[113]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k3687 in k3684 in k3681 in copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3692,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5133,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t5,t4);}

/* f5133 in k3687 in k3684 in k3681 in copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3707 in k3687 in k3684 in k3681 in copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3690 in k3687 in k3684 in k3681 in copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[113]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k3693 in k3690 in k3687 in k3684 in k3681 in copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3698,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5128,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t5,t4);}

/* f5128 in k3693 in k3690 in k3687 in k3684 in k3681 in copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f5128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* k3703 in k3693 in k3690 in k3687 in k3684 in k3681 in copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3696 in k3693 in k3690 in k3687 in k3684 in k3681 in copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3701,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[111]))(3,*((C_word*)lf[111]+1),t2,((C_word*)t0)[2]);}

/* k3699 in k3696 in k3693 in k3690 in k3687 in k3684 in k3681 in copy-files in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 937  command */
f_4093(((C_word*)t0)[2],t1);}

/* lib-path in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3626(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3626,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3634,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[8],"win"))){
/* ##sys#peek-c-string */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
if(C_truep(C_retrieve2(lf[20],"host-mode"))){
/* ##sys#peek-c-string */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}}

/* k3632 in lib-path in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3634,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep(C_retrieve2(lf[17],"chicken-prefix"))){
t3=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[17],"chicken-prefix"),lf[106]);
/* csc.scm: 82   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),t2,t3,lf[108]);}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* compiler-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3238(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3238,NULL,1,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3246,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3250,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=C_retrieve2(lf[97],"static");
t9=(C_truep(t8)?t8:C_retrieve2(lf[98],"static-libs"));
if(C_truep(t9)){
/* csc.scm: 850  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[104]+1)))(5,*((C_word*)lf[104]+1),t7,C_SCHEME_END_OF_LIST,C_retrieve2(lf[86],"compilation-optimization-options"),C_retrieve2(lf[84],"compile-options"));}
else{
/* csc.scm: 850  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[104]+1)))(5,*((C_word*)lf[104]+1),t7,C_SCHEME_END_OF_LIST,C_retrieve2(lf[86],"compilation-optimization-options"),C_retrieve2(lf[84],"compile-options"));}}

/* k3248 in compiler-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3250,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3252(t5,((C_word*)t0)[2],t1);}

/* loop522 in k3248 in compiler-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_3252(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3252,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve2(lf[103],"quote-option");
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3281,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g538539 */
t6=C_retrieve2(lf[103],"quote-option");
f_4007(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3279 in loop522 in k3248 in compiler-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3281,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop522535 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3252(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop522535 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3252(t6,((C_word*)t0)[3],t5);}}

/* k3244 in compiler-options in k1222 in k1214 in k1206 in k1193 in k4288 in k1184 in k4321 in k1176 in k1172 in k1143 in k1138 in k1134 in k1130 in k1125 in k1098 in k1094 in k1090 in k1086 in k1082 in k1078 in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 848  string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[102]))(3,*((C_word*)lf[102]+1),((C_word*)t0)[2],t1);}

/* quotewrap in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1068,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1076,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm: 86   normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t3,t2);}

/* k1074 in quotewrap in k1043 in k1039 in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 86   qs */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1);}

/* quit in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_fcall f_1022(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1022,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1026,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1033,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* csc.scm: 72   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[16]))(2,*((C_word*)lf[16]+1),t5);}

/* k1031 in quit in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k1035 in k1031 in quit in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 72   fprintf */
((C_proc7)C_retrieve_symbol_proc(lf[13]))(7,*((C_word*)lf[13]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[14],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1024 in quit in k4466 in k4470 in k4474 in k4478 in k998 in k995 in k992 in k989 in k986 in k983 in k980 in k977 in k974 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm: 73   exit */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[427] = {
{"toplevel:csc_scm",(void*)C_toplevel},
{"f_976:csc_scm",(void*)f_976},
{"f_979:csc_scm",(void*)f_979},
{"f_982:csc_scm",(void*)f_982},
{"f_985:csc_scm",(void*)f_985},
{"f_988:csc_scm",(void*)f_988},
{"f_991:csc_scm",(void*)f_991},
{"f_994:csc_scm",(void*)f_994},
{"f_997:csc_scm",(void*)f_997},
{"f_1000:csc_scm",(void*)f_1000},
{"f_4480:csc_scm",(void*)f_4480},
{"f_4476:csc_scm",(void*)f_4476},
{"f_4472:csc_scm",(void*)f_4472},
{"f_4468:csc_scm",(void*)f_4468},
{"f_1041:csc_scm",(void*)f_1041},
{"f_1045:csc_scm",(void*)f_1045},
{"f_4458:csc_scm",(void*)f_4458},
{"f5621:csc_scm",(void*)f5621},
{"f_4454:csc_scm",(void*)f_4454},
{"f5298:csc_scm",(void*)f5298},
{"f_1080:csc_scm",(void*)f_1080},
{"f_4446:csc_scm",(void*)f_4446},
{"f_4450:csc_scm",(void*)f_4450},
{"f_4442:csc_scm",(void*)f_4442},
{"f5617:csc_scm",(void*)f5617},
{"f_4438:csc_scm",(void*)f_4438},
{"f5293:csc_scm",(void*)f5293},
{"f_1084:csc_scm",(void*)f_1084},
{"f_4428:csc_scm",(void*)f_4428},
{"f5288:csc_scm",(void*)f5288},
{"f_1088:csc_scm",(void*)f_1088},
{"f_4418:csc_scm",(void*)f_4418},
{"f5283:csc_scm",(void*)f5283},
{"f_1092:csc_scm",(void*)f_1092},
{"f5278:csc_scm",(void*)f5278},
{"f_4405:csc_scm",(void*)f_4405},
{"f5273:csc_scm",(void*)f5273},
{"f_1096:csc_scm",(void*)f_1096},
{"f5268:csc_scm",(void*)f5268},
{"f_4392:csc_scm",(void*)f_4392},
{"f5263:csc_scm",(void*)f5263},
{"f_1100:csc_scm",(void*)f_1100},
{"f_1127:csc_scm",(void*)f_1127},
{"f_1132:csc_scm",(void*)f_1132},
{"f_1136:csc_scm",(void*)f_1136},
{"f_4371:csc_scm",(void*)f_4371},
{"f_1140:csc_scm",(void*)f_1140},
{"f_4361:csc_scm",(void*)f_4361},
{"f_1145:csc_scm",(void*)f_1145},
{"f_1174:csc_scm",(void*)f_1174},
{"f_1178:csc_scm",(void*)f_1178},
{"f_4335:csc_scm",(void*)f_4335},
{"f_4339:csc_scm",(void*)f_4339},
{"f_4331:csc_scm",(void*)f_4331},
{"f5613:csc_scm",(void*)f5613},
{"f_4327:csc_scm",(void*)f_4327},
{"f5258:csc_scm",(void*)f5258},
{"f_4323:csc_scm",(void*)f_4323},
{"f_4319:csc_scm",(void*)f_4319},
{"f_1186:csc_scm",(void*)f_1186},
{"f_4302:csc_scm",(void*)f_4302},
{"f_4306:csc_scm",(void*)f_4306},
{"f_4298:csc_scm",(void*)f_4298},
{"f5609:csc_scm",(void*)f5609},
{"f_4294:csc_scm",(void*)f_4294},
{"f5253:csc_scm",(void*)f5253},
{"f_4290:csc_scm",(void*)f_4290},
{"f_4286:csc_scm",(void*)f_4286},
{"f_1195:csc_scm",(void*)f_1195},
{"f_4273:csc_scm",(void*)f_4273},
{"f_1208:csc_scm",(void*)f_1208},
{"f_4262:csc_scm",(void*)f_4262},
{"f_1216:csc_scm",(void*)f_1216},
{"f_4249:csc_scm",(void*)f_4249},
{"f_1224:csc_scm",(void*)f_1224},
{"f_4242:csc_scm",(void*)f_4242},
{"f_4238:csc_scm",(void*)f_4238},
{"f_4234:csc_scm",(void*)f_4234},
{"f_1412:csc_scm",(void*)f_1412},
{"f_1649:csc_scm",(void*)f_1649},
{"f_2014:csc_scm",(void*)f_2014},
{"f_2215:csc_scm",(void*)f_2215},
{"f_2457:csc_scm",(void*)f_2457},
{"f_2460:csc_scm",(void*)f_2460},
{"f_2463:csc_scm",(void*)f_2463},
{"f_2884:csc_scm",(void*)f_2884},
{"f_2519:csc_scm",(void*)f_2519},
{"f_2528:csc_scm",(void*)f_2528},
{"f_2739:csc_scm",(void*)f_2739},
{"f_2847:csc_scm",(void*)f_2847},
{"f_2853:csc_scm",(void*)f_2853},
{"f_2750:csc_scm",(void*)f_2750},
{"f_2761:csc_scm",(void*)f_2761},
{"f_2837:csc_scm",(void*)f_2837},
{"f_2829:csc_scm",(void*)f_2829},
{"f_2812:csc_scm",(void*)f_2812},
{"f_2788:csc_scm",(void*)f_2788},
{"f_2793:csc_scm",(void*)f_2793},
{"f_2775:csc_scm",(void*)f_2775},
{"f_2744:csc_scm",(void*)f_2744},
{"f_2709:csc_scm",(void*)f_2709},
{"f_2606:csc_scm",(void*)f_2606},
{"f_2692:csc_scm",(void*)f_2692},
{"f_2688:csc_scm",(void*)f_2688},
{"f_2639:csc_scm",(void*)f_2639},
{"f_2677:csc_scm",(void*)f_2677},
{"f_2637:csc_scm",(void*)f_2637},
{"f_2633:csc_scm",(void*)f_2633},
{"f_2610:csc_scm",(void*)f_2610},
{"f_2596:csc_scm",(void*)f_2596},
{"f_2583:csc_scm",(void*)f_2583},
{"f_2566:csc_scm",(void*)f_2566},
{"f_2552:csc_scm",(void*)f_2552},
{"f_2538:csc_scm",(void*)f_2538},
{"f_2500:csc_scm",(void*)f_2500},
{"f_2506:csc_scm",(void*)f_2506},
{"f_2509:csc_scm",(void*)f_2509},
{"f_2470:csc_scm",(void*)f_2470},
{"f_2450:csc_scm",(void*)f_2450},
{"f_2454:csc_scm",(void*)f_2454},
{"f_2404:csc_scm",(void*)f_2404},
{"f_2434:csc_scm",(void*)f_2434},
{"f_2426:csc_scm",(void*)f_2426},
{"f_2414:csc_scm",(void*)f_2414},
{"f_2392:csc_scm",(void*)f_2392},
{"f_2367:csc_scm",(void*)f_2367},
{"f_2379:csc_scm",(void*)f_2379},
{"f_2371:csc_scm",(void*)f_2371},
{"f_2354:csc_scm",(void*)f_2354},
{"f_2328:csc_scm",(void*)f_2328},
{"f_2340:csc_scm",(void*)f_2340},
{"f_2332:csc_scm",(void*)f_2332},
{"f_2307:csc_scm",(void*)f_2307},
{"f_2311:csc_scm",(void*)f_2311},
{"f_2290:csc_scm",(void*)f_2290},
{"f_2273:csc_scm",(void*)f_2273},
{"f_2256:csc_scm",(void*)f_2256},
{"f_2239:csc_scm",(void*)f_2239},
{"f_2198:csc_scm",(void*)f_2198},
{"f_2188:csc_scm",(void*)f_2188},
{"f_2178:csc_scm",(void*)f_2178},
{"f_2148:csc_scm",(void*)f_2148},
{"f_2151:csc_scm",(void*)f_2151},
{"f_2168:csc_scm",(void*)f_2168},
{"f_2164:csc_scm",(void*)f_2164},
{"f_2138:csc_scm",(void*)f_2138},
{"f_2128:csc_scm",(void*)f_2128},
{"f_2118:csc_scm",(void*)f_2118},
{"f_2108:csc_scm",(void*)f_2108},
{"f_2087:csc_scm",(void*)f_2087},
{"f_2063:csc_scm",(void*)f_2063},
{"f_2074:csc_scm",(void*)f_2074},
{"f_2039:csc_scm",(void*)f_2039},
{"f_2032:csc_scm",(void*)f_2032},
{"f_1973:csc_scm",(void*)f_1973},
{"f_1977:csc_scm",(void*)f_1977},
{"f_1980:csc_scm",(void*)f_1980},
{"f_1941:csc_scm",(void*)f_1941},
{"f_1945:csc_scm",(void*)f_1945},
{"f_1948:csc_scm",(void*)f_1948},
{"f_1838:csc_scm",(void*)f_1838},
{"f_1823:csc_scm",(void*)f_1823},
{"f_1829:csc_scm",(void*)f_1829},
{"f_1803:csc_scm",(void*)f_1803},
{"f_1791:csc_scm",(void*)f_1791},
{"f_1779:csc_scm",(void*)f_1779},
{"f_1767:csc_scm",(void*)f_1767},
{"f_1741:csc_scm",(void*)f_1741},
{"f_1730:csc_scm",(void*)f_1730},
{"f_1699:csc_scm",(void*)f_1699},
{"f_1692:csc_scm",(void*)f_1692},
{"f_1683:csc_scm",(void*)f_1683},
{"f_1676:csc_scm",(void*)f_1676},
{"f_1283:csc_scm",(void*)f_1283},
{"f_1290:csc_scm",(void*)f_1290},
{"f_1664:csc_scm",(void*)f_1664},
{"f_1652:csc_scm",(void*)f_1652},
{"f_1423:csc_scm",(void*)f_1423},
{"f_1266:csc_scm",(void*)f_1266},
{"f_1238:csc_scm",(void*)f_1238},
{"f_1253:csc_scm",(void*)f_1253},
{"f_1246:csc_scm",(void*)f_1246},
{"f_1242:csc_scm",(void*)f_1242},
{"f_1427:csc_scm",(void*)f_1427},
{"f_1636:csc_scm",(void*)f_1636},
{"f_1603:csc_scm",(void*)f_1603},
{"f_1629:csc_scm",(void*)f_1629},
{"f_1606:csc_scm",(void*)f_1606},
{"f5244:csc_scm",(void*)f5244},
{"f_1622:csc_scm",(void*)f_1622},
{"f_1609:csc_scm",(void*)f_1609},
{"f_1612:csc_scm",(void*)f_1612},
{"f_1430:csc_scm",(void*)f_1430},
{"f_1566:csc_scm",(void*)f_1566},
{"f_1576:csc_scm",(void*)f_1576},
{"f_1569:csc_scm",(void*)f_1569},
{"f_2989:csc_scm",(void*)f_2989},
{"f_3001:csc_scm",(void*)f_3001},
{"f5238:csc_scm",(void*)f5238},
{"f_3032:csc_scm",(void*)f_3032},
{"f5233:csc_scm",(void*)f5233},
{"f_3094:csc_scm",(void*)f_3094},
{"f_3040:csc_scm",(void*)f_3040},
{"f_3048:csc_scm",(void*)f_3048},
{"f_3050:csc_scm",(void*)f_3050},
{"f_3079:csc_scm",(void*)f_3079},
{"f_3044:csc_scm",(void*)f_3044},
{"f_3036:csc_scm",(void*)f_3036},
{"f_3028:csc_scm",(void*)f_3028},
{"f_3024:csc_scm",(void*)f_3024},
{"f_3004:csc_scm",(void*)f_3004},
{"f_3008:csc_scm",(void*)f_3008},
{"f_3012:csc_scm",(void*)f_3012},
{"f_2958:csc_scm",(void*)f_2958},
{"f_2966:csc_scm",(void*)f_2966},
{"f_2976:csc_scm",(void*)f_2976},
{"f_1528:csc_scm",(void*)f_1528},
{"f_1531:csc_scm",(void*)f_1531},
{"f_1538:csc_scm",(void*)f_1538},
{"f_1433:csc_scm",(void*)f_1433},
{"f_1436:csc_scm",(void*)f_1436},
{"f_3171:csc_scm",(void*)f_3171},
{"f_3225:csc_scm",(void*)f_3225},
{"f_3179:csc_scm",(void*)f_3179},
{"f_3183:csc_scm",(void*)f_3183},
{"f5216:csc_scm",(void*)f5216},
{"f_3210:csc_scm",(void*)f_3210},
{"f5211:csc_scm",(void*)f5211},
{"f_3222:csc_scm",(void*)f_3222},
{"f_3214:csc_scm",(void*)f_3214},
{"f_3218:csc_scm",(void*)f_3218},
{"f_3198:csc_scm",(void*)f_3198},
{"f_3186:csc_scm",(void*)f_3186},
{"f_3132:csc_scm",(void*)f_3132},
{"f_3169:csc_scm",(void*)f_3169},
{"f_3136:csc_scm",(void*)f_3136},
{"f_3144:csc_scm",(void*)f_3144},
{"f_3154:csc_scm",(void*)f_3154},
{"f_1442:csc_scm",(void*)f_1442},
{"f_1457:csc_scm",(void*)f_1457},
{"f_1460:csc_scm",(void*)f_1460},
{"f_1463:csc_scm",(void*)f_1463},
{"f_1466:csc_scm",(void*)f_1466},
{"f_1469:csc_scm",(void*)f_1469},
{"f_1472:csc_scm",(void*)f_1472},
{"f_1479:csc_scm",(void*)f_1479},
{"f_1482:csc_scm",(void*)f_1482},
{"f_1485:csc_scm",(void*)f_1485},
{"f5204:csc_scm",(void*)f5204},
{"f_1509:csc_scm",(void*)f_1509},
{"f_1488:csc_scm",(void*)f_1488},
{"f_1491:csc_scm",(void*)f_1491},
{"f_1505:csc_scm",(void*)f_1505},
{"f5199:csc_scm",(void*)f5199},
{"f_1501:csc_scm",(void*)f_1501},
{"f_1494:csc_scm",(void*)f_1494},
{"f_1497:csc_scm",(void*)f_1497},
{"f_1448:csc_scm",(void*)f_1448},
{"f_3620:csc_scm",(void*)f_3620},
{"f_3614:csc_scm",(void*)f_3614},
{"f_3612:csc_scm",(void*)f_3612},
{"f_3573:csc_scm",(void*)f_3573},
{"f_3575:csc_scm",(void*)f_3575},
{"f5192:csc_scm",(void*)f5192},
{"f_3604:csc_scm",(void*)f_3604},
{"f_3298:csc_scm",(void*)f_3298},
{"f5187:csc_scm",(void*)f5187},
{"f_3301:csc_scm",(void*)f_3301},
{"f_3471:csc_scm",(void*)f_3471},
{"f_3521:csc_scm",(void*)f_3521},
{"f_3552:csc_scm",(void*)f_3552},
{"f_3555:csc_scm",(void*)f_3555},
{"f_3569:csc_scm",(void*)f_3569},
{"f5182:csc_scm",(void*)f5182},
{"f_3565:csc_scm",(void*)f_3565},
{"f_3558:csc_scm",(void*)f_3558},
{"f_3561:csc_scm",(void*)f_3561},
{"f_3524:csc_scm",(void*)f_3524},
{"f_3531:csc_scm",(void*)f_3531},
{"f_3534:csc_scm",(void*)f_3534},
{"f_3548:csc_scm",(void*)f_3548},
{"f5177:csc_scm",(void*)f5177},
{"f_3544:csc_scm",(void*)f_3544},
{"f_3537:csc_scm",(void*)f_3537},
{"f_3540:csc_scm",(void*)f_3540},
{"f_3474:csc_scm",(void*)f_3474},
{"f_3511:csc_scm",(void*)f_3511},
{"f_3501:csc_scm",(void*)f_3501},
{"f_3478:csc_scm",(void*)f_3478},
{"f5172:csc_scm",(void*)f5172},
{"f_3482:csc_scm",(void*)f_3482},
{"f_3488:csc_scm",(void*)f_3488},
{"f_3491:csc_scm",(void*)f_3491},
{"f_3304:csc_scm",(void*)f_3304},
{"f5167:csc_scm",(void*)f5167},
{"f_3467:csc_scm",(void*)f_3467},
{"f_3455:csc_scm",(void*)f_3455},
{"f_3459:csc_scm",(void*)f_3459},
{"f_3463:csc_scm",(void*)f_3463},
{"f_3447:csc_scm",(void*)f_3447},
{"f_3439:csc_scm",(void*)f_3439},
{"f_3435:csc_scm",(void*)f_3435},
{"f_3307:csc_scm",(void*)f_3307},
{"f_3381:csc_scm",(void*)f_3381},
{"f_3425:csc_scm",(void*)f_3425},
{"f_3415:csc_scm",(void*)f_3415},
{"f5162:csc_scm",(void*)f5162},
{"f_3408:csc_scm",(void*)f_3408},
{"f_3400:csc_scm",(void*)f_3400},
{"f_3384:csc_scm",(void*)f_3384},
{"f_4132:csc_scm",(void*)f_4132},
{"f_4135:csc_scm",(void*)f_4135},
{"f5157:csc_scm",(void*)f5157},
{"f_4159:csc_scm",(void*)f_4159},
{"f_4138:csc_scm",(void*)f_4138},
{"f_4141:csc_scm",(void*)f_4141},
{"f_4155:csc_scm",(void*)f_4155},
{"f5152:csc_scm",(void*)f5152},
{"f_4151:csc_scm",(void*)f_4151},
{"f_4144:csc_scm",(void*)f_4144},
{"f_4147:csc_scm",(void*)f_4147},
{"f_3310:csc_scm",(void*)f_3310},
{"f_3345:csc_scm",(void*)f_3345},
{"f_3365:csc_scm",(void*)f_3365},
{"f_3659:csc_scm",(void*)f_3659},
{"f_3667:csc_scm",(void*)f_3667},
{"f_3652:csc_scm",(void*)f_3652},
{"f_3348:csc_scm",(void*)f_3348},
{"f_3361:csc_scm",(void*)f_3361},
{"f_4165:csc_scm",(void*)f_4165},
{"f_4168:csc_scm",(void*)f_4168},
{"f_4171:csc_scm",(void*)f_4171},
{"f_4174:csc_scm",(void*)f_4174},
{"f_4214:csc_scm",(void*)f_4214},
{"f_4221:csc_scm",(void*)f_4221},
{"f_4177:csc_scm",(void*)f_4177},
{"f_4180:csc_scm",(void*)f_4180},
{"f_4186:csc_scm",(void*)f_4186},
{"f_4191:csc_scm",(void*)f_4191},
{"f_4199:csc_scm",(void*)f_4199},
{"f_4183:csc_scm",(void*)f_4183},
{"f_3313:csc_scm",(void*)f_3313},
{"f_3321:csc_scm",(void*)f_3321},
{"f_3331:csc_scm",(void*)f_3331},
{"f_1395:csc_scm",(void*)f_1395},
{"f_1369:csc_scm",(void*)f_1369},
{"f_1374:csc_scm",(void*)f_1374},
{"f_1378:csc_scm",(void*)f_1378},
{"f_1330:csc_scm",(void*)f_1330},
{"f_1348:csc_scm",(void*)f_1348},
{"f_1323:csc_scm",(void*)f_1323},
{"f_1328:csc_scm",(void*)f_1328},
{"f_4224:csc_scm",(void*)f_4224},
{"f_4230:csc_scm",(void*)f_4230},
{"f_4227:csc_scm",(void*)f_4227},
{"f_4109:csc_scm",(void*)f_4109},
{"f_4113:csc_scm",(void*)f_4113},
{"f_4093:csc_scm",(void*)f_4093},
{"f_4048:csc_scm",(void*)f_4048},
{"f_4051:csc_scm",(void*)f_4051},
{"f_4054:csc_scm",(void*)f_4054},
{"f_4070:csc_scm",(void*)f_4070},
{"f_4073:csc_scm",(void*)f_4073},
{"f_4076:csc_scm",(void*)f_4076},
{"f_4079:csc_scm",(void*)f_4079},
{"f_4057:csc_scm",(void*)f_4057},
{"f_4007:csc_scm",(void*)f_4007},
{"f_4037:csc_scm",(void*)f_4037},
{"f_4014:csc_scm",(void*)f_4014},
{"f_4025:csc_scm",(void*)f_4025},
{"f_4020:csc_scm",(void*)f_4020},
{"f_3958:csc_scm",(void*)f_3958},
{"f_3960:csc_scm",(void*)f_3960},
{"f_3990:csc_scm",(void*)f_3990},
{"f_3997:csc_scm",(void*)f_3997},
{"f_3983:csc_scm",(void*)f_3983},
{"f_3954:csc_scm",(void*)f_3954},
{"f_3940:csc_scm",(void*)f_3940},
{"f_3950:csc_scm",(void*)f_3950},
{"f_3864:csc_scm",(void*)f_3864},
{"f_3868:csc_scm",(void*)f_3868},
{"f_3910:csc_scm",(void*)f_3910},
{"f_3904:csc_scm",(void*)f_3904},
{"f_3879:csc_scm",(void*)f_3879},
{"f_3883:csc_scm",(void*)f_3883},
{"f_3875:csc_scm",(void*)f_3875},
{"f_3812:csc_scm",(void*)f_3812},
{"f_3858:csc_scm",(void*)f_3858},
{"f_3852:csc_scm",(void*)f_3852},
{"f_3850:csc_scm",(void*)f_3850},
{"f_3846:csc_scm",(void*)f_3846},
{"f_3820:csc_scm",(void*)f_3820},
{"f_3827:csc_scm",(void*)f_3827},
{"f_3715:csc_scm",(void*)f_3715},
{"f_3719:csc_scm",(void*)f_3719},
{"f_3730:csc_scm",(void*)f_3730},
{"f_3751:csc_scm",(void*)f_3751},
{"f_3789:csc_scm",(void*)f_3789},
{"f_3771:csc_scm",(void*)f_3771},
{"f_3744:csc_scm",(void*)f_3744},
{"f_3748:csc_scm",(void*)f_3748},
{"f_3675:csc_scm",(void*)f_3675},
{"f_3683:csc_scm",(void*)f_3683},
{"f_3686:csc_scm",(void*)f_3686},
{"f_3689:csc_scm",(void*)f_3689},
{"f5133:csc_scm",(void*)f5133},
{"f_3709:csc_scm",(void*)f_3709},
{"f_3692:csc_scm",(void*)f_3692},
{"f_3695:csc_scm",(void*)f_3695},
{"f5128:csc_scm",(void*)f5128},
{"f_3705:csc_scm",(void*)f_3705},
{"f_3698:csc_scm",(void*)f_3698},
{"f_3701:csc_scm",(void*)f_3701},
{"f_3626:csc_scm",(void*)f_3626},
{"f_3634:csc_scm",(void*)f_3634},
{"f_3238:csc_scm",(void*)f_3238},
{"f_3250:csc_scm",(void*)f_3250},
{"f_3252:csc_scm",(void*)f_3252},
{"f_3281:csc_scm",(void*)f_3281},
{"f_3246:csc_scm",(void*)f_3246},
{"f_1068:csc_scm",(void*)f_1068},
{"f_1076:csc_scm",(void*)f_1076},
{"f_1022:csc_scm",(void*)f_1022},
{"f_1033:csc_scm",(void*)f_1033},
{"f_1037:csc_scm",(void*)f_1037},
{"f_1026:csc_scm",(void*)f_1026},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
