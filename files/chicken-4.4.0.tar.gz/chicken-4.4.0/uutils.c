/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:17
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: utils.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file uutils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[60];
static double C_possibly_force_alignment;


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_207)
static void C_ccall f_207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_210)
static void C_ccall f_210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_213)
static void C_ccall f_213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_216)
static void C_ccall f_216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_219)
static void C_ccall f_219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_222)
static void C_ccall f_222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_396)
static void C_ccall f_396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_399)
static void C_ccall f_399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_597)
static void C_ccall f_597(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_597)
static void C_ccall f_597r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_609)
static void C_fcall f_609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_613)
static void C_ccall f_613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_622)
static void C_ccall f_622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_636)
static void C_ccall f_636(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_644)
static void C_ccall f_644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_594)
static void C_ccall f_594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_407)
static void C_ccall f_407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_591)
static void C_ccall f_591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_589)
static void C_ccall f_589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_419)
static void C_ccall f_419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_579)
static void C_ccall f_579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_547)
static void C_ccall f_547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_575)
static void C_ccall f_575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_571)
static void C_ccall f_571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_551)
static void C_ccall f_551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_555)
static void C_ccall f_555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_559)
static void C_ccall f_559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_428)
static void C_ccall f_428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_493)
static void C_ccall f_493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_502)
static void C_ccall f_502(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_517)
static void C_ccall f_517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_529)
static void C_ccall f_529(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_529)
static void C_ccall f_529r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_535)
static void C_ccall f_535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_523)
static void C_ccall f_523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_508)
static void C_ccall f_508(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_514)
static void C_ccall f_514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_497)
static void C_ccall f_497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_431)
static void C_ccall f_431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_445)
static void C_ccall f_445(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_466)
static void C_ccall f_466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_478)
static void C_ccall f_478(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_478)
static void C_ccall f_478r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_484)
static void C_ccall f_484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_472)
static void C_ccall f_472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_476)
static void C_ccall f_476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_451)
static void C_ccall f_451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_457)
static void C_ccall f_457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_461)
static void C_ccall f_461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_440)
static void C_ccall f_440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_278)
static void C_ccall f_278(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_278)
static void C_ccall f_278r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_282)
static void C_ccall f_282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_311)
static void C_ccall f_311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_313)
static void C_fcall f_313(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_362)
static void C_fcall f_362(C_word t0,C_word t1) C_noret;
C_noret_decl(f_307)
static void C_ccall f_307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_242)
static void C_ccall f_242(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_242)
static void C_ccall f_242r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_252)
static void C_ccall f_252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_260)
static void C_ccall f_260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_224)
static void C_ccall f_224(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_224)
static void C_ccall f_224r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_228)
static void C_ccall f_228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_231)
static void C_ccall f_231(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_609)
static void C_fcall trf_609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_609(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_609(t0,t1);}

C_noret_decl(trf_313)
static void C_fcall trf_313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_313(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_313(t0,t1,t2);}

C_noret_decl(trf_362)
static void C_fcall trf_362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_362(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_362(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(528)){
C_save(t1);
C_rereclaim2(528*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,60);
lf[0]=C_h_intern(&lf[0],7,"sprintf");
lf[1]=C_h_intern(&lf[1],6,"system");
lf[2]=C_h_intern(&lf[2],7,"system*");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[5]=C_h_intern(&lf[5],8,"read-all");
lf[6]=C_h_intern(&lf[6],18,"\003sysstandard-input");
lf[7]=C_h_intern(&lf[7],20,"\003sysread-string/port");
lf[8]=C_h_intern(&lf[8],11,"read-string");
lf[9]=C_h_intern(&lf[9],20,"with-input-from-file");
lf[10]=C_h_intern(&lf[10],5,"port\077");
lf[11]=C_h_intern(&lf[11],2,"qs");
lf[12]=C_h_intern(&lf[12],7,"mingw32");
lf[13]=C_h_intern(&lf[13],4,"msvc");
lf[14]=C_h_intern(&lf[14],13,"string-append");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\002\047\047");
lf[18]=C_h_intern(&lf[18],18,"string-concatenate");
lf[19]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000#\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000`\376\003\000\000\002\376\377\012\000\000\264\376\003\000\000\002\376\377\012\000\000~\376\003\000\000\002\376\377\012\000\000&\376\003\000"
"\000\002\376\377\012\000\000%\376\003\000\000\002\376\377\012\000\000$\376\003\000\000\002\376\377\012\000\000!\376\003\000\000\002\376\377\012\000\000*\376\003\000\000\002\376\377\012\000\000;\376\003\000\000\002\376\377\012\000\000<\376\003\000\000\002\376\377\012\000\000>\376\003\000\000\002\376"
"\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000(\376\003\000\000\002\376\377\012\000\000)\376\003\000\000\002\376\377\012\000\000[\376\003\000\000\002\376\377\012\000\000]\376\003\000\000\002\376\377\012\000\000{\376\003\000\000\002\376\377\012\000\000}\376\377\016");
lf[20]=C_h_intern(&lf[20],16,"\003sysstring->list");
lf[21]=C_h_intern(&lf[21],14,"build-platform");
lf[22]=C_h_intern(&lf[22],20,"compile-file-options");
lf[23]=C_h_intern(&lf[23],4,"load");
lf[24]=C_h_intern(&lf[24],12,"compile-file");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007mingw32\376\003\000\000\002\376\001\000\000\004msvc\376\377\016");
lf[27]=C_h_intern(&lf[27],5,"abort");
lf[28]=C_h_intern(&lf[28],12,"delete-file*");
lf[29]=C_h_intern(&lf[29],22,"with-exception-handler");
lf[30]=C_h_intern(&lf[30],30,"call-with-current-continuation");
lf[31]=C_h_intern(&lf[31],7,"on-exit");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\025~a~a -s ~a ~a -o ~a~a");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[37]=C_h_intern(&lf[37],18,"string-intersperse");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[39]=C_h_intern(&lf[39],6,"append");
lf[40]=C_h_intern(&lf[40],5,"print");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\014; compiling ");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[43]=C_h_intern(&lf[43],21,"create-temporary-file");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[45]=C_h_intern(&lf[45],12,"file-exists\077");
lf[46]=C_h_intern(&lf[46],13,"make-pathname");
lf[47]=C_h_intern(&lf[47],15,"\003sysget-keyword");
lf[48]=C_h_intern(&lf[48],5,"\000load");
lf[49]=C_h_intern(&lf[49],12,"\000output-file");
lf[50]=C_h_intern(&lf[50],8,"\000options");
lf[51]=C_h_intern(&lf[51],6,"regexp");
lf[52]=C_h_intern(&lf[52],9,"read-line");
lf[53]=C_h_intern(&lf[53],13,"string-search");
lf[54]=C_h_intern(&lf[54],16,"scan-input-lines");
lf[55]=C_h_intern(&lf[55],17,"\003syspeek-c-string");
lf[56]=C_h_intern(&lf[56],14,"make-parameter");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-S\376\003\000\000\002\376B\000\000\003-O2\376\003\000\000\002\376B\000\000\003-d2\376\377\016");
lf[58]=C_h_intern(&lf[58],17,"register-feature!");
lf[59]=C_h_intern(&lf[59],5,"utils");
C_register_lf2(lf,60,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_207,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k205 */
static void C_ccall f_207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k208 in k205 */
static void C_ccall f_210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_213,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k211 in k208 in k205 */
static void C_ccall f_213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k214 in k211 in k208 in k205 */
static void C_ccall f_216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_222,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 52   register-feature! */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[59]);}

/* k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_222,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=*((C_word*)lf[1]+1);
t4=C_mutate((C_word*)lf[2]+1 /* (set! system* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_224,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[5]+1 /* (set! read-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_242,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[11]+1 /* (set! qs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_278,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 97   make-parameter */
t8=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[57]);}

/* k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=C_mutate((C_word*)lf[22]+1 /* (set! compile-file-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_399,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}

/* k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_399,2,t0,t1);}
t2=*((C_word*)lf[23]+1);
t3=C_mutate((C_word*)lf[24]+1 /* (set! compile-file ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_400,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t4=*((C_word*)lf[51]+1);
t5=*((C_word*)lf[52]+1);
t6=*((C_word*)lf[53]+1);
t7=C_mutate((C_word*)lf[54]+1 /* (set! scan-input-lines ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_597,a[2]=t5,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}

/* scan-input-lines in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_597(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3rv,(void*)f_597r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_597r(t0,t1,t2,t3);}}

static void C_ccall f_597r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?*((C_word*)lf[6]+1):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_closurep(t2);
t7=(C_truep(t6)?t2:(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_636,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_609,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_609(t11,t1);}

/* loop in scan-input-lines in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_fcall f_609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_609,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_613,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 141  read-line */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k611 in loop in scan-input-lines in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_613,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_622,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 143  rx */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k620 in k611 in loop in scan-input-lines in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* utils.scm: 144  loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_609(t2,((C_word*)t0)[3]);}}

/* f_636 in scan-input-lines in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_636(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_636,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_644,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 139  regexp */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k642 */
static void C_ccall f_644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g176177 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_400(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_400r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_400r(t0,t1,t2,t3);}}

static void C_ccall f_400r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_404,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_594,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[50],t3,t5);}

/* a593 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_594,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#get-keyword */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[49],((C_word*)t0)[2]);}

/* k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_591,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[48],((C_word*)t0)[2],t3);}

/* a590 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_591,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_589,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 104  make-pathname */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k587 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 104  file-exists? */
t2=*((C_word*)lf[45]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_413,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[25]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_419,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)t0)[6];
if(C_truep(t4)){
t5=t3;
f_419(2,t5,C_SCHEME_FALSE);}
else{
/* utils.scm: 105  create-temporary-file */
t5=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,lf[44]);}}

/* k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* utils.scm: 106  build-platform */
t3=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_579,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,lf[26]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* utils.scm: 107  print */
t4=*((C_word*)lf[40]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[41],((C_word*)t0)[4],lf[42]);}

/* k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_428,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(((C_word*)t0)[5])?lf[32]:lf[33]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* utils.scm: 111  qs */
t5=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k545 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_551,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_571,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_575,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 112  compile-file-options */
t5=*((C_word*)lf[22]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k573 in k545 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 112  append */
t2=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k569 in k545 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 112  string-intersperse */
t2=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[38]);}

/* k549 in k545 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* utils.scm: 113  qs */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k553 in k549 in k545 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_559,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[3];
/* utils.scm: 114  qs */
t4=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=((C_word*)t0)[2];
/* utils.scm: 114  qs */
t4=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* k557 in k553 in k549 in k545 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[7])){
/* utils.scm: 108  system* */
t2=*((C_word*)lf[2]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[6],lf[34],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[35]);}
else{
/* utils.scm: 108  system* */
t2=*((C_word*)lf[2]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[6],lf[34],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[36]);}}

/* k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_431(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_493,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 117  on-exit */
t4=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a492 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_497,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_502,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a501 in a492 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_502(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_502,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_508,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_517,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a516 in a501 in a492 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_523,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_529,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a528 in a516 in a501 in a492 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_529(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_529r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_529r(t0,t1,t2);}}

static void C_ccall f_529r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_535,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k123128 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a534 in a528 in a516 in a501 in a492 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_535,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a522 in a516 in a501 in a492 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_523,2,t0,t1);}
/* utils.scm: 119  delete-file* */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a507 in a501 in a492 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_508(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_508,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_514,tmp=(C_word)a,a+=2,tmp);
/* k123128 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a513 in a507 in a501 in a492 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_514,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k495 in a492 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g126127 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k429 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_431,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_440,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_445,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* a444 in k429 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_445(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_445,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_451,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_466,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a465 in a444 in k429 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_472,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_478,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a477 in a465 in a444 in k429 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_478(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_478r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_478r(t0,t1,t2);}}

static void C_ccall f_478r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_484,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k139144 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a483 in a477 in a465 in a444 in k429 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_484,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a471 in a465 in a444 in k429 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_476,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 126  load-file */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k474 in a471 in a465 in a444 in k429 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a450 in a444 in k429 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_451,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_457,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k139144 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a456 in a450 in a444 in k429 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_461,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 124  delete-file* */
t3=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k459 in a456 in a450 in a444 in k429 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 125  abort */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k438 in k429 in k426 in k423 in k577 in k417 in k411 in k408 in k405 in k402 in compile-file in k397 in k394 in k390 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g142143 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_278(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_278r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_278r(t0,t1,t2,t3);}}

static void C_ccall f_278r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_282,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
/* utils.scm: 78   build-platform */
t5=*((C_word*)lf[21]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t4;
f_282(2,t5,(C_word)C_slot(t3,C_fix(0)));}}

/* k280 in qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_282,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[12]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[13]));
if(C_truep(t3)){
/* utils.scm: 81   string-append */
t4=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],lf[16]);}
else{
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[2]));
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[17]);}
else{
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_307,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_311,a[2]=t10,a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* string->list */
t12=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[2]);}}}

/* k309 in k280 in qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_311,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_313,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_313(t5,((C_word*)t0)[2],t1);}

/* loop58 in k309 in k280 in qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_fcall f_313(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_313,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_362,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_u_i_char_whitespacep(t4);
if(C_truep(t5)){
t6=t3;
f_362(t6,(C_truep(t5)?(C_word)C_a_i_string(&a,2,C_make_character(92),t4):(C_word)C_a_i_string(&a,1,t4)));}
else{
t6=(C_word)C_u_i_memq(t4,lf[19]);
t7=t3;
f_362(t7,(C_truep(t6)?(C_word)C_a_i_string(&a,2,C_make_character(92),t4):(C_word)C_a_i_string(&a,1,t4)));}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k360 in loop58 in k309 in k280 in qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_fcall f_362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_362,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop5871 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_313(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop5871 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_313(t6,((C_word*)t0)[3],t5);}}

/* k305 in k280 in qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 85   string-concatenate */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* read-all in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_242(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_242r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_242r(t0,t1,t2);}}

static void C_ccall f_242r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?*((C_word*)lf[6]+1):(C_word)C_slot(t2,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_252,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 71   port? */
t6=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k250 in read-all in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_252,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_260,tmp=(C_word)a,a+=2,tmp);
/* utils.scm: 73   with-input-from-file */
t3=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a259 in k250 in read-all in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_260,2,t0,t1);}
t2=*((C_word*)lf[8]+1);
/* g3031 */
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,C_SCHEME_FALSE);}

/* system* in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_224(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_224r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_224r(t0,t1,t2,t3);}}

static void C_ccall f_224r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_228,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k226 in system* in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_231,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 62   system */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k229 in k226 in system* in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* utils.scm: 64   ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[4],((C_word*)t0)[2],t1);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[67] = {
{"toplevel:utils_scm",(void*)C_utils_toplevel},
{"f_207:utils_scm",(void*)f_207},
{"f_210:utils_scm",(void*)f_210},
{"f_213:utils_scm",(void*)f_213},
{"f_216:utils_scm",(void*)f_216},
{"f_219:utils_scm",(void*)f_219},
{"f_222:utils_scm",(void*)f_222},
{"f_392:utils_scm",(void*)f_392},
{"f_396:utils_scm",(void*)f_396},
{"f_399:utils_scm",(void*)f_399},
{"f_597:utils_scm",(void*)f_597},
{"f_609:utils_scm",(void*)f_609},
{"f_613:utils_scm",(void*)f_613},
{"f_622:utils_scm",(void*)f_622},
{"f_636:utils_scm",(void*)f_636},
{"f_644:utils_scm",(void*)f_644},
{"f_400:utils_scm",(void*)f_400},
{"f_594:utils_scm",(void*)f_594},
{"f_404:utils_scm",(void*)f_404},
{"f_407:utils_scm",(void*)f_407},
{"f_591:utils_scm",(void*)f_591},
{"f_410:utils_scm",(void*)f_410},
{"f_589:utils_scm",(void*)f_589},
{"f_413:utils_scm",(void*)f_413},
{"f_419:utils_scm",(void*)f_419},
{"f_579:utils_scm",(void*)f_579},
{"f_425:utils_scm",(void*)f_425},
{"f_547:utils_scm",(void*)f_547},
{"f_575:utils_scm",(void*)f_575},
{"f_571:utils_scm",(void*)f_571},
{"f_551:utils_scm",(void*)f_551},
{"f_555:utils_scm",(void*)f_555},
{"f_559:utils_scm",(void*)f_559},
{"f_428:utils_scm",(void*)f_428},
{"f_493:utils_scm",(void*)f_493},
{"f_502:utils_scm",(void*)f_502},
{"f_517:utils_scm",(void*)f_517},
{"f_529:utils_scm",(void*)f_529},
{"f_535:utils_scm",(void*)f_535},
{"f_523:utils_scm",(void*)f_523},
{"f_508:utils_scm",(void*)f_508},
{"f_514:utils_scm",(void*)f_514},
{"f_497:utils_scm",(void*)f_497},
{"f_431:utils_scm",(void*)f_431},
{"f_445:utils_scm",(void*)f_445},
{"f_466:utils_scm",(void*)f_466},
{"f_478:utils_scm",(void*)f_478},
{"f_484:utils_scm",(void*)f_484},
{"f_472:utils_scm",(void*)f_472},
{"f_476:utils_scm",(void*)f_476},
{"f_451:utils_scm",(void*)f_451},
{"f_457:utils_scm",(void*)f_457},
{"f_461:utils_scm",(void*)f_461},
{"f_440:utils_scm",(void*)f_440},
{"f_278:utils_scm",(void*)f_278},
{"f_282:utils_scm",(void*)f_282},
{"f_311:utils_scm",(void*)f_311},
{"f_313:utils_scm",(void*)f_313},
{"f_362:utils_scm",(void*)f_362},
{"f_307:utils_scm",(void*)f_307},
{"f_242:utils_scm",(void*)f_242},
{"f_252:utils_scm",(void*)f_252},
{"f_260:utils_scm",(void*)f_260},
{"f_224:utils_scm",(void*)f_224},
{"f_228:utils_scm",(void*)f_228},
{"f_231:utils_scm",(void*)f_231},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
