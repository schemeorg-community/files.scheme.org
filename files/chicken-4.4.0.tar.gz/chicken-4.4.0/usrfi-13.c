/* Generated from srfi-13.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: srfi-13.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file usrfi-13.c
   unit: srfi_13
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_14_toplevel)
C_externimport void C_ccall C_srfi_14_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[155];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_13_toplevel)
C_externexport void C_ccall C_srfi_13_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8394)
static void C_ccall f_8394(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8394)
static void C_ccall f_8394r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8503)
static void C_ccall f_8503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8473)
static void C_ccall f_8473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8456)
static void C_ccall f_8456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8411)
static void C_fcall f_8411(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8417)
static void C_fcall f_8417(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8439)
static void C_ccall f_8439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8321)
static void C_fcall f_8321(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8392)
static void C_ccall f_8392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8352)
static void C_fcall f_8352(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8181)
static void C_ccall f_8181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_8181)
static void C_ccall f_8181r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_8234)
static void C_ccall f_8234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8300)
static void C_ccall f_8300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8296)
static void C_ccall f_8296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8190)
static void C_ccall f_8190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8212)
static void C_ccall f_8212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8202)
static void C_ccall f_8202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8043)
static void C_ccall f_8043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8043)
static void C_ccall f_8043r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8096)
static void C_ccall f_8096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8159)
static void C_ccall f_8159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8162)
static void C_ccall f_8162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8156)
static void C_ccall f_8156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8152)
static void C_ccall f_8152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8052)
static void C_ccall f_8052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8074)
static void C_ccall f_8074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8064)
static void C_ccall f_8064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7951)
static void C_ccall f_7951(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7951)
static void C_ccall f_7951r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7969)
static void C_ccall f_7969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7975)
static void C_fcall f_7975(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7979)
static void C_ccall f_7979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7983)
static void C_fcall f_7983(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8020)
static void C_ccall f_8020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7994)
static void C_fcall f_7994(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8006)
static void C_ccall f_8006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7963)
static void C_ccall f_7963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7900)
static void C_ccall f_7900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_7900)
static void C_ccall f_7900r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7915)
static void C_ccall f_7915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7857)
static void C_fcall f_7857(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7861)
static void C_ccall f_7861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static C_word C_fcall f_7869(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7755)
static void C_fcall f_7755(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7805)
static void C_fcall f_7805(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7646)
static void C_ccall f_7646r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7673)
static C_word C_fcall f_7673(C_word t0,C_word t1);
C_noret_decl(f_7573)
static void C_ccall f_7573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7580)
static void C_ccall f_7580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7585)
static C_word C_fcall f_7585(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7614)
static C_word C_fcall f_7614(C_word t0,C_word t1);
C_noret_decl(f_7471)
static void C_ccall f_7471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7477)
static void C_fcall f_7477(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7531)
static void C_ccall f_7531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static C_word C_fcall f_7536(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7465)
static void C_ccall f_7465(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7465)
static void C_ccall f_7465r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7419)
static void C_ccall f_7419r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7441)
static void C_fcall f_7441(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7425)
static void C_ccall f_7425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7376)
static void C_ccall f_7376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7386)
static C_word C_fcall f_7386(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7370)
static void C_ccall f_7370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7309)
static void C_ccall f_7309(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7309)
static void C_ccall f_7309r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7321)
static void C_ccall f_7321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7328)
static void C_ccall f_7328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7337)
static C_word C_fcall f_7337(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7315)
static void C_ccall f_7315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7306)
static void C_ccall f_7306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_7185)
static void C_ccall f_7185r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_7209)
static void C_ccall f_7209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7218)
static void C_fcall f_7218(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7250)
static void C_fcall f_7250(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7257)
static void C_ccall f_7257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7248)
static void C_ccall f_7248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7203)
static void C_ccall f_7203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7153)
static void C_fcall f_7153(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7012)
static void C_ccall f_7012(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7012)
static void C_ccall f_7012r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7030)
static void C_ccall f_7030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7037)
static void C_ccall f_7037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7054)
static void C_fcall f_7054(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7069)
static void C_fcall f_7069(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7102)
static void C_ccall f_7102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7096)
static void C_ccall f_7096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7024)
static void C_ccall f_7024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6950)
static void C_ccall f_6950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6950)
static void C_ccall f_6950r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6986)
static void C_fcall f_6986(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6968)
static void C_ccall f_6968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6888)
static void C_ccall f_6888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6888)
static void C_ccall f_6888r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6900)
static void C_ccall f_6900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6924)
static void C_fcall f_6924(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6937)
static void C_ccall f_6937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6894)
static void C_ccall f_6894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6853)
static void C_ccall f_6853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6853)
static void C_ccall f_6853r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6812)
static void C_ccall f_6812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6812)
static void C_ccall f_6812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6824)
static void C_ccall f_6824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6834)
static C_word C_fcall f_6834(C_word t0,C_word t1);
C_noret_decl(f_6818)
static void C_ccall f_6818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6677)
static void C_ccall f_6677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6677)
static void C_ccall f_6677r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6689)
static void C_ccall f_6689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6735)
static void C_ccall f_6735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6779)
static void C_fcall f_6779(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6740)
static void C_fcall f_6740(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6701)
static C_word C_fcall f_6701(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_6683)
static void C_ccall f_6683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6648)
static void C_fcall f_6648(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6609)
static void C_fcall f_6609(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6570)
static C_word C_fcall f_6570(C_word t0,C_word t1);
C_noret_decl(f_6548)
static void C_ccall f_6548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6513)
static void C_fcall f_6513(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6478)
static void C_fcall f_6478(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6443)
static C_word C_fcall f_6443(C_word t0,C_word t1);
C_noret_decl(f_6425)
static void C_ccall f_6425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6284)
static void C_ccall f_6284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6284)
static void C_ccall f_6284r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6296)
static void C_ccall f_6296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_fcall f_6390(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6403)
static void C_ccall f_6403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_fcall f_6351(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6312)
static C_word C_fcall f_6312(C_word t0,C_word t1);
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6161)
static void C_ccall f_6161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6161)
static void C_ccall f_6161r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6173)
static void C_ccall f_6173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6255)
static void C_fcall f_6255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6268)
static void C_ccall f_6268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_fcall f_6220(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6185)
static C_word C_fcall f_6185(C_word t0,C_word t1);
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6147)
static void C_ccall f_6147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6108)
static void C_ccall f_6108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6111)
static void C_ccall f_6111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6114)
static void C_ccall f_6114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6119)
static void C_ccall f_6119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6126)
static void C_ccall f_6126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6099)
static void C_ccall f_6099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6039)
static void C_ccall f_6039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6026)
static void C_ccall f_6026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6033)
static void C_ccall f_6033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6003)
static void C_ccall f_6003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5904)
static void C_ccall f_5904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5924)
static void C_ccall f_5924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5898)
static void C_ccall f_5898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5840)
static void C_ccall f_5840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5792)
static void C_ccall f_5792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_fcall f_5796(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5719)
static void C_ccall f_5719(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5719)
static void C_ccall f_5719r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5741)
static void C_ccall f_5741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5745)
static void C_fcall f_5745(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5731)
static void C_ccall f_5731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5690)
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5698)
static void C_fcall f_5698(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5684)
static void C_ccall f_5684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5629)
static void C_ccall f_5629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5569)
static void C_ccall f_5569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5457)
static void C_fcall f_5457(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5463)
static void C_fcall f_5463(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_fcall f_5471(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5485)
static void C_fcall f_5485(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5489)
static void C_ccall f_5489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5451)
static void C_ccall f_5451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5339)
static void C_fcall f_5339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5353)
static void C_ccall f_5353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5293)
static void C_fcall f_5293(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5211)
static void C_fcall f_5211(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5229)
static void C_fcall f_5229(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static C_word C_fcall f_5264(C_word t0,C_word t1);
C_noret_decl(f_5213)
static void C_fcall f_5213(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5194)
static void C_fcall f_5194(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5139)
static void C_ccall f_5139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5146)
static void C_fcall f_5146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5121)
static void C_ccall f_5121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5076)
static void C_ccall f_5076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5095)
static void C_fcall f_5095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5044)
static void C_fcall f_5044(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4993)
static void C_fcall f_4993(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4952)
static void C_ccall f_4952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4918)
static void C_fcall f_4918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4867)
static void C_fcall f_4867(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4788)
static void C_ccall f_4788r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4819)
static void C_fcall f_4819(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4806)
static void C_ccall f_4806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4737)
static void C_ccall f_4737r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4768)
static void C_fcall f_4768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4717)
static void C_fcall f_4717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4666)
static void C_fcall f_4666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4591)
static void C_fcall f_4591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4435)
static void C_fcall f_4435(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_fcall f_4373(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4263)
static void C_ccall f_4263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4269)
static void C_ccall f_4269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4167)
static void C_ccall f_4167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4143)
static void C_ccall f_4143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4119)
static void C_ccall f_4119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4107)
static void C_ccall f_4107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_fcall f_3956(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_fcall f_3969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_fcall f_3982(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_fcall f_3992(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_fcall f_3883(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_fcall f_3896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3901)
static void C_fcall f_3901(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_fcall f_3911(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_fcall f_3798(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_fcall f_3811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_fcall f_3824(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3834)
static void C_fcall f_3834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_fcall f_3725(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3738)
static void C_fcall f_3738(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_fcall f_3743(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3753)
static void C_fcall f_3753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_fcall f_3702(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_fcall f_3656(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_fcall f_3615(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static C_word C_fcall f_3580(C_word t0,C_word t1);
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3526)
static void C_fcall f_3526(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_fcall f_3485(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static C_word C_fcall f_3450(C_word t0,C_word t1);
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3407)
static void C_fcall f_3407(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3366)
static void C_fcall f_3366(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_fcall f_3187(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3193)
static void C_fcall f_3193(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_fcall f_3280(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_fcall f_3008(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3014)
static void C_fcall f_3014(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static C_word C_fcall f_3098(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2959)
static void C_fcall f_2959(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2913)
static void C_fcall f_2913(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_fcall f_2862(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2868)
static void C_fcall f_2868(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_fcall f_2801(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_fcall f_2813(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2743)
static void C_fcall f_2743(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2750)
static void C_fcall f_2750(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2713)
static void C_ccall f_2713r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8411)
static void C_fcall trf_8411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8411(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8411(t0,t1,t2,t3);}

C_noret_decl(trf_8417)
static void C_fcall trf_8417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8417(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8417(t0,t1,t2);}

C_noret_decl(trf_8321)
static void C_fcall trf_8321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8321(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8321(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8352)
static void C_fcall trf_8352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8352(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8352(t0,t1,t2,t3);}

C_noret_decl(trf_7975)
static void C_fcall trf_7975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7975(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7975(t0,t1,t2,t3);}

C_noret_decl(trf_7983)
static void C_fcall trf_7983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7983(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7983(t0,t1,t2);}

C_noret_decl(trf_7994)
static void C_fcall trf_7994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7994(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7994(t0,t1,t2);}

C_noret_decl(trf_7857)
static void C_fcall trf_7857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7857(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7857(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7755)
static void C_fcall trf_7755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7755(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7755(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7805)
static void C_fcall trf_7805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7805(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7805(t0,t1);}

C_noret_decl(trf_7477)
static void C_fcall trf_7477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7477(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7477(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7441)
static void C_fcall trf_7441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7441(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7441(t0,t1,t2,t3);}

C_noret_decl(trf_7218)
static void C_fcall trf_7218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7218(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7218(t0,t1,t2,t3);}

C_noret_decl(trf_7250)
static void C_fcall trf_7250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7250(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7250(t0,t1,t2);}

C_noret_decl(trf_7153)
static void C_fcall trf_7153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7153(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7153(t0,t1,t2);}

C_noret_decl(trf_7054)
static void C_fcall trf_7054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7054(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7054(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7069)
static void C_fcall trf_7069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7069(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7069(t0,t1,t2);}

C_noret_decl(trf_6986)
static void C_fcall trf_6986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6986(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6986(t0,t1,t2);}

C_noret_decl(trf_6924)
static void C_fcall trf_6924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6924(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6924(t0,t1,t2);}

C_noret_decl(trf_6779)
static void C_fcall trf_6779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6779(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6779(t0,t1,t2,t3);}

C_noret_decl(trf_6740)
static void C_fcall trf_6740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6740(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6740(t0,t1,t2,t3);}

C_noret_decl(trf_6648)
static void C_fcall trf_6648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6648(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6648(t0,t1,t2);}

C_noret_decl(trf_6609)
static void C_fcall trf_6609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6609(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6609(t0,t1,t2);}

C_noret_decl(trf_6513)
static void C_fcall trf_6513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6513(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6513(t0,t1,t2);}

C_noret_decl(trf_6478)
static void C_fcall trf_6478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6478(t0,t1,t2);}

C_noret_decl(trf_6390)
static void C_fcall trf_6390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6390(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6390(t0,t1,t2);}

C_noret_decl(trf_6351)
static void C_fcall trf_6351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6351(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6351(t0,t1,t2);}

C_noret_decl(trf_6255)
static void C_fcall trf_6255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6255(t0,t1,t2);}

C_noret_decl(trf_6220)
static void C_fcall trf_6220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6220(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6220(t0,t1,t2);}

C_noret_decl(trf_5796)
static void C_fcall trf_5796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5796(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5796(t0,t1,t2);}

C_noret_decl(trf_5745)
static void C_fcall trf_5745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5745(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5745(t0,t1,t2);}

C_noret_decl(trf_5698)
static void C_fcall trf_5698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5698(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5698(t0,t1,t2);}

C_noret_decl(trf_5457)
static void C_fcall trf_5457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5457(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5457(t0,t1,t2,t3);}

C_noret_decl(trf_5463)
static void C_fcall trf_5463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5463(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5463(t0,t1,t2);}

C_noret_decl(trf_5471)
static void C_fcall trf_5471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5471(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5471(t0,t1,t2);}

C_noret_decl(trf_5485)
static void C_fcall trf_5485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5485(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5485(t0,t1,t2);}

C_noret_decl(trf_5339)
static void C_fcall trf_5339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5339(t0,t1);}

C_noret_decl(trf_5293)
static void C_fcall trf_5293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5293(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5293(t0,t1);}

C_noret_decl(trf_5211)
static void C_fcall trf_5211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5211(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5211(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5229)
static void C_fcall trf_5229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5229(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5229(t0,t1,t2,t3);}

C_noret_decl(trf_5213)
static void C_fcall trf_5213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5213(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5213(t0,t1,t2,t3);}

C_noret_decl(trf_5194)
static void C_fcall trf_5194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5194(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5194(t0,t1);}

C_noret_decl(trf_5146)
static void C_fcall trf_5146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5146(t0,t1);}

C_noret_decl(trf_5095)
static void C_fcall trf_5095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5095(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5095(t0,t1);}

C_noret_decl(trf_5044)
static void C_fcall trf_5044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5044(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5044(t0,t1);}

C_noret_decl(trf_4993)
static void C_fcall trf_4993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4993(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4993(t0,t1);}

C_noret_decl(trf_4918)
static void C_fcall trf_4918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4918(t0,t1);}

C_noret_decl(trf_4867)
static void C_fcall trf_4867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4867(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4867(t0,t1);}

C_noret_decl(trf_4819)
static void C_fcall trf_4819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4819(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4819(t0,t1);}

C_noret_decl(trf_4768)
static void C_fcall trf_4768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4768(t0,t1);}

C_noret_decl(trf_4717)
static void C_fcall trf_4717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4717(t0,t1);}

C_noret_decl(trf_4666)
static void C_fcall trf_4666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4666(t0,t1);}

C_noret_decl(trf_4591)
static void C_fcall trf_4591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4591(t0,t1);}

C_noret_decl(trf_4435)
static void C_fcall trf_4435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4435(void *dummy){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
f_4435(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(trf_4373)
static void C_fcall trf_4373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4373(void *dummy){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
f_4373(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(trf_3956)
static void C_fcall trf_3956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3956(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3956(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3969)
static void C_fcall trf_3969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3969(t0,t1);}

C_noret_decl(trf_3982)
static void C_fcall trf_3982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3982(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3982(t0,t1,t2,t3);}

C_noret_decl(trf_3992)
static void C_fcall trf_3992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3992(t0,t1);}

C_noret_decl(trf_3883)
static void C_fcall trf_3883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3883(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3883(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3896)
static void C_fcall trf_3896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3896(t0,t1);}

C_noret_decl(trf_3901)
static void C_fcall trf_3901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3901(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3901(t0,t1,t2,t3);}

C_noret_decl(trf_3911)
static void C_fcall trf_3911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3911(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3911(t0,t1);}

C_noret_decl(trf_3798)
static void C_fcall trf_3798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3798(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3798(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3811)
static void C_fcall trf_3811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3811(t0,t1);}

C_noret_decl(trf_3824)
static void C_fcall trf_3824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3824(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3824(t0,t1,t2,t3);}

C_noret_decl(trf_3834)
static void C_fcall trf_3834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3834(t0,t1);}

C_noret_decl(trf_3725)
static void C_fcall trf_3725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3725(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3725(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3738)
static void C_fcall trf_3738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3738(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3738(t0,t1);}

C_noret_decl(trf_3743)
static void C_fcall trf_3743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3743(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3743(t0,t1,t2,t3);}

C_noret_decl(trf_3753)
static void C_fcall trf_3753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3753(t0,t1);}

C_noret_decl(trf_3702)
static void C_fcall trf_3702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3702(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3702(t0,t1,t2);}

C_noret_decl(trf_3656)
static void C_fcall trf_3656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3656(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3656(t0,t1,t2);}

C_noret_decl(trf_3615)
static void C_fcall trf_3615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3615(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3615(t0,t1,t2);}

C_noret_decl(trf_3526)
static void C_fcall trf_3526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3526(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3526(t0,t1,t2);}

C_noret_decl(trf_3485)
static void C_fcall trf_3485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3485(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3485(t0,t1,t2);}

C_noret_decl(trf_3407)
static void C_fcall trf_3407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3407(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3407(t0,t1,t2);}

C_noret_decl(trf_3366)
static void C_fcall trf_3366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3366(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3366(t0,t1,t2);}

C_noret_decl(trf_3187)
static void C_fcall trf_3187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3187(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3187(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_3193)
static void C_fcall trf_3193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3193(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3193(t0,t1,t2,t3);}

C_noret_decl(trf_3280)
static void C_fcall trf_3280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3280(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3280(t0,t1,t2,t3);}

C_noret_decl(trf_3008)
static void C_fcall trf_3008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3008(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3008(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_3014)
static void C_fcall trf_3014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3014(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3014(t0,t1,t2,t3);}

C_noret_decl(trf_2959)
static void C_fcall trf_2959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2959(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2959(t0,t1,t2,t3);}

C_noret_decl(trf_2913)
static void C_fcall trf_2913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2913(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2913(t0,t1,t2,t3);}

C_noret_decl(trf_2862)
static void C_fcall trf_2862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2862(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2862(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2868)
static void C_fcall trf_2868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2868(t0,t1,t2);}

C_noret_decl(trf_2801)
static void C_fcall trf_2801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2801(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2801(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2813)
static void C_fcall trf_2813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2813(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2813(t0,t1,t2,t3);}

C_noret_decl(trf_2743)
static void C_fcall trf_2743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2743(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2743(t0,t1,t2,t3);}

C_noret_decl(trf_2750)
static void C_fcall trf_2750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2750(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2750(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr7r)
static void C_fcall tr7r(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7r(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n*3);
t7=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_13_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_13_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1090)){
C_save(t1);
C_rereclaim2(1090*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,155);
lf[0]=C_h_intern(&lf[0],22,"string-parse-start+end");
lf[1]=C_h_intern(&lf[1],9,"\003syserror");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000\032Illegal substring END spec");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000 Illegal substring START/END spec");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\034Illegal substring START spec");
lf[5]=C_h_intern(&lf[5],28,"string-parse-final-start+end");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\034Extra arguments to procedure");
lf[7]=C_h_intern(&lf[7],18,"substring-spec-ok\077");
lf[8]=C_h_intern(&lf[8],20,"check-substring-spec");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\027Illegal substring spec.");
lf[10]=C_h_intern(&lf[10],16,"substring/shared");
lf[12]=C_h_intern(&lf[12],13,"\003syssubstring");
lf[13]=C_h_intern(&lf[13],11,"string-copy");
lf[14]=C_h_intern(&lf[14],10,"string-map");
lf[16]=C_h_intern(&lf[16],11,"make-string");
lf[17]=C_h_intern(&lf[17],11,"string-map!");
lf[19]=C_h_intern(&lf[19],11,"string-fold");
lf[20]=C_h_intern(&lf[20],17,"string-fold-right");
lf[21]=C_h_intern(&lf[21],13,"string-unfold");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[24]=C_h_intern(&lf[24],3,"min");
lf[25]=C_h_intern(&lf[25],19,"string-unfold-right");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[28]=C_h_intern(&lf[28],15,"string-for-each");
lf[29]=C_h_intern(&lf[29],21,"string-for-each-index");
lf[30]=C_h_intern(&lf[30],12,"string-every");
lf[31]=C_h_intern(&lf[31],18,"char-set-contains\077");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[33]=C_h_intern(&lf[33],9,"char-set\077");
lf[34]=C_h_intern(&lf[34],10,"string-any");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[36]=C_h_intern(&lf[36],15,"string-tabulate");
lf[40]=C_h_intern(&lf[40],9,"char-ci=\077");
lf[42]=C_h_intern(&lf[42],20,"string-prefix-length");
lf[43]=C_h_intern(&lf[43],20,"string-suffix-length");
lf[44]=C_h_intern(&lf[44],23,"string-prefix-length-ci");
lf[45]=C_h_intern(&lf[45],23,"string-suffix-length-ci");
lf[46]=C_h_intern(&lf[46],14,"string-prefix\077");
lf[47]=C_h_intern(&lf[47],14,"string-suffix\077");
lf[48]=C_h_intern(&lf[48],17,"string-prefix-ci\077");
lf[49]=C_h_intern(&lf[49],17,"string-suffix-ci\077");
lf[52]=C_h_intern(&lf[52],9,"char-ci<\077");
lf[53]=C_h_intern(&lf[53],14,"string-compare");
lf[54]=C_h_intern(&lf[54],17,"string-compare-ci");
lf[55]=C_h_intern(&lf[55],7,"string=");
lf[56]=C_h_intern(&lf[56],6,"values");
lf[57]=C_h_intern(&lf[57],8,"string<>");
lf[58]=C_h_intern(&lf[58],7,"string<");
lf[59]=C_h_intern(&lf[59],7,"string>");
lf[60]=C_h_intern(&lf[60],8,"string<=");
lf[61]=C_h_intern(&lf[61],8,"string>=");
lf[62]=C_h_intern(&lf[62],10,"string-ci=");
lf[63]=C_h_intern(&lf[63],11,"string-ci<>");
lf[64]=C_h_intern(&lf[64],10,"string-ci<");
lf[65]=C_h_intern(&lf[65],10,"string-ci>");
lf[66]=C_h_intern(&lf[66],11,"string-ci<=");
lf[67]=C_h_intern(&lf[67],11,"string-ci>=");
lf[69]=C_h_intern(&lf[69],6,"modulo");
lf[70]=C_h_intern(&lf[70],11,"string-hash");
lf[71]=C_h_intern(&lf[71],13,"char->integer");
lf[72]=C_h_intern(&lf[72],14,"string-hash-ci");
lf[73]=C_h_intern(&lf[73],13,"string-upcase");
lf[74]=C_h_intern(&lf[74],11,"char-upcase");
lf[75]=C_h_intern(&lf[75],14,"string-upcase!");
lf[76]=C_h_intern(&lf[76],15,"string-downcase");
lf[77]=C_h_intern(&lf[77],13,"char-downcase");
lf[78]=C_h_intern(&lf[78],16,"string-downcase!");
lf[80]=C_h_intern(&lf[80],11,"string-skip");
lf[81]=C_h_intern(&lf[81],12,"string-index");
lf[82]=C_h_intern(&lf[82],17,"string-titlecase!");
lf[83]=C_h_intern(&lf[83],16,"string-titlecase");
lf[84]=C_h_intern(&lf[84],11,"string-take");
lf[85]=C_h_intern(&lf[85],15,"\003syscheck-range");
lf[86]=C_h_intern(&lf[86],17,"string-take-right");
lf[87]=C_h_intern(&lf[87],11,"string-drop");
lf[88]=C_h_intern(&lf[88],17,"string-drop-right");
lf[89]=C_h_intern(&lf[89],11,"string-trim");
lf[90]=C_h_intern(&lf[90],19,"char-set:whitespace");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[92]=C_h_intern(&lf[92],17,"string-trim-right");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[94]=C_h_intern(&lf[94],17,"string-skip-right");
lf[95]=C_h_intern(&lf[95],16,"string-trim-both");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[97]=C_h_intern(&lf[97],16,"string-pad-right");
lf[98]=C_h_intern(&lf[98],10,"string-pad");
lf[99]=C_h_intern(&lf[99],13,"string-delete");
lf[100]=C_h_intern(&lf[100],8,"char-set");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\0006string-delete criteria not predicate, char or char-set");
lf[102]=C_h_intern(&lf[102],13,"string-filter");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\0006string-delete criteria not predicate, char or char-set");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[105]=C_h_intern(&lf[105],18,"string-index-right");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\077Second param is neither char-set, char, or predicate procedure.");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000+CRITERIA param is neither char-set or char.");
lf[109]=C_h_intern(&lf[109],12,"string-count");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000+CRITERIA param is neither char-set or char.");
lf[111]=C_h_intern(&lf[111],12,"string-fill!");
lf[112]=C_h_intern(&lf[112],12,"string-copy!");
lf[113]=C_h_intern(&lf[113],15,"string-contains");
lf[114]=C_h_intern(&lf[114],18,"string-contains-ci");
lf[115]=C_h_intern(&lf[115],23,"make-kmp-restart-vector");
lf[116]=C_h_intern(&lf[116],6,"char=\077");
lf[117]=C_h_intern(&lf[117],11,"make-vector");
lf[118]=C_h_intern(&lf[118],8,"kmp-step");
lf[119]=C_h_intern(&lf[119],25,"string-kmp-partial-search");
lf[120]=C_h_intern(&lf[120],12,"string-null\077");
lf[121]=C_h_intern(&lf[121],14,"string-reverse");
lf[122]=C_h_intern(&lf[122],15,"string-reverse!");
lf[123]=C_h_intern(&lf[123],12,"string->list");
lf[124]=C_h_intern(&lf[124],20,"string-append/shared");
lf[125]=C_h_intern(&lf[125],25,"string-concatenate/shared");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[127]=C_h_intern(&lf[127],18,"string-concatenate");
lf[128]=C_h_intern(&lf[128],26,"string-concatenate-reverse");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[131]=C_h_intern(&lf[131],33,"string-concatenate-reverse/shared");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[133]=C_h_intern(&lf[133],14,"string-replace");
lf[134]=C_h_intern(&lf[134],15,"string-tokenize");
lf[135]=C_h_intern(&lf[135],16,"char-set:graphic");
lf[136]=C_h_intern(&lf[136],10,"xsubstring");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\042Cannot replicate empty (sub)string");
lf[141]=C_h_intern(&lf[141],13,"string-xcopy!");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\042Cannot replicate empty (sub)string");
lf[143]=C_h_intern(&lf[143],11,"string-join");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[145]=C_h_intern(&lf[145],5,"infix");
lf[146]=C_h_intern(&lf[146],12,"strict-infix");
lf[147]=C_h_intern(&lf[147],6,"prefix");
lf[148]=C_h_intern(&lf[148],6,"suffix");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\024Illegal join grammar");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\0006Empty list cannot be joined with STRICT-INFIX grammar.");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\033STRINGS parameter not list.");
lf[153]=C_h_intern(&lf[153],17,"register-feature!");
lf[154]=C_h_intern(&lf[154],7,"srfi-13");
C_register_lf2(lf,155,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2532,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2530 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 49   register-feature! */
t3=*((C_word*)lf[153]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[154]);}

/* k2533 in k2530 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word ab[194],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2535,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! string-parse-start+end ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2537,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[5]+1 /* (set! string-parse-final-start+end ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2630,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[7]+1 /* (set! substring-spec-ok? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2657,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[8]+1 /* (set! check-substring-spec ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2697,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! substring/shared ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2713,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[11] /* (set! %substring/shared ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2743,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[13]+1 /* (set! string-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2765,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[14]+1 /* (set! string-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2783,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[15] /* (set! %string-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2801,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[17]+1 /* (set! string-map! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2844,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[18] /* (set! %string-map! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2862,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[19]+1 /* (set! string-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2895,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[20]+1 /* (set! string-fold-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2937,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[21]+1 /* (set! string-unfold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2983,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[25]+1 /* (set! string-unfold-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3162,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[28]+1 /* (set! string-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3348,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[29]+1 /* (set! string-for-each-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3389,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[30]+1 /* (set! string-every ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3426,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[34]+1 /* (set! string-any ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3556,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[36]+1 /* (set! string-tabulate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3686,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate(&lf[37] /* (set! %string-prefix-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3725,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[38] /* (set! %string-suffix-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3798,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate(&lf[39] /* (set! %string-prefix-length-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3883,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate(&lf[41] /* (set! %string-suffix-length-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3956,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[42]+1 /* (set! string-prefix-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4041,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[43]+1 /* (set! string-suffix-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4071,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[44]+1 /* (set! string-prefix-length-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4101,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[45]+1 /* (set! string-suffix-length-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4131,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[46]+1 /* (set! string-prefix? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4161,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[47]+1 /* (set! string-suffix? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4191,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[48]+1 /* (set! string-prefix-ci? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4221,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[49]+1 /* (set! string-suffix-ci? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4251,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate(&lf[50] /* (set! %string-compare ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4373,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate(&lf[51] /* (set! %string-compare-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4435,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[53]+1 /* (set! string-compare ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4497,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[54]+1 /* (set! string-compare-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4527,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[55]+1 /* (set! string= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4557,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[57]+1 /* (set! string<> ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4619,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[58]+1 /* (set! string< ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4686,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[59]+1 /* (set! string> ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4737,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[60]+1 /* (set! string<= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4788,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[61]+1 /* (set! string>= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4836,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[62]+1 /* (set! string-ci= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4884,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[63]+1 /* (set! string-ci<> ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4946,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[64]+1 /* (set! string-ci< ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5013,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[65]+1 /* (set! string-ci> ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5064,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[66]+1 /* (set! string-ci<= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5115,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[67]+1 /* (set! string-ci>= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5163,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate(&lf[68] /* (set! %string-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5211,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[70]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5283,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[72]+1 /* (set! string-hash-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5329,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[73]+1 /* (set! string-upcase ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5385,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[75]+1 /* (set! string-upcase! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5403,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[76]+1 /* (set! string-downcase ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5421,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[78]+1 /* (set! string-downcase! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5439,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate(&lf[79] /* (set! %string-titlecase! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5457,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[82]+1 /* (set! string-titlecase! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5532,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[83]+1 /* (set! string-titlecase ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5550,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[84]+1 /* (set! string-take ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5575,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[86]+1 /* (set! string-take-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5595,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[87]+1 /* (set! string-drop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5622,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[88]+1 /* (set! string-drop-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5645,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[89]+1 /* (set! string-trim ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5672,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[92]+1 /* (set! string-trim-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5719,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[95]+1 /* (set! string-trim-both ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5770,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[97]+1 /* (set! string-pad-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5825,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[98]+1 /* (set! string-pad ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5883,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[99]+1 /* (set! string-delete ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5945,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[102]+1 /* (set! string-filter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6053,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[81]+1 /* (set! string-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6161,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[105]+1 /* (set! string-index-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6284,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[80]+1 /* (set! string-skip ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6419,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[94]+1 /* (set! string-skip-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6542,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[109]+1 /* (set! string-count ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6677,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[111]+1 /* (set! string-fill! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6812,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[112]+1 /* (set! string-copy! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6853,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[113]+1 /* (set! string-contains ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6888,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[114]+1 /* (set! string-contains-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6950,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[115]+1 /* (set! make-kmp-restart-vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7012,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[118]+1 /* (set! kmp-step ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7147,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[119]+1 /* (set! string-kmp-partial-search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7185,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[120]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7306,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[121]+1 /* (set! string-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7309,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[122]+1 /* (set! string-reverse! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7364,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[123]+1 /* (set! string->list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7419,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[124]+1 /* (set! string-append/shared ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7465,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[125]+1 /* (set! string-concatenate/shared ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7471,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[127]+1 /* (set! string-concatenate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7573,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[128]+1 /* (set! string-concatenate-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7646,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[131]+1 /* (set! string-concatenate-reverse/shared ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7731,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate(&lf[130] /* (set! %finish-string-concatenate-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7857,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[133]+1 /* (set! string-replace ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7900,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[134]+1 /* (set! string-tokenize ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7951,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[136]+1 /* (set! xsubstring ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8043,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate(&lf[140] /* (set! string-fill! ...) */,*((C_word*)lf[111]+1));
t97=C_mutate((C_word*)lf[141]+1 /* (set! string-xcopy! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8181,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate(&lf[139] /* (set! %multispan-repcopy! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8321,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[143]+1 /* (set! string-join ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8394,tmp=(C_word)a,a+=2,tmp));
t100=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t100+1)))(2,t100,C_SCHEME_UNDEFINED);}

/* string-join in k2533 in k2530 */
static void C_ccall f_8394(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8394r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8394r(t0,t1,t2,t3);}}

static void C_ccall f_8394r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a=C_alloc(13);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[144]:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?lf[145]:(C_word)C_u_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t7,C_fix(1)));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8411,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8456,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_eqp(t9,lf[145]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t9,lf[146]));
if(C_truep(t15)){
t16=(C_word)C_u_i_car(t2);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8473,a[2]=t1,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t18=(C_word)C_slot(t2,C_fix(1));
/* srfi-13.scm: 1909 buildit */
t19=t12;
f_8411(t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(t9,lf[147]);
if(C_truep(t16)){
/* srfi-13.scm: 1911 buildit */
t17=t12;
f_8411(t17,t13,t2,C_SCHEME_END_OF_LIST);}
else{
t17=(C_word)C_eqp(t9,lf[148]);
if(C_truep(t17)){
t18=(C_word)C_u_i_car(t2);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8503,a[2]=t1,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_slot(t2,C_fix(1));
t21=(C_word)C_a_i_list(&a,1,t5);
/* srfi-13.scm: 1914 buildit */
t22=t12;
f_8411(t22,t19,t20,t21);}
else{
/* srfi-13.scm: 1916 ##sys#error */
t18=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t18+1)))(6,t18,t13,lf[143],lf[149],t9,*((C_word*)lf[143]+1));}}}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t13=(C_word)C_eqp(t9,lf[146]);
if(C_truep(t13)){
/* srfi-13.scm: 1925 ##sys#error */
t14=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t1,lf[143],lf[150],*((C_word*)lf[143]+1));}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[151]);}}
else{
/* srfi-13.scm: 1920 ##sys#error */
t13=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t1,lf[143],lf[152],t2,*((C_word*)lf[143]+1));}}}

/* k8501 in string-join in k2533 in k2530 */
static void C_ccall f_8503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8503,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* srfi-13.scm: 1905 string-concatenate */
t3=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k8471 in string-join in k2533 in k2530 */
static void C_ccall f_8473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8473,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* srfi-13.scm: 1905 string-concatenate */
t3=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k8454 in string-join in k2533 in k2530 */
static void C_ccall f_8456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1905 string-concatenate */
t2=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* buildit in string-join in k2533 in k2530 */
static void C_fcall f_8411(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8411,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8417,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_8417(t7,t1,t2);}

/* recur in buildit in string-join in k2533 in k2530 */
static void C_fcall f_8417(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8417,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8439,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-13.scm: 1901 recur */
t8=t4;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t3=((C_word*)t0)[2];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8437 in recur in buildit in string-join in k2533 in k2530 */
static void C_ccall f_8439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8439,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* %multispan-repcopy! in k2533 in k2530 */
static void C_fcall f_8321(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8321,NULL,8,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_u_fixnum_difference(t8,t7);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8392,a[2]=t1,a[3]=t9,a[4]=t8,a[5]=t4,a[6]=t3,a[7]=t2,a[8]=t5,a[9]=t6,a[10]=t7,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1860 modulo */
t11=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t5,t9);}

/* k8390 in %multispan-repcopy! in k2533 in k2530 */
static void C_ccall f_8392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8392,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],t1);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[9],((C_word*)t0)[8]);
t4=((C_word*)t0)[7];
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[5];
t7=((C_word*)t0)[4];
t8=(C_word)C_substring_copy(t6,t4,t2,t7,t5);
t9=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],t2);
t10=(C_word)C_u_fixnum_difference(t3,t9);
t11=(C_word)C_fixnum_divide(t10,((C_word*)t0)[3]);
t12=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t9);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8352,a[2]=t14,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp));
t16=((C_word*)t14)[1];
f_8352(t16,((C_word*)t0)[2],t12,t11);}

/* doloop2375 in k8390 in %multispan-repcopy! in k2533 in k2530 */
static void C_fcall f_8352(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8352,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[9]);
t6=(C_word)C_u_fixnum_difference(((C_word*)t0)[8],t5);
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t6);
t8=t1;
t9=((C_word*)t0)[6];
t10=t2;
t11=((C_word*)t0)[5];
t12=((C_word*)t0)[7];
t13=t8;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_substring_copy(t11,t9,t12,t7,t10));}
else{
t5=((C_word*)t0)[6];
t6=t2;
t7=((C_word*)t0)[5];
t8=((C_word*)t0)[7];
t9=((C_word*)t0)[4];
t10=(C_word)C_substring_copy(t7,t5,t8,t9,t6);
t11=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[3]);
t12=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t22=t1;
t23=t11;
t24=t12;
t1=t22;
t2=t23;
t3=t24;
goto loop;}}

/* string-xcopy! in k2533 in k2530 */
static void C_ccall f_8181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr6r,(void*)f_8181r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_8181r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_8181r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t7=(C_word)C_i_check_exact_2(t5,lf[141]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8190,a[2]=t5,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8234,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a8233 in string-xcopy! in k2533 in k2530 */
static void C_ccall f_8234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8234,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[5]);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t5);
t7=(C_word)C_u_fixnum_difference(t4,t3);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8247,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[3],a[10]=t7,a[11]=t1,a[12]=t5,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 1838 check-substring-spec */
t9=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t8,*((C_word*)lf[141]+1),((C_word*)t0)[3],((C_word*)t0)[4],t6);}

/* k8245 in a8233 in string-xcopy! in k2533 in k2530 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8247,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[12],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],C_fix(0));
if(C_truep(t3)){
/* srfi-13.scm: 1840 ##sys#error */
t4=*((C_word*)lf[1]+1);
((C_proc12)(void*)(*((C_word*)t4+1)))(12,t4,((C_word*)t0)[11],lf[141],lf[142],*((C_word*)lf[141]+1),((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_eqp(C_fix(1),((C_word*)t0)[10]);
if(C_truep(t4)){
t5=(C_word)C_subchar(((C_word*)t0)[7],((C_word*)t0)[4]);
/* srfi-13.scm: 1845 ##srfi13#string-fill! */
t6=lf[140];
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,((C_word*)t0)[11],((C_word*)t0)[9],t5,((C_word*)t0)[8],((C_word*)t0)[2]);}
else{
t5=(C_word)C_fixnum_divide(((C_word*)t0)[6],((C_word*)t0)[10]);
t6=(C_word)C_fixnum_divide(((C_word*)t0)[5],((C_word*)t0)[10]);
t7=(C_word)C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8300,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 1850 modulo */
t9=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],((C_word*)t0)[10]);}
else{
/* srfi-13.scm: 1854 %multispan-repcopy! */
f_8321(((C_word*)t0)[11],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}}

/* k8298 in k8245 in a8233 in string-xcopy! in k2533 in k2530 */
static void C_ccall f_8300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8300,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8296,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1851 modulo */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8294 in k8298 in k8245 in a8233 in string-xcopy! in k2533 in k2530 */
static void C_ccall f_8296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=t3;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_substring_copy(t6,t4,((C_word*)t0)[2],t2,t5));}

/* a8189 in string-xcopy! in k2533 in k2530 */
static void C_ccall f_8190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8190,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8212,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}
else{
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1833 values */
C_values(5,0,t1,t3,C_fix(0),t2);}}

/* a8211 in a8189 in string-xcopy! in k2533 in k2530 */
static void C_ccall f_8212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8212,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[2]);
t5=(C_word)C_i_check_exact_2(t4,lf[141]);
/* srfi-13.scm: 1831 values */
C_values(5,0,t1,t4,t2,t3);}

/* a8201 in a8189 in string-xcopy! in k2533 in k2530 */
static void C_ccall f_8202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8202,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* string-parse-final-start+end */
t3=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[141]+1),((C_word*)t0)[2],t2);}

/* xsubstring in k2533 in k2530 */
static void C_ccall f_8043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_8043r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8043r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8043r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t5=(C_word)C_i_check_exact_2(t3,lf[136]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8052,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8096,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a8095 in xsubstring in k2533 in k2530 */
static void C_ccall f_8096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8096,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t4,t3);
t6=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[3]);
t7=(C_word)C_eqp(t6,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[137]);}
else{
t8=(C_word)C_eqp(t5,C_fix(0));
if(C_truep(t8)){
/* srfi-13.scm: 1794 ##sys#error */
t9=*((C_word*)lf[1]+1);
((C_proc10)(void*)(*((C_word*)t9+1)))(10,t9,t1,lf[136],lf[138],*((C_word*)lf[136]+1),((C_word*)t0)[2],((C_word*)t0)[3],t2,t3,t4);}
else{
t9=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t9)){
t10=(C_word)C_subchar(((C_word*)t0)[2],t3);
/* srfi-13.scm: 1798 make-string */
t11=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,t6,t10);}
else{
t10=(C_word)C_fixnum_divide(((C_word*)t0)[3],t5);
t11=(C_word)C_fixnum_divide(t2,t5);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8156,a[2]=t5,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1802 modulo */
t14=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t13,((C_word*)t0)[3],t5);}
else{
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8159,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1806 make-string */
t14=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t6);}}}}}

/* k8157 in a8095 in xsubstring in k2533 in k2530 */
static void C_ccall f_8159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8162,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1807 %multispan-repcopy! */
f_8321(t2,t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8160 in k8157 in a8095 in xsubstring in k2533 in k2530 */
static void C_ccall f_8162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k8154 in a8095 in xsubstring in k2533 in k2530 */
static void C_ccall f_8156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8156,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8152,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1803 modulo */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8150 in k8154 in a8095 in xsubstring in k2533 in k2530 */
static void C_ccall f_8152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t1);
/* srfi-13.scm: 1802 ##sys#substring */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a8051 in xsubstring in k2533 in k2530 */
static void C_ccall f_8052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8052,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8074,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}
else{
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2);
/* srfi-13.scm: 1790 values */
C_values(5,0,t1,t3,C_fix(0),t2);}}

/* a8073 in a8051 in xsubstring in k2533 in k2530 */
static void C_ccall f_8074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8074,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[2]);
t5=(C_word)C_i_check_exact_2(t4,lf[136]);
/* srfi-13.scm: 1787 values */
C_values(5,0,t1,t4,t2,t3);}

/* a8063 in a8051 in xsubstring in k2533 in k2530 */
static void C_ccall f_8064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8064,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* string-parse-final-start+end */
t3=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[136]+1),((C_word*)t0)[2],t2);}

/* string-tokenize in k2533 in k2530 */
static void C_ccall f_7951(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_7951r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7951r(t0,t1,t2,t3);}}

static void C_ccall f_7951r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[135]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7963,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7969,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a7968 in string-tokenize in k2533 in k2530 */
static void C_ccall f_7969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7969,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7975,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7975(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in a7968 in string-tokenize in k2533 in k2530 */
static void C_fcall f_7975(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7975,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7979,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[3];
t6=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,t6))){
/* srfi-13.scm: 1735 string-index-right */
t7=*((C_word*)lf[105]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3],t2);}
else{
t7=t4;
f_7979(2,t7,C_SCHEME_FALSE);}}

/* k7977 in lp in a7968 in string-tokenize in k2533 in k2530 */
static void C_ccall f_7979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7979,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7983,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* g22752276 */
t3=t2;
f_7983(t3,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* g2275 in k7977 in lp in a7968 in string-tokenize in k2533 in k2530 */
static void C_fcall f_7983(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7983,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_fixnum_plus(C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7990,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1738 string-skip-right */
t5=*((C_word*)lf[94]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3],t2);}

/* k7988 in g2275 in k7977 in lp in a7968 in string-tokenize in k2533 in k2530 */
static void C_ccall f_7990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7990,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7994,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* g22872288 */
t3=t2;
f_7994(t3,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8020,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1743 ##sys#substring */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k8018 in k7988 in g2275 in k7977 in lp in a7968 in string-tokenize in k2533 in k2530 */
static void C_ccall f_8020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8020,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* g2287 in k7988 in g2275 in k7977 in lp in a7968 in string-tokenize in k2533 in k2530 */
static void C_fcall f_7994(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7994,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8006,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_fixnum_plus(C_fix(1),t2);
/* srfi-13.scm: 1741 ##sys#substring */
t5=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k8004 in g2287 in k7988 in g2275 in k7977 in lp in a7968 in string-tokenize in k2533 in k2530 */
static void C_ccall f_8006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8006,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* srfi-13.scm: 1740 lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7975(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a7962 in string-tokenize in k2533 in k2530 */
static void C_ccall f_7963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7963,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[134]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-replace in k2533 in k2530 */
static void C_ccall f_7900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr6r,(void*)f_7900r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_7900r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_7900r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7904,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t2,a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1712 check-substring-spec */
t8=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t7,*((C_word*)lf[133]+1),t2,t4,t5);}

/* k7902 in string-replace in k2533 in k2530 */
static void C_ccall f_7904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7909,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7915,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a7914 in k7902 in string-replace in k2533 in k2530 */
static void C_ccall f_7915(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7915,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],((C_word*)t0)[3]);
t7=(C_word)C_u_fixnum_difference(t4,t6);
t8=(C_word)C_u_fixnum_plus(t7,t5);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7928,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 1717 make-string */
t10=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t8);}

/* k7926 in a7914 in k7902 in string-replace in k2533 in k2530 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
t2=t1;
t3=((C_word*)t0)[10];
t4=((C_word*)t0)[9];
t5=(C_word)C_substring_copy(t3,t2,C_fix(0),t4,C_fix(0));
t6=t1;
t7=((C_word*)t0)[9];
t8=((C_word*)t0)[8];
t9=((C_word*)t0)[7];
t10=((C_word*)t0)[6];
t11=(C_word)C_substring_copy(t8,t6,t9,t10,t7);
t12=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],((C_word*)t0)[5]);
t13=t1;
t14=((C_word*)t0)[10];
t15=((C_word*)t0)[4];
t16=(C_word)C_substring_copy(t14,t13,t15,((C_word*)t0)[3],t12);
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,t1);}

/* a7908 in k7902 in string-replace in k2533 in k2530 */
static void C_ccall f_7909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7909,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[133]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %finish-string-concatenate-reverse in k2533 in k2530 */
static void C_fcall f_7857(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7857,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7861,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_fixnum_plus(t5,t2);
/* srfi-13.scm: 1692 make-string */
t8=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k7859 in %finish-string-concatenate-reverse in k2533 in k2530 */
static void C_ccall f_7861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7861,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=(C_word)C_substring_copy(t4,t2,C_fix(0),t5,t3);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7869,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=f_7869(t7,((C_word*)t0)[6],((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t1);}

/* lp in k7859 in %finish-string-concatenate-reverse in k2533 in k2530 */
static C_word C_fcall f_7869(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_fix((C_word)C_header_size(t3));
t6=(C_word)C_u_fixnum_difference(t1,t5);
t7=((C_word*)t0)[2];
t8=(C_word)C_substring_copy(t3,t7,C_fix(0),t5,t6);
t11=t6;
t12=t4;
t1=t11;
t2=t12;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* string-concatenate-reverse/shared in k2533 in k2530 */
static void C_ccall f_7731(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_7731r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7731r(t0,t1,t2,t3);}}

static void C_ccall f_7731r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(7);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[132]:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?(C_word)C_fix((C_word)C_header_size(t5)):(C_word)C_u_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t7,C_fix(1)));
t12=(C_word)C_i_check_exact_2(t9,lf[131]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7755,a[2]=t9,a[3]=t5,a[4]=t14,tmp=(C_word)a,a+=5,tmp));
t16=((C_word*)t14)[1];
f_7755(t16,t1,C_fix(0),C_SCHEME_FALSE,t2);}

/* lp in string-concatenate-reverse/shared in k2533 in k2530 */
static void C_fcall f_7755(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7755,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_fix((C_word)C_header_size(t5));
t7=(C_word)C_u_fixnum_plus(t2,t6);
t8=t3;
if(C_truep(t8)){
t9=(C_truep(t8)?t3:t4);
t10=(C_word)C_slot(t4,C_fix(1));
/* srfi-13.scm: 1678 lp */
t21=t1;
t22=t7;
t23=t9;
t24=t10;
t1=t21;
t2=t22;
t3=t23;
t4=t24;
goto loop;}
else{
t9=(C_word)C_eqp(t6,C_fix(0));
t10=(C_truep(t9)?t3:t4);
t11=(C_word)C_slot(t4,C_fix(1));
/* srfi-13.scm: 1678 lp */
t21=t1;
t22=t7;
t23=t10;
t24=t11;
t1=t21;
t2=t22;
t3=t23;
t4=t24;
goto loop;}}
else{
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
/* srfi-13.scm: 1682 substring/shared */
t6=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t7)){
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_fix((C_word)C_header_size(t8));
t10=t2;
t11=t6;
f_7805(t11,(C_word)C_eqp(t10,t9));}
else{
t8=t6;
f_7805(t8,C_SCHEME_FALSE);}}}}

/* k7803 in lp in string-concatenate-reverse/shared in k2533 in k2530 */
static void C_fcall f_7805(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_car(((C_word*)t0)[5]));}
else{
/* srfi-13.scm: 1689 %finish-string-concatenate-reverse */
f_7857(((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* string-concatenate-reverse in k2533 in k2530 */
static void C_ccall f_7646(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr3r,(void*)f_7646r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7646r(t0,t1,t2,t3);}}

static void C_ccall f_7646r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(2);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?lf[129]:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?(C_word)C_fix((C_word)C_header_size(t5)):(C_word)C_u_i_car(t7));
t10=(C_word)C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t7,C_fix(1)));
t12=(C_word)C_i_check_exact_2(t9,lf[128]);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7673,tmp=(C_word)a,a+=2,tmp);
t14=f_7673(C_fix(0),t2);
/* srfi-13.scm: 1663 %finish-string-concatenate-reverse */
f_7857(t1,t14,t2,t5,t9);}

/* lp in string-concatenate-reverse in k2533 in k2530 */
static C_word C_fcall f_7673(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=(C_word)C_u_fixnum_plus(t1,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=t1;
return(t3);}}

/* string-concatenate in k2533 in k2530 */
static void C_ccall f_7573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7573,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7614,tmp=(C_word)a,a+=2,tmp);
t4=f_7614(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7580,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1630 make-string */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k7578 in string-concatenate in k2533 in k2530 */
static void C_ccall f_7580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7585,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=f_7585(t2,C_fix(0),((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* lp in k7578 in string-concatenate in k2533 in k2530 */
static C_word C_fcall f_7585(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=((C_word*)t0)[2];
t6=t1;
t7=(C_word)C_substring_copy(t3,t5,C_fix(0),t4,t6);
t8=(C_word)C_u_fixnum_plus(t1,t4);
t9=(C_word)C_slot(t2,C_fix(1));
t12=t8;
t13=t9;
t1=t12;
t2=t13;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* doloop2131 in string-concatenate in k2533 in k2530 */
static C_word C_fcall f_7614(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_i_car(t1);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(C_word)C_u_fixnum_plus(t2,t5);
t9=t3;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=t2;
return(t3);}}

/* string-concatenate/shared in k2533 in k2530 */
static void C_ccall f_7471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7471,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7477,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7477(t6,t1,t2,C_fix(0),C_SCHEME_FALSE);}

/* lp in string-concatenate/shared in k2533 in k2530 */
static void C_fcall f_7477(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7477,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_fix((C_word)C_header_size(t5));
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
/* srfi-13.scm: 1603 lp */
t19=t1;
t20=t6;
t21=t3;
t22=t4;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t9=(C_word)C_u_fixnum_plus(t3,t7);
t10=t4;
if(C_truep(t10)){
/* srfi-13.scm: 1604 lp */
t19=t1;
t20=t6;
t21=t9;
t22=t10;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t11=t2;
/* srfi-13.scm: 1604 lp */
t19=t1;
t20=t6;
t21=t9;
t22=t11;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}}}
else{
t5=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[126]);}
else{
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_fix((C_word)C_header_size(t6));
t8=t3;
t9=(C_word)C_eqp(t8,t7);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_u_i_car(t4));}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7531,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1611 make-string */
t11=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t3);}}}}

/* k7529 in lp in string-concatenate/shared in k2533 in k2530 */
static void C_ccall f_7531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7536,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=f_7536(t2,((C_word*)t0)[3],C_fix(0));
t4=t1;
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* lp in k7529 in lp in string-concatenate/shared in k2533 in k2530 */
static C_word C_fcall f_7536(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=((C_word*)t0)[2];
t6=t2;
t7=(C_word)C_substring_copy(t3,t5,C_fix(0),t4,t6);
t8=(C_word)C_slot(t1,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t2,t4);
t12=t8;
t13=t9;
t1=t12;
t2=t13;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* string-append/shared in k2533 in k2530 */
static void C_ccall f_7465(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_7465r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7465r(t0,t1,t2);}}

static void C_ccall f_7465r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-13.scm: 1594 string-concatenate/shared */
t3=*((C_word*)lf[125]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* string->list in k2533 in k2530 */
static void C_ccall f_7419(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_7419r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7419r(t0,t1,t2,t3);}}

static void C_ccall f_7419r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7425,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7431,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a7430 in string->list in k2533 in k2530 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7431,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7441,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7441(t8,t1,t4,C_SCHEME_END_OF_LIST);}

/* doloop2086 in a7430 in string->list in k2533 in k2530 */
static void C_fcall f_7441(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7441,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t11=t1;
t12=t6;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* a7424 in string->list in k2533 in k2530 */
static void C_ccall f_7425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7425,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[123]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-reverse! in k2533 in k2530 */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_7364r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7364r(t0,t1,t2,t3);}}

static void C_ccall f_7364r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7370,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7376,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a7375 in string-reverse! in k2533 in k2530 */
static void C_ccall f_7376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7376,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_7386(t5,t4,t2));}

/* doloop2066 in a7375 in string-reverse! in k2533 in k2530 */
static C_word C_fcall f_7386(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
loop:
t3=t1;
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,t4))){
t5=C_SCHEME_UNDEFINED;
return(t5);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[2],t1);
t6=(C_word)C_subchar(((C_word*)t0)[2],t2);
t7=(C_word)C_setsubchar(((C_word*)t0)[2],t1,t6);
t8=(C_word)C_setsubchar(((C_word*)t0)[2],t2,t5);
t9=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t10=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t13=t9;
t14=t10;
t1=t13;
t2=t14;
goto loop;}}

/* a7369 in string-reverse! in k2533 in k2530 */
static void C_ccall f_7370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7370,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[122]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-reverse in k2533 in k2530 */
static void C_ccall f_7309(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_7309r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7309r(t0,t1,t2,t3);}}

static void C_ccall f_7309r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7315,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7321,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a7320 in string-reverse in k2533 in k2530 */
static void C_ccall f_7321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7321,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7328,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1536 make-string */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k7326 in a7320 in string-reverse in k2533 in k2530 */
static void C_ccall f_7328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7328,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7337,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=f_7337(t3,((C_word*)t0)[3],t2);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* doloop2047 in k7326 in a7320 in string-reverse in k2533 in k2530 */
static C_word C_fcall f_7337(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=C_SCHEME_UNDEFINED;
return(t4);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_setsubchar(((C_word*)t0)[2],t2,t4);
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t7=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* a7314 in string-reverse in k2533 in k2530 */
static void C_ccall f_7315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7315,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[121]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-null? in k2533 in k2530 */
static void C_ccall f_7306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7306,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_null_p(t2));}

/* string-kmp-partial-search in k2533 in k2530 */
static void C_ccall f_7185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr6r,(void*)f_7185r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_7185r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_7185r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(12);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?*((C_word*)lf[116]+1):(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?C_fix(0):(C_word)C_u_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t10,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7203,a[2]=t14,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7209,a[2]=t5,a[3]=t8,a[4]=t2,a[5]=t12,a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t15,t16);}

/* a7208 in string-kmp-partial-search in k2533 in k2530 */
static void C_ccall f_7209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7209,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7218,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=t7,a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t5,tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_7218(t9,t1,t3,((C_word*)t0)[2]);}

/* lp in a7208 in string-kmp-partial-search in k2533 in k2530 */
static void C_fcall f_7218(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7218,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_eqp(t4,((C_word*)t0)[9]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u_fixnum_negate(t2));}
else{
t6=t2;
t7=((C_word*)t0)[8];
t8=(C_word)C_eqp(t6,t7);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t3);}
else{
t9=(C_word)C_subchar(((C_word*)t0)[7],t2);
t10=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7248,a[2]=t10,a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7250,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t13,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t15=((C_word*)t13)[1];
f_7250(t15,t11,t3);}}}

/* lp2 in lp in a7208 in string-kmp-partial-search in k2533 in k2530 */
static void C_fcall f_7250(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7250,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7257,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[5]);
t5=(C_word)C_subchar(((C_word*)t0)[4],t4);
/* srfi-13.scm: 1516 c= */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,((C_word*)t0)[2],t5);}

/* k7255 in lp2 in lp in a7208 in string-kmp-partial-search in k2533 in k2530 */
static void C_ccall f_7257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
/* srfi-13.scm: 1520 lp2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7250(t4,((C_word*)t0)[5],t2);}}}

/* k7246 in lp in a7208 in string-kmp-partial-search in k2533 in k2530 */
static void C_ccall f_7248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1514 lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7218(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7202 in string-kmp-partial-search in k2533 in k2530 */
static void C_ccall f_7203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7203,2,t0,t1);}
/* srfi-13.scm: 1505 string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[119]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* kmp-step in k2533 in k2530 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_7147,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7153,a[2]=t4,a[3]=t6,a[4]=t2,a[5]=t7,a[6]=t9,a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_7153(t11,t1,t5);}

/* lp in kmp-step in k2533 in k2530 */
static void C_fcall f_7153(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7153,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7160,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[5]);
t5=(C_word)C_subchar(((C_word*)t0)[4],t4);
/* srfi-13.scm: 1483 c= */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,((C_word*)t0)[2],t5);}

/* k7158 in lp in kmp-step in k2533 in k2530 */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
/* srfi-13.scm: 1487 lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7153(t4,((C_word*)t0)[5],t2);}}}

/* make-kmp-restart-vector in k2533 in k2530 */
static void C_ccall f_7012(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_7012r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7012r(t0,t1,t2,t3);}}

static void C_ccall f_7012r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[116]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7024,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7030,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a7029 in make-kmp-restart-vector in k2533 in k2530 */
static void C_ccall f_7030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7030,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7037,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1437 make-vector */
t7=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,C_fix(-1));}

/* k7035 in a7029 in make-kmp-restart-vector in k2533 in k2530 */
static void C_ccall f_7037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7040,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[5],C_fix(0)))){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[4],((C_word*)t0)[3]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7054,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_7054(t8,t2,C_fix(0),C_fix(-1),((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* lp1 in k7035 in a7029 in make-kmp-restart-vector in k2533 in k2530 */
static void C_fcall f_7054(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7054,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,((C_word*)t0)[8]))){
t6=(C_word)C_subchar(((C_word*)t0)[7],t4);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7069,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=((C_word*)t0)[6],a[11]=t2,tmp=(C_word)a,a+=12,tmp));
t10=((C_word*)t8)[1];
f_7069(t10,t1,t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* lp2 in lp1 in k7035 in a7029 in make-kmp-restart-vector in k2533 in k2530 */
static void C_fcall f_7069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7069,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t4)){
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[11],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7096,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t5,a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1455 c= */
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7102,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t2,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[3]);
t7=(C_word)C_subchar(((C_word*)t0)[2],t6);
/* srfi-13.scm: 1459 c= */
t8=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[6],t7);}}

/* k7100 in lp2 in lp1 in k7035 in a7029 in make-kmp-restart-vector in k2533 in k2530 */
static void C_ccall f_7102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(C_fix(1),((C_word*)t0)[8]);
t3=(C_word)C_u_fixnum_plus(C_fix(1),((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],t2,t3);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-13.scm: 1463 lp1 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7054(t6,((C_word*)t0)[3],t2,t3,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[7]);
/* srfi-13.scm: 1465 lp2 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7069(t3,((C_word*)t0)[3],t2);}}

/* k7094 in lp2 in lp1 in k7035 in a7029 in make-kmp-restart-vector in k2533 in k2530 */
static void C_ccall f_7096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_set_i_slot(((C_word*)t0)[6],((C_word*)t0)[5],C_fix(-1)):(C_word)C_i_set_i_slot(((C_word*)t0)[6],((C_word*)t0)[5],C_fix(0)));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1456 lp1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7054(t4,((C_word*)t0)[2],((C_word*)t0)[5],C_fix(0),t3);}

/* k7038 in k7035 in a7029 in make-kmp-restart-vector in k2533 in k2530 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a7023 in make-kmp-restart-vector in k2533 in k2530 */
static void C_ccall f_7024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7024,2,t0,t1);}
/* srfi-13.scm: 1435 string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-contains-ci in k2533 in k2530 */
static void C_ccall f_6950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_6950r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6950r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6950r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[113]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6956,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6962,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a6961 in string-contains-ci in k2533 in k2530 */
static void C_ccall f_6962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6962,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6968,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6974,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6973 in a6961 in string-contains-ci in k2533 in k2530 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6974,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6986,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_6986(t9,t1,((C_word*)t0)[2]);}

/* lp in a6973 in a6961 in string-contains-ci in k2533 in k2530 */
static void C_fcall f_6986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6986,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6999,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[6]);
/* srfi-13.scm: 1378 string-ci= */
t5=*((C_word*)lf[62]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6997 in lp in a6973 in a6961 in string-contains-ci in k2533 in k2530 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1380 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6986(t3,((C_word*)t0)[4],t2);}}

/* a6967 in a6961 in string-contains-ci in k2533 in k2530 */
static void C_ccall f_6968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6968,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6955 in string-contains-ci in k2533 in k2530 */
static void C_ccall f_6956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6956,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-contains in k2533 in k2530 */
static void C_ccall f_6888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_6888r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6888r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6888r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[113]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6894,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6900,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a6899 in string-contains in k2533 in k2530 */
static void C_ccall f_6900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6900,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6906,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6912,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6911 in a6899 in string-contains in k2533 in k2530 */
static void C_ccall f_6912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6912,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6924,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_6924(t9,t1,((C_word*)t0)[2]);}

/* lp in a6911 in a6899 in string-contains in k2533 in k2530 */
static void C_fcall f_6924(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6924,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[8]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6937,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[6]);
/* srfi-13.scm: 1367 string= */
t5=*((C_word*)lf[55]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6935 in lp in a6911 in a6899 in string-contains in k2533 in k2530 */
static void C_ccall f_6937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1369 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6924(t3,((C_word*)t0)[4],t2);}}

/* a6905 in a6899 in string-contains in k2533 in k2530 */
static void C_ccall f_6906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6906,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6893 in string-contains in k2533 in k2530 */
static void C_ccall f_6894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6894,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-copy! in k2533 in k2530 */
static void C_ccall f_6853(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_6853r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6853r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6853r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6859,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6865,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a6864 in string-copy! in k2533 in k2530 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6865,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[112]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6872,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_fixnum_difference(t3,t2);
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t6);
/* srfi-13.scm: 1347 check-substring-spec */
t8=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[4],t7);}

/* k6870 in a6864 in string-copy! in k2533 in k2530 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_substring_copy(t5,t3,t6,t7,t4));}

/* a6858 in string-copy! in k2533 in k2530 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6859,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-fill! in k2533 in k2530 */
static void C_ccall f_6812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_6812r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6812r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6812r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6818,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6824,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6823 in string-fill! in k2533 in k2530 */
static void C_ccall f_6824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6824,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6834(t5,t4));}

/* doloop1846 in a6823 in string-fill! in k2533 in k2530 */
static C_word C_fcall f_6834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=C_SCHEME_UNDEFINED;
return(t4);}
else{
t4=(C_word)C_setsubchar(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t5=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t8=t5;
t1=t8;
goto loop;}}

/* a6817 in string-fill! in k2533 in k2530 */
static void C_ccall f_6818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6818,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[111]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-count in k2533 in k2530 */
static void C_ccall f_6677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_6677r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6677r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6677r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6683,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6689,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6688 in string-count in k2533 in k2530 */
static void C_ccall f_6689(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6689,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6701,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_6701(t4,t2,C_fix(0)));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6735,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1313 char-set? */
t5=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k6733 in a6688 in string-count in k2533 in k2530 */
static void C_ccall f_6735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6735,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6740,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6740(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6779,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6779(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
/* srfi-13.scm: 1325 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[109],lf[110],*((C_word*)lf[109]+1),((C_word*)t0)[4]);}}}

/* doloop1828 in k6733 in a6688 in string-count in k2533 in k2530 */
static void C_fcall f_6779(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6779,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6800,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1322 criteria */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* k6798 in doloop1828 in k6733 in a6688 in string-count in k2533 in k2530 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)((C_word*)t0)[4])[1];
f_6779(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[5];
t3=((C_word*)((C_word*)t0)[4])[1];
f_6779(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* doloop1821 in k6733 in a6688 in string-count in k2533 in k2530 */
static void C_fcall f_6740(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6740,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6761,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1315 char-set-contains? */
t9=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k6759 in doloop1821 in k6733 in a6688 in string-count in k2533 in k2530 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)((C_word*)t0)[4])[1];
f_6740(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[5];
t3=((C_word*)((C_word*)t0)[4])[1];
f_6740(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* doloop1814 in a6688 in string-count in k2533 in k2530 */
static C_word C_fcall f_6701(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
t3=t1;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=t2;
return(t5);}
else{
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_subchar(((C_word*)t0)[3],t1);
t7=(C_word)C_eqp(((C_word*)t0)[2],t6);
if(C_truep(t7)){
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t12=t5;
t13=t8;
t1=t12;
t2=t13;
goto loop;}
else{
t8=t2;
t12=t5;
t13=t8;
t1=t12;
t2=t13;
goto loop;}}}

/* a6682 in string-count in k2533 in k2530 */
static void C_ccall f_6683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6683,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[109]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-skip-right in k2533 in k2530 */
static void C_ccall f_6542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_6542r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6542r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6542r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6548,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6554,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6553 in string-skip-right in k2533 in k2530 */
static void C_ccall f_6554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6554,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6570(t5,t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6600,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1287 char-set? */
t5=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k6598 in a6553 in string-skip-right in k2533 in k2530 */
static void C_ccall f_6600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6600,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6609(t6,((C_word*)t0)[2],t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6648(t6,((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 1298 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[94],lf[108],*((C_word*)lf[94]+1),((C_word*)t0)[3]);}}}

/* lp in k6598 in a6553 in string-skip-right in k2533 in k2530 */
static void C_fcall f_6648(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6648,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6661,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1296 criteria */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6659 in lp in k6598 in a6553 in string-skip-right in k2533 in k2530 */
static void C_ccall f_6661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1296 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6648(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in k6598 in a6553 in string-skip-right in k2533 in k2530 */
static void C_fcall f_6609(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6609,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6622,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1290 char-set-contains? */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6620 in lp in k6598 in a6553 in string-skip-right in k2533 in k2530 */
static void C_ccall f_6622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1291 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6609(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in a6553 in string-skip-right in k2533 in k2530 */
static C_word C_fcall f_6570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(0)))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}
else{
return(t1);}}
else{
return(C_SCHEME_FALSE);}}

/* a6547 in string-skip-right in k2533 in k2530 */
static void C_ccall f_6548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6548,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[94]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-skip in k2533 in k2530 */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_6419r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6419r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6419r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6425,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6431,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6430 in string-skip in k2533 in k2530 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6431,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6443,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_6443(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6473,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1265 char-set? */
t5=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k6471 in a6430 in string-skip in k2533 in k2530 */
static void C_ccall f_6473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6473,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6478,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6478(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6513,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6513(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1276 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[80],lf[107],*((C_word*)lf[80]+1),((C_word*)t0)[4]);}}}

/* lp in k6471 in a6430 in string-skip in k2533 in k2530 */
static void C_fcall f_6513(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6513,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6526,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1274 criteria */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k6524 in lp in k6471 in a6430 in string-skip in k2533 in k2530 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1274 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6513(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in k6471 in a6430 in string-skip in k2533 in k2530 */
static void C_fcall f_6478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6478,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6491,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1268 char-set-contains? */
t7=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k6489 in lp in k6471 in a6430 in string-skip in k2533 in k2530 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1269 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6478(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* lp in a6430 in string-skip in k2533 in k2530 */
static C_word C_fcall f_6443(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}
else{
return(t1);}}
else{
return(C_SCHEME_FALSE);}}

/* a6424 in string-skip in k2533 in k2530 */
static void C_ccall f_6425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6425,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[80]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-index-right in k2533 in k2530 */
static void C_ccall f_6284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_6284r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6284r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6284r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6290,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6296,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6295 in string-index-right in k2533 in k2530 */
static void C_ccall f_6296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6296,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6312,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6312(t5,t4));}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6342,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1244 char-set? */
t5=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k6340 in a6295 in string-index-right in k2533 in k2530 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6351(t6,((C_word*)t0)[2],t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_6390(t6,((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 1254 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[105],lf[106],*((C_word*)lf[105]+1),((C_word*)t0)[3]);}}}

/* lp in k6340 in a6295 in string-index-right in k2533 in k2530 */
static void C_fcall f_6390(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6390,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6403,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1252 criteria */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6401 in lp in k6340 in a6295 in string-index-right in k2533 in k2530 */
static void C_ccall f_6403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1253 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6390(t3,((C_word*)t0)[4],t2);}}

/* lp in k6340 in a6295 in string-index-right in k2533 in k2530 */
static void C_fcall f_6351(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6351,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6364,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1247 char-set-contains? */
t6=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6362 in lp in k6340 in a6295 in string-index-right in k2533 in k2530 */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1248 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6351(t3,((C_word*)t0)[4],t2);}}

/* lp in a6295 in string-index-right in k2533 in k2530 */
static C_word C_fcall f_6312(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(0)))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t1);
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t1);}
else{
t5=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a6289 in string-index-right in k2533 in k2530 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6290,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[105]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-index in k2533 in k2530 */
static void C_ccall f_6161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_6161r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6161r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6161r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6167,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6173,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6172 in string-index in k2533 in k2530 */
static void C_ccall f_6173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6173,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6185,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_6185(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6215,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1224 char-set? */
t5=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k6213 in a6172 in string-index in k2533 in k2530 */
static void C_ccall f_6215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6215,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6220,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6220(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6255,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6255(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1234 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[81],lf[104],*((C_word*)lf[81]+1),((C_word*)t0)[4]);}}}

/* lp in k6213 in a6172 in string-index in k2533 in k2530 */
static void C_fcall f_6255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6255,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6268,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1232 criteria */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k6266 in lp in k6213 in a6172 in string-index in k2533 in k2530 */
static void C_ccall f_6268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1233 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6255(t3,((C_word*)t0)[4],t2);}}

/* lp in k6213 in a6172 in string-index in k2533 in k2530 */
static void C_fcall f_6220(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6220,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6233,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 1227 char-set-contains? */
t7=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k6231 in lp in k6213 in a6172 in string-index in k2533 in k2530 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 1228 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6220(t3,((C_word*)t0)[4],t2);}}

/* lp in a6172 in string-index in k2533 in k2530 */
static C_word C_fcall f_6185(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return(t1);}
else{
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a6166 in string-index in k2533 in k2530 */
static void C_ccall f_6167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6167,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[81]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-filter in k2533 in k2530 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_6053r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6053r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6053r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6059,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6065,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6065,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6078,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1180 make-string */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6108,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6147,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1189 char-set? */
t6=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}}

/* k6145 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_6108(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-13.scm: 1190 char-set */
t2=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1191 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[102],lf[103],((C_word*)t0)[2]);}}}

/* k6106 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6134,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 1193 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6133 in k6106 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6134,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6141,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1193 char-set-contains? */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k6139 in a6133 in k6106 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6109 in k6106 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1197 make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6112 in k6109 in k6106 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6117,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6119,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1198 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6118 in k6112 in k6109 in k6106 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6119,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6126,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1198 char-set-contains? */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k6124 in a6118 in k6112 in k6109 in k6106 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6115 in k6112 in k6109 in k6106 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6076 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6081,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6092,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1181 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6091 in k6076 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6092,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6099,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1182 criteria */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6097 in a6091 in k6076 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1)));}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6079 in k6076 in a6064 in string-filter in k2533 in k2530 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1187 ##sys#substring */
t4=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* a6058 in string-filter in k2533 in k2530 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6059,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[102]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-delete in k2533 in k2530 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_5945r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5945r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5945r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5951,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5957,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5957,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[3]))){
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5970,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1153 make-string */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6000,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6039,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1161 char-set? */
t6=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}}

/* k6037 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_6039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_6000(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
/* srfi-13.scm: 1162 char-set */
t2=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1163 ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[99],lf[101],((C_word*)t0)[2]);}}}

/* k5998 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6026,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-13.scm: 1164 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6025 in k5998 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_6026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6026,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6033,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1164 char-set-contains? */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k6031 in a6025 in k5998 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_6033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1)));}}

/* k6001 in k5998 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_6003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 1168 make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6004 in k6001 in k5998 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_6006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6009,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6011,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1169 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6010 in k6004 in k6001 in k5998 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_6011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6011,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6018,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1169 char-set-contains? */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k6016 in a6010 in k6004 in k6001 in k5998 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1)));}}

/* k6007 in k6004 in k6001 in k5998 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5968 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5973,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1154 string-fold */
t4=*((C_word*)lf[19]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t2,t3,C_fix(0),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5983 in k5968 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5984,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5991,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1155 criteria */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5989 in a5983 in k5968 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_setsubchar(((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1)));}}

/* k5971 in k5968 in a5956 in string-delete in k2533 in k2530 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
/* srfi-13.scm: 1159 ##sys#substring */
t4=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* a5950 in string-delete in k2533 in k2530 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5951,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[99]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-pad in k2533 in k2530 */
static void C_ccall f_5883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_5883r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5883r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5883r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_i_check_exact_2(t3,lf[98]);
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?C_make_character(32):(C_word)C_u_i_car(t4));
t8=(C_word)C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t4,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5898,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5904,a[2]=t7,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t10,t11);}

/* a5903 in string-pad in k2533 in k2530 */
static void C_ccall f_5904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5904,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t4))){
t6=(C_word)C_u_fixnum_difference(t3,((C_word*)t0)[4]);
/* srfi-13.scm: 1128 %substring/shared */
f_2743(t1,((C_word*)t0)[3],t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5924,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 1129 make-string */
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k5922 in a5903 in string-pad in k2533 in k2530 */
static void C_ccall f_5924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=t1;
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=(C_word)C_substring_copy(t4,t3,t5,t6,t2);
t8=t1;
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* a5897 in string-pad in k2533 in k2530 */
static void C_ccall f_5898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5898,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[98]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-pad-right in k2533 in k2530 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_5825r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5825r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5825r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_i_check_exact_2(t3,lf[97]);
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?C_make_character(32):(C_word)C_u_i_car(t4));
t8=(C_word)C_i_nullp(t4);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t4,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5840,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5846,a[2]=t7,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t10,t11);}

/* a5845 in string-pad-right in k2533 in k2530 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5846,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t4))){
t6=(C_word)C_u_fixnum_plus(t2,((C_word*)t0)[4]);
/* srfi-13.scm: 1117 %substring/shared */
f_2743(t1,((C_word*)t0)[3],t2,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5866,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1118 make-string */
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k5864 in a5845 in string-pad-right in k2533 in k2530 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=t1;
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_substring_copy(t3,t2,t4,t5,C_fix(0));
t7=t1;
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* a5839 in string-pad-right in k2533 in k2530 */
static void C_ccall f_5840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5840,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[97]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim-both in k2533 in k2530 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_5770r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5770r(t0,t1,t2,t3);}}

static void C_ccall f_5770r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[90]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5782,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5788,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a5787 in string-trim-both in k2533 in k2530 */
static void C_ccall f_5788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5788,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5792,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 1105 string-skip */
t5=*((C_word*)lf[80]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k5790 in a5787 in string-trim-both in k2533 in k2530 */
static void C_ccall f_5792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5792,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* g15481549 */
t3=t2;
f_5796(t3,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[96]);}}

/* g1548 in k5790 in a5787 in string-trim-both in k2533 in k2530 */
static void C_fcall f_5796(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5796,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5808,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1107 string-skip-right */
t4=*((C_word*)lf[94]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5806 in g1548 in k5790 in a5787 in string-trim-both in k2533 in k2530 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(C_fix(1),t1);
/* srfi-13.scm: 1107 %substring/shared */
f_2743(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5781 in string-trim-both in k2533 in k2530 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5782,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[95]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim-right in k2533 in k2530 */
static void C_ccall f_5719(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_5719r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5719r(t0,t1,t2,t3);}}

static void C_ccall f_5719r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[90]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5731,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5737,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a5736 in string-trim-right in k2533 in k2530 */
static void C_ccall f_5737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5737,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5741,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 1098 string-skip-right */
t5=*((C_word*)lf[94]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k5739 in a5736 in string-trim-right in k2533 in k2530 */
static void C_ccall f_5741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5741,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5745,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* g15171518 */
t3=t2;
f_5745(t3,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[93]);}}

/* g1517 in k5739 in a5736 in string-trim-right in k2533 in k2530 */
static void C_fcall f_5745(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5745,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_fixnum_plus(C_fix(1),t2);
/* srfi-13.scm: 1099 %substring/shared */
f_2743(t1,((C_word*)t0)[2],C_fix(0),t3);}

/* a5730 in string-trim-right in k2533 in k2530 */
static void C_ccall f_5731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5731,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[92]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-trim in k2533 in k2530 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_5672r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5672r(t0,t1,t2,t3);}}

static void C_ccall f_5672r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?*((C_word*)lf[90]+1):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5684,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5690,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t8,t9);}

/* a5689 in string-trim in k2533 in k2530 */
static void C_ccall f_5690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5690,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5694,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1091 string-skip */
t5=*((C_word*)lf[80]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k5692 in a5689 in string-trim in k2533 in k2530 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5694,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5698,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* g14861487 */
t3=t2;
f_5698(t3,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[91]);}}

/* g1486 in k5692 in a5689 in string-trim in k2533 in k2530 */
static void C_fcall f_5698(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5698,NULL,3,t0,t1,t2);}
/* srfi-13.scm: 1092 %substring/shared */
f_2743(t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5683 in string-trim in k2533 in k2530 */
static void C_ccall f_5684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5684,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[89]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-drop-right in k2533 in k2530 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5645,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[88]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5652,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1081 ##sys#check-range */
t8=*((C_word*)lf[85]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[88]);}

/* k5650 in string-drop-right in k2533 in k2530 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[3]);
/* srfi-13.scm: 1085 %substring/shared */
f_2743(((C_word*)t0)[2],((C_word*)t0)[4],C_fix(0),t3);}

/* string-drop in k2533 in k2530 */
static void C_ccall f_5622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5622,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[87]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5629,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1072 ##sys#check-range */
t8=*((C_word*)lf[85]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[87]);}

/* k5627 in string-drop in k2533 in k2530 */
static void C_ccall f_5629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-13.scm: 1076 %substring/shared */
f_2743(((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2],t2);}

/* string-take-right in k2533 in k2530 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5595,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[86]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5602,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1063 ##sys#check-range */
t8=*((C_word*)lf[85]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[86]);}

/* k5600 in string-take-right in k2533 in k2530 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_difference(t2,((C_word*)t0)[3]);
/* srfi-13.scm: 1067 %substring/shared */
f_2743(((C_word*)t0)[2],((C_word*)t0)[4],t3,t2);}

/* string-take in k2533 in k2530 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5575,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[84]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5582,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(C_fix(1),t6);
/* srfi-13.scm: 1057 ##sys#check-range */
t8=*((C_word*)lf[85]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t3,C_fix(0),t7,lf[84]);}

/* k5580 in string-take in k2533 in k2530 */
static void C_ccall f_5582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 1058 %substring/shared */
f_2743(((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* string-titlecase in k2533 in k2530 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5550r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5550r(t0,t1,t2,t3);}}

static void C_ccall f_5550r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5556,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5562,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5561 in string-titlecase in k2533 in k2530 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5562,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5566,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1028 ##sys#substring */
t5=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t2,t3);}

/* k5564 in a5561 in string-titlecase in k2533 in k2530 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5569,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-13.scm: 1029 %string-titlecase! */
f_5457(t2,t1,C_fix(0),t3);}

/* k5567 in k5564 in a5561 in string-titlecase in k2533 in k2530 */
static void C_ccall f_5569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a5555 in string-titlecase in k2533 in k2530 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5556,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-titlecase! in k2533 in k2530 */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5532r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5532r(t0,t1,t2,t3);}}

static void C_ccall f_5532r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5538,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5544,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5543 in string-titlecase! in k2533 in k2530 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5544,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1024 %string-titlecase! */
f_5457(t1,((C_word*)t0)[2],t2,t3);}

/* a5537 in string-titlecase! in k2533 in k2530 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-titlecase! in k2533 in k2530 */
static void C_fcall f_5457(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5457,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5463,a[2]=t4,a[3]=t6,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5463(t8,t1,t3);}

/* lp in %string-titlecase! in k2533 in k2530 */
static void C_fcall f_5463(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5463,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5467,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5526,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 1012 string-index */
t5=*((C_word*)lf[81]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t3,((C_word*)t0)[4],t4,t2,((C_word*)t0)[2]);}

/* a5525 in lp in %string-titlecase! in k2533 in k2530 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5526,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_char_alphabeticp(t2));}

/* k5465 in lp in %string-titlecase! in k2533 in k2530 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5471,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* g13911392 */
t3=t2;
f_5471(t3,((C_word*)t0)[2],t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* g1391 in k5465 in lp in %string-titlecase! in k2533 in k2530 */
static void C_fcall f_5471(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5471,NULL,3,t0,t1,t2);}
t3=(C_word)C_subchar(((C_word*)t0)[4],t2);
t4=(C_word)C_u_i_char_upcase(t3);
t5=(C_word)C_setsubchar(((C_word*)t0)[4],t2,t4);
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5481,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5504,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 1016 string-skip */
t9=*((C_word*)lf[80]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t7,((C_word*)t0)[4],t8,t6,((C_word*)t0)[2]);}

/* a5503 in g1391 in k5465 in lp in %string-titlecase! in k2533 in k2530 */
static void C_ccall f_5504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5504,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_char_alphabeticp(t2));}

/* k5479 in g1391 in k5465 in lp in %string-titlecase! in k2533 in k2530 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5481,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5485,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* g14071408 */
t3=t2;
f_5485(t3,((C_word*)t0)[3],t1);}
else{
/* srfi-13.scm: 1020 string-downcase! */
t2=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* g1407 in k5479 in g1391 in k5465 in lp in %string-titlecase! in k2533 in k2530 */
static void C_fcall f_5485(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5485,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5489,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 1018 string-downcase! */
t4=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5487 in g1407 in k5479 in g1391 in k5465 in lp in %string-titlecase! in k2533 in k2530 */
static void C_ccall f_5489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 1019 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5463(t3,((C_word*)t0)[2],t2);}

/* string-downcase! in k2533 in k2530 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5439r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5439r(t0,t1,t2,t3);}}

static void C_ccall f_5439r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5445,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5451,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5450 in string-downcase! in k2533 in k2530 */
static void C_ccall f_5451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5451,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1008 %string-map! */
f_2862(t1,*((C_word*)lf[77]+1),((C_word*)t0)[2],t2,t3);}

/* a5444 in string-downcase! in k2533 in k2530 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[78]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-downcase in k2533 in k2530 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5421r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5421r(t0,t1,t2,t3);}}

static void C_ccall f_5421r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5427,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5433,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5432 in string-downcase in k2533 in k2530 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5433,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1004 %string-map */
f_2801(t1,*((C_word*)lf[77]+1),((C_word*)t0)[2],t2,t3);}

/* a5426 in string-downcase in k2533 in k2530 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5427,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[76]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-upcase! in k2533 in k2530 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5403r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5403r(t0,t1,t2,t3);}}

static void C_ccall f_5403r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5409,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5415,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5414 in string-upcase! in k2533 in k2530 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5415,4,t0,t1,t2,t3);}
/* srfi-13.scm: 1000 %string-map! */
f_2862(t1,*((C_word*)lf[74]+1),((C_word*)t0)[2],t2,t3);}

/* a5408 in string-upcase! in k2533 in k2530 */
static void C_ccall f_5409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5409,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[75]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-upcase in k2533 in k2530 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_5385r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5385r(t0,t1,t2,t3);}}

static void C_ccall f_5385r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5391,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5397,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5396 in string-upcase in k2533 in k2530 */
static void C_ccall f_5397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5397,4,t0,t1,t2,t3);}
/* srfi-13.scm: 996  %string-map */
f_2801(t1,*((C_word*)lf[74]+1),((C_word*)t0)[2],t2,t3);}

/* a5390 in string-upcase in k2533 in k2530 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5391,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[73]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-hash-ci in k2533 in k2530 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_5329r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5329r(t0,t1,t2,t3);}}

static void C_ccall f_5329r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_u_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5339,a[2]=t1,a[3]=t9,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t11)){
t12=C_set_block_item(t7,0,C_fix(4194304));
t13=t10;
f_5339(t13,t12);}
else{
t12=t10;
f_5339(t12,C_SCHEME_UNDEFINED);}}

/* k5337 in string-hash-ci in k2533 in k2530 */
static void C_fcall f_5339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5339,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[72]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5353,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a5352 in k5337 in string-hash-ci in k2533 in k2530 */
static void C_ccall f_5353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5353,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5359,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 979  %string-hash */
f_5211(t1,((C_word*)t0)[3],t4,((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* a5358 in a5352 in k5337 in string-hash-ci in k2533 in k2530 */
static void C_ccall f_5359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5359,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_downcase(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t3)));}

/* a5346 in k5337 in string-hash-ci in k2533 in k2530 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5347,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[72]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-hash in k2533 in k2530 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_5283r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5283r(t0,t1,t2,t3);}}

static void C_ccall f_5283r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(8);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(4194304):(C_word)C_u_i_car(t3));
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_i_nullp(t3);
t9=(C_truep(t8)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5293,a[2]=t1,a[3]=t9,a[4]=t2,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(((C_word*)t7)[1],C_fix(0));
if(C_truep(t11)){
t12=C_set_block_item(t7,0,C_fix(4194304));
t13=t10;
f_5293(t13,t12);}
else{
t12=t10;
f_5293(t12,C_SCHEME_UNDEFINED);}}

/* k5291 in string-hash in k2533 in k2530 */
static void C_fcall f_5293(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5293,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[70]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5307,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a5306 in k5291 in string-hash in k2533 in k2530 */
static void C_ccall f_5307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5307,4,t0,t1,t2,t3);}
/* srfi-13.scm: 969  %string-hash */
f_5211(t1,((C_word*)t0)[3],*((C_word*)lf[71]+1),((C_word*)((C_word*)t0)[2])[1],t2,t3);}

/* a5300 in k5291 in string-hash in k2533 in k2530 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5301,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[70]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-hash in k2533 in k2530 */
static void C_fcall f_5211(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5211,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5213,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5264,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=f_5264(t8,C_fix(65536));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5229,a[2]=t2,a[3]=t7,a[4]=t11,a[5]=t9,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t13=((C_word*)t11)[1];
f_5229(t13,t1,t5,C_fix(0));}

/* lp in %string-hash in k2533 in k2530 */
static void C_fcall f_5229(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5229,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[7];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
/* srfi-13.scm: 958  modulo */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t3,((C_word*)t0)[6]);}
else{
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(C_word)C_fixnum_times(C_fix(37),t3);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5262,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 959  iref */
t9=((C_word*)t0)[3];
f_5213(t9,t8,((C_word*)t0)[2],t2);}}

/* k5260 in lp in %string-hash in k2533 in k2530 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_and(((C_word*)t0)[5],t2);
/* srfi-13.scm: 959  lp */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5229(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* lp in %string-hash in k2533 in k2530 */
static C_word C_fcall f_5264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=t1;
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_u_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_u_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* iref in %string-hash in k2533 in k2530 */
static void C_fcall f_5213(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5213,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_subchar(t2,t3);
/* srfi-13.scm: 953  char->int */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* string-ci>= in k2533 in k2530 */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5163r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5163r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5163r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[67]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5169,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5175,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5174 in string-ci>= in k2533 in k2530 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5175,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5181,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5187,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5186 in a5174 in string-ci>= in k2533 in k2530 */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5187,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5194,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_5194(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_5194(t6,C_SCHEME_FALSE);}}

/* k5192 in a5186 in a5174 in string-ci>= in k2533 in k2530 */
static void C_fcall f_5194(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5194,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greater_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5202,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 933  %string-compare-ci */
f_4435(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,*((C_word*)lf[56]+1),*((C_word*)lf[56]+1));}}

/* a5201 in k5192 in a5186 in a5174 in string-ci>= in k2533 in k2530 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5202,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5180 in a5174 in string-ci>= in k2533 in k2530 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5181,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5168 in string-ci>= in k2533 in k2530 */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5169,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci<= in k2533 in k2530 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5115r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5115r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5115r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[66]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5121,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5127,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5126 in string-ci<= in k2533 in k2530 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5127,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5133,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5139,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5138 in a5126 in string-ci<= in k2533 in k2530 */
static void C_ccall f_5139(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5139,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5146,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_5146(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_5146(t6,C_SCHEME_FALSE);}}

/* k5144 in a5138 in a5126 in string-ci<= in k2533 in k2530 */
static void C_fcall f_5146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5146,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_less_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5154,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 922  %string-compare-ci */
f_4435(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[56]+1),*((C_word*)lf[56]+1),t2);}}

/* a5153 in k5144 in a5138 in a5126 in string-ci<= in k2533 in k2530 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5154,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5132 in a5126 in string-ci<= in k2533 in k2530 */
static void C_ccall f_5133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5133,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5120 in string-ci<= in k2533 in k2530 */
static void C_ccall f_5121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5121,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci> in k2533 in k2530 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5064r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5064r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5064r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[65]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5070,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5076,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5075 in string-ci> in k2533 in k2530 */
static void C_ccall f_5076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5076,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5082,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5088,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5087 in a5075 in string-ci> in k2533 in k2530 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5088,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5095,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_5095(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_5095(t6,C_SCHEME_FALSE);}}

/* k5093 in a5087 in a5075 in string-ci> in k2533 in k2530 */
static void C_fcall f_5095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5095,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greaterp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5103,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5106,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 911  %string-compare-ci */
f_4435(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,t3,*((C_word*)lf[56]+1));}}

/* a5105 in k5093 in a5087 in a5075 in string-ci> in k2533 in k2530 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5106,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5102 in k5093 in a5087 in a5075 in string-ci> in k2533 in k2530 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5103,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5081 in a5075 in string-ci> in k2533 in k2530 */
static void C_ccall f_5082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5082,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5069 in string-ci> in k2533 in k2530 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5070,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci< in k2533 in k2530 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_5013r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5013r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5013r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[64]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5019,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5025,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a5024 in string-ci< in k2533 in k2530 */
static void C_ccall f_5025(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5025,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5031,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5037,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a5036 in a5024 in string-ci< in k2533 in k2530 */
static void C_ccall f_5037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5037,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5044,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_5044(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_5044(t6,C_SCHEME_FALSE);}}

/* k5042 in a5036 in a5024 in string-ci< in k2533 in k2530 */
static void C_fcall f_5044(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5044,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_lessp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5052,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5055,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 900  %string-compare-ci */
f_4435(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[56]+1),t2,t3);}}

/* a5054 in k5042 in a5036 in a5024 in string-ci< in k2533 in k2530 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5055,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5051 in k5042 in a5036 in a5024 in string-ci< in k2533 in k2530 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5052,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a5030 in a5024 in string-ci< in k2533 in k2530 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5031,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5018 in string-ci< in k2533 in k2530 */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5019,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci<> in k2533 in k2530 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4946r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4946r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4946r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[63]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4952,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4958,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4957 in string-ci<> in k2533 in k2530 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4958,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4964,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4969 in a4957 in string-ci<> in k2533 in k2530 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4970,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4993,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
t11=t2;
t12=t8;
f_4993(t12,(C_word)C_eqp(t10,t11));}
else{
t10=t8;
f_4993(t10,C_SCHEME_FALSE);}}}

/* k4991 in a4969 in a4957 in string-ci<> in k2533 in k2530 */
static void C_fcall f_4993(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4993,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4988,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 889  %string-compare-ci */
f_4435(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[56]+1),t2,*((C_word*)lf[56]+1));}}

/* a4987 in k4991 in a4969 in a4957 in string-ci<> in k2533 in k2530 */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4988,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4963 in a4957 in string-ci<> in k2533 in k2530 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4964,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4951 in string-ci<> in k2533 in k2530 */
static void C_ccall f_4952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4952,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-ci= in k2533 in k2530 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4884r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4884r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4884r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[62]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4890,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4896,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4895 in string-ci= in k2533 in k2530 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4896,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4902,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4907 in a4895 in string-ci= in k2533 in k2530 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4908,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4918,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=t2;
t11=t7;
f_4918(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t7;
f_4918(t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k4916 in a4907 in a4895 in string-ci= in k2533 in k2530 */
static void C_fcall f_4918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4918,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4926,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4929,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 879  %string-compare-ci */
f_4435(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,*((C_word*)lf[56]+1),t3);}}

/* a4928 in k4916 in a4907 in a4895 in string-ci= in k2533 in k2530 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4929,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4925 in k4916 in a4907 in a4895 in string-ci= in k2533 in k2530 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4926,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4901 in a4895 in string-ci= in k2533 in k2530 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4902,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4889 in string-ci= in k2533 in k2530 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4890,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string>= in k2533 in k2530 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4836r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4836r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4836r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[61]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4842,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4848,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4847 in string>= in k2533 in k2530 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4848,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4854,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4859 in a4847 in string>= in k2533 in k2530 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4860,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4867,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4867(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4867(t6,C_SCHEME_FALSE);}}

/* k4865 in a4859 in a4847 in string>= in k2533 in k2530 */
static void C_fcall f_4867(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4867,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greater_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4875,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 869  %string-compare */
f_4373(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,*((C_word*)lf[56]+1),*((C_word*)lf[56]+1));}}

/* a4874 in k4865 in a4859 in a4847 in string>= in k2533 in k2530 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4875,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4853 in a4847 in string>= in k2533 in k2530 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4841 in string>= in k2533 in k2530 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4842,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string<= in k2533 in k2530 */
static void C_ccall f_4788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4788r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4788r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4788r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[60]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4794,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4800,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4799 in string<= in k2533 in k2530 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4800,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4806,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4812,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4811 in a4799 in string<= in k2533 in k2530 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4812,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4819,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4819(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4819(t6,C_SCHEME_FALSE);}}

/* k4817 in a4811 in a4799 in string<= in k2533 in k2530 */
static void C_fcall f_4819(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4819,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_less_or_equal_p(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4827,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 858  %string-compare */
f_4373(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[56]+1),*((C_word*)lf[56]+1),t2);}}

/* a4826 in k4817 in a4811 in a4799 in string<= in k2533 in k2530 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4827,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4805 in a4799 in string<= in k2533 in k2530 */
static void C_ccall f_4806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4806,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4793 in string<= in k2533 in k2530 */
static void C_ccall f_4794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4794,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string> in k2533 in k2530 */
static void C_ccall f_4737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4737r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4737r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4737r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[59]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4743,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4749,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4748 in string> in k2533 in k2530 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4749,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4755,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4761,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4760 in a4748 in string> in k2533 in k2530 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4761,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4768,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4768(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4768(t6,C_SCHEME_FALSE);}}

/* k4766 in a4760 in a4748 in string> in k2533 in k2530 */
static void C_fcall f_4768(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4768,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_greaterp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4776,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4779,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 847  %string-compare */
f_4373(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2,t3,*((C_word*)lf[56]+1));}}

/* a4778 in k4766 in a4760 in a4748 in string> in k2533 in k2530 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4779,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4775 in k4766 in a4760 in a4748 in string> in k2533 in k2530 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4776,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4754 in a4748 in string> in k2533 in k2530 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4742 in string> in k2533 in k2530 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4743,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string< in k2533 in k2530 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4686r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4686r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4686r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[58]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4692,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4698,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4697 in string< in k2533 in k2530 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4698,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4704,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4709 in a4697 in string< in k2533 in k2530 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4710,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4717,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[2]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t2;
t8=t4;
f_4717(t8,(C_word)C_eqp(t6,t7));}
else{
t6=t4;
f_4717(t6,C_SCHEME_FALSE);}}

/* k4715 in a4709 in a4697 in string< in k2533 in k2530 */
static void C_fcall f_4717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4717,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_lessp(t2,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4725,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4728,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 836  %string-compare */
f_4373(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],*((C_word*)lf[56]+1),t2,t3);}}

/* a4727 in k4715 in a4709 in a4697 in string< in k2533 in k2530 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4728,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4724 in k4715 in a4709 in a4697 in string< in k2533 in k2530 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4725,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4703 in a4697 in string< in k2533 in k2530 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4691 in string< in k2533 in k2530 */
static void C_ccall f_4692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4692,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string<> in k2533 in k2530 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4619r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4619r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4619r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[57]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4625,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4631,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4630 in string<> in k2533 in k2530 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4631,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4637,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4643,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4642 in a4630 in string<> in k2533 in k2530 */
static void C_ccall f_4643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4643,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
t7=(C_word)C_i_not(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4666,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
t11=t2;
t12=t8;
f_4666(t12,(C_word)C_eqp(t10,t11));}
else{
t10=t8;
f_4666(t10,C_SCHEME_FALSE);}}}

/* k4664 in a4642 in a4630 in string<> in k2533 in k2530 */
static void C_fcall f_4666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4666,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4661,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 825  %string-compare */
f_4373(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[56]+1),t2,*((C_word*)lf[56]+1));}}

/* a4660 in k4664 in a4642 in a4630 in string<> in k2533 in k2530 */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4661,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4636 in a4630 in string<> in k2533 in k2530 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4624 in string<> in k2533 in k2530 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4625,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string= in k2533 in k2530 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4557r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4557r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4557r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[55]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4563,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4569,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4568 in string= in k2533 in k2530 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4569,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4575,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4581,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4580 in a4568 in string= in k2533 in k2530 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4581,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_difference(t3,t2);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4591,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=t2;
t11=t7;
f_4591(t11,(C_word)C_eqp(t9,t10));}
else{
t9=t7;
f_4591(t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* k4589 in a4580 in a4568 in string= in k2533 in k2530 */
static void C_fcall f_4591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4591,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4599,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4602,tmp=(C_word)a,a+=2,tmp);
/* srfi-13.scm: 815  %string-compare */
f_4373(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,*((C_word*)lf[56]+1),t3);}}

/* a4601 in k4589 in a4580 in a4568 in string= in k2533 in k2530 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4602,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4598 in k4589 in a4580 in a4568 in string= in k2533 in k2530 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4599,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* a4574 in a4568 in string= in k2533 in k2530 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4575,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4562 in string= in k2533 in k2530 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-compare-ci in k2533 in k2530 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr7r,(void*)f_4527r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest(a,C_rest_count(0));
f_4527r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_4527r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t8=*((C_word*)lf[54]+1);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4533,a[2]=t7,a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4539,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t3,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a4538 in string-compare-ci in k2533 in k2530 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4539,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4545,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4550 in a4538 in string-compare-ci in k2533 in k2530 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4551,4,t0,t1,t2,t3);}
/* srfi-13.scm: 799  %string-compare-ci */
f_4435(t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4544 in a4538 in string-compare-ci in k2533 in k2530 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4545,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4532 in string-compare-ci in k2533 in k2530 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-compare in k2533 in k2530 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr7r,(void*)f_4497r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest(a,C_rest_count(0));
f_4497r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_4497r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t8=*((C_word*)lf[53]+1);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4503,a[2]=t7,a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4509,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t3,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a4508 in string-compare in k2533 in k2530 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4509,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4515,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4520 in a4508 in string-compare in k2533 in k2530 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4521,4,t0,t1,t2,t3);}
/* srfi-13.scm: 791  %string-compare */
f_4373(t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4514 in a4508 in string-compare in k2533 in k2530 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4515,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4502 in string-compare in k2533 in k2530 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4503,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-compare-ci in k2533 in k2530 */
static void C_fcall f_4435(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4435,NULL,10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
t11=(C_word)C_u_fixnum_difference(t4,t3);
t12=(C_word)C_u_fixnum_difference(t7,t6);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4445,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t3,a[6]=t10,a[7]=t8,a[8]=t4,a[9]=t1,a[10]=t9,a[11]=t12,a[12]=t11,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 776  %string-prefix-length-ci */
f_3883(t13,t2,t3,t4,t5,t6,t7);}

/* k4443 in %string-compare-ci in k2533 in k2530 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[12]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
if(C_truep(t5)){
t6=((C_word*)t0)[10];
/* g858859 */
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t6=((C_word*)t0)[7];
/* g858859 */
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,((C_word*)t0)[9],((C_word*)t0)[8]);}}
else{
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
if(C_truep(t5)){
t6=((C_word*)t0)[6];
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t1);
/* g860861 */
t8=t6;
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,((C_word*)t0)[9],t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4479,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t1);
t8=(C_word)C_subchar(((C_word*)t0)[4],t7);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t10=(C_word)C_subchar(((C_word*)t0)[2],t9);
/* srfi-13.scm: 780  char-ci<? */
t11=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t6,t8,t10);}}}

/* k4477 in k4443 in %string-compare-ci in k2533 in k2530 */
static void C_ccall f_4479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* g860861 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[2];
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* g860861 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[3],t3);}}

/* %string-compare in k2533 in k2530 */
static void C_fcall f_4373(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4373,NULL,10,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
t11=(C_word)C_u_fixnum_difference(t4,t3);
t12=(C_word)C_u_fixnum_difference(t7,t6);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4383,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t3,a[6]=t10,a[7]=t8,a[8]=t4,a[9]=t1,a[10]=t9,a[11]=t12,a[12]=t11,tmp=(C_word)a,a+=13,tmp);
/* srfi-13.scm: 762  %string-prefix-length */
f_3725(t13,t2,t3,t4,t5,t6,t7);}

/* k4381 in %string-compare in k2533 in k2530 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[12]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
if(C_truep(t5)){
t6=((C_word*)t0)[10];
/* g841842 */
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t6=((C_word*)t0)[7];
/* g841842 */
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,((C_word*)t0)[9],((C_word*)t0)[8]);}}
else{
t4=t1;
t5=(C_word)C_eqp(t4,((C_word*)t0)[11]);
if(C_truep(t5)){
t6=((C_word*)t0)[6];
t7=(C_word)C_u_fixnum_plus(t1,((C_word*)t0)[5]);
/* g843844 */
t8=t6;
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,((C_word*)t0)[9],t7);}
else{
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t1);
t7=(C_word)C_subchar(((C_word*)t0)[4],t6);
t8=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t9=(C_word)C_subchar(((C_word*)t0)[2],t8);
if(C_truep((C_word)C_fixnum_lessp(t7,t9))){
t10=((C_word*)t0)[7];
t11=(C_word)C_u_fixnum_plus(t1,((C_word*)t0)[5]);
/* g843844 */
t12=t10;
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,((C_word*)t0)[9],t11);}
else{
t10=((C_word*)t0)[6];
t11=(C_word)C_u_fixnum_plus(t1,((C_word*)t0)[5]);
/* g843844 */
t12=t10;
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,((C_word*)t0)[9],t11);}}}}

/* string-suffix-ci? in k2533 in k2530 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4251r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4251r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4251r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[49]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4257,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4263,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4262 in string-suffix-ci? in k2533 in k2530 */
static void C_ccall f_4263(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4263,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4269,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4275,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4274 in a4262 in string-suffix-ci? in k2533 in k2530 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4275,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4367,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 746  %string-suffix-length-ci */
f_3956(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k4365 in a4274 in a4262 in string-suffix-ci? in k2533 in k2530 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a4268 in a4262 in string-suffix-ci? in k2533 in k2530 */
static void C_ccall f_4269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4269,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4256 in string-suffix-ci? in k2533 in k2530 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4257,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-ci? in k2533 in k2530 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4221r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4221r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4221r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[48]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4227,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4233,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4232 in string-prefix-ci? in k2533 in k2530 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4233,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4239,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4244 in a4232 in string-prefix-ci? in k2533 in k2530 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4245,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4344,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 740  %string-prefix-length-ci */
f_3883(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k4342 in a4244 in a4232 in string-prefix-ci? in k2533 in k2530 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a4238 in a4232 in string-prefix-ci? in k2533 in k2530 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4239,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4226 in string-prefix-ci? in k2533 in k2530 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4227,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix? in k2533 in k2530 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4191r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4191r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4191r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[47]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4197,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4203,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4202 in string-suffix? in k2533 in k2530 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4203,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4209,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4215,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4214 in a4202 in string-suffix? in k2533 in k2530 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4215,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4321,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 734  %string-suffix-length */
f_3798(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k4319 in a4214 in a4202 in string-suffix? in k2533 in k2530 */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* a4208 in a4202 in string-suffix? in k2533 in k2530 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4209,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4196 in string-suffix? in k2533 in k2530 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4197,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix? in k2533 in k2530 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4161r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4161r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4161r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[46]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4167,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4173,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4172 in string-prefix? in k2533 in k2530 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4173,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4179,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4185,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4184 in a4172 in string-prefix? in k2533 in k2530 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4185,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_u_fixnum_difference(t6,t5);
t9=(C_word)C_u_fixnum_difference(t3,t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t8,t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4298,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-13.scm: 727  %string-prefix-length */
f_3725(t10,t4,t5,t6,t7,t2,t3);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k4296 in a4184 in a4172 in string-prefix? in k2533 in k2530 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(t1,((C_word*)t0)[2]));}

/* a4178 in a4172 in string-prefix? in k2533 in k2530 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4166 in string-prefix? in k2533 in k2530 */
static void C_ccall f_4167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4167,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-length-ci in k2533 in k2530 */
static void C_ccall f_4131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4131r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4131r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4131r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[45]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4137,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4143,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4142 in string-suffix-length-ci in k2533 in k2530 */
static void C_ccall f_4143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4143,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4149,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4155,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4154 in a4142 in string-suffix-length-ci in k2533 in k2530 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4155,4,t0,t1,t2,t3);}
/* srfi-13.scm: 691  %string-suffix-length-ci */
f_3956(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a4148 in a4142 in string-suffix-length-ci in k2533 in k2530 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4149,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4136 in string-suffix-length-ci in k2533 in k2530 */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4137,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-length-ci in k2533 in k2530 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4101r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4101r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4101r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[44]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4107,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4113,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4112 in string-prefix-length-ci in k2533 in k2530 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4113,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4119,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4125,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4124 in a4112 in string-prefix-length-ci in k2533 in k2530 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4125,4,t0,t1,t2,t3);}
/* srfi-13.scm: 686  %string-prefix-length-ci */
f_3883(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a4118 in a4112 in string-prefix-length-ci in k2533 in k2530 */
static void C_ccall f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4119,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4106 in string-prefix-length-ci in k2533 in k2530 */
static void C_ccall f_4107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4107,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-suffix-length in k2533 in k2530 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4071r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4071r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4071r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[43]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4077,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4083,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4082 in string-suffix-length in k2533 in k2530 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4083,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4089,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4095,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4094 in a4082 in string-suffix-length in k2533 in k2530 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4095,4,t0,t1,t2,t3);}
/* srfi-13.scm: 681  %string-suffix-length */
f_3798(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a4088 in a4082 in string-suffix-length in k2533 in k2530 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4089,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4076 in string-suffix-length in k2533 in k2530 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4077,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-prefix-length in k2533 in k2530 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4041r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4041r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4041r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t5=*((C_word*)lf[42]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4047,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4053,a[2]=t2,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a4052 in string-prefix-length in k2533 in k2530 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4053,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4059,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4065,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a4064 in a4052 in string-prefix-length in k2533 in k2530 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4065,4,t0,t1,t2,t3);}
/* srfi-13.scm: 676  %string-prefix-length */
f_3725(t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a4058 in a4052 in string-prefix-length in k2533 in k2530 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4046 in string-prefix-length in k2533 in k2530 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
/* string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-suffix-length-ci in k2533 in k2530 */
static void C_fcall f_3956(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3956,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3960,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 659  min */
t11=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k3958 in %string-suffix-length-ci in k2533 in k2530 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3960,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[4];
t7=t3;
f_3969(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_3969(t5,C_SCHEME_FALSE);}}

/* k3967 in k3958 in %string-suffix-length-ci in k2533 in k2530 */
static void C_fcall f_3969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3969,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3982(t7,((C_word*)t0)[7],t2,t3);}}

/* lp in k3967 in k3958 in %string-suffix-length-ci in k2533 in k2530 */
static void C_fcall f_3982(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3982,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_lessp(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3992(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4017,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
t9=(C_word)C_subchar(((C_word*)t0)[2],t3);
/* srfi-13.scm: 667  char-ci=? */
t10=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}}

/* k4015 in lp in k3967 in k3958 in %string-suffix-length-ci in k2533 in k2530 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3992(t2,(C_word)C_i_not(t1));}

/* k3990 in lp in k3967 in k3958 in %string-suffix-length-ci in k2533 in k2530 */
static void C_fcall f_3992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_difference(t2,C_fix(1)));}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 670  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3982(t4,((C_word*)t0)[4],t2,t3);}}

/* %string-prefix-length-ci in k2533 in k2530 */
static void C_fcall f_3883(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3883,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3887,a[2]=t6,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 645  min */
t11=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k3885 in %string-prefix-length-ci in k2533 in k2530 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3887,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[2];
t7=t3;
f_3896(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_3896(t5,C_SCHEME_FALSE);}}

/* k3894 in k3885 in %string-prefix-length-ci in k2533 in k2530 */
static void C_fcall f_3896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3896,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3901(t5,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* lp in k3894 in k3885 in %string-prefix-length-ci in k2533 in k2530 */
static void C_fcall f_3901(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3901,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3911(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3932,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_subchar(((C_word*)t0)[3],t2);
t9=(C_word)C_subchar(((C_word*)t0)[2],t3);
/* srfi-13.scm: 653  char-ci=? */
t10=*((C_word*)lf[40]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}}

/* k3930 in lp in k3894 in k3885 in %string-prefix-length-ci in k2533 in k2530 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3911(t2,(C_word)C_i_not(t1));}

/* k3909 in lp in k3894 in k3885 in %string-prefix-length-ci in k2533 in k2530 */
static void C_fcall f_3911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 656  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3901(t4,((C_word*)t0)[6],t2,t3);}}

/* %string-suffix-length in k2533 in k2530 */
static void C_fcall f_3798(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3798,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3802,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 631  min */
t11=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k3800 in %string-suffix-length in k2533 in k2530 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3802,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[4];
t7=t3;
f_3811(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_3811(t5,C_SCHEME_FALSE);}}

/* k3809 in k3800 in %string-suffix-length in k2533 in k2530 */
static void C_fcall f_3811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3811,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3824(t7,((C_word*)t0)[7],t2,t3);}}

/* lp in k3809 in k3800 in %string-suffix-length in k2533 in k2530 */
static void C_fcall f_3824(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3824,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_lessp(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3834(t7,t5);}
else{
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
t8=(C_word)C_subchar(((C_word*)t0)[2],t3);
t9=(C_word)C_eqp(t7,t8);
t10=t6;
f_3834(t10,(C_word)C_i_not(t9));}}

/* k3832 in lp in k3809 in k3800 in %string-suffix-length in k2533 in k2530 */
static void C_fcall f_3834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_difference(t2,C_fix(1)));}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 642  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3824(t4,((C_word*)t0)[4],t2,t3);}}

/* %string-prefix-length in k2533 in k2530 */
static void C_fcall f_3725(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3725,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3729,a[2]=t6,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_u_fixnum_difference(t4,t3);
t10=(C_word)C_u_fixnum_difference(t7,t6);
/* srfi-13.scm: 617  min */
t11=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}

/* k3727 in %string-prefix-length in k2533 in k2530 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3729,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
t6=((C_word*)t0)[2];
t7=t3;
f_3738(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t3;
f_3738(t5,C_SCHEME_FALSE);}}

/* k3736 in k3727 in %string-prefix-length in k2533 in k2530 */
static void C_fcall f_3738(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3738,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3743,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3743(t5,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* lp in k3736 in k3727 in %string-prefix-length in k2533 in k2530 */
static void C_fcall f_3743(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3743,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3753(t7,t5);}
else{
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
t8=(C_word)C_subchar(((C_word*)t0)[2],t3);
t9=(C_word)C_eqp(t7,t8);
t10=t6;
f_3753(t10,(C_word)C_i_not(t9));}}

/* k3751 in lp in k3736 in k3727 in %string-prefix-length in k2533 in k2530 */
static void C_fcall f_3753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 628  lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3743(t4,((C_word*)t0)[6],t2,t3);}}

/* string-tabulate in k2533 in k2530 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3686,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[36]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3693,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 599  make-string */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k3691 in string-tabulate in k2533 in k2530 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3696,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3702,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3702(t7,t2,t3);}

/* doloop503 in k3691 in string-tabulate in k2533 in k2530 */
static void C_fcall f_3702(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3702,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3723,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 602  proc */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k3721 in doloop503 in k3691 in string-tabulate in k2533 in k2530 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3702(t4,((C_word*)t0)[2],t3);}

/* k3694 in k3691 in string-tabulate in k2533 in k2530 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-any in k2533 in k2530 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_3556r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3556r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3556r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3562,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3568,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3567 in string-any in k2533 in k2530 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3568,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3580,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3580(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3610,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 576  char-set? */
t5=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k3608 in a3567 in string-any in k2533 in k2530 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3610,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3615,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3615(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[6];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3656,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3656(t7,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
/* srfi-13.scm: 590  ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[34],lf[35],*((C_word*)lf[34]+1),((C_word*)t0)[4]);}}}

/* lp in k3608 in a3567 in string-any in k2533 in k2530 */
static void C_fcall f_3656(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3656,NULL,3,t0,t1,t2);}
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=((C_word*)t0)[4];
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
/* srfi-13.scm: 587  criteria */
t7=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3675,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 588  criteria */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k3673 in lp in k3608 in a3567 in string-any in k2533 in k2530 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* srfi-13.scm: 588  lp */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3656(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* lp in k3608 in a3567 in string-any in k2533 in k2530 */
static void C_fcall f_3615(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3615,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 579  char-set-contains? */
t7=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k3623 in lp in k3608 in a3567 in string-any in k2533 in k2530 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-13.scm: 580  lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3615(t3,((C_word*)t0)[4],t2);}}

/* lp in a3567 in string-any in k2533 in k2530 */
static C_word C_fcall f_3580(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=t1;
t3=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return(t5);}
else{
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* a3561 in string-any in k2533 in k2530 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3562,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[34]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-every in k2533 in k2530 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_3426r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3426r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3426r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3432,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3438,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3437 in string-every in k2533 in k2530 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3438,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_charp(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3450(t4,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3480,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 550  char-set? */
t5=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k3478 in a3437 in string-every in k2533 in k2530 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3485,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3485(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[4]))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[6];
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3526,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3526(t8,((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
/* srfi-13.scm: 564  ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[30],lf[32],*((C_word*)lf[30]+1),((C_word*)t0)[4]);}}}

/* lp in k3478 in a3437 in string-every in k2533 in k2530 */
static void C_fcall f_3526(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3526,NULL,3,t0,t1,t2);}
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=((C_word*)t0)[4];
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
/* srfi-13.scm: 561  criteria */
t7=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3548,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 562  criteria */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k3546 in lp in k3478 in a3437 in string-every in k2533 in k2530 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-13.scm: 562  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3526(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lp in k3478 in a3437 in string-every in k2533 in k2530 */
static void C_fcall f_3485(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3485,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
t5=(C_word)C_fixnum_greater_or_equal_p(t3,t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3498,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 553  char-set-contains? */
t8=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k3496 in lp in k3478 in a3437 in string-every in k2533 in k2530 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 554  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3485(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lp in a3437 in string-every in k2533 in k2530 */
static C_word C_fcall f_3450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=t1;
t3=((C_word*)t0)[4];
t4=(C_word)C_fixnum_greater_or_equal_p(t2,t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[3],t1);
t6=(C_word)C_eqp(((C_word*)t0)[2],t5);
if(C_truep(t6)){
t7=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* a3431 in string-every in k2533 in k2530 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3432,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[30]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-for-each-index in k2533 in k2530 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_3389r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3389r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3389r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3395,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3401,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3400 in string-for-each-index in k2533 in k2530 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3401,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3407,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3407(t7,t1,t2);}

/* lp in a3400 in string-for-each-index in k2533 in k2530 */
static void C_fcall f_3407(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3407,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3417,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-13.scm: 540  proc */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k3415 in lp in a3400 in string-for-each-index in k2533 in k2530 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 540  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3407(t3,((C_word*)t0)[2],t2);}

/* a3394 in string-for-each-index in k2533 in k2530 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3395,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[29]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-for-each in k2533 in k2530 */
static void C_ccall f_3348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_3348r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3348r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3348r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3354,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3360,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a3359 in string-for-each in k2533 in k2530 */
static void C_ccall f_3360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3360,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3366(t7,t1,t2);}

/* lp in a3359 in string-for-each in k2533 in k2530 */
static void C_fcall f_3366(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3366,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3376,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
/* srfi-13.scm: 533  proc */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k3374 in lp in a3359 in string-for-each in k2533 in k2530 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 534  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3366(t3,((C_word*)t0)[2],t2);}

/* a3353 in string-for-each in k2533 in k2530 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3354,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[28]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-unfold-right in k2533 in k2530 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr6r,(void*)f_3162r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_3162r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_3162r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(11);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?lf[26]:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3330,tmp=(C_word)a,a+=2,tmp):(C_word)C_u_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t10,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3185,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=t12,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 486  make-string */
t16=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,C_fix(40));}

/* k3183 in string-unfold-right in k2533 in k2530 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3187,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3187(t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_fix(0),t1,C_fix(40),C_fix(40),((C_word*)t0)[2]);}

/* lp in k3183 in string-unfold-right in k2533 in k2530 */
static void C_fcall f_3187(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3187,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t4,a[10]=t3,a[11]=t5,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp));
t11=((C_word*)t9)[1];
f_3193(t11,t1,t6,t7);}

/* lp2 in lp in k3183 in string-unfold-right in k2533 in k2530 */
static void C_fcall f_3193(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3193,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
/* srfi-13.scm: 491  p */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3315 in lp2 in lp in k3183 in string-unfold-right in k2533 in k2530 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3250,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 508  make-final */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3203,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 492  f */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k3201 in k3315 in lp2 in lp in k3183 in string-unfold-right in k2533 in k2530 */
static void C_ccall f_3203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3206,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 493  g */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3204 in k3201 in k3315 in lp2 in lp in k3183 in string-unfold-right in k2533 in k2530 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3206,2,t0,t1);}
t2=((C_word*)t0)[10];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[10],C_fix(1));
t4=(C_word)C_setsubchar(((C_word*)t0)[9],t3,((C_word*)t0)[8]);
/* srfi-13.scm: 497  lp2 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_3193(t5,((C_word*)t0)[6],t3,t1);}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3227,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 500  min */
t5=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(4096),t3);}}

/* k3225 in k3204 in k3201 in k3315 in lp2 in lp in k3183 in string-unfold-right in k2533 in k2530 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 501  make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3228 in k3225 in k3204 in k3201 in k3315 in lp2 in lp in k3183 in string-unfold-right in k2533 in k2530 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3230,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_setsubchar(t1,t2,((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
/* srfi-13.scm: 504  lp */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3187(t6,((C_word*)t0)[3],t4,t5,t1,((C_word*)t0)[10],t2,((C_word*)t0)[2]);}

/* k3248 in k3315 in lp2 in lp in k3183 in string-unfold-right in k2533 in k2530 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3250,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[8]));
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(t3,((C_word*)t0)[5]),t4);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[4],a[10]=t2,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_u_fixnum_plus(t5,t2);
/* srfi-13.scm: 513  make-string */
t8=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k3263 in k3248 in k3315 in lp2 in lp in k3183 in string-unfold-right in k2533 in k2530 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[11];
t4=(C_word)C_substring_copy(t3,t2,C_fix(0),((C_word*)t0)[10],C_fix(0));
t5=t1;
t6=((C_word*)t0)[9];
t7=((C_word*)t0)[8];
t8=((C_word*)t0)[7];
t9=(C_word)C_substring_copy(t6,t5,t7,t8,((C_word*)t0)[10]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3274,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],((C_word*)t0)[5]);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t13,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_3280(t15,t10,t11,((C_word*)t0)[2]);}

/* lp in k3263 in k3248 in k3315 in lp2 in lp in k3183 in string-unfold-right in k2533 in k2530 */
static void C_fcall f_3280(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3280,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_fix((C_word)C_header_size(t4));
t7=((C_word*)t0)[5];
t8=t2;
t9=(C_word)C_substring_copy(t4,t7,C_fix(0),t6,t8);
t10=(C_word)C_u_fixnum_plus(t2,t6);
/* srfi-13.scm: 523  lp */
t15=t1;
t16=t10;
t17=t5;
t1=t15;
t2=t16;
t3=t17;
goto loop;}
else{
t4=t1;
t5=((C_word*)t0)[5];
t6=t2;
t7=t4;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_substring_copy(((C_word*)t0)[3],t5,C_fix(0),((C_word*)t0)[2],t6));}}

/* k3272 in k3263 in k3248 in k3315 in lp2 in lp in k3183 in string-unfold-right in k2533 in k2530 */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_3330 in string-unfold-right in k2533 in k2530 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3330,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[27]);}

/* string-unfold in k2533 in k2530 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr6r,(void*)f_2983r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_2983r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_2983r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(11);
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?lf[22]:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_word)C_i_nullp(t10);
t12=(C_truep(t11)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3144,tmp=(C_word)a,a+=2,tmp):(C_word)C_u_i_car(t10));
t13=(C_word)C_i_nullp(t10);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t10,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3006,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=t4,a[7]=t12,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* srfi-13.scm: 441  make-string */
t16=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,C_fix(40));}

/* k3004 in string-unfold in k2533 in k2530 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3008,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3008(t5,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_fix(0),t1,C_fix(40),C_fix(0),((C_word*)t0)[2]);}

/* lp in k3004 in string-unfold in k2533 in k2530 */
static void C_fcall f_3008(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3008,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=t5,a[8]=((C_word*)t0)[6],a[9]=t2,a[10]=t4,a[11]=t3,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp));
t11=((C_word*)t9)[1];
f_3014(t11,t1,t6,t7);}

/* lp2 in lp in k3004 in string-unfold in k2533 in k2530 */
static void C_fcall f_3014(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3014,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
/* srfi-13.scm: 446  p */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3129 in lp2 in lp in k3004 in string-unfold in k2533 in k2530 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3131,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3069,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
/* srfi-13.scm: 461  make-final */
t3=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3024,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* srfi-13.scm: 447  f */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}}

/* k3022 in k3129 in lp2 in lp in k3004 in string-unfold in k2533 in k2530 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 448  g */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3025 in k3022 in k3129 in lp2 in lp in k3004 in string-unfold in k2533 in k2530 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3027,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=((C_word*)t0)[9];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[10],((C_word*)t0)[7]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* srfi-13.scm: 451  lp2 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3014(t6,((C_word*)t0)[5],t5,t1);}
else{
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3049,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* srfi-13.scm: 454  min */
t6=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(4096),t4);}}

/* k3047 in k3025 in k3022 in k3129 in lp2 in lp in k3004 in string-unfold in k2533 in k2530 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* srfi-13.scm: 455  make-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3050 in k3047 in k3025 in k3022 in k3129 in lp2 in lp in k3004 in string-unfold in k2533 in k2530 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
t2=(C_word)C_setsubchar(t1,C_fix(0),((C_word*)t0)[10]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],((C_word*)t0)[6]);
/* srfi-13.scm: 457  lp */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3008(t5,((C_word*)t0)[4],t3,t4,t1,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}

/* k3067 in k3129 in lp2 in lp in k3004 in string-unfold in k2533 in k2530 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3069,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t4=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(t3,((C_word*)t0)[6]),((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3081,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t2,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_u_fixnum_plus(t4,t2);
/* srfi-13.scm: 465  make-string */
t7=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k3079 in k3067 in k3129 in lp2 in lp in k3004 in string-unfold in k2533 in k2530 */
static void C_ccall f_3081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3081,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[10];
t4=(C_word)C_substring_copy(t3,t2,C_fix(0),((C_word*)t0)[9],((C_word*)t0)[8]);
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[8],((C_word*)t0)[7]);
t6=t1;
t7=((C_word*)t0)[6];
t8=((C_word*)t0)[7];
t9=(C_word)C_substring_copy(t7,t6,C_fix(0),t8,t5);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3098,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=f_3098(t10,t5,((C_word*)t0)[5]);
t12=t1;
t13=(C_word)C_substring_copy(((C_word*)t0)[4],t12,C_fix(0),((C_word*)t0)[3],C_fix(0));
t14=t1;
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}

/* lp in k3079 in k3067 in k3129 in lp2 in lp in k3004 in string-unfold in k2533 in k2530 */
static C_word C_fcall f_3098(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_fix((C_word)C_header_size(t3));
t6=(C_word)C_u_fixnum_difference(t1,t5);
t7=((C_word*)t0)[2];
t8=(C_word)C_substring_copy(t3,t7,C_fix(0),t5,t6);
t11=t6;
t12=t4;
t1=t11;
t2=t12;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* f_3144 in string-unfold in k2533 in k2530 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3144,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[23]);}

/* string-fold-right in k2533 in k2530 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_2937r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2937r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2937r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2943,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2949,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a2948 in string-fold-right in k2533 in k2530 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2949,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2959(t8,t1,((C_word*)t0)[2],t4);}

/* lp in a2948 in string-fold-right in k2533 in k2530 */
static void C_fcall f_2959(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2959,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2973,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_subchar(((C_word*)t0)[3],t3);
/* srfi-13.scm: 366  kons */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}
else{
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2971 in lp in a2948 in string-fold-right in k2533 in k2530 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 366  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2959(t3,((C_word*)t0)[2],t1,t2);}

/* a2942 in string-fold-right in k2533 in k2530 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2943,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[20]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-fold in k2533 in k2530 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_2895r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2895r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2895r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2901,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2907,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}

/* a2906 in string-fold in k2533 in k2530 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2907,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2913(t7,t1,((C_word*)t0)[2],t2);}

/* lp in a2906 in string-fold in k2533 in k2530 */
static void C_fcall f_2913(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2913,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2927,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_subchar(((C_word*)t0)[3],t3);
/* srfi-13.scm: 359  kons */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}
else{
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2925 in lp in a2906 in string-fold in k2533 in k2530 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-13.scm: 359  lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2913(t3,((C_word*)t0)[2],t1,t2);}

/* a2900 in string-fold in k2533 in k2530 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[19]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-map! in k2533 in k2530 */
static void C_fcall f_2862(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2862,NULL,5,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2868,a[2]=t2,a[3]=t7,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2868(t9,t1,t4);}

/* doloop214 in %string-map! in k2533 in k2530 */
static void C_fcall f_2868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2868,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=((C_word*)t0)[4];
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2889,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[4],t2);
/* srfi-13.scm: 353  proc */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k2887 in doloop214 in %string-map! in k2533 in k2530 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2868(t4,((C_word*)t0)[2],t3);}

/* string-map! in k2533 in k2530 */
static void C_ccall f_2844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_2844r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2844r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2844r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2850,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2856,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a2855 in string-map! in k2533 in k2530 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2856,4,t0,t1,t2,t3);}
/* srfi-13.scm: 348  %string-map! */
f_2862(t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2849 in string-map! in k2533 in k2530 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[17]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string-map in k2533 in k2530 */
static void C_fcall f_2801(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2801,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_u_fixnum_difference(t5,t4);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2808,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 338  make-string */
t8=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}

/* k2806 in %string-map in k2533 in k2530 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2811,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2813,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2813(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* doloop189 in k2806 in %string-map in k2533 in k2530 */
static void C_fcall f_2813(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2813,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[6]))){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2838,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_subchar(((C_word*)t0)[3],t3);
/* srfi-13.scm: 342  proc */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k2836 in doloop189 in k2806 in %string-map in k2533 in k2530 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2813(t5,((C_word*)t0)[2],t3,t4);}

/* k2809 in k2806 in %string-map in k2533 in k2530 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-map in k2533 in k2530 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_2783r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2783r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2783r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2789,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2795,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a2794 in string-map in k2533 in k2530 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2795,4,t0,t1,t2,t3);}
/* srfi-13.scm: 334  %string-map */
f_2801(t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2788 in string-map in k2533 in k2530 */
static void C_ccall f_2789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2789,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[14]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-copy in k2533 in k2530 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2765r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2765r(t0,t1,t2,t3);}}

static void C_ccall f_2765r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2771,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2777,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a2776 in string-copy in k2533 in k2530 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2777,4,t0,t1,t2,t3);}
/* srfi-13.scm: 299  ##sys#substring */
t4=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* a2770 in string-copy in k2533 in k2530 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2771,2,t0,t1);}
/* string-parse-final-start+end */
t2=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %substring/shared in k2533 in k2530 */
static void C_fcall f_2743(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2743,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2750,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_fix((C_word)C_header_size(t2));
t8=t4;
t9=t5;
f_2750(t9,(C_word)C_eqp(t8,t7));}
else{
t7=t5;
f_2750(t7,C_SCHEME_FALSE);}}

/* k2748 in %substring/shared in k2533 in k2530 */
static void C_fcall f_2750(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* srfi-13.scm: 295  ##sys#substring */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* substring/shared in k2533 in k2530 */
static void C_ccall f_2713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2713r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2713r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2713r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_fix((C_word)C_header_size(t2));
t6=(C_word)C_i_nullp(t4);
t7=(C_truep(t6)?t5:(C_word)C_u_i_car(t4));
t8=(C_word)C_i_check_exact_2(t7,lf[10]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2726,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-13.scm: 280  check-substring-spec */
t10=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[10],t2,t3,t7);}

/* k2724 in substring/shared in k2533 in k2530 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-13.scm: 281  %substring/shared */
f_2743(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* check-substring-spec in k2533 in k2530 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2697,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2711,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-13.scm: 248  substring-spec-ok? */
t7=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t3,t4,t5);}

/* k2709 in check-substring-spec in k2533 in k2530 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* srfi-13.scm: 249  ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[6],lf[8],lf[9],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* substring-spec-ok? in k2533 in k2530 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2657,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_stringp(t2))){
if(C_truep((C_word)C_fixnump(t3))){
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t5))){
t6=t3;
t7=t4;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,t7))){
t8=(C_word)C_fix((C_word)C_header_size(t2));
t9=t4;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_fixnum_less_or_equal_p(t9,t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* string-parse-final-start+end in k2533 in k2530 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2630,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2636,a[2]=t4,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2642,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}

/* a2641 in string-parse-final-start+end in k2533 in k2530 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2642,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
/* srfi-13.scm: 232  ##sys#error */
t5=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[5],lf[6],((C_word*)t0)[2],t2);}
else{
/* srfi-13.scm: 233  values */
C_values(4,0,t1,t3,t4);}}

/* a2635 in string-parse-final-start+end in k2533 in k2530 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2636,2,t0,t1);}
/* srfi-13.scm: 231  string-parse-start+end */
t2=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* string-parse-start+end in k2533 in k2530 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2537,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t3,lf[0]);
t6=(C_word)C_fix((C_word)C_header_size(t3));
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_u_i_car(t4);
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_truep((C_word)C_fixnump(t7))?(C_word)C_fixnum_greater_or_equal_p(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2567,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2603,a[2]=t3,a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t10,t11);}
else{
/* srfi-13.scm: 226  ##sys#error */
t10=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t1,lf[0],lf[4],t2,t7,t3);}}
else{
/* srfi-13.scm: 228  values */
C_values(5,0,t1,C_SCHEME_END_OF_LIST,C_fix(0),t6);}}

/* a2602 in string-parse-start+end in k2533 in k2530 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2603,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],t4))){
/* srfi-13.scm: 223  values */
C_values(5,0,t1,t3,((C_word*)t0)[4],t2);}
else{
/* srfi-13.scm: 224  ##sys#error */
t5=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t1,lf[0],lf[3],((C_word*)t0)[3],((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* a2566 in string-parse-start+end in k2533 in k2530 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2567,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_truep((C_word)C_fixnump(t2))?(C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-13.scm: 220  values */
C_values(4,0,t1,t2,t3);}
else{
/* srfi-13.scm: 221  ##sys#error */
t5=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[0],lf[2],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}
else{
/* srfi-13.scm: 222  values */
C_values(4,0,t1,((C_word*)t0)[4],((C_word*)t0)[5]);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[541] = {
{"toplevel:srfi_13_scm",(void*)C_srfi_13_toplevel},
{"f_2532:srfi_13_scm",(void*)f_2532},
{"f_2535:srfi_13_scm",(void*)f_2535},
{"f_8394:srfi_13_scm",(void*)f_8394},
{"f_8503:srfi_13_scm",(void*)f_8503},
{"f_8473:srfi_13_scm",(void*)f_8473},
{"f_8456:srfi_13_scm",(void*)f_8456},
{"f_8411:srfi_13_scm",(void*)f_8411},
{"f_8417:srfi_13_scm",(void*)f_8417},
{"f_8439:srfi_13_scm",(void*)f_8439},
{"f_8321:srfi_13_scm",(void*)f_8321},
{"f_8392:srfi_13_scm",(void*)f_8392},
{"f_8352:srfi_13_scm",(void*)f_8352},
{"f_8181:srfi_13_scm",(void*)f_8181},
{"f_8234:srfi_13_scm",(void*)f_8234},
{"f_8247:srfi_13_scm",(void*)f_8247},
{"f_8300:srfi_13_scm",(void*)f_8300},
{"f_8296:srfi_13_scm",(void*)f_8296},
{"f_8190:srfi_13_scm",(void*)f_8190},
{"f_8212:srfi_13_scm",(void*)f_8212},
{"f_8202:srfi_13_scm",(void*)f_8202},
{"f_8043:srfi_13_scm",(void*)f_8043},
{"f_8096:srfi_13_scm",(void*)f_8096},
{"f_8159:srfi_13_scm",(void*)f_8159},
{"f_8162:srfi_13_scm",(void*)f_8162},
{"f_8156:srfi_13_scm",(void*)f_8156},
{"f_8152:srfi_13_scm",(void*)f_8152},
{"f_8052:srfi_13_scm",(void*)f_8052},
{"f_8074:srfi_13_scm",(void*)f_8074},
{"f_8064:srfi_13_scm",(void*)f_8064},
{"f_7951:srfi_13_scm",(void*)f_7951},
{"f_7969:srfi_13_scm",(void*)f_7969},
{"f_7975:srfi_13_scm",(void*)f_7975},
{"f_7979:srfi_13_scm",(void*)f_7979},
{"f_7983:srfi_13_scm",(void*)f_7983},
{"f_7990:srfi_13_scm",(void*)f_7990},
{"f_8020:srfi_13_scm",(void*)f_8020},
{"f_7994:srfi_13_scm",(void*)f_7994},
{"f_8006:srfi_13_scm",(void*)f_8006},
{"f_7963:srfi_13_scm",(void*)f_7963},
{"f_7900:srfi_13_scm",(void*)f_7900},
{"f_7904:srfi_13_scm",(void*)f_7904},
{"f_7915:srfi_13_scm",(void*)f_7915},
{"f_7928:srfi_13_scm",(void*)f_7928},
{"f_7909:srfi_13_scm",(void*)f_7909},
{"f_7857:srfi_13_scm",(void*)f_7857},
{"f_7861:srfi_13_scm",(void*)f_7861},
{"f_7869:srfi_13_scm",(void*)f_7869},
{"f_7731:srfi_13_scm",(void*)f_7731},
{"f_7755:srfi_13_scm",(void*)f_7755},
{"f_7805:srfi_13_scm",(void*)f_7805},
{"f_7646:srfi_13_scm",(void*)f_7646},
{"f_7673:srfi_13_scm",(void*)f_7673},
{"f_7573:srfi_13_scm",(void*)f_7573},
{"f_7580:srfi_13_scm",(void*)f_7580},
{"f_7585:srfi_13_scm",(void*)f_7585},
{"f_7614:srfi_13_scm",(void*)f_7614},
{"f_7471:srfi_13_scm",(void*)f_7471},
{"f_7477:srfi_13_scm",(void*)f_7477},
{"f_7531:srfi_13_scm",(void*)f_7531},
{"f_7536:srfi_13_scm",(void*)f_7536},
{"f_7465:srfi_13_scm",(void*)f_7465},
{"f_7419:srfi_13_scm",(void*)f_7419},
{"f_7431:srfi_13_scm",(void*)f_7431},
{"f_7441:srfi_13_scm",(void*)f_7441},
{"f_7425:srfi_13_scm",(void*)f_7425},
{"f_7364:srfi_13_scm",(void*)f_7364},
{"f_7376:srfi_13_scm",(void*)f_7376},
{"f_7386:srfi_13_scm",(void*)f_7386},
{"f_7370:srfi_13_scm",(void*)f_7370},
{"f_7309:srfi_13_scm",(void*)f_7309},
{"f_7321:srfi_13_scm",(void*)f_7321},
{"f_7328:srfi_13_scm",(void*)f_7328},
{"f_7337:srfi_13_scm",(void*)f_7337},
{"f_7315:srfi_13_scm",(void*)f_7315},
{"f_7306:srfi_13_scm",(void*)f_7306},
{"f_7185:srfi_13_scm",(void*)f_7185},
{"f_7209:srfi_13_scm",(void*)f_7209},
{"f_7218:srfi_13_scm",(void*)f_7218},
{"f_7250:srfi_13_scm",(void*)f_7250},
{"f_7257:srfi_13_scm",(void*)f_7257},
{"f_7248:srfi_13_scm",(void*)f_7248},
{"f_7203:srfi_13_scm",(void*)f_7203},
{"f_7147:srfi_13_scm",(void*)f_7147},
{"f_7153:srfi_13_scm",(void*)f_7153},
{"f_7160:srfi_13_scm",(void*)f_7160},
{"f_7012:srfi_13_scm",(void*)f_7012},
{"f_7030:srfi_13_scm",(void*)f_7030},
{"f_7037:srfi_13_scm",(void*)f_7037},
{"f_7054:srfi_13_scm",(void*)f_7054},
{"f_7069:srfi_13_scm",(void*)f_7069},
{"f_7102:srfi_13_scm",(void*)f_7102},
{"f_7096:srfi_13_scm",(void*)f_7096},
{"f_7040:srfi_13_scm",(void*)f_7040},
{"f_7024:srfi_13_scm",(void*)f_7024},
{"f_6950:srfi_13_scm",(void*)f_6950},
{"f_6962:srfi_13_scm",(void*)f_6962},
{"f_6974:srfi_13_scm",(void*)f_6974},
{"f_6986:srfi_13_scm",(void*)f_6986},
{"f_6999:srfi_13_scm",(void*)f_6999},
{"f_6968:srfi_13_scm",(void*)f_6968},
{"f_6956:srfi_13_scm",(void*)f_6956},
{"f_6888:srfi_13_scm",(void*)f_6888},
{"f_6900:srfi_13_scm",(void*)f_6900},
{"f_6912:srfi_13_scm",(void*)f_6912},
{"f_6924:srfi_13_scm",(void*)f_6924},
{"f_6937:srfi_13_scm",(void*)f_6937},
{"f_6906:srfi_13_scm",(void*)f_6906},
{"f_6894:srfi_13_scm",(void*)f_6894},
{"f_6853:srfi_13_scm",(void*)f_6853},
{"f_6865:srfi_13_scm",(void*)f_6865},
{"f_6872:srfi_13_scm",(void*)f_6872},
{"f_6859:srfi_13_scm",(void*)f_6859},
{"f_6812:srfi_13_scm",(void*)f_6812},
{"f_6824:srfi_13_scm",(void*)f_6824},
{"f_6834:srfi_13_scm",(void*)f_6834},
{"f_6818:srfi_13_scm",(void*)f_6818},
{"f_6677:srfi_13_scm",(void*)f_6677},
{"f_6689:srfi_13_scm",(void*)f_6689},
{"f_6735:srfi_13_scm",(void*)f_6735},
{"f_6779:srfi_13_scm",(void*)f_6779},
{"f_6800:srfi_13_scm",(void*)f_6800},
{"f_6740:srfi_13_scm",(void*)f_6740},
{"f_6761:srfi_13_scm",(void*)f_6761},
{"f_6701:srfi_13_scm",(void*)f_6701},
{"f_6683:srfi_13_scm",(void*)f_6683},
{"f_6542:srfi_13_scm",(void*)f_6542},
{"f_6554:srfi_13_scm",(void*)f_6554},
{"f_6600:srfi_13_scm",(void*)f_6600},
{"f_6648:srfi_13_scm",(void*)f_6648},
{"f_6661:srfi_13_scm",(void*)f_6661},
{"f_6609:srfi_13_scm",(void*)f_6609},
{"f_6622:srfi_13_scm",(void*)f_6622},
{"f_6570:srfi_13_scm",(void*)f_6570},
{"f_6548:srfi_13_scm",(void*)f_6548},
{"f_6419:srfi_13_scm",(void*)f_6419},
{"f_6431:srfi_13_scm",(void*)f_6431},
{"f_6473:srfi_13_scm",(void*)f_6473},
{"f_6513:srfi_13_scm",(void*)f_6513},
{"f_6526:srfi_13_scm",(void*)f_6526},
{"f_6478:srfi_13_scm",(void*)f_6478},
{"f_6491:srfi_13_scm",(void*)f_6491},
{"f_6443:srfi_13_scm",(void*)f_6443},
{"f_6425:srfi_13_scm",(void*)f_6425},
{"f_6284:srfi_13_scm",(void*)f_6284},
{"f_6296:srfi_13_scm",(void*)f_6296},
{"f_6342:srfi_13_scm",(void*)f_6342},
{"f_6390:srfi_13_scm",(void*)f_6390},
{"f_6403:srfi_13_scm",(void*)f_6403},
{"f_6351:srfi_13_scm",(void*)f_6351},
{"f_6364:srfi_13_scm",(void*)f_6364},
{"f_6312:srfi_13_scm",(void*)f_6312},
{"f_6290:srfi_13_scm",(void*)f_6290},
{"f_6161:srfi_13_scm",(void*)f_6161},
{"f_6173:srfi_13_scm",(void*)f_6173},
{"f_6215:srfi_13_scm",(void*)f_6215},
{"f_6255:srfi_13_scm",(void*)f_6255},
{"f_6268:srfi_13_scm",(void*)f_6268},
{"f_6220:srfi_13_scm",(void*)f_6220},
{"f_6233:srfi_13_scm",(void*)f_6233},
{"f_6185:srfi_13_scm",(void*)f_6185},
{"f_6167:srfi_13_scm",(void*)f_6167},
{"f_6053:srfi_13_scm",(void*)f_6053},
{"f_6065:srfi_13_scm",(void*)f_6065},
{"f_6147:srfi_13_scm",(void*)f_6147},
{"f_6108:srfi_13_scm",(void*)f_6108},
{"f_6134:srfi_13_scm",(void*)f_6134},
{"f_6141:srfi_13_scm",(void*)f_6141},
{"f_6111:srfi_13_scm",(void*)f_6111},
{"f_6114:srfi_13_scm",(void*)f_6114},
{"f_6119:srfi_13_scm",(void*)f_6119},
{"f_6126:srfi_13_scm",(void*)f_6126},
{"f_6117:srfi_13_scm",(void*)f_6117},
{"f_6078:srfi_13_scm",(void*)f_6078},
{"f_6092:srfi_13_scm",(void*)f_6092},
{"f_6099:srfi_13_scm",(void*)f_6099},
{"f_6081:srfi_13_scm",(void*)f_6081},
{"f_6059:srfi_13_scm",(void*)f_6059},
{"f_5945:srfi_13_scm",(void*)f_5945},
{"f_5957:srfi_13_scm",(void*)f_5957},
{"f_6039:srfi_13_scm",(void*)f_6039},
{"f_6000:srfi_13_scm",(void*)f_6000},
{"f_6026:srfi_13_scm",(void*)f_6026},
{"f_6033:srfi_13_scm",(void*)f_6033},
{"f_6003:srfi_13_scm",(void*)f_6003},
{"f_6006:srfi_13_scm",(void*)f_6006},
{"f_6011:srfi_13_scm",(void*)f_6011},
{"f_6018:srfi_13_scm",(void*)f_6018},
{"f_6009:srfi_13_scm",(void*)f_6009},
{"f_5970:srfi_13_scm",(void*)f_5970},
{"f_5984:srfi_13_scm",(void*)f_5984},
{"f_5991:srfi_13_scm",(void*)f_5991},
{"f_5973:srfi_13_scm",(void*)f_5973},
{"f_5951:srfi_13_scm",(void*)f_5951},
{"f_5883:srfi_13_scm",(void*)f_5883},
{"f_5904:srfi_13_scm",(void*)f_5904},
{"f_5924:srfi_13_scm",(void*)f_5924},
{"f_5898:srfi_13_scm",(void*)f_5898},
{"f_5825:srfi_13_scm",(void*)f_5825},
{"f_5846:srfi_13_scm",(void*)f_5846},
{"f_5866:srfi_13_scm",(void*)f_5866},
{"f_5840:srfi_13_scm",(void*)f_5840},
{"f_5770:srfi_13_scm",(void*)f_5770},
{"f_5788:srfi_13_scm",(void*)f_5788},
{"f_5792:srfi_13_scm",(void*)f_5792},
{"f_5796:srfi_13_scm",(void*)f_5796},
{"f_5808:srfi_13_scm",(void*)f_5808},
{"f_5782:srfi_13_scm",(void*)f_5782},
{"f_5719:srfi_13_scm",(void*)f_5719},
{"f_5737:srfi_13_scm",(void*)f_5737},
{"f_5741:srfi_13_scm",(void*)f_5741},
{"f_5745:srfi_13_scm",(void*)f_5745},
{"f_5731:srfi_13_scm",(void*)f_5731},
{"f_5672:srfi_13_scm",(void*)f_5672},
{"f_5690:srfi_13_scm",(void*)f_5690},
{"f_5694:srfi_13_scm",(void*)f_5694},
{"f_5698:srfi_13_scm",(void*)f_5698},
{"f_5684:srfi_13_scm",(void*)f_5684},
{"f_5645:srfi_13_scm",(void*)f_5645},
{"f_5652:srfi_13_scm",(void*)f_5652},
{"f_5622:srfi_13_scm",(void*)f_5622},
{"f_5629:srfi_13_scm",(void*)f_5629},
{"f_5595:srfi_13_scm",(void*)f_5595},
{"f_5602:srfi_13_scm",(void*)f_5602},
{"f_5575:srfi_13_scm",(void*)f_5575},
{"f_5582:srfi_13_scm",(void*)f_5582},
{"f_5550:srfi_13_scm",(void*)f_5550},
{"f_5562:srfi_13_scm",(void*)f_5562},
{"f_5566:srfi_13_scm",(void*)f_5566},
{"f_5569:srfi_13_scm",(void*)f_5569},
{"f_5556:srfi_13_scm",(void*)f_5556},
{"f_5532:srfi_13_scm",(void*)f_5532},
{"f_5544:srfi_13_scm",(void*)f_5544},
{"f_5538:srfi_13_scm",(void*)f_5538},
{"f_5457:srfi_13_scm",(void*)f_5457},
{"f_5463:srfi_13_scm",(void*)f_5463},
{"f_5526:srfi_13_scm",(void*)f_5526},
{"f_5467:srfi_13_scm",(void*)f_5467},
{"f_5471:srfi_13_scm",(void*)f_5471},
{"f_5504:srfi_13_scm",(void*)f_5504},
{"f_5481:srfi_13_scm",(void*)f_5481},
{"f_5485:srfi_13_scm",(void*)f_5485},
{"f_5489:srfi_13_scm",(void*)f_5489},
{"f_5439:srfi_13_scm",(void*)f_5439},
{"f_5451:srfi_13_scm",(void*)f_5451},
{"f_5445:srfi_13_scm",(void*)f_5445},
{"f_5421:srfi_13_scm",(void*)f_5421},
{"f_5433:srfi_13_scm",(void*)f_5433},
{"f_5427:srfi_13_scm",(void*)f_5427},
{"f_5403:srfi_13_scm",(void*)f_5403},
{"f_5415:srfi_13_scm",(void*)f_5415},
{"f_5409:srfi_13_scm",(void*)f_5409},
{"f_5385:srfi_13_scm",(void*)f_5385},
{"f_5397:srfi_13_scm",(void*)f_5397},
{"f_5391:srfi_13_scm",(void*)f_5391},
{"f_5329:srfi_13_scm",(void*)f_5329},
{"f_5339:srfi_13_scm",(void*)f_5339},
{"f_5353:srfi_13_scm",(void*)f_5353},
{"f_5359:srfi_13_scm",(void*)f_5359},
{"f_5347:srfi_13_scm",(void*)f_5347},
{"f_5283:srfi_13_scm",(void*)f_5283},
{"f_5293:srfi_13_scm",(void*)f_5293},
{"f_5307:srfi_13_scm",(void*)f_5307},
{"f_5301:srfi_13_scm",(void*)f_5301},
{"f_5211:srfi_13_scm",(void*)f_5211},
{"f_5229:srfi_13_scm",(void*)f_5229},
{"f_5262:srfi_13_scm",(void*)f_5262},
{"f_5264:srfi_13_scm",(void*)f_5264},
{"f_5213:srfi_13_scm",(void*)f_5213},
{"f_5163:srfi_13_scm",(void*)f_5163},
{"f_5175:srfi_13_scm",(void*)f_5175},
{"f_5187:srfi_13_scm",(void*)f_5187},
{"f_5194:srfi_13_scm",(void*)f_5194},
{"f_5202:srfi_13_scm",(void*)f_5202},
{"f_5181:srfi_13_scm",(void*)f_5181},
{"f_5169:srfi_13_scm",(void*)f_5169},
{"f_5115:srfi_13_scm",(void*)f_5115},
{"f_5127:srfi_13_scm",(void*)f_5127},
{"f_5139:srfi_13_scm",(void*)f_5139},
{"f_5146:srfi_13_scm",(void*)f_5146},
{"f_5154:srfi_13_scm",(void*)f_5154},
{"f_5133:srfi_13_scm",(void*)f_5133},
{"f_5121:srfi_13_scm",(void*)f_5121},
{"f_5064:srfi_13_scm",(void*)f_5064},
{"f_5076:srfi_13_scm",(void*)f_5076},
{"f_5088:srfi_13_scm",(void*)f_5088},
{"f_5095:srfi_13_scm",(void*)f_5095},
{"f_5106:srfi_13_scm",(void*)f_5106},
{"f_5103:srfi_13_scm",(void*)f_5103},
{"f_5082:srfi_13_scm",(void*)f_5082},
{"f_5070:srfi_13_scm",(void*)f_5070},
{"f_5013:srfi_13_scm",(void*)f_5013},
{"f_5025:srfi_13_scm",(void*)f_5025},
{"f_5037:srfi_13_scm",(void*)f_5037},
{"f_5044:srfi_13_scm",(void*)f_5044},
{"f_5055:srfi_13_scm",(void*)f_5055},
{"f_5052:srfi_13_scm",(void*)f_5052},
{"f_5031:srfi_13_scm",(void*)f_5031},
{"f_5019:srfi_13_scm",(void*)f_5019},
{"f_4946:srfi_13_scm",(void*)f_4946},
{"f_4958:srfi_13_scm",(void*)f_4958},
{"f_4970:srfi_13_scm",(void*)f_4970},
{"f_4993:srfi_13_scm",(void*)f_4993},
{"f_4988:srfi_13_scm",(void*)f_4988},
{"f_4964:srfi_13_scm",(void*)f_4964},
{"f_4952:srfi_13_scm",(void*)f_4952},
{"f_4884:srfi_13_scm",(void*)f_4884},
{"f_4896:srfi_13_scm",(void*)f_4896},
{"f_4908:srfi_13_scm",(void*)f_4908},
{"f_4918:srfi_13_scm",(void*)f_4918},
{"f_4929:srfi_13_scm",(void*)f_4929},
{"f_4926:srfi_13_scm",(void*)f_4926},
{"f_4902:srfi_13_scm",(void*)f_4902},
{"f_4890:srfi_13_scm",(void*)f_4890},
{"f_4836:srfi_13_scm",(void*)f_4836},
{"f_4848:srfi_13_scm",(void*)f_4848},
{"f_4860:srfi_13_scm",(void*)f_4860},
{"f_4867:srfi_13_scm",(void*)f_4867},
{"f_4875:srfi_13_scm",(void*)f_4875},
{"f_4854:srfi_13_scm",(void*)f_4854},
{"f_4842:srfi_13_scm",(void*)f_4842},
{"f_4788:srfi_13_scm",(void*)f_4788},
{"f_4800:srfi_13_scm",(void*)f_4800},
{"f_4812:srfi_13_scm",(void*)f_4812},
{"f_4819:srfi_13_scm",(void*)f_4819},
{"f_4827:srfi_13_scm",(void*)f_4827},
{"f_4806:srfi_13_scm",(void*)f_4806},
{"f_4794:srfi_13_scm",(void*)f_4794},
{"f_4737:srfi_13_scm",(void*)f_4737},
{"f_4749:srfi_13_scm",(void*)f_4749},
{"f_4761:srfi_13_scm",(void*)f_4761},
{"f_4768:srfi_13_scm",(void*)f_4768},
{"f_4779:srfi_13_scm",(void*)f_4779},
{"f_4776:srfi_13_scm",(void*)f_4776},
{"f_4755:srfi_13_scm",(void*)f_4755},
{"f_4743:srfi_13_scm",(void*)f_4743},
{"f_4686:srfi_13_scm",(void*)f_4686},
{"f_4698:srfi_13_scm",(void*)f_4698},
{"f_4710:srfi_13_scm",(void*)f_4710},
{"f_4717:srfi_13_scm",(void*)f_4717},
{"f_4728:srfi_13_scm",(void*)f_4728},
{"f_4725:srfi_13_scm",(void*)f_4725},
{"f_4704:srfi_13_scm",(void*)f_4704},
{"f_4692:srfi_13_scm",(void*)f_4692},
{"f_4619:srfi_13_scm",(void*)f_4619},
{"f_4631:srfi_13_scm",(void*)f_4631},
{"f_4643:srfi_13_scm",(void*)f_4643},
{"f_4666:srfi_13_scm",(void*)f_4666},
{"f_4661:srfi_13_scm",(void*)f_4661},
{"f_4637:srfi_13_scm",(void*)f_4637},
{"f_4625:srfi_13_scm",(void*)f_4625},
{"f_4557:srfi_13_scm",(void*)f_4557},
{"f_4569:srfi_13_scm",(void*)f_4569},
{"f_4581:srfi_13_scm",(void*)f_4581},
{"f_4591:srfi_13_scm",(void*)f_4591},
{"f_4602:srfi_13_scm",(void*)f_4602},
{"f_4599:srfi_13_scm",(void*)f_4599},
{"f_4575:srfi_13_scm",(void*)f_4575},
{"f_4563:srfi_13_scm",(void*)f_4563},
{"f_4527:srfi_13_scm",(void*)f_4527},
{"f_4539:srfi_13_scm",(void*)f_4539},
{"f_4551:srfi_13_scm",(void*)f_4551},
{"f_4545:srfi_13_scm",(void*)f_4545},
{"f_4533:srfi_13_scm",(void*)f_4533},
{"f_4497:srfi_13_scm",(void*)f_4497},
{"f_4509:srfi_13_scm",(void*)f_4509},
{"f_4521:srfi_13_scm",(void*)f_4521},
{"f_4515:srfi_13_scm",(void*)f_4515},
{"f_4503:srfi_13_scm",(void*)f_4503},
{"f_4435:srfi_13_scm",(void*)f_4435},
{"f_4445:srfi_13_scm",(void*)f_4445},
{"f_4479:srfi_13_scm",(void*)f_4479},
{"f_4373:srfi_13_scm",(void*)f_4373},
{"f_4383:srfi_13_scm",(void*)f_4383},
{"f_4251:srfi_13_scm",(void*)f_4251},
{"f_4263:srfi_13_scm",(void*)f_4263},
{"f_4275:srfi_13_scm",(void*)f_4275},
{"f_4367:srfi_13_scm",(void*)f_4367},
{"f_4269:srfi_13_scm",(void*)f_4269},
{"f_4257:srfi_13_scm",(void*)f_4257},
{"f_4221:srfi_13_scm",(void*)f_4221},
{"f_4233:srfi_13_scm",(void*)f_4233},
{"f_4245:srfi_13_scm",(void*)f_4245},
{"f_4344:srfi_13_scm",(void*)f_4344},
{"f_4239:srfi_13_scm",(void*)f_4239},
{"f_4227:srfi_13_scm",(void*)f_4227},
{"f_4191:srfi_13_scm",(void*)f_4191},
{"f_4203:srfi_13_scm",(void*)f_4203},
{"f_4215:srfi_13_scm",(void*)f_4215},
{"f_4321:srfi_13_scm",(void*)f_4321},
{"f_4209:srfi_13_scm",(void*)f_4209},
{"f_4197:srfi_13_scm",(void*)f_4197},
{"f_4161:srfi_13_scm",(void*)f_4161},
{"f_4173:srfi_13_scm",(void*)f_4173},
{"f_4185:srfi_13_scm",(void*)f_4185},
{"f_4298:srfi_13_scm",(void*)f_4298},
{"f_4179:srfi_13_scm",(void*)f_4179},
{"f_4167:srfi_13_scm",(void*)f_4167},
{"f_4131:srfi_13_scm",(void*)f_4131},
{"f_4143:srfi_13_scm",(void*)f_4143},
{"f_4155:srfi_13_scm",(void*)f_4155},
{"f_4149:srfi_13_scm",(void*)f_4149},
{"f_4137:srfi_13_scm",(void*)f_4137},
{"f_4101:srfi_13_scm",(void*)f_4101},
{"f_4113:srfi_13_scm",(void*)f_4113},
{"f_4125:srfi_13_scm",(void*)f_4125},
{"f_4119:srfi_13_scm",(void*)f_4119},
{"f_4107:srfi_13_scm",(void*)f_4107},
{"f_4071:srfi_13_scm",(void*)f_4071},
{"f_4083:srfi_13_scm",(void*)f_4083},
{"f_4095:srfi_13_scm",(void*)f_4095},
{"f_4089:srfi_13_scm",(void*)f_4089},
{"f_4077:srfi_13_scm",(void*)f_4077},
{"f_4041:srfi_13_scm",(void*)f_4041},
{"f_4053:srfi_13_scm",(void*)f_4053},
{"f_4065:srfi_13_scm",(void*)f_4065},
{"f_4059:srfi_13_scm",(void*)f_4059},
{"f_4047:srfi_13_scm",(void*)f_4047},
{"f_3956:srfi_13_scm",(void*)f_3956},
{"f_3960:srfi_13_scm",(void*)f_3960},
{"f_3969:srfi_13_scm",(void*)f_3969},
{"f_3982:srfi_13_scm",(void*)f_3982},
{"f_4017:srfi_13_scm",(void*)f_4017},
{"f_3992:srfi_13_scm",(void*)f_3992},
{"f_3883:srfi_13_scm",(void*)f_3883},
{"f_3887:srfi_13_scm",(void*)f_3887},
{"f_3896:srfi_13_scm",(void*)f_3896},
{"f_3901:srfi_13_scm",(void*)f_3901},
{"f_3932:srfi_13_scm",(void*)f_3932},
{"f_3911:srfi_13_scm",(void*)f_3911},
{"f_3798:srfi_13_scm",(void*)f_3798},
{"f_3802:srfi_13_scm",(void*)f_3802},
{"f_3811:srfi_13_scm",(void*)f_3811},
{"f_3824:srfi_13_scm",(void*)f_3824},
{"f_3834:srfi_13_scm",(void*)f_3834},
{"f_3725:srfi_13_scm",(void*)f_3725},
{"f_3729:srfi_13_scm",(void*)f_3729},
{"f_3738:srfi_13_scm",(void*)f_3738},
{"f_3743:srfi_13_scm",(void*)f_3743},
{"f_3753:srfi_13_scm",(void*)f_3753},
{"f_3686:srfi_13_scm",(void*)f_3686},
{"f_3693:srfi_13_scm",(void*)f_3693},
{"f_3702:srfi_13_scm",(void*)f_3702},
{"f_3723:srfi_13_scm",(void*)f_3723},
{"f_3696:srfi_13_scm",(void*)f_3696},
{"f_3556:srfi_13_scm",(void*)f_3556},
{"f_3568:srfi_13_scm",(void*)f_3568},
{"f_3610:srfi_13_scm",(void*)f_3610},
{"f_3656:srfi_13_scm",(void*)f_3656},
{"f_3675:srfi_13_scm",(void*)f_3675},
{"f_3615:srfi_13_scm",(void*)f_3615},
{"f_3625:srfi_13_scm",(void*)f_3625},
{"f_3580:srfi_13_scm",(void*)f_3580},
{"f_3562:srfi_13_scm",(void*)f_3562},
{"f_3426:srfi_13_scm",(void*)f_3426},
{"f_3438:srfi_13_scm",(void*)f_3438},
{"f_3480:srfi_13_scm",(void*)f_3480},
{"f_3526:srfi_13_scm",(void*)f_3526},
{"f_3548:srfi_13_scm",(void*)f_3548},
{"f_3485:srfi_13_scm",(void*)f_3485},
{"f_3498:srfi_13_scm",(void*)f_3498},
{"f_3450:srfi_13_scm",(void*)f_3450},
{"f_3432:srfi_13_scm",(void*)f_3432},
{"f_3389:srfi_13_scm",(void*)f_3389},
{"f_3401:srfi_13_scm",(void*)f_3401},
{"f_3407:srfi_13_scm",(void*)f_3407},
{"f_3417:srfi_13_scm",(void*)f_3417},
{"f_3395:srfi_13_scm",(void*)f_3395},
{"f_3348:srfi_13_scm",(void*)f_3348},
{"f_3360:srfi_13_scm",(void*)f_3360},
{"f_3366:srfi_13_scm",(void*)f_3366},
{"f_3376:srfi_13_scm",(void*)f_3376},
{"f_3354:srfi_13_scm",(void*)f_3354},
{"f_3162:srfi_13_scm",(void*)f_3162},
{"f_3185:srfi_13_scm",(void*)f_3185},
{"f_3187:srfi_13_scm",(void*)f_3187},
{"f_3193:srfi_13_scm",(void*)f_3193},
{"f_3317:srfi_13_scm",(void*)f_3317},
{"f_3203:srfi_13_scm",(void*)f_3203},
{"f_3206:srfi_13_scm",(void*)f_3206},
{"f_3227:srfi_13_scm",(void*)f_3227},
{"f_3230:srfi_13_scm",(void*)f_3230},
{"f_3250:srfi_13_scm",(void*)f_3250},
{"f_3265:srfi_13_scm",(void*)f_3265},
{"f_3280:srfi_13_scm",(void*)f_3280},
{"f_3274:srfi_13_scm",(void*)f_3274},
{"f_3330:srfi_13_scm",(void*)f_3330},
{"f_2983:srfi_13_scm",(void*)f_2983},
{"f_3006:srfi_13_scm",(void*)f_3006},
{"f_3008:srfi_13_scm",(void*)f_3008},
{"f_3014:srfi_13_scm",(void*)f_3014},
{"f_3131:srfi_13_scm",(void*)f_3131},
{"f_3024:srfi_13_scm",(void*)f_3024},
{"f_3027:srfi_13_scm",(void*)f_3027},
{"f_3049:srfi_13_scm",(void*)f_3049},
{"f_3052:srfi_13_scm",(void*)f_3052},
{"f_3069:srfi_13_scm",(void*)f_3069},
{"f_3081:srfi_13_scm",(void*)f_3081},
{"f_3098:srfi_13_scm",(void*)f_3098},
{"f_3144:srfi_13_scm",(void*)f_3144},
{"f_2937:srfi_13_scm",(void*)f_2937},
{"f_2949:srfi_13_scm",(void*)f_2949},
{"f_2959:srfi_13_scm",(void*)f_2959},
{"f_2973:srfi_13_scm",(void*)f_2973},
{"f_2943:srfi_13_scm",(void*)f_2943},
{"f_2895:srfi_13_scm",(void*)f_2895},
{"f_2907:srfi_13_scm",(void*)f_2907},
{"f_2913:srfi_13_scm",(void*)f_2913},
{"f_2927:srfi_13_scm",(void*)f_2927},
{"f_2901:srfi_13_scm",(void*)f_2901},
{"f_2862:srfi_13_scm",(void*)f_2862},
{"f_2868:srfi_13_scm",(void*)f_2868},
{"f_2889:srfi_13_scm",(void*)f_2889},
{"f_2844:srfi_13_scm",(void*)f_2844},
{"f_2856:srfi_13_scm",(void*)f_2856},
{"f_2850:srfi_13_scm",(void*)f_2850},
{"f_2801:srfi_13_scm",(void*)f_2801},
{"f_2808:srfi_13_scm",(void*)f_2808},
{"f_2813:srfi_13_scm",(void*)f_2813},
{"f_2838:srfi_13_scm",(void*)f_2838},
{"f_2811:srfi_13_scm",(void*)f_2811},
{"f_2783:srfi_13_scm",(void*)f_2783},
{"f_2795:srfi_13_scm",(void*)f_2795},
{"f_2789:srfi_13_scm",(void*)f_2789},
{"f_2765:srfi_13_scm",(void*)f_2765},
{"f_2777:srfi_13_scm",(void*)f_2777},
{"f_2771:srfi_13_scm",(void*)f_2771},
{"f_2743:srfi_13_scm",(void*)f_2743},
{"f_2750:srfi_13_scm",(void*)f_2750},
{"f_2713:srfi_13_scm",(void*)f_2713},
{"f_2726:srfi_13_scm",(void*)f_2726},
{"f_2697:srfi_13_scm",(void*)f_2697},
{"f_2711:srfi_13_scm",(void*)f_2711},
{"f_2657:srfi_13_scm",(void*)f_2657},
{"f_2630:srfi_13_scm",(void*)f_2630},
{"f_2642:srfi_13_scm",(void*)f_2642},
{"f_2636:srfi_13_scm",(void*)f_2636},
{"f_2537:srfi_13_scm",(void*)f_2537},
{"f_2603:srfi_13_scm",(void*)f_2603},
{"f_2567:srfi_13_scm",(void*)f_2567},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
