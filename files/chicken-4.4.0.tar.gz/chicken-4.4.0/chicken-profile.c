/* Generated from chicken-profile.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: chicken-profile.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -output-file chicken-profile.c
   used units: library eval srfi_1 srfi_13 srfi_69 posix utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[89];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_370)
static void C_ccall f_370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_373)
static void C_ccall f_373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_376)
static void C_ccall f_376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_385)
static void C_ccall f_385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_388)
static void C_ccall f_388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_444)
static void C_fcall f_444(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_646)
static void C_fcall f_646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_640)
static void C_ccall f_640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_836)
static void C_ccall f_836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_fcall f_797(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_807)
static void C_ccall f_807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_599)
static void C_ccall f_599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_582)
static void C_ccall f_582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_575)
static void C_ccall f_575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_566)
static void C_ccall f_566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_559)
static void C_ccall f_559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_541)
static void C_ccall f_541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_518)
static void C_fcall f_518(C_word t0,C_word t1) C_noret;
C_noret_decl(f_538)
static void C_ccall f_538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_522)
static void C_ccall f_522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_499)
static void C_fcall f_499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_461)
static void C_ccall f_461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_479)
static void C_ccall f_479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_487)
static void C_ccall f_487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_491)
static void C_ccall f_491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_464)
static void C_ccall f_464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_454)
static void C_fcall f_454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_fcall f_1497(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_fcall f_1524(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1542)
static void C_fcall f_1542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_fcall f_1549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_ccall f_1113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1116)
static void C_fcall f_1116(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1371)
static void C_ccall f_1371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_fcall f_1373(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1129)
static void C_ccall f_1129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1326)
static void C_fcall f_1326(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_fcall f_1277(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_fcall f_1290(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1215)
static void C_ccall f_1215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_fcall f_1220(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1134)
static void C_fcall f_1134(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1148)
static void C_fcall f_1148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1155)
static void C_fcall f_1155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_fcall f_1161(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_fcall f_1044(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1098)
static void C_ccall f_1098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_996)
static void C_fcall f_996(C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_fcall f_991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_966)
static void C_fcall f_966(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_849)
static void C_ccall f_849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_853)
static void C_ccall f_853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_865)
static void C_fcall f_865(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_900)
static void C_fcall f_900(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_910)
static void C_fcall f_910(C_word t0,C_word t1) C_noret;
C_noret_decl(f_913)
static void C_fcall f_913(C_word t0,C_word t1) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_875)
static void C_ccall f_875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_882)
static void C_ccall f_882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_856)
static void C_ccall f_856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_765)
static void C_ccall f_765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_773)
static void C_ccall f_773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_736)
static void C_ccall f_736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_707)
static void C_ccall f_707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_672)
static void C_ccall f_672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_397)
static void C_fcall f_397(C_word t0) C_noret;
C_noret_decl(f_408)
static void C_ccall f_408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_444)
static void C_fcall trf_444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_444(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_444(t0,t1,t2);}

C_noret_decl(trf_646)
static void C_fcall trf_646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_646(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_646(t0,t1);}

C_noret_decl(trf_797)
static void C_fcall trf_797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_797(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_797(t0,t1,t2);}

C_noret_decl(trf_518)
static void C_fcall trf_518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_518(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_518(t0,t1);}

C_noret_decl(trf_499)
static void C_fcall trf_499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_499(t0,t1);}

C_noret_decl(trf_454)
static void C_fcall trf_454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_454(t0,t1);}

C_noret_decl(trf_1497)
static void C_fcall trf_1497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1497(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1497(t0,t1,t2);}

C_noret_decl(trf_1524)
static void C_fcall trf_1524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1524(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1524(t0,t1,t2);}

C_noret_decl(trf_1542)
static void C_fcall trf_1542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1542(t0,t1);}

C_noret_decl(trf_1549)
static void C_fcall trf_1549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1549(t0,t1);}

C_noret_decl(trf_1116)
static void C_fcall trf_1116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1116(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1116(t0,t1);}

C_noret_decl(trf_1373)
static void C_fcall trf_1373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1373(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1373(t0,t1,t2);}

C_noret_decl(trf_1326)
static void C_fcall trf_1326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1326(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1326(t0,t1,t2);}

C_noret_decl(trf_1277)
static void C_fcall trf_1277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1277(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1277(t0,t1,t2,t3);}

C_noret_decl(trf_1290)
static void C_fcall trf_1290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1290(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1290(t0,t1);}

C_noret_decl(trf_1220)
static void C_fcall trf_1220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1220(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1220(t0,t1,t2);}

C_noret_decl(trf_1134)
static void C_fcall trf_1134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1134(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1134(t0,t1,t2);}

C_noret_decl(trf_1148)
static void C_fcall trf_1148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1148(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1148(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1155)
static void C_fcall trf_1155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1155(t0,t1);}

C_noret_decl(trf_1161)
static void C_fcall trf_1161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1161(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1161(t0,t1);}

C_noret_decl(trf_1044)
static void C_fcall trf_1044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1044(t0,t1,t2);}

C_noret_decl(trf_996)
static void C_fcall trf_996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_996(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_996(t0,t1);}

C_noret_decl(trf_991)
static void C_fcall trf_991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_991(t0,t1,t2);}

C_noret_decl(trf_966)
static void C_fcall trf_966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_966(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_966(t0,t1,t2,t3);}

C_noret_decl(trf_865)
static void C_fcall trf_865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_865(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_865(t0,t1,t2);}

C_noret_decl(trf_900)
static void C_fcall trf_900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_900(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_900(t0,t1,t2,t3);}

C_noret_decl(trf_910)
static void C_fcall trf_910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_910(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_910(t0,t1);}

C_noret_decl(trf_913)
static void C_fcall trf_913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_913(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_913(t0,t1);}

C_noret_decl(trf_397)
static void C_fcall trf_397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_397(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_397(t0);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(366)){
C_save(t1);
C_rereclaim2(366*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,89);
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],7,"display");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\001\242)\012 -no-unused                remove procedures that are never called\012 -top "
"N                    display only the top N entries\012 -help                     s"
"how this text and exit\012 -version                  show version and exit\012 -releas"
"e                  show release number and exit\012\012 FILENAME defaults to the `PROF"
"ILE.<number>\047, selecting the one with\012 the highest modification time, in case mu"
"ltiple profiles exist.\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\001\315Usage: chicken-profile [FILENAME | OPTION] ...\012\012 -sort-by-calls            "
"sort output by call frequency\012 -sort-by-time             sort output by procedur"
"e execution time\012 -sort-by-avg              sort output by average procedure exe"
"cution time\012 -sort-by-name             sort output alphabetically by procedure n"
"ame\012 -decimals DDD             set number of decimals for seconds, average and\012 "
"                          percent columns (three digits, default: ");
lf[14]=C_h_intern(&lf[14],19,"\003sysprint-to-string");
lf[19]=C_h_intern(&lf[19],8,"string<\077");
lf[20]=C_h_intern(&lf[20],14,"symbol->string");
lf[22]=C_h_intern(&lf[22],17,"hash-table->alist");
lf[23]=C_h_intern(&lf[23],4,"read");
lf[24]=C_h_intern(&lf[24],15,"hash-table-set!");
lf[25]=C_h_intern(&lf[25],22,"hash-table-ref/default");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\000\376\377\016");
lf[27]=C_h_intern(&lf[27],15,"make-hash-table");
lf[28]=C_h_intern(&lf[28],3,"eq\077");
lf[30]=C_h_intern(&lf[30],13,"string-append");
lf[31]=C_h_intern(&lf[31],11,"make-string");
lf[32]=C_h_intern(&lf[32],9,"\003syserror");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[37]=C_h_intern(&lf[37],9,"substring");
lf[38]=C_h_intern(&lf[38],8,"truncate");
lf[39]=C_h_intern(&lf[39],4,"expt");
lf[40]=C_h_intern(&lf[40],25,"\003sysimplicit-exit-handler");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\011procedure");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\005calls");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\007seconds");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\007average");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\007percent");
lf[46]=C_h_intern(&lf[46],5,"print");
lf[47]=C_h_intern(&lf[47],11,"string-join");
lf[48]=C_h_intern(&lf[48],6,"reduce");
lf[49]=C_h_intern(&lf[49],1,"+");
lf[50]=C_h_intern(&lf[50],3,"max");
lf[51]=C_h_intern(&lf[51],13,"string-length");
lf[52]=C_h_intern(&lf[52],4,"fold");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\010overflow");
lf[54]=C_h_intern(&lf[54],28,"\003syssymbol->qualified-string");
lf[55]=C_h_intern(&lf[55],6,"remove");
lf[56]=C_h_intern(&lf[56],4,"take");
lf[57]=C_h_intern(&lf[57],4,"sort");
lf[58]=C_h_intern(&lf[58],6,"append");
lf[59]=C_h_intern(&lf[59],20,"with-input-from-file");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\011reading `");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\006\047 ...\012");
lf[62]=C_h_intern(&lf[62],5,"error");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\021no PROFILEs found");
lf[64]=C_h_intern(&lf[64],22,"file-modification-time");
lf[65]=C_h_intern(&lf[65],4,"glob");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\011PROFILE.*");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\032missing argument to option");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid argument to option");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\032chicken-profile - Version ");
lf[75]=C_h_intern(&lf[75],15,"chicken-version");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\012-no-unused");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\004-top");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\016-sort-by-calls");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-time");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\014-sort-by-avg");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-name");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\011-decimals");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[88]=C_h_intern(&lf[88],22,"command-line-arguments");
C_register_lf2(lf,89,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_370,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k368 */
static void C_ccall f_370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k371 in k368 */
static void C_ccall f_373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k374 in k371 in k368 */
static void C_ccall f_376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k377 in k374 in k371 in k368 */
static void C_ccall f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_388,2,t0,t1);}
t2=lf[0] /* sort-by */ =C_SCHEME_FALSE;;
t3=lf[1] /* file */ =C_SCHEME_FALSE;;
t4=lf[2] /* no-unused */ =C_SCHEME_FALSE;;
t5=lf[3] /* seconds-digits */ =C_fix(3);;
t6=lf[4] /* average-digits */ =C_fix(3);;
t7=lf[5] /* percent-digits */ =C_fix(3);;
t8=lf[6] /* top */ =C_fix(0);;
t9=C_mutate(&lf[7] /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_397,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[15] /* (set! sort-by-calls ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_672,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[16] /* (set! sort-by-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_707,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[17] /* (set! sort-by-avg ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_736,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[18] /* (set! sort-by-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_765,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[0] /* (set! sort-by ...) */,lf[16]);
t15=C_mutate(&lf[21] /* (set! read-profile ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_849,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[29] /* (set! format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_964,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[34] /* (set! format-real ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1044,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1601,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 234  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[88]))(2,*((C_word*)lf[88]+1),t19);}

/* k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_444,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_444(t5,((C_word*)t0)[2],t1);}

/* loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_444(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word *a;
loop:
a=C_alloc(24);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_444,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_454,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(lf[1])){
t4=t3;
f_454(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_461,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 73   glob */
((C_proc3)C_retrieve_symbol_proc(lf[65]))(3,*((C_word*)lf[65]+1),t4,lf[66]);}}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_499,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t11=t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_518,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_541,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[70]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[71]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-profile.scm: 93   print-usage */
f_397(t12);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[72]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[73]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_559,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_566,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 95   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[75]))(2,*((C_word*)lf[75]+1),t14);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[76]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_575,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_582,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 98   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[75]))(2,*((C_word*)lf[75]+1),t14);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[77]))){
t13=lf[2] /* no-unused */ =C_SCHEME_TRUE;;
/* chicken-profile.scm: 111  loop */
t30=t1;
t31=((C_word*)t6)[1];
t1=t30;
t2=t31;
goto loop;}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[78]))){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_599,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 101  next-number */
t14=t9;
f_518(t14,t13);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[79]))){
t13=C_mutate(&lf[0] /* (set! sort-by ...) */,lf[15]);
/* chicken-profile.scm: 111  loop */
t30=t1;
t31=((C_word*)t6)[1];
t1=t30;
t2=t31;
goto loop;}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[80]))){
t13=C_mutate(&lf[0] /* (set! sort-by ...) */,lf[16]);
/* chicken-profile.scm: 111  loop */
t30=t1;
t31=((C_word*)t6)[1];
t1=t30;
t2=t31;
goto loop;}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[81]))){
t13=C_mutate(&lf[0] /* (set! sort-by ...) */,lf[17]);
/* chicken-profile.scm: 111  loop */
t30=t1;
t31=((C_word*)t6)[1];
t1=t30;
t2=t31;
goto loop;}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[82]))){
t13=C_mutate(&lf[0] /* (set! sort-by ...) */,lf[18]);
/* chicken-profile.scm: 111  loop */
t30=t1;
t31=((C_word*)t6)[1];
t1=t30;
t2=t31;
goto loop;}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[83]))){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_640,a[2]=t12,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 106  next-arg */
t14=((C_word*)t8)[1];
f_499(t14,t13);}
else{
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_646,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
t14=(C_word)C_i_string_length(t3);
if(C_truep((C_word)C_i_greaterp(t14,C_fix(1)))){
t15=(C_word)C_i_string_ref(t3,C_fix(0));
t16=t13;
f_646(t16,(C_word)C_eqp(C_make_character(45),t15));}
else{
t15=t13;
f_646(t15,C_SCHEME_FALSE);}}}}}}}}}}}}}

/* k644 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_646(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* chicken-profile.scm: 108  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),((C_word*)t0)[6],lf[87],((C_word*)t0)[5]);}
else{
if(C_truep(lf[1])){
/* chicken-profile.scm: 109  print-usage */
f_397(((C_word*)t0)[6]);}
else{
t2=C_mutate(&lf[1] /* (set! file ...) */,((C_word*)t0)[5]);
/* chicken-profile.scm: 111  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_444(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}}

/* k638 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_640,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_nequalp(t2,C_fix(3)))){
t3=C_mutate(&lf[84] /* (set! arg-digit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_797,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 148  arg-digit */
t5=C_retrieve2(lf[84],"arg-digit");
f_797(t5,t4,C_fix(0));}
else{
/* chicken-profile.scm: 151  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),((C_word*)t0)[2],lf[86],t1);}}

/* k830 in k638 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_832,2,t0,t1);}
t2=C_mutate(&lf[3] /* (set! seconds-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 149  arg-digit */
t4=C_retrieve2(lf[84],"arg-digit");
f_797(t4,t3,C_fix(1));}

/* k834 in k830 in k638 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_836,2,t0,t1);}
t2=C_mutate(&lf[4] /* (set! average-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 150  arg-digit */
t4=C_retrieve2(lf[84],"arg-digit");
f_797(t4,t3,C_fix(2));}

/* k838 in k834 in k830 in k638 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[5] /* (set! percent-digits ...) */,t1);
/* chicken-profile.scm: 111  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_444(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* arg-digit in k638 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_797(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_797,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(48));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_807,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 145  <= */
C_less_or_equal_p(5,0,t6,C_fix(0),t5,C_fix(9));}

/* k805 in arg-digit in k638 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_nequalp(((C_word*)t0)[4],C_fix(9));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_fix(8):((C_word*)t0)[4]));}
else{
/* chicken-profile.scm: 147  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),((C_word*)t0)[3],lf[85],((C_word*)t0)[2]);}}

/* k597 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[6] /* (set! top ...) */,t1);
/* chicken-profile.scm: 111  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_444(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k580 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 98   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* k573 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 99   exit */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* k564 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 95   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[46]+1)))(4,*((C_word*)lf[46]+1),((C_word*)t0)[2],lf[74],t1);}

/* k557 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 96   exit */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* k539 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 111  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_444(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* next-number in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_518(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_518,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_522,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_538,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 90   next-arg */
t4=((C_word*)((C_word*)t0)[2])[1];
f_499(t4,t3);}

/* k536 in next-number in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 90   string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k520 in next-number in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
if(C_truep((C_word)C_i_greaterp(t1,C_fix(0)))){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* chicken-profile.scm: 91   error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),((C_word*)t0)[3],lf[68],((C_word*)t0)[2]);}}
else{
/* chicken-profile.scm: 91   error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),((C_word*)t0)[3],lf[68],((C_word*)t0)[2]);}}

/* next-arg in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_499,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* chicken-profile.scm: 85   error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),t1,lf[67],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k459 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_464,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-profile.scm: 75   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[62]+1)))(3,*((C_word*)lf[62]+1),t2,lf[63]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_477,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_479,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 76   sort */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t3,t1,t4);}}

/* a478 in k459 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_479,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_487,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 78   file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t4,t2);}

/* k485 in a478 in k459 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_491,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 79   file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t2,((C_word*)t0)[2]);}

/* k489 in k485 in a478 in k459 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_greaterp(((C_word*)t0)[2],t1));}

/* k475 in k459 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=C_mutate(&lf[1] /* (set! file ...) */,t2);
t4=((C_word*)t0)[2];
f_454(t4,t3);}

/* k462 in k459 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[1] /* (set! file ...) */,t1);
t3=((C_word*)t0)[2];
f_454(t3,t2);}

/* k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_454,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1104,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 184  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[46]+1)))(5,*((C_word*)lf[46]+1),t3,lf[60],lf[1],lf[61]);}

/* k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1107,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 185  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),t2,lf[1],lf[21]);}

/* k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1110,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1580,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 186  fold */
((C_proc5)C_retrieve_symbol_proc(lf[52]))(5,*((C_word*)lf[52]+1),t2,t3,C_fix(0),t1);}

/* a1579 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1580,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
/* chicken-profile.scm: 187  max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t1,t4,t3);}

/* k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1113,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1495,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1497,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_1497(t11,t7,((C_word*)t0)[2]);}

/* loop154 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1497(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1497,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g170171 */
t6=t3;
f_1524(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1572 in loop154 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop154167 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1497(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop154167 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1497(t6,((C_word*)t0)[3],t5);}}

/* g170 in loop154 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1524(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1524,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_caddr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1542,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_greaterp(t3,C_fix(0));
t7=t5;
f_1542(t7,(C_truep(t6)?(C_word)C_a_i_divide(&a,2,t4,t3):C_SCHEME_FALSE));}
else{
t6=t5;
f_1542(t6,C_SCHEME_FALSE);}}

/* k1540 in g170 in loop154 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1542,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t4=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t5=t3;
f_1549(t5,(C_word)C_a_i_times(&a,2,t4,C_fix(100)));}
else{
t4=t3;
f_1549(t4,C_SCHEME_FALSE);}}

/* k1547 in k1540 in g170 in loop154 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1549,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2);
/* chicken-profile.scm: 191  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[58]+1)))(4,*((C_word*)lf[58]+1),((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],C_fix(0));
/* chicken-profile.scm: 191  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[58]+1)))(4,*((C_word*)lf[58]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k1493 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 190  sort */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),((C_word*)t0)[2],t1,lf[0]);}

/* k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1113,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1116,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1483,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_length(((C_word*)t3)[1]);
/* chicken-profile.scm: 200  < */
C_lessp(5,0,t5,C_fix(0),lf[6],t6);}

/* k1481 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1483,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 201  take */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t2,((C_word*)((C_word*)t0)[3])[1],lf[6]);}
else{
t2=((C_word*)t0)[2];
f_1116(t2,C_SCHEME_UNDEFINED);}}

/* k1485 in k1481 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1116(t3,t2);}

/* k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1116,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1371,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1463,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 212  remove */
((C_proc4)C_retrieve_symbol_proc(lf[55]))(4,*((C_word*)lf[55]+1),t7,t8,((C_word*)((C_word*)t0)[3])[1]);}

/* a1462 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1463,3,t0,t1,t2);}
if(C_truep((C_word)C_i_cadr(t2))){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_zerop(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[2]:C_SCHEME_FALSE));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1369 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1371,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1373(t5,((C_word*)t0)[2],t1);}

/* loop196 in k1369 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1373(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1373,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_i_caddr(t3);
t6=(C_word)C_i_cadddr(t3);
t7=(C_word)C_i_list_ref(t3,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1420,a[2]=t4,a[3]=t5,a[4]=t6,a[5]=t7,a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[3],a[9]=t2,a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
t9=(C_word)C_i_car(t3);
/* chicken-profile.scm: 207  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t8,t9);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1418 in loop196 in k1369 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken-profile.scm: 208  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1424(2,t3,lf[53]);}}

/* k1422 in k1418 in loop196 in k1369 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 209  format-real */
f_1044(t2,t3,lf[3]);}

/* k1426 in k1422 in k1418 in loop196 in k1369 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 210  format-real */
f_1044(t2,t3,lf[4]);}

/* k1430 in k1426 in k1422 in k1418 in loop196 in k1369 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* chicken-profile.scm: 211  format-real */
f_1044(t2,((C_word*)t0)[2],lf[5]);}

/* k1434 in k1430 in k1426 in k1422 in k1418 in loop196 in k1369 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1436,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t4=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop196209 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_1373(t7,((C_word*)t0)[3],t6);}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop196209 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_1373(t7,((C_word*)t0)[3],t6);}}

/* k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1120,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_a_i_list(&a,5,lf[41],lf[42],lf[43],lf[44],lf[45]);
t4=(C_word)C_a_i_list(&a,5,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1129,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 220  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),t5,C_fix(2),C_make_character(32));}

/* k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1267,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_a_i_list(&a,5,C_fix(0),C_fix(0),C_fix(0),C_fix(0),C_fix(0));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
/* chicken-profile.scm: 221  fold */
((C_proc5)C_retrieve_symbol_proc(lf[52]))(5,*((C_word*)lf[52]+1),t2,t3,t4,t5);}

/* a1266 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1267,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1275,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1326,a[2]=t9,a[3]=t14,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t16=((C_word*)t14)[1];
f_1326(t16,t12,t2);}

/* loop262 in a1266 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1326(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1326,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[51]+1);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_string_length(t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop262275 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop262275 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1273 in a1266 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1275,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1277(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop235 in k1273 in a1266 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1277(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1277,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[50]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1310,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* g255256 */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k1308 in loop235 in k1273 in a1266 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1310,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_1290(t4,(C_word)C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_1290(t5,t4);}}

/* k1288 in k1308 in loop235 in k1273 in a1266 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1290(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* loop235249 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1277(t5,((C_word*)t0)[2],t3,t4);}

/* k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1134,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1212,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm: 228  print-row */
t4=t2;
f_1134(t4,t3,((C_word*)t0)[2]);}

/* k1210 in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1215,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1245,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1253,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 229  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[48]))(5,*((C_word*)lf[48]+1),t4,*((C_word*)lf[49]+1),C_fix(0),((C_word*)t0)[2]);}

/* k1251 in k1210 in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1253,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t4=(C_word)C_a_i_times(&a,2,C_fix(2),t3);
t5=(C_word)C_a_i_plus(&a,2,t1,t4);
/* chicken-profile.scm: 229  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),((C_word*)t0)[2],t5,C_make_character(45));}

/* k1243 in k1210 in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 229  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* k1213 in k1210 in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1215,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1220(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* loop318 in k1213 in k1210 in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1220(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1220,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1230,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* g325326 */
t5=((C_word*)t0)[2];
f_1134(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1228 in loop318 in k1213 in k1210 in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1220(t3,((C_word*)t0)[2],t2);}

/* print-row in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1134(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1134,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1142,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1148,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_1148(t12,t8,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop287 in print-row in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1148,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1155,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_pairp(t3);
t7=t5;
f_1155(t7,(C_truep(t6)?(C_word)C_i_pairp(t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_1155(t6,C_SCHEME_FALSE);}}

/* k1153 in loop287 in print-row in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1155,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=lf[29];
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
/* g311312 */
t7=lf[29];
f_964(5,t7,t3,t4,t5,t6);}
else{
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1183 in k1153 in loop287 in print-row in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1185,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t4=t3;
f_1161(t4,(C_word)C_i_setslot(((C_word*)((C_word*)t0)[8])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_1161(t5,t4);}}

/* k1159 in k1183 in k1153 in loop287 in print-row in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1161(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* loop287302 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1148(t6,((C_word*)t0)[2],t3,t4,t5);}

/* k1144 in print-row in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 227  string-join */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1140 in print-row in k1130 in k1127 in k1118 in k1114 in k1111 in k1108 in k1105 in k1102 in k452 in loop in k1599 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 227  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* k1589 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1597,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[40]))(2,*((C_word*)lf[40]+1),t3);}

/* k1595 in k1589 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1592 in k1589 in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_1044(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1044,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1098,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 172  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t4,t2);}

/* k1096 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1098,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1055,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 174  number->string */
C_number_to_string(3,0,t3,t2);}

/* k1053 in k1096 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(0));
t3=(C_truep(t2)?lf[35]:lf[36]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1063,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1067,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1079,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1087,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 180  - */
C_minus(5,0,t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(-1));}

/* k1085 in k1053 in k1096 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1091,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 180  expt */
((C_proc4)C_retrieve_proc(*((C_word*)lf[39]+1)))(4,*((C_word*)lf[39]+1),t2,C_fix(10),((C_word*)t0)[2]);}

/* k1089 in k1085 in k1053 in k1096 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1091,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],t1);
/* chicken-profile.scm: 179  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2);}

/* k1077 in k1053 in k1096 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
/* chicken-profile.scm: 177  number->string */
C_number_to_string(3,0,((C_word*)t0)[2],t2);}

/* k1065 in k1053 in k1096 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1067,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* chicken-profile.scm: 176  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),((C_word*)t0)[2],t1,C_fix(1),t2);}

/* k1061 in k1053 in k1096 in format-real in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 173  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[30]+1)))(5,*((C_word*)lf[30]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* format-string in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_964r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_964r(t0,t1,t2,t3,t4);}}

static void C_ccall f_964r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_966,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_991,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_996,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-right121135 */
t8=t7;
f_996(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-padc122133 */
t10=t6;
f_991(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body119127 */
t12=t5;
f_966(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[33],t11);}}}}

/* def-right121 in format-string in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_996(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_996,NULL,2,t0,t1);}
/* def-padc122133 */
t2=((C_word*)t0)[2];
f_991(t2,t1,C_SCHEME_FALSE);}

/* def-padc122 in format-string in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_991(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_991,NULL,3,t0,t1,t2);}
/* body119127 */
t3=((C_word*)t0)[2];
f_966(t3,t1,t2,C_make_character(32));}

/* body119 in format-string in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_966(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_966,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_973,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[2],t4);
t7=(C_word)C_i_fixnum_max(C_fix(0),t6);
/* chicken-profile.scm: 166  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),t5,t7,t3);}

/* k971 in body119 in format-string in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-profile.scm: 168  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-profile.scm: 169  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

/* read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_853,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 154  make-hash-table */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t2,*((C_word*)lf[28]+1));}

/* k851 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_856,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_863,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 155  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t3);}

/* k861 in k851 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_863,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_865,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_865(t5,((C_word*)t0)[2],t1);}

/* doloop63 in k861 in k851 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_865(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_865,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_875,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_890,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_894,a[2]=t9,a[3]=t6,a[4]=t8,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_car(t2);
/* chicken-profile.scm: 160  hash-table-ref/default */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t10,((C_word*)t0)[2],t11,lf[26]);}}

/* k892 in doloop63 in k861 in k851 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_894,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_900,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_900(t6,((C_word*)t0)[2],t1,t2);}

/* loop70 in k892 in doloop63 in k861 in k851 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_900(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_900,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_910,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t7)){
if(C_truep(t8)){
t9=(C_word)C_a_i_plus(&a,2,t7,t8);
t10=t6;
f_910(t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}
else{
t9=t6;
f_910(t9,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST));}}
else{
t9=t6;
f_910(t9,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST));}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k908 in loop70 in k892 in doloop63 in k861 in k851 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_910(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_910,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t3=t2;
f_913(t3,(C_word)C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t1));}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t4=t2;
f_913(t4,t3);}}

/* k911 in k908 in loop70 in k892 in doloop63 in k861 in k851 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* loop7084 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_900(t5,((C_word*)t0)[2],t3,t4);}

/* k888 in doloop63 in k861 in k851 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 157  hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k873 in doloop63 in k861 in k851 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 155  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t2);}

/* k880 in k873 in doloop63 in k861 in k851 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_865(t2,((C_word*)t0)[2],t1);}

/* k854 in k851 in read-profile in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 162  hash-table->alist */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* sort-by-name in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_765,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_773,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-profile.scm: 135  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t4,t5);}

/* k771 in sort-by-name in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_777,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-profile.scm: 135  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,t3);}

/* k775 in k771 in sort-by-name in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 135  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[19]+1)))(4,*((C_word*)lf[19]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sort-by-avg in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_736,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadddr(t2);
t5=(C_word)C_i_cadddr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-time in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_707,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
t5=(C_word)C_i_caddr(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_i_cadr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-calls in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_672,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_cadr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t4)?(C_truep(t5)?(C_word)C_i_greaterp(t4,t5):C_SCHEME_TRUE):C_SCHEME_TRUE));}}

/* print-usage in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_fcall f_397(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_397,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_408,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[10],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[5],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[11],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[4],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[12],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[3],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[13],t9);
/* chicken-profile.scm: 45   ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,t10);}

/* k406 in print-usage in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 45   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),((C_word*)t0)[2],t1);}

/* k399 in print-usage in k386 in k383 in k380 in k377 in k374 in k371 in k368 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 65   exit */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[116] = {
{"toplevel:chicken_profile_scm",(void*)C_toplevel},
{"f_370:chicken_profile_scm",(void*)f_370},
{"f_373:chicken_profile_scm",(void*)f_373},
{"f_376:chicken_profile_scm",(void*)f_376},
{"f_379:chicken_profile_scm",(void*)f_379},
{"f_382:chicken_profile_scm",(void*)f_382},
{"f_385:chicken_profile_scm",(void*)f_385},
{"f_388:chicken_profile_scm",(void*)f_388},
{"f_1601:chicken_profile_scm",(void*)f_1601},
{"f_444:chicken_profile_scm",(void*)f_444},
{"f_646:chicken_profile_scm",(void*)f_646},
{"f_640:chicken_profile_scm",(void*)f_640},
{"f_832:chicken_profile_scm",(void*)f_832},
{"f_836:chicken_profile_scm",(void*)f_836},
{"f_840:chicken_profile_scm",(void*)f_840},
{"f_797:chicken_profile_scm",(void*)f_797},
{"f_807:chicken_profile_scm",(void*)f_807},
{"f_599:chicken_profile_scm",(void*)f_599},
{"f_582:chicken_profile_scm",(void*)f_582},
{"f_575:chicken_profile_scm",(void*)f_575},
{"f_566:chicken_profile_scm",(void*)f_566},
{"f_559:chicken_profile_scm",(void*)f_559},
{"f_541:chicken_profile_scm",(void*)f_541},
{"f_518:chicken_profile_scm",(void*)f_518},
{"f_538:chicken_profile_scm",(void*)f_538},
{"f_522:chicken_profile_scm",(void*)f_522},
{"f_499:chicken_profile_scm",(void*)f_499},
{"f_461:chicken_profile_scm",(void*)f_461},
{"f_479:chicken_profile_scm",(void*)f_479},
{"f_487:chicken_profile_scm",(void*)f_487},
{"f_491:chicken_profile_scm",(void*)f_491},
{"f_477:chicken_profile_scm",(void*)f_477},
{"f_464:chicken_profile_scm",(void*)f_464},
{"f_454:chicken_profile_scm",(void*)f_454},
{"f_1104:chicken_profile_scm",(void*)f_1104},
{"f_1107:chicken_profile_scm",(void*)f_1107},
{"f_1580:chicken_profile_scm",(void*)f_1580},
{"f_1110:chicken_profile_scm",(void*)f_1110},
{"f_1497:chicken_profile_scm",(void*)f_1497},
{"f_1574:chicken_profile_scm",(void*)f_1574},
{"f_1524:chicken_profile_scm",(void*)f_1524},
{"f_1542:chicken_profile_scm",(void*)f_1542},
{"f_1549:chicken_profile_scm",(void*)f_1549},
{"f_1495:chicken_profile_scm",(void*)f_1495},
{"f_1113:chicken_profile_scm",(void*)f_1113},
{"f_1483:chicken_profile_scm",(void*)f_1483},
{"f_1487:chicken_profile_scm",(void*)f_1487},
{"f_1116:chicken_profile_scm",(void*)f_1116},
{"f_1463:chicken_profile_scm",(void*)f_1463},
{"f_1371:chicken_profile_scm",(void*)f_1371},
{"f_1373:chicken_profile_scm",(void*)f_1373},
{"f_1420:chicken_profile_scm",(void*)f_1420},
{"f_1424:chicken_profile_scm",(void*)f_1424},
{"f_1428:chicken_profile_scm",(void*)f_1428},
{"f_1432:chicken_profile_scm",(void*)f_1432},
{"f_1436:chicken_profile_scm",(void*)f_1436},
{"f_1120:chicken_profile_scm",(void*)f_1120},
{"f_1129:chicken_profile_scm",(void*)f_1129},
{"f_1267:chicken_profile_scm",(void*)f_1267},
{"f_1326:chicken_profile_scm",(void*)f_1326},
{"f_1275:chicken_profile_scm",(void*)f_1275},
{"f_1277:chicken_profile_scm",(void*)f_1277},
{"f_1310:chicken_profile_scm",(void*)f_1310},
{"f_1290:chicken_profile_scm",(void*)f_1290},
{"f_1132:chicken_profile_scm",(void*)f_1132},
{"f_1212:chicken_profile_scm",(void*)f_1212},
{"f_1253:chicken_profile_scm",(void*)f_1253},
{"f_1245:chicken_profile_scm",(void*)f_1245},
{"f_1215:chicken_profile_scm",(void*)f_1215},
{"f_1220:chicken_profile_scm",(void*)f_1220},
{"f_1230:chicken_profile_scm",(void*)f_1230},
{"f_1134:chicken_profile_scm",(void*)f_1134},
{"f_1148:chicken_profile_scm",(void*)f_1148},
{"f_1155:chicken_profile_scm",(void*)f_1155},
{"f_1185:chicken_profile_scm",(void*)f_1185},
{"f_1161:chicken_profile_scm",(void*)f_1161},
{"f_1146:chicken_profile_scm",(void*)f_1146},
{"f_1142:chicken_profile_scm",(void*)f_1142},
{"f_1591:chicken_profile_scm",(void*)f_1591},
{"f_1597:chicken_profile_scm",(void*)f_1597},
{"f_1594:chicken_profile_scm",(void*)f_1594},
{"f_1044:chicken_profile_scm",(void*)f_1044},
{"f_1098:chicken_profile_scm",(void*)f_1098},
{"f_1055:chicken_profile_scm",(void*)f_1055},
{"f_1087:chicken_profile_scm",(void*)f_1087},
{"f_1091:chicken_profile_scm",(void*)f_1091},
{"f_1079:chicken_profile_scm",(void*)f_1079},
{"f_1067:chicken_profile_scm",(void*)f_1067},
{"f_1063:chicken_profile_scm",(void*)f_1063},
{"f_964:chicken_profile_scm",(void*)f_964},
{"f_996:chicken_profile_scm",(void*)f_996},
{"f_991:chicken_profile_scm",(void*)f_991},
{"f_966:chicken_profile_scm",(void*)f_966},
{"f_973:chicken_profile_scm",(void*)f_973},
{"f_849:chicken_profile_scm",(void*)f_849},
{"f_853:chicken_profile_scm",(void*)f_853},
{"f_863:chicken_profile_scm",(void*)f_863},
{"f_865:chicken_profile_scm",(void*)f_865},
{"f_894:chicken_profile_scm",(void*)f_894},
{"f_900:chicken_profile_scm",(void*)f_900},
{"f_910:chicken_profile_scm",(void*)f_910},
{"f_913:chicken_profile_scm",(void*)f_913},
{"f_890:chicken_profile_scm",(void*)f_890},
{"f_875:chicken_profile_scm",(void*)f_875},
{"f_882:chicken_profile_scm",(void*)f_882},
{"f_856:chicken_profile_scm",(void*)f_856},
{"f_765:chicken_profile_scm",(void*)f_765},
{"f_773:chicken_profile_scm",(void*)f_773},
{"f_777:chicken_profile_scm",(void*)f_777},
{"f_736:chicken_profile_scm",(void*)f_736},
{"f_707:chicken_profile_scm",(void*)f_707},
{"f_672:chicken_profile_scm",(void*)f_672},
{"f_397:chicken_profile_scm",(void*)f_397},
{"f_408:chicken_profile_scm",(void*)f_408},
{"f_401:chicken_profile_scm",(void*)f_401},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
