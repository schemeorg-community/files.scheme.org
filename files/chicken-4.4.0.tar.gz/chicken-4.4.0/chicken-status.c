/* Generated from chicken-status.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: chicken-status.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -ignore-repository -output-file chicken-status.c
   used units: library eval srfi_1 posix data_structures utils ports regex files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[55];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_368)
static void C_ccall f_368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_371)
static void C_ccall f_371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_374)
static void C_ccall f_374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_383)
static void C_ccall f_383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_738)
static void C_fcall f_738(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_782)
static void C_fcall f_782(C_word t0,C_word t1) C_noret;
C_noret_decl(f_827)
static void C_fcall f_827(C_word t0,C_word t1) C_noret;
C_noret_decl(f1008)
static void C_ccall f1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_836)
static void C_ccall f_836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1003)
static void C_ccall f1003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_853)
static void C_ccall f_853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_849)
static void C_ccall f_849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_821)
static void C_ccall f_821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f998)
static void C_ccall f998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_461)
static void C_ccall f_461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_422)
static void C_ccall f_422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_424)
static void C_fcall f_424(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_453)
static void C_ccall f_453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_414)
static void C_ccall f_414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_412)
static void C_ccall f_412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_408)
static void C_ccall f_408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_748)
static void C_ccall f_748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_924)
static void C_ccall f_924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_927)
static void C_ccall f_927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_669)
static void C_ccall f_669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_706)
static void C_ccall f_706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_720)
static void C_ccall f_720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_704)
static void C_ccall f_704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_677)
static void C_ccall f_677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_679)
static void C_fcall f_679(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_689)
static void C_ccall f_689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_583)
static void C_ccall f_583(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_551)
static void C_ccall f_551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_557)
static void C_ccall f_557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_577)
static void C_ccall f_577(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_577)
static void C_ccall f_577r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_571)
static void C_ccall f_571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_560)
static void C_ccall f_560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_667)
static void C_ccall f_667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_587)
static void C_ccall f_587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_594)
static void C_ccall f_594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_596)
static void C_fcall f_596(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_648)
static void C_ccall f_648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_604)
static void C_fcall f_604(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_645)
static void C_ccall f_645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_638)
static void C_ccall f_638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_618)
static void C_ccall f_618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_630)
static void C_ccall f_630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_626)
static void C_ccall f_626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_622)
static void C_ccall f_622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_467)
static void C_fcall f_467(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_499)
static void C_fcall f_499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_494)
static void C_fcall f_494(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_469)
static void C_fcall f_469(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_476)
static void C_ccall f_476(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_738)
static void C_fcall trf_738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_738(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_738(t0,t1,t2,t3);}

C_noret_decl(trf_782)
static void C_fcall trf_782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_782(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_782(t0,t1);}

C_noret_decl(trf_827)
static void C_fcall trf_827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_827(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_827(t0,t1);}

C_noret_decl(trf_424)
static void C_fcall trf_424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_424(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_424(t0,t1,t2);}

C_noret_decl(trf_679)
static void C_fcall trf_679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_679(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_679(t0,t1,t2);}

C_noret_decl(trf_596)
static void C_fcall trf_596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_596(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_596(t0,t1,t2);}

C_noret_decl(trf_604)
static void C_fcall trf_604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_604(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_604(t0,t1,t2);}

C_noret_decl(trf_467)
static void C_fcall trf_467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_467(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_467(t0,t1,t2,t3);}

C_noret_decl(trf_499)
static void C_fcall trf_499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_499(t0,t1);}

C_noret_decl(trf_494)
static void C_fcall trf_494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_494(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_494(t0,t1,t2);}

C_noret_decl(trf_469)
static void C_fcall trf_469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_469(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_469(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(369)){
C_save(t1);
C_rereclaim2(369*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,55);
lf[1]=C_h_intern(&lf[1],13,"string-append");
lf[2]=C_h_intern(&lf[2],11,"make-string");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[6]=C_h_intern(&lf[6],7,"version");
lf[7]=C_h_intern(&lf[7],5,"print");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\012 version: ");
lf[9]=C_h_intern(&lf[9],8,"->string");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[11]=C_h_intern(&lf[11],19,"setup-api#read-info");
lf[12]=C_h_intern(&lf[12],4,"sort");
lf[13]=C_h_intern(&lf[13],8,"string<\077");
lf[14]=C_h_intern(&lf[14],3,"min");
lf[15]=C_h_intern(&lf[15],13,"terminal-size");
lf[16]=C_h_intern(&lf[16],14,"terminal-port\077");
lf[17]=C_h_intern(&lf[17],19,"current-output-port");
lf[19]=C_h_intern(&lf[19],5,"files");
lf[20]=C_h_intern(&lf[20],10,"append-map");
lf[21]=C_h_intern(&lf[21],25,"\003sysimplicit-exit-handler");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\006(none)");
lf[23]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002.*\376\377\016");
lf[24]=C_h_intern(&lf[24],17,"delete-duplicates");
lf[25]=C_h_intern(&lf[25],8,"string=\077");
lf[26]=C_h_intern(&lf[26],11,"concatenate");
lf[27]=C_h_intern(&lf[27],4,"grep");
lf[28]=C_h_intern(&lf[28],7,"\003sysmap");
lf[29]=C_h_intern(&lf[29],13,"pathname-file");
lf[30]=C_h_intern(&lf[30],4,"glob");
lf[31]=C_h_intern(&lf[31],13,"make-pathname");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[34]=C_h_intern(&lf[34],15,"repository-path");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[36]=C_h_intern(&lf[36],4,"exit");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\312usage: chicken-status [OPTION | PATTERN] ...\012\012  -h   -help                 "
"   show this message\012  -v   -version                 show version and exit\012  -f "
"  -files                   list installed files");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\002-f");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\006-files");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[42]=C_h_intern(&lf[42],15,"chicken-version");
lf[43]=C_h_intern(&lf[43],6,"append");
lf[44]=C_h_intern(&lf[44],6,"string");
lf[45]=C_h_intern(&lf[45],17,"lset-intersection");
lf[46]=C_h_intern(&lf[46],3,"eq\077");
lf[47]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000f\376\377\016");
lf[48]=C_h_intern(&lf[48],16,"\003sysstring->list");
lf[49]=C_h_intern(&lf[49],9,"substring");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[52]=C_h_intern(&lf[52],22,"command-line-arguments");
lf[53]=C_h_intern(&lf[53],11,"\003sysrequire");
lf[54]=C_h_intern(&lf[54],9,"setup-api");
C_register_lf2(lf,55,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_368,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k366 */
static void C_ccall f_368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_371,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k369 in k366 */
static void C_ccall f_371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_374,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k372 in k369 in k366 */
static void C_ccall f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k375 in k372 in k369 in k366 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t2,lf[54]);}

/* k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_467,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[5] /* (set! main#list-installed-eggs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_583,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[18] /* (set! main#list-installed-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_669,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_924,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_934,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 131  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[52]))(2,*((C_word*)lf[52]+1),t6);}

/* k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_934,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_738,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_738(t7,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_fcall f_738(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_738,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_748,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?lf[23]:t3);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_401,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_422,a[2]=t11,a[3]=t8,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_461,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_465,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 38   repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[34]))(2,*((C_word*)lf[34]+1),t14);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[35]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_782,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_782(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[50]);
t8=t6;
f_782(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[51])));}}}

/* k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_fcall f_782(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_782,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f998,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 89   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t3,lf[37]);}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[38]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[39]));
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-status.scm: 117  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_738(t6,((C_word*)t0)[7],t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[40]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[41]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_814,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_821,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 119  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[42]))(2,*((C_word*)lf[42]+1),t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_827,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_positivep(t7))){
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t9=t6;
f_827(t9,(C_word)C_eqp(C_make_character(45),t8));}
else{
t8=t6;
f_827(t8,C_SCHEME_FALSE);}}}}}

/* k825 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_fcall f_827(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_827,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_874,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 124  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1008,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 89   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t4,lf[37]);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[3]);
/* chicken-status.scm: 129  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_738(t4,((C_word*)t0)[4],t2,t3);}}

/* f1008 in k825 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 97   exit */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],C_fix(1));}

/* k872 in k825 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[48]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k834 in k825 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_870,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-status.scm: 125  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t2,*((C_word*)lf[46]+1),lf[47],t1);}

/* k868 in k834 in k825 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_870,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_849,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_853,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_859,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1003,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 89   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t3,lf[37]);}}

/* f1003 in k868 in k834 in k825 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f1003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 97   exit */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],C_fix(1));}

/* a858 in k868 in k834 in k825 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_859,3,t0,t1,t2);}
t3=*((C_word*)lf[44]+1);
/* g338339 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(45),t2);}

/* k851 in k868 in k834 in k825 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-status.scm: 126  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[43]+1)))(4,*((C_word*)lf[43]+1),((C_word*)t0)[2],t1,t2);}

/* k847 in k868 in k834 in k825 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 126  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_738(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k819 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 119  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],t1);}

/* k812 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 120  exit */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],C_fix(0));}

/* f998 in k780 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 97   exit */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],C_fix(0));}

/* k463 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 38   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),((C_word*)t0)[2],t1,lf[32],lf[33]);}

/* k459 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 38   glob */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),((C_word*)t0)[2],t1);}

/* k420 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_422,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_424,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_424(t5,((C_word*)t0)[2],t1);}

/* loop155 in k420 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_fcall f_424(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_424,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[29]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_453,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g171172 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k451 in loop155 in k420 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_453,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop155168 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_424(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop155168 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_424(t6,((C_word*)t0)[3],t5);}}

/* k399 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_408,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_412,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_414,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a413 in k399 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_414,3,t0,t1,t2);}
t3=C_retrieve(lf[27]);
/* g195196 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* k410 in k399 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 40   concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),((C_word*)t0)[2],t1);}

/* k406 in k399 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 39   delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),((C_word*)t0)[2],t1,*((C_word*)lf[25]+1));}

/* k746 in loop in k932 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-status.scm: 107  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],lf[22]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=C_retrieve2(lf[18],"main#list-installed-files");
t3=C_retrieve2(lf[18],"main#list-installed-files");
/* g285286 */
t4=C_retrieve2(lf[18],"main#list-installed-files");
f_669(3,t4,((C_word*)t0)[3],t1);}
else{
t2=C_retrieve2(lf[5],"main#list-installed-eggs");
t3=C_retrieve2(lf[5],"main#list-installed-eggs");
/* g285286 */
t4=C_retrieve2(lf[5],"main#list-installed-eggs");
f_583(3,t4,((C_word*)t0)[3],t1);}}}

/* k922 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_927,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_930,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t3);}

/* k928 in k922 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k925 in k922 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#list-installed-files in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_669,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_677,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_704,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_706,tmp=(C_word)a,a+=2,tmp);
/* chicken-status.scm: 79   append-map */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t4,t5,t2);}

/* a705 in main#list-installed-files in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_706,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_720,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 81   setup-api#read-info */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* k718 in a705 in main#list-installed-files in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(lf[19],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_END_OF_LIST));}

/* k702 in main#list-installed-files in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 78   sort */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),((C_word*)t0)[2],t1,*((C_word*)lf[13]+1));}

/* k675 in main#list-installed-files in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_677,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_679,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_679(t5,((C_word*)t0)[2],t1);}

/* loop262 in k675 in main#list-installed-files in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_fcall f_679(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_679,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[7]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_689,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g269270 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k687 in loop262 in k675 in main#list-installed-files in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_679(t3,((C_word*)t0)[2],t2);}

/* main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_583(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_583,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_587,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_667,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_551,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 53   current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[17]+1)))(2,*((C_word*)lf[17]+1),t5);}

/* k549 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_557,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-status.scm: 54   terminal-port? */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,t1);}

/* k555 in k549 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_557,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_571,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_577,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}
else{
t2=((C_word*)t0)[4];
f_587(2,t2,C_fix(39));}}

/* a576 in k555 in k549 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_577(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_577r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_577r(t0,t1,t2);}}

static void C_ccall f_577r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a570 in k555 in k549 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_571,2,t0,t1);}
/* chicken-status.scm: 55   terminal-size */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t1,((C_word*)t0)[2]);}

/* k558 in k555 in k549 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[3];
f_587(2,t2,C_fix(39));}
else{
/* chicken-status.scm: 58   min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_fix(80),t1);}}

/* k665 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_667,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,t1,C_fix(2));
C_quotient(4,0,((C_word*)t0)[2],t2,C_fix(2));}

/* k585 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_594,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 73   sort */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),t2,((C_word*)t0)[2],*((C_word*)lf[13]+1));}

/* k592 in k585 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_594,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_596,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_596(t5,((C_word*)t0)[2],t1);}

/* loop245 in k592 in k585 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_fcall f_596(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_596,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_604,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_648,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g252253 */
t6=t3;
f_604(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k646 in loop245 in k592 in k585 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_596(t3,((C_word*)t0)[2],t2);}

/* g252 in loop245 in k592 in k585 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_fcall f_604(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_604,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_645,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-status.scm: 65   setup-api#read-info */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* k643 in g252 in loop245 in k592 in k585 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_645,2,t0,t1);}
t2=(C_word)C_i_assq(lf[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_618,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_638,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 68   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t4,((C_word*)t0)[2],lf[10]);}
else{
/* chicken-status.scm: 72   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k636 in k643 in g252 in loop245 in k592 in k585 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_638,2,t0,t1);}
/* chicken-status.scm: 68   format-string */
f_467(((C_word*)t0)[3],t1,((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,C_make_character(46)));}

/* k616 in k643 in g252 in loop245 in k592 in k585 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_622,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_626,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_630,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-status.scm: 70   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t4,t5);}

/* k628 in k616 in k643 in g252 in loop245 in k592 in k585 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 70   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[8],t1);}

/* k624 in k616 in k643 in g252 in loop245 in k592 in k585 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_626,2,t0,t1);}
/* chicken-status.scm: 69   format-string */
f_467(((C_word*)t0)[3],t1,((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,C_make_character(46)));}

/* k620 in k616 in k643 in g252 in loop245 in k592 in k585 in main#list-installed-eggs in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 67   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* main#format-string in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_fcall f_467(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_467,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_469,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_494,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_499,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-right214228 */
t8=t7;
f_499(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-padc215226 */
t10=t6;
f_494(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body212220 */
t12=t5;
f_469(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[4],t11);}}}}

/* def-right214 in main#format-string in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_fcall f_499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_499,NULL,2,t0,t1);}
/* def-padc215226 */
t2=((C_word*)t0)[2];
f_494(t2,t1,C_SCHEME_FALSE);}

/* def-padc215 in main#format-string in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_fcall f_494(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_494,NULL,3,t0,t1,t2);}
/* body212220 */
t3=((C_word*)t0)[2];
f_469(t3,t1,t2,C_make_character(32));}

/* body212 in main#format-string in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_fcall f_469(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_469,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_476,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[2],t4);
t7=(C_word)C_i_fixnum_max(C_fix(0),t6);
/* chicken-status.scm: 45   make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[2]+1)))(4,*((C_word*)lf[2]+1),t5,t7,t3);}

/* k474 in body212 in main#format-string in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 */
static void C_ccall f_476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-status.scm: 47   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-status.scm: 48   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[70] = {
{"toplevel:chicken_status_scm",(void*)C_toplevel},
{"f_368:chicken_status_scm",(void*)f_368},
{"f_371:chicken_status_scm",(void*)f_371},
{"f_374:chicken_status_scm",(void*)f_374},
{"f_377:chicken_status_scm",(void*)f_377},
{"f_380:chicken_status_scm",(void*)f_380},
{"f_383:chicken_status_scm",(void*)f_383},
{"f_386:chicken_status_scm",(void*)f_386},
{"f_389:chicken_status_scm",(void*)f_389},
{"f_392:chicken_status_scm",(void*)f_392},
{"f_395:chicken_status_scm",(void*)f_395},
{"f_934:chicken_status_scm",(void*)f_934},
{"f_738:chicken_status_scm",(void*)f_738},
{"f_782:chicken_status_scm",(void*)f_782},
{"f_827:chicken_status_scm",(void*)f_827},
{"f1008:chicken_status_scm",(void*)f1008},
{"f_874:chicken_status_scm",(void*)f_874},
{"f_836:chicken_status_scm",(void*)f_836},
{"f_870:chicken_status_scm",(void*)f_870},
{"f1003:chicken_status_scm",(void*)f1003},
{"f_859:chicken_status_scm",(void*)f_859},
{"f_853:chicken_status_scm",(void*)f_853},
{"f_849:chicken_status_scm",(void*)f_849},
{"f_821:chicken_status_scm",(void*)f_821},
{"f_814:chicken_status_scm",(void*)f_814},
{"f998:chicken_status_scm",(void*)f998},
{"f_465:chicken_status_scm",(void*)f_465},
{"f_461:chicken_status_scm",(void*)f_461},
{"f_422:chicken_status_scm",(void*)f_422},
{"f_424:chicken_status_scm",(void*)f_424},
{"f_453:chicken_status_scm",(void*)f_453},
{"f_401:chicken_status_scm",(void*)f_401},
{"f_414:chicken_status_scm",(void*)f_414},
{"f_412:chicken_status_scm",(void*)f_412},
{"f_408:chicken_status_scm",(void*)f_408},
{"f_748:chicken_status_scm",(void*)f_748},
{"f_924:chicken_status_scm",(void*)f_924},
{"f_930:chicken_status_scm",(void*)f_930},
{"f_927:chicken_status_scm",(void*)f_927},
{"f_669:chicken_status_scm",(void*)f_669},
{"f_706:chicken_status_scm",(void*)f_706},
{"f_720:chicken_status_scm",(void*)f_720},
{"f_704:chicken_status_scm",(void*)f_704},
{"f_677:chicken_status_scm",(void*)f_677},
{"f_679:chicken_status_scm",(void*)f_679},
{"f_689:chicken_status_scm",(void*)f_689},
{"f_583:chicken_status_scm",(void*)f_583},
{"f_551:chicken_status_scm",(void*)f_551},
{"f_557:chicken_status_scm",(void*)f_557},
{"f_577:chicken_status_scm",(void*)f_577},
{"f_571:chicken_status_scm",(void*)f_571},
{"f_560:chicken_status_scm",(void*)f_560},
{"f_667:chicken_status_scm",(void*)f_667},
{"f_587:chicken_status_scm",(void*)f_587},
{"f_594:chicken_status_scm",(void*)f_594},
{"f_596:chicken_status_scm",(void*)f_596},
{"f_648:chicken_status_scm",(void*)f_648},
{"f_604:chicken_status_scm",(void*)f_604},
{"f_645:chicken_status_scm",(void*)f_645},
{"f_638:chicken_status_scm",(void*)f_638},
{"f_618:chicken_status_scm",(void*)f_618},
{"f_630:chicken_status_scm",(void*)f_630},
{"f_626:chicken_status_scm",(void*)f_626},
{"f_622:chicken_status_scm",(void*)f_622},
{"f_467:chicken_status_scm",(void*)f_467},
{"f_499:chicken_status_scm",(void*)f_499},
{"f_494:chicken_status_scm",(void*)f_494},
{"f_469:chicken_status_scm",(void*)f_469},
{"f_476:chicken_status_scm",(void*)f_476},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
