/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: srfi-69.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file usrfi-69.c -extend ./private-namespace.scm
   unit: srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[115];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_69_toplevel)
C_externexport void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5603)
static void C_ccall f_5603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5615)
static void C_ccall f_5615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_fcall f_5672(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_fcall f_5630(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5564)
static void C_ccall f_5564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_fcall f_5450(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5462)
static void C_fcall f_5462(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5478)
static void C_fcall f_5478(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5379)
static void C_fcall f_5379(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5391)
static void C_fcall f_5391(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5414)
static void C_fcall f_5414(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_fcall f_5422(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5329)
static void C_fcall f_5329(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5345)
static void C_fcall f_5345(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5264)
static void C_fcall f_5264(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5280)
static void C_fcall f_5280(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_fcall f_5210(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5218)
static void C_fcall f_5218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5140)
static void C_fcall f_5140(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5156)
static void C_fcall f_5156(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5032)
static void C_fcall f_5032(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5044)
static void C_fcall f_5044(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5067)
static void C_fcall f_5067(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_ccall f_5054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4941)
static void C_fcall f_4941(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4967)
static void C_fcall f_4967(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_fcall f_4872(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static C_word C_fcall f_4825(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_fcall f_4752(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static C_word C_fcall f_4712(C_word t0,C_word t1);
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4591)
static void C_ccall f_4591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_fcall f_4645(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static C_word C_fcall f_4606(C_word t0,C_word t1);
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_fcall f_4406(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_fcall f_4521(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_fcall f_4472(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_fcall f_4149(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_fcall f_4179(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_fcall f_4301(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_fcall f_4242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4104)
static void C_fcall f_4104(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4087)
static void C_fcall f_4087(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_fcall f_3859(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_fcall f_3898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4024)
static void C_fcall f_4024(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_fcall f_3961(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3736)
static void C_fcall f_3736(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3746)
static void C_ccall f_3746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_fcall f_3751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3813)
static void C_fcall f_3813(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_fcall f_3643(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3666)
static void C_fcall f_3666(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_fcall f_3250(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_fcall f_3253(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3256)
static void C_fcall f_3256(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_fcall f_3291(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_fcall f_3302(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3174)
static C_word C_fcall f_3174(C_word t0);
C_noret_decl(f_3148)
static void C_fcall f_3148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_fcall f_3118(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3124)
static C_word C_fcall f_3124(C_word t0,C_word t1);
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3059)
static void C_fcall f_3059(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_fcall f_3050(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3031)
static void C_fcall f_3031(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2921)
static void C_fcall f_2921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_fcall f_2912(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2893)
static void C_fcall f_2893(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_fcall f_2321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_fcall f_2440(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2775)
static void C_fcall f_2775(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2763)
static void C_fcall f_2763(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_fcall f_2696(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_fcall f_2670(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_fcall f_2389(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2423)
static void C_fcall f_2423(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_fcall f_2426(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_fcall f_2324(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2341)
static void C_fcall f_2341(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_fcall f_1686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_5672)
static void C_fcall trf_5672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5672(t0,t1,t2);}

C_noret_decl(trf_5630)
static void C_fcall trf_5630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5630(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5630(t0,t1,t2);}

C_noret_decl(trf_5450)
static void C_fcall trf_5450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5450(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5450(t0,t1,t2,t3);}

C_noret_decl(trf_5462)
static void C_fcall trf_5462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5462(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5462(t0,t1,t2,t3);}

C_noret_decl(trf_5478)
static void C_fcall trf_5478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5478(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5478(t0,t1,t2,t3);}

C_noret_decl(trf_5379)
static void C_fcall trf_5379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5379(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5379(t0,t1,t2);}

C_noret_decl(trf_5391)
static void C_fcall trf_5391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5391(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5391(t0,t1,t2);}

C_noret_decl(trf_5414)
static void C_fcall trf_5414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5414(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5414(t0,t1,t2);}

C_noret_decl(trf_5422)
static void C_fcall trf_5422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5422(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5422(t0,t1,t2);}

C_noret_decl(trf_5329)
static void C_fcall trf_5329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5329(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5329(t0,t1,t2,t3);}

C_noret_decl(trf_5345)
static void C_fcall trf_5345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5345(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5345(t0,t1,t2,t3);}

C_noret_decl(trf_5264)
static void C_fcall trf_5264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5264(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5264(t0,t1,t2,t3);}

C_noret_decl(trf_5280)
static void C_fcall trf_5280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5280(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5280(t0,t1,t2,t3);}

C_noret_decl(trf_5210)
static void C_fcall trf_5210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5210(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5210(t0,t1,t2);}

C_noret_decl(trf_5218)
static void C_fcall trf_5218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5218(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5218(t0,t1,t2);}

C_noret_decl(trf_5140)
static void C_fcall trf_5140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5140(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5140(t0,t1,t2,t3);}

C_noret_decl(trf_5156)
static void C_fcall trf_5156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5156(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5156(t0,t1,t2,t3);}

C_noret_decl(trf_5032)
static void C_fcall trf_5032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5032(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5032(t0,t1,t2);}

C_noret_decl(trf_5044)
static void C_fcall trf_5044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5044(t0,t1,t2);}

C_noret_decl(trf_5067)
static void C_fcall trf_5067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5067(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5067(t0,t1,t2);}

C_noret_decl(trf_4941)
static void C_fcall trf_4941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4941(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4941(t0,t1,t2);}

C_noret_decl(trf_4967)
static void C_fcall trf_4967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4967(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4967(t0,t1,t2,t3);}

C_noret_decl(trf_4872)
static void C_fcall trf_4872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4872(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4872(t0,t1,t2,t3);}

C_noret_decl(trf_4752)
static void C_fcall trf_4752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4752(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4752(t0,t1,t2);}

C_noret_decl(trf_4645)
static void C_fcall trf_4645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4645(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4645(t0,t1,t2);}

C_noret_decl(trf_4406)
static void C_fcall trf_4406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4406(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4406(t0,t1);}

C_noret_decl(trf_4521)
static void C_fcall trf_4521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4521(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4521(t0,t1,t2);}

C_noret_decl(trf_4472)
static void C_fcall trf_4472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4472(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4472(t0,t1,t2);}

C_noret_decl(trf_4149)
static void C_fcall trf_4149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4149(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4149(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4179)
static void C_fcall trf_4179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4179(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4179(t0,t1);}

C_noret_decl(trf_4301)
static void C_fcall trf_4301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4301(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4301(t0,t1,t2);}

C_noret_decl(trf_4242)
static void C_fcall trf_4242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4242(t0,t1,t2);}

C_noret_decl(trf_4104)
static void C_fcall trf_4104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4104(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4104(t0,t1);}

C_noret_decl(trf_4087)
static void C_fcall trf_4087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4087(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4087(t0,t1,t2);}

C_noret_decl(trf_3859)
static void C_fcall trf_3859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3859(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3859(t0,t1,t2,t3);}

C_noret_decl(trf_3898)
static void C_fcall trf_3898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3898(t0,t1);}

C_noret_decl(trf_4024)
static void C_fcall trf_4024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4024(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4024(t0,t1,t2);}

C_noret_decl(trf_3961)
static void C_fcall trf_3961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3961(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3961(t0,t1,t2);}

C_noret_decl(trf_3736)
static void C_fcall trf_3736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3736(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3736(t0,t1,t2);}

C_noret_decl(trf_3751)
static void C_fcall trf_3751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3751(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3751(t0,t1,t2);}

C_noret_decl(trf_3813)
static void C_fcall trf_3813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3813(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3813(t0,t1,t2);}

C_noret_decl(trf_3643)
static void C_fcall trf_3643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3643(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3643(t0,t1,t2);}

C_noret_decl(trf_3666)
static void C_fcall trf_3666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3666(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3666(t0,t1,t2);}

C_noret_decl(trf_3250)
static void C_fcall trf_3250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3250(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3250(t0,t1);}

C_noret_decl(trf_3253)
static void C_fcall trf_3253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3253(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3253(t0,t1);}

C_noret_decl(trf_3256)
static void C_fcall trf_3256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3256(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3256(t0,t1);}

C_noret_decl(trf_3291)
static void C_fcall trf_3291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3291(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3291(t0,t1,t2);}

C_noret_decl(trf_3302)
static void C_fcall trf_3302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3302(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3302(t0,t1,t2);}

C_noret_decl(trf_3148)
static void C_fcall trf_3148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3148(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_3148(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_3118)
static void C_fcall trf_3118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3118(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3118(t0,t1,t2);}

C_noret_decl(trf_3059)
static void C_fcall trf_3059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3059(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3059(t0,t1);}

C_noret_decl(trf_3050)
static void C_fcall trf_3050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3050(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3050(t0,t1,t2);}

C_noret_decl(trf_3031)
static void C_fcall trf_3031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3031(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3031(t0,t1,t2,t3);}

C_noret_decl(trf_2921)
static void C_fcall trf_2921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2921(t0,t1);}

C_noret_decl(trf_2912)
static void C_fcall trf_2912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2912(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2912(t0,t1,t2);}

C_noret_decl(trf_2893)
static void C_fcall trf_2893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2893(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2893(t0,t1,t2,t3);}

C_noret_decl(trf_2321)
static void C_fcall trf_2321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2321(t0,t1);}

C_noret_decl(trf_2440)
static void C_fcall trf_2440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2440(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2440(t0,t1,t2,t3);}

C_noret_decl(trf_2775)
static void C_fcall trf_2775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2775(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2775(t0,t1,t2);}

C_noret_decl(trf_2763)
static void C_fcall trf_2763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2763(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2763(t0,t1,t2);}

C_noret_decl(trf_2696)
static void C_fcall trf_2696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2696(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2696(t0,t1,t2);}

C_noret_decl(trf_2670)
static void C_fcall trf_2670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2670(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2670(t0,t1,t2);}

C_noret_decl(trf_2389)
static void C_fcall trf_2389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2389(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2389(t0,t1,t2,t3);}

C_noret_decl(trf_2423)
static void C_fcall trf_2423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2423(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2423(t0,t1);}

C_noret_decl(trf_2426)
static void C_fcall trf_2426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2426(t0,t1);}

C_noret_decl(trf_2324)
static void C_fcall trf_2324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2324(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2324(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2341)
static void C_fcall trf_2341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2341(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2341(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1686)
static void C_fcall trf_1686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1686(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(933)){
C_save(t1);
C_rereclaim2(933*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,115);
lf[0]=C_h_intern(&lf[0],20,"\003sysnumber-hash-hook");
lf[2]=C_h_intern(&lf[2],11,"number-hash");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],5,"\000type");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[6]=C_h_intern(&lf[6],15,"object-uid-hash");
lf[7]=C_h_intern(&lf[7],11,"symbol-hash");
lf[8]=C_h_intern(&lf[8],17,"\003syscheck-keyword");
lf[9]=C_h_intern(&lf[9],11,"\000type-error");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[11]=C_h_intern(&lf[11],8,"keyword\077");
lf[12]=C_h_intern(&lf[12],12,"keyword-hash");
lf[13]=C_h_intern(&lf[13],8,"eq\077-hash");
lf[14]=C_h_intern(&lf[14],16,"hash-by-identity");
lf[15]=C_h_intern(&lf[15],9,"eqv\077-hash");
lf[16]=C_h_intern(&lf[16],11,"input-port\077");
lf[17]=C_h_intern(&lf[17],11,"equal\077-hash");
lf[18]=C_h_intern(&lf[18],4,"hash");
lf[19]=C_h_intern(&lf[19],11,"string-hash");
lf[20]=C_h_intern(&lf[20],13,"\003syssubstring");
lf[21]=C_h_intern(&lf[21],15,"\003syscheck-range");
lf[22]=C_h_intern(&lf[22],14,"string-ci-hash");
lf[23]=C_h_intern(&lf[23],14,"string-hash-ci");
lf[25]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[27]=C_h_intern(&lf[27],11,"make-vector");
lf[29]=C_h_intern(&lf[29],10,"hash-table");
lf[30]=C_h_intern(&lf[30],3,"eq\077");
lf[31]=C_h_intern(&lf[31],4,"eqv\077");
lf[32]=C_h_intern(&lf[32],6,"equal\077");
lf[33]=C_h_intern(&lf[33],8,"string=\077");
lf[34]=C_h_intern(&lf[34],11,"string-ci=\077");
lf[35]=C_h_intern(&lf[35],1,"=");
lf[36]=C_h_intern(&lf[36],15,"make-hash-table");
lf[37]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[38]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[39]=C_h_intern(&lf[39],7,"warning");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[41]=C_h_intern(&lf[41],5,"error");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[43]=C_h_intern(&lf[43],5,"\000test");
lf[44]=C_h_intern(&lf[44],17,"\003syscheck-closure");
lf[45]=C_h_intern(&lf[45],5,"\000hash");
lf[46]=C_h_intern(&lf[46],5,"\000size");
lf[47]=C_h_intern(&lf[47],19,"hash-table-max-size");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[49]=C_h_intern(&lf[49],8,"\000initial");
lf[50]=C_h_intern(&lf[50],9,"\000min-load");
lf[51]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[52]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[54]=C_h_intern(&lf[54],17,"\003syscheck-inexact");
lf[55]=C_h_intern(&lf[55],9,"\000max-load");
lf[56]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[57]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[59]=C_h_intern(&lf[59],10,"\000weak-keys");
lf[60]=C_h_intern(&lf[60],12,"\000weak-values");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[65]=C_h_intern(&lf[65],11,"hash-table\077");
lf[66]=C_h_intern(&lf[66],15,"hash-table-size");
lf[67]=C_h_intern(&lf[67],31,"hash-table-equivalence-function");
lf[68]=C_h_intern(&lf[68],24,"hash-table-hash-function");
lf[69]=C_h_intern(&lf[69],19,"hash-table-min-load");
lf[70]=C_h_intern(&lf[70],19,"hash-table-max-load");
lf[71]=C_h_intern(&lf[71],20,"hash-table-weak-keys");
lf[72]=C_h_intern(&lf[72],22,"hash-table-weak-values");
lf[73]=C_h_intern(&lf[73],23,"hash-table-has-initial\077");
lf[74]=C_h_intern(&lf[74],18,"hash-table-initial");
lf[75]=C_h_intern(&lf[75],18,"hash-table-resize!");
lf[77]=C_h_intern(&lf[77],15,"hash-table-copy");
lf[78]=C_h_intern(&lf[78],18,"hash-table-update!");
lf[79]=C_h_intern(&lf[79],5,"floor");
lf[80]=C_h_intern(&lf[80],13,"\000access-error");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[82]=C_h_intern(&lf[82],8,"identity");
lf[84]=C_h_intern(&lf[84],26,"hash-table-update!/default");
lf[85]=C_h_intern(&lf[85],15,"hash-table-set!");
lf[86]=C_h_intern(&lf[86],19,"\003sysundefined-value");
lf[87]=C_h_intern(&lf[87],14,"hash-table-ref");
lf[88]=C_h_intern(&lf[88],22,"hash-table-ref/default");
lf[89]=C_h_intern(&lf[89],18,"hash-table-exists\077");
lf[90]=C_h_intern(&lf[90],18,"hash-table-delete!");
lf[91]=C_h_intern(&lf[91],18,"hash-table-remove!");
lf[92]=C_h_intern(&lf[92],17,"hash-table-clear!");
lf[93]=C_h_intern(&lf[93],12,"vector-fill!");
lf[95]=C_h_intern(&lf[95],17,"hash-table-merge!");
lf[96]=C_h_intern(&lf[96],16,"hash-table-merge");
lf[97]=C_h_intern(&lf[97],17,"hash-table->alist");
lf[98]=C_h_intern(&lf[98],17,"alist->hash-table");
lf[99]=C_h_intern(&lf[99],15,"hash-table-keys");
lf[100]=C_h_intern(&lf[100],17,"hash-table-values");
lf[103]=C_h_intern(&lf[103],15,"hash-table-fold");
lf[104]=C_h_intern(&lf[104],19,"hash-table-for-each");
lf[105]=C_h_intern(&lf[105],15,"hash-table-walk");
lf[106]=C_h_intern(&lf[106],14,"hash-table-map");
lf[107]=C_h_intern(&lf[107],9,"\003sysprint");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\002)>");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\016#<hash-table (");
lf[110]=C_h_intern(&lf[110],27,"\003sysregister-record-printer");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[112]=C_h_intern(&lf[112],18,"getter-with-setter");
lf[113]=C_h_intern(&lf[113],17,"register-feature!");
lf[114]=C_h_intern(&lf[114],7,"srfi-69");
C_register_lf2(lf,115,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 65   register-feature! */
t3=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[114]);}

/* k1500 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[81],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! number-hash-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1504,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[2]+1 /* (set! number-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1510,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1706,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[7]+1 /* (set! symbol-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1763,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[8]+1 /* (set! check-keyword ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1829,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[12]+1 /* (set! keyword-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1855,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[13]+1 /* (set! eq?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2002,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[14]+1 /* (set! hash-by-identity ...) */,*((C_word*)lf[13]+1));
t10=C_mutate((C_word*)lf[15]+1 /* (set! eqv?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2269,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[1] /* (set! *equal?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2321,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[17]+1 /* (set! equal?-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2787,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[18]+1 /* (set! hash ...) */,*((C_word*)lf[17]+1));
t14=C_mutate((C_word*)lf[19]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2840,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[22]+1 /* (set! string-ci-hash ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2978,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[23]+1 /* (set! string-hash-ci ...) */,*((C_word*)lf[22]+1));
t17=C_mutate(&lf[24] /* (set! constant699 ...) */,lf[25]);
t18=C_mutate(&lf[26] /* (set! hash-table-canonical-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3118,tmp=(C_word)a,a+=2,tmp));
t19=*((C_word*)lf[27]+1);
t20=C_mutate(&lf[28] /* (set! *make-hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=t19,tmp=(C_word)a,a+=3,tmp));
t21=*((C_word*)lf[30]+1);
t22=*((C_word*)lf[31]+1);
t23=*((C_word*)lf[32]+1);
t24=*((C_word*)lf[33]+1);
t25=*((C_word*)lf[34]+1);
t26=*((C_word*)lf[35]+1);
t27=C_mutate((C_word*)lf[36]+1 /* (set! make-hash-table ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3172,a[2]=t26,a[3]=t25,a[4]=t24,a[5]=t23,a[6]=t22,a[7]=t21,tmp=(C_word)a,a+=8,tmp));
t28=C_mutate((C_word*)lf[65]+1 /* (set! hash-table? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3535,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[66]+1 /* (set! hash-table-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3541,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[67]+1 /* (set! hash-table-equivalence-function ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3550,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[68]+1 /* (set! hash-table-hash-function ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3559,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[69]+1 /* (set! hash-table-min-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3568,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[70]+1 /* (set! hash-table-max-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3577,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[71]+1 /* (set! hash-table-weak-keys ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3586,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[72]+1 /* (set! hash-table-weak-values ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3595,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[73]+1 /* (set! hash-table-has-initial? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3604,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[74]+1 /* (set! hash-table-initial ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3616,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[75]+1 /* (set! hash-table-resize! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3710,tmp=(C_word)a,a+=2,tmp));
t39=*((C_word*)lf[27]+1);
t40=C_mutate(&lf[76] /* (set! *hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3736,a[2]=t39,tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[77]+1 /* (set! hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3848,tmp=(C_word)a,a+=2,tmp));
t42=*((C_word*)lf[30]+1);
t43=C_mutate((C_word*)lf[78]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3857,a[2]=t42,tmp=(C_word)a,a+=3,tmp));
t44=*((C_word*)lf[30]+1);
t45=C_mutate(&lf[83] /* (set! *hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4149,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[84]+1 /* (set! hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4361,tmp=(C_word)a,a+=2,tmp));
t47=*((C_word*)lf[30]+1);
t48=C_mutate((C_word*)lf[85]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4373,a[2]=t47,tmp=(C_word)a,a+=3,tmp));
t49=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t50=*((C_word*)lf[30]+1);
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5593,a[2]=t50,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 809  getter-with-setter */
t52=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t52+1)))(4,t52,t49,t51,*((C_word*)lf[85]+1));}

/* a5592 in k1500 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5593r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5593r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5593r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(11);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5713,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_structure_2(t2,lf[29],lf[87]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5603,a[2]=t1,a[3]=t3,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 816  ##sys#check-closure */
t9=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t6,lf[87]);}

/* k5601 in a5592 in k1500 */
static void C_ccall f_5603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5603,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(4));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_block_size(t2);
/* srfi-69.scm: 820  hash */
t7=t4;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[3],t6);}

/* k5613 in k5601 in a5592 in k1500 */
static void C_ccall f_5615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5615,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5630,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5630(t7,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5672,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5672(t7,((C_word*)t0)[2],t3);}}

/* loop in k5613 in k5601 in a5592 in k1500 */
static void C_fcall f_5672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5672,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 833  def */
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5691,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 835  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k5689 in loop in k5613 in k5601 in a5592 in k1500 */
static void C_ccall f_5691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 837  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5672(t3,((C_word*)t0)[5],t2);}}

/* loop in k5613 in k5601 in a5592 in k1500 */
static void C_fcall f_5630(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5630,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 825  def */
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 829  loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* f_5713 in a5592 in k1500 */
static void C_ccall f_5713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5713,2,t0,t1);}
/* srfi-69.scm: 812  ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[80],lf[87],lf[111],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4571 in k1500 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! hash-table-ref ...) */,t1);
t3=*((C_word*)lf[30]+1);
t4=C_mutate((C_word*)lf[88]+1 /* (set! hash-table-ref/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4575,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[30]+1);
t6=C_mutate((C_word*)lf[89]+1 /* (set! hash-table-exists? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4681,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[30]+1);
t8=C_mutate((C_word*)lf[90]+1 /* (set! hash-table-delete! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4789,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[91]+1 /* (set! hash-table-remove! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4920,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[92]+1 /* (set! hash-table-clear! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5016,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[94] /* (set! *hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5032,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[95]+1 /* (set! hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5097,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[96]+1 /* (set! hash-table-merge ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5109,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[97]+1 /* (set! hash-table->alist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5125,tmp=(C_word)a,a+=2,tmp));
t15=*((C_word*)lf[36]+1);
t16=C_mutate((C_word*)lf[98]+1 /* (set! alist->hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5198,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[99]+1 /* (set! hash-table-keys ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5249,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[100]+1 /* (set! hash-table-values ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5314,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[101] /* (set! *hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5379,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[102] /* (set! *hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5450,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[103]+1 /* (set! hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5516,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[104]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5528,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[105]+1 /* (set! hash-table-walk ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5540,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[106]+1 /* (set! hash-table-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5552,tmp=(C_word)a,a+=2,tmp));
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5575,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5577,tmp=(C_word)a,a+=2,tmp);
/* srfi-69.scm: 1095 ##sys#register-record-printer */
t27=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t25,lf[29],t26);}

/* a5576 in k4571 in k1500 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5577,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5581,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1098 ##sys#print */
t5=*((C_word*)lf[107]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[109],C_SCHEME_FALSE,t3);}

/* k5579 in a5576 in k4571 in k1500 */
static void C_ccall f_5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
/* srfi-69.scm: 1099 ##sys#print */
t4=*((C_word*)lf[107]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k5582 in k5579 in a5576 in k4571 in k1500 */
static void C_ccall f_5584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1100 ##sys#print */
t2=*((C_word*)lf[107]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[108],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5573 in k4571 in k1500 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* hash-table-map in k4571 in k1500 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5552,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[106]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5559,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1089 ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[106]);}

/* k5557 in hash-table-map in k4571 in k1500 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5564,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 1090 *hash-table-fold */
f_5450(((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a5563 in k5557 in hash-table-map in k4571 in k1500 */
static void C_ccall f_5564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5564,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5572,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1090 func */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k5570 in a5563 in k5557 in hash-table-map in k4571 in k1500 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5572,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k4571 in k1500 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5540,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[105]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5547,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1084 ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[105]);}

/* k5545 in hash-table-walk in k4571 in k1500 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1085 *hash-table-for-each */
f_5379(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k4571 in k1500 */
static void C_ccall f_5528(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5528,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[104]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5535,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1079 ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[104]);}

/* k5533 in hash-table-for-each in k4571 in k1500 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1080 *hash-table-for-each */
f_5379(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k4571 in k1500 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5516,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[29],lf[103]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5523,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 1074 ##sys#check-closure */
t7=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[103]);}

/* k5521 in hash-table-fold in k4571 in k1500 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1075 *hash-table-fold */
f_5450(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-fold in k4571 in k1500 */
static void C_fcall f_5450(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5450,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5462,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5462(t10,t1,C_fix(0),t4);}

/* loop in *hash-table-fold in k4571 in k1500 */
static void C_fcall f_5462(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5462,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5478,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5478(t8,t1,t4,t3);}}

/* fold2 in loop in *hash-table-fold in k4571 in k1500 */
static void C_fcall f_5478(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5478,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 1067 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5462(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5506,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 1070 func */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t6,t7,t8,t3);}}

/* k5504 in fold2 in loop in *hash-table-fold in k4571 in k1500 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1069 fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5478(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* *hash-table-for-each in k4571 in k1500 */
static void C_fcall f_5379(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5379,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5391,a[2]=t3,a[3]=t4,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5391(t9,t1,C_fix(0));}

/* doloop1370 in *hash-table-for-each in k4571 in k1500 */
static void C_fcall f_5391(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5391,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5401,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5414,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5414(t8,t3,t4);}}

/* loop1377 in doloop1370 in *hash-table-for-each in k4571 in k1500 */
static void C_fcall f_5414(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5414,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5422,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5437,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g13841385 */
t6=t3;
f_5422(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5435 in loop1377 in doloop1370 in *hash-table-for-each in k4571 in k1500 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5414(t3,((C_word*)t0)[2],t2);}

/* g1384 in loop1377 in doloop1370 in *hash-table-for-each in k4571 in k1500 */
static void C_fcall f_5422(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5422,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 1055 proc */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k5399 in doloop1370 in *hash-table-for-each in k4571 in k1500 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5391(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k4571 in k1500 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5314,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[100]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5329,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_5329(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k4571 in k1500 */
static void C_fcall f_5329(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5329,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5345,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5345(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k4571 in k1500 */
static void C_fcall f_5345(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5345,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1037 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5329(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1038 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k4571 in k1500 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5249,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[99]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5264,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_5264(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k4571 in k1500 */
static void C_fcall f_5264(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5264,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5280,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5280(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k4571 in k1500 */
static void C_fcall f_5280(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5280,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1022 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5264(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1023 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k4571 in k1500 */
static void C_ccall f_5198(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5198r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5198r(t0,t1,t2,t3);}}

static void C_ccall f_5198r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_list_2(t2,lf[98]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5205,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,((C_word*)t0)[2],t3);}

/* k5203 in alist->hash-table in k4571 in k1500 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5208,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5210,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5210(t6,t2,((C_word*)t0)[2]);}

/* loop1319 in k5203 in alist->hash-table in k4571 in k1500 */
static void C_fcall f_5210(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5210,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5218,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5236,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g13261327 */
t6=t3;
f_5218(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5234 in loop1319 in k5203 in alist->hash-table in k4571 in k1500 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5210(t3,((C_word*)t0)[2],t2);}

/* g1326 in loop1319 in k5203 in alist->hash-table in k4571 in k1500 */
static void C_fcall f_5218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5218,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[98]);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 1006 *hash-table-update!/default */
t6=lf[83];
f_4149(t6,t1,((C_word*)t0)[2],t4,*((C_word*)lf[82]+1),t5);}

/* k5206 in k5203 in alist->hash-table in k4571 in k1500 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k4571 in k1500 */
static void C_ccall f_5125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5125,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[97]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5140,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_5140(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k4571 in k1500 */
static void C_fcall f_5140(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5140,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5156,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5156(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k4571 in k1500 */
static void C_fcall f_5156(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5156,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 993  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5140(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm: 994  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k4571 in k1500 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5109,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[96]);
t5=(C_word)C_i_check_structure_2(t3,lf[29],lf[96]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5123,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 979  *hash-table-copy */
t7=lf[76];
f_3736(t7,t6,t2);}

/* k5121 in hash-table-merge in k4571 in k1500 */
static void C_ccall f_5123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 979  *hash-table-merge! */
f_5032(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k4571 in k1500 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5097,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[95]);
t5=(C_word)C_i_check_structure_2(t3,lf[29],lf[95]);
/* srfi-69.scm: 974  *hash-table-merge! */
f_5032(t1,t2,t3);}

/* *hash-table-merge! in k4571 in k1500 */
static void C_fcall f_5032(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5032,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5044,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5044(t9,t1,C_fix(0));}

/* doloop1273 in *hash-table-merge! in k4571 in k1500 */
static void C_fcall f_5044(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5044,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=((C_word*)t0)[4];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5054,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[4],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5067(t8,t3,t4);}}

/* doloop1278 in doloop1273 in *hash-table-merge! in k4571 in k1500 */
static void C_fcall f_5067(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5067,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5080,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 969  *hash-table-update!/default */
t7=lf[83];
f_4149(t7,t4,((C_word*)t0)[2],t5,*((C_word*)lf[82]+1),t6);}}

/* k5078 in doloop1278 in doloop1273 in *hash-table-merge! in k4571 in k1500 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5067(t3,((C_word*)t0)[2],t2);}

/* k5052 in doloop1273 in *hash-table-merge! in k4571 in k1500 */
static void C_ccall f_5054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5044(t3,((C_word*)t0)[2],t2);}

/* hash-table-clear! in k4571 in k1500 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5016,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[92]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5023,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 956  vector-fill! */
t6=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k5021 in hash-table-clear! in k4571 in k1500 */
static void C_ccall f_5023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_fix(0)));}

/* hash-table-remove! in k4571 in k1500 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4920,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[91]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4927,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 933  ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[91]);}

/* k4925 in hash-table-remove! in k4571 in k1500 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4941,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_4941(t10,((C_word*)t0)[2],C_fix(0));}

/* doloop1244 in k4925 in hash-table-remove! in k4571 in k1500 */
static void C_fcall f_4941(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4941,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4954,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_4967(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in doloop1244 in k4925 in hash-table-remove! in k4571 in k1500 */
static void C_fcall f_4967(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4967,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4986,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 943  func */
t9=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}}

/* k4984 in loop in doloop1244 in k4925 in hash-table-remove! in k4571 in k1500 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 950  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4967(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k4952 in doloop1244 in k4925 in hash-table-remove! in k4571 in k1500 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4941(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k4571 in k1500 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4789,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[90]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4805,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 897  hash */
t9=t7;
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t3,t6);}

/* k4803 in hash-table-delete! in k4571 in k1500 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4805,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[5],t1);
t6=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4825,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_4825(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4872,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_4872(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k4803 in hash-table-delete! in k4571 in k1500 */
static void C_fcall f_4872(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4872,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4891,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
/* srfi-69.scm: 920  test */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k4889 in loop in k4803 in hash-table-delete! in k4571 in k1500 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):(C_word)C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 927  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4872(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k4803 in hash-table-delete! in k4571 in k1500 */
static C_word C_fcall f_4825(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?(C_word)C_i_setslot(t1,C_fix(1),t4):(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k4571 in k1500 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4681,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[29],lf[89]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(3));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4697,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_block_size(t5);
/* srfi-69.scm: 873  hash */
t10=t7;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t3,t9);}

/* k4695 in hash-table-exists? in k4571 in k1500 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4697,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4712(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4752(t7,((C_word*)t0)[2],t3);}}

/* loop in k4695 in hash-table-exists? in k4571 in k1500 */
static void C_fcall f_4752(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4752,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4765,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 885  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4763 in loop in k4695 in hash-table-exists? in k4571 in k1500 */
static void C_ccall f_4765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 886  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4752(t3,((C_word*)t0)[4],t2);}}

/* loop in k4695 in hash-table-exists? in k4571 in k1500 */
static C_word C_fcall f_4712(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-ref/default in k4571 in k1500 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4575,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[29],lf[88]);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(3));
t8=(C_word)C_slot(t2,C_fix(4));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4591,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t6,a[6]=t7,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_block_size(t6);
/* srfi-69.scm: 847  hash */
t11=t8;
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t3,t10);}

/* k4589 in hash-table-ref/default in k4571 in k1500 */
static void C_ccall f_4591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4591,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4606(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4645(t7,((C_word*)t0)[2],t3);}}

/* loop in k4589 in hash-table-ref/default in k4571 in k1500 */
static void C_fcall f_4645(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4645,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[5];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4661,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 862  test */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4659 in loop in k4589 in hash-table-ref/default in k4571 in k1500 */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 864  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4645(t3,((C_word*)t0)[5],t2);}}

/* loop in k4589 in hash-table-ref/default in k4571 in k1500 */
static C_word C_fcall f_4606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[3];
return(t2);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return((C_word)C_slot(t2,C_fix(1)));}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t8=t5;
t1=t8;
goto loop;}}}

/* hash-table-set! in k1500 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4373,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[29],lf[85]);
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_fixnum_plus(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4440,a[2]=t7,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_slot(t9,C_fix(5));
t12=(C_word)C_slot(t9,C_fix(6));
t13=(C_word)C_block_size(t10);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4433,a[2]=t12,a[3]=t7,a[4]=t13,a[5]=t10,a[6]=t9,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t15=(C_word)C_a_i_times(&a,2,t13,t11);
/* srfi-69.scm: 637  floor */
t16=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t14,t15);}

/* k4431 in hash-table-set! in k1500 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4433,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm: 638  floor */
t5=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4423 in k4431 in hash-table-set! in k1500 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4425,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t4=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t5=t3;
f_4406(t5,(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t2):C_SCHEME_FALSE));}
else{
t4=t3;
f_4406(t4,C_SCHEME_FALSE);}}

/* k4404 in k4423 in k4431 in hash-table-set! in k1500 */
static void C_fcall f_4406(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 641  hash-table-resize! */
t2=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_4440(2,t3,t2);}}

/* k4438 in hash-table-set! in k1500 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4440,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 781  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],t5);}

/* k4453 in k4438 in hash-table-set! in k1500 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4455,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4461,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4472,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_4472(t8,t3,t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp));
t8=((C_word*)t6)[1];
f_4521(t8,t3,t2);}}

/* loop in k4453 in k4438 in hash-table-set! in k1500 */
static void C_fcall f_4521(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4521,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4551,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 801  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[10],t5);}}

/* k4549 in loop in k4453 in k4438 in hash-table-set! in k1500 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 803  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4521(t3,((C_word*)t0)[6],t2);}}

/* loop in k4453 in k4438 in hash-table-set! in k1500 */
static void C_fcall f_4472(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4472,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[7]);
t5=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[9],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(t3,C_fix(1),((C_word*)t0)[8]));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 793  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4459 in k4453 in k4438 in hash-table-set! in k1500 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[86]+1));}

/* hash-table-update!/default in k1500 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4361,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_structure_2(t2,lf[29],lf[84]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4368,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 768  ##sys#check-closure */
t8=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[84]);}

/* k4366 in hash-table-update!/default in k1500 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 769  *hash-table-update!/default */
t2=lf[83];
f_4149(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-update!/default in k1500 */
static void C_fcall f_4149(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4149,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_fixnum_plus(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4213,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t7,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t9=t2;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_slot(t9,C_fix(5));
t12=(C_word)C_slot(t9,C_fix(6));
t13=(C_word)C_block_size(t10);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4206,a[2]=t12,a[3]=t7,a[4]=t13,a[5]=t10,a[6]=t9,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t15=(C_word)C_a_i_times(&a,2,t13,t11);
/* srfi-69.scm: 637  floor */
t16=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t14,t15);}

/* k4204 in *hash-table-update!/default in k1500 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4198,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm: 638  floor */
t5=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4196 in k4204 in *hash-table-update!/default in k1500 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4179,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t4=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t5=t3;
f_4179(t5,(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t2):C_SCHEME_FALSE));}
else{
t4=t3;
f_4179(t4,C_SCHEME_FALSE);}}

/* k4177 in k4196 in k4204 in *hash-table-update!/default in k1500 */
static void C_fcall f_4179(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 641  hash-table-resize! */
t2=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_4213(2,t3,t2);}}

/* k4211 in *hash-table-update!/default in k1500 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4213,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 736  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k4226 in k4211 in *hash-table-update!/default in k1500 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4228,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4242,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_4242(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4301,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4301(t7,((C_word*)t0)[2],t2);}}

/* loop in k4226 in k4211 in *hash-table-update!/default in k1500 */
static void C_fcall f_4301(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4301,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4311,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 755  func */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 760  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4332 in loop in k4226 in k4211 in *hash-table-update!/default in k1500 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 761  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 764  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4301(t3,((C_word*)t0)[5],t2);}}

/* k4335 in k4332 in loop in k4226 in k4211 in *hash-table-update!/default in k1500 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4309 in loop in k4226 in k4211 in *hash-table-update!/default in k1500 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4311,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* loop in k4226 in k4211 in *hash-table-update!/default in k1500 */
static void C_fcall f_4242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4242,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4252,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 742  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4278,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 748  func */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 751  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4276 in loop in k4226 in k4211 in *hash-table-update!/default in k1500 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4250 in loop in k4226 in k4211 in *hash-table-update!/default in k1500 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4252,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* hash-table-update! in k1500 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3857r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3857r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3857r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3859,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4087,a[2]=t3,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4104,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-func9681029 */
t8=t7;
f_4104(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-thunk9691021 */
t10=t6;
f_4087(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body966974 */
t12=t5;
f_3859(t12,t1,t8,t10);}}}

/* def-func968 in hash-table-update! in k1500 */
static void C_fcall f_4104(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4104,NULL,2,t0,t1);}
/* def-thunk9691021 */
t2=((C_word*)t0)[2];
f_4087(t2,t1,*((C_word*)lf[82]+1));}

/* def-thunk969 in hash-table-update! in k1500 */
static void C_fcall f_4087(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4087,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(9));
if(C_truep(t3)){
/* body966974 */
t4=((C_word*)t0)[3];
f_3859(t4,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* body966974 */
t5=((C_word*)t0)[3];
f_3859(t5,t1,t2,t4);}}

/* f_4099 in def-thunk969 in hash-table-update! in k1500 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4099,2,t0,t1);}
/* srfi-69.scm: 685  ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[80],lf[78],lf[81],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body966 in hash-table-update! in k1500 */
static void C_fcall f_3859(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3859,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[4],lf[29],lf[78]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3866,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 689  ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[78]);}

/* k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 690  ##sys#check-closure */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[78]);}

/* k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_3869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3869,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(2));
t3=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[7];
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_slot(t5,C_fix(5));
t8=(C_word)C_slot(t5,C_fix(6));
t9=(C_word)C_block_size(t6);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3925,a[2]=t8,a[3]=t3,a[4]=t9,a[5]=t6,a[6]=t5,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t11=(C_word)C_a_i_times(&a,2,t9,t7);
/* srfi-69.scm: 637  floor */
t12=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}

/* k3923 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3925,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm: 638  floor */
t5=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3915 in k3923 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3917,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3898,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t4=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t5=t3;
f_3898(t5,(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t2):C_SCHEME_FALSE));}
else{
t4=t3;
f_3898(t4,C_SCHEME_FALSE);}}

/* k3896 in k3915 in k3923 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_fcall f_3898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 641  hash-table-resize! */
t2=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3932(2,t3,t2);}}

/* k3930 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3932,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 697  hash */
t7=t2;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k3945 in k3930 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3961,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3961(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4024,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4024(t7,((C_word*)t0)[2],t2);}}

/* loop in k3945 in k3930 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_fcall f_4024(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4024,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4034,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4052,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 716  thunk */
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4061,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 721  test */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4059 in loop in k3945 in k3930 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4061,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 722  func */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 725  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4024(t3,((C_word*)t0)[5],t2);}}

/* k4062 in k4059 in loop in k3945 in k3930 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4050 in loop in k3945 in k3930 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 716  func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4032 in loop in k3945 in k3930 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* loop in k3945 in k3930 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_fcall f_3961(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3961,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3971,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3989,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 703  thunk */
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4001,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 709  func */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 712  loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k3999 in loop in k3945 in k3930 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k3987 in loop in k3945 in k3930 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 703  func */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3969 in loop in k3945 in k3930 in k3867 in k3864 in body966 in hash-table-update! in k1500 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* hash-table-copy in k1500 */
static void C_ccall f_3848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3848,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[77]);
/* srfi-69.scm: 670  *hash-table-copy */
t4=lf[76];
f_3736(t4,t1,t2);}

/* *hash-table-copy in k1500 */
static void C_fcall f_3736(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3736,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3746,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 650  make-vector */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k3744 in *hash-table-copy in k1500 */
static void C_ccall f_3746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3746,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3751,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3751(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop937 in k3744 in *hash-table-copy in k1500 */
static void C_fcall f_3751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3751,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(6));
t8=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t9=(C_word)C_slot(((C_word*)t0)[5],C_fix(8));
t10=(C_word)C_slot(((C_word*)t0)[5],C_fix(9));
/* srfi-69.scm: 653  *make-hash-table */
t11=lf[28];
f_3148(t11,t1,t3,t4,t5,t6,t7,t10,(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3807,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3813,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3813(t8,t3,t4);}}

/* copy-loop in doloop937 in k3744 in *hash-table-copy in k1500 */
static void C_fcall f_3813(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3813,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3834,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 666  copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k3832 in copy-loop in doloop937 in k3744 in *hash-table-copy in k1500 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3834,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3805 in doloop937 in k3744 in *hash-table-copy in k1500 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3751(t4,((C_word*)t0)[2],t3);}

/* hash-table-resize! in k1500 */
static void C_ccall f_3710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3710,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_times(t4,C_fix(2));
t6=(C_word)C_i_fixnum_min(C_fix(1073741823),t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3717,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 625  hash-table-canonical-length */
f_3118(t7,lf[24],t6);}

/* k3715 in hash-table-resize! in k1500 */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 626  make-vector */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_SCHEME_END_OF_LIST);}

/* k3718 in k3715 in hash-table-resize! in k1500 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3723,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t5);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3643,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t9,a[7]=t6,tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_3643(t11,t2,C_fix(0));}

/* doloop904 in k3718 in k3715 in hash-table-resize! in k1500 */
static void C_fcall f_3643(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3643,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3653,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3666(t8,t3,t4);}}

/* loop in doloop904 in k3718 in k3715 in hash-table-resize! in k1500 */
static void C_fcall f_3666(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3666,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3682,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 616  hash */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k3680 in loop in doloop904 in k3718 in k3715 in hash-table-resize! in k1500 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 619  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3666(t8,((C_word*)t0)[2],t7);}

/* k3651 in doloop904 in k3718 in k3715 in hash-table-resize! in k1500 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3643(t3,((C_word*)t0)[2],t2);}

/* k3721 in k3718 in k3715 in hash-table-resize! in k1500 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]));}

/* hash-table-initial in k1500 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3616,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[74]);
t4=(C_word)C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm: 603  thunk */
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k1500 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3604,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[73]);
t4=(C_word)C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k1500 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3595,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[72]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k1500 */
static void C_ccall f_3586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3586,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k1500 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3577,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[70]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k1500 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3568,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[69]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k1500 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3559,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[68]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k1500 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3550,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[67]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-size in k1500 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3541,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[66]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* hash-table? in k1500 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3535,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[29]));}

/* make-hash-table in k1500 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+41)){
C_save_and_reclaim((void*)tr2r,(void*)f_3172r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3172r(t0,t1,t2);}}

static void C_ccall f_3172r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(41);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[32]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[37];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[38];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3250,a[2]=t4,a[3]=t2,a[4]=t17,a[5]=t12,a[6]=t16,a[7]=t14,a[8]=t6,a[9]=t1,a[10]=t8,a[11]=t10,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t4)[1]))){
t19=t18;
f_3250(t19,C_SCHEME_UNDEFINED);}
else{
t19=(C_word)C_u_i_car(((C_word*)t4)[1]);
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3525,a[2]=t4,a[3]=t19,a[4]=t6,a[5]=t18,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 482  keyword? */
t21=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t21+1)))(3,t21,t20,t19);}}

/* k3523 in make-hash-table in k1500 */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3525,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3250(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3528,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 483  ##sys#check-closure */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[36]);}}

/* k3526 in k3523 in make-hash-table in k1500 */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3250(t5,t4);}

/* k3248 in make-hash-table in k1500 */
static void C_fcall f_3250(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3250,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3253(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 488  keyword? */
t5=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k3503 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3505,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3253(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 489  ##sys#check-closure */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[36]);}}

/* k3506 in k3503 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3253(t5,t4);}

/* k3251 in k3248 in make-hash-table in k1500 */
static void C_fcall f_3253(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3253,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3256(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 494  keyword? */
t5=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k3471 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3473,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3256(t3,t2);}
else{
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[36]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3479,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_3479(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 497  error */
t4=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[36],lf[64],((C_word*)t0)[4]);}}}

/* k3477 in k3471 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[47]+1),((C_word*)t0)[5]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_3256(t6,t5);}

/* k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_fcall f_3256(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3256,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[8],a[8]=t4,a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3291(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_fcall f_3291(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3291,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[9],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3312,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* srfi-69.scm: 507  keyword? */
t6=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k3310 in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3312,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[12],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=t3;
f_3318(2,t4,(C_word)C_u_i_car(t2));}
else{
/* srfi-69.scm: 511  invarg-err */
t4=((C_word*)t0)[2];
f_3302(t4,t3,lf[62]);}}
else{
/* srfi-69.scm: 543  invarg-err */
t2=((C_word*)t0)[2];
f_3302(t2,((C_word*)t0)[10],lf[63]);}}

/* k3316 in k3310 in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3321,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[43]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 514  ##sys#check-closure */
t5=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,lf[36]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[45]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 517  ##sys#check-closure */
t6=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[36]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[46]);
if(C_truep(t5)){
t6=(C_word)C_i_check_exact_2(t1,lf[36]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3357,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_3357(2,t8,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 522  error */
t8=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[36],lf[48],t1);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[49]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3375,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t8=(C_word)C_slot(((C_word*)t0)[12],C_fix(1));
/* srfi-69.scm: 542  loop */
t9=((C_word*)((C_word*)t0)[11])[1];
f_3291(t9,((C_word*)t0)[10],t8);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[50]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3385,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 527  ##sys#check-inexact */
t9=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t1,lf[36]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[55]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3410,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 532  ##sys#check-inexact */
t10=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t1,lf[36]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[59]);
if(C_truep(t9)){
if(C_truep(t1)){
t10=(C_word)C_slot(((C_word*)t0)[12],C_fix(1));
/* srfi-69.scm: 542  loop */
t11=((C_word*)((C_word*)t0)[11])[1];
f_3291(t11,((C_word*)t0)[10],t10);}
else{
t10=(C_word)C_slot(((C_word*)t0)[12],C_fix(1));
/* srfi-69.scm: 542  loop */
t11=((C_word*)((C_word*)t0)[11])[1];
f_3291(t11,((C_word*)t0)[10],t10);}}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[60]);
if(C_truep(t10)){
if(C_truep(t1)){
t11=(C_word)C_slot(((C_word*)t0)[12],C_fix(1));
/* srfi-69.scm: 542  loop */
t12=((C_word*)((C_word*)t0)[11])[1];
f_3291(t12,((C_word*)t0)[10],t11);}
else{
t11=(C_word)C_slot(((C_word*)t0)[12],C_fix(1));
/* srfi-69.scm: 542  loop */
t12=((C_word*)((C_word*)t0)[11])[1];
f_3291(t12,((C_word*)t0)[10],t11);}}
else{
/* srfi-69.scm: 541  invarg-err */
t11=((C_word*)t0)[2];
f_3302(t11,t2,lf[61]);}}}}}}}}}

/* k3408 in k3316 in k3310 in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_flonum_lessp(lf[56],((C_word*)t0)[5]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[5],lf[57]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t6=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 542  loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_3291(t7,((C_word*)t0)[2],t6);}
else{
/* srfi-69.scm: 534  error */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[36],lf[58],((C_word*)t0)[5]);}}

/* k3411 in k3408 in k3316 in k3310 in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 542  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3291(t4,((C_word*)t0)[2],t3);}

/* k3383 in k3316 in k3310 in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_flonum_lessp(lf[51],((C_word*)t0)[5]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[5],lf[52]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t6=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 542  loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_3291(t7,((C_word*)t0)[2],t6);}
else{
/* srfi-69.scm: 529  error */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[36],lf[53],((C_word*)t0)[5]);}}

/* k3386 in k3383 in k3316 in k3310 in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 542  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3291(t4,((C_word*)t0)[2],t3);}

/* f_3375 in k3316 in k3310 in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3355 in k3316 in k3310 in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[47]+1),((C_word*)t0)[6]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 542  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3291(t5,((C_word*)t0)[2],t4);}

/* k3342 in k3316 in k3310 in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 542  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3291(t4,((C_word*)t0)[2],t3);}

/* k3332 in k3316 in k3310 in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 542  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3291(t4,((C_word*)t0)[2],t3);}

/* k3319 in k3316 in k3310 in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 542  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3291(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_fcall f_3302(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3302,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 506  error */
t3=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[36],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3257 in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_flonum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* srfi-69.scm: 546  error */
t3=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[36],lf[42],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_3262(2,t3,C_SCHEME_UNDEFINED);}}

/* k3260 in k3257 in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 548  hash-table-canonical-length */
f_3118(t2,lf[24],((C_word*)((C_word*)t0)[9])[1]);}

/* k3264 in k3260 in k3257 in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3266,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
/* srfi-69.scm: 558  *make-hash-table */
t3=lf[28];
f_3148(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);}
else{
t3=f_3174(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=C_mutate(((C_word *)((C_word*)t0)[8])+1,t3);
/* srfi-69.scm: 558  *make-hash-table */
t5=lf[28];
f_3148(t5,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 555  warning */
t5=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[36],lf[40]);}}}

/* k3280 in k3264 in k3260 in k3257 in k3254 in k3251 in k3248 in make-hash-table in k1500 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[17]+1));
/* srfi-69.scm: 558  *make-hash-table */
t3=lf[28];
f_3148(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* hash-for-test in make-hash-table in k1500 */
static C_word C_fcall f_3174(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
t1=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:(C_word)C_eqp(*((C_word*)lf[30]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
t3=*((C_word*)lf[13]+1);
return(t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(*((C_word*)lf[31]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
return(*((C_word*)lf[15]+1));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(*((C_word*)lf[32]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
t7=*((C_word*)lf[17]+1);
return(t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(*((C_word*)lf[33]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
return(*((C_word*)lf[19]+1));}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(*((C_word*)lf[34]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
t11=*((C_word*)lf[23]+1);
return(t11);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t11)){
return((C_truep(t11)?*((C_word*)lf[2]+1):C_SCHEME_FALSE));}
else{
t12=(C_word)C_eqp(*((C_word*)lf[35]+1),((C_word*)((C_word*)t0)[7])[1]);
return((C_truep(t12)?*((C_word*)lf[2]+1):C_SCHEME_FALSE));}}}}}}}

/* *make-hash-table in k1500 */
static void C_fcall f_3148(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3148,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3152,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
/* srfi-69.scm: 430  make-vector */
t10=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t4,C_SCHEME_END_OF_LIST);}
else{
t10=t9;
f_3152(2,t10,(C_word)C_u_i_car(t8));}}

/* k3150 in *make-hash-table in k1500 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3152,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,10,lf[29],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* hash-table-canonical-length in k1500 */
static void C_fcall f_3118(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3118,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3124,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3124(t4,t2));}

/* loop in hash-table-canonical-length in k1500 */
static C_word C_fcall f_3124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
if(C_truep(t4)){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}}

/* string-ci-hash in k1500 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_2978r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2978r(t0,t1,t2,t3);}}

static void C_ccall f_2978r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(14);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_check_string_2(t2,lf[22]);
t9=(C_word)C_i_check_exact_2(t5,lf[22]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2994,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3031,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3050,a[2]=t11,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3059,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-start654667 */
t14=t13;
f_3059(t14,t10);}
else{
t14=(C_word)C_u_i_car(t7);
t15=(C_word)C_slot(t7,C_fix(1));
if(C_truep((C_word)C_i_nullp(t15))){
/* def-end655665 */
t16=t12;
f_3050(t16,t10,t14);}
else{
t16=(C_word)C_u_i_car(t15);
t17=(C_word)C_slot(t15,C_fix(1));
/* body652660 */
t18=t11;
f_3031(t18,t10,t14,t16);}}}
else{
t11=t10;
f_2994(2,t11,t2);}}

/* def-start654 in string-ci-hash in k1500 */
static void C_fcall f_3059(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3059,NULL,2,t0,t1);}
/* def-end655665 */
t2=((C_word*)t0)[2];
f_3050(t2,t1,C_fix(0));}

/* def-end655 in string-ci-hash in k1500 */
static void C_fcall f_3050(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3050,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(((C_word*)t0)[3]);
/* body652660 */
t4=((C_word*)t0)[2];
f_3031(t4,t1,t2,t3);}

/* body652 in string-ci-hash in k1500 */
static void C_fcall f_3031(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3031,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3035,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 378  ##sys#check-range */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t2,C_fix(0),t5,lf[23]);}

/* k3033 in body652 in string-ci-hash in k1500 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3038,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 379  ##sys#check-range */
t4=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[2],C_fix(0),t3,lf[23]);}

/* k3036 in k3033 in body652 in string-ci-hash in k1500 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 380  ##sys#substring */
t2=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2992 in string-ci-hash in k1500 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_hash_string_ci(t1);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(C_word)C_u_fixnum_negate(t2);
t5=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_modulo(t5,((C_word*)t0)[2]));}
else{
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t2);
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}}

/* string-hash in k1500 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_2840r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2840r(t0,t1,t2,t3);}}

static void C_ccall f_2840r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(14);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_check_string_2(t2,lf[19]);
t9=(C_word)C_i_check_exact_2(t5,lf[19]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2856,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2912,a[2]=t11,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2921,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-start594607 */
t14=t13;
f_2921(t14,t10);}
else{
t14=(C_word)C_u_i_car(t7);
t15=(C_word)C_slot(t7,C_fix(1));
if(C_truep((C_word)C_i_nullp(t15))){
/* def-end595605 */
t16=t12;
f_2912(t16,t10,t14);}
else{
t16=(C_word)C_u_i_car(t15);
t17=(C_word)C_slot(t15,C_fix(1));
/* body592600 */
t18=t11;
f_2893(t18,t10,t14,t16);}}}
else{
t11=t10;
f_2856(2,t11,t2);}}

/* def-start594 in string-hash in k1500 */
static void C_fcall f_2921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2921,NULL,2,t0,t1);}
/* def-end595605 */
t2=((C_word*)t0)[2];
f_2912(t2,t1,C_fix(0));}

/* def-end595 in string-hash in k1500 */
static void C_fcall f_2912(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2912,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(((C_word*)t0)[3]);
/* body592600 */
t4=((C_word*)t0)[2];
f_2893(t4,t1,t2,t3);}

/* body592 in string-hash in k1500 */
static void C_fcall f_2893(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2893,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2897,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 366  ##sys#check-range */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t2,C_fix(0),t5,lf[19]);}

/* k2895 in body592 in string-hash in k1500 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 367  ##sys#check-range */
t4=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[2],C_fix(0),t3,lf[19]);}

/* k2898 in k2895 in body592 in string-hash in k1500 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 368  ##sys#substring */
t2=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2854 in string-hash in k1500 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_hash_string(t1);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(C_word)C_u_fixnum_negate(t2);
t5=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_modulo(t5,((C_word*)t0)[2]));}
else{
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t2);
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}}

/* equal?-hash in k1500 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2787r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2787r(t0,t1,t2,t3);}}

static void C_ccall f_2787r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[18]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2825,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 354  *equal?-hash */
f_2321(t7,t2);}

/* k2823 in equal?-hash in k1500 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_u_fixnum_negate(t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}
else{
t3=t1;
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}}

/* *equal?-hash in k1500 */
static void C_fcall f_2321(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2321,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2324,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2389,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2440,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
/* srfi-69.scm: 350  recursive-hash */
t12=((C_word*)t8)[1];
f_2440(t12,t1,t2,C_fix(0));}

/* recursive-hash in *equal?-hash in k1500 */
static void C_fcall f_2440(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2440,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t1;
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t4;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_hash_string(t6));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t4=t1;
t5=t2;
if(C_truep((C_word)C_i_flonump(t5))){
t6=(C_word)C_subbyte(t5,C_fix(7));
t7=(C_word)C_subbyte(t5,C_fix(6));
t8=(C_word)C_subbyte(t5,C_fix(5));
t9=(C_word)C_subbyte(t5,C_fix(4));
t10=(C_word)C_subbyte(t5,C_fix(3));
t11=(C_word)C_subbyte(t5,C_fix(2));
t12=(C_word)C_subbyte(t5,C_fix(1));
t13=(C_word)C_subbyte(t5,C_fix(0));
t14=(C_word)C_fixnum_shift_left(t13,C_fix(1));
t15=(C_word)C_u_fixnum_plus(t12,t14);
t16=(C_word)C_fixnum_shift_left(t15,C_fix(1));
t17=(C_word)C_u_fixnum_plus(t11,t16);
t18=(C_word)C_fixnum_shift_left(t17,C_fix(1));
t19=(C_word)C_u_fixnum_plus(t10,t18);
t20=(C_word)C_fixnum_shift_left(t19,C_fix(1));
t21=(C_word)C_u_fixnum_plus(t9,t20);
t22=(C_word)C_fixnum_shift_left(t21,C_fix(1));
t23=(C_word)C_u_fixnum_plus(t8,t22);
t24=(C_word)C_fixnum_shift_left(t23,C_fix(1));
t25=(C_word)C_u_fixnum_plus(t7,t24);
t26=(C_word)C_fixnum_shift_left(t25,C_fix(1));
t27=(C_word)C_u_fixnum_plus(t6,t26);
t28=t4;
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,(C_word)C_fixnum_times(C_fix(331804471),t27));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2636,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 166  ##sys#number-hash-hook */
t7=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}}
else{
t4=t2;
if(C_truep((C_word)C_blockp(t4))){
t5=t2;
if(C_truep((C_word)C_byteblockp(t5))){
t6=t1;
t7=t2;
t8=t6;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_hash_string(t7));}
else{
if(C_truep((C_word)C_i_listp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2670,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* g518519 */
t7=t6;
f_2670(t7,t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2696,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* g521522 */
t7=t6;
f_2696(t7,t1,t2);}
else{
t6=t2;
if(C_truep((C_word)C_portp(t6))){
t7=t1;
t8=t2;
t9=(C_word)C_peek_fixnum(t8,C_fix(0));
t10=(C_word)C_fixnum_shift_left(t9,C_fix(4));
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2747,a[2]=t10,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 294  input-port? */
t12=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t8);}
else{
t7=t2;
if(C_truep((C_word)C_specialp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2763,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* g533534 */
t9=t8;
f_2763(t9,t1,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2775,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* g536537 */
t9=t8;
f_2775(t9,t1,t2);}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(262));}}}}}}}}}}

/* g536 in recursive-hash in *equal?-hash in k1500 */
static void C_fcall f_2775(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2775,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 302  vector-hash */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2324(t3,t1,t2,C_fix(0),((C_word*)t0)[2],C_fix(0));}

/* g533 in recursive-hash in *equal?-hash in k1500 */
static void C_fcall f_2763(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2763,NULL,3,t0,t1,t2);}
t3=(C_word)C_peek_fixnum(t2,C_fix(0));
/* srfi-69.scm: 299  vector-hash */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2324(t4,t1,t2,t3,((C_word*)t0)[2],C_fix(1));}

/* k2745 in recursive-hash in *equal?-hash in k1500 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(260)):(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(261))));}

/* g521 in recursive-hash in *equal?-hash in k1500 */
static void C_fcall f_2696(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2696,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* srfi-69.scm: 289  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2389(t5,t3,t4,((C_word*)t0)[2]);}

/* k2714 in g521 in recursive-hash in *equal?-hash in k1500 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2716,2,t0,t1);}
t2=(C_word)C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2708,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 290  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2389(t5,t3,t4,((C_word*)t0)[2]);}

/* k2706 in k2714 in g521 in recursive-hash in *equal?-hash in k1500 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* g518 in recursive-hash in *equal?-hash in k1500 */
static void C_fcall f_2670(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2670,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2682,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* srfi-69.scm: 286  recursive-atomic-hash */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2389(t6,t4,t5,((C_word*)t0)[2]);}

/* k2680 in g518 in recursive-hash in *equal?-hash in k1500 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2634 in recursive-hash in *equal?-hash in k1500 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix(t1));}

/* recursive-atomic-hash in *equal?-hash in k1500 */
static void C_fcall f_2389(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2389,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2423,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=t2;
t6=(C_word)C_i_not((C_word)C_blockp(t5));
if(C_truep(t6)){
t7=t4;
f_2423(t7,(C_truep(t6)?t6:(C_word)C_i_numberp(t5)));}
else{
t7=(C_word)C_i_symbolp(t5);
t8=t4;
f_2423(t8,(C_truep(t7)?t7:(C_word)C_i_numberp(t5)));}}

/* k2421 in recursive-atomic-hash in *equal?-hash in k1500 */
static void C_fcall f_2423(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2423,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_2426(t3,t1);}
else{
t3=((C_word*)t0)[2];
t4=t2;
f_2426(t4,(C_word)C_byteblockp(t3));}}

/* k2424 in k2421 in recursive-atomic-hash in *equal?-hash in k1500 */
static void C_fcall f_2426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 324  recursive-hash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2440(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* vector-hash in *equal?-hash in k1500 */
static void C_fcall f_2324(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2324,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t2);
t7=(C_word)C_u_fixnum_plus(t6,t3);
t8=(C_word)C_i_fixnum_min(C_fix(4),t6);
t9=(C_word)C_u_fixnum_difference(t8,t5);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_2341(t13,t1,t7,t5,t9);}

/* loop in vector-hash in *equal?-hash in k1500 */
static void C_fcall f_2341(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2341,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2375,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 316  recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2440(t10,t7,t8,t9);}}

/* k2373 in loop in vector-hash in *equal?-hash in k1500 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 314  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2341(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k1500 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2269r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2269r(t0,t1,t2,t3);}}

static void C_ccall f_2269r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[15]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2307,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t8=t7;
f_2307(2,t8,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=t7;
f_2307(2,t8,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t8=t7;
f_2307(2,t8,C_fix(256));
case C_SCHEME_FALSE:
t8=t7;
f_2307(2,t8,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t8=t7;
f_2307(2,t8,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t8=t7;
f_2307(2,t8,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t7;
f_2307(2,t9,(C_word)C_hash_string(t8));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
if(C_truep((C_word)C_i_flonump(t2))){
t8=(C_word)C_subbyte(t2,C_fix(7));
t9=(C_word)C_subbyte(t2,C_fix(6));
t10=(C_word)C_subbyte(t2,C_fix(5));
t11=(C_word)C_subbyte(t2,C_fix(4));
t12=(C_word)C_subbyte(t2,C_fix(3));
t13=(C_word)C_subbyte(t2,C_fix(2));
t14=(C_word)C_subbyte(t2,C_fix(1));
t15=(C_word)C_subbyte(t2,C_fix(0));
t16=(C_word)C_fixnum_shift_left(t15,C_fix(1));
t17=(C_word)C_u_fixnum_plus(t14,t16);
t18=(C_word)C_fixnum_shift_left(t17,C_fix(1));
t19=(C_word)C_u_fixnum_plus(t13,t18);
t20=(C_word)C_fixnum_shift_left(t19,C_fix(1));
t21=(C_word)C_u_fixnum_plus(t12,t20);
t22=(C_word)C_fixnum_shift_left(t21,C_fix(1));
t23=(C_word)C_u_fixnum_plus(t11,t22);
t24=(C_word)C_fixnum_shift_left(t23,C_fix(1));
t25=(C_word)C_u_fixnum_plus(t10,t24);
t26=(C_word)C_fixnum_shift_left(t25,C_fix(1));
t27=(C_word)C_u_fixnum_plus(t9,t26);
t28=(C_word)C_fixnum_shift_left(t27,C_fix(1));
t29=(C_word)C_u_fixnum_plus(t8,t28);
t30=t7;
f_2307(2,t30,(C_word)C_fixnum_times(C_fix(331804471),t29));}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2245,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 166  ##sys#number-hash-hook */
t9=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 185  *equal?-hash */
f_2321(t7,t2);}
else{
t8=t7;
f_2307(2,t8,C_fix(262));}}}}}}}}}

/* k2243 in eqv?-hash in k1500 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2307(2,t2,(C_word)C_fix(t1));}

/* k2305 in eqv?-hash in k1500 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_u_fixnum_negate(t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}
else{
t3=t1;
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}}

/* eq?-hash in k1500 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2002r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2002r(t0,t1,t2,t3);}}

static void C_ccall f_2002r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[13]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2040,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t8=t7;
f_2040(2,t8,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=t7;
f_2040(2,t8,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t8=t7;
f_2040(2,t8,C_fix(256));
case C_SCHEME_FALSE:
t8=t7;
f_2040(2,t8,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t8=t7;
f_2040(2,t8,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t8=t7;
f_2040(2,t8,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t7;
f_2040(2,t9,(C_word)C_hash_string(t8));}
else{
if(C_truep((C_word)C_blockp(t2))){
/* srfi-69.scm: 185  *equal?-hash */
f_2321(t7,t2);}
else{
t8=t7;
f_2040(2,t8,C_fix(262));}}}}}}}}

/* k2038 in eq?-hash in k1500 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_u_fixnum_negate(t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}
else{
t3=t1;
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}}

/* keyword-hash in k1500 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1855r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1855r(t0,t1,t2,t3);}}

static void C_ccall f_1855r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1862,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 221  ##sys#check-keyword */
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,lf[12]);}

/* k1860 in keyword-hash in k1500 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[12]);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_hash_string(t4);
t6=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
t7=(C_word)C_u_fixnum_negate(t5);
t8=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t7);
t9=t6;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t8,((C_word*)t0)[4]));}
else{
t7=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t5);
t8=t6;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_modulo(t7,((C_word*)t0)[4]));}}

/* ##sys#check-keyword in k1500 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1829r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1829r(t0,t1,t2,t3);}}

static void C_ccall f_1829r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1836,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 208  keyword? */
t5=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1834 in ##sys#check-keyword in k1500 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_vemptyp(((C_word*)t0)[3]))){
/* srfi-69.scm: 209  ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[9],C_SCHEME_FALSE,lf[10],((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
/* srfi-69.scm: 209  ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[9],t2,lf[10],((C_word*)t0)[2]);}}}

/* symbol-hash in k1500 */
static void C_ccall f_1763(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1763r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1763r(t0,t1,t2,t3);}}

static void C_ccall f_1763r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_symbol_2(t2,lf[7]);
t7=(C_word)C_i_check_exact_2(t5,lf[7]);
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_hash_string(t9);
if(C_truep((C_word)C_fixnum_lessp(t10,C_fix(0)))){
t11=(C_word)C_u_fixnum_negate(t10);
t12=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_fixnum_modulo(t12,t5));}
else{
t11=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_fixnum_modulo(t11,t5));}}

/* object-uid-hash in k1500 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1706r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1706r(t0,t1,t2,t3);}}

static void C_ccall f_1706r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t5,lf[6]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1749,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 185  *equal?-hash */
f_2321(t7,t2);}

/* k1747 in object-uid-hash in k1500 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_u_fixnum_negate(t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}
else{
t3=t1;
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}}

/* number-hash in k1500 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1510r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1510r(t0,t1,t2,t3);}}

static void C_ccall f_1510r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1517,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_numberp(t2))){
t7=t6;
f_1517(2,t7,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 174  ##sys#signal-hook */
t7=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[4],lf[2],lf[5],t2);}}

/* k1515 in number-hash in k1500 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1517,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
f_1686(t5,t4);}
else{
if(C_truep((C_word)C_i_flonump(t4))){
t5=(C_word)C_subbyte(t4,C_fix(7));
t6=(C_word)C_subbyte(t4,C_fix(6));
t7=(C_word)C_subbyte(t4,C_fix(5));
t8=(C_word)C_subbyte(t4,C_fix(4));
t9=(C_word)C_subbyte(t4,C_fix(3));
t10=(C_word)C_subbyte(t4,C_fix(2));
t11=(C_word)C_subbyte(t4,C_fix(1));
t12=(C_word)C_subbyte(t4,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_u_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_u_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_u_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_u_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_u_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_u_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_u_fixnum_plus(t5,t25);
t27=t3;
f_1686(t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1680,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 166  ##sys#number-hash-hook */
t6=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}}

/* k1678 in k1515 in number-hash in k1500 */
static void C_ccall f_1680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1686(t2,(C_word)C_fix(t1));}

/* k1684 in k1515 in number-hash in k1500 */
static void C_fcall f_1686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_u_fixnum_negate(t1);
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}
else{
t3=t1;
t4=(C_word)C_u_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(t4,((C_word*)t0)[2]));}}

/* ##sys#number-hash-hook in k1500 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1504,3,t0,t1,t2);}
/* srfi-69.scm: 162  *equal?-hash */
f_2321(t1,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[234] = {
{"toplevel:srfi_69_scm",(void*)C_srfi_69_toplevel},
{"f_1502:srfi_69_scm",(void*)f_1502},
{"f_5593:srfi_69_scm",(void*)f_5593},
{"f_5603:srfi_69_scm",(void*)f_5603},
{"f_5615:srfi_69_scm",(void*)f_5615},
{"f_5672:srfi_69_scm",(void*)f_5672},
{"f_5691:srfi_69_scm",(void*)f_5691},
{"f_5630:srfi_69_scm",(void*)f_5630},
{"f_5713:srfi_69_scm",(void*)f_5713},
{"f_4573:srfi_69_scm",(void*)f_4573},
{"f_5577:srfi_69_scm",(void*)f_5577},
{"f_5581:srfi_69_scm",(void*)f_5581},
{"f_5584:srfi_69_scm",(void*)f_5584},
{"f_5575:srfi_69_scm",(void*)f_5575},
{"f_5552:srfi_69_scm",(void*)f_5552},
{"f_5559:srfi_69_scm",(void*)f_5559},
{"f_5564:srfi_69_scm",(void*)f_5564},
{"f_5572:srfi_69_scm",(void*)f_5572},
{"f_5540:srfi_69_scm",(void*)f_5540},
{"f_5547:srfi_69_scm",(void*)f_5547},
{"f_5528:srfi_69_scm",(void*)f_5528},
{"f_5535:srfi_69_scm",(void*)f_5535},
{"f_5516:srfi_69_scm",(void*)f_5516},
{"f_5523:srfi_69_scm",(void*)f_5523},
{"f_5450:srfi_69_scm",(void*)f_5450},
{"f_5462:srfi_69_scm",(void*)f_5462},
{"f_5478:srfi_69_scm",(void*)f_5478},
{"f_5506:srfi_69_scm",(void*)f_5506},
{"f_5379:srfi_69_scm",(void*)f_5379},
{"f_5391:srfi_69_scm",(void*)f_5391},
{"f_5414:srfi_69_scm",(void*)f_5414},
{"f_5437:srfi_69_scm",(void*)f_5437},
{"f_5422:srfi_69_scm",(void*)f_5422},
{"f_5401:srfi_69_scm",(void*)f_5401},
{"f_5314:srfi_69_scm",(void*)f_5314},
{"f_5329:srfi_69_scm",(void*)f_5329},
{"f_5345:srfi_69_scm",(void*)f_5345},
{"f_5249:srfi_69_scm",(void*)f_5249},
{"f_5264:srfi_69_scm",(void*)f_5264},
{"f_5280:srfi_69_scm",(void*)f_5280},
{"f_5198:srfi_69_scm",(void*)f_5198},
{"f_5205:srfi_69_scm",(void*)f_5205},
{"f_5210:srfi_69_scm",(void*)f_5210},
{"f_5236:srfi_69_scm",(void*)f_5236},
{"f_5218:srfi_69_scm",(void*)f_5218},
{"f_5208:srfi_69_scm",(void*)f_5208},
{"f_5125:srfi_69_scm",(void*)f_5125},
{"f_5140:srfi_69_scm",(void*)f_5140},
{"f_5156:srfi_69_scm",(void*)f_5156},
{"f_5109:srfi_69_scm",(void*)f_5109},
{"f_5123:srfi_69_scm",(void*)f_5123},
{"f_5097:srfi_69_scm",(void*)f_5097},
{"f_5032:srfi_69_scm",(void*)f_5032},
{"f_5044:srfi_69_scm",(void*)f_5044},
{"f_5067:srfi_69_scm",(void*)f_5067},
{"f_5080:srfi_69_scm",(void*)f_5080},
{"f_5054:srfi_69_scm",(void*)f_5054},
{"f_5016:srfi_69_scm",(void*)f_5016},
{"f_5023:srfi_69_scm",(void*)f_5023},
{"f_4920:srfi_69_scm",(void*)f_4920},
{"f_4927:srfi_69_scm",(void*)f_4927},
{"f_4941:srfi_69_scm",(void*)f_4941},
{"f_4967:srfi_69_scm",(void*)f_4967},
{"f_4986:srfi_69_scm",(void*)f_4986},
{"f_4954:srfi_69_scm",(void*)f_4954},
{"f_4789:srfi_69_scm",(void*)f_4789},
{"f_4805:srfi_69_scm",(void*)f_4805},
{"f_4872:srfi_69_scm",(void*)f_4872},
{"f_4891:srfi_69_scm",(void*)f_4891},
{"f_4825:srfi_69_scm",(void*)f_4825},
{"f_4681:srfi_69_scm",(void*)f_4681},
{"f_4697:srfi_69_scm",(void*)f_4697},
{"f_4752:srfi_69_scm",(void*)f_4752},
{"f_4765:srfi_69_scm",(void*)f_4765},
{"f_4712:srfi_69_scm",(void*)f_4712},
{"f_4575:srfi_69_scm",(void*)f_4575},
{"f_4591:srfi_69_scm",(void*)f_4591},
{"f_4645:srfi_69_scm",(void*)f_4645},
{"f_4661:srfi_69_scm",(void*)f_4661},
{"f_4606:srfi_69_scm",(void*)f_4606},
{"f_4373:srfi_69_scm",(void*)f_4373},
{"f_4433:srfi_69_scm",(void*)f_4433},
{"f_4425:srfi_69_scm",(void*)f_4425},
{"f_4406:srfi_69_scm",(void*)f_4406},
{"f_4440:srfi_69_scm",(void*)f_4440},
{"f_4455:srfi_69_scm",(void*)f_4455},
{"f_4521:srfi_69_scm",(void*)f_4521},
{"f_4551:srfi_69_scm",(void*)f_4551},
{"f_4472:srfi_69_scm",(void*)f_4472},
{"f_4461:srfi_69_scm",(void*)f_4461},
{"f_4361:srfi_69_scm",(void*)f_4361},
{"f_4368:srfi_69_scm",(void*)f_4368},
{"f_4149:srfi_69_scm",(void*)f_4149},
{"f_4206:srfi_69_scm",(void*)f_4206},
{"f_4198:srfi_69_scm",(void*)f_4198},
{"f_4179:srfi_69_scm",(void*)f_4179},
{"f_4213:srfi_69_scm",(void*)f_4213},
{"f_4228:srfi_69_scm",(void*)f_4228},
{"f_4301:srfi_69_scm",(void*)f_4301},
{"f_4334:srfi_69_scm",(void*)f_4334},
{"f_4337:srfi_69_scm",(void*)f_4337},
{"f_4311:srfi_69_scm",(void*)f_4311},
{"f_4242:srfi_69_scm",(void*)f_4242},
{"f_4278:srfi_69_scm",(void*)f_4278},
{"f_4252:srfi_69_scm",(void*)f_4252},
{"f_3857:srfi_69_scm",(void*)f_3857},
{"f_4104:srfi_69_scm",(void*)f_4104},
{"f_4087:srfi_69_scm",(void*)f_4087},
{"f_4099:srfi_69_scm",(void*)f_4099},
{"f_3859:srfi_69_scm",(void*)f_3859},
{"f_3866:srfi_69_scm",(void*)f_3866},
{"f_3869:srfi_69_scm",(void*)f_3869},
{"f_3925:srfi_69_scm",(void*)f_3925},
{"f_3917:srfi_69_scm",(void*)f_3917},
{"f_3898:srfi_69_scm",(void*)f_3898},
{"f_3932:srfi_69_scm",(void*)f_3932},
{"f_3947:srfi_69_scm",(void*)f_3947},
{"f_4024:srfi_69_scm",(void*)f_4024},
{"f_4061:srfi_69_scm",(void*)f_4061},
{"f_4064:srfi_69_scm",(void*)f_4064},
{"f_4052:srfi_69_scm",(void*)f_4052},
{"f_4034:srfi_69_scm",(void*)f_4034},
{"f_3961:srfi_69_scm",(void*)f_3961},
{"f_4001:srfi_69_scm",(void*)f_4001},
{"f_3989:srfi_69_scm",(void*)f_3989},
{"f_3971:srfi_69_scm",(void*)f_3971},
{"f_3848:srfi_69_scm",(void*)f_3848},
{"f_3736:srfi_69_scm",(void*)f_3736},
{"f_3746:srfi_69_scm",(void*)f_3746},
{"f_3751:srfi_69_scm",(void*)f_3751},
{"f_3813:srfi_69_scm",(void*)f_3813},
{"f_3834:srfi_69_scm",(void*)f_3834},
{"f_3807:srfi_69_scm",(void*)f_3807},
{"f_3710:srfi_69_scm",(void*)f_3710},
{"f_3717:srfi_69_scm",(void*)f_3717},
{"f_3720:srfi_69_scm",(void*)f_3720},
{"f_3643:srfi_69_scm",(void*)f_3643},
{"f_3666:srfi_69_scm",(void*)f_3666},
{"f_3682:srfi_69_scm",(void*)f_3682},
{"f_3653:srfi_69_scm",(void*)f_3653},
{"f_3723:srfi_69_scm",(void*)f_3723},
{"f_3616:srfi_69_scm",(void*)f_3616},
{"f_3604:srfi_69_scm",(void*)f_3604},
{"f_3595:srfi_69_scm",(void*)f_3595},
{"f_3586:srfi_69_scm",(void*)f_3586},
{"f_3577:srfi_69_scm",(void*)f_3577},
{"f_3568:srfi_69_scm",(void*)f_3568},
{"f_3559:srfi_69_scm",(void*)f_3559},
{"f_3550:srfi_69_scm",(void*)f_3550},
{"f_3541:srfi_69_scm",(void*)f_3541},
{"f_3535:srfi_69_scm",(void*)f_3535},
{"f_3172:srfi_69_scm",(void*)f_3172},
{"f_3525:srfi_69_scm",(void*)f_3525},
{"f_3528:srfi_69_scm",(void*)f_3528},
{"f_3250:srfi_69_scm",(void*)f_3250},
{"f_3505:srfi_69_scm",(void*)f_3505},
{"f_3508:srfi_69_scm",(void*)f_3508},
{"f_3253:srfi_69_scm",(void*)f_3253},
{"f_3473:srfi_69_scm",(void*)f_3473},
{"f_3479:srfi_69_scm",(void*)f_3479},
{"f_3256:srfi_69_scm",(void*)f_3256},
{"f_3291:srfi_69_scm",(void*)f_3291},
{"f_3312:srfi_69_scm",(void*)f_3312},
{"f_3318:srfi_69_scm",(void*)f_3318},
{"f_3410:srfi_69_scm",(void*)f_3410},
{"f_3413:srfi_69_scm",(void*)f_3413},
{"f_3385:srfi_69_scm",(void*)f_3385},
{"f_3388:srfi_69_scm",(void*)f_3388},
{"f_3375:srfi_69_scm",(void*)f_3375},
{"f_3357:srfi_69_scm",(void*)f_3357},
{"f_3344:srfi_69_scm",(void*)f_3344},
{"f_3334:srfi_69_scm",(void*)f_3334},
{"f_3321:srfi_69_scm",(void*)f_3321},
{"f_3302:srfi_69_scm",(void*)f_3302},
{"f_3259:srfi_69_scm",(void*)f_3259},
{"f_3262:srfi_69_scm",(void*)f_3262},
{"f_3266:srfi_69_scm",(void*)f_3266},
{"f_3282:srfi_69_scm",(void*)f_3282},
{"f_3174:srfi_69_scm",(void*)f_3174},
{"f_3148:srfi_69_scm",(void*)f_3148},
{"f_3152:srfi_69_scm",(void*)f_3152},
{"f_3118:srfi_69_scm",(void*)f_3118},
{"f_3124:srfi_69_scm",(void*)f_3124},
{"f_2978:srfi_69_scm",(void*)f_2978},
{"f_3059:srfi_69_scm",(void*)f_3059},
{"f_3050:srfi_69_scm",(void*)f_3050},
{"f_3031:srfi_69_scm",(void*)f_3031},
{"f_3035:srfi_69_scm",(void*)f_3035},
{"f_3038:srfi_69_scm",(void*)f_3038},
{"f_2994:srfi_69_scm",(void*)f_2994},
{"f_2840:srfi_69_scm",(void*)f_2840},
{"f_2921:srfi_69_scm",(void*)f_2921},
{"f_2912:srfi_69_scm",(void*)f_2912},
{"f_2893:srfi_69_scm",(void*)f_2893},
{"f_2897:srfi_69_scm",(void*)f_2897},
{"f_2900:srfi_69_scm",(void*)f_2900},
{"f_2856:srfi_69_scm",(void*)f_2856},
{"f_2787:srfi_69_scm",(void*)f_2787},
{"f_2825:srfi_69_scm",(void*)f_2825},
{"f_2321:srfi_69_scm",(void*)f_2321},
{"f_2440:srfi_69_scm",(void*)f_2440},
{"f_2775:srfi_69_scm",(void*)f_2775},
{"f_2763:srfi_69_scm",(void*)f_2763},
{"f_2747:srfi_69_scm",(void*)f_2747},
{"f_2696:srfi_69_scm",(void*)f_2696},
{"f_2716:srfi_69_scm",(void*)f_2716},
{"f_2708:srfi_69_scm",(void*)f_2708},
{"f_2670:srfi_69_scm",(void*)f_2670},
{"f_2682:srfi_69_scm",(void*)f_2682},
{"f_2636:srfi_69_scm",(void*)f_2636},
{"f_2389:srfi_69_scm",(void*)f_2389},
{"f_2423:srfi_69_scm",(void*)f_2423},
{"f_2426:srfi_69_scm",(void*)f_2426},
{"f_2324:srfi_69_scm",(void*)f_2324},
{"f_2341:srfi_69_scm",(void*)f_2341},
{"f_2375:srfi_69_scm",(void*)f_2375},
{"f_2269:srfi_69_scm",(void*)f_2269},
{"f_2245:srfi_69_scm",(void*)f_2245},
{"f_2307:srfi_69_scm",(void*)f_2307},
{"f_2002:srfi_69_scm",(void*)f_2002},
{"f_2040:srfi_69_scm",(void*)f_2040},
{"f_1855:srfi_69_scm",(void*)f_1855},
{"f_1862:srfi_69_scm",(void*)f_1862},
{"f_1829:srfi_69_scm",(void*)f_1829},
{"f_1836:srfi_69_scm",(void*)f_1836},
{"f_1763:srfi_69_scm",(void*)f_1763},
{"f_1706:srfi_69_scm",(void*)f_1706},
{"f_1749:srfi_69_scm",(void*)f_1749},
{"f_1510:srfi_69_scm",(void*)f_1510},
{"f_1517:srfi_69_scm",(void*)f_1517},
{"f_1680:srfi_69_scm",(void*)f_1680},
{"f_1686:srfi_69_scm",(void*)f_1686},
{"f_1504:srfi_69_scm",(void*)f_1504},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
