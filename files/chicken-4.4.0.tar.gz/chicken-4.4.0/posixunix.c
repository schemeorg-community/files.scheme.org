/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:16
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: posixunix.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>
#include <utime.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)      C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)       (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)      C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)    (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_do_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_test_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_unsetenv(s)      (unsetenv((char *)C_data_pointer(s)), C_SCHEME_TRUE)
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
# define C_unsetenv(s)      C_fix(putenv((char *)C_data_pointer(s)))
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

/* It is assumed that 'int' is-a 'long' */
#define C_ftell(p)          C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_num_to_int(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define cpy_tmvec_to_tmstc08(ptm, v) \
    (memset((ptm), 0, sizeof(struct tm)), \
    (ptm)->tm_sec = C_unfix(C_block_item((v), 0)), \
    (ptm)->tm_min = C_unfix(C_block_item((v), 1)), \
    (ptm)->tm_hour = C_unfix(C_block_item((v), 2)), \
    (ptm)->tm_mday = C_unfix(C_block_item((v), 3)), \
    (ptm)->tm_mon = C_unfix(C_block_item((v), 4)), \
    (ptm)->tm_year = C_unfix(C_block_item((v), 5)), \
    (ptm)->tm_wday = C_unfix(C_block_item((v), 6)), \
    (ptm)->tm_yday = C_unfix(C_block_item((v), 7)), \
    (ptm)->tm_isdst = (C_block_item((v), 8) != C_SCHEME_FALSE))

#define cpy_tmvec_to_tmstc9(ptm, v) \
    (((struct tm *)ptm)->tm_gmtoff = C_unfix(C_block_item((v), 9)))

#define cpy_tmstc08_to_tmvec(v, ptm) \
    (C_set_block_item((v), 0, C_fix(((struct tm *)ptm)->tm_sec)), \
    C_set_block_item((v), 1, C_fix((ptm)->tm_min)), \
    C_set_block_item((v), 2, C_fix((ptm)->tm_hour)), \
    C_set_block_item((v), 3, C_fix((ptm)->tm_mday)), \
    C_set_block_item((v), 4, C_fix((ptm)->tm_mon)), \
    C_set_block_item((v), 5, C_fix((ptm)->tm_year)), \
    C_set_block_item((v), 6, C_fix((ptm)->tm_wday)), \
    C_set_block_item((v), 7, C_fix((ptm)->tm_yday)), \
    C_set_block_item((v), 8, ((ptm)->tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define cpy_tmstc9_to_tmvec(v, ptm) \
    (C_set_block_item((v), 9, C_fix((ptm)->tm_gmtoff)))

#define C_tm_set_08(v)  cpy_tmvec_to_tmstc08( &C_tm, (v) )
#define C_tm_set_9(v)   cpy_tmvec_to_tmstc9( &C_tm, (v) )

#define C_tm_get_08(v)  cpy_tmstc08_to_tmvec( (v), &C_tm )
#define C_tm_get_9(v)   cpy_tmstc9_to_tmvec( (v), &C_tm )

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  return v;
}

#else

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  C_tm_set_9( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  C_tm_get_9( v );
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_a_mktime(ptr, c, v)  C_flonum(ptr, mktime(C_tm_set(v)))
#define C_a_timegm(ptr, c, v)  C_flonum(ptr, timegm(C_tm_set(v)))

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#ifdef __linux__
extern char *strptime(const char *s, const char *format, struct tm *tm);
extern pid_t getpgid(pid_t pid);
#endif

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif

static int set_file_mtime(char *filename, C_word tm)
{
  struct utimbuf tb;

  tb.actime = tb.modtime = C_num_to_int(tm);
  return utime(filename, &tb);
}


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[462];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,49,54,32,108,111,99,49,55,32,109,115,103,49,56,32,46,32,97,114,103,115,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,50,49,50,52,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,50,53,50,56,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,52,52,32,99,109,100,52,53,32,46,32,116,109,112,52,51,52,54,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,53,55,32,102,108,97,103,115,53,56,32,46,32,109,111,100,101,53,57,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,99,108,111,115,101,32,102,100,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,114,101,97,100,32,102,100,55,51,32,115,105,122,101,55,52,32,46,32,98,117,102,102,101,114,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,119,114,105,116,101,32,102,100,56,56,32,98,117,102,102,101,114,56,57,32,46,32,115,105,122,101,57,48,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,49,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,6),40,103,50,52,48,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,51,51,32,103,50,51,55,50,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,6),40,103,50,50,48,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,49,51,32,103,50,49,55,50,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,6),40,103,49,56,54,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,49,55,57,32,103,49,56,51,49,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,6),40,103,49,53,55,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,49,53,48,32,103,49,53,52,49,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,49,51,49,32,102,100,115,119,49,51,50,32,46,32,116,105,109,101,111,117,116,49,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,50,53,51,32,108,105,110,107,50,53,52,32,108,111,99,50,53,53,41,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,50,54,55,32,46,32,108,105,110,107,50,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,50,55,53,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,50,57,54,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,50,57,57,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,51,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,51,48,53,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,51,48,56,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,51,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,28),40,99,104,97,114,97,99,116,101,114,45,100,101,118,105,99,101,63,32,102,110,97,109,101,51,50,50,41,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,24),40,98,108,111,99,107,45,100,101,118,105,99,101,63,32,102,110,97,109,101,51,50,57,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,17),40,102,95,51,50,55,55,32,102,110,97,109,101,51,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,18),40,115,111,99,107,101,116,63,32,102,110,97,109,101,51,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,51,52,57,32,112,111,115,51,53,48,32,46,32,119,104,101,110,99,101,51,53,49,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,100,105,114,52,49,52,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,7),40,97,51,52,52,50,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,47),40,97,51,52,52,56,32,100,105,114,52,51,56,52,51,57,52,52,52,32,102,105,108,101,52,52,48,52,52,49,52,52,53,32,101,120,116,52,52,50,52,52,51,52,52,54,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,51,56,57,32,46,32,116,109,112,51,56,56,51,57,48,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,52,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,52,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,52,56,53,32,115,112,101,99,52,57,52,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,57,53,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,52,56,56,32,37,115,112,101,99,52,56,51,53,50,55,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,52,56,55,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,52,55,56,52,55,57,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,53,51,52,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,53,53,49,53,53,50,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,51,56,50,55,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,19),40,97,51,56,50,49,32,101,120,118,97,114,53,57,56,54,49,49,41,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,51,56,52,53,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,7),40,97,51,56,53,55,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,20),40,97,51,56,53,49,32,46,32,97,114,103,115,54,48,54,54,50,50,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,7),40,97,51,56,51,57,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,15),40,97,51,56,49,53,32,107,54,48,53,54,49,48,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,54,52,57,32,114,54,53,48,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,54,50,51,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,54,53,56,32,99,109,100,54,53,57,32,105,110,112,54,54,48,32,114,54,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,54,52,32,46,32,109,54,54,53,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,54,55,51,32,46,32,109,54,55,52,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,54,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,7),40,97,52,51,48,57,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,20),40,97,52,51,49,53,32,46,32,114,101,115,117,108,116,115,55,48,50,41,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,54,57,56,32,112,114,111,99,54,57,57,32,46,32,109,111,100,101,55,48,48,41,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,7),40,97,52,51,51,51,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,20),40,97,52,51,51,57,32,46,32,114,101,115,117,108,116,115,55,48,56,41,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,55,48,52,32,112,114,111,99,55,48,53,32,46,32,109,111,100,101,55,48,54,41};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,20),40,97,52,51,53,56,32,46,32,114,101,115,117,108,116,115,55,49,53,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,55,49,48,32,116,104,117,110,107,55,49,49,32,46,32,109,111,100,101,55,49,50,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,20),40,97,52,51,55,56,32,46,32,114,101,115,117,108,116,115,55,50,52,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,55,49,57,32,116,104,117,110,107,55,50,48,32,46,32,109,111,100,101,55,50,49,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,55,51,54,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,36),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,55,51,56,32,112,114,111,99,55,51,57,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,55,52,52,32,115,116,97,116,101,55,52,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,9),40,108,111,111,112,55,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,26),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,55,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,105,103,115,55,55,51,32,109,97,115,107,55,55,52,41,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,55,55,56,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,21),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,55,56,49,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,23),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,55,56,55,41,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,38),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,56,50,56,32,46,32,116,109,112,56,50,55,56,50,57,41,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,54,57,41,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,40),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,56,53,53,32,46,32,116,109,112,56,53,52,56,53,54,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,57,52,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,23),40,100,111,108,111,111,112,57,48,51,32,108,115,116,57,48,55,32,105,57,48,56,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,21),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,57,48,48,41,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,33),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,57,50,54,32,105,100,57,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,32),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,57,51,51,32,109,57,51,52,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,39),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,57,51,57,32,117,105,100,57,52,48,32,103,105,100,57,52,49,41,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,57,52,56,32,97,99,99,57,52,57,32,108,111,99,57,53,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,53,54,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,53,55,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,34),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,57,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,36),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,57,56,50,32,110,101,119,57,56,51,41,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,41),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,57,57,54,32,46,32,116,109,112,57,57,53,57,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,27),40,102,105,108,101,45,108,105,110,107,32,111,108,100,49,48,50,50,32,110,101,119,49,48,50,51,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,20),40,109,111,100,101,32,105,110,112,49,48,51,48,32,109,49,48,51,49,41,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,108,111,99,49,48,52,52,32,102,100,49,48,52,53,32,105,110,112,49,48,52,54,32,114,49,48,52,55,41,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,33),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,49,48,53,48,32,46,32,109,49,48,53,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,34),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,49,48,53,51,32,46,32,109,49,48,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,23),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,49,48,53,57,41,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,36),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,49,48,55,49,32,46,32,110,101,119,49,48,55,50,41,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,8),40,114,101,97,100,121,63,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,7),40,102,101,116,99,104,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,7),40,97,53,53,57,52,41,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,7),40,97,53,54,48,55,41,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,7),40,97,53,54,49,57,41,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,7),40,97,53,54,52,48,41,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,110,49,49,54,54,32,109,49,49,54,55,32,115,116,97,114,116,49,49,54,56,41,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,41),40,97,53,54,52,57,32,112,111,114,116,49,49,54,49,32,110,49,49,54,50,32,100,101,115,116,49,49,54,51,32,115,116,97,114,116,49,49,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,24),40,98,117,109,112,101,114,32,99,117,114,49,49,57,50,32,112,116,114,49,49,57,51,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,7),40,97,53,56,49,49,41,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,42),40,97,53,56,49,55,32,100,101,115,116,49,50,50,51,49,50,50,52,49,50,50,55,32,99,111,110,116,63,49,50,50,53,49,50,50,54,49,50,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,49,49,57,48,41,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,26),40,97,53,55,50,53,32,112,111,114,116,49,49,56,55,32,108,105,109,105,116,49,49,56,56,41,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,49,48,57,57,32,110,111,110,98,108,111,99,107,105,110,103,63,49,49,49,48,32,98,117,102,105,49,49,49,49,32,111,110,45,99,108,111,115,101,49,49,49,50,32,109,111,114,101,63,49,49,49,51,41,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,69),40,100,101,102,45,109,111,114,101,63,49,49,48,52,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,48,57,53,49,50,51,55,32,37,98,117,102,105,49,48,57,54,49,50,51,56,32,37,111,110,45,99,108,111,115,101,49,48,57,55,49,50,51,57,41,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,49,48,51,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,48,57,53,49,50,52,49,32,37,98,117,102,105,49,48,57,54,49,50,52,50,41,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,49,48,50,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,48,57,53,49,50,52,52,41,0,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,49,48,49,41,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,62),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,48,56,56,32,110,97,109,49,48,56,57,32,102,100,49,48,57,48,32,46,32,116,109,112,49,48,56,55,49,48,57,49,41,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,22),40,112,111,107,101,32,115,116,114,49,50,56,57,32,108,101,110,49,50,57,48,41,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,15),40,97,54,48,48,56,32,115,116,114,49,51,50,52,41,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,7),40,97,54,48,49,52,41,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,7),40,97,54,48,51,53,41,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,16),40,102,95,54,48,52,52,32,115,116,114,49,51,48,48,41};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,32,114,101,109,49,51,48,55,32,115,116,97,114,116,49,51,48,56,32,108,101,110,49,51,48,57,41};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,16),40,102,95,54,48,53,57,32,115,116,114,49,51,48,53,41};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,49),40,98,111,100,121,49,50,55,50,32,110,111,110,98,108,111,99,107,105,110,103,63,49,50,56,50,32,98,117,102,105,49,50,56,51,32,111,110,45,99,108,111,115,101,49,50,56,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,50,55,54,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,50,54,57,49,51,51,54,32,37,98,117,102,105,49,50,55,48,49,51,51,55,41,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,50,55,53,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,50,54,57,49,51,51,57,41,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,50,55,52,41,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,63),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,50,54,50,32,110,97,109,49,50,54,51,32,102,100,49,50,54,52,32,46,32,116,109,112,49,50,54,49,49,50,54,53,41,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,49,51,52,55,32,111,102,102,49,51,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,32,112,111,114,116,49,51,54,48,32,97,114,103,115,49,51,54,49,32,108,111,99,49,51,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,30),40,101,114,114,32,109,115,103,49,51,55,56,32,108,111,99,107,49,51,55,57,32,108,111,99,49,51,56,48,41,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,49,51,56,49,32,46,32,97,114,103,115,49,51,56,50,41,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,40),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,49,51,56,52,32,46,32,97,114,103,115,49,51,56,53,41};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,36),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,49,51,56,55,32,46,32,97,114,103,115,49,51,56,56,41,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,49,52,48,55,41,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,34),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,49,52,49,50,32,46,32,109,111,100,101,49,52,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,20),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,49,52,49,57,41,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,49,52,50,50,32,118,97,108,49,52,50,51,41};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,49,52,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,49,52,52,49,41,0,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,52,51,56,41,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,27),40,103,101,116,45,101,110,118,105,114,111,110,109,101,110,116,45,118,97,114,105,97,98,108,101,115,41,0,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,72),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,49,52,54,50,32,108,101,110,49,52,54,51,32,112,114,111,116,49,52,54,52,32,102,108,97,103,49,52,54,53,32,102,100,49,52,54,54,32,46,32,111,102,102,49,52,54,55,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,43),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,49,52,56,56,32,46,32,108,101,110,49,52,56,57,41,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,37),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,49,52,57,53,41,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,49,52,57,56,41,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,34),40,99,104,101,99,107,45,116,105,109,101,45,118,101,99,116,111,114,32,108,111,99,49,53,48,48,32,116,109,49,53,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,35),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,46,32,116,109,112,49,53,49,49,49,53,49,50,41,0,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,33),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,46,32,116,109,112,49,53,50,53,49,53,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,31),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,46,32,116,109,112,49,53,52,52,49,53,52,53,41,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,49,53,55,51,32,46,32,116,109,112,49,53,55,50,49,53,55,52,41,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,36),40,115,116,114,105,110,103,45,62,116,105,109,101,32,116,105,109,49,54,48,51,32,46,32,116,109,112,49,54,48,50,49,54,48,52,41,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,49,54,49,51,41,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,26),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,49,54,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,49,54,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,97,108,97,114,109,33,32,97,49,54,50,57,49,54,51,50,41,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,49,54,51,51,32,109,111,100,101,49,54,51,52,32,46,32,115,105,122,101,49,54,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,49,54,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,49,54,53,52,32,112,111,114,116,49,54,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,49,54,54,55,41};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,49,54,55,56,41};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,7),40,97,55,50,56,49,41,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,13),40,103,49,55,52,49,32,109,49,55,52,51,41,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,49,55,51,50,41,0,0};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,55),40,97,55,50,56,55,32,100,105,114,49,55,49,49,49,55,49,50,49,55,49,55,32,102,105,108,49,55,49,51,49,55,49,52,49,55,49,56,32,101,120,116,49,55,49,53,49,55,49,54,49,55,49,57,41,0};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,49,55,48,55,41,0,0,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,49,55,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,49,55,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,28),40,115,101,116,97,114,103,32,97,49,55,55,57,49,55,56,53,32,97,49,55,55,56,49,55,56,54,41,0,0,0,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,28),40,115,101,116,101,110,118,32,97,49,55,57,49,49,55,57,55,32,97,49,55,57,48,49,55,57,56,41,0,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,56,51,53,32,105,49,56,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,25),40,100,111,108,111,111,112,49,56,50,55,32,97,108,49,56,51,49,32,105,49,56,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,49,56,49,53,32,97,114,103,108,105,115,116,49,56,50,52,32,101,110,118,108,105,115,116,49,56,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,34),40,100,101,102,45,101,110,118,108,105,115,116,49,56,49,56,32,37,97,114,103,108,105,115,116,49,56,49,51,49,56,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,97,114,103,108,105,115,116,49,56,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,49,56,48,56,32,46,32,116,109,112,49,56,48,55,49,56,48,57,41,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,49,56,55,48,32,110,111,104,97,110,103,49,56,55,49,41,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,7),40,97,55,54,56,51,41,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,36),40,97,55,54,56,57,32,101,112,105,100,49,57,48,49,32,101,110,111,114,109,49,57,48,50,32,101,99,111,100,101,49,57,48,51,41,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,49,56,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,49,57,48,57,49,57,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,49,57,49,51,32,46,32,115,105,103,49,57,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,49,57,50,56,41,0,0,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,49,57,51,49,32,46,32,97,114,103,115,49,57,51,50,41,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,7),40,97,55,56,53,57,41,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,29),40,97,55,56,54,53,32,95,49,57,55,48,32,102,108,103,49,57,55,49,32,99,111,100,49,57,55,50,41,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,8),40,102,95,55,56,52,53,41};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,111,110,45,99,108,111,115,101,32,108,111,99,49,57,53,56,32,112,105,100,49,57,53,57,32,99,108,115,118,101,99,49,57,54,48,32,105,100,120,49,57,54,49,32,105,100,120,97,49,57,54,50,32,105,100,120,98,49,57,54,51,41,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,7),40,97,55,56,56,56,41,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,19),40,97,55,56,57,52,32,105,49,57,56,50,32,111,49,57,56,51,41,0,0,0,0,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,101,100,45,112,105,112,101,32,112,111,114,116,49,57,55,55,41,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,34),40,99,111,110,110,101,99,116,45,112,97,114,101,110,116,32,112,105,112,101,49,57,56,53,32,112,111,114,116,49,57,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,43),40,99,111,110,110,101,99,116,45,99,104,105,108,100,32,112,105,112,101,49,57,57,52,32,112,111,114,116,49,57,57,53,32,115,116,100,102,100,49,57,57,54,41,0,0,0,0,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,7),40,97,55,57,54,57,41,0};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,67),40,115,112,97,119,110,32,99,109,100,50,48,49,48,32,97,114,103,115,50,48,49,49,32,101,110,118,50,48,49,50,32,115,116,100,111,117,116,102,50,48,49,51,32,115,116,100,105,110,102,50,48,49,52,32,115,116,100,101,114,114,102,50,48,49,53,41,0,0,0,0,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,59),40,105,110,112,117,116,45,112,111,114,116,32,108,111,99,50,48,50,50,32,99,109,100,50,48,50,52,32,112,105,112,101,50,48,50,53,32,115,116,100,102,50,48,50,54,32,111,110,45,99,108,111,115,101,50,48,50,56,41,0,0,0,0,0};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,60),40,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,50,48,51,51,32,99,109,100,50,48,51,53,32,112,105,112,101,50,48,51,54,32,115,116,100,102,50,48,51,55,32,111,110,45,99,108,111,115,101,50,48,51,57,41,0,0,0,0};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,7),40,97,56,48,49,57,41,0};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,50),40,97,56,48,50,53,32,105,110,112,105,112,101,50,48,53,51,32,111,117,116,112,105,112,101,50,48,53,52,32,101,114,114,112,105,112,101,50,48,53,53,32,112,105,100,50,48,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,50,48,52,52,32,99,109,100,50,48,52,53,32,97,114,103,115,50,48,52,54,32,101,110,118,50,48,52,55,32,115,116,100,111,117,116,102,50,48,52,56,32,115,116,100,105,110,102,50,48,52,57,32,115,116,100,101,114,114,102,50,48,53,48,41,0,0,0,0,0};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,21),40,97,56,48,56,50,32,103,50,48,55,54,50,48,55,55,50,48,55,56,41,0,0,0};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,50,48,54,53,41,0,0,0,0,0};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,7),40,97,56,49,48,48,41,0};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,38),40,97,56,49,48,54,32,105,110,50,48,56,55,32,111,117,116,50,48,56,56,32,112,105,100,50,48,56,57,32,101,114,114,50,48,57,48,41,0,0};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,52),40,37,112,114,111,99,101,115,115,32,108,111,99,50,48,53,57,32,101,114,114,63,50,48,54,48,32,99,109,100,50,48,54,49,32,97,114,103,115,50,48,54,50,32,101,110,118,50,48,54,51,41,0,0,0,0};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,50,49,48,55,32,97,114,103,115,50,49,49,54,32,101,110,118,50,49,49,55,41,0,0,0,0,0};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,50,49,49,48,32,37,97,114,103,115,50,49,48,53,50,49,49,57,41,0,0,0,0,0};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,50,49,48,57,41,0,0};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,50,49,48,48,32,46,32,116,109,112,50,48,57,57,50,49,48,49,41,0};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,50,49,51,56,32,97,114,103,115,50,49,52,55,32,101,110,118,50,49,52,56,41,0,0,0,0,0};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,50,49,52,49,32,37,97,114,103,115,50,49,51,54,50,49,53,48,41,0,0,0,0,0};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,50,49,52,48,41,0,0};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,50,49,51,49,32,46,32,116,109,112,50,49,51,48,50,49,51,50,41};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,14),40,102,95,56,51,57,54,32,120,50,50,48,49,41,0,0};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,7),40,97,56,51,49,57,41,0};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,7),40,97,56,51,50,52,41,0};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,7),40,97,56,51,52,56,41,0};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,50,50,48,51,32,114,50,50,48,52,41,0,0,0,0,0};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,16),40,102,95,56,52,49,53,32,46,32,95,50,49,57,52,41};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,16),40,102,95,56,52,48,55,32,46,32,95,50,49,57,51,41};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,50,49,55,49,32,97,99,116,105,111,110,50,49,56,49,32,105,100,50,49,56,50,32,108,105,109,105,116,50,49,56,51,41,0,0};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,50,49,55,53,32,37,97,99,116,105,111,110,50,49,54,56,50,50,51,52,32,37,105,100,50,49,54,57,50,50,51,53,41,0,0,0,0,0};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,50,49,55,52,32,37,97,99,116,105,111,110,50,49,54,56,50,50,51,55,41,0,0,0,0};
static C_char C_TLS li239[] C_aligned={C_lihdr(0,0,19),40,97,56,52,51,53,32,120,50,50,51,57,32,121,50,50,52,48,41,0,0,0,0,0};
static C_char C_TLS li240[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,50,49,55,51,41};
static C_char C_TLS li241[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,50,49,54,50,32,112,114,101,100,50,49,54,51,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,50,49,54,52,41,0,0,0,0,0};
static C_char C_TLS li242[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,50,50,53,52,41,0,0,0};
static C_char C_TLS li243[] C_aligned={C_lihdr(0,0,14),40,97,56,53,51,52,32,112,105,100,57,54,56,41,0,0};
static C_char C_TLS li244[] C_aligned={C_lihdr(0,0,22),40,97,56,53,53,50,32,112,105,100,57,55,53,32,112,103,105,100,57,55,54,41,0,0};
static C_char C_TLS li245[] C_aligned={C_lihdr(0,0,7),40,97,56,53,55,51,41,0};
static C_char C_TLS li246[] C_aligned={C_lihdr(0,0,13),40,97,56,53,55,54,32,105,100,56,49,55,41,0,0,0};
static C_char C_TLS li247[] C_aligned={C_lihdr(0,0,7),40,97,56,53,57,49,41,0};
static C_char C_TLS li248[] C_aligned={C_lihdr(0,0,13),40,97,56,53,57,52,32,105,100,56,49,49,41,0,0,0};
static C_char C_TLS li249[] C_aligned={C_lihdr(0,0,7),40,97,56,54,48,57,41,0};
static C_char C_TLS li250[] C_aligned={C_lihdr(0,0,13),40,97,56,54,49,50,32,105,100,56,48,53,41,0,0,0};
static C_char C_TLS li251[] C_aligned={C_lihdr(0,0,7),40,97,56,54,50,55,41,0};
static C_char C_TLS li252[] C_aligned={C_lihdr(0,0,13),40,97,56,54,51,48,32,105,100,55,57,57,41,0,0,0};
static C_char C_TLS li253[] C_aligned={C_lihdr(0,0,12),40,97,56,54,52,53,32,110,55,57,50,41,0,0,0,0};
static C_char C_TLS li254[] C_aligned={C_lihdr(0,0,15),40,97,56,54,53,49,32,112,111,114,116,51,54,56,41,0};
static C_char C_TLS li255[] C_aligned={C_lihdr(0,0,12),40,97,56,54,56,56,32,102,50,55,55,41,0,0,0,0};
static C_char C_TLS li256[] C_aligned={C_lihdr(0,0,17),40,97,56,54,57,52,32,102,50,55,57,32,116,50,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li257[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k8502 in set-root-directory! in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub2249(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2249(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k7741 */
static C_word C_fcall stub1910(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1910(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub1907(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1907(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub1905(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1905(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub1800(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1800(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k7447 */
static C_word C_fcall stub1793(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1793(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub1788(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1788(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k7428 */
static C_word C_fcall stub1781(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1781(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k7404 */
static C_word C_fcall stub1769(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1769(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub1752(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1752(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1692(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1692(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k7211 */
static C_word C_fcall stub1673(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1673(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k7188 */
static C_word C_fcall stub1663(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1663(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k7077 */
static C_word C_fcall stub1630(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1630(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k7055 */
static C_word C_fcall stub1625(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1625(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1620(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1620(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = time(NULL);struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub1592(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1592(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub1562(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1562(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub1556(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1556(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k6837 */
static C_word C_fcall stub1535(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1535(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k6687 */
static C_word C_fcall stub1482(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1482(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k6625 */
static C_word C_fcall stub1451(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub1451(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k6524 */
static C_word C_fcall stub1433(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1433(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k5270 in k5266 in file-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub1014(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1014(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k4973 */
static C_word C_fcall stub920(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub920(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k4842 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub877(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub877(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from k4835 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub873(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub873(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from k4749 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub844(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub844(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a8573 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub815(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub815(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a8591 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub809(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub809(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a8609 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub803(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub803(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a8627 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub797(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub797(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k8703 in k8726 in a8694 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub286(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub286(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_fix((C_word)set_file_mtime(t0,t1));
return C_r;}

/* from k2855 */
static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k2845 */
static C_word C_fcall stub121(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub121(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k2835 */
static C_word C_fcall stub116(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub116(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k2617 */
static C_word C_fcall stub33(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub33(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from k2566 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub26(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub26(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from k2559 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub22(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub22(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k2535 */
static C_word C_fcall stub12(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub12(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8695)
static void C_ccall f_8695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8728)
static void C_ccall f_8728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8705)
static void C_ccall f_8705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8715)
static void C_fcall f_8715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8689)
static void C_ccall f_8689(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8693)
static void C_ccall f_8693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8652)
static void C_ccall f_8652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8668)
static void C_ccall f_8668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8656)
static void C_ccall f_8656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8659)
static void C_ccall f_8659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8646)
static void C_ccall f_8646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4591)
static void C_ccall f_4591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8631)
static void C_ccall f_8631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8641)
static void C_ccall f_8641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8628)
static void C_ccall f_8628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8613)
static void C_ccall f_8613(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8623)
static void C_ccall f_8623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8610)
static void C_ccall f_8610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8595)
static void C_ccall f_8595(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8605)
static void C_ccall f_8605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8592)
static void C_ccall f_8592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8577)
static void C_ccall f_8577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8587)
static void C_ccall f_8587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8574)
static void C_ccall f_8574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8553)
static void C_ccall f_8553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8569)
static void C_ccall f_8569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8535)
static void C_ccall f_8535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8548)
static void C_ccall f_8548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8542)
static void C_ccall f_8542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8512)
static void C_ccall f_8512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8504)
static void C_ccall f_8504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8522)
static void C_fcall f_8522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8253)
static void C_ccall f_8253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8253)
static void C_ccall f_8253r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8430)
static void C_fcall f_8430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8436)
static void C_ccall f_8436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8425)
static void C_fcall f_8425(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8420)
static void C_fcall f_8420(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8255)
static void C_fcall f_8255(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8407)
static void C_ccall f_8407(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8415)
static void C_ccall f_8415(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8262)
static void C_fcall f_8262(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8395)
static void C_ccall f_8395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8389)
static void C_ccall f_8389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8272)
static void C_ccall f_8272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8274)
static void C_fcall f_8274(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8375)
static void C_ccall f_8375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8382)
static void C_ccall f_8382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8308)
static void C_ccall f_8308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8362)
static void C_ccall f_8362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8359)
static void C_ccall f_8359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8349)
static void C_ccall f_8349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8325)
static void C_ccall f_8325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8347)
static void C_ccall f_8347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8333)
static void C_ccall f_8333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_ccall f_8340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8320)
static void C_ccall f_8320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8318)
static void C_ccall f_8318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8396)
static void C_ccall f_8396(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8193)
static void C_ccall f_8193(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8193)
static void C_ccall f_8193r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8205)
static void C_fcall f_8205(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8200)
static void C_fcall f_8200(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8195)
static void C_fcall f_8195(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8145)
static void C_fcall f_8145(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8140)
static void C_fcall f_8140(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8135)
static void C_fcall f_8135(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8072)
static void C_fcall f_8072(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8131)
static void C_ccall f_8131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8096)
static void C_ccall f_8096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8107)
static void C_ccall f_8107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8101)
static void C_ccall f_8101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8074)
static void C_fcall f_8074(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8083)
static void C_ccall f_8083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8014)
static void C_ccall f_8014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8026)
static void C_ccall f_8026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8057)
static void C_ccall f_8057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8037)
static void C_ccall f_8037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8053)
static void C_ccall f_8053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8049)
static void C_ccall f_8049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8045)
static void C_ccall f_8045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8020)
static void C_ccall f_8020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8003)
static void C_fcall f_8003(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8007)
static void C_ccall f_8007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7992)
static void C_fcall f_7992(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7996)
static void C_ccall f_7996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7947)
static void C_fcall f_7947(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7951)
static void C_ccall f_7951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7957)
static void C_ccall f_7957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7964)
static void C_fcall f_7964(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7970)
static void C_ccall f_7970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7974)
static void C_ccall f_7974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7977)
static void C_ccall f_7977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7980)
static void C_ccall f_7980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7968)
static void C_ccall f_7968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7914)
static void C_fcall f_7914(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7927)
static void C_ccall f_7927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7900)
static void C_fcall f_7900(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7913)
static void C_ccall f_7913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7880)
static void C_fcall f_7880(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7895)
static void C_ccall f_7895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7843)
static void C_fcall f_7843(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7787)
static void C_ccall f_7787r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7794)
static void C_ccall f_7794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7813)
static void C_ccall f_7813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7817)
static void C_ccall f_7817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7781)
static void C_ccall f_7781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7772)
static void C_ccall f_7772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7776)
static void C_ccall f_7776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7745)
static void C_ccall f_7745(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7745)
static void C_ccall f_7745r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7738)
static void C_ccall f_7738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7735)
static void C_ccall f_7735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7654)
static void C_ccall f_7654(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7654)
static void C_ccall f_7654r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7690)
static void C_ccall f_7690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7684)
static void C_ccall f_7684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7637)
static void C_ccall f_7637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7455)
static void C_ccall f_7455(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7455)
static void C_ccall f_7455r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7589)
static void C_fcall f_7589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7584)
static void C_fcall f_7584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7457)
static void C_fcall f_7457(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7475)
static void C_fcall f_7475(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7521)
static C_word C_fcall f_7521(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7488)
static void C_fcall f_7488(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7491)
static void C_ccall f_7491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7436)
static C_word C_fcall f_7436(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7417)
static C_word C_fcall f_7417(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7375)
static void C_ccall f_7375(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7375)
static void C_ccall f_7375r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7400)
static void C_ccall f_7400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7261)
static void C_ccall f_7261(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7261)
static void C_ccall f_7261r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7267)
static void C_fcall f_7267(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7367)
static void C_ccall f_7367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7292)
static void C_ccall f_7292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7295)
static void C_ccall f_7295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7302)
static void C_ccall f_7302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7304)
static void C_fcall f_7304(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7321)
static void C_ccall f_7321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7325)
static void C_fcall f_7325(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7333)
static void C_ccall f_7333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7337)
static void C_ccall f_7337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7256)
static void C_ccall f_7256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7214)
static void C_ccall f_7214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7218)
static void C_ccall f_7218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_ccall f_7238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7242)
static void C_ccall f_7242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7191)
static void C_ccall f_7191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7159)
static void C_fcall f_7159(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7163)
static void C_ccall f_7163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7144)
static void C_ccall f_7144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7147)
static void C_ccall f_7147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7081)
static void C_ccall f_7081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7081)
static void C_ccall f_7081r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7085)
static void C_ccall f_7085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7100)
static void C_fcall f_7100(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7020)
static void C_ccall f_7020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6970)
static void C_ccall f_6970(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6970)
static void C_ccall f_6970r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6987)
static void C_ccall f_6987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6905)
static void C_ccall f_6905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6908)
static void C_ccall f_6908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6917)
static void C_ccall f_6917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6840)
static void C_ccall f_6840(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6840)
static void C_ccall f_6840r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6844)
static void C_ccall f_6844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6796)
static void C_ccall f_6796(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6796)
static void C_ccall f_6796r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6766)
static void C_ccall f_6766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6743)
static void C_fcall f_6743(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6728)
static void C_ccall f_6728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6693)
static void C_ccall f_6693(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6693)
static void C_ccall f_6693r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_6635)
static void C_ccall f_6635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6647)
static void C_ccall f_6647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6533)
static void C_fcall f_6533(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_fcall f_6545(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6575)
static void C_ccall f_6575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6563)
static void C_ccall f_6563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6507)
static void C_ccall f_6507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6515)
static void C_ccall f_6515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6501)
static void C_ccall f_6501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6464)
static void C_ccall f_6464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6428)
static void C_fcall f_6428(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6449)
static void C_ccall f_6449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6445)
static void C_ccall f_6445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6340)
static void C_ccall f_6340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_fcall f_6318(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6244)
static void C_fcall f_6244(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6266)
static void C_ccall f_6266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6272)
static void C_fcall f_6272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6222)
static void C_ccall f_6222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6215)
static void C_fcall f_6215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5946)
static void C_ccall f_5946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5946)
static void C_ccall f_5946r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6142)
static void C_fcall f_6142(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_fcall f_6137(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6132)
static void C_fcall f_6132(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5948)
static void C_fcall f_5948(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6076)
static void C_fcall f_6076(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6000)
static void C_fcall f_6000(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6036)
static void C_ccall f_6036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6004)
static void C_ccall f_6004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6007)
static void C_ccall f_6007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5954)
static void C_fcall f_5954(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5989)
static void C_ccall f_5989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5868)
static void C_fcall f_5868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_fcall f_5863(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5858)
static void C_fcall f_5858(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5853)
static void C_fcall f_5853(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5466)
static void C_fcall f_5466(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5470)
static void C_ccall f_5470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5726)
static void C_ccall f_5726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5732)
static void C_fcall f_5732(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5741)
static void C_ccall f_5741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5751)
static void C_ccall f_5751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5650)
static void C_ccall f_5650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5658)
static void C_fcall f_5658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5660)
static void C_fcall f_5660(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5508)
static void C_fcall f_5508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_fcall f_5520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_ccall f_5539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static C_word C_fcall f_5500(C_word t0);
C_noret_decl(f_5477)
static void C_fcall f_5477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5444)
static void C_fcall f_5444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5396)
static void C_ccall f_5396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_ccall f_5431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5364)
static void C_ccall f_5364(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5364)
static void C_ccall f_5364r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5376)
static void C_ccall f_5376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_fcall f_5349(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static void C_fcall f_5312(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5300)
static void C_fcall f_5300(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5207)
static void C_ccall f_5207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5165)
static void C_ccall f_5165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5146)
static void C_ccall f_5146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5150)
static void C_ccall f_5150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5140)
static void C_ccall f_5140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5104)
static void C_fcall f_5104(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5072)
static void C_ccall f_5072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5068)
static void C_ccall f_5068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4909)
static void C_ccall f_4909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_fcall f_4918(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4846)
static void C_ccall f_4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4856)
static void C_ccall f_4856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_fcall f_4861(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_ccall f_4753(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4753)
static void C_ccall f_4753r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_fcall f_4760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_fcall f_4783(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_fcall f_4654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4528)
static void C_fcall f_4528(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4494)
static C_word C_fcall f_4494(C_word t0);
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4340)
static void C_ccall f_4340(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4340)
static void C_ccall f_4340r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_ccall f_4301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4301)
static void C_ccall f_4301r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4305)
static void C_ccall f_4305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4263)
static void C_ccall f_4263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_fcall f_4198(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3990)
static void C_fcall f_3990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_fcall f_4009(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4138)
static void C_ccall f_4138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4123)
static void C_ccall f_4123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_fcall f_4053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4093)
static void C_ccall f_4093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_fcall f_3879(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3892)
static void C_ccall f_3892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_fcall f_3807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3665)
static void C_fcall f_3665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_fcall f_3660(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3562)
static void C_fcall f_3562(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_fcall f_3593(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_fcall f_3615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3523)
static void C_ccall f_3523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3526)
static void C_ccall f_3526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_fcall f_3376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_fcall f_3388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_fcall f_3395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_fcall f_3138(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3097)
static void C_fcall f_3097(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3105)
static C_word C_fcall f_3105(C_word t0,C_word t1);
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_fcall f_3049(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3057)
static C_word C_fcall f_3057(C_word t0,C_word t1);
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_fcall f_2883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_fcall f_2987(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2995)
static C_word C_fcall f_2995(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_fcall f_2922(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_fcall f_2940(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2948)
static C_word C_fcall f_2948(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2735)
static void C_ccall f_2735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8715)
static void C_fcall trf_8715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8715(t0,t1);}

C_noret_decl(trf_8522)
static void C_fcall trf_8522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8522(t0,t1);}

C_noret_decl(trf_8430)
static void C_fcall trf_8430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8430(t0,t1);}

C_noret_decl(trf_8425)
static void C_fcall trf_8425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8425(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8425(t0,t1,t2);}

C_noret_decl(trf_8420)
static void C_fcall trf_8420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8420(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8420(t0,t1,t2,t3);}

C_noret_decl(trf_8255)
static void C_fcall trf_8255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8255(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8255(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8262)
static void C_fcall trf_8262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8262(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8262(t0,t1);}

C_noret_decl(trf_8274)
static void C_fcall trf_8274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8274(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8274(t0,t1,t2,t3);}

C_noret_decl(trf_8205)
static void C_fcall trf_8205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8205(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8205(t0,t1);}

C_noret_decl(trf_8200)
static void C_fcall trf_8200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8200(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8200(t0,t1,t2);}

C_noret_decl(trf_8195)
static void C_fcall trf_8195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8195(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8195(t0,t1,t2,t3);}

C_noret_decl(trf_8145)
static void C_fcall trf_8145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8145(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8145(t0,t1);}

C_noret_decl(trf_8140)
static void C_fcall trf_8140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8140(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8140(t0,t1,t2);}

C_noret_decl(trf_8135)
static void C_fcall trf_8135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8135(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8135(t0,t1,t2,t3);}

C_noret_decl(trf_8072)
static void C_fcall trf_8072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8072(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8072(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8074)
static void C_fcall trf_8074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8074(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8074(t0,t1,t2);}

C_noret_decl(trf_8003)
static void C_fcall trf_8003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8003(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8003(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7992)
static void C_fcall trf_7992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7992(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7992(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7947)
static void C_fcall trf_7947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7947(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7947(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7964)
static void C_fcall trf_7964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7964(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7964(t0,t1);}

C_noret_decl(trf_7914)
static void C_fcall trf_7914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7914(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7914(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7900)
static void C_fcall trf_7900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7900(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7900(t0,t1,t2,t3);}

C_noret_decl(trf_7880)
static void C_fcall trf_7880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7880(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7880(t0,t1,t2);}

C_noret_decl(trf_7843)
static void C_fcall trf_7843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7843(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7843(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7589)
static void C_fcall trf_7589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7589(t0,t1);}

C_noret_decl(trf_7584)
static void C_fcall trf_7584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7584(t0,t1,t2);}

C_noret_decl(trf_7457)
static void C_fcall trf_7457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7457(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7457(t0,t1,t2,t3);}

C_noret_decl(trf_7475)
static void C_fcall trf_7475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7475(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7475(t0,t1,t2,t3);}

C_noret_decl(trf_7488)
static void C_fcall trf_7488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7488(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7488(t0,t1);}

C_noret_decl(trf_7267)
static void C_fcall trf_7267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7267(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7267(t0,t1,t2);}

C_noret_decl(trf_7304)
static void C_fcall trf_7304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7304(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7304(t0,t1,t2);}

C_noret_decl(trf_7325)
static void C_fcall trf_7325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7325(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7325(t0,t1,t2);}

C_noret_decl(trf_7159)
static void C_fcall trf_7159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7159(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7159(t0,t1,t2);}

C_noret_decl(trf_7100)
static void C_fcall trf_7100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7100(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7100(t0,t1);}

C_noret_decl(trf_6743)
static void C_fcall trf_6743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6743(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6743(t0,t1,t2);}

C_noret_decl(trf_6533)
static void C_fcall trf_6533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6533(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6533(t0,t1,t2);}

C_noret_decl(trf_6545)
static void C_fcall trf_6545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6545(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6545(t0,t1,t2);}

C_noret_decl(trf_6428)
static void C_fcall trf_6428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6428(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6428(t0,t1);}

C_noret_decl(trf_6318)
static void C_fcall trf_6318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6318(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6318(t0,t1,t2,t3);}

C_noret_decl(trf_6244)
static void C_fcall trf_6244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6244(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6244(t0,t1,t2,t3);}

C_noret_decl(trf_6272)
static void C_fcall trf_6272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6272(t0,t1);}

C_noret_decl(trf_6215)
static void C_fcall trf_6215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6215(t0,t1);}

C_noret_decl(trf_6142)
static void C_fcall trf_6142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6142(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6142(t0,t1);}

C_noret_decl(trf_6137)
static void C_fcall trf_6137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6137(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6137(t0,t1,t2);}

C_noret_decl(trf_6132)
static void C_fcall trf_6132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6132(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6132(t0,t1,t2,t3);}

C_noret_decl(trf_5948)
static void C_fcall trf_5948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5948(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5948(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6076)
static void C_fcall trf_6076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6076(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6076(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6000)
static void C_fcall trf_6000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6000(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6000(t0,t1);}

C_noret_decl(trf_5954)
static void C_fcall trf_5954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5954(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5954(t0,t1,t2,t3);}

C_noret_decl(trf_5868)
static void C_fcall trf_5868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5868(t0,t1);}

C_noret_decl(trf_5863)
static void C_fcall trf_5863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5863(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5863(t0,t1,t2);}

C_noret_decl(trf_5858)
static void C_fcall trf_5858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5858(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5858(t0,t1,t2,t3);}

C_noret_decl(trf_5853)
static void C_fcall trf_5853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5853(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5853(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5466)
static void C_fcall trf_5466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5466(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5466(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5732)
static void C_fcall trf_5732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5732(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5732(t0,t1,t2);}

C_noret_decl(trf_5658)
static void C_fcall trf_5658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5658(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5658(t0,t1);}

C_noret_decl(trf_5660)
static void C_fcall trf_5660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5660(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5660(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5508)
static void C_fcall trf_5508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5508(t0,t1);}

C_noret_decl(trf_5520)
static void C_fcall trf_5520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5520(t0,t1);}

C_noret_decl(trf_5477)
static void C_fcall trf_5477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5477(t0,t1);}

C_noret_decl(trf_5444)
static void C_fcall trf_5444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5444(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5444(t0,t1);}

C_noret_decl(trf_5349)
static void C_fcall trf_5349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5349(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5349(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5312)
static void C_fcall trf_5312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5312(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5312(t0,t1,t2);}

C_noret_decl(trf_5300)
static void C_fcall trf_5300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5300(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5300(t0,t1);}

C_noret_decl(trf_5104)
static void C_fcall trf_5104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5104(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5104(t0,t1,t2,t3);}

C_noret_decl(trf_4918)
static void C_fcall trf_4918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4918(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4918(t0,t1,t2,t3);}

C_noret_decl(trf_4861)
static void C_fcall trf_4861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4861(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4861(t0,t1,t2);}

C_noret_decl(trf_4760)
static void C_fcall trf_4760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4760(t0,t1);}

C_noret_decl(trf_4783)
static void C_fcall trf_4783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4783(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4783(t0,t1,t2);}

C_noret_decl(trf_4654)
static void C_fcall trf_4654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4654(t0,t1);}

C_noret_decl(trf_4528)
static void C_fcall trf_4528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4528(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4528(t0,t1,t2,t3);}

C_noret_decl(trf_4198)
static void C_fcall trf_4198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4198(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4198(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3990)
static void C_fcall trf_3990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3990(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3990(t0,t1);}

C_noret_decl(trf_4009)
static void C_fcall trf_4009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4009(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4009(t0,t1);}

C_noret_decl(trf_4053)
static void C_fcall trf_4053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4053(t0,t1);}

C_noret_decl(trf_3879)
static void C_fcall trf_3879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3879(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3879(t0,t1,t2,t3);}

C_noret_decl(trf_3807)
static void C_fcall trf_3807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3807(t0,t1);}

C_noret_decl(trf_3665)
static void C_fcall trf_3665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3665(t0,t1);}

C_noret_decl(trf_3660)
static void C_fcall trf_3660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3660(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3660(t0,t1,t2);}

C_noret_decl(trf_3562)
static void C_fcall trf_3562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3562(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3562(t0,t1,t2,t3);}

C_noret_decl(trf_3593)
static void C_fcall trf_3593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3593(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3593(t0,t1);}

C_noret_decl(trf_3615)
static void C_fcall trf_3615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3615(t0,t1);}

C_noret_decl(trf_3376)
static void C_fcall trf_3376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3376(t0,t1);}

C_noret_decl(trf_3388)
static void C_fcall trf_3388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3388(t0,t1,t2);}

C_noret_decl(trf_3395)
static void C_fcall trf_3395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3395(t0,t1);}

C_noret_decl(trf_3138)
static void C_fcall trf_3138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3138(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3138(t0,t1,t2,t3);}

C_noret_decl(trf_3097)
static void C_fcall trf_3097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3097(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3097(t0,t1,t2);}

C_noret_decl(trf_3049)
static void C_fcall trf_3049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3049(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3049(t0,t1,t2);}

C_noret_decl(trf_2883)
static void C_fcall trf_2883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2883(t0,t1);}

C_noret_decl(trf_2987)
static void C_fcall trf_2987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2987(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2987(t0,t1,t2);}

C_noret_decl(trf_2922)
static void C_fcall trf_2922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2922(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2922(t0,t1);}

C_noret_decl(trf_2940)
static void C_fcall trf_2940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2940(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2940(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3348)){
C_save(t1);
C_rereclaim2(3348*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,462);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_h_intern(&lf[51],9,"file-open");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[53]=C_h_intern(&lf[53],17,"\003sysmake-c-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysexpand-home-path");
lf[55]=C_h_intern(&lf[55],10,"file-close");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],10,"file-write");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[65]=C_h_intern(&lf[65],12,"file-mkstemp");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[68]=C_h_intern(&lf[68],11,"file-select");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[70]=C_h_intern(&lf[70],8,"seek/set");
lf[71]=C_h_intern(&lf[71],8,"seek/end");
lf[72]=C_h_intern(&lf[72],8,"seek/cur");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[76]=C_h_intern(&lf[76],9,"file-stat");
lf[77]=C_h_intern(&lf[77],9,"file-size");
lf[78]=C_h_intern(&lf[78],22,"file-modification-time");
lf[79]=C_h_intern(&lf[79],16,"file-access-time");
lf[80]=C_h_intern(&lf[80],16,"file-change-time");
lf[81]=C_h_intern(&lf[81],10,"file-owner");
lf[82]=C_h_intern(&lf[82],16,"file-permissions");
lf[83]=C_h_intern(&lf[83],13,"regular-file\077");
lf[84]=C_h_intern(&lf[84],14,"symbolic-link\077");
lf[85]=C_h_intern(&lf[85],17,"character-device\077");
lf[86]=C_h_intern(&lf[86],13,"block-device\077");
lf[87]=C_h_intern(&lf[87],5,"fifo\077");
lf[88]=C_h_intern(&lf[88],10,"stat-fifo\077");
lf[89]=C_h_intern(&lf[89],7,"socket\077");
lf[90]=C_h_intern(&lf[90],18,"set-file-position!");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[92]=C_h_intern(&lf[92],6,"stream");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[94]=C_h_intern(&lf[94],5,"port\077");
lf[95]=C_h_intern(&lf[95],13,"\000bounds-error");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[97]=C_h_intern(&lf[97],13,"file-position");
lf[98]=C_h_intern(&lf[98],18,"decompose-pathname");
lf[99]=C_h_intern(&lf[99],18,"pathname-directory");
lf[100]=C_h_intern(&lf[100],16,"create-directory");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[102]=C_h_intern(&lf[102],13,"make-pathname");
lf[103]=C_h_intern(&lf[103],16,"change-directory");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[105]=C_h_intern(&lf[105],16,"delete-directory");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[107]=C_h_intern(&lf[107],10,"string-ref");
lf[108]=C_h_intern(&lf[108],6,"string");
lf[109]=C_h_intern(&lf[109],9,"directory");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[111]=C_h_intern(&lf[111],16,"\003sysmake-pointer");
lf[112]=C_h_intern(&lf[112],17,"current-directory");
lf[113]=C_h_intern(&lf[113],10,"directory\077");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[115]=C_h_intern(&lf[115],5,"null\077");
lf[116]=C_h_intern(&lf[116],6,"char=\077");
lf[117]=C_h_intern(&lf[117],8,"string=\077");
lf[118]=C_h_intern(&lf[118],16,"char-alphabetic\077");
lf[119]=C_h_intern(&lf[119],24,"get-environment-variable");
lf[120]=C_h_intern(&lf[120],17,"current-user-name");
lf[121]=C_h_intern(&lf[121],9,"condition");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[123]=C_h_intern(&lf[123],22,"with-exception-handler");
lf[124]=C_h_intern(&lf[124],30,"call-with-current-continuation");
lf[125]=C_h_intern(&lf[125],14,"canonical-path");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[128]=C_h_intern(&lf[128],18,"string-intersperse");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[131]=C_h_intern(&lf[131],7,"reverse");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[135]=C_h_intern(&lf[135],12,"string-split");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[144]=C_h_intern(&lf[144],13,"\003sysmake-port");
lf[145]=C_h_intern(&lf[145],21,"\003sysstream-port-class");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[147]=C_h_intern(&lf[147],15,"open-input-pipe");
lf[148]=C_h_intern(&lf[148],5,"\000text");
lf[149]=C_h_intern(&lf[149],7,"\000binary");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[151]=C_h_intern(&lf[151],16,"open-output-pipe");
lf[152]=C_h_intern(&lf[152],16,"close-input-pipe");
lf[153]=C_h_intern(&lf[153],23,"close-input/output-pipe");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[155]=C_h_intern(&lf[155],14,"\003syscheck-port");
lf[156]=C_h_intern(&lf[156],17,"close-output-pipe");
lf[157]=C_h_intern(&lf[157],20,"call-with-input-pipe");
lf[158]=C_h_intern(&lf[158],21,"call-with-output-pipe");
lf[159]=C_h_intern(&lf[159],20,"with-input-from-pipe");
lf[160]=C_h_intern(&lf[160],18,"\003sysstandard-input");
lf[161]=C_h_intern(&lf[161],19,"with-output-to-pipe");
lf[162]=C_h_intern(&lf[162],19,"\003sysstandard-output");
lf[163]=C_h_intern(&lf[163],11,"create-pipe");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[165]=C_h_intern(&lf[165],11,"signal/term");
lf[166]=C_h_intern(&lf[166],11,"signal/kill");
lf[167]=C_h_intern(&lf[167],10,"signal/int");
lf[168]=C_h_intern(&lf[168],10,"signal/hup");
lf[169]=C_h_intern(&lf[169],10,"signal/fpe");
lf[170]=C_h_intern(&lf[170],10,"signal/ill");
lf[171]=C_h_intern(&lf[171],11,"signal/segv");
lf[172]=C_h_intern(&lf[172],11,"signal/abrt");
lf[173]=C_h_intern(&lf[173],11,"signal/trap");
lf[174]=C_h_intern(&lf[174],11,"signal/quit");
lf[175]=C_h_intern(&lf[175],11,"signal/alrm");
lf[176]=C_h_intern(&lf[176],13,"signal/vtalrm");
lf[177]=C_h_intern(&lf[177],11,"signal/prof");
lf[178]=C_h_intern(&lf[178],9,"signal/io");
lf[179]=C_h_intern(&lf[179],10,"signal/urg");
lf[180]=C_h_intern(&lf[180],11,"signal/chld");
lf[181]=C_h_intern(&lf[181],11,"signal/cont");
lf[182]=C_h_intern(&lf[182],11,"signal/stop");
lf[183]=C_h_intern(&lf[183],11,"signal/tstp");
lf[184]=C_h_intern(&lf[184],11,"signal/pipe");
lf[185]=C_h_intern(&lf[185],11,"signal/xcpu");
lf[186]=C_h_intern(&lf[186],11,"signal/xfsz");
lf[187]=C_h_intern(&lf[187],11,"signal/usr1");
lf[188]=C_h_intern(&lf[188],11,"signal/usr2");
lf[189]=C_h_intern(&lf[189],12,"signal/winch");
lf[190]=C_h_intern(&lf[190],12,"signals-list");
lf[191]=C_h_intern(&lf[191],18,"\003sysinterrupt-hook");
lf[192]=C_h_intern(&lf[192],14,"signal-handler");
lf[193]=C_h_intern(&lf[193],19,"set-signal-handler!");
lf[194]=C_h_intern(&lf[194],16,"set-signal-mask!");
lf[195]=C_h_intern(&lf[195],14,"\000process-error");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[197]=C_h_intern(&lf[197],11,"signal-mask");
lf[198]=C_h_intern(&lf[198],14,"signal-masked\077");
lf[199]=C_h_intern(&lf[199],12,"signal-mask!");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[201]=C_h_intern(&lf[201],14,"signal-unmask!");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[203]=C_h_intern(&lf[203],18,"system-information");
lf[204]=C_h_intern(&lf[204],25,"\003syspeek-nonnull-c-string");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[206]=C_h_intern(&lf[206],15,"current-user-id");
lf[207]=C_h_intern(&lf[207],25,"current-effective-user-id");
lf[208]=C_h_intern(&lf[208],16,"current-group-id");
lf[209]=C_h_intern(&lf[209],26,"current-effective-group-id");
lf[210]=C_h_intern(&lf[210],16,"user-information");
lf[211]=C_h_intern(&lf[211],6,"vector");
lf[212]=C_h_intern(&lf[212],4,"list");
lf[213]=C_h_intern(&lf[213],27,"current-effective-user-name");
lf[214]=C_h_intern(&lf[214],17,"group-information");
lf[215]=C_h_intern(&lf[215],10,"get-groups");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[219]=C_h_intern(&lf[219],11,"set-groups!");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[222]=C_h_intern(&lf[222],17,"initialize-groups");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[224]=C_h_intern(&lf[224],10,"errno/perm");
lf[225]=C_h_intern(&lf[225],11,"errno/noent");
lf[226]=C_h_intern(&lf[226],10,"errno/srch");
lf[227]=C_h_intern(&lf[227],10,"errno/intr");
lf[228]=C_h_intern(&lf[228],8,"errno/io");
lf[229]=C_h_intern(&lf[229],12,"errno/noexec");
lf[230]=C_h_intern(&lf[230],10,"errno/badf");
lf[231]=C_h_intern(&lf[231],11,"errno/child");
lf[232]=C_h_intern(&lf[232],11,"errno/nomem");
lf[233]=C_h_intern(&lf[233],11,"errno/acces");
lf[234]=C_h_intern(&lf[234],11,"errno/fault");
lf[235]=C_h_intern(&lf[235],10,"errno/busy");
lf[236]=C_h_intern(&lf[236],12,"errno/notdir");
lf[237]=C_h_intern(&lf[237],11,"errno/isdir");
lf[238]=C_h_intern(&lf[238],11,"errno/inval");
lf[239]=C_h_intern(&lf[239],11,"errno/mfile");
lf[240]=C_h_intern(&lf[240],11,"errno/nospc");
lf[241]=C_h_intern(&lf[241],11,"errno/spipe");
lf[242]=C_h_intern(&lf[242],10,"errno/pipe");
lf[243]=C_h_intern(&lf[243],11,"errno/again");
lf[244]=C_h_intern(&lf[244],10,"errno/rofs");
lf[245]=C_h_intern(&lf[245],11,"errno/exist");
lf[246]=C_h_intern(&lf[246],16,"errno/wouldblock");
lf[247]=C_h_intern(&lf[247],10,"errno/2big");
lf[248]=C_h_intern(&lf[248],12,"errno/deadlk");
lf[249]=C_h_intern(&lf[249],9,"errno/dom");
lf[250]=C_h_intern(&lf[250],10,"errno/fbig");
lf[251]=C_h_intern(&lf[251],11,"errno/ilseq");
lf[252]=C_h_intern(&lf[252],11,"errno/mlink");
lf[253]=C_h_intern(&lf[253],17,"errno/nametoolong");
lf[254]=C_h_intern(&lf[254],11,"errno/nfile");
lf[255]=C_h_intern(&lf[255],11,"errno/nodev");
lf[256]=C_h_intern(&lf[256],11,"errno/nolck");
lf[257]=C_h_intern(&lf[257],11,"errno/nosys");
lf[258]=C_h_intern(&lf[258],14,"errno/notempty");
lf[259]=C_h_intern(&lf[259],11,"errno/notty");
lf[260]=C_h_intern(&lf[260],10,"errno/nxio");
lf[261]=C_h_intern(&lf[261],11,"errno/range");
lf[262]=C_h_intern(&lf[262],10,"errno/xdev");
lf[263]=C_h_intern(&lf[263],16,"change-file-mode");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[265]=C_h_intern(&lf[265],17,"change-file-owner");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[267]=C_h_intern(&lf[267],17,"file-read-access\077");
lf[268]=C_h_intern(&lf[268],18,"file-write-access\077");
lf[269]=C_h_intern(&lf[269],20,"file-execute-access\077");
lf[270]=C_h_intern(&lf[270],14,"create-session");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[272]=C_h_intern(&lf[272],16,"process-group-id");
lf[273]=C_h_intern(&lf[273],20,"create-symbolic-link");
lf[274]=C_h_intern(&lf[274],18,"create-symbol-link");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[276]=C_h_intern(&lf[276],9,"substring");
lf[277]=C_h_intern(&lf[277],18,"read-symbolic-link");
lf[278]=C_h_intern(&lf[278],12,"canonicalize");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[280]=C_h_intern(&lf[280],9,"file-link");
lf[281]=C_h_intern(&lf[281],9,"hard-link");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[283]=C_h_intern(&lf[283],12,"fileno/stdin");
lf[284]=C_h_intern(&lf[284],13,"fileno/stdout");
lf[285]=C_h_intern(&lf[285],13,"fileno/stderr");
lf[286]=C_h_intern(&lf[286],7,"\000append");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[294]=C_h_intern(&lf[294],16,"open-input-file*");
lf[295]=C_h_intern(&lf[295],17,"open-output-file*");
lf[296]=C_h_intern(&lf[296],12,"port->fileno");
lf[297]=C_h_intern(&lf[297],6,"socket");
lf[298]=C_h_intern(&lf[298],20,"\003systcp-port->fileno");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[301]=C_h_intern(&lf[301],25,"\003syspeek-unsigned-integer");
lf[302]=C_h_intern(&lf[302],16,"duplicate-fileno");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[304]=C_h_intern(&lf[304],15,"make-input-port");
lf[305]=C_h_intern(&lf[305],14,"set-port-name!");
lf[306]=C_h_intern(&lf[306],21,"\003syscustom-input-port");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[308]=C_h_intern(&lf[308],17,"\003systhread-yield!");
lf[309]=C_h_intern(&lf[309],25,"\003systhread-block-for-i/o!");
lf[310]=C_h_intern(&lf[310],18,"\003syscurrent-thread");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[315]=C_h_intern(&lf[315],17,"\003sysstring-append");
lf[316]=C_h_intern(&lf[316],15,"\003sysmake-string");
lf[317]=C_h_intern(&lf[317],20,"\003sysscan-buffer-line");
lf[318]=C_h_intern(&lf[318],4,"noop");
lf[319]=C_h_intern(&lf[319],16,"make-output-port");
lf[320]=C_h_intern(&lf[320],22,"\003syscustom-output-port");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[323]=C_h_intern(&lf[323],13,"file-truncate");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[326]=C_h_intern(&lf[326],4,"lock");
lf[327]=C_h_intern(&lf[327],9,"file-lock");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[329]=C_h_intern(&lf[329],18,"file-lock/blocking");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[331]=C_h_intern(&lf[331],14,"file-test-lock");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[333]=C_h_intern(&lf[333],11,"file-unlock");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[335]=C_h_intern(&lf[335],11,"create-fifo");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[338]=C_h_intern(&lf[338],13,"\003sysfile-info");
lf[339]=C_h_intern(&lf[339],6,"setenv");
lf[340]=C_h_intern(&lf[340],8,"unsetenv");
lf[341]=C_h_intern(&lf[341],25,"get-environment-variables");
lf[342]=C_h_intern(&lf[342],19,"current-environment");
lf[343]=C_h_intern(&lf[343],9,"prot/read");
lf[344]=C_h_intern(&lf[344],10,"prot/write");
lf[345]=C_h_intern(&lf[345],9,"prot/exec");
lf[346]=C_h_intern(&lf[346],9,"prot/none");
lf[347]=C_h_intern(&lf[347],9,"map/fixed");
lf[348]=C_h_intern(&lf[348],10,"map/shared");
lf[349]=C_h_intern(&lf[349],11,"map/private");
lf[350]=C_h_intern(&lf[350],13,"map/anonymous");
lf[351]=C_h_intern(&lf[351],8,"map/file");
lf[352]=C_h_intern(&lf[352],18,"map-file-to-memory");
lf[353]=C_h_intern(&lf[353],4,"mmap");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[355]=C_h_intern(&lf[355],20,"\003syspointer->address");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[357]=C_h_intern(&lf[357],16,"\003sysnull-pointer");
lf[358]=C_h_intern(&lf[358],22,"unmap-file-from-memory");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[360]=C_h_intern(&lf[360],26,"memory-mapped-file-pointer");
lf[361]=C_h_intern(&lf[361],19,"memory-mapped-file\077");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[364]=C_h_intern(&lf[364],19,"seconds->local-time");
lf[365]=C_h_intern(&lf[365],18,"\003sysdecode-seconds");
lf[366]=C_h_intern(&lf[366],15,"current-seconds");
lf[367]=C_h_intern(&lf[367],17,"seconds->utc-time");
lf[368]=C_h_intern(&lf[368],15,"seconds->string");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[370]=C_h_intern(&lf[370],12,"time->string");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[373]=C_h_intern(&lf[373],12,"string->time");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[375]=C_h_intern(&lf[375],19,"local-time->seconds");
lf[376]=C_decode_literal(C_heaptop,"\376U-1.0\000");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[378]=C_h_intern(&lf[378],17,"utc-time->seconds");
lf[379]=C_decode_literal(C_heaptop,"\376U-1.0\000");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[381]=C_h_intern(&lf[381],27,"local-timezone-abbreviation");
lf[382]=C_h_intern(&lf[382],5,"_exit");
lf[383]=C_h_intern(&lf[383],10,"set-alarm!");
lf[384]=C_h_intern(&lf[384],19,"set-buffering-mode!");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[386]=C_h_intern(&lf[386],5,"\000full");
lf[387]=C_h_intern(&lf[387],5,"\000line");
lf[388]=C_h_intern(&lf[388],5,"\000none");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[390]=C_h_intern(&lf[390],14,"terminal-port\077");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[393]=C_h_intern(&lf[393],13,"terminal-name");
lf[394]=C_h_intern(&lf[394],13,"terminal-size");
lf[395]=C_h_intern(&lf[395],6,"\000error");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[397]=C_h_intern(&lf[397],17,"\003sysmake-locative");
lf[398]=C_h_intern(&lf[398],8,"location");
lf[399]=C_h_intern(&lf[399],13,"get-host-name");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[401]=C_h_intern(&lf[401],6,"regexp");
lf[402]=C_h_intern(&lf[402],12,"string-match");
lf[403]=C_h_intern(&lf[403],12,"glob->regexp");
lf[404]=C_h_intern(&lf[404],4,"glob");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[407]=C_h_intern(&lf[407],12,"process-fork");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[409]=C_h_intern(&lf[409],24,"pathname-strip-directory");
lf[410]=C_h_intern(&lf[410],15,"process-execute");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[412]=C_h_intern(&lf[412],16,"\003sysprocess-wait");
lf[413]=C_h_intern(&lf[413],12,"process-wait");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[415]=C_h_intern(&lf[415],18,"current-process-id");
lf[416]=C_h_intern(&lf[416],17,"parent-process-id");
lf[417]=C_h_intern(&lf[417],5,"sleep");
lf[418]=C_h_intern(&lf[418],14,"process-signal");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[420]=C_h_intern(&lf[420],17,"\003sysshell-command");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[423]=C_h_intern(&lf[423],27,"\003sysshell-command-arguments");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[425]=C_h_intern(&lf[425],11,"process-run");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[427]=C_h_intern(&lf[427],11,"\003sysprocess");
lf[428]=C_h_intern(&lf[428],7,"process");
lf[429]=C_h_intern(&lf[429],8,"process*");
lf[430]=C_h_intern(&lf[430],16,"\003syscheck-string");
lf[431]=C_h_intern(&lf[431],12,"\003sysfor-each");
lf[432]=C_h_intern(&lf[432],13,"pathname-file");
lf[433]=C_h_intern(&lf[433],10,"find-files");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[437]=C_h_intern(&lf[437],16,"\003sysdynamic-wind");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[439]=C_h_intern(&lf[439],7,"regexp\077");
lf[440]=C_h_intern(&lf[440],19,"set-root-directory!");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[443]=C_h_intern(&lf[443],21,"set-process-group-id!");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[445]=C_h_intern(&lf[445],18,"getter-with-setter");
lf[446]=C_h_intern(&lf[446],26,"effective-group-id!-setter");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[448]=C_h_intern(&lf[448],12,"set-user-id!");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[450]=C_h_intern(&lf[450],25,"effective-user-id!-setter");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[453]=C_h_intern(&lf[453],23,"\003sysuser-interrupt-hook");
lf[454]=C_h_intern(&lf[454],11,"make-vector");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[457]=C_h_intern(&lf[457],26,"set-file-modification-time");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000!cannot set file modification-time");
lf[459]=C_h_intern(&lf[459],4,"file");
lf[460]=C_h_intern(&lf[460],17,"register-feature!");
lf[461]=C_h_intern(&lf[461],5,"posix");
C_register_lf2(lf,462,create_ptable());
t2=C_mutate(&lf[0] /* (set! c52 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2508,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k2506 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2509 in k2506 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2512 in k2509 in k2506 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2520,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2523,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 516  register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[460]+1)))(3,*((C_word*)lf[460]+1),t2,lf[461]);}

/* k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2526,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2538,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* (set! file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2556,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! file-select-one ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2563,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1 /* (set! fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1 /* (set! fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1 /* (set! fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1 /* (set! fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1 /* (set! fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1 /* (set! open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1 /* (set! open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1 /* (set! open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1 /* (set! open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1 /* (set! perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1 /* (set! perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1 /* (set! perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1 /* (set! file-control ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2620,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[51]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2666,a[2]=t45,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[55]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2704,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[57]+1);
t49=C_mutate((C_word*)lf[58]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2719,a[2]=t48,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[62]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[65]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2800,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[68]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2858,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[70]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t54=C_mutate((C_word*)lf[71]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t55=C_mutate((C_word*)lf[72]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t56=C_mutate(&lf[73] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3138,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[76]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3175,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[77]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3207,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3215,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t60=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8689,a[2]=((C_word)li255),tmp=(C_word)a,a+=3,tmp);
t61=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8695,a[2]=((C_word)li256),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 793  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t59,t60,t61);}

/* a8694 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8695,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[457]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8715,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8728,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 799  ##sys#expand-home-path */
t7=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[459]+1));}

/* k8726 in a8694 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8728,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8705,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t4=(C_word)C_i_foreign_string_argumentp(t1);
/* ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t4=((C_word*)t0)[2];
f_8715(t4,(C_word)stub286(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t2));}}

/* k8703 in k8726 in a8694 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_8715(t2,(C_word)stub286(C_SCHEME_UNDEFINED,t1,((C_word*)t0)[2]));}

/* k8713 in a8694 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 801  posix-error */
t2=lf[3];
f_2538(7,t2,((C_word*)t0)[4],lf[48],lf[457],lf[458],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* a8688 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8689(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8689,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8693,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 795  ##sys#stat */
f_3138(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k8691 in a8688 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8693,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3215,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! file-modification-time ...) */,t1);
t3=C_mutate((C_word*)lf[79]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3217,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[80]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3223,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[81]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3229,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[82]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3235,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[83]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3241,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[84]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3250,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[85]+1 /* (set! character-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3259,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[86]+1 /* (set! block-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[87]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[89]+1 /* (set! socket? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3286,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[90]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3295,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8652,a[2]=((C_word)li254),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 857  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t14,t15,*((C_word*)lf[90]+1));}

/* a8651 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8652,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8656,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8668,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 859  port? */
t5=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k8666 in a8651 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[92]);
if(C_truep(t3)){
t4=(C_word)C_ftell(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
f_8656(2,t5,t4);}
else{
t4=((C_word*)t0)[2];
f_8656(2,t4,C_fix(-1));}}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR));
t3=((C_word*)t0)[2];
f_8656(2,t3,t2);}
else{
/* posixunix.scm: 866  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[97],lf[456],((C_word*)t0)[3]);}}}

/* k8654 in a8651 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8659,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_lessp(t1,C_fix(0)))){
/* posixunix.scm: 868  posix-error */
t3=lf[3];
f_2538(6,t3,t2,lf[48],lf[97],lf[455],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k8657 in k8654 in a8651 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word ab[155],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3355,2,t0,t1);}
t2=C_mutate((C_word*)lf[97]+1 /* (set! file-position ...) */,t1);
t3=*((C_word*)lf[98]+1);
t4=*((C_word*)lf[99]+1);
t5=C_mutate((C_word*)lf[100]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3357,a[2]=t3,a[3]=t4,a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp));
t6=C_mutate((C_word*)lf[103]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3516,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[105]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3538,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[107]+1);
t9=*((C_word*)lf[57]+1);
t10=*((C_word*)lf[108]+1);
t11=C_mutate((C_word*)lf[109]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3560,a[2]=t9,a[3]=t8,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t12=C_mutate((C_word*)lf[113]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3717,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[57]+1);
t14=C_mutate((C_word*)lf[112]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3743,a[2]=t13,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t15=*((C_word*)lf[115]+1);
t16=*((C_word*)lf[116]+1);
t17=*((C_word*)lf[117]+1);
t18=*((C_word*)lf[118]+1);
t19=*((C_word*)lf[107]+1);
t20=*((C_word*)lf[2]+1);
t21=*((C_word*)lf[119]+1);
t22=*((C_word*)lf[120]+1);
t23=*((C_word*)lf[112]+1);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3807,a[2]=t23,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
t25=C_mutate((C_word*)lf[125]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3863,a[2]=t18,a[3]=t16,a[4]=t21,a[5]=t22,a[6]=t24,a[7]=t17,a[8]=t15,a[9]=t19,a[10]=t20,a[11]=((C_word)li54),tmp=(C_word)a,a+=12,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4198,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
t27=C_mutate((C_word*)lf[147]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4213,a[2]=t26,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t28=C_mutate((C_word*)lf[151]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4249,a[2]=t26,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp));
t29=C_mutate((C_word*)lf[152]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4285,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[156]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[152]+1));
t31=*((C_word*)lf[147]+1);
t32=*((C_word*)lf[151]+1);
t33=*((C_word*)lf[152]+1);
t34=*((C_word*)lf[156]+1);
t35=C_mutate((C_word*)lf[157]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4301,a[2]=t31,a[3]=t33,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t36=C_mutate((C_word*)lf[158]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4325,a[2]=t32,a[3]=t34,a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp));
t37=C_mutate((C_word*)lf[159]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4349,a[2]=t31,a[3]=t33,a[4]=((C_word)li66),tmp=(C_word)a,a+=5,tmp));
t38=C_mutate((C_word*)lf[161]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4369,a[2]=t32,a[3]=t34,a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[163]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4389,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[165]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t41=C_mutate((C_word*)lf[166]+1 /* (set! signal/kill ...) */,C_fix((C_word)SIGKILL));
t42=C_mutate((C_word*)lf[167]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t43=C_mutate((C_word*)lf[168]+1 /* (set! signal/hup ...) */,C_fix((C_word)SIGHUP));
t44=C_mutate((C_word*)lf[169]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t45=C_mutate((C_word*)lf[170]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t46=C_mutate((C_word*)lf[171]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t47=C_mutate((C_word*)lf[172]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t48=C_mutate((C_word*)lf[173]+1 /* (set! signal/trap ...) */,C_fix((C_word)SIGTRAP));
t49=C_mutate((C_word*)lf[174]+1 /* (set! signal/quit ...) */,C_fix((C_word)SIGQUIT));
t50=C_mutate((C_word*)lf[175]+1 /* (set! signal/alrm ...) */,C_fix((C_word)SIGALRM));
t51=C_mutate((C_word*)lf[176]+1 /* (set! signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t52=C_mutate((C_word*)lf[177]+1 /* (set! signal/prof ...) */,C_fix((C_word)SIGPROF));
t53=C_mutate((C_word*)lf[178]+1 /* (set! signal/io ...) */,C_fix((C_word)SIGIO));
t54=C_mutate((C_word*)lf[179]+1 /* (set! signal/urg ...) */,C_fix((C_word)SIGURG));
t55=C_mutate((C_word*)lf[180]+1 /* (set! signal/chld ...) */,C_fix((C_word)SIGCHLD));
t56=C_mutate((C_word*)lf[181]+1 /* (set! signal/cont ...) */,C_fix((C_word)SIGCONT));
t57=C_mutate((C_word*)lf[182]+1 /* (set! signal/stop ...) */,C_fix((C_word)SIGSTOP));
t58=C_mutate((C_word*)lf[183]+1 /* (set! signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t59=C_mutate((C_word*)lf[184]+1 /* (set! signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t60=C_mutate((C_word*)lf[185]+1 /* (set! signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t61=C_mutate((C_word*)lf[186]+1 /* (set! signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t62=C_mutate((C_word*)lf[187]+1 /* (set! signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t63=C_mutate((C_word*)lf[188]+1 /* (set! signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t64=C_mutate((C_word*)lf[189]+1 /* (set! signal/winch ...) */,C_fix((C_word)SIGWINCH));
t65=(C_word)C_a_i_list(&a,25,*((C_word*)lf[165]+1),*((C_word*)lf[166]+1),*((C_word*)lf[167]+1),*((C_word*)lf[168]+1),*((C_word*)lf[169]+1),*((C_word*)lf[170]+1),*((C_word*)lf[171]+1),*((C_word*)lf[172]+1),*((C_word*)lf[173]+1),*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1),*((C_word*)lf[189]+1));
t66=C_mutate((C_word*)lf[190]+1 /* (set! signals-list ...) */,t65);
t67=*((C_word*)lf[191]+1);
t68=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4434,a[2]=((C_word*)t0)[2],a[3]=t67,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1182 make-vector */
t69=*((C_word*)lf[454]+1);
((C_proc4)(void*)(*((C_word*)t69+1)))(4,t69,t68,C_fix(256),C_SCHEME_FALSE);}

/* k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4434,2,t0,t1);}
t2=C_mutate((C_word*)lf[192]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4436,a[2]=t1,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[193]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4445,a[2]=t1,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[191]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[194]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4476,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[197]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4522,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[198]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4554,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[199]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4560,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[201]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4575,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4591,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8646,a[2]=((C_word)li253),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1238 set-signal-handler! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t10,*((C_word*)lf[167]+1),t11);}

/* a8645 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8646,3,t0,t1,t2);}
/* posixunix.scm: 1240 ##sys#user-interrupt-hook */
((C_proc2)C_retrieve_proc(*((C_word*)lf[453]+1)))(2,*((C_word*)lf[453]+1),t1);}

/* k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4591,2,t0,t1);}
t2=C_mutate((C_word*)lf[203]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4593,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8628,a[2]=((C_word)li251),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8631,a[2]=((C_word)li252),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1264 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t3,t4,t5);}

/* a8630 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8631,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8641,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1268 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8639 in a8630 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1269 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[448],lf[452],((C_word*)t0)[2]);}

/* a8627 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8628,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub797(C_SCHEME_UNDEFINED));}

/* k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4633,2,t0,t1);}
t2=C_mutate((C_word*)lf[206]+1 /* (set! current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8610,a[2]=((C_word)li249),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8613,a[2]=((C_word)li250),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1272 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t3,t4,t5);}

/* a8612 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8613(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8613,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8623,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1276 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8621 in a8612 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1277 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[450],lf[451],((C_word*)t0)[2]);}

/* a8609 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8610,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub803(C_SCHEME_UNDEFINED));}

/* k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
t2=C_mutate((C_word*)lf[207]+1 /* (set! current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8592,a[2]=((C_word)li247),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8595,a[2]=((C_word)li248),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1281 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t3,t4,t5);}

/* a8594 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8595(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8595,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8605,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1285 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8603 in a8594 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1286 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[448],lf[449],((C_word*)t0)[2]);}

/* a8591 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8592,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub809(C_SCHEME_UNDEFINED));}

/* k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=C_mutate((C_word*)lf[208]+1 /* (set! current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8574,a[2]=((C_word)li245),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8577,a[2]=((C_word)li246),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1289 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t3,t4,t5);}

/* a8576 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8577,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8587,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1293 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8585 in a8576 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1294 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[446],lf[447],((C_word*)t0)[2]);}

/* a8573 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8574,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub815(C_SCHEME_UNDEFINED));}

/* k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1 /* (set! current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[210]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4647,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[120]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4714,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[213]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4728,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[214]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4753,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[215]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4846,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[219]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4909,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[222]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4983,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[224]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t11=C_mutate((C_word*)lf[225]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t12=C_mutate((C_word*)lf[226]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t13=C_mutate((C_word*)lf[227]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t14=C_mutate((C_word*)lf[228]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t15=C_mutate((C_word*)lf[229]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t16=C_mutate((C_word*)lf[230]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t17=C_mutate((C_word*)lf[231]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t18=C_mutate((C_word*)lf[232]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t19=C_mutate((C_word*)lf[233]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t20=C_mutate((C_word*)lf[234]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t21=C_mutate((C_word*)lf[235]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t22=C_mutate((C_word*)lf[236]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t23=C_mutate((C_word*)lf[237]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t24=C_mutate((C_word*)lf[238]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t25=C_mutate((C_word*)lf[239]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t26=C_mutate((C_word*)lf[240]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t27=C_mutate((C_word*)lf[241]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t28=C_mutate((C_word*)lf[242]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t29=C_mutate((C_word*)lf[243]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t30=C_mutate((C_word*)lf[244]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t31=C_mutate((C_word*)lf[245]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t32=C_mutate((C_word*)lf[246]+1 /* (set! errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t33=C_set_block_item(lf[247] /* errno/2big */,0,C_fix(0));
t34=C_set_block_item(lf[248] /* errno/deadlk */,0,C_fix(0));
t35=C_set_block_item(lf[249] /* errno/dom */,0,C_fix(0));
t36=C_set_block_item(lf[250] /* errno/fbig */,0,C_fix(0));
t37=C_set_block_item(lf[251] /* errno/ilseq */,0,C_fix(0));
t38=C_set_block_item(lf[252] /* errno/mlink */,0,C_fix(0));
t39=C_set_block_item(lf[253] /* errno/nametoolong */,0,C_fix(0));
t40=C_set_block_item(lf[254] /* errno/nfile */,0,C_fix(0));
t41=C_set_block_item(lf[255] /* errno/nodev */,0,C_fix(0));
t42=C_set_block_item(lf[256] /* errno/nolck */,0,C_fix(0));
t43=C_set_block_item(lf[257] /* errno/nosys */,0,C_fix(0));
t44=C_set_block_item(lf[258] /* errno/notempty */,0,C_fix(0));
t45=C_set_block_item(lf[259] /* errno/notty */,0,C_fix(0));
t46=C_set_block_item(lf[260] /* errno/nxio */,0,C_fix(0));
t47=C_set_block_item(lf[261] /* errno/range */,0,C_fix(0));
t48=C_set_block_item(lf[262] /* errno/xdev */,0,C_fix(0));
t49=C_mutate((C_word*)lf[263]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5047,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[265]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5074,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t51=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5104,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
t52=C_mutate((C_word*)lf[267]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5128,a[2]=t51,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp));
t53=C_mutate((C_word*)lf[268]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5134,a[2]=t51,a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[269]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5140,a[2]=t51,a[3]=((C_word)li96),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[270]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5146,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t56=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5163,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8535,a[2]=((C_word)li243),tmp=(C_word)a,a+=3,tmp);
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8553,a[2]=((C_word)li244),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1509 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[445]+1)))(4,*((C_word*)lf[445]+1),t56,t57,t58);}

/* a8552 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8553(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8553,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[443]);
t5=(C_word)C_i_check_exact_2(t3,lf[443]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8569,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1521 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8567 in a8552 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1522 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[443],lf[444],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8534 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8535,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[272]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8542,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8548,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1514 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}}

/* k8546 in a8534 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1515 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[272],lf[442],((C_word*)t0)[2]);}

/* k8540 in a8534 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5163,2,t0,t1);}
t2=C_mutate((C_word*)lf[272]+1 /* (set! process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[273]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5165,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[276]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1542 make-string */
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word ab[266],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5202,2,t0,t1);}
t2=C_mutate((C_word*)lf[277]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5203,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[280]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5287,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[283]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[284]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[285]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5312,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5349,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[294]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5364,a[2]=t8,a[3]=t10,a[4]=((C_word)li103),tmp=(C_word)a,a+=5,tmp));
t14=C_mutate((C_word*)lf[295]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5378,a[2]=t8,a[3]=t10,a[4]=((C_word)li104),tmp=(C_word)a,a+=5,tmp));
t15=C_mutate((C_word*)lf[296]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5392,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[302]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5437,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[304]+1);
t18=*((C_word*)lf[305]+1);
t19=C_mutate((C_word*)lf[306]+1 /* (set! custom-input-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5464,a[2]=t17,a[3]=t18,a[4]=((C_word)li126),tmp=(C_word)a,a+=5,tmp));
t20=*((C_word*)lf[319]+1);
t21=*((C_word*)lf[305]+1);
t22=C_mutate((C_word*)lf[320]+1 /* (set! custom-output-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5946,a[2]=t20,a[3]=t21,a[4]=((C_word)li138),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[323]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6205,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6244,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t29=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6318,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[327]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6336,a[2]=t25,a[3]=t27,a[4]=((C_word)li142),tmp=(C_word)a,a+=5,tmp));
t31=C_mutate((C_word*)lf[329]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6351,a[2]=t25,a[3]=t27,a[4]=((C_word)li143),tmp=(C_word)a,a+=5,tmp));
t32=C_mutate((C_word*)lf[331]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6366,a[2]=t25,a[3]=t27,a[4]=((C_word)li144),tmp=(C_word)a,a+=5,tmp));
t33=C_mutate((C_word*)lf[333]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6393,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[335]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6421,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[87]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6464,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[339]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6490,a[2]=((C_word)li148),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[340]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6507,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[341]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6527,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[342]+1 /* (set! current-environment ...) */,*((C_word*)lf[341]+1));
t40=C_mutate((C_word*)lf[343]+1 /* (set! prot/read ...) */,C_fix((C_word)PROT_READ));
t41=C_mutate((C_word*)lf[344]+1 /* (set! prot/write ...) */,C_fix((C_word)PROT_WRITE));
t42=C_mutate((C_word*)lf[345]+1 /* (set! prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t43=C_mutate((C_word*)lf[346]+1 /* (set! prot/none ...) */,C_fix((C_word)PROT_NONE));
t44=C_mutate((C_word*)lf[347]+1 /* (set! map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t45=C_mutate((C_word*)lf[348]+1 /* (set! map/shared ...) */,C_fix((C_word)MAP_SHARED));
t46=C_mutate((C_word*)lf[349]+1 /* (set! map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t47=C_mutate((C_word*)lf[350]+1 /* (set! map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t48=C_mutate((C_word*)lf[351]+1 /* (set! map/file ...) */,C_fix((C_word)MAP_FILE));
t49=C_mutate((C_word*)lf[352]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6631,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[358]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6693,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[360]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6728,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[361]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6737,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate(&lf[362] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6743,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[364]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6762,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[367]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6796,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[368]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6840,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[370]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6901,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[373]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6970,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[375]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7016,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[378]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7031,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[381]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7046,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[382]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7058,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[383]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7074,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[384]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7081,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[390]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7140,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate(&lf[391] /* (set! terminal-check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7159,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[393]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7191,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[394]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7214,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[399]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7249,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t70=*((C_word*)lf[401]+1);
t71=*((C_word*)lf[402]+1);
t72=*((C_word*)lf[403]+1);
t73=*((C_word*)lf[109]+1);
t74=*((C_word*)lf[102]+1);
t75=*((C_word*)lf[98]+1);
t76=C_mutate((C_word*)lf[404]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7261,a[2]=t72,a[3]=t70,a[4]=t73,a[5]=t71,a[6]=t74,a[7]=t75,a[8]=((C_word)li179),tmp=(C_word)a,a+=9,tmp));
t77=C_mutate((C_word*)lf[407]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7375,a[2]=((C_word)li180),tmp=(C_word)a,a+=3,tmp));
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7417,a[2]=((C_word)li181),tmp=(C_word)a,a+=3,tmp);
t79=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7436,a[2]=((C_word)li182),tmp=(C_word)a,a+=3,tmp);
t80=*((C_word*)lf[409]+1);
t81=C_mutate((C_word*)lf[410]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7455,a[2]=t80,a[3]=t79,a[4]=t78,a[5]=((C_word)li188),tmp=(C_word)a,a+=6,tmp));
t82=C_mutate((C_word*)lf[412]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7637,a[2]=((C_word)li189),tmp=(C_word)a,a+=3,tmp));
t83=C_mutate((C_word*)lf[413]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7654,a[2]=((C_word)li192),tmp=(C_word)a,a+=3,tmp));
t84=C_mutate((C_word*)lf[415]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7732,a[2]=((C_word)li193),tmp=(C_word)a,a+=3,tmp));
t85=C_mutate((C_word*)lf[416]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7735,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp));
t86=C_mutate((C_word*)lf[417]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7738,a[2]=((C_word)li195),tmp=(C_word)a,a+=3,tmp));
t87=C_mutate((C_word*)lf[418]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7745,a[2]=((C_word)li196),tmp=(C_word)a,a+=3,tmp));
t88=C_mutate((C_word*)lf[420]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7772,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp));
t89=C_mutate((C_word*)lf[423]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7781,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp));
t90=*((C_word*)lf[407]+1);
t91=*((C_word*)lf[410]+1);
t92=C_mutate((C_word*)lf[425]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7787,a[2]=t90,a[3]=t91,a[4]=((C_word)li199),tmp=(C_word)a,a+=5,tmp));
t93=*((C_word*)lf[163]+1);
t94=*((C_word*)lf[413]+1);
t95=*((C_word*)lf[407]+1);
t96=*((C_word*)lf[410]+1);
t97=*((C_word*)lf[302]+1);
t98=*((C_word*)lf[55]+1);
t99=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7843,a[2]=t94,a[3]=((C_word)li203),tmp=(C_word)a,a+=4,tmp);
t100=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7880,a[2]=t93,a[3]=((C_word)li206),tmp=(C_word)a,a+=4,tmp);
t101=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7900,a[2]=t98,a[3]=((C_word)li207),tmp=(C_word)a,a+=4,tmp);
t102=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7914,a[2]=t98,a[3]=((C_word)li208),tmp=(C_word)a,a+=4,tmp);
t103=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7947,a[2]=t100,a[3]=t95,a[4]=t102,a[5]=t96,a[6]=((C_word)li210),tmp=(C_word)a,a+=7,tmp);
t104=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7992,a[2]=t101,a[3]=((C_word)li211),tmp=(C_word)a,a+=4,tmp);
t105=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8003,a[2]=t101,a[3]=((C_word)li212),tmp=(C_word)a,a+=4,tmp);
t106=C_mutate((C_word*)lf[427]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8014,a[2]=t105,a[3]=t99,a[4]=t104,a[5]=t103,a[6]=((C_word)li215),tmp=(C_word)a,a+=7,tmp));
t107=C_set_block_item(lf[428] /* process */,0,C_SCHEME_UNDEFINED);
t108=C_set_block_item(lf[429] /* process* */,0,C_SCHEME_UNDEFINED);
t109=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8072,a[2]=((C_word)li220),tmp=(C_word)a,a+=3,tmp);
t110=C_mutate((C_word*)lf[428]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8133,a[2]=t109,a[3]=((C_word)li224),tmp=(C_word)a,a+=4,tmp));
t111=C_mutate((C_word*)lf[429]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8193,a[2]=t109,a[3]=((C_word)li228),tmp=(C_word)a,a+=4,tmp));
t112=*((C_word*)lf[404]+1);
t113=*((C_word*)lf[402]+1);
t114=*((C_word*)lf[102]+1);
t115=*((C_word*)lf[432]+1);
t116=*((C_word*)lf[113]+1);
t117=C_mutate((C_word*)lf[433]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8253,a[2]=t116,a[3]=t115,a[4]=t114,a[5]=t112,a[6]=t113,a[7]=((C_word)li241),tmp=(C_word)a,a+=8,tmp));
t118=C_mutate((C_word*)lf[440]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8512,a[2]=((C_word)li242),tmp=(C_word)a,a+=3,tmp));
t119=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t119+1)))(2,t119,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8512,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[440]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8522,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8504,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t7=(C_word)C_i_foreign_string_argumentp(t5);
/* ##sys#make-c-string */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t7=(C_word)stub2249(C_SCHEME_UNDEFINED,C_SCHEME_FALSE);
t8=t4;
f_8522(t8,(C_word)C_fixnum_lessp(t7,C_fix(0)));}}

/* k8502 in set-root-directory! in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub2249(C_SCHEME_UNDEFINED,t1);
t3=((C_word*)t0)[2];
f_8522(t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* k8520 in set-root-directory! in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2409 posix-error */
t2=lf[3];
f_2538(6,t2,((C_word*)t0)[3],lf[48],lf[440],lf[441],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8253(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+22)){
C_save_and_reclaim((void*)tr4r,(void*)f_8253r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8253r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8253r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(22);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t2,a[9]=((C_word)li236),tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8420,a[2]=t5,a[3]=((C_word)li237),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8425,a[2]=t6,a[3]=((C_word)li238),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8430,a[2]=t7,a[3]=((C_word)li240),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action21732238 */
t9=t8;
f_8430(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id21742236 */
t11=t7;
f_8425(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit21752233 */
t13=t6;
f_8420(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body21712180 */
t15=t5;
f_8255(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action2173 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8430,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8436,a[2]=((C_word)li239),tmp=(C_word)a,a+=3,tmp);
/* def-id21742236 */
t3=((C_word*)t0)[2];
f_8425(t3,t1,t2);}

/* a8435 in def-action2173 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8436,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id2174 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8425(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8425,NULL,3,t0,t1,t2);}
/* def-limit21752233 */
t3=((C_word*)t0)[2];
f_8420(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit2175 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8420(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8420,NULL,4,t0,t1,t2,t3);}
/* body21712180 */
t4=((C_word*)t0)[2];
f_8255(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8255(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8255,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[8],lf[433]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8262,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=t7,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
t9=t4;
if(C_truep(t9)){
if(C_truep((C_word)C_fixnump(t4))){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8415,a[2]=t4,a[3]=t7,a[4]=((C_word)li234),tmp=(C_word)a,a+=5,tmp);
t11=t8;
f_8262(t11,t10);}
else{
t10=t4;
t11=t8;
f_8262(t11,t10);}}
else{
t10=t8;
f_8262(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8407,a[2]=((C_word)li235),tmp=(C_word)a,a+=3,tmp));}}

/* f_8407 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8407(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8407,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_8415 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8415(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8415,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8262(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8262,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=t3;
f_8395(2,t4,t2);}
else{
/* posixunix.scm: 2381 regexp? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[439]+1)))(3,*((C_word*)lf[439]+1),t3,((C_word*)t0)[12]);}}

/* k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8395,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8396,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word)li229),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8272,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t2,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8389,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2384 make-pathname */
t5=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[438]);}

/* k8387 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2384 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8272,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8274,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t3,a[11]=((C_word)li233),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_8274(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8274(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8274,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t4,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=t5,a[12]=t1,a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2390 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8293,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2391 pathname-file */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8375,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2398 pproc */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}}

/* k8373 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8375,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8382,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2398 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2399 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_8274(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k8380 in k8373 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2398 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8274(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8369,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[434]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[435]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2391 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_8274(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2392 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8306 in k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8308,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8318,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8320,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,a[5]=((C_word)li230),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word)li231),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8349,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,a[5]=((C_word)li232),tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[437]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8359,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8362,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2397 pproc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k8360 in k8306 in k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2397 action */
t2=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[5];
/* posixunix.scm: 2397 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8274(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k8357 in k8306 in k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2397 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8274(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8348 in k8306 in k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8349,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8324 in k8306 in k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8333,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8347,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2395 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],lf[436]);}

/* k8345 in a8324 in k8306 in k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2395 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8331 in a8324 in k8306 in k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8337,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8340,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2396 pproc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k8338 in k8331 in a8324 in k8306 in k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2396 action */
t2=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[5];
/* posixunix.scm: 2395 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8274(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k8335 in k8331 in a8324 in k8306 in k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2395 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8274(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8319 in k8306 in k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8320,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8316 in k8306 in k8367 in k8291 in loop in k8270 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2393 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8274(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8396 in k8393 in k8260 in body2171 in find-files in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8396(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8396,3,t0,t1,t2);}
/* posixunix.scm: 2382 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8193(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8193r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8193r(t0,t1,t2,t3);}}

static void C_ccall f_8193r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8195,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li225),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8200,a[2]=t4,a[3]=((C_word)li226),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8205,a[2]=t5,a[3]=((C_word)li227),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args21402151 */
t7=t6;
f_8205(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env21412149 */
t9=t5;
f_8200(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body21382146 */
t11=t4;
f_8195(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args2140 in process* in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8205(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8205,NULL,2,t0,t1);}
/* def-env21412149 */
t2=((C_word*)t0)[2];
f_8200(t2,t1,C_SCHEME_FALSE);}

/* def-env2141 in process* in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8200(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8200,NULL,3,t0,t1,t2);}
/* body21382146 */
t3=((C_word*)t0)[2];
f_8195(t3,t1,t2,C_SCHEME_FALSE);}

/* body2138 in process* in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8195(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8195,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2358 %process */
f_8072(t1,lf[429],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8133r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8133r(t0,t1,t2,t3);}}

static void C_ccall f_8133r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8135,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li221),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8140,a[2]=t4,a[3]=((C_word)li222),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8145,a[2]=t5,a[3]=((C_word)li223),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args21092120 */
t7=t6;
f_8145(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env21102118 */
t9=t5;
f_8140(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body21072115 */
t11=t4;
f_8135(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args2109 in process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8145(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8145,NULL,2,t0,t1);}
/* def-env21102118 */
t2=((C_word*)t0)[2];
f_8140(t2,t1,C_SCHEME_FALSE);}

/* def-env2110 in process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8140(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8140,NULL,3,t0,t1,t2);}
/* body21072115 */
t3=((C_word*)t0)[2];
f_8135(t3,t1,t2,C_SCHEME_FALSE);}

/* body2107 in process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8135(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8135,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2355 %process */
f_8072(t1,lf[428],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8072(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8072,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8074,a[2]=t2,a[3]=((C_word)li217),tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8093,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2344 chkstrlst */
t12=t9;
f_8074(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8127,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2346 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[423]+1)))(3,*((C_word*)lf[423]+1),t12,((C_word*)t7)[1]);}}

/* k8125 in %process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8127,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2347 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[420]+1)))(2,*((C_word*)lf[420]+1),t3);}

/* k8129 in k8125 in %process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_8093(2,t3,t2);}

/* k8091 in %process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2348 chkstrlst */
t3=((C_word*)t0)[2];
f_8074(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_8096(2,t3,C_SCHEME_UNDEFINED);}}

/* k8094 in k8091 in %process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8101,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li218),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8107,a[2]=((C_word*)t0)[3],a[3]=((C_word)li219),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8106 in k8094 in k8091 in %process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8107,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2351 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2352 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8100 in k8094 in k8091 in %process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8101,2,t0,t1);}
/* posixunix.scm: 2349 ##sys#process */
t2=*((C_word*)lf[427]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8074(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8074,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8083,a[2]=((C_word*)t0)[2],a[3]=((C_word)li216),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[431]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a8082 in chkstrlst in %process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8083,3,t0,t1,t2);}
t3=*((C_word*)lf[430]+1);
/* g20792080 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* ##sys#process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8014,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8020,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word)li213),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,a[10]=((C_word)li214),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a8025 in ##sys#process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8026,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8037,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8057,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2325 make-on-close */
t12=((C_word*)t0)[3];
f_7843(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k8055 in a8025 in ##sys#process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2324 input-port */
t2=((C_word*)t0)[7];
f_7992(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8035 in a8025 in ##sys#process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8041,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2327 make-on-close */
t4=((C_word*)t0)[6];
f_7843(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k8051 in k8035 in a8025 in ##sys#process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2326 output-port */
t2=((C_word*)t0)[7];
f_8003(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8039 in k8035 in a8025 in ##sys#process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8045,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8049,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2330 make-on-close */
t4=((C_word*)t0)[3];
f_7843(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k8047 in k8039 in k8035 in a8025 in ##sys#process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2329 input-port */
t2=((C_word*)t0)[7];
f_7992(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8043 in k8039 in k8035 in a8025 in ##sys#process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2323 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8019 in ##sys#process in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8020,2,t0,t1);}
/* posixunix.scm: 2318 spawn */
t2=((C_word*)t0)[8];
f_7947(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8003(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8003,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8007,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2314 connect-parent */
t8=((C_word*)t0)[2];
f_7900(t8,t7,t4,t5);}

/* k8005 in output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2315 ##sys#custom-output-port */
((C_proc8)C_retrieve_proc(*((C_word*)lf[320]+1)))(8,*((C_word*)lf[320]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7992(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7992,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7996,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2310 connect-parent */
t8=((C_word*)t0)[2];
f_7900(t8,t7,t4,t5);}

/* k7994 in input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2311 ##sys#custom-input-port */
((C_proc8)C_retrieve_proc(*((C_word*)lf[306]+1)))(8,*((C_word*)lf[306]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7947(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7947,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2297 needed-pipe */
t9=((C_word*)t0)[2];
f_7880(t9,t8,t6);}

/* k7949 in spawn in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2298 needed-pipe */
t3=((C_word*)t0)[2];
f_7880(t3,t2,((C_word*)t0)[5]);}

/* k7952 in k7949 in spawn in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2299 needed-pipe */
t3=((C_word*)t0)[2];
f_7880(t3,t2,((C_word*)t0)[6]);}

/* k7955 in k7952 in k7949 in spawn in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=((C_word*)t0)[4];
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_i_car(t3);
t6=t2;
f_7964(t6,(C_word)C_a_i_cons(&a,2,t4,t5));}
else{
t4=t2;
f_7964(t4,C_SCHEME_FALSE);}}

/* k7962 in k7955 in k7952 in k7949 in spawn in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7964(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7964,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7968,a[2]=((C_word*)t0)[12],a[3]=t1,a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word)li209),tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2302 process-fork */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a7969 in k7962 in k7955 in k7952 in k7949 in spawn in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7974,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2304 connect-child */
t3=((C_word*)t0)[7];
f_7914(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[283]+1));}

/* k7972 in a7969 in k7962 in k7955 in k7952 in k7949 in spawn in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7977,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_i_car(t3);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
/* posixunix.scm: 2305 connect-child */
t7=((C_word*)t0)[5];
f_7914(t7,t2,t6,((C_word*)t0)[2],*((C_word*)lf[284]+1));}
else{
/* posixunix.scm: 2305 connect-child */
t4=((C_word*)t0)[5];
f_7914(t4,t2,C_SCHEME_FALSE,((C_word*)t0)[2],*((C_word*)lf[284]+1));}}

/* k7975 in k7972 in a7969 in k7962 in k7955 in k7952 in k7949 in spawn in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7980,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[4];
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_i_car(t3);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
/* posixunix.scm: 2306 connect-child */
t7=((C_word*)t0)[3];
f_7914(t7,t2,t6,((C_word*)t0)[2],*((C_word*)lf[285]+1));}
else{
/* posixunix.scm: 2306 connect-child */
t4=((C_word*)t0)[3];
f_7914(t4,t2,C_SCHEME_FALSE,((C_word*)t0)[2],*((C_word*)lf[285]+1));}}

/* k7978 in k7975 in k7972 in a7969 in k7962 in k7955 in k7952 in k7949 in spawn in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2307 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7966 in k7962 in k7955 in k7952 in k7949 in spawn in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2300 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* connect-child in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7914(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7914,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7927,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2288 file-close */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k7925 in connect-child in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7927,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7839,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2262 duplicate-fileno */
t6=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k7837 in k7925 in connect-child in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2263 file-close */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7900(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7900,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7913,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2282 file-close */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k7911 in connect-parent in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7880(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7880,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7889,a[2]=((C_word*)t0)[2],a[3]=((C_word)li204),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7895,a[2]=((C_word)li205),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a7894 in needed-pipe in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7895,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a7888 in needed-pipe in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7889,2,t0,t1);}
/* posixunix.scm: 2277 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* make-on-close in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7843(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7843,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7845,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,a[9]=((C_word)li202),tmp=(C_word)a,a+=10,tmp));}

/* f_7845 in make-on-close in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7845,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li200),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li201),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* a7865 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7866,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* posixunix.scm: 2272 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[195],((C_word*)t0)[3],lf[426],((C_word*)t0)[2],t4);}}

/* a7859 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
/* posixunix.scm: 2270 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7787(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7787r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7787r(t0,t1,t2,t3);}}

static void C_ccall f_7787r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7794,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2226 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k7792 in process-run in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7794,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2228 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2230 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[420]+1)))(2,*((C_word*)lf[420]+1),t3);}}
else{
t3=t1;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7811 in k7792 in process-run in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7817,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2230 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[423]+1)))(3,*((C_word*)lf[423]+1),t2,((C_word*)t0)[2]);}

/* k7815 in k7811 in k7792 in process-run in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2230 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7781,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[424],t2));}

/* ##sys#shell-command in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7776,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2216 get-environment-variable */
t3=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[422]);}

/* k7774 in ##sys#shell-command in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[421]);}}

/* process-signal in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7745(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7745r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7745r(t0,t1,t2,t3);}}

static void C_ccall f_7745r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[418]);
t7=(C_word)C_i_check_exact_2(t5,lf[418]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2213 posix-error */
t10=lf[3];
f_2538(7,t10,t1,lf[195],lf[418],lf[419],t2,t5);}
else{
t10=C_SCHEME_UNDEFINED;
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}}

/* sleep in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7738,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1910(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7735,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1907(C_SCHEME_UNDEFINED));}

/* current-process-id in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7732,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1905(C_SCHEME_UNDEFINED));}

/* process-wait in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7654(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_7654r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7654r(t0,t1,t2);}}

static void C_ccall f_7654r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[413]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7684,a[2]=t8,a[3]=t11,a[4]=((C_word)li190),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7690,a[2]=t11,a[3]=((C_word)li191),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t13,t14);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* a7689 in process-wait in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7690,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2199 posix-error */
t6=lf[3];
f_2538(6,t6,t1,lf[195],lf[413],lf[414],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2200 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a7683 in process-wait in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7684,2,t0,t1);}
/* posixunix.scm: 2197 ##sys#process-wait */
((C_proc4)C_retrieve_proc(*((C_word*)lf[412]+1)))(4,*((C_word*)lf[412]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7637,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
if(C_truep(t6)){
t7=(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status));
/* posixunix.scm: 2184 values */
C_values(5,0,t1,t5,t6,t7);}
else{
if(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))){
t7=(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status));
/* posixunix.scm: 2184 values */
C_values(5,0,t1,t5,t6,t7);}
else{
t7=(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status));
/* posixunix.scm: 2184 values */
C_values(5,0,t1,t5,t6,t7);}}}

/* process-execute in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7455(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_7455r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7455r(t0,t1,t2,t3);}}

static void C_ccall f_7455r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li185),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7584,a[2]=t4,a[3]=((C_word)li186),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7589,a[2]=t5,a[3]=((C_word)li187),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist18171864 */
t7=t6;
f_7589(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist18181862 */
t9=t5;
f_7584(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body18151823 */
t11=t4;
f_7457(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist1817 in process-execute in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7589,NULL,2,t0,t1);}
/* def-envlist18181862 */
t2=((C_word*)t0)[2];
f_7584(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist1818 in process-execute in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7584,NULL,3,t0,t1,t2);}
/* body18151823 */
t3=((C_word*)t0)[2];
f_7457(t3,t1,t2,C_SCHEME_FALSE);}

/* body1815 in process-execute in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7457(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7457,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[410]);
t5=(C_word)C_i_check_list_2(t2,lf[410]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7467,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2152 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k7465 in body1815 in process-execute in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7467,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_7417(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7475,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li184),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_7475(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* doloop1827 in k7465 in body1815 in process-execute in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7475(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7475,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_7417(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7488,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[410]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7521,a[2]=((C_word*)t0)[3],a[3]=((C_word)li183),tmp=(C_word)a,a+=4,tmp);
t8=t5;
f_7488(t8,f_7521(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_7488(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[410]);
t6=(C_word)C_block_size(t4);
t7=f_7417(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* doloop1835 in doloop1827 in k7465 in body1815 in process-execute in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_7521(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_7436(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[410]);
t5=(C_word)C_block_size(t3);
t6=f_7436(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k7486 in doloop1827 in k7465 in body1815 in process-execute in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7488(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7488,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7513,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2166 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k7511 in k7486 in doloop1827 in k7465 in body1815 in process-execute in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2166 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7489 in k7486 in doloop1827 in k7465 in body1815 in process-execute in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub1788(C_SCHEME_UNDEFINED);
t5=(C_word)stub1800(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2173 posix-error */
t6=lf[3];
f_2538(6,t6,((C_word*)t0)[3],lf[195],lf[410],lf[411],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_7436(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub1793(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_7417(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub1781(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7375(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7375r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7375r(t0,t1,t2);}}

static void C_ccall f_7375r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub1752(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2137 posix-error */
t5=lf[3];
f_2538(5,t5,t1,lf[195],lf[407],lf[408]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_i_vector_ref(t2,C_fix(0));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7400,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* g17641765 */
t9=t7;
((C_proc2)C_retrieve_proc(t9))(2,t9,t8);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k7398 in process-fork in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1769(C_SCHEME_UNDEFINED,t3));}

/* glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7261(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_7261r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7261r(t0,t1,t2);}}

static void C_ccall f_7261r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=((C_word)li178),tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_7267(t6,t1,t2);}

/* conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7267(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7267,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7282,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word)li174),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word)li177),tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a7287 in conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7288,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7367,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t7=t3;
/* posixunix.scm: 2122 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}
else{
/* posixunix.scm: 2122 make-pathname */
t7=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,C_SCHEME_FALSE,lf[406],t4);}}

/* k7365 in a7287 in conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2122 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7290 in a7287 in conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2123 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k7293 in k7290 in a7287 in conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7302,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=((C_word*)t0)[5];
/* posixunix.scm: 2124 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}
else{
/* posixunix.scm: 2124 directory */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[405],C_SCHEME_TRUE);}}

/* k7300 in k7293 in k7290 in a7287 in conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7302,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7304,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li176),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_7304(t5,((C_word*)t0)[2],t1);}

/* loop in k7300 in k7293 in k7290 in a7287 in conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7304(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7304,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixunix.scm: 2125 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_7267(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7321,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixunix.scm: 2126 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k7319 in loop in k7300 in k7293 in k7290 in a7287 in conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7321,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7325,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li175),tmp=(C_word)a,a+=7,tmp);
/* g17411742 */
t3=t2;
f_7325(t3,((C_word*)t0)[2],t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* posixunix.scm: 2128 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7304(t3,((C_word*)t0)[2],t2);}}

/* g1741 in k7319 in loop in k7300 in k7293 in k7290 in a7287 in conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7325,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7333,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* posixunix.scm: 2127 make-pathname */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k7331 in g1741 in k7319 in loop in k7300 in k7293 in k7290 in a7287 in conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7337,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixunix.scm: 2127 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7304(t4,t2,t3);}

/* k7335 in k7331 in g1741 in k7319 in loop in k7300 in k7293 in k7290 in a7287 in conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7337,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a7281 in conc-loop in glob in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7282,2,t0,t1);}
/* posixunix.scm: 2121 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7253,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub1692(t3),C_fix(0));}

/* k7251 in get-host-name in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7256,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* posixunix.scm: 2103 posix-error */
t3=lf[3];
f_2538(5,t3,t2,lf[395],lf[399],lf[400]);}}

/* k7254 in k7251 in get-host-name in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7214,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7218,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2084 ##sys#terminal-check */
f_7159(t3,lf[394],t2);}

/* k7216 in terminal-size in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7218,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7238,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[397]+1)))(6,*((C_word*)lf[397]+1),t4,t2,C_fix(0),C_SCHEME_FALSE,lf[398]);}

/* k7236 in k7216 in terminal-size in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[397]+1)))(6,*((C_word*)lf[397]+1),t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[398]);}

/* k7240 in k7236 in k7216 in terminal-size in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_pointer_argumentp(t3);
t6=(C_word)C_i_foreign_pointer_argumentp(t1);
t7=(C_word)stub1673(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(C_word)C_eqp(C_fix(0),t7);
if(C_truep(t8)){
/* posixunix.scm: 2091 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2092 posix-error */
t9=lf[3];
f_2538(6,t9,((C_word*)t0)[4],lf[395],lf[394],lf[396],((C_word*)t0)[6]);}}

/* terminal-name in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7191,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7195,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2076 ##sys#terminal-check */
f_7159(t3,lf[393],t2);}

/* k7193 in terminal-name in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7195,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub1663(t4,t5);
/* ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* ##sys#terminal-check in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7159(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7159,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7163,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2068 ##sys#check-port */
t5=*((C_word*)lf[155]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k7161 in ##sys#terminal-check in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[92],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* posixunix.scm: 2071 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[392],((C_word*)t0)[4]);}}

/* terminal-port? in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7140,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7144,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2063 ##sys#check-port */
t4=*((C_word*)lf[155]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[390]);}

/* k7142 in terminal-port? in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2064 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[301]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k7145 in k7142 in terminal-port? in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_tty_portp(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* set-buffering-mode! in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_7081r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_7081r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7081r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7085,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2048 ##sys#check-port */
t6=*((C_word*)lf[155]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[384]);}

/* k7083 in set-buffering-mode! in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7085,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[386]);
if(C_truep(t6)){
t7=t5;
f_7091(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[387]);
if(C_truep(t7)){
t8=C_fix((C_word)_IOLBF);
t9=t5;
f_7091(2,t9,t8);}
else{
t8=(C_word)C_eqp(t4,lf[388]);
if(C_truep(t8)){
t9=t5;
f_7091(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2054 ##sys#error */
t9=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[384],lf[389],((C_word*)t0)[4],((C_word*)t0)[2]);}}}}

/* k7089 in k7083 in set-buffering-mode! in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7091,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[384]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7100,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(7));
t5=(C_word)C_eqp(lf[92],t4);
if(C_truep(t5)){
t6=(C_word)C_setvbuf(((C_word*)t0)[2],t1,((C_word*)t0)[4]);
t7=t3;
f_7100(t7,(C_word)C_fixnum_lessp(t6,C_fix(0)));}
else{
t6=t3;
f_7100(t6,C_SCHEME_TRUE);}}

/* k7098 in k7089 in k7083 in set-buffering-mode! in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7100(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2060 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],lf[384],lf[385],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-alarm! in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7074,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1630(C_SCHEME_UNDEFINED,t3));}

/* _exit in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7058r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7058r(t0,t1,t2);}}

static void C_ccall f_7058r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
t4=t1;
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub1625(C_SCHEME_UNDEFINED,t5));}
else{
t3=t1;
t4=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub1625(C_SCHEME_UNDEFINED,t4));}}

/* local-timezone-abbreviation in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7046,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub1620(t2),C_fix(0));}

/* utc-time->seconds in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7031,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7035,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2015 check-time-vector */
f_6743(t3,lf[378],t2);}

/* k7033 in utc-time->seconds in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7035,2,t0,t1);}
t2=(C_word)C_a_timegm(&a,1,((C_word*)t0)[3]);
if(C_truep((C_word)C_flonum_equalp(lf[379],t2))){
/* posixunix.scm: 2018 ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[378],lf[380],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* local-time->seconds in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7016,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7020,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2008 check-time-vector */
f_6743(t3,lf[375],t2);}

/* k7018 in local-time->seconds in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7020,2,t0,t1);}
t2=(C_word)C_a_mktime(&a,1,((C_word*)t0)[3]);
if(C_truep((C_word)C_flonum_equalp(lf[376],t2))){
/* posixunix.scm: 2011 ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[375],lf[377],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* string->time in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6970(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6970r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6970r(t0,t1,t2,t3);}}

static void C_ccall f_6970r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6974,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_6974(2,t5,lf[374]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_6974(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k6972 in string->time in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6974,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[373]);
t3=(C_word)C_i_check_string_2(t1,lf[373]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6987,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2005 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* k6985 in k6972 in string->time in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6991,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2005 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6989 in k6985 in k6972 in string->time in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6991,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub1592(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6901(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_6901r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6901r(t0,t1,t2,t3);}}

static void C_ccall f_6901r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6905,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_6905(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_6905(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k6903 in time->string in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1989 check-time-vector */
f_6743(t2,lf[370],((C_word*)t0)[2]);}

/* k6906 in k6903 in time->string in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6908,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[370]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6927,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1993 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1556(t4,t3),C_fix(0));}}

/* k6928 in k6906 in k6903 in time->string in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1997 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1998 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[370],lf[372],((C_word*)t0)[2]);}}

/* k6925 in k6906 in k6903 in time->string in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6927,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub1562(t3,t2,t1),C_fix(0));}

/* k6915 in k6906 in k6903 in time->string in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1994 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[370],lf[371],((C_word*)t0)[2]);}}

/* seconds->string in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6840(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6840r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6840r(t0,t1,t2);}}

static void C_ccall f_6840r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6844,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* posixunix.scm: 1978 current-seconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[366]+1)))(2,*((C_word*)lf[366]+1),t3);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_6844(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k6842 in seconds->string in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6844,2,t0,t1);}
t2=(C_word)C_i_check_number_2(t1,lf[368]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6850,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=t1;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_integer_argumentp(t4);
t7=(C_word)stub1535(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k6848 in k6842 in seconds->string in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1982 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1983 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[368],lf[369],((C_word*)t0)[2]);}}

/* seconds->utc-time in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6796(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6796r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6796r(t0,t1,t2);}}

static void C_ccall f_6796r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6800,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* posixunix.scm: 1972 current-seconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[366]+1)))(2,*((C_word*)lf[366]+1),t3);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_check_number_2(t5,lf[367]);
/* posixunix.scm: 1974 ##sys#decode-seconds */
t7=*((C_word*)lf[365]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t5,C_SCHEME_TRUE);}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k6798 in seconds->utc-time in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_number_2(t1,lf[367]);
/* posixunix.scm: 1974 ##sys#decode-seconds */
t3=*((C_word*)lf[365]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* seconds->local-time in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6762r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6762r(t0,t1,t2);}}

static void C_ccall f_6762r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6766,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* posixunix.scm: 1968 current-seconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[366]+1)))(2,*((C_word*)lf[366]+1),t3);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_check_number_2(t5,lf[364]);
/* posixunix.scm: 1970 ##sys#decode-seconds */
t7=*((C_word*)lf[365]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t5,C_SCHEME_FALSE);}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k6764 in seconds->local-time in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_number_2(t1,lf[364]);
/* posixunix.scm: 1970 ##sys#decode-seconds */
t3=*((C_word*)lf[365]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* check-time-vector in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6743(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6743,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1966 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[363],t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* memory-mapped-file? in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6737,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[353]));}

/* memory-mapped-file-pointer in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6728,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[353],lf[360]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6693(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6693r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6693r(t0,t1,t2,t3);}}

static void C_ccall f_6693r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=(C_word)C_i_check_structure_2(t2,lf[353],lf[358]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub1482(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=C_SCHEME_UNDEFINED;
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
/* posixunix.scm: 1952 posix-error */
t12=lf[3];
f_2538(7,t12,t1,lf[48],lf[358],lf[359],t2,t6);}}

/* map-file-to-memory in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_6631r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_6631r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_6631r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6635,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_6635(2,t10,t2);}
else{
/* posixunix.scm: 1937 ##sys#null-pointer */
t10=*((C_word*)lf[357]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k6633 in map-file-to-memory in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6635,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6641,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_blockp(t1))){
if(C_truep((C_word)C_specialp(t1))){
t5=t4;
f_6641(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1940 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[60],lf[352],lf[356],t1);}}
else{
/* posixunix.scm: 1940 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[60],lf[352],lf[356],t1);}}

/* k6639 in k6633 in map-file-to-memory in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6641,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub1451(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6647,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6660,a[2]=t14,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t15,tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1942 ##sys#pointer->address */
t17=*((C_word*)lf[355]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,t14);}

/* k6658 in k6639 in k6633 in map-file-to-memory in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6660,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1943 posix-error */
t3=lf[3];
f_2538(11,t3,((C_word*)t0)[10],lf[48],lf[352],lf[354],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,3,lf[353],((C_word*)t0)[2],((C_word*)t0)[8]));}}

/* k6645 in k6639 in k6633 in map-file-to-memory in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6647,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[353],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* get-environment-variables in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6527,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6533,a[2]=t3,a[3]=((C_word)li151),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6533(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6533(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6533,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6537,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1433(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k6535 in loop in get-environment-variables in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6537,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6545,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li150),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_6545(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k6535 in loop in get-environment-variables in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6545(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6545,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6571,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1901 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1904 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k6569 in scan in k6535 in loop in get-environment-variables in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6575,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1902 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k6573 in k6569 in scan in k6535 in loop in get-environment-variables in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6575,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6563,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1903 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6533(t5,t3,t4);}

/* k6561 in k6573 in k6569 in scan in k6535 in loop in get-environment-variables in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6563,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6507,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[340]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6515,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1890 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6513 in unsetenv in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_unsetenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6490,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[339]);
t5=(C_word)C_i_check_string_2(t3,lf[339]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6501,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1885 ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k6499 in setenv in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6505,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1885 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6503 in k6499 in setenv in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6464,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6471,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6488,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1873 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k6486 in fifo? in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1873 ##sys#file-info */
t2=*((C_word*)lf[338]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6469 in fifo? in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1876 posix-error */
t2=lf[3];
f_2538(6,t2,((C_word*)t0)[3],lf[48],lf[87],lf[337],((C_word*)t0)[2]);}}

/* create-fifo in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6421(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6421r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6421r(t0,t1,t2,t3);}}

static void C_ccall f_6421r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[335]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6428,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_6428(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_6428(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k6426 in create-fifo in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6428(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6428,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[335]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6449,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1867 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k6447 in k6426 in create-fifo in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1867 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6443 in k6426 in create-fifo in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1868 posix-error */
t3=lf[3];
f_2538(7,t3,((C_word*)t0)[3],lf[48],lf[335],lf[336],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* file-unlock in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6393,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[326],lf[333]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1857 posix-error */
t9=lf[3];
f_2538(6,t9,t1,lf[48],lf[333],lf[334],t2);}
else{
t9=C_SCHEME_UNDEFINED;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* file-test-lock in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6366r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6366r(t0,t1,t2,t3);}}

static void C_ccall f_6366r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6370,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1848 setup */
f_6244(t4,t2,t3,lf[331]);}

/* k6368 in file-test-lock in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1850 err */
f_6318(((C_word*)t0)[3],lf[332],t1,lf[331]);}}

/* file-lock/blocking in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6351r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6351r(t0,t1,t2,t3);}}

static void C_ccall f_6351r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6355,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1842 setup */
f_6244(t4,t2,t3,lf[329]);}

/* k6353 in file-lock/blocking in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1844 err */
f_6318(((C_word*)t0)[2],lf[330],t1,lf[329]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* file-lock in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6336r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6336r(t0,t1,t2,t3);}}

static void C_ccall f_6336r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6340,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1836 setup */
f_6244(t4,t2,t3,lf[327]);}

/* k6338 in file-lock in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1838 err */
f_6318(((C_word*)t0)[2],lf[328],t1,lf[327]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* err in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6318(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6318,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1833 posix-error */
t8=lf[3];
f_2538(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6244(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6244,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6266,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1825 ##sys#check-port */
t16=*((C_word*)lf[155]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k6264 in setup in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6266,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_6272(t6,t5);}
else{
t5=t3;
f_6272(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k6270 in k6264 in setup in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6272,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[326],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6205,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[323]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6215,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6222,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6229,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6233,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1808 ##sys#expand-home-path */
t9=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t7=(C_word)C_ftruncate(t2,t3);
t8=t5;
f_6215(t8,(C_word)C_fixnum_lessp(t7,C_fix(0)));}
else{
/* posixunix.scm: 1810 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[323],lf[325],t2);}}}

/* k6231 in file-truncate in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1808 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6227 in file-truncate in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_truncate(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_6215(t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* k6220 in file-truncate in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6215(t2,(C_word)C_fixnum_lessp(t1,C_fix(0)));}

/* k6213 in file-truncate in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 1812 posix-error */
t2=lf[3];
f_2538(7,t2,((C_word*)t0)[4],lf[48],lf[323],lf[324],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_5946r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5946r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5946r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li134),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6132,a[2]=t6,a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6137,a[2]=t7,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6142,a[2]=t8,a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?12741340 */
t10=t9;
f_6142(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi12751338 */
t12=t8;
f_6137(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close12761335 */
t14=t7;
f_6132(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* body12721281 */
t16=t6;
f_5948(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-nonblocking?1274 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6142,NULL,2,t0,t1);}
/* def-bufi12751338 */
t2=((C_word*)t0)[2];
f_6137(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1275 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6137(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6137,NULL,3,t0,t1,t2);}
/* def-on-close12761335 */
t3=((C_word*)t0)[2];
f_6132(t3,t1,t2,C_fix(0));}

/* def-on-close1276 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6132(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6132,NULL,4,t0,t1,t2,t3);}
/* body12721281 */
t4=((C_word*)t0)[2];
f_5948(t4,t1,t2,t3,*((C_word*)lf[318]+1));}

/* body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5948(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5948,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5952,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1750 ##sys#file-nonblocking! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_5952(2,t6,C_SCHEME_UNDEFINED);}}

/* k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5952,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5954,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word)li127),tmp=(C_word)a,a+=7,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_6000(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6044,a[2]=t3,a[3]=((C_word)li131),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6058,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1769 ##sys#make-string */
t12=*((C_word*)lf[316]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_6058(2,t12,((C_word*)t0)[6]);}}}

/* k6056 in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6058,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_6000(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6059,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li133),tmp=(C_word)a,a+=7,tmp));}

/* f_6059 in k6056 in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6059,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6076,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word)li132),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6076(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1785 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5954(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_6076(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6076,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6086,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1775 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5954(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_difference(t4,t2);
/* posixunix.scm: 1780 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k6084 in loop */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1777 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6076(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_6044 in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6044,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1768 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5954(t4,t1,t2,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5998 in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6000(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6000,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6004,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6009,a[2]=((C_word*)t0)[9],a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6015,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li129),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6036,a[2]=((C_word*)t0)[9],a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1788 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t5,t6,t7,t8);}

/* a6035 in k5998 in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6036,2,t0,t1);}
/* posixunix.scm: 1798 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* a6014 in k5998 in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6015,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6025,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1795 posix-error */
t3=lf[3];
f_2538(7,t3,t2,lf[48],((C_word*)t0)[3],lf[322],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1796 on-close */
t3=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}}}

/* k6023 in a6014 in k5998 in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1796 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6008 in k5998 in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6009,3,t0,t1,t2);}
/* posixunix.scm: 1790 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* k6002 in k5998 in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6004,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6007,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1799 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6005 in k6002 in k5998 in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5954(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5954,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5970,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1758 ##sys#thread-yield! */
t8=*((C_word*)lf[308]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1760 posix-error */
t7=lf[3];
f_2538(7,t7,t1,((C_word*)t0)[3],lf[48],lf[321],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5989,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1762 ##sys#substring */
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k5987 in poke in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1762 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5954(t3,((C_word*)t0)[2],t1,t2);}

/* k5968 in poke in k5950 in body1272 in ##sys#custom-output-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1759 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5954(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_5464r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5464r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5464r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,a[7]=((C_word)li121),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5853,a[2]=t6,a[3]=((C_word)li122),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5858,a[2]=t7,a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5863,a[2]=t8,a[3]=((C_word)li124),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5868,a[2]=t9,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?11011245 */
t11=t10;
f_5868(t11,t1);}
else{
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi11021243 */
t13=t9;
f_5863(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close11031240 */
t15=t8;
f_5858(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?11041236 */
t17=t7;
f_5853(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
/* body10991109 */
t19=t6;
f_5466(t19,t1,t11,t13,t15,t17);}
else{
/* ##sys#error */
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[0],t18);}}}}}}

/* def-nonblocking?1101 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5868,NULL,2,t0,t1);}
/* def-bufi11021243 */
t2=((C_word*)t0)[2];
f_5863(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1102 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5863(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5863,NULL,3,t0,t1,t2);}
/* def-on-close11031240 */
t3=((C_word*)t0)[2];
f_5858(t3,t1,t2,C_fix(1));}

/* def-on-close1103 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5858(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5858,NULL,4,t0,t1,t2,t3);}
/* def-more?11041236 */
t4=((C_word*)t0)[2];
f_5853(t4,t1,t2,t3,*((C_word*)lf[318]+1));}

/* def-more?1104 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5853(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5853,NULL,5,t0,t1,t2,t3,t4);}
/* body10991109 */
t5=((C_word*)t0)[2];
f_5466(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5466(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5466,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5470,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1624 ##sys#file-nonblocking! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_5470(2,t7,C_SCHEME_UNDEFINED);}}

/* k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5470,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1626 ##sys#make-string */
t5=*((C_word*)lf[316]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_5476(2,t5,((C_word*)t0)[10]);}}

/* k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5476,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5477,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li107),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5500,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5508,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,a[10]=((C_word)li109),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5590,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5595,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word)li110),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5608,a[2]=t6,a[3]=t3,a[4]=t5,a[5]=((C_word)li111),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=((C_word)li112),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5641,a[2]=t8,a[3]=t7,a[4]=((C_word)li113),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5650,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li115),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5726,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,a[6]=((C_word)li120),tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1674 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t18))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a5725 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5726,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5732,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li119),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_5732(t7,t1,C_SCHEME_FALSE);}

/* loop in a5725 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5732(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5732,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5734,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li116),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5812,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word)li117),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5818,a[2]=((C_word*)t0)[2],a[3]=((C_word)li118),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5828,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1739 fetch */
t5=((C_word*)t0)[5];
f_5508(t5,t4);}}

/* k5826 in loop in a5725 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1741 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5732(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a5817 in loop in a5725 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5818,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1736 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5732(t4,t1,t2);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* a5811 in loop in a5725 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5812,2,t0,t1);}
/* posixunix.scm: 1734 ##sys#scan-buffer-line */
((C_proc6)C_retrieve_proc(*((C_word*)lf[317]+1)))(6,*((C_word*)lf[317]+1),t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a5725 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5734,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5741,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_5741(2,t8,(C_truep(t7)?t7:lf[314]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5784,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1716 ##sys#make-string */
t8=*((C_word*)lf[316]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k5782 in bumper in loop in a5725 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1722 ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[315]+1)))(4,*((C_word*)lf[315]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=t1;
t7=((C_word*)t0)[2];
f_5741(2,t7,t6);}}

/* k5739 in bumper in loop in a5725 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5741,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5751,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1726 fetch */
t5=((C_word*)t0)[3];
f_5508(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1731 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k5749 in k5739 in bumper in loop in a5725 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1727 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5649 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5650,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5658,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_5658(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_5658(t8,(C_word)C_fixnum_difference(t7,t5));}}

/* k5656 in a5649 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5658,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5660,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li114),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_5660(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k5656 in a5649 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5660(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5660,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* posixunix.scm: 1702 loop */
t19=t1;
t20=t13;
t21=t14;
t22=t15;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5708,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1704 fetch */
t7=((C_word*)t0)[2];
f_5508(t7,t6);}}}

/* k5706 in loop in k5656 in a5649 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* posixunix.scm: 1707 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5660(t3,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* a5640 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5645,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1692 fetch */
t3=((C_word*)t0)[2];
f_5508(t3,t2);}

/* k5643 in a5640 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1693 peek */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5500(((C_word*)t0)[2]));}

/* a5619 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5620,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5630,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1689 posix-error */
t3=lf[3];
f_2538(7,t3,t2,lf[48],((C_word*)t0)[3],lf[313],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1690 on-close */
t3=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}}}

/* k5628 in a5619 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1690 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a5607 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5608,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1684 ready? */
t3=((C_word*)t0)[2];
f_5477(t3,t1);}}

/* a5594 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5599,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1676 fetch */
t3=((C_word*)t0)[2];
f_5508(t3,t2);}

/* k5597 in a5594 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_5500(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k5588 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5590,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5593,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1743 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k5591 in k5588 in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5508,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5520,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li108),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_5520(t5,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop in fetch in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5520,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5536,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1651 ##sys#thread-block-for-i/o! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[309]+1)))(5,*((C_word*)lf[309]+1),t5,*((C_word*)lf[310]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1654 posix-error */
t5=lf[3];
f_2538(7,t5,t1,lf[48],((C_word*)t0)[6],lf[311],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1658 more? */
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k5555 in loop in fetch in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5560,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1660 ##sys#thread-yield! */
t3=*((C_word*)lf[308]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5566,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t3)[1]);
t9=C_set_block_item(((C_word*)t0)[4],0,C_fix(0));
t10=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
/* posixunix.scm: 1666 posix-error */
t7=lf[3];
f_2538(7,t7,t4,lf[48],((C_word*)t0)[3],lf[312],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t3)[1]);
t7=C_set_block_item(((C_word*)t0)[4],0,C_fix(0));
t8=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}}

/* k5564 in k5555 in loop in fetch in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5558 in k5555 in loop in fetch in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1661 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5520(t2,((C_word*)t0)[2]);}

/* k5534 in loop in fetch in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1652 ##sys#thread-yield! */
t3=*((C_word*)lf[308]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5537 in k5534 in loop in fetch in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1653 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5520(t2,((C_word*)t0)[2]);}

/* peek in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_5500(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]))){
return(C_SCHEME_END_OF_FILE);}
else{
t1=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);
return(t1);}}

/* ready? in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5477(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5477,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1632 ##sys#file-select-one */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[3]);}

/* k5479 in ready? in k5474 in k5468 in body1099 in ##sys#custom-input-port in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* posixunix.scm: 1636 posix-error */
t4=lf[3];
f_2538(7,t4,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[307],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t1));}}

/* duplicate-fileno in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5437r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5437r(t0,t1,t2,t3);}}

static void C_ccall f_5437r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[302]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5444,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_5444(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[302]);
t8=t5;
f_5444(t8,(C_word)C_dup2(t2,t6));}}

/* k5442 in duplicate-fileno in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5444,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5447,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1617 posix-error */
t3=lf[3];
f_2538(6,t3,t2,lf[48],lf[302],lf[303],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k5445 in k5442 in duplicate-fileno in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5392,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5396,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1599 ##sys#check-port */
t4=*((C_word*)lf[155]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[296]);}

/* k5394 in port->fileno in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5396,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[297],t2);
if(C_truep(t3)){
/* posixunix.scm: 1600 ##sys#tcp-port->fileno */
((C_proc3)C_retrieve_proc(*((C_word*)lf[298]+1)))(3,*((C_word*)lf[298]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1601 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[301]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k5429 in k5394 in port->fileno in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5431,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1606 posix-error */
t2=lf[3];
f_2538(6,t2,((C_word*)t0)[3],lf[60],lf[296],lf[299],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5414,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1604 posix-error */
t4=lf[3];
f_2538(6,t4,t3,lf[48],lf[296],lf[300],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k5412 in k5429 in k5394 in port->fileno in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5378r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5378r(t0,t1,t2,t3);}}

static void C_ccall f_5378r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[295]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5390,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1595 mode */
f_5312(t5,C_SCHEME_FALSE,t3);}

/* k5388 in open-output-file* in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5390,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1595 check */
f_5349(((C_word*)t0)[2],lf[295],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5364(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5364r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5364r(t0,t1,t2,t3);}}

static void C_ccall f_5364r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[294]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5376,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1591 mode */
f_5312(t5,C_SCHEME_TRUE,t3);}

/* k5374 in open-input-file* in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5376,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1591 check */
f_5349(((C_word*)t0)[2],lf[294],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5349(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5349,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1584 posix-error */
t6=lf[3];
f_2538(6,t6,t1,lf[48],t2,lf[292],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5362,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1585 ##sys#make-port */
t7=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[145]+1),lf[293],lf[92]);}}

/* k5360 in check in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* mode in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5312(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5312,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5320,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[286]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1578 ##sys#error */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[287],t5);}
else{
/* posixunix.scm: 1574 ##sys#make-c-string */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,lf[288]);}}
else{
/* posixunix.scm: 1579 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[289],t5);}}
else{
if(C_truep(t2)){
/* posixunix.scm: 1574 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[290]);}
else{
/* posixunix.scm: 1574 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[291]);}}}

/* k5318 in mode in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1574 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5287,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[280]);
t5=(C_word)C_i_check_string_2(t3,lf[280]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5300,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=t3;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5268,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t10=(C_word)C_i_foreign_string_argumentp(t7);
/* ##sys#make-c-string */
t11=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
t10=t9;
f_5268(2,t10,C_SCHEME_FALSE);}}

/* k5266 in file-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5272,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=(C_word)stub1014(C_SCHEME_UNDEFINED,t1,C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
f_5300(t4,(C_word)C_fixnum_lessp(t3,C_fix(0)));}}

/* k5270 in k5266 in file-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1014(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_5300(t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* k5298 in file-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5300(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 1559 posix-error */
t2=lf[3];
f_2538(7,t2,((C_word*)t0)[4],lf[48],lf[281],lf[282],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* read-symbolic-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5203r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5203r(t0,t1,t2,t3);}}

static void C_ccall f_5203r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5207,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5207(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5207(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5205 in read-symbolic-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5207,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[277]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5242,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1545 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}

/* k5240 in k5205 in read-symbolic-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1545 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5212 in k5205 in read-symbolic-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5214,2,t0,t1);}
t2=(C_word)C_do_readlink(t1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5217,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1547 posix-error */
t4=lf[3];
f_2538(6,t4,t3,lf[48],lf[277],lf[279],((C_word*)t0)[2]);}
else{
t4=t3;
f_5217(2,t4,C_SCHEME_UNDEFINED);}}

/* k5215 in k5212 in k5205 in read-symbolic-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5220,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1548 substring */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5218 in k5215 in k5212 in k5205 in read-symbolic-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5226,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 1549 symbolic-link? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t2,t1);}
else{
t3=t1;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5224 in k5218 in k5215 in k5212 in k5205 in read-symbolic-link in k5200 in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 1550 read-symbolic-link */
((C_proc4)C_retrieve_proc(*((C_word*)lf[277]+1)))(4,*((C_word*)lf[277]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[278]);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* create-symbolic-link in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5165,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[273]);
t5=(C_word)C_i_check_string_2(t3,lf[273]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5186,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5198,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1533 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5196 in create-symbolic-link in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1533 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5184 in create-symbolic-link in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5194,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1534 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5192 in k5184 in create-symbolic-link in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1534 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5188 in k5184 in create-symbolic-link in k5161 in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1536 posix-error */
t3=lf[3];
f_2538(7,t3,((C_word*)t0)[4],lf[48],lf[274],lf[275],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* create-session in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5146,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5150,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5156,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1504 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k5154 in create-session in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1505 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[270],lf[271]);}

/* k5148 in create-session in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5140,3,t0,t1,t2);}
/* posixunix.scm: 1499 check */
f_5104(t1,t2,C_fix((C_word)X_OK),lf[269]);}

/* file-write-access? in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5134,3,t0,t1,t2);}
/* posixunix.scm: 1498 check */
f_5104(t1,t2,C_fix((C_word)W_OK),lf[268]);}

/* file-read-access? in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5128,3,t0,t1,t2);}
/* posixunix.scm: 1497 check */
f_5104(t1,t2,C_fix((C_word)R_OK),lf[267]);}

/* check in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5104(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5104,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5122,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5126,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1494 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5124 in check in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1494 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5120 in check in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5122,2,t0,t1);}
t2=(C_word)C_test_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5114,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* posixunix.scm: 1495 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5112 in k5120 in check in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5074,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[265]);
t6=(C_word)C_i_check_exact_2(t3,lf[265]);
t7=(C_word)C_i_check_exact_2(t4,lf[265]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5098,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5102,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1484 ##sys#expand-home-path */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k5100 in change-file-owner in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1484 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5096 in change-file-owner in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1485 posix-error */
t3=lf[3];
f_2538(8,t3,((C_word*)t0)[3],lf[48],lf[265],lf[266],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* change-file-mode in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5047,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[263]);
t5=(C_word)C_i_check_exact_2(t3,lf[263]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5068,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5072,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1476 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5070 in change-file-mode in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1476 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5066 in change-file-mode in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1477 posix-error */
t3=lf[3];
f_2538(7,t3,((C_word*)t0)[3],lf[48],lf[263],lf[264],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* initialize-groups in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4983,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[222]);
t5=(C_word)C_i_check_exact_2(t3,lf[222]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4971,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_4971(2,t9,C_SCHEME_FALSE);}}

/* k4969 in initialize-groups in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4971,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub920(C_SCHEME_UNDEFINED,t1,t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1397 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4997 in k4969 in initialize-groups in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1398 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[222],lf[223],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4909,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4913,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
if(C_truep((C_word)stub877(C_SCHEME_UNDEFINED,t5))){
t6=t3;
f_4913(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1380 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[219],lf[221]);}}

/* k4911 in set-groups! in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4918,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li88),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4918(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop903 in k4911 in set-groups! in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4918(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4918,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4934,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1385 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[219]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k4932 in doloop903 in k4911 in set-groups! in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1386 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[219],lf[220],((C_word*)t0)[2]);}

/* get-groups in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4846,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4850,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4904,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1366 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4850(2,t4,C_SCHEME_UNDEFINED);}}

/* k4902 in get-groups in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1367 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[215],lf[218]);}

/* k4848 in get-groups in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
if(C_truep((C_word)stub877(C_SCHEME_UNDEFINED,t3))){
t4=t2;
f_4853(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1369 ##sys#error */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[215],lf[217]);}}

/* k4851 in k4848 in get-groups in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub873(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4885,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1371 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_4856(2,t5,C_SCHEME_UNDEFINED);}}

/* k4883 in k4851 in k4848 in get-groups in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1372 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[215],lf[216]);}

/* k4854 in k4851 in k4848 in get-groups in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4856,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4861,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li86),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4861(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k4854 in k4851 in k4848 in get-groups in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4861(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4861,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4875,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1376 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k4873 in loop in k4854 in k4851 in k4848 in get-groups in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4875,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* group-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4753(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4753r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4753r(t0,t1,t2,t3);}}

static void C_ccall f_4753r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4757,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4757(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4757(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4755 in group-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_4760(t3,(C_word)C_getgrgid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[214]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4811,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1340 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4809 in k4755 in group-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4760(t2,(C_word)C_getgrnam(t1));}

/* k4758 in k4755 in group-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4760,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[3])?*((C_word*)lf[211]+1):*((C_word*)lf[212]+1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t4=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4771 in k4758 in k4755 in group-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4777,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k4775 in k4771 in k4758 in k4755 in group-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4781,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4783,a[2]=t4,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4783(t6,t2,C_fix(0));}

/* loop in k4775 in k4771 in k4758 in k4755 in group-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4783(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4783,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4787,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub844(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k4785 in loop in k4775 in k4771 in k4758 in k4755 in group-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4787,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4797,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1349 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4783(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k4795 in k4785 in loop in k4775 in k4771 in k4758 in k4755 in group-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4797,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4779 in k4775 in k4771 in k4758 in k4755 in group-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g866867 */
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4736,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4740,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1325 current-effective-user-id */
((C_proc2)C_retrieve_proc(*((C_word*)lf[207]+1)))(2,*((C_word*)lf[207]+1),t3);}

/* k4738 in current-effective-user-name in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1325 user-information */
((C_proc3)C_retrieve_proc(*((C_word*)lf[210]+1)))(3,*((C_word*)lf[210]+1),((C_word*)t0)[2],t1);}

/* k4734 in current-effective-user-name in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}

/* current-user-name in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4722,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4726,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1322 current-user-id */
((C_proc2)C_retrieve_proc(*((C_word*)lf[206]+1)))(2,*((C_word*)lf[206]+1),t3);}

/* k4724 in current-user-name in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1322 user-information */
((C_proc3)C_retrieve_proc(*((C_word*)lf[210]+1)))(3,*((C_word*)lf[210]+1),((C_word*)t0)[2],t1);}

/* k4720 in current-user-name in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}

/* user-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4647r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4647r(t0,t1,t2,t3);}}

static void C_ccall f_4647r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4651,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4651(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4651(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4649 in user-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4654,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_4654(t3,(C_word)C_getpwuid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[210]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4693,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1310 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4691 in k4649 in user-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4654(t2,(C_word)C_getpwnam(t1));}

/* k4652 in k4649 in user-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4654,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[3])?*((C_word*)lf[211]+1):*((C_word*)lf[212]+1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4667,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t4=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4665 in k4652 in k4649 in user-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4671,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k4669 in k4665 in k4652 in k4649 in user-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4675,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k4673 in k4669 in k4665 in k4652 in k4649 in user-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4679,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k4677 in k4673 in k4669 in k4665 in k4652 in k4649 in user-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4683,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k4681 in k4677 in k4673 in k4669 in k4665 in k4652 in k4649 in user-information in k4643 in k4639 in k4635 in k4631 in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g839840 */
t2=((C_word*)t0)[7];
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* system-information in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4597,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4626,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1255 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4597(2,t3,C_SCHEME_UNDEFINED);}}

/* k4624 in system-information in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1256 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[203],lf[205]);}

/* k4595 in system-information in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k4602 in k4595 in system-information in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4608,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k4606 in k4602 in k4595 in system-information in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4612,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k4610 in k4606 in k4602 in k4595 in system-information in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4616,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k4614 in k4610 in k4606 in k4602 in k4595 in system-information in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4620,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k4618 in k4614 in k4610 in k4606 in k4602 in k4595 in system-information in k4589 in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4620,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4575,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[201]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1234 posix-error */
t5=lf[3];
f_2538(5,t5,t1,lf[195],lf[201],lf[202]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* signal-mask! in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4560,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[199]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1228 posix-error */
t5=lf[3];
f_2538(5,t5,t1,lf[195],lf[199],lf[200]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* signal-masked? in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4554,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[198]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4522,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4528,a[2]=t3,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4528(t5,t1,*((C_word*)lf[190]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4528(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4528,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_sigismember(t4))){
t6=(C_word)C_a_i_cons(&a,2,t4,t3);
/* posixunix.scm: 1218 loop */
t10=t1;
t11=t5;
t12=t6;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
t6=t3;
/* posixunix.scm: 1218 loop */
t10=t1;
t11=t5;
t12=t6;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}}

/* set-signal-mask! in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4476,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[194]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4494,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
t6=f_4494(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1211 posix-error */
t7=lf[3];
f_2538(5,t7,t1,lf[195],lf[194],lf[196]);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* loop753 in set-signal-mask! in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_4494(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_check_exact_2(t2,lf[194]);
t4=(C_word)C_sigaddset(t2);
t5=(C_word)C_slot(t1,C_fix(1));
t8=t5;
t1=t8;
goto loop;}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* ##sys#interrupt-hook in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4458,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4468,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1197 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1199 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k4466 in ##sys#interrupt-hook in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1198 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4445,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[193]);
if(C_truep(t3)){
t5=t2;
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}
else{
t5=(C_word)C_establish_signal_handler(t2,C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}}

/* signal-handler in k4432 in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4436,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[192]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4393,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1114 posix-error */
t3=lf[3];
f_2538(5,t3,t2,lf[48],lf[163],lf[164]);}
else{
/* posixunix.scm: 1115 values */
C_values(4,0,t1,C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}}

/* k4391 in create-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1115 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4369r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4369r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4369r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[162]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4373,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4371 in with-output-to-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4373,2,t0,t1);}
t2=C_mutate((C_word*)lf[162]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4379,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li67),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1102 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4378 in k4371 in with-output-to-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4379r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4379r(t0,t1,t2);}}

static void C_ccall f_4379r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4383,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1104 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4381 in a4378 in k4371 in with-output-to-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[162]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4349r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4349r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4349r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[160]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4353,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4351 in with-input-from-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4353,2,t0,t1);}
t2=C_mutate((C_word*)lf[160]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4359,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li65),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1092 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4358 in k4351 in with-input-from-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4359r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4359r(t0,t1,t2);}}

static void C_ccall f_4359r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4363,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1094 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4361 in a4358 in k4351 in with-input-from-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[160]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4325r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4325r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4325r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4329,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4327 in call-with-output-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4334,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4340,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1082 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4339 in k4327 in call-with-output-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4340(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4340r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4340r(t0,t1,t2);}}

static void C_ccall f_4340r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4344,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1085 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4342 in a4339 in k4327 in call-with-output-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4333 in k4327 in call-with-output-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
/* posixunix.scm: 1083 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4301r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4301r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4301r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4305,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4303 in call-with-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4310,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4316,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1074 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4315 in k4303 in call-with-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4316r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4316r(t0,t1,t2);}}

static void C_ccall f_4316r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4320,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1077 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4318 in a4315 in k4303 in call-with-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4309 in k4303 in call-with-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
/* posixunix.scm: 1075 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4285,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4289,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1061 ##sys#check-port */
t4=*((C_word*)lf[155]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[152]);}

/* k4287 in close-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4289,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4292,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1063 posix-error */
t5=lf[3];
f_2538(6,t5,t3,lf[48],lf[153],lf[154],((C_word*)t0)[3]);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k4290 in k4287 in close-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4249r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4249r(t0,t1,t2,t3);}}

static void C_ccall f_4249r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_string_2(t2,lf[151]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[148]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4263,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[148]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4270,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1056 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[149]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4280,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1057 ##sys#make-c-string */
t11=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixunix.scm: 1030 ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,lf[150],t6);}}}

/* k4278 in open-output-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4280,2,t0,t1);}
t2=(C_word)open_binary_output_pipe(&a,1,t1);
/* posixunix.scm: 1052 check */
f_4198(((C_word*)t0)[3],lf[151],((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* k4268 in open-output-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=(C_word)open_text_output_pipe(&a,1,t1);
/* posixunix.scm: 1052 check */
f_4198(((C_word*)t0)[3],lf[151],((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* k4261 in open-output-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1052 check */
f_4198(((C_word*)t0)[3],lf[151],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4213r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4213r(t0,t1,t2,t3);}}

static void C_ccall f_4213r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_string_2(t2,lf[147]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[148]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4227,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[148]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4234,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1045 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[149]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4244,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1046 ##sys#make-c-string */
t11=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixunix.scm: 1030 ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,lf[150],t6);}}}

/* k4242 in open-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
t2=(C_word)open_binary_input_pipe(&a,1,t1);
/* posixunix.scm: 1041 check */
f_4198(((C_word*)t0)[3],lf[147],((C_word*)t0)[2],C_SCHEME_TRUE,t2);}

/* k4232 in open-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
t2=(C_word)open_text_input_pipe(&a,1,t1);
/* posixunix.scm: 1041 check */
f_4198(((C_word*)t0)[3],lf[147],((C_word*)t0)[2],C_SCHEME_TRUE,t2);}

/* k4225 in open-input-pipe in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1041 check */
f_4198(((C_word*)t0)[3],lf[147],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4198(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4198,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1033 posix-error */
t6=lf[3];
f_2538(6,t6,t1,lf[48],t2,lf[143],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4211,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1034 ##sys#make-port */
t7=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[145]+1),lf[146],lf[92]);}}

/* k4209 in check in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3863,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[125]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3870,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3984,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 978  cwd */
t8=((C_word*)t0)[6];
f_3807(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=t4,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4170,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 980  sref */
t10=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_3990(t9,C_SCHEME_FALSE);}}}

/* k4168 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3990(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3990,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
t3=((C_word*)t0)[9];
f_3870(2,t3,t2);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 983  cwd */
t5=((C_word*)t0)[7];
f_3807(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4145,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4156,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 984  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k4154 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 984  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k4143 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4145,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4152,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 985  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[4];
f_4009(t2,C_SCHEME_FALSE);}}

/* k4150 in k4143 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_4009(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4009(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4009,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 987  get-environment-variable */
t3=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[140]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 992  cwd */
t5=((C_word*)t0)[5];
f_3807(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4138,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 993  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k4136 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 993  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4115 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4117,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4123,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4134,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 994  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4053(t2,C_SCHEME_FALSE);}}

/* k4132 in k4115 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 994  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4121 in k4115 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4123,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4130,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 995  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_4053(t2,C_SCHEME_FALSE);}}

/* k4128 in k4121 in k4115 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_4053(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k4051 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4053,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[8]);
/* posixunix.scm: 996  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[7],((C_word*)t0)[8],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4114,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 997  sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k4112 in k4051 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 997  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k4091 in k4051 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4093,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4110,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 998  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4066(2,t2,C_SCHEME_FALSE);}}

/* k4108 in k4091 in k4051 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 998  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4097 in k4091 in k4051 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4099,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 999  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_4066(2,t2,C_SCHEME_FALSE);}}

/* k4104 in k4097 in k4091 in k4051 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 999  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4064 in k4051 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[6]);
/* posixunix.scm: 1000 ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[5],((C_word*)t0)[6],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1001 sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[6],C_fix(0));}}

/* k4088 in k4064 in k4051 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4090,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
f_3870(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1004 cwd */
t5=((C_word*)t0)[2];
f_3807(t5,t4);}}

/* k4084 in k4088 in k4064 in k4051 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1004 sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[142],((C_word*)t0)[2]);}

/* k4045 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 992  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[141],((C_word*)t0)[2]);}

/* k4014 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4019(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4034,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 988  user */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k4032 in k4014 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 988  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[139],t1);}

/* k4017 in k4014 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4023,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 989  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k4021 in k4017 in k4014 in k4007 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 986  sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4001 in k3988 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 983  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[138],((C_word*)t0)[2]);}

/* k3982 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 978  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[137]);}

/* k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=t1;
t4=*((C_word*)lf[135]+1);
/* g580581 */
t5=t4;
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,t3,lf[136]);}

/* k3875 in k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3877,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li53),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3879(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k3875 in k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3879(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3879,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1007 null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3884 in loop in k3875 in k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3892,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1008 null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 1019 string=? */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,lf[134],t4);}}

/* k3948 in k3884 in loop in k3875 in k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3950,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* posixunix.scm: 1017 loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3879(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 1021 string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[133],t3);}}

/* k3957 in k3948 in k3884 in loop in k3875 in k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3959,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
/* posixunix.scm: 1017 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3879(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[6]);
/* posixunix.scm: 1017 loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3879(t4,((C_word*)t0)[4],((C_word*)t0)[3],t3);}}

/* k3890 in k3884 in loop in k3875 in k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3892,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[126]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3928,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 1010 sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k3926 in k3890 in k3884 in loop in k3875 in k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3928,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3909,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_a_i_cons(&a,2,lf[130],((C_word*)t0)[2]);
/* posixunix.scm: 1013 reverse */
t7=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3924,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1016 reverse */
t6=*((C_word*)lf[131]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3922 in k3926 in k3890 in k3884 in loop in k3875 in k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[128]+1);
/* g589590 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,lf[129]);}

/* k3918 in k3926 in k3890 in k3884 in loop in k3875 in k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1014 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[132],t1);}

/* k3907 in k3926 in k3890 in k3884 in loop in k3875 in k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[128]+1);
/* g589590 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,lf[129]);}

/* k3903 in k3926 in k3890 in k3884 in loop in k3875 in k3868 in canonical-path in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1011 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[127],t1);}

/* cwd in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3807,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3811,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3816,a[2]=((C_word*)t0)[2],a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[124]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a3815 in cwd in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3816,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3822,a[2]=t2,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3840,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li50),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t1,t3,t4);}

/* a3839 in a3815 in cwd in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[3],a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3852,a[2]=((C_word*)t0)[2],a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3851 in a3839 in a3815 in cwd in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3852r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3852r(t0,t1,t2);}}

static void C_ccall f_3852r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3858,a[2]=t2,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
/* k605610 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3857 in a3851 in a3839 in a3815 in cwd in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3858,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3845 in a3839 in a3815 in cwd in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3846,2,t0,t1);}
/* posixunix.scm: 973  cw */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a3821 in a3815 in cwd in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3822,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3828,a[2]=t2,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
/* k605610 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3827 in a3821 in a3815 in cwd in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3828,2,t0,t1);}
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[2],lf[121]))){
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[122]);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[122]);}}

/* k3809 in cwd in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g608609 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* current-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3743r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3743r(t0,t1,t2);}}

static void C_ccall f_3743r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3747(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3747(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3745 in current-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 952  change-directory */
t2=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 953  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k3754 in k3745 in current-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 956  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 957  posix-error */
t3=lf[3];
f_2538(5,t3,((C_word*)t0)[2],lf[48],lf[112],lf[114]);}}

/* directory? in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3717,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[113]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3741,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 946  ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3739 in directory? in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3741,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3734,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 876  ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k3732 in k3739 in directory? in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_stat(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_mk_bool(C_isdir);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_3560r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3560r(t0,t1,t2);}}

static void C_ccall f_3560r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3660,a[2]=t3,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3665,a[2]=t4,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec487528 */
t6=t5;
f_3665(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?488526 */
t8=t4;
f_3660(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body485493 */
t10=t3;
f_3562(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec487 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3665,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3673,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 919  current-directory */
t3=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3671 in def-spec487 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?488526 */
t2=((C_word*)t0)[3];
f_3660(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?488 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3660(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3660,NULL,3,t0,t1,t2);}
/* body485493 */
t3=((C_word*)t0)[2];
f_3562(t3,t1,t2,C_SCHEME_FALSE);}

/* body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3562(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3562,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[109]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 921  make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k3567 in body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 922  ##sys#make-pointer */
t3=*((C_word*)lf[111]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3570 in k3567 in body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 923  ##sys#make-pointer */
t3=*((C_word*)lf[111]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3573 in k3570 in k3567 in body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3659,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 924  ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k3657 in k3573 in k3570 in k3567 in body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 924  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3577 in k3573 in k3570 in k3567 in body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3579,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 926  posix-error */
t3=lf[3];
f_2538(6,t3,((C_word*)t0)[7],lf[48],lf[109],lf[110],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word)li38),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3593(t6,((C_word*)t0)[7]);}}

/* loop in k3577 in k3573 in k3570 in k3567 in body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3593(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3593,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 934  ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k3601 in loop in k3577 in k3573 in k3570 in k3567 in body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 935  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_fix(0));}

/* k3604 in k3601 in loop in k3577 in k3573 in k3570 in k3567 in body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 936  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_3609(2,t3,C_SCHEME_FALSE);}}

/* k3607 in k3604 in k3601 in loop in k3577 in k3573 in k3570 in k3567 in body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3615,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_3615(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]);
t7=t2;
f_3615(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}
else{
t6=t2;
f_3615(t6,(C_word)C_i_not(((C_word*)t0)[2]));}}}
else{
t4=t2;
f_3615(t4,C_SCHEME_FALSE);}}

/* k3613 in k3607 in k3604 in k3601 in loop in k3577 in k3573 in k3570 in k3567 in body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3615,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 941  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3593(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 942  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3593(t3,t2);}}

/* k3623 in k3613 in k3607 in k3604 in k3601 in loop in k3577 in k3573 in k3570 in k3567 in body485 in directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3625,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3538,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[105]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3545,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3558,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 910  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3556 in delete-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 910  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3543 in delete-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3548,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(0),(C_word)C_rmdir(t1));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
/* posixunix.scm: 912  posix-error */
t4=lf[3];
f_2538(6,t4,t2,lf[48],lf[105],lf[106],t1);}}

/* k3546 in k3543 in delete-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3516,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[103]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3523,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3536,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 902  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3534 in change-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 902  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3521 in change-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3526,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(0),(C_word)C_chdir(t1));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
/* posixunix.scm: 904  posix-error */
t4=lf[3];
f_2538(6,t4,t2,lf[48],lf[103],lf[104],t1);}}

/* k3524 in k3521 in change-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_3357r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3357r(t0,t1,t2,t3);}}

static void C_ccall f_3357r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3361(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3361(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3361,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[100]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 888  ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3370,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_block_size(t1);
t4=(C_word)C_eqp(C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_3376(t6,t4);}
else{
t6=t1;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3488,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 876  ##sys#make-c-string */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}}

/* k3486 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_stat(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_mk_bool(C_isdir);
t5=((C_word*)t0)[2];
f_3376(t5,t4);}
else{
t4=((C_word*)t0)[2];
f_3376(t4,C_SCHEME_FALSE);}}

/* k3374 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3376,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3386,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3449,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3472,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 880  ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}

/* k3470 in k3374 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_mkdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}
else{
/* posixunix.scm: 881  posix-error */
t4=lf[3];
f_2538(6,t4,((C_word*)t0)[3],lf[48],lf[100],lf[101],((C_word*)t0)[2]);}}

/* a3448 in k3374 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3449,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
/* posixunix.scm: 892  make-pathname */
t5=*((C_word*)lf[102]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,t4);}
else{
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* a3442 in k3374 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
/* posixunix.scm: 891  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k3384 in k3374 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3386,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3388(t5,((C_word*)t0)[2],t1);}

/* loop in k3384 in k3374 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3388,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t2;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3438,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 876  ##sys#make-c-string */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=t3;
f_3395(t4,C_SCHEME_FALSE);}}

/* k3436 in loop in k3384 in k3374 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_stat(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_mk_bool(C_isdir);
t5=((C_word*)t0)[2];
f_3395(t5,(C_word)C_i_not(t4));}
else{
t4=((C_word*)t0)[2];
f_3395(t4,C_SCHEME_TRUE);}}

/* k3393 in loop in k3384 in k3374 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3395,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3421,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 894  pathname-directory */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3419 in k3393 in loop in k3384 in k3374 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 894  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3388(t2,((C_word*)t0)[2],t1);}

/* k3396 in k3393 in loop in k3384 in k3374 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3414,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 880  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3412 in k3396 in k3393 in loop in k3384 in k3374 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_mkdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* posixunix.scm: 881  posix-error */
t4=lf[3];
f_2538(6,t4,((C_word*)t0)[3],lf[48],lf[100],lf[101],((C_word*)t0)[2]);}}

/* k3368 in k3365 in k3359 in create-directory in k3353 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* set-file-position! in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3295r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3295r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3295r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[90]);
t8=(C_word)C_i_check_exact_2(t6,lf[90]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3308,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_negativep(t3))){
/* posixunix.scm: 846  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[95],lf[90],lf[96],t3,t2);}
else{
t10=t9;
f_3308(2,t10,C_SCHEME_UNDEFINED);}}

/* k3306 in set-file-position! in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3320,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 847  port? */
t4=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k3318 in k3306 in set-file-position! in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[92]);
if(C_truep(t3)){
t4=(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
f_3314(2,t5,t4);}
else{
t4=((C_word*)t0)[2];
f_3314(2,t4,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3314(2,t3,t2);}
else{
/* posixunix.scm: 853  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[90],lf[93],((C_word*)t0)[5]);}}}

/* k3312 in k3306 in set-file-position! in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 854  posix-error */
t2=lf[3];
f_2538(7,t2,((C_word*)t0)[4],lf[48],lf[90],lf[91],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* socket? in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3286,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3293,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 837  ##sys#stat */
f_3138(t4,t2,C_SCHEME_FALSE,lf[89]);}

/* k3291 in socket? in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* f_3277 in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3277,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3284,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 832  ##sys#stat */
f_3138(t4,t2,C_SCHEME_FALSE,lf[88]);}

/* k3282 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* block-device? in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3268,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3275,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 827  ##sys#stat */
f_3138(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k3273 in block-device? in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* character-device? in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3259,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3266,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 822  ##sys#stat */
f_3138(t4,t2,C_SCHEME_FALSE,lf[85]);}

/* k3264 in character-device? in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* symbolic-link? in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3250,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3257,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 817  ##sys#stat */
f_3138(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k3255 in symbolic-link? in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3241,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[83]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3248,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 812  ##sys#stat */
f_3138(t4,t2,C_SCHEME_TRUE,lf[83]);}

/* k3246 in regular-file? in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3235,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3239,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 808  ##sys#stat */
f_3138(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k3237 in file-permissions in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3229,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3233,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 807  ##sys#stat */
f_3138(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k3231 in file-owner in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3223,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3227,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 806  ##sys#stat */
f_3138(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k3225 in file-change-time in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3217,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3221,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 805  ##sys#stat */
f_3138(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k3219 in file-access-time in k3213 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3221,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-size in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3207,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3211,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 790  ##sys#stat */
f_3138(t3,t2,C_SCHEME_FALSE,lf[77]);}

/* k3209 in file-size in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3211,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3175r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3175r(t0,t1,t2,t3);}}

static void C_ccall f_3175r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3179,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3186,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* posixunix.scm: 783  ##sys#stat */
f_3138(t4,t2,C_SCHEME_FALSE,lf[76]);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=(C_word)C_i_car(t3);
/* posixunix.scm: 783  ##sys#stat */
f_3138(t4,t2,t7,lf[76]);}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k3184 in file-stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 783  ##sys#stat */
f_3138(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[76]);}

/* k3177 in file-stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3179,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3138(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3138,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3142,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_3142(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3163,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3170,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 774  ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 778  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[75],t2);}}}

/* k3168 in ##sys#stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 774  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3161 in ##sys#stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3142(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k3140 in ##sys#stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 780  posix-error */
t2=lf[3];
f_2538(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[74],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2858r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2858r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2858r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a=C_alloc(16);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t10=(C_word)stub116(C_SCHEME_UNDEFINED,t9);
t11=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t12=(C_word)stub116(C_SCHEME_UNDEFINED,t11);
t13=(C_word)C_i_not(t2);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2874,a[2]=t6,a[3]=t8,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t13)){
t15=t14;
f_2874(2,t15,t13);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t15=C_set_block_item(t6,0,t2);
t16=t2;
t17=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t18=(C_word)C_i_foreign_fixnum_argumentp(t16);
t19=t14;
f_2874(2,t19,(C_word)stub121(C_SCHEME_UNDEFINED,t17,t18));}
else{
t15=(C_word)C_i_check_list_2(t2,lf[68]);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3097,a[2]=t17,a[3]=t6,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp));
t19=((C_word*)t17)[1];
f_3097(t19,t14,t2);}}}

/* loop150 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3097(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3097,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[3],a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_3105(t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g157 in loop150 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_3105(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t2=(C_word)C_i_check_exact_2(t1,lf[68]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[2])[1],t1));
t4=t1;
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
return((C_word)stub121(C_SCHEME_UNDEFINED,t5,t6));}

/* k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2880(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[6]);
t5=((C_word*)t0)[6];
t6=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=t3;
f_2880(2,t8,(C_word)stub121(C_SCHEME_UNDEFINED,t6,t7));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[6],lf[68]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3049,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3049(t8,t3,((C_word*)t0)[6]);}}}

/* loop179 in k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3049(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3049,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3057,a[2]=((C_word*)t0)[3],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_3057(t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g186 in loop179 in k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_3057(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t2=(C_word)C_i_check_exact_2(t1,lf[68]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[2])[1],t1));
t4=t1;
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
return((C_word)stub121(C_SCHEME_UNDEFINED,t5,t6));}

/* k2878 in k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[68]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_2883(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_2883(t4,(C_word)C_C_select(t3));}}

/* k2881 in k2878 in k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_2883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2883,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 729  posix-error */
t2=lf[3];
f_2538(7,t2,((C_word*)t0)[4],lf[48],lf[68],lf[69],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[3]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
/* posixunix.scm: 730  values */
C_values(4,0,((C_word*)t0)[4],t4,C_SCHEME_END_OF_LIST);}
else{
/* posixunix.scm: 730  values */
C_values(4,0,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t4=((C_word*)t0)[3];
t5=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=t3;
f_2922(t7,(C_word)stub127(C_SCHEME_UNDEFINED,t5,t6));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2985,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2987,a[2]=t8,a[3]=t5,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2987(t10,t6,((C_word*)t0)[3]);}}
else{
t4=t3;
f_2922(t4,C_SCHEME_FALSE);}}}}

/* loop213 in k2881 in k2878 in k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_2987(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2987,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[3],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_2995(C_a_i(&a,3),t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g220 in loop213 in k2881 in k2878 in k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_2995(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_check;
t2=t1;
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(0));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
if(C_truep((C_word)stub127(C_SCHEME_UNDEFINED,t3,t4))){
t5=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}
else{
t5=C_SCHEME_UNDEFINED;
return(t5);}}

/* k2983 in k2881 in k2878 in k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
f_2922(t3,t2);}

/* k2920 in k2881 in k2878 in k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_2922(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2922,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[3];
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)stub127(C_SCHEME_UNDEFINED,t3,t4);
/* posixunix.scm: 732  values */
C_values(4,0,((C_word*)t0)[2],t1,t5);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2938,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2940,a[2]=t6,a[3]=t3,a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2940(t8,t4,((C_word*)t0)[3]);}}
else{
/* posixunix.scm: 732  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* loop233 in k2920 in k2881 in k2878 in k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_2940(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2940,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[3],a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_2948(C_a_i(&a,3),t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g240 in loop233 in k2920 in k2881 in k2878 in k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_2948(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_check;
t2=t1;
t3=(C_word)C_i_foreign_fixnum_argumentp(C_fix(1));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
if(C_truep((C_word)stub127(C_SCHEME_UNDEFINED,t3,t4))){
t5=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}
else{
t5=C_SCHEME_UNDEFINED;
return(t5);}}

/* k2936 in k2920 in k2881 in k2878 in k2872 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
/* posixunix.scm: 732  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* file-mkstemp in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2800(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2800,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[65]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2807,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 681  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2805 in file-mkstemp in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2807,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2813,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 685  posix-error */
t6=lf[3];
f_2538(6,t6,t4,lf[48],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t6=t4;
f_2813(2,t6,C_SCHEME_UNDEFINED);}}

/* k2811 in k2805 in file-mkstemp in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 686  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2818 in k2811 in k2805 in file-mkstemp in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 686  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2761r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2761r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2761r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[62]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2768,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_byteblockp(t3))){
t7=t6;
f_2768(2,t7,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 670  ##sys#signal-hook */
t7=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[60],lf[62],lf[64],t3);}}
else{
/* posixunix.scm: 670  ##sys#signal-hook */
t7=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[60],lf[62],lf[64],t3);}}

/* k2766 in file-write in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2768,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[62]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2777,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 675  posix-error */
t8=lf[3];
f_2538(7,t8,t6,lf[48],lf[62],lf[63],((C_word*)t0)[3],t3);}
else{
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t5);}}

/* k2775 in k2766 in file-write in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2719r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2719r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2719r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2729,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_2729(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixunix.scm: 658  make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k2727 in file-read in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(t1))){
if(C_truep((C_word)C_byteblockp(t1))){
t3=t2;
f_2732(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 660  ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[60],lf[58],lf[61],t1);}}
else{
/* posixunix.scm: 660  ##sys#signal-hook */
t3=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[60],lf[58],lf[61],t1);}}

/* k2730 in k2727 in file-read in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2732,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2735,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 663  posix-error */
t5=lf[3];
f_2538(7,t5,t3,lf[48],lf[58],lf[59],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2));}}

/* k2733 in k2730 in k2727 in file-read in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2735,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2704,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[55]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 651  posix-error */
t4=lf[3];
f_2538(6,t4,t1,lf[48],lf[55],lf[56],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* file-open in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2666r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2666r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2666r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[51]);
t8=(C_word)C_i_check_exact_2(t3,lf[51]);
t9=(C_word)C_i_check_exact_2(t6,lf[51]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2683,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2696,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 642  ##sys#expand-home-path */
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k2694 in file-open in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 642  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2681 in file-open in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2683,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2686,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 644  posix-error */
t5=lf[3];
f_2538(8,t5,t3,lf[48],lf[51],lf[52],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k2684 in k2681 in file-open in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2620r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2620r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2620r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2624,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2624(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2624(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k2622 in file-control in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[47]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[47]);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_integer_argumentp(t1);
t9=(C_word)stub33(C_SCHEME_UNDEFINED,t6,t7,t8);
t10=(C_word)C_eqp(t9,C_fix(-1));
if(C_truep(t10)){
/* posixunix.scm: 632  posix-error */
t11=lf[3];
f_2538(7,t11,((C_word*)t0)[2],lf[48],lf[47],lf[49],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t9);}}

/* ##sys#file-select-one in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2563,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub26(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-nonblocking! in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2556,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub22(C_SCHEME_UNDEFINED,t3));}

/* posix-error in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_2538r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2538r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2538r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2542,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 522  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k2540 in posix-error in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub12(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k2551 in k2540 in posix-error in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 523  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k2547 in k2540 in posix-error in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[626] = {
{"toplevel:posixunix_scm",(void*)C_posix_toplevel},
{"f_2508:posixunix_scm",(void*)f_2508},
{"f_2511:posixunix_scm",(void*)f_2511},
{"f_2514:posixunix_scm",(void*)f_2514},
{"f_2517:posixunix_scm",(void*)f_2517},
{"f_2520:posixunix_scm",(void*)f_2520},
{"f_2523:posixunix_scm",(void*)f_2523},
{"f_2526:posixunix_scm",(void*)f_2526},
{"f_8695:posixunix_scm",(void*)f_8695},
{"f_8728:posixunix_scm",(void*)f_8728},
{"f_8705:posixunix_scm",(void*)f_8705},
{"f_8715:posixunix_scm",(void*)f_8715},
{"f_8689:posixunix_scm",(void*)f_8689},
{"f_8693:posixunix_scm",(void*)f_8693},
{"f_3215:posixunix_scm",(void*)f_3215},
{"f_8652:posixunix_scm",(void*)f_8652},
{"f_8668:posixunix_scm",(void*)f_8668},
{"f_8656:posixunix_scm",(void*)f_8656},
{"f_8659:posixunix_scm",(void*)f_8659},
{"f_3355:posixunix_scm",(void*)f_3355},
{"f_4434:posixunix_scm",(void*)f_4434},
{"f_8646:posixunix_scm",(void*)f_8646},
{"f_4591:posixunix_scm",(void*)f_4591},
{"f_8631:posixunix_scm",(void*)f_8631},
{"f_8641:posixunix_scm",(void*)f_8641},
{"f_8628:posixunix_scm",(void*)f_8628},
{"f_4633:posixunix_scm",(void*)f_4633},
{"f_8613:posixunix_scm",(void*)f_8613},
{"f_8623:posixunix_scm",(void*)f_8623},
{"f_8610:posixunix_scm",(void*)f_8610},
{"f_4637:posixunix_scm",(void*)f_4637},
{"f_8595:posixunix_scm",(void*)f_8595},
{"f_8605:posixunix_scm",(void*)f_8605},
{"f_8592:posixunix_scm",(void*)f_8592},
{"f_4641:posixunix_scm",(void*)f_4641},
{"f_8577:posixunix_scm",(void*)f_8577},
{"f_8587:posixunix_scm",(void*)f_8587},
{"f_8574:posixunix_scm",(void*)f_8574},
{"f_4645:posixunix_scm",(void*)f_4645},
{"f_8553:posixunix_scm",(void*)f_8553},
{"f_8569:posixunix_scm",(void*)f_8569},
{"f_8535:posixunix_scm",(void*)f_8535},
{"f_8548:posixunix_scm",(void*)f_8548},
{"f_8542:posixunix_scm",(void*)f_8542},
{"f_5163:posixunix_scm",(void*)f_5163},
{"f_5202:posixunix_scm",(void*)f_5202},
{"f_8512:posixunix_scm",(void*)f_8512},
{"f_8504:posixunix_scm",(void*)f_8504},
{"f_8522:posixunix_scm",(void*)f_8522},
{"f_8253:posixunix_scm",(void*)f_8253},
{"f_8430:posixunix_scm",(void*)f_8430},
{"f_8436:posixunix_scm",(void*)f_8436},
{"f_8425:posixunix_scm",(void*)f_8425},
{"f_8420:posixunix_scm",(void*)f_8420},
{"f_8255:posixunix_scm",(void*)f_8255},
{"f_8407:posixunix_scm",(void*)f_8407},
{"f_8415:posixunix_scm",(void*)f_8415},
{"f_8262:posixunix_scm",(void*)f_8262},
{"f_8395:posixunix_scm",(void*)f_8395},
{"f_8389:posixunix_scm",(void*)f_8389},
{"f_8272:posixunix_scm",(void*)f_8272},
{"f_8274:posixunix_scm",(void*)f_8274},
{"f_8293:posixunix_scm",(void*)f_8293},
{"f_8375:posixunix_scm",(void*)f_8375},
{"f_8382:posixunix_scm",(void*)f_8382},
{"f_8369:posixunix_scm",(void*)f_8369},
{"f_8308:posixunix_scm",(void*)f_8308},
{"f_8362:posixunix_scm",(void*)f_8362},
{"f_8359:posixunix_scm",(void*)f_8359},
{"f_8349:posixunix_scm",(void*)f_8349},
{"f_8325:posixunix_scm",(void*)f_8325},
{"f_8347:posixunix_scm",(void*)f_8347},
{"f_8333:posixunix_scm",(void*)f_8333},
{"f_8340:posixunix_scm",(void*)f_8340},
{"f_8337:posixunix_scm",(void*)f_8337},
{"f_8320:posixunix_scm",(void*)f_8320},
{"f_8318:posixunix_scm",(void*)f_8318},
{"f_8396:posixunix_scm",(void*)f_8396},
{"f_8193:posixunix_scm",(void*)f_8193},
{"f_8205:posixunix_scm",(void*)f_8205},
{"f_8200:posixunix_scm",(void*)f_8200},
{"f_8195:posixunix_scm",(void*)f_8195},
{"f_8133:posixunix_scm",(void*)f_8133},
{"f_8145:posixunix_scm",(void*)f_8145},
{"f_8140:posixunix_scm",(void*)f_8140},
{"f_8135:posixunix_scm",(void*)f_8135},
{"f_8072:posixunix_scm",(void*)f_8072},
{"f_8127:posixunix_scm",(void*)f_8127},
{"f_8131:posixunix_scm",(void*)f_8131},
{"f_8093:posixunix_scm",(void*)f_8093},
{"f_8096:posixunix_scm",(void*)f_8096},
{"f_8107:posixunix_scm",(void*)f_8107},
{"f_8101:posixunix_scm",(void*)f_8101},
{"f_8074:posixunix_scm",(void*)f_8074},
{"f_8083:posixunix_scm",(void*)f_8083},
{"f_8014:posixunix_scm",(void*)f_8014},
{"f_8026:posixunix_scm",(void*)f_8026},
{"f_8057:posixunix_scm",(void*)f_8057},
{"f_8037:posixunix_scm",(void*)f_8037},
{"f_8053:posixunix_scm",(void*)f_8053},
{"f_8041:posixunix_scm",(void*)f_8041},
{"f_8049:posixunix_scm",(void*)f_8049},
{"f_8045:posixunix_scm",(void*)f_8045},
{"f_8020:posixunix_scm",(void*)f_8020},
{"f_8003:posixunix_scm",(void*)f_8003},
{"f_8007:posixunix_scm",(void*)f_8007},
{"f_7992:posixunix_scm",(void*)f_7992},
{"f_7996:posixunix_scm",(void*)f_7996},
{"f_7947:posixunix_scm",(void*)f_7947},
{"f_7951:posixunix_scm",(void*)f_7951},
{"f_7954:posixunix_scm",(void*)f_7954},
{"f_7957:posixunix_scm",(void*)f_7957},
{"f_7964:posixunix_scm",(void*)f_7964},
{"f_7970:posixunix_scm",(void*)f_7970},
{"f_7974:posixunix_scm",(void*)f_7974},
{"f_7977:posixunix_scm",(void*)f_7977},
{"f_7980:posixunix_scm",(void*)f_7980},
{"f_7968:posixunix_scm",(void*)f_7968},
{"f_7914:posixunix_scm",(void*)f_7914},
{"f_7927:posixunix_scm",(void*)f_7927},
{"f_7839:posixunix_scm",(void*)f_7839},
{"f_7900:posixunix_scm",(void*)f_7900},
{"f_7913:posixunix_scm",(void*)f_7913},
{"f_7880:posixunix_scm",(void*)f_7880},
{"f_7895:posixunix_scm",(void*)f_7895},
{"f_7889:posixunix_scm",(void*)f_7889},
{"f_7843:posixunix_scm",(void*)f_7843},
{"f_7845:posixunix_scm",(void*)f_7845},
{"f_7866:posixunix_scm",(void*)f_7866},
{"f_7860:posixunix_scm",(void*)f_7860},
{"f_7787:posixunix_scm",(void*)f_7787},
{"f_7794:posixunix_scm",(void*)f_7794},
{"f_7813:posixunix_scm",(void*)f_7813},
{"f_7817:posixunix_scm",(void*)f_7817},
{"f_7781:posixunix_scm",(void*)f_7781},
{"f_7772:posixunix_scm",(void*)f_7772},
{"f_7776:posixunix_scm",(void*)f_7776},
{"f_7745:posixunix_scm",(void*)f_7745},
{"f_7738:posixunix_scm",(void*)f_7738},
{"f_7735:posixunix_scm",(void*)f_7735},
{"f_7732:posixunix_scm",(void*)f_7732},
{"f_7654:posixunix_scm",(void*)f_7654},
{"f_7690:posixunix_scm",(void*)f_7690},
{"f_7684:posixunix_scm",(void*)f_7684},
{"f_7637:posixunix_scm",(void*)f_7637},
{"f_7455:posixunix_scm",(void*)f_7455},
{"f_7589:posixunix_scm",(void*)f_7589},
{"f_7584:posixunix_scm",(void*)f_7584},
{"f_7457:posixunix_scm",(void*)f_7457},
{"f_7467:posixunix_scm",(void*)f_7467},
{"f_7475:posixunix_scm",(void*)f_7475},
{"f_7521:posixunix_scm",(void*)f_7521},
{"f_7488:posixunix_scm",(void*)f_7488},
{"f_7513:posixunix_scm",(void*)f_7513},
{"f_7491:posixunix_scm",(void*)f_7491},
{"f_7436:posixunix_scm",(void*)f_7436},
{"f_7417:posixunix_scm",(void*)f_7417},
{"f_7375:posixunix_scm",(void*)f_7375},
{"f_7400:posixunix_scm",(void*)f_7400},
{"f_7261:posixunix_scm",(void*)f_7261},
{"f_7267:posixunix_scm",(void*)f_7267},
{"f_7288:posixunix_scm",(void*)f_7288},
{"f_7367:posixunix_scm",(void*)f_7367},
{"f_7292:posixunix_scm",(void*)f_7292},
{"f_7295:posixunix_scm",(void*)f_7295},
{"f_7302:posixunix_scm",(void*)f_7302},
{"f_7304:posixunix_scm",(void*)f_7304},
{"f_7321:posixunix_scm",(void*)f_7321},
{"f_7325:posixunix_scm",(void*)f_7325},
{"f_7333:posixunix_scm",(void*)f_7333},
{"f_7337:posixunix_scm",(void*)f_7337},
{"f_7282:posixunix_scm",(void*)f_7282},
{"f_7249:posixunix_scm",(void*)f_7249},
{"f_7253:posixunix_scm",(void*)f_7253},
{"f_7256:posixunix_scm",(void*)f_7256},
{"f_7214:posixunix_scm",(void*)f_7214},
{"f_7218:posixunix_scm",(void*)f_7218},
{"f_7238:posixunix_scm",(void*)f_7238},
{"f_7242:posixunix_scm",(void*)f_7242},
{"f_7191:posixunix_scm",(void*)f_7191},
{"f_7195:posixunix_scm",(void*)f_7195},
{"f_7159:posixunix_scm",(void*)f_7159},
{"f_7163:posixunix_scm",(void*)f_7163},
{"f_7140:posixunix_scm",(void*)f_7140},
{"f_7144:posixunix_scm",(void*)f_7144},
{"f_7147:posixunix_scm",(void*)f_7147},
{"f_7081:posixunix_scm",(void*)f_7081},
{"f_7085:posixunix_scm",(void*)f_7085},
{"f_7091:posixunix_scm",(void*)f_7091},
{"f_7100:posixunix_scm",(void*)f_7100},
{"f_7074:posixunix_scm",(void*)f_7074},
{"f_7058:posixunix_scm",(void*)f_7058},
{"f_7046:posixunix_scm",(void*)f_7046},
{"f_7031:posixunix_scm",(void*)f_7031},
{"f_7035:posixunix_scm",(void*)f_7035},
{"f_7016:posixunix_scm",(void*)f_7016},
{"f_7020:posixunix_scm",(void*)f_7020},
{"f_6970:posixunix_scm",(void*)f_6970},
{"f_6974:posixunix_scm",(void*)f_6974},
{"f_6987:posixunix_scm",(void*)f_6987},
{"f_6991:posixunix_scm",(void*)f_6991},
{"f_6901:posixunix_scm",(void*)f_6901},
{"f_6905:posixunix_scm",(void*)f_6905},
{"f_6908:posixunix_scm",(void*)f_6908},
{"f_6930:posixunix_scm",(void*)f_6930},
{"f_6927:posixunix_scm",(void*)f_6927},
{"f_6917:posixunix_scm",(void*)f_6917},
{"f_6840:posixunix_scm",(void*)f_6840},
{"f_6844:posixunix_scm",(void*)f_6844},
{"f_6850:posixunix_scm",(void*)f_6850},
{"f_6796:posixunix_scm",(void*)f_6796},
{"f_6800:posixunix_scm",(void*)f_6800},
{"f_6762:posixunix_scm",(void*)f_6762},
{"f_6766:posixunix_scm",(void*)f_6766},
{"f_6743:posixunix_scm",(void*)f_6743},
{"f_6737:posixunix_scm",(void*)f_6737},
{"f_6728:posixunix_scm",(void*)f_6728},
{"f_6693:posixunix_scm",(void*)f_6693},
{"f_6631:posixunix_scm",(void*)f_6631},
{"f_6635:posixunix_scm",(void*)f_6635},
{"f_6641:posixunix_scm",(void*)f_6641},
{"f_6660:posixunix_scm",(void*)f_6660},
{"f_6647:posixunix_scm",(void*)f_6647},
{"f_6527:posixunix_scm",(void*)f_6527},
{"f_6533:posixunix_scm",(void*)f_6533},
{"f_6537:posixunix_scm",(void*)f_6537},
{"f_6545:posixunix_scm",(void*)f_6545},
{"f_6571:posixunix_scm",(void*)f_6571},
{"f_6575:posixunix_scm",(void*)f_6575},
{"f_6563:posixunix_scm",(void*)f_6563},
{"f_6507:posixunix_scm",(void*)f_6507},
{"f_6515:posixunix_scm",(void*)f_6515},
{"f_6490:posixunix_scm",(void*)f_6490},
{"f_6501:posixunix_scm",(void*)f_6501},
{"f_6505:posixunix_scm",(void*)f_6505},
{"f_6464:posixunix_scm",(void*)f_6464},
{"f_6488:posixunix_scm",(void*)f_6488},
{"f_6471:posixunix_scm",(void*)f_6471},
{"f_6421:posixunix_scm",(void*)f_6421},
{"f_6428:posixunix_scm",(void*)f_6428},
{"f_6449:posixunix_scm",(void*)f_6449},
{"f_6445:posixunix_scm",(void*)f_6445},
{"f_6393:posixunix_scm",(void*)f_6393},
{"f_6366:posixunix_scm",(void*)f_6366},
{"f_6370:posixunix_scm",(void*)f_6370},
{"f_6351:posixunix_scm",(void*)f_6351},
{"f_6355:posixunix_scm",(void*)f_6355},
{"f_6336:posixunix_scm",(void*)f_6336},
{"f_6340:posixunix_scm",(void*)f_6340},
{"f_6318:posixunix_scm",(void*)f_6318},
{"f_6244:posixunix_scm",(void*)f_6244},
{"f_6266:posixunix_scm",(void*)f_6266},
{"f_6272:posixunix_scm",(void*)f_6272},
{"f_6205:posixunix_scm",(void*)f_6205},
{"f_6233:posixunix_scm",(void*)f_6233},
{"f_6229:posixunix_scm",(void*)f_6229},
{"f_6222:posixunix_scm",(void*)f_6222},
{"f_6215:posixunix_scm",(void*)f_6215},
{"f_5946:posixunix_scm",(void*)f_5946},
{"f_6142:posixunix_scm",(void*)f_6142},
{"f_6137:posixunix_scm",(void*)f_6137},
{"f_6132:posixunix_scm",(void*)f_6132},
{"f_5948:posixunix_scm",(void*)f_5948},
{"f_5952:posixunix_scm",(void*)f_5952},
{"f_6058:posixunix_scm",(void*)f_6058},
{"f_6059:posixunix_scm",(void*)f_6059},
{"f_6076:posixunix_scm",(void*)f_6076},
{"f_6086:posixunix_scm",(void*)f_6086},
{"f_6044:posixunix_scm",(void*)f_6044},
{"f_6000:posixunix_scm",(void*)f_6000},
{"f_6036:posixunix_scm",(void*)f_6036},
{"f_6015:posixunix_scm",(void*)f_6015},
{"f_6025:posixunix_scm",(void*)f_6025},
{"f_6009:posixunix_scm",(void*)f_6009},
{"f_6004:posixunix_scm",(void*)f_6004},
{"f_6007:posixunix_scm",(void*)f_6007},
{"f_5954:posixunix_scm",(void*)f_5954},
{"f_5989:posixunix_scm",(void*)f_5989},
{"f_5970:posixunix_scm",(void*)f_5970},
{"f_5464:posixunix_scm",(void*)f_5464},
{"f_5868:posixunix_scm",(void*)f_5868},
{"f_5863:posixunix_scm",(void*)f_5863},
{"f_5858:posixunix_scm",(void*)f_5858},
{"f_5853:posixunix_scm",(void*)f_5853},
{"f_5466:posixunix_scm",(void*)f_5466},
{"f_5470:posixunix_scm",(void*)f_5470},
{"f_5476:posixunix_scm",(void*)f_5476},
{"f_5726:posixunix_scm",(void*)f_5726},
{"f_5732:posixunix_scm",(void*)f_5732},
{"f_5828:posixunix_scm",(void*)f_5828},
{"f_5818:posixunix_scm",(void*)f_5818},
{"f_5812:posixunix_scm",(void*)f_5812},
{"f_5734:posixunix_scm",(void*)f_5734},
{"f_5784:posixunix_scm",(void*)f_5784},
{"f_5741:posixunix_scm",(void*)f_5741},
{"f_5751:posixunix_scm",(void*)f_5751},
{"f_5650:posixunix_scm",(void*)f_5650},
{"f_5658:posixunix_scm",(void*)f_5658},
{"f_5660:posixunix_scm",(void*)f_5660},
{"f_5708:posixunix_scm",(void*)f_5708},
{"f_5641:posixunix_scm",(void*)f_5641},
{"f_5645:posixunix_scm",(void*)f_5645},
{"f_5620:posixunix_scm",(void*)f_5620},
{"f_5630:posixunix_scm",(void*)f_5630},
{"f_5608:posixunix_scm",(void*)f_5608},
{"f_5595:posixunix_scm",(void*)f_5595},
{"f_5599:posixunix_scm",(void*)f_5599},
{"f_5590:posixunix_scm",(void*)f_5590},
{"f_5593:posixunix_scm",(void*)f_5593},
{"f_5508:posixunix_scm",(void*)f_5508},
{"f_5520:posixunix_scm",(void*)f_5520},
{"f_5557:posixunix_scm",(void*)f_5557},
{"f_5566:posixunix_scm",(void*)f_5566},
{"f_5560:posixunix_scm",(void*)f_5560},
{"f_5536:posixunix_scm",(void*)f_5536},
{"f_5539:posixunix_scm",(void*)f_5539},
{"f_5500:posixunix_scm",(void*)f_5500},
{"f_5477:posixunix_scm",(void*)f_5477},
{"f_5481:posixunix_scm",(void*)f_5481},
{"f_5437:posixunix_scm",(void*)f_5437},
{"f_5444:posixunix_scm",(void*)f_5444},
{"f_5447:posixunix_scm",(void*)f_5447},
{"f_5392:posixunix_scm",(void*)f_5392},
{"f_5396:posixunix_scm",(void*)f_5396},
{"f_5431:posixunix_scm",(void*)f_5431},
{"f_5414:posixunix_scm",(void*)f_5414},
{"f_5378:posixunix_scm",(void*)f_5378},
{"f_5390:posixunix_scm",(void*)f_5390},
{"f_5364:posixunix_scm",(void*)f_5364},
{"f_5376:posixunix_scm",(void*)f_5376},
{"f_5349:posixunix_scm",(void*)f_5349},
{"f_5362:posixunix_scm",(void*)f_5362},
{"f_5312:posixunix_scm",(void*)f_5312},
{"f_5320:posixunix_scm",(void*)f_5320},
{"f_5287:posixunix_scm",(void*)f_5287},
{"f_5268:posixunix_scm",(void*)f_5268},
{"f_5272:posixunix_scm",(void*)f_5272},
{"f_5300:posixunix_scm",(void*)f_5300},
{"f_5203:posixunix_scm",(void*)f_5203},
{"f_5207:posixunix_scm",(void*)f_5207},
{"f_5242:posixunix_scm",(void*)f_5242},
{"f_5214:posixunix_scm",(void*)f_5214},
{"f_5217:posixunix_scm",(void*)f_5217},
{"f_5220:posixunix_scm",(void*)f_5220},
{"f_5226:posixunix_scm",(void*)f_5226},
{"f_5165:posixunix_scm",(void*)f_5165},
{"f_5198:posixunix_scm",(void*)f_5198},
{"f_5186:posixunix_scm",(void*)f_5186},
{"f_5194:posixunix_scm",(void*)f_5194},
{"f_5190:posixunix_scm",(void*)f_5190},
{"f_5146:posixunix_scm",(void*)f_5146},
{"f_5156:posixunix_scm",(void*)f_5156},
{"f_5150:posixunix_scm",(void*)f_5150},
{"f_5140:posixunix_scm",(void*)f_5140},
{"f_5134:posixunix_scm",(void*)f_5134},
{"f_5128:posixunix_scm",(void*)f_5128},
{"f_5104:posixunix_scm",(void*)f_5104},
{"f_5126:posixunix_scm",(void*)f_5126},
{"f_5122:posixunix_scm",(void*)f_5122},
{"f_5114:posixunix_scm",(void*)f_5114},
{"f_5074:posixunix_scm",(void*)f_5074},
{"f_5102:posixunix_scm",(void*)f_5102},
{"f_5098:posixunix_scm",(void*)f_5098},
{"f_5047:posixunix_scm",(void*)f_5047},
{"f_5072:posixunix_scm",(void*)f_5072},
{"f_5068:posixunix_scm",(void*)f_5068},
{"f_4983:posixunix_scm",(void*)f_4983},
{"f_4971:posixunix_scm",(void*)f_4971},
{"f_4999:posixunix_scm",(void*)f_4999},
{"f_4909:posixunix_scm",(void*)f_4909},
{"f_4913:posixunix_scm",(void*)f_4913},
{"f_4918:posixunix_scm",(void*)f_4918},
{"f_4934:posixunix_scm",(void*)f_4934},
{"f_4846:posixunix_scm",(void*)f_4846},
{"f_4904:posixunix_scm",(void*)f_4904},
{"f_4850:posixunix_scm",(void*)f_4850},
{"f_4853:posixunix_scm",(void*)f_4853},
{"f_4885:posixunix_scm",(void*)f_4885},
{"f_4856:posixunix_scm",(void*)f_4856},
{"f_4861:posixunix_scm",(void*)f_4861},
{"f_4875:posixunix_scm",(void*)f_4875},
{"f_4753:posixunix_scm",(void*)f_4753},
{"f_4757:posixunix_scm",(void*)f_4757},
{"f_4811:posixunix_scm",(void*)f_4811},
{"f_4760:posixunix_scm",(void*)f_4760},
{"f_4773:posixunix_scm",(void*)f_4773},
{"f_4777:posixunix_scm",(void*)f_4777},
{"f_4783:posixunix_scm",(void*)f_4783},
{"f_4787:posixunix_scm",(void*)f_4787},
{"f_4797:posixunix_scm",(void*)f_4797},
{"f_4781:posixunix_scm",(void*)f_4781},
{"f_4728:posixunix_scm",(void*)f_4728},
{"f_4740:posixunix_scm",(void*)f_4740},
{"f_4736:posixunix_scm",(void*)f_4736},
{"f_4714:posixunix_scm",(void*)f_4714},
{"f_4726:posixunix_scm",(void*)f_4726},
{"f_4722:posixunix_scm",(void*)f_4722},
{"f_4647:posixunix_scm",(void*)f_4647},
{"f_4651:posixunix_scm",(void*)f_4651},
{"f_4693:posixunix_scm",(void*)f_4693},
{"f_4654:posixunix_scm",(void*)f_4654},
{"f_4667:posixunix_scm",(void*)f_4667},
{"f_4671:posixunix_scm",(void*)f_4671},
{"f_4675:posixunix_scm",(void*)f_4675},
{"f_4679:posixunix_scm",(void*)f_4679},
{"f_4683:posixunix_scm",(void*)f_4683},
{"f_4593:posixunix_scm",(void*)f_4593},
{"f_4626:posixunix_scm",(void*)f_4626},
{"f_4597:posixunix_scm",(void*)f_4597},
{"f_4604:posixunix_scm",(void*)f_4604},
{"f_4608:posixunix_scm",(void*)f_4608},
{"f_4612:posixunix_scm",(void*)f_4612},
{"f_4616:posixunix_scm",(void*)f_4616},
{"f_4620:posixunix_scm",(void*)f_4620},
{"f_4575:posixunix_scm",(void*)f_4575},
{"f_4560:posixunix_scm",(void*)f_4560},
{"f_4554:posixunix_scm",(void*)f_4554},
{"f_4522:posixunix_scm",(void*)f_4522},
{"f_4528:posixunix_scm",(void*)f_4528},
{"f_4476:posixunix_scm",(void*)f_4476},
{"f_4494:posixunix_scm",(void*)f_4494},
{"f_4458:posixunix_scm",(void*)f_4458},
{"f_4468:posixunix_scm",(void*)f_4468},
{"f_4445:posixunix_scm",(void*)f_4445},
{"f_4436:posixunix_scm",(void*)f_4436},
{"f_4389:posixunix_scm",(void*)f_4389},
{"f_4393:posixunix_scm",(void*)f_4393},
{"f_4369:posixunix_scm",(void*)f_4369},
{"f_4373:posixunix_scm",(void*)f_4373},
{"f_4379:posixunix_scm",(void*)f_4379},
{"f_4383:posixunix_scm",(void*)f_4383},
{"f_4349:posixunix_scm",(void*)f_4349},
{"f_4353:posixunix_scm",(void*)f_4353},
{"f_4359:posixunix_scm",(void*)f_4359},
{"f_4363:posixunix_scm",(void*)f_4363},
{"f_4325:posixunix_scm",(void*)f_4325},
{"f_4329:posixunix_scm",(void*)f_4329},
{"f_4340:posixunix_scm",(void*)f_4340},
{"f_4344:posixunix_scm",(void*)f_4344},
{"f_4334:posixunix_scm",(void*)f_4334},
{"f_4301:posixunix_scm",(void*)f_4301},
{"f_4305:posixunix_scm",(void*)f_4305},
{"f_4316:posixunix_scm",(void*)f_4316},
{"f_4320:posixunix_scm",(void*)f_4320},
{"f_4310:posixunix_scm",(void*)f_4310},
{"f_4285:posixunix_scm",(void*)f_4285},
{"f_4289:posixunix_scm",(void*)f_4289},
{"f_4292:posixunix_scm",(void*)f_4292},
{"f_4249:posixunix_scm",(void*)f_4249},
{"f_4280:posixunix_scm",(void*)f_4280},
{"f_4270:posixunix_scm",(void*)f_4270},
{"f_4263:posixunix_scm",(void*)f_4263},
{"f_4213:posixunix_scm",(void*)f_4213},
{"f_4244:posixunix_scm",(void*)f_4244},
{"f_4234:posixunix_scm",(void*)f_4234},
{"f_4227:posixunix_scm",(void*)f_4227},
{"f_4198:posixunix_scm",(void*)f_4198},
{"f_4211:posixunix_scm",(void*)f_4211},
{"f_3863:posixunix_scm",(void*)f_3863},
{"f_4170:posixunix_scm",(void*)f_4170},
{"f_3990:posixunix_scm",(void*)f_3990},
{"f_4156:posixunix_scm",(void*)f_4156},
{"f_4145:posixunix_scm",(void*)f_4145},
{"f_4152:posixunix_scm",(void*)f_4152},
{"f_4009:posixunix_scm",(void*)f_4009},
{"f_4138:posixunix_scm",(void*)f_4138},
{"f_4117:posixunix_scm",(void*)f_4117},
{"f_4134:posixunix_scm",(void*)f_4134},
{"f_4123:posixunix_scm",(void*)f_4123},
{"f_4130:posixunix_scm",(void*)f_4130},
{"f_4053:posixunix_scm",(void*)f_4053},
{"f_4114:posixunix_scm",(void*)f_4114},
{"f_4093:posixunix_scm",(void*)f_4093},
{"f_4110:posixunix_scm",(void*)f_4110},
{"f_4099:posixunix_scm",(void*)f_4099},
{"f_4106:posixunix_scm",(void*)f_4106},
{"f_4066:posixunix_scm",(void*)f_4066},
{"f_4090:posixunix_scm",(void*)f_4090},
{"f_4086:posixunix_scm",(void*)f_4086},
{"f_4047:posixunix_scm",(void*)f_4047},
{"f_4016:posixunix_scm",(void*)f_4016},
{"f_4034:posixunix_scm",(void*)f_4034},
{"f_4019:posixunix_scm",(void*)f_4019},
{"f_4023:posixunix_scm",(void*)f_4023},
{"f_4003:posixunix_scm",(void*)f_4003},
{"f_3984:posixunix_scm",(void*)f_3984},
{"f_3870:posixunix_scm",(void*)f_3870},
{"f_3877:posixunix_scm",(void*)f_3877},
{"f_3879:posixunix_scm",(void*)f_3879},
{"f_3886:posixunix_scm",(void*)f_3886},
{"f_3950:posixunix_scm",(void*)f_3950},
{"f_3959:posixunix_scm",(void*)f_3959},
{"f_3892:posixunix_scm",(void*)f_3892},
{"f_3928:posixunix_scm",(void*)f_3928},
{"f_3924:posixunix_scm",(void*)f_3924},
{"f_3920:posixunix_scm",(void*)f_3920},
{"f_3909:posixunix_scm",(void*)f_3909},
{"f_3905:posixunix_scm",(void*)f_3905},
{"f_3807:posixunix_scm",(void*)f_3807},
{"f_3816:posixunix_scm",(void*)f_3816},
{"f_3840:posixunix_scm",(void*)f_3840},
{"f_3852:posixunix_scm",(void*)f_3852},
{"f_3858:posixunix_scm",(void*)f_3858},
{"f_3846:posixunix_scm",(void*)f_3846},
{"f_3822:posixunix_scm",(void*)f_3822},
{"f_3828:posixunix_scm",(void*)f_3828},
{"f_3811:posixunix_scm",(void*)f_3811},
{"f_3743:posixunix_scm",(void*)f_3743},
{"f_3747:posixunix_scm",(void*)f_3747},
{"f_3756:posixunix_scm",(void*)f_3756},
{"f_3717:posixunix_scm",(void*)f_3717},
{"f_3741:posixunix_scm",(void*)f_3741},
{"f_3734:posixunix_scm",(void*)f_3734},
{"f_3560:posixunix_scm",(void*)f_3560},
{"f_3665:posixunix_scm",(void*)f_3665},
{"f_3673:posixunix_scm",(void*)f_3673},
{"f_3660:posixunix_scm",(void*)f_3660},
{"f_3562:posixunix_scm",(void*)f_3562},
{"f_3569:posixunix_scm",(void*)f_3569},
{"f_3572:posixunix_scm",(void*)f_3572},
{"f_3575:posixunix_scm",(void*)f_3575},
{"f_3659:posixunix_scm",(void*)f_3659},
{"f_3579:posixunix_scm",(void*)f_3579},
{"f_3593:posixunix_scm",(void*)f_3593},
{"f_3603:posixunix_scm",(void*)f_3603},
{"f_3606:posixunix_scm",(void*)f_3606},
{"f_3609:posixunix_scm",(void*)f_3609},
{"f_3615:posixunix_scm",(void*)f_3615},
{"f_3625:posixunix_scm",(void*)f_3625},
{"f_3538:posixunix_scm",(void*)f_3538},
{"f_3558:posixunix_scm",(void*)f_3558},
{"f_3545:posixunix_scm",(void*)f_3545},
{"f_3548:posixunix_scm",(void*)f_3548},
{"f_3516:posixunix_scm",(void*)f_3516},
{"f_3536:posixunix_scm",(void*)f_3536},
{"f_3523:posixunix_scm",(void*)f_3523},
{"f_3526:posixunix_scm",(void*)f_3526},
{"f_3357:posixunix_scm",(void*)f_3357},
{"f_3361:posixunix_scm",(void*)f_3361},
{"f_3367:posixunix_scm",(void*)f_3367},
{"f_3488:posixunix_scm",(void*)f_3488},
{"f_3376:posixunix_scm",(void*)f_3376},
{"f_3472:posixunix_scm",(void*)f_3472},
{"f_3449:posixunix_scm",(void*)f_3449},
{"f_3443:posixunix_scm",(void*)f_3443},
{"f_3386:posixunix_scm",(void*)f_3386},
{"f_3388:posixunix_scm",(void*)f_3388},
{"f_3438:posixunix_scm",(void*)f_3438},
{"f_3395:posixunix_scm",(void*)f_3395},
{"f_3421:posixunix_scm",(void*)f_3421},
{"f_3398:posixunix_scm",(void*)f_3398},
{"f_3414:posixunix_scm",(void*)f_3414},
{"f_3370:posixunix_scm",(void*)f_3370},
{"f_3295:posixunix_scm",(void*)f_3295},
{"f_3308:posixunix_scm",(void*)f_3308},
{"f_3320:posixunix_scm",(void*)f_3320},
{"f_3314:posixunix_scm",(void*)f_3314},
{"f_3286:posixunix_scm",(void*)f_3286},
{"f_3293:posixunix_scm",(void*)f_3293},
{"f_3277:posixunix_scm",(void*)f_3277},
{"f_3284:posixunix_scm",(void*)f_3284},
{"f_3268:posixunix_scm",(void*)f_3268},
{"f_3275:posixunix_scm",(void*)f_3275},
{"f_3259:posixunix_scm",(void*)f_3259},
{"f_3266:posixunix_scm",(void*)f_3266},
{"f_3250:posixunix_scm",(void*)f_3250},
{"f_3257:posixunix_scm",(void*)f_3257},
{"f_3241:posixunix_scm",(void*)f_3241},
{"f_3248:posixunix_scm",(void*)f_3248},
{"f_3235:posixunix_scm",(void*)f_3235},
{"f_3239:posixunix_scm",(void*)f_3239},
{"f_3229:posixunix_scm",(void*)f_3229},
{"f_3233:posixunix_scm",(void*)f_3233},
{"f_3223:posixunix_scm",(void*)f_3223},
{"f_3227:posixunix_scm",(void*)f_3227},
{"f_3217:posixunix_scm",(void*)f_3217},
{"f_3221:posixunix_scm",(void*)f_3221},
{"f_3207:posixunix_scm",(void*)f_3207},
{"f_3211:posixunix_scm",(void*)f_3211},
{"f_3175:posixunix_scm",(void*)f_3175},
{"f_3186:posixunix_scm",(void*)f_3186},
{"f_3179:posixunix_scm",(void*)f_3179},
{"f_3138:posixunix_scm",(void*)f_3138},
{"f_3170:posixunix_scm",(void*)f_3170},
{"f_3163:posixunix_scm",(void*)f_3163},
{"f_3142:posixunix_scm",(void*)f_3142},
{"f_2858:posixunix_scm",(void*)f_2858},
{"f_3097:posixunix_scm",(void*)f_3097},
{"f_3105:posixunix_scm",(void*)f_3105},
{"f_2874:posixunix_scm",(void*)f_2874},
{"f_3049:posixunix_scm",(void*)f_3049},
{"f_3057:posixunix_scm",(void*)f_3057},
{"f_2880:posixunix_scm",(void*)f_2880},
{"f_2883:posixunix_scm",(void*)f_2883},
{"f_2987:posixunix_scm",(void*)f_2987},
{"f_2995:posixunix_scm",(void*)f_2995},
{"f_2985:posixunix_scm",(void*)f_2985},
{"f_2922:posixunix_scm",(void*)f_2922},
{"f_2940:posixunix_scm",(void*)f_2940},
{"f_2948:posixunix_scm",(void*)f_2948},
{"f_2938:posixunix_scm",(void*)f_2938},
{"f_2800:posixunix_scm",(void*)f_2800},
{"f_2807:posixunix_scm",(void*)f_2807},
{"f_2813:posixunix_scm",(void*)f_2813},
{"f_2820:posixunix_scm",(void*)f_2820},
{"f_2761:posixunix_scm",(void*)f_2761},
{"f_2768:posixunix_scm",(void*)f_2768},
{"f_2777:posixunix_scm",(void*)f_2777},
{"f_2719:posixunix_scm",(void*)f_2719},
{"f_2729:posixunix_scm",(void*)f_2729},
{"f_2732:posixunix_scm",(void*)f_2732},
{"f_2735:posixunix_scm",(void*)f_2735},
{"f_2704:posixunix_scm",(void*)f_2704},
{"f_2666:posixunix_scm",(void*)f_2666},
{"f_2696:posixunix_scm",(void*)f_2696},
{"f_2683:posixunix_scm",(void*)f_2683},
{"f_2686:posixunix_scm",(void*)f_2686},
{"f_2620:posixunix_scm",(void*)f_2620},
{"f_2624:posixunix_scm",(void*)f_2624},
{"f_2563:posixunix_scm",(void*)f_2563},
{"f_2556:posixunix_scm",(void*)f_2556},
{"f_2538:posixunix_scm",(void*)f_2538},
{"f_2542:posixunix_scm",(void*)f_2542},
{"f_2553:posixunix_scm",(void*)f_2553},
{"f_2549:posixunix_scm",(void*)f_2549},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
