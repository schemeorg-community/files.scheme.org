/* Generated from ./setup-api.import.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:20
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: ./setup-api.import.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature chicken-compile-shared -dynamic -no-trace -ignore-repository -output-file setup-api.import.c
   used units: library eval
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[29];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,18),40,102,111,114,109,45,101,114,114,111,114,32,115,55,32,112,56,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,12),40,103,54,49,32,108,105,110,101,54,51,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,52,53,32,103,53,53,53,57,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,13),40,97,52,52,51,32,108,105,110,101,50,51,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,18),40,97,50,54,56,32,102,111,114,109,48,32,114,49,32,99,50,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,39),40,97,50,51,52,32,105,110,112,117,116,56,51,57,54,32,114,101,110,97,109,101,57,50,57,55,32,99,111,109,112,97,114,101,56,48,57,56,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,13),40,97,50,49,55,32,101,120,112,49,51,56,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,45),40,97,49,56,50,32,105,110,112,117,116,49,49,51,49,50,54,32,114,101,110,97,109,101,49,50,50,49,50,55,32,99,111,109,112,97,114,101,49,49,48,49,50,56,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_148)
static void C_ccall f_148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_151)
static void C_ccall f_151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_154)
static void C_ccall f_154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_183)
static void C_ccall f_183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_193)
static void C_ccall f_193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_200)
static void C_ccall f_200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_212)
static void C_ccall f_212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_218)
static void C_ccall f_218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_226)
static void C_ccall f_226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_216)
static void C_ccall f_216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_235)
static void C_ccall f_235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_245)
static void C_ccall f_245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_252)
static void C_ccall f_252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_264)
static void C_ccall f_264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_269)
static void C_ccall f_269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_273)
static void C_ccall f_273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_279)
static void C_ccall f_279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_282)
static void C_ccall f_282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_439)
static void C_ccall f_439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_444)
static void C_ccall f_444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_451)
static void C_fcall f_451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_454)
static void C_ccall f_454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_290)
static void C_ccall f_290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_297)
static void C_ccall f_297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_333)
static void C_fcall f_333(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_420)
static void C_ccall f_420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_360)
static void C_fcall f_360(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_409)
static void C_ccall f_409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_384)
static void C_ccall f_384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_331)
static void C_ccall f_331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_327)
static void C_ccall f_327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_309)
static void C_ccall f_309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_283)
static void C_fcall f_283(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_157)
static void C_ccall f_157(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_451)
static void C_fcall trf_451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_451(t0,t1);}

C_noret_decl(trf_333)
static void C_fcall trf_333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_333(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_333(t0,t1,t2);}

C_noret_decl(trf_360)
static void C_fcall trf_360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_360(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_360(t0,t1,t2);}

C_noret_decl(trf_283)
static void C_fcall trf_283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_283(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_283(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1465)){
C_save(t1);
C_rereclaim2(1465*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,29);
lf[0]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007execute\376\001\000\000\021setup-api#execute");
lf[1]=C_h_intern(&lf[1],5,"error");
lf[2]=C_h_intern(&lf[2],4,"list");
lf[3]=C_h_intern(&lf[3],10,"\003sysappend");
lf[4]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[5]=C_h_intern(&lf[5],9,"make/proc");
lf[6]=C_h_intern(&lf[6],15,"make:line-error");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\047second part of clause is not a sequence");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000%clause does not have at least 2 parts");
lf[9]=C_h_intern(&lf[9],5,"every");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\023empty specification");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000&illegal specification (not a sequence)");
lf[12]=C_h_intern(&lf[12],6,"lambda");
lf[13]=C_h_intern(&lf[13],16,"\003syscheck-syntax");
lf[14]=C_h_intern(&lf[14],4,"make");
lf[15]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[16]=C_h_intern(&lf[16],3,"csc");
lf[17]=C_h_intern(&lf[17],3,"run");
lf[18]=C_h_intern(&lf[18],25,"\003syssyntax-rules-mismatch");
lf[19]=C_h_intern(&lf[19],9,"\003syslist\077");
lf[20]=C_h_intern(&lf[20],7,"compile");
lf[21]=C_h_intern(&lf[21],10,"quasiquote");
lf[22]=C_h_intern(&lf[22],9,"\003sysmap-n");
lf[23]=C_h_intern(&lf[23],7,"execute");
lf[24]=C_h_intern(&lf[24],28,"\003sysregister-compiled-module");
lf[25]=C_h_intern(&lf[25],9,"setup-api");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011move-file\376\001\000\000\023setup-api#move-file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022standard-extensio"
"n\376\001\000\000\034setup-api#standard-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011make/proc\376\001\000\000\023setup-api#make/pr"
"oc\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016host-extension\376\001\000\000\030setup-api#host-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021insta"
"ll-extension\376\001\000\000\033setup-api#install-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017install-program\376\001\000\000\031s"
"etup-api#install-program\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016install-script\376\001\000\000\030setup-api#install-scri"
"pt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022setup-verbose-mode\376\001\000\000\034setup-api#setup-verbose-mode\376\003\000\000\002\376\003\000\000\002\376\001"
"\000\000\022setup-install-mode\376\001\000\000\034setup-api#setup-install-mode\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017deployment-"
"mode\376\001\000\000\031setup-api#deployment-mode\376\003\000\000\002\376\003\000\000\002\376\001\000\000\023installation-prefix\376\001\000\000\035setup-a"
"pi#installation-prefix\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016chicken-prefix\376\001\000\000\030setup-api#chicken-prefix"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014find-library\376\001\000\000\026setup-api#find-library\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013find-header"
"\376\001\000\000\025setup-api#find-header\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014program-path\376\001\000\000\026setup-api#program-path"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014remove-file*\376\001\000\000\026setup-api#remove-file*\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005patch\376\001\000\000\017s"
"etup-api#patch\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012yes-or-no\077\376\001\000\000\024setup-api#yes-or-no\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013a"
"bort-setup\376\001\000\000\025setup-api#abort-setup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024setup-root-directory\376\001\000\000\036setu"
"p-api#setup-root-directory\376\003\000\000\002\376\003\000\000\002\376\001\000\000\030create-directory/parents\376\001\000\000\042setup-api#"
"create-directory/parents\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014test-compile\376\001\000\000\026setup-api#test-compile\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\013try-compile\376\001\000\000\025setup-api#try-compile\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011copy-file\376\001\000\000\023s"
"etup-api#copy-file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013run-verbose\376\001\000\000\025setup-api#run-verbose\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\030required-chicken-version\376\001\000\000\042setup-api#required-chicken-version\376\003\000\000\002\376\003\000\000\002\376\001"
"\000\000\032required-extension-version\376\001\000\000$setup-api#required-extension-version\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\015cross-chicken\376\001\000\000\027setup-api#cross-chicken\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014sudo-install\376\001\000\000\026se"
"tup-api#sudo-install\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022keep-intermediates\376\001\000\000\034setup-api#keep-interme"
"diates\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012version>=\077\376\001\000\000\024setup-api#version>=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\032extension"
"-name-and-version\376\001\000\000$setup-api#extension-name-and-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016extensi"
"on-name\376\001\000\000\030setup-api#extension-name\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021extension-version\376\001\000\000\033setup-a"
"pi#extension-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\032create-temporary-directory\376\001\000\000$setup-api#crea"
"te-temporary-directory\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020remove-directory\376\001\000\000\032setup-api#remove-direc"
"tory\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020remove-extension\376\001\000\000\032setup-api#remove-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\011read-info\376\001\000\000\023setup-api#read-info\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011shellpath\376\001\000\000\023setup-api#shellpa"
"th\376\377\016");
lf[27]=C_h_intern(&lf[27],4,"eval");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006import\376\003\000\000\002\376\001\000\000\006scheme\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\007foreign\376\003\000\000\002\376\001\000\000\005rege"
"x\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\005ports\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\017data-str"
"uctures\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000\000\005files\376\377\016");
C_register_lf2(lf,29,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_148,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k146 */
static void C_ccall f_148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_151,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k149 in k146 */
static void C_ccall f_151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_154,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ./setup-api.import.scm: 3    eval */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t2,lf[28]);}

/* k152 in k149 in k146 */
static void C_ccall f_154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_157,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[0]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_269,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[14],t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_235,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[20],t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_183,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_cons(&a,2,lf[17],t8);
t10=(C_word)C_a_i_list(&a,3,t5,t7,t9);
/* ./setup-api.import.scm: 16   ##sys#register-compiled-module */
((C_proc7)C_retrieve_symbol_proc(lf[24]))(7,*((C_word*)lf[24]+1),t2,lf[25],t3,lf[26],t10,C_SCHEME_END_OF_LIST);}

/* a182 in k152 in k149 in k146 */
static void C_ccall f_183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_183,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_193,a[2]=t2,a[3]=t5,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#list? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t6,t5);}

/* k191 in a182 in k152 in k149 in k146 */
static void C_ccall f_193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_193,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* rename122127 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[23]);}
else{
/* ##sys#syntax-rules-mismatch */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k198 in k191 in a182 in k152 in k149 in k146 */
static void C_ccall f_200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* rename122127 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[2]);}

/* k210 in k198 in k191 in a182 in k152 in k149 in k146 */
static void C_ccall f_212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_216,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_218,a[2]=((C_word*)t0)[3],a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
/* ##sys#map-n */
((C_proc4)C_retrieve_symbol_proc(lf[22]))(4,*((C_word*)lf[22]+1),t2,t3,((C_word*)t0)[2]);}

/* a217 in k210 in k198 in k191 in a182 in k152 in k149 in k146 */
static void C_ccall f_218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_218,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_226,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* rename122127 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[21]);}

/* k224 in a217 in k210 in k198 in k191 in a182 in k152 in k149 in k146 */
static void C_ccall f_226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_226,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k214 in k210 in k198 in k191 in a182 in k152 in k149 in k146 */
static void C_ccall f_216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_216,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a234 in k152 in k149 in k146 */
static void C_ccall f_235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_235,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_245,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* ##sys#list? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t6,t5);}

/* k243 in a234 in k152 in k149 in k146 */
static void C_ccall f_245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_245,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* rename9297 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[17]);}
else{
/* ##sys#syntax-rules-mismatch */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k250 in k243 in a234 in k152 in k149 in k146 */
static void C_ccall f_252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_264,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* rename9297 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[16]);}

/* k262 in k250 in k243 in a234 in k152 in k149 in k146 */
static void C_ccall f_264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_264,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a268 in k152 in k149 in k146 */
static void C_ccall f_269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_269,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_273,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ./setup-api.import.scm: 60   ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t5,lf[14],t2,lf[15]);}

/* k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_273,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ./setup-api.import.scm: 62   r */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[2]);}

/* k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_282,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ./setup-api.import.scm: 63   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[12]);}

/* k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_283,a[2]=((C_word*)t0)[6],a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_listp(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_430,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_430(2,t6,t4);}
else{
/* ./setup-api.import.scm: 66   form-error */
t6=t2;
f_283(t6,t5,lf[11],C_SCHEME_END_OF_LIST);}}

/* k428 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_430,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_439,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_439(2,t4,t2);}
else{
/* ./setup-api.import.scm: 68   form-error */
t4=((C_word*)t0)[3];
f_283(t4,t3,lf[10],C_SCHEME_END_OF_LIST);}}
else{
t2=((C_word*)t0)[2];
f_290(2,t2,C_SCHEME_FALSE);}}

/* k437 in k428 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_439,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_444,a[2]=((C_word*)t0)[4],a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp);
/* ./setup-api.import.scm: 69   every */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_290(2,t2,C_SCHEME_FALSE);}}

/* a443 in k437 in k428 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_444,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_451,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=t3;
f_451(t5,(C_word)C_i_greater_or_equalp(t4,C_fix(2)));}
else{
t4=t3;
f_451(t4,C_SCHEME_FALSE);}}

/* k449 in a443 in k437 in k428 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_fcall f_451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_451,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_454(2,t3,t1);}
else{
/* ./setup-api.import.scm: 71   form-error */
t3=((C_word*)t0)[2];
f_283(t3,t2,lf[8],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}}

/* k452 in k449 in a443 in k437 in k428 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_listp(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* ./setup-api.import.scm: 76   make:line-error */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),((C_word*)t0)[2],lf[7],t5,t2);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k288 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ./setup-api.import.scm: 81   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[5]);}

/* k295 in k288 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_327,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_331,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_333,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word)li2),tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_333(t11,t7,((C_word*)t0)[2]);}

/* loop45 in k295 in k288 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_fcall f_333(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_333,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_360,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_420,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g6162 */
t6=t3;
f_360(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k418 in loop45 in k295 in k288 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_420,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop4558 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_333(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop4558 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_333(t6,((C_word*)t0)[3],t5);}}

/* g61 in loop45 in k295 in k288 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_fcall f_360(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_360,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(t2);
/* ##sys#append */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k411 in g61 in loop45 in k295 in k288 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_413,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_384,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
/* ##sys#append */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_409,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}}

/* k407 in k411 in g61 in loop45 in k295 in k288 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_409,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t4,C_SCHEME_END_OF_LIST);}

/* k382 in k411 in g61 in loop45 in k295 in k288 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_384,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k329 in k295 in k288 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k325 in k295 in k288 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_327,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[2],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_nullp(t4))){
/* ##sys#append */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[4],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,C_SCHEME_END_OF_LIST);}}

/* k307 in k325 in k295 in k288 in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_ccall f_309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_309,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* form-error in k280 in k277 in k271 in a268 in k152 in k149 in k146 */
static void C_fcall f_283(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_283,NULL,4,t0,t1,t2,t3);}
C_apply(6,0,t1,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],t3);}

/* k155 in k152 in k149 in k146 */
static void C_ccall f_157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[38] = {
{"toplevel:__setup_api_import_scm",(void*)C_toplevel},
{"f_148:__setup_api_import_scm",(void*)f_148},
{"f_151:__setup_api_import_scm",(void*)f_151},
{"f_154:__setup_api_import_scm",(void*)f_154},
{"f_183:__setup_api_import_scm",(void*)f_183},
{"f_193:__setup_api_import_scm",(void*)f_193},
{"f_200:__setup_api_import_scm",(void*)f_200},
{"f_212:__setup_api_import_scm",(void*)f_212},
{"f_218:__setup_api_import_scm",(void*)f_218},
{"f_226:__setup_api_import_scm",(void*)f_226},
{"f_216:__setup_api_import_scm",(void*)f_216},
{"f_235:__setup_api_import_scm",(void*)f_235},
{"f_245:__setup_api_import_scm",(void*)f_245},
{"f_252:__setup_api_import_scm",(void*)f_252},
{"f_264:__setup_api_import_scm",(void*)f_264},
{"f_269:__setup_api_import_scm",(void*)f_269},
{"f_273:__setup_api_import_scm",(void*)f_273},
{"f_279:__setup_api_import_scm",(void*)f_279},
{"f_282:__setup_api_import_scm",(void*)f_282},
{"f_430:__setup_api_import_scm",(void*)f_430},
{"f_439:__setup_api_import_scm",(void*)f_439},
{"f_444:__setup_api_import_scm",(void*)f_444},
{"f_451:__setup_api_import_scm",(void*)f_451},
{"f_454:__setup_api_import_scm",(void*)f_454},
{"f_290:__setup_api_import_scm",(void*)f_290},
{"f_297:__setup_api_import_scm",(void*)f_297},
{"f_333:__setup_api_import_scm",(void*)f_333},
{"f_420:__setup_api_import_scm",(void*)f_420},
{"f_360:__setup_api_import_scm",(void*)f_360},
{"f_413:__setup_api_import_scm",(void*)f_413},
{"f_409:__setup_api_import_scm",(void*)f_409},
{"f_384:__setup_api_import_scm",(void*)f_384},
{"f_331:__setup_api_import_scm",(void*)f_331},
{"f_327:__setup_api_import_scm",(void*)f_327},
{"f_309:__setup_api_import_scm",(void*)f_309},
{"f_283:__setup_api_import_scm",(void*)f_283},
{"f_157:__setup_api_import_scm",(void*)f_157},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
