/* Generated from regex.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: regex.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file uregex.c
   unit: regex
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[313];
static double C_possibly_force_alignment;


C_noret_decl(C_regex_toplevel)
C_externexport void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22312)
static void C_ccall f_22312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_22319)
static void C_ccall f_22319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22327)
static void C_fcall f_22327(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_22359)
static void C_ccall f_22359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22346)
static void C_ccall f_22346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22349)
static void C_ccall f_22349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22245)
static void C_ccall f_22245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_22245)
static void C_ccall f_22245r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_22255)
static void C_ccall f_22255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22258)
static void C_ccall f_22258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22263)
static void C_fcall f_22263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_22296)
static void C_ccall f_22296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22282)
static void C_ccall f_22282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22289)
static void C_ccall f_22289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22300)
static void C_ccall f_22300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21968)
static void C_ccall f_21968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21983)
static void C_ccall f_21983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21985)
static void C_fcall f_21985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_22240)
static void C_ccall f_22240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22236)
static void C_ccall f_22236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22225)
static void C_ccall f_22225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22047)
static void C_fcall f_22047(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_22077)
static void C_fcall f_22077(C_word t0,C_word t1) C_noret;
C_noret_decl(f_22106)
static void C_fcall f_22106(C_word t0,C_word t1) C_noret;
C_noret_decl(f_22154)
static void C_ccall f_22154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22133)
static void C_ccall f_22133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22129)
static void C_ccall f_22129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22096)
static void C_ccall f_22096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22092)
static void C_ccall f_22092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22067)
static void C_ccall f_22067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22045)
static void C_ccall f_22045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22032)
static void C_ccall f_22032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22019)
static void C_ccall f_22019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_22015)
static void C_ccall f_22015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21979)
static void C_ccall f_21979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21883)
static void C_ccall f_21883(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21896)
static void C_fcall f_21896(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21915)
static void C_fcall f_21915(C_word t0,C_word t1) C_noret;
C_noret_decl(f_21831)
static void C_ccall f_21831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_21831)
static void C_ccall f_21831r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_21846)
static void C_fcall f_21846(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21863)
static void C_ccall f_21863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21576)
static void C_ccall f_21576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_21576)
static void C_ccall f_21576r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_21718)
static void C_fcall f_21718(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21722)
static void C_ccall f_21722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21813)
static void C_ccall f_21813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21809)
static void C_ccall f_21809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21780)
static void C_ccall f_21780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21762)
static void C_ccall f_21762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21755)
static void C_ccall f_21755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21612)
static void C_fcall f_21612(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21618)
static void C_fcall f_21618(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21685)
static void C_ccall f_21685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21673)
static void C_ccall f_21673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21632)
static void C_ccall f_21632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21597)
static C_word C_fcall f_21597(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_21394)
static void C_ccall f_21394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_21394)
static void C_ccall f_21394r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_21558)
static void C_ccall f_21558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21532)
static void C_ccall f_21532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21557)
static void C_ccall f_21557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21512)
static void C_ccall f_21512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21413)
static void C_fcall f_21413(C_word t0,C_word t1) C_noret;
C_noret_decl(f_21421)
static void C_fcall f_21421(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21425)
static void C_ccall f_21425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21486)
static void C_ccall f_21486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21467)
static void C_ccall f_21467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21501)
static void C_ccall f_21501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_21496)
static void C_ccall f_21496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_21274)
static void C_ccall f_21274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_21274)
static void C_ccall f_21274r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_21349)
static void C_fcall f_21349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_21340)
static void C_fcall f_21340(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21276)
static void C_fcall f_21276(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21280)
static void C_ccall f_21280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21335)
static void C_ccall f_21335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21289)
static void C_ccall f_21289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21299)
static void C_ccall f_21299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21301)
static void C_fcall f_21301(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21162)
static void C_ccall f_21162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_21162)
static void C_ccall f_21162r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_21229)
static void C_fcall f_21229(C_word t0,C_word t1) C_noret;
C_noret_decl(f_21220)
static void C_fcall f_21220(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_21164)
static void C_fcall f_21164(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21168)
static void C_ccall f_21168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21215)
static void C_ccall f_21215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21177)
static void C_ccall f_21177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21187)
static void C_ccall f_21187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21189)
static void C_fcall f_21189(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21211)
static void C_ccall f_21211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21100)
static void C_ccall f_21100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21104)
static void C_ccall f_21104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21107)
static void C_ccall f_21107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21117)
static void C_ccall f_21117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21119)
static void C_fcall f_21119(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21054)
static void C_ccall f_21054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21058)
static void C_ccall f_21058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21061)
static void C_ccall f_21061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21071)
static void C_ccall f_21071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21073)
static void C_fcall f_21073(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_21098)
static void C_ccall f_21098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21033)
static void C_fcall f_21033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_21040)
static void C_ccall f_21040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_21049)
static void C_ccall f_21049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20930)
static void C_ccall f_20930(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_20930)
static void C_ccall f_20930r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_20973)
static void C_fcall f_20973(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20968)
static void C_fcall f_20968(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20963)
static void C_fcall f_20963(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20932)
static void C_fcall f_20932(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_20944)
static void C_fcall f_20944(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20947)
static void C_fcall f_20947(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20940)
static void C_ccall f_20940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20912)
static void C_ccall f_20912(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20730)
static void C_ccall f_20730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20736)
static void C_fcall f_20736(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20858)
static void C_ccall f_20858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20862)
static void C_ccall f_20862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20870)
static void C_ccall f_20870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20854)
static void C_ccall f_20854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20829)
static void C_ccall f_20829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20833)
static void C_ccall f_20833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20825)
static void C_ccall f_20825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20795)
static void C_ccall f_20795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20764)
static void C_ccall f_20764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20674)
static void C_ccall f_20674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_20674)
static void C_ccall f_20674r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_20707)
static void C_ccall f_20707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20728)
static void C_ccall f_20728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20680)
static void C_ccall f_20680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_20684)
static void C_ccall f_20684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20691)
static void C_ccall f_20691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20705)
static void C_ccall f_20705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20622)
static void C_ccall f_20622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_20622)
static void C_ccall f_20622r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_20672)
static void C_ccall f_20672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20626)
static void C_ccall f_20626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20664)
static void C_ccall f_20664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20640)
static void C_ccall f_20640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20648)
static void C_ccall f_20648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20660)
static void C_ccall f_20660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20656)
static void C_ccall f_20656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20644)
static void C_ccall f_20644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20509)
static void C_ccall f_20509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_20509)
static void C_ccall f_20509r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_20513)
static void C_ccall f_20513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20516)
static void C_ccall f_20516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20522)
static void C_fcall f_20522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20525)
static void C_fcall f_20525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20533)
static void C_fcall f_20533(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20546)
static void C_ccall f_20546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20558)
static void C_ccall f_20558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20561)
static void C_ccall f_20561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20564)
static void C_ccall f_20564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20619)
static void C_ccall f_20619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20344)
static void C_ccall f_20344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20350)
static void C_fcall f_20350(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20366)
static void C_fcall f_20366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20403)
static void C_fcall f_20403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20461)
static void C_ccall f_20461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20418)
static void C_ccall f_20418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20414)
static void C_ccall f_20414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20386)
static void C_ccall f_20386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20334)
static void C_fcall f_20334(C_word t0,C_word t1) C_noret;
C_noret_decl(f_20342)
static void C_ccall f_20342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20211)
static void C_ccall f_20211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20217)
static void C_fcall f_20217(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_20324)
static void C_ccall f_20324(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20227)
static void C_ccall f_20227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20231)
static void C_fcall f_20231(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20296)
static void C_ccall f_20296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20237)
static void C_ccall f_20237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_20288)
static void C_ccall f_20288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20241)
static void C_ccall f_20241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20250)
static void C_ccall f_20250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20253)
static void C_ccall f_20253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20260)
static void C_ccall f_20260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20085)
static void C_fcall f_20085(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20197)
static void C_ccall f_20197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20108)
static void C_ccall f_20108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20112)
static void C_fcall f_20112(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20169)
static void C_ccall f_20169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20118)
static void C_ccall f_20118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_20161)
static void C_ccall f_20161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20122)
static void C_ccall f_20122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20131)
static void C_ccall f_20131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20134)
static void C_ccall f_20134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19993)
static void C_ccall f_19993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_20075)
static void C_ccall f_20075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20003)
static void C_ccall f_20003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20007)
static void C_fcall f_20007(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_20051)
static void C_ccall f_20051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20023)
static void C_ccall f_20023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_20015)
static void C_ccall f_20015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19848)
static void C_fcall f_19848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19864)
static void C_fcall f_19864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19798)
static void C_fcall f_19798(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f27494)
static void C_ccall f27494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19804)
static void C_ccall f_19804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19377)
static void C_fcall f_19377(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19387)
static void C_fcall f_19387(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19656)
static void C_ccall f_19656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19666)
static void C_fcall f_19666(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19695)
static void C_ccall f_19695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19660)
static void C_ccall f_19660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13742)
static void C_fcall f_13742(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13769)
static void C_ccall f_13769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13765)
static void C_ccall f_13765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19639)
static void C_ccall f_19639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19301)
static void C_fcall f_19301(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19629)
static void C_ccall f_19629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19573)
static void C_ccall f_19573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19583)
static void C_fcall f_19583(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19612)
static void C_ccall f_19612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19577)
static void C_ccall f_19577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19565)
static void C_ccall f_19565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_19507)
static void C_ccall f_19507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19517)
static void C_fcall f_19517(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19546)
static void C_ccall f_19546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19511)
static void C_ccall f_19511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19447)
static void C_ccall f_19447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19457)
static void C_fcall f_19457(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19486)
static void C_ccall f_19486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19451)
static void C_ccall f_19451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19443)
static void C_ccall f_19443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19416)
static void C_ccall f_19416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19390)
static void C_fcall f_19390(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19260)
static void C_fcall f_19260(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_19262)
static void C_ccall f_19262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_19269)
static void C_ccall f_19269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16862)
static void C_fcall f_16862(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16902)
static void C_ccall f_16902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16746)
static void C_fcall f_16746(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16752)
static void C_fcall f_16752(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16836)
static void C_ccall f_16836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16799)
static void C_ccall f_16799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16801)
static void C_fcall f_16801(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16830)
static void C_ccall f_16830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16791)
static void C_ccall f_16791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16779)
static void C_ccall f_16779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16783)
static void C_ccall f_16783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16630)
static void C_fcall f_16630(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16663)
static void C_fcall f_16663(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16667)
static void C_fcall f_16667(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16644)
static void C_ccall f_16644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16556)
static void C_fcall f_16556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16564)
static void C_fcall f_16564(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16082)
static void C_fcall f_16082(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16291)
static void C_fcall f_16291(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16319)
static void C_fcall f_16319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16476)
static void C_fcall f_16476(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16377)
static void C_fcall f_16377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16447)
static void C_ccall f_16447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16382)
static void C_ccall f_16382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_16435)
static void C_ccall f_16435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16395)
static void C_fcall f_16395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16398)
static void C_fcall f_16398(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16405)
static void C_ccall f_16405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16363)
static void C_ccall f_16363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16324)
static void C_ccall f_16324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16351)
static void C_ccall f_16351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16335)
static void C_ccall f_16335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16113)
static void C_fcall f_16113(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16162)
static void C_fcall f_16162(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16229)
static void C_ccall f_16229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16167)
static void C_ccall f_16167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16217)
static void C_ccall f_16217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16183)
static void C_fcall f_16183(C_word t0,C_word t1) C_noret;
C_noret_decl(f_16179)
static void C_ccall f_16179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16148)
static void C_ccall f_16148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16085)
static void C_fcall f_16085(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15564)
static void C_fcall f_15564(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15714)
static void C_ccall f_15714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15577)
static void C_fcall f_15577(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_15959)
static void C_fcall f_15959(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_16072)
static void C_ccall f_16072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15977)
static void C_fcall f_15977(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16023)
static void C_ccall f_16023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16004)
static void C_fcall f_16004(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_16016)
static void C_ccall f_16016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15610)
static void C_ccall f_15610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15622)
static void C_fcall f_15622(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15663)
static void C_fcall f_15663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15692)
static void C_ccall f_15692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15657)
static void C_ccall f_15657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15629)
static void C_ccall f_15629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15653)
static void C_ccall f_15653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15645)
static void C_ccall f_15645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15591)
static void C_ccall f_15591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15918)
static void C_fcall f_15918(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15859)
static void C_ccall f_15859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15863)
static void C_ccall f_15863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15865)
static void C_fcall f_15865(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_15898)
static void C_ccall f_15898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15878)
static void C_fcall f_15878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15734)
static void C_ccall f_15734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15753)
static void C_fcall f_15753(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15851)
static void C_ccall f_15851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15780)
static void C_fcall f_15780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15798)
static void C_fcall f_15798(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15825)
static C_word C_fcall f_15825(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_15792)
static void C_ccall f_15792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15751)
static void C_ccall f_15751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15736)
static C_word C_fcall f_15736(C_word t0,C_word t1);
C_noret_decl(f_14706)
static void C_fcall f_14706(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14724)
static void C_fcall f_14724(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_15021)
static void C_fcall f_15021(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15075)
static void C_fcall f_15075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15369)
static void C_ccall f_15369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15457)
static void C_ccall f_15457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15375)
static void C_ccall f_15375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15453)
static void C_ccall f_15453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15378)
static void C_ccall f_15378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15433)
static void C_ccall f_15433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15384)
static void C_fcall f_15384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15403)
static void C_ccall f_15403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15309)
static void C_ccall f_15309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15353)
static void C_ccall f_15353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15315)
static void C_ccall f_15315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15337)
static void C_ccall f_15337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15206)
static void C_ccall f_15206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15288)
static void C_ccall f_15288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15209)
static void C_ccall f_15209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15273)
static void C_ccall f_15273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15212)
static void C_ccall f_15212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15238)
static void C_ccall f_15238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15230)
static void C_ccall f_15230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15234)
static void C_ccall f_15234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15226)
static void C_ccall f_15226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25590)
static void C_ccall f25590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15078)
static void C_ccall f_15078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15105)
static void C_ccall f_15105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15133)
static void C_fcall f_15133(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_15143)
static void C_fcall f_15143(C_word t0,C_word t1) C_noret;
C_noret_decl(f_15131)
static void C_ccall f_15131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15119)
static void C_ccall f_15119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15123)
static void C_ccall f_15123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15094)
static void C_ccall f_15094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15024)
static void C_ccall f_15024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15030)
static void C_ccall f_15030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15044)
static void C_ccall f_15044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_15004)
static void C_ccall f_15004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14981)
static void C_ccall f_14981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25581)
static void C_ccall f25581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14871)
static void C_fcall f_14871(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14893)
static void C_ccall f_14893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14878)
static void C_ccall f_14878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14848)
static void C_ccall f_14848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14827)
static void C_ccall f_14827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14823)
static void C_ccall f_14823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14741)
static void C_fcall f_14741(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14756)
static void C_ccall f_14756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14762)
static void C_fcall f_14762(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14789)
static C_word C_fcall f_14789(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_14760)
static void C_ccall f_14760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14727)
static void C_fcall f_14727(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14599)
static void C_fcall f_14599(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14613)
static void C_fcall f_14613(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f27441)
static void C_ccall f27441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14651)
static void C_ccall f_14651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14421)
static void C_ccall f_14421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14425)
static void C_ccall f_14425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14428)
static void C_ccall f_14428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14440)
static void C_ccall f_14440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14468)
static void C_ccall f_14468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14485)
static void C_ccall f_14485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14471)
static void C_ccall f_14471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14465)
static void C_ccall f_14465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14443)
static void C_ccall f_14443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14458)
static void C_ccall f_14458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14461)
static void C_ccall f_14461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14262)
static void C_ccall f_14262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_14269)
static void C_ccall f_14269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14385)
static void C_ccall f_14385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14390)
static void C_fcall f_14390(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14418)
static void C_ccall f_14418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14400)
static void C_ccall f_14400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14382)
static void C_ccall f_14382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25563)
static void C_ccall f25563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14378)
static void C_ccall f_14378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14520)
static void C_fcall f_14520(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f27431)
static void C_ccall f27431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14555)
static void C_ccall f_14555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14300)
static void C_ccall f_14300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14374)
static void C_ccall f_14374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14309)
static void C_ccall f_14309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14315)
static void C_ccall f_14315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14320)
static void C_fcall f_14320(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14330)
static void C_ccall f_14330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14342)
static void C_ccall f_14342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14345)
static void C_ccall f_14345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14297)
static void C_ccall f_14297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14278)
static void C_ccall f_14278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14290)
static void C_ccall f_14290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14293)
static void C_ccall f_14293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14216)
static void C_ccall f_14216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_14216)
static void C_ccall f_14216r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_14220)
static void C_ccall f_14220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14226)
static void C_fcall f_14226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14229)
static void C_ccall f_14229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14064)
static void C_ccall f_14064(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14083)
static void C_fcall f_14083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14160)
static void C_fcall f_14160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14189)
static void C_ccall f_14189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14154)
static void C_ccall f_14154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14121)
static void C_ccall f_14121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14028)
static void C_fcall f_14028(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14058)
static void C_ccall f_14058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14050)
static void C_ccall f_14050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13798)
static void C_fcall f_13798(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13896)
static void C_fcall f_13896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13648)
static void C_ccall f_13648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13697)
static void C_fcall f_13697(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13726)
static void C_ccall f_13726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13623)
static C_word C_fcall f_13623(C_word *a,C_word t0);
C_noret_decl(f_13598)
static C_word C_fcall f_13598(C_word *a,C_word t0);
C_noret_decl(f_12503)
static void C_fcall f_12503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12509)
static void C_ccall f_12509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12477)
static void C_ccall f_12477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12391)
static void C_ccall f_12391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12430)
static void C_fcall f_12430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12443)
static void C_ccall f_12443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12305)
static void C_ccall f_12305(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12344)
static void C_fcall f_12344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12249)
static C_word C_fcall f_12249(C_word t0);
C_noret_decl(f_12173)
static void C_ccall f_12173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12198)
static void C_fcall f_12198(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12045)
static void C_ccall f_12045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12064)
static void C_fcall f_12064(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12113)
static void C_fcall f_12113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11894)
static void C_ccall f_11894(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11894)
static void C_ccall f_11894r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11898)
static void C_ccall f_11898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25540)
static void C_ccall f25540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25534)
static void C_ccall f25534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11414)
static void C_fcall f_11414(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11806)
static void C_fcall f_11806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11817)
static void C_ccall f_11817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11819)
static void C_fcall f_11819(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11848)
static void C_ccall f_11848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11813)
static void C_ccall f_11813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11595)
static void C_fcall f_11595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11740)
static void C_fcall f_11740(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11769)
static void C_ccall f_11769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11734)
static void C_ccall f_11734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11686)
static void C_fcall f_11686(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11715)
static void C_ccall f_11715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11680)
static void C_ccall f_11680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11604)
static void C_ccall f_11604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11625)
static void C_ccall f_11625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11610)
static void C_ccall f_11610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11620)
static void C_ccall f_11620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11548)
static void C_fcall f_11548(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11582)
static void C_ccall f_11582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11575)
static void C_fcall f_11575(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11542)
static void C_ccall f_11542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11487)
static void C_fcall f_11487(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11521)
static void C_ccall f_11521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11514)
static void C_fcall f_11514(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11481)
static void C_ccall f_11481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11417)
static void C_fcall f_11417(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11901)
static void C_ccall f_11901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11904)
static void C_ccall f_11904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11907)
static void C_ccall f_11907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11910)
static void C_fcall f_11910(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11989)
static void C_ccall f_11989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11993)
static void C_fcall f_11993(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11913)
static void C_ccall f_11913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11916)
static void C_ccall f_11916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11968)
static void C_fcall f_11968(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11919)
static void C_ccall f_11919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16918)
static void C_fcall f_16918(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_17242)
static void C_ccall f_17242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16932)
static void C_ccall f_16932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16945)
static void C_ccall f_16945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16936)
static void C_ccall f_16936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16937)
static void C_ccall f_16937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17193)
static void C_ccall f_17193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17194)
static void C_ccall f_17194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17198)
static void C_ccall f_17198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17168)
static void C_ccall f_17168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17169)
static void C_ccall f_17169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17173)
static void C_ccall f_17173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17112)
static void C_ccall f_17112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17137)
static void C_ccall f_17137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17141)
static void C_ccall f_17141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17114)
static void C_ccall f_17114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17118)
static void C_ccall f_17118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17124)
static void C_fcall f_17124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17062)
static void C_ccall f_17062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17087)
static void C_ccall f_17087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17065)
static void C_ccall f_17065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17066)
static void C_ccall f_17066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17070)
static void C_ccall f_17070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16969)
static void C_ccall f_16969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17038)
static void C_ccall f_17038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16972)
static void C_ccall f_16972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16973)
static void C_ccall f_16973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_16979)
static void C_fcall f_16979(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_16989)
static void C_ccall f_16989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_16992)
static void C_ccall f_16992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17015)
static void C_fcall f_17015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11922)
static void C_ccall f_11922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11925)
static void C_ccall f_11925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11928)
static void C_ccall f_11928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12566)
static void C_ccall f_12566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13587)
static void C_ccall f_13587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12569)
static void C_ccall f_12569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12578)
static void C_fcall f_12578(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_12623)
static void C_fcall f_12623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12652)
static void C_fcall f_12652(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13382)
static void C_fcall f_13382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13432)
static void C_fcall f_13432(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13409)
static void C_ccall f_13409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13355)
static void C_ccall f_13355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13325)
static void C_ccall f_13325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13181)
static void C_fcall f_13181(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13184)
static void C_fcall f_13184(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13249)
static void C_ccall f_13249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13202)
static void C_ccall f_13202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13161)
static void C_ccall f_13161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13152)
static void C_ccall f_13152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13039)
static void C_ccall f_13039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13048)
static void C_fcall f_13048(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12999)
static void C_ccall f_12999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12828)
static void C_fcall f_12828(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12834)
static void C_ccall f_12834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12837)
static void C_ccall f_12837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12844)
static void C_fcall f_12844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12846)
static void C_ccall f_12846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12860)
static void C_ccall f_12860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12874)
static void C_ccall f_12874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12903)
static void C_ccall f_12903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12899)
static void C_ccall f_12899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12743)
static void C_fcall f_12743(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_12776)
static void C_ccall f_12776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12809)
static void C_ccall f_12809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12792)
static void C_ccall f_12792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12796)
static void C_ccall f_12796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12661)
static void C_fcall f_12661(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_12694)
static void C_ccall f_12694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12724)
static void C_ccall f_12724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12639)
static void C_ccall f_12639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12581)
static void C_fcall f_12581(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12576)
static void C_ccall f_12576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11950)
static void C_ccall f_11950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11957)
static void C_ccall f_11957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11934)
static void C_ccall f_11934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17249)
static void C_ccall f_17249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17261)
static void C_fcall f_17261(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_19230)
static void C_ccall f_19230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25467)
static void C_ccall f25467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19182)
static void C_ccall f_19182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_19189)
static void C_fcall f_19189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19150)
static void C_ccall f_19150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_19157)
static void C_ccall f_19157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19053)
static void C_ccall f_19053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_19060)
static void C_fcall f_19060(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18995)
static void C_ccall f_18995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_19014)
static void C_fcall f_19014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_19002)
static void C_fcall f_19002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18961)
static void C_ccall f_18961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18971)
static void C_fcall f_18971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18937)
static void C_ccall f_18937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18879)
static void C_ccall f_18879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18898)
static void C_fcall f_18898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18886)
static void C_fcall f_18886(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18845)
static void C_ccall f_18845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18855)
static void C_fcall f_18855(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18825)
static void C_ccall f_18825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18783)
static void C_ccall f_18783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18790)
static void C_fcall f_18790(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18755)
static void C_ccall f_18755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17307)
static void C_fcall f_17307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18707)
static void C_ccall f_18707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18667)
static void C_ccall f_18667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18679)
static void C_ccall f_18679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18637)
static void C_ccall f_18637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18638)
static void C_ccall f_18638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18650)
static void C_ccall f_18650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18510)
static void C_ccall f_18510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25461)
static void C_ccall f25461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18513)
static void C_fcall f_18513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18514)
static void C_ccall f_18514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18518)
static void C_ccall f_18518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18552)
static void C_ccall f_18552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18536)
static void C_ccall f_18536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18368)
static void C_ccall f_18368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18371)
static void C_ccall f_18371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18478)
static void C_ccall f_18478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18473)
static void C_ccall f_18473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18374)
static void C_ccall f_18374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18383)
static void C_fcall f_18383(C_word t0,C_word t1) C_noret;
C_noret_decl(f_18429)
static void C_ccall f_18429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18430)
static void C_ccall f_18430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18436)
static void C_ccall f_18436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18386)
static void C_ccall f_18386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18387)
static void C_ccall f_18387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18354)
static void C_ccall f_18354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18331)
static void C_ccall f_18331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18332)
static void C_ccall f_18332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18347)
static void C_ccall f_18347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18336)
static void C_ccall f_18336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18313)
static void C_ccall f_18313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18282)
static void C_ccall f_18282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18283)
static void C_ccall f_18283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18304)
static void C_ccall f_18304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18306)
static void C_ccall f_18306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18300)
static void C_ccall f_18300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18264)
static void C_ccall f_18264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18233)
static void C_ccall f_18233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18234)
static void C_ccall f_18234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18255)
static void C_ccall f_18255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18257)
static void C_ccall f_18257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18251)
static void C_ccall f_18251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18219)
static void C_ccall f_18219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18196)
static void C_ccall f_18196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18197)
static void C_ccall f_18197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18212)
static void C_ccall f_18212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18204)
static void C_ccall f_18204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18182)
static void C_ccall f_18182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18159)
static void C_ccall f_18159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18160)
static void C_ccall f_18160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_18175)
static void C_ccall f_18175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18167)
static void C_ccall f_18167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18146)
static void C_ccall f_18146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18121)
static void C_ccall f_18121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_18056)
static void C_ccall f_18056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17835)
static void C_fcall f_17835(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17838)
static void C_fcall f_17838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_17861)
static void C_ccall f_17861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17961)
static void C_ccall f_17961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17945)
static void C_ccall f_17945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_17864)
static void C_ccall f_17864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17893)
static void C_ccall f_17893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17895)
static void C_fcall f_17895(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_17922)
static C_word C_fcall f_17922(C_word t0);
C_noret_decl(f_17885)
static void C_ccall f_17885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17881)
static void C_ccall f_17881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17839)
static void C_ccall f_17839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17816)
static void C_ccall f_17816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17783)
static void C_ccall f_17783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17734)
static void C_ccall f_17734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17671)
static void C_ccall f_17671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17695)
static void C_ccall f_17695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17701)
static void C_ccall f_17701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17678)
static void C_ccall f_17678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17679)
static void C_ccall f_17679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17685)
static void C_ccall f_17685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17613)
static void C_ccall f_17613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17637)
static void C_ccall f_17637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17643)
static void C_ccall f_17643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17620)
static void C_ccall f_17620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17621)
static void C_ccall f_17621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17627)
static void C_ccall f_17627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17582)
static void C_ccall f_17582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17583)
static void C_ccall f_17583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17589)
static void C_ccall f_17589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17554)
static void C_ccall f_17554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17555)
static void C_ccall f_17555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17561)
static void C_ccall f_17561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17533)
static void C_ccall f_17533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17514)
static void C_ccall f_17514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17476)
static void C_ccall f_17476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17455)
static void C_ccall f_17455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17434)
static void C_ccall f_17434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17413)
static void C_ccall f_17413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17354)
static void C_ccall f_17354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17380)
static void C_ccall f_17380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17357)
static void C_ccall f_17357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17358)
static void C_ccall f_17358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_17364)
static void C_ccall f_17364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17334)
static void C_ccall f_17334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f25445)
static void C_ccall f25445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17314)
static void C_ccall f_17314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25439)
static void C_ccall f25439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17287)
static void C_ccall f_17287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_17264)
static void C_fcall f_17264(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_17258)
static void C_ccall f_17258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_11943)
static void C_ccall f_11943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11884)
static void C_ccall f_11884(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11884)
static void C_ccall f_11884r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11892)
static void C_ccall f_11892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11863)
static void C_ccall f_11863(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11863)
static void C_ccall f_11863r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11870)
static void C_ccall f_11870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11240)
static void C_fcall f_11240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11246)
static void C_fcall f_11246(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11337)
static void C_fcall f_11337(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10090)
static void C_ccall f_10090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10093)
static void C_ccall f_10093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11039)
static void C_fcall f_11039(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11033)
static void C_ccall f_11033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10861)
static void C_ccall f_10861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10863)
static void C_fcall f_10863(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11005)
static void C_ccall f_11005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10890)
static void C_fcall f_10890(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10990)
static void C_ccall f_10990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10982)
static void C_fcall f_10982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10910)
static void C_ccall f_10910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10912)
static void C_fcall f_10912(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10906)
static void C_ccall f_10906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10733)
static void C_ccall f_10733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10841)
static void C_ccall f_10841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10759)
static void C_fcall f_10759(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10753)
static void C_ccall f_10753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10725)
static void C_ccall f_10725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10114)
static void C_ccall f_10114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10119)
static void C_fcall f_10119(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10191)
static void C_ccall f_10191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11144)
static void C_fcall f_11144(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11154)
static void C_fcall f_11154(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11148)
static void C_ccall f_11148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10199)
static void C_ccall f_10199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10176)
static void C_ccall f_10176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10180)
static void C_ccall f_10180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10147)
static void C_ccall f_10147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11352)
static void C_ccall f_11352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11264)
static void C_ccall f_11264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11282)
static void C_ccall f_11282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11260)
static void C_ccall f_11260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10551)
static void C_fcall f_10551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10704)
static void C_ccall f_10704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10696)
static void C_ccall f_10696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10653)
static void C_ccall f_10653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10655)
static void C_fcall f_10655(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10684)
static void C_ccall f_10684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10621)
static void C_ccall f_10621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10649)
static void C_ccall f_10649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10617)
static void C_ccall f_10617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10573)
static void C_ccall f_10573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10571)
static void C_ccall f_10571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10388)
static void C_fcall f_10388(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10541)
static void C_ccall f_10541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10533)
static void C_ccall f_10533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10490)
static void C_ccall f_10490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10492)
static void C_fcall f_10492(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10521)
static void C_ccall f_10521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10458)
static void C_ccall f_10458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10486)
static void C_ccall f_10486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10454)
static void C_ccall f_10454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10410)
static void C_ccall f_10410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10408)
static void C_ccall f_10408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10233)
static void C_fcall f_10233(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10349)
static void C_fcall f_10349(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10378)
static void C_ccall f_10378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10267)
static void C_ccall f_10267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10275)
static void C_ccall f_10275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10289)
static void C_fcall f_10289(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10283)
static void C_ccall f_10283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10279)
static void C_ccall f_10279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10263)
static void C_ccall f_10263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9957)
static void C_fcall f_9957(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10045)
static void C_ccall f_10045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10073)
static void C_ccall f_10073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10049)
static void C_ccall f_10049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10065)
static void C_ccall f_10065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10053)
static void C_ccall f_10053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10061)
static void C_ccall f_10061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10057)
static void C_ccall f_10057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10008)
static void C_ccall f_10008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10024)
static void C_ccall f_10024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10012)
static void C_ccall f_10012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10020)
static void C_ccall f_10020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10016)
static void C_ccall f_10016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9983)
static void C_ccall f_9983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9991)
static void C_ccall f_9991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9987)
static void C_ccall f_9987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9897)
static void C_fcall f_9897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9672)
static void C_fcall f_9672(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9847)
static void C_ccall f_9847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9835)
static void C_ccall f_9835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9823)
static void C_ccall f_9823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9811)
static void C_ccall f_9811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9778)
static void C_ccall f_9778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9766)
static void C_ccall f_9766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9754)
static void C_ccall f_9754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9725)
static void C_ccall f_9725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9675)
static C_word C_fcall f_9675(C_word t0,C_word t1);
C_noret_decl(f_9652)
static void C_ccall f_9652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8849)
static void C_fcall f_8849(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8916)
static void C_ccall f_8916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8919)
static void C_ccall f_8919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8880)
static void C_ccall f_8880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8883)
static void C_ccall f_8883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static C_word C_fcall f_4964(C_word t0,C_word t1);
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_fcall f_5875(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f25291)
static void C_ccall f25291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8759)
static void C_ccall f_8759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8777)
static void C_ccall f_8777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25285)
static void C_ccall f25285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8737)
static void C_ccall f_8737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25279)
static void C_ccall f25279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8707)
static void C_ccall f_8707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25273)
static void C_ccall f25273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8676)
static void C_ccall f_8676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8648)
static void C_ccall f_8648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8615)
static void C_ccall f_8615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8597)
static void C_ccall f_8597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25260)
static void C_ccall f25260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8541)
static void C_ccall f_8541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8537)
static void C_ccall f_8537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8529)
static void C_ccall f_8529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static C_word C_fcall f_5022(C_word t0,C_word t1);
C_noret_decl(f_8391)
static void C_ccall f_8391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8400)
static void C_fcall f_8400(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8462)
static void C_ccall f_8462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8307)
static void C_fcall f_8307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8310)
static void C_ccall f_8310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8313)
static void C_ccall f_8313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25252)
static void C_ccall f25252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8360)
static void C_ccall f_8360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8352)
static void C_ccall f_8352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8348)
static void C_ccall f_8348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8282)
static void C_ccall f_8282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8239)
static void C_ccall f_8239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8214)
static void C_ccall f_8214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8210)
static void C_ccall f_8210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8185)
static void C_ccall f_8185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8181)
static void C_ccall f_8181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8156)
static void C_ccall f_8156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8152)
static void C_ccall f_8152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8123)
static void C_ccall f_8123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8094)
static void C_ccall f_8094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8057)
static void C_ccall f_8057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8053)
static void C_ccall f_8053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8028)
static void C_ccall f_8028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8024)
static void C_ccall f_8024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7991)
static void C_ccall f_7991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7987)
static void C_ccall f_7987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7934)
static void C_ccall f_7934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7852)
static void C_ccall f_7852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7823)
static void C_ccall f_7823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7819)
static void C_ccall f_7819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7790)
static void C_ccall f_7790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_ccall f_7786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7757)
static void C_ccall f_7757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7753)
static void C_ccall f_7753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7506)
static void C_fcall f_7506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7516)
static void C_ccall f_7516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7525)
static void C_ccall f_7525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7669)
static void C_ccall f_7669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_fcall f_5063(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5066)
static void C_fcall f_5066(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7528)
static void C_ccall f_7528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7531)
static void C_ccall f_7531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25244)
static void C_ccall f25244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25236)
static void C_ccall f25236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8962)
static void C_fcall f_8962(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9590)
static void C_fcall f_9590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9608)
static void C_ccall f_9608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9460)
static void C_fcall f_9460(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9517)
static void C_ccall f_9517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9505)
static void C_ccall f_9505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9490)
static void C_ccall f_9490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9463)
static void C_ccall f_9463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9486)
static void C_ccall f_9486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9474)
static void C_ccall f_9474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9482)
static void C_ccall f_9482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9478)
static void C_ccall f_9478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9327)
static void C_ccall f_9327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9336)
static void C_fcall f_9336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9379)
static void C_ccall f_9379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9375)
static void C_ccall f_9375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9342)
static void C_ccall f_9342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9345)
static void C_ccall f_9345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9368)
static void C_ccall f_9368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9356)
static void C_ccall f_9356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9364)
static void C_ccall f_9364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9360)
static void C_ccall f_9360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9275)
static void C_fcall f_9275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9118)
static void C_fcall f_9118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9203)
static void C_fcall f_9203(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9216)
static void C_fcall f_9216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9226)
static void C_ccall f_9226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9182)
static C_word C_fcall f_9182(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_9181)
static void C_ccall f_9181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9149)
static void C_ccall f_9149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f25220)
static void C_ccall f25220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9004)
static void C_ccall f_9004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_fcall f_5568(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9007)
static void C_ccall f_9007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9089)
static void C_ccall f_9089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9085)
static void C_ccall f_9085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9090)
static void C_ccall f_9090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9078)
static void C_ccall f_9078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9033)
static void C_fcall f_9033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9061)
static void C_ccall f_9061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9043)
static void C_ccall f_9043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_19342)
static void C_fcall f_19342(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9054)
static void C_ccall f_9054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9029)
static void C_ccall f_9029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9012)
static C_word C_fcall f_9012(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_7487)
static void C_ccall f_7487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7463)
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7483)
static void C_ccall f_7483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7448)
static void C_ccall f_7448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6713)
static void C_ccall f_6713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_ccall f_6717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7182)
static void C_fcall f_7182(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7367)
static void C_ccall f_7367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7379)
static void C_ccall f_7379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7346)
static void C_ccall f_7346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7342)
static void C_ccall f_7342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7297)
static void C_ccall f_7297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7277)
static void C_ccall f_7277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7260)
static void C_ccall f_7260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7243)
static void C_ccall f_7243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7194)
static void C_fcall f_7194(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f25199)
static void C_ccall f25199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25193)
static void C_ccall f25193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7185)
static void C_fcall f_7185(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7144)
static void C_ccall f_7144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7083)
static void C_ccall f_7083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7117)
static void C_ccall f_7117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7086)
static void C_ccall f_7086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7066)
static void C_ccall f_7066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7026)
static void C_ccall f_7026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_ccall f_6995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6999)
static void C_ccall f_6999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6903)
static void C_ccall f_6903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6921)
static void C_ccall f_6921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6941)
static void C_ccall f_6941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6929)
static void C_ccall f_6929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6900)
static void C_ccall f_6900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6871)
static void C_ccall f_6871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6828)
static void C_ccall f_6828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6832)
static void C_ccall f_6832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6807)
static void C_ccall f_6807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6778)
static void C_ccall f_6778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6632)
static void C_ccall f_6632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6647)
static void C_ccall f_6647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6429)
static void C_ccall f_6429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6596)
static void C_ccall f_6596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6525)
static void C_ccall f_6525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6508)
static void C_ccall f_6508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6460)
static void C_fcall f_6460(C_word t0,C_word t1) C_noret;
C_noret_decl(f25183)
static void C_ccall f25183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25177)
static void C_ccall f25177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f25173)
static void C_ccall f25173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_fcall f_6355(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6367)
static void C_ccall f_6367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6055)
static void C_fcall f_6055(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_fcall f_6062(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6315)
static void C_fcall f_6315(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6326)
static void C_ccall f_6326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6065)
static void C_fcall f_6065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6308)
static void C_ccall f_6308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6068)
static void C_ccall f_6068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6073)
static void C_fcall f_6073(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f25167)
static void C_ccall f25167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6175)
static void C_fcall f_6175(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6183)
static void C_fcall f_6183(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6076)
static C_word C_fcall f_6076(C_word *a,C_word t0);
C_noret_decl(f_5983)
static void C_fcall f_5983(C_word t0,C_word t1) C_noret;
C_noret_decl(f25161)
static void C_ccall f25161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_fcall f_6040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9862)
static C_word C_fcall f_9862(C_word t0,C_word t1);
C_noret_decl(f_5990)
static void C_fcall f_5990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6027)
static void C_ccall f_6027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5999)
static void C_ccall f_5999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6019)
static void C_ccall f_6019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5963)
static void C_fcall f_5963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5981)
static void C_ccall f_5981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5977)
static void C_ccall f_5977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5908)
static void C_fcall f_5908(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f25153)
static void C_ccall f25153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5926)
static void C_ccall f_5926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5928)
static void C_fcall f_5928(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_fcall f_5878(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f25145)
static void C_ccall f25145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5763)
static void C_fcall f_5763(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5769)
static void C_fcall f_5769(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5800)
static void C_fcall f_5800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5735)
static void C_ccall f_5735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5678)
static void C_fcall f_5678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5698)
static void C_fcall f_5698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5706)
static void C_ccall f_5706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5631)
static void C_fcall f_5631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5651)
static void C_fcall f_5651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_fcall f_5519(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5525)
static void C_fcall f_5525(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5489)
static void C_fcall f_5489(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5495)
static void C_fcall f_5495(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_fcall f_5440(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5460)
static void C_fcall f_5460(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5391)
static void C_fcall f_5391(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5411)
static void C_fcall f_5411(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_fcall f_5349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5364)
static C_word C_fcall f_5364(C_word t0);
C_noret_decl(f_5317)
static void C_fcall f_5317(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5323)
static void C_fcall f_5323(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5262)
static void C_fcall f_5262(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5268)
static void C_fcall f_5268(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5275)
static void C_fcall f_5275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_fcall f_5223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5239)
static void C_fcall f_5239(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5166)
static void C_fcall f_5166(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5195)
static void C_fcall f_5195(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5139)
static C_word C_fcall f_5139(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_fcall f_4906(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4919)
static C_word C_fcall f_4919(C_word t0,C_word t1);
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4793)
static C_word C_fcall f_4793(C_word t0,C_word t1);
C_noret_decl(f_4747)
static void C_fcall f_4747(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4673)
static void C_ccall f_4673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4578)
static C_word C_fcall f_4578(C_word t0,C_word t1);
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_22327)
static void C_fcall trf_22327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_22327(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_22327(t0,t1,t2);}

C_noret_decl(trf_22263)
static void C_fcall trf_22263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_22263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_22263(t0,t1,t2);}

C_noret_decl(trf_21985)
static void C_fcall trf_21985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21985(t0,t1,t2);}

C_noret_decl(trf_22047)
static void C_fcall trf_22047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_22047(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_22047(t0,t1,t2);}

C_noret_decl(trf_22077)
static void C_fcall trf_22077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_22077(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_22077(t0,t1);}

C_noret_decl(trf_22106)
static void C_fcall trf_22106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_22106(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_22106(t0,t1);}

C_noret_decl(trf_21896)
static void C_fcall trf_21896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21896(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21896(t0,t1,t2);}

C_noret_decl(trf_21915)
static void C_fcall trf_21915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_21915(t0,t1);}

C_noret_decl(trf_21846)
static void C_fcall trf_21846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21846(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21846(t0,t1,t2,t3);}

C_noret_decl(trf_21718)
static void C_fcall trf_21718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21718(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21718(t0,t1,t2,t3);}

C_noret_decl(trf_21612)
static void C_fcall trf_21612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21612(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21612(t0,t1,t2);}

C_noret_decl(trf_21618)
static void C_fcall trf_21618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21618(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21618(t0,t1,t2,t3);}

C_noret_decl(trf_21413)
static void C_fcall trf_21413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21413(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_21413(t0,t1);}

C_noret_decl(trf_21421)
static void C_fcall trf_21421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21421(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21421(t0,t1,t2,t3);}

C_noret_decl(trf_21349)
static void C_fcall trf_21349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_21349(t0,t1);}

C_noret_decl(trf_21340)
static void C_fcall trf_21340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21340(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21340(t0,t1,t2);}

C_noret_decl(trf_21276)
static void C_fcall trf_21276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21276(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21276(t0,t1,t2,t3);}

C_noret_decl(trf_21301)
static void C_fcall trf_21301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21301(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21301(t0,t1,t2,t3);}

C_noret_decl(trf_21229)
static void C_fcall trf_21229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_21229(t0,t1);}

C_noret_decl(trf_21220)
static void C_fcall trf_21220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21220(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_21220(t0,t1,t2);}

C_noret_decl(trf_21164)
static void C_fcall trf_21164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21164(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21164(t0,t1,t2,t3);}

C_noret_decl(trf_21189)
static void C_fcall trf_21189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21189(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21189(t0,t1,t2,t3);}

C_noret_decl(trf_21119)
static void C_fcall trf_21119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21119(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21119(t0,t1,t2,t3);}

C_noret_decl(trf_21073)
static void C_fcall trf_21073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21073(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_21073(t0,t1,t2,t3);}

C_noret_decl(trf_21033)
static void C_fcall trf_21033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_21033(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_21033(t0,t1);}

C_noret_decl(trf_20973)
static void C_fcall trf_20973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20973(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20973(t0,t1);}

C_noret_decl(trf_20968)
static void C_fcall trf_20968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20968(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20968(t0,t1,t2);}

C_noret_decl(trf_20963)
static void C_fcall trf_20963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20963(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20963(t0,t1,t2,t3);}

C_noret_decl(trf_20932)
static void C_fcall trf_20932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20932(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_20932(t0,t1,t2,t3,t4);}

C_noret_decl(trf_20944)
static void C_fcall trf_20944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20944(t0,t1);}

C_noret_decl(trf_20947)
static void C_fcall trf_20947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20947(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20947(t0,t1);}

C_noret_decl(trf_20736)
static void C_fcall trf_20736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20736(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20736(t0,t1,t2,t3);}

C_noret_decl(trf_20522)
static void C_fcall trf_20522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20522(t0,t1);}

C_noret_decl(trf_20525)
static void C_fcall trf_20525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20525(t0,t1);}

C_noret_decl(trf_20533)
static void C_fcall trf_20533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20533(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20533(t0,t1,t2,t3);}

C_noret_decl(trf_20350)
static void C_fcall trf_20350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20350(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_20350(t0,t1,t2,t3);}

C_noret_decl(trf_20366)
static void C_fcall trf_20366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20366(t0,t1);}

C_noret_decl(trf_20403)
static void C_fcall trf_20403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20403(t0,t1);}

C_noret_decl(trf_20334)
static void C_fcall trf_20334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20334(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_20334(t0,t1);}

C_noret_decl(trf_20217)
static void C_fcall trf_20217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20217(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_20217(t0,t1,t2,t3,t4);}

C_noret_decl(trf_20231)
static void C_fcall trf_20231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20231(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20231(t0,t1,t2);}

C_noret_decl(trf_20085)
static void C_fcall trf_20085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20085(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20085(t0,t1,t2);}

C_noret_decl(trf_20112)
static void C_fcall trf_20112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20112(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20112(t0,t1,t2);}

C_noret_decl(trf_20007)
static void C_fcall trf_20007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_20007(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_20007(t0,t1,t2);}

C_noret_decl(trf_19848)
static void C_fcall trf_19848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19848(t0,t1,t2);}

C_noret_decl(trf_19864)
static void C_fcall trf_19864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19864(t0,t1);}

C_noret_decl(trf_19798)
static void C_fcall trf_19798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19798(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19798(t0,t1,t2);}

C_noret_decl(trf_19377)
static void C_fcall trf_19377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19377(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19377(t0,t1,t2);}

C_noret_decl(trf_19387)
static void C_fcall trf_19387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19387(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19387(t0,t1,t2,t3);}

C_noret_decl(trf_19666)
static void C_fcall trf_19666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19666(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19666(t0,t1,t2);}

C_noret_decl(trf_13742)
static void C_fcall trf_13742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13742(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13742(t0,t1,t2,t3);}

C_noret_decl(trf_19301)
static void C_fcall trf_19301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19301(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19301(t0,t1,t2,t3);}

C_noret_decl(trf_19583)
static void C_fcall trf_19583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19583(t0,t1,t2);}

C_noret_decl(trf_19517)
static void C_fcall trf_19517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19517(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19517(t0,t1,t2);}

C_noret_decl(trf_19457)
static void C_fcall trf_19457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19457(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19457(t0,t1,t2);}

C_noret_decl(trf_19390)
static void C_fcall trf_19390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19390(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19390(t0,t1,t2);}

C_noret_decl(trf_19260)
static void C_fcall trf_19260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19260(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_19260(t0,t1,t2);}

C_noret_decl(trf_16862)
static void C_fcall trf_16862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16862(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16862(t0,t1,t2);}

C_noret_decl(trf_16746)
static void C_fcall trf_16746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16746(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16746(t0,t1,t2);}

C_noret_decl(trf_16752)
static void C_fcall trf_16752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16752(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_16752(t0,t1,t2,t3);}

C_noret_decl(trf_16801)
static void C_fcall trf_16801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16801(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16801(t0,t1,t2);}

C_noret_decl(trf_16630)
static void C_fcall trf_16630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16630(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16630(t0,t1,t2);}

C_noret_decl(trf_16663)
static void C_fcall trf_16663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16663(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16663(t0,t1);}

C_noret_decl(trf_16667)
static void C_fcall trf_16667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16667(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16667(t0,t1);}

C_noret_decl(trf_16556)
static void C_fcall trf_16556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16556(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16556(t0,t1,t2);}

C_noret_decl(trf_16564)
static void C_fcall trf_16564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16564(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16564(t0,t1);}

C_noret_decl(trf_16082)
static void C_fcall trf_16082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16082(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16082(t0,t1,t2);}

C_noret_decl(trf_16291)
static void C_fcall trf_16291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16291(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_16291(t0,t1,t2,t3);}

C_noret_decl(trf_16319)
static void C_fcall trf_16319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16319(t0,t1);}

C_noret_decl(trf_16476)
static void C_fcall trf_16476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16476(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16476(t0,t1);}

C_noret_decl(trf_16377)
static void C_fcall trf_16377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16377(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16377(t0,t1);}

C_noret_decl(trf_16395)
static void C_fcall trf_16395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16395(t0,t1);}

C_noret_decl(trf_16398)
static void C_fcall trf_16398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16398(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16398(t0,t1);}

C_noret_decl(trf_16113)
static void C_fcall trf_16113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16113(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_16113(t0,t1,t2,t3);}

C_noret_decl(trf_16162)
static void C_fcall trf_16162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16162(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16162(t0,t1);}

C_noret_decl(trf_16183)
static void C_fcall trf_16183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_16183(t0,t1);}

C_noret_decl(trf_16085)
static void C_fcall trf_16085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16085(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_16085(t0,t1,t2,t3);}

C_noret_decl(trf_15564)
static void C_fcall trf_15564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15564(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15564(t0,t1,t2);}

C_noret_decl(trf_15577)
static void C_fcall trf_15577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15577(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_15577(t0,t1,t2,t3,t4);}

C_noret_decl(trf_15959)
static void C_fcall trf_15959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15959(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_15959(t0,t1,t2,t3,t4);}

C_noret_decl(trf_15977)
static void C_fcall trf_15977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15977(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15977(t0,t1,t2);}

C_noret_decl(trf_16004)
static void C_fcall trf_16004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16004(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_16004(t0,t1,t2);}

C_noret_decl(trf_15622)
static void C_fcall trf_15622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15622(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15622(t0,t1);}

C_noret_decl(trf_15663)
static void C_fcall trf_15663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15663(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15663(t0,t1,t2);}

C_noret_decl(trf_15918)
static void C_fcall trf_15918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15918(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15918(t0,t1,t2);}

C_noret_decl(trf_15865)
static void C_fcall trf_15865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15865(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_15865(t0,t1,t2,t3);}

C_noret_decl(trf_15878)
static void C_fcall trf_15878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15878(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15878(t0,t1);}

C_noret_decl(trf_15753)
static void C_fcall trf_15753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15753(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15753(t0,t1,t2);}

C_noret_decl(trf_15780)
static void C_fcall trf_15780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15780(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15780(t0,t1,t2);}

C_noret_decl(trf_15798)
static void C_fcall trf_15798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15798(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15798(t0,t1,t2);}

C_noret_decl(trf_14706)
static void C_fcall trf_14706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14706(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14706(t0,t1,t2);}

C_noret_decl(trf_14724)
static void C_fcall trf_14724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14724(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_14724(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_15021)
static void C_fcall trf_15021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15021(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15021(t0,t1);}

C_noret_decl(trf_15075)
static void C_fcall trf_15075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15075(t0,t1);}

C_noret_decl(trf_15384)
static void C_fcall trf_15384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15384(t0,t1);}

C_noret_decl(trf_15133)
static void C_fcall trf_15133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15133(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_15133(t0,t1,t2);}

C_noret_decl(trf_15143)
static void C_fcall trf_15143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_15143(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_15143(t0,t1);}

C_noret_decl(trf_14871)
static void C_fcall trf_14871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14871(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14871(t0,t1);}

C_noret_decl(trf_14741)
static void C_fcall trf_14741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14741(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14741(t0,t1,t2,t3);}

C_noret_decl(trf_14762)
static void C_fcall trf_14762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14762(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14762(t0,t1,t2);}

C_noret_decl(trf_14727)
static void C_fcall trf_14727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14727(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14727(t0,t1,t2);}

C_noret_decl(trf_14599)
static void C_fcall trf_14599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14599(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_14599(t0,t1,t2,t3,t4);}

C_noret_decl(trf_14613)
static void C_fcall trf_14613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14613(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_14613(t0,t1,t2,t3,t4);}

C_noret_decl(trf_14390)
static void C_fcall trf_14390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14390(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14390(t0,t1,t2);}

C_noret_decl(trf_14520)
static void C_fcall trf_14520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14520(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14520(t0,t1,t2,t3);}

C_noret_decl(trf_14320)
static void C_fcall trf_14320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14320(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14320(t0,t1,t2);}

C_noret_decl(trf_14226)
static void C_fcall trf_14226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14226(t0,t1);}

C_noret_decl(trf_14083)
static void C_fcall trf_14083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14083(t0,t1);}

C_noret_decl(trf_14160)
static void C_fcall trf_14160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14160(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14160(t0,t1,t2);}

C_noret_decl(trf_14028)
static void C_fcall trf_14028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14028(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14028(t0,t1,t2,t3);}

C_noret_decl(trf_13798)
static void C_fcall trf_13798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13798(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13798(t0,t1,t2,t3);}

C_noret_decl(trf_13896)
static void C_fcall trf_13896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13896(t0,t1);}

C_noret_decl(trf_13697)
static void C_fcall trf_13697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13697(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13697(t0,t1,t2);}

C_noret_decl(trf_12503)
static void C_fcall trf_12503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12503(t0,t1);}

C_noret_decl(trf_12430)
static void C_fcall trf_12430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12430(t0,t1);}

C_noret_decl(trf_12344)
static void C_fcall trf_12344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12344(t0,t1);}

C_noret_decl(trf_12198)
static void C_fcall trf_12198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12198(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12198(t0,t1);}

C_noret_decl(trf_12064)
static void C_fcall trf_12064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12064(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12064(t0,t1);}

C_noret_decl(trf_12113)
static void C_fcall trf_12113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12113(t0,t1);}

C_noret_decl(trf_11414)
static void C_fcall trf_11414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11414(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_11414(t0,t1,t2,t3,t4);}

C_noret_decl(trf_11806)
static void C_fcall trf_11806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11806(t0,t1);}

C_noret_decl(trf_11819)
static void C_fcall trf_11819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11819(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11819(t0,t1,t2);}

C_noret_decl(trf_11595)
static void C_fcall trf_11595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11595(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11595(t0,t1);}

C_noret_decl(trf_11740)
static void C_fcall trf_11740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11740(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11740(t0,t1,t2);}

C_noret_decl(trf_11686)
static void C_fcall trf_11686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11686(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11686(t0,t1,t2);}

C_noret_decl(trf_11548)
static void C_fcall trf_11548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11548(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11548(t0,t1,t2);}

C_noret_decl(trf_11575)
static void C_fcall trf_11575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11575(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11575(t0,t1,t2);}

C_noret_decl(trf_11487)
static void C_fcall trf_11487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11487(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11487(t0,t1,t2);}

C_noret_decl(trf_11514)
static void C_fcall trf_11514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11514(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11514(t0,t1,t2);}

C_noret_decl(trf_11417)
static void C_fcall trf_11417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11417(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11417(t0,t1,t2);}

C_noret_decl(trf_11910)
static void C_fcall trf_11910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11910(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11910(t0,t1);}

C_noret_decl(trf_11993)
static void C_fcall trf_11993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11993(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11993(t0,t1,t2);}

C_noret_decl(trf_11968)
static void C_fcall trf_11968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11968(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11968(t0,t1,t2);}

C_noret_decl(trf_16918)
static void C_fcall trf_16918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16918(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_16918(t0,t1,t2,t3,t4);}

C_noret_decl(trf_17124)
static void C_fcall trf_17124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17124(t0,t1);}

C_noret_decl(trf_16979)
static void C_fcall trf_16979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_16979(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_16979(t0,t1,t2,t3);}

C_noret_decl(trf_17015)
static void C_fcall trf_17015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17015(t0,t1);}

C_noret_decl(trf_12578)
static void C_fcall trf_12578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12578(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_12578(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_12623)
static void C_fcall trf_12623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12623(t0,t1);}

C_noret_decl(trf_12652)
static void C_fcall trf_12652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12652(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12652(t0,t1);}

C_noret_decl(trf_13382)
static void C_fcall trf_13382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13382(t0,t1);}

C_noret_decl(trf_13432)
static void C_fcall trf_13432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13432(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13432(t0,t1);}

C_noret_decl(trf_13181)
static void C_fcall trf_13181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13181(t0,t1);}

C_noret_decl(trf_13184)
static void C_fcall trf_13184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13184(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13184(t0,t1);}

C_noret_decl(trf_13048)
static void C_fcall trf_13048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13048(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13048(t0,t1);}

C_noret_decl(trf_12828)
static void C_fcall trf_12828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12828(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12828(t0,t1);}

C_noret_decl(trf_12844)
static void C_fcall trf_12844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12844(t0,t1);}

C_noret_decl(trf_12743)
static void C_fcall trf_12743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12743(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_12743(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_12661)
static void C_fcall trf_12661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12661(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_12661(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_12581)
static void C_fcall trf_12581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12581(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12581(t0,t1,t2);}

C_noret_decl(trf_17261)
static void C_fcall trf_17261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17261(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_17261(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_19189)
static void C_fcall trf_19189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19189(t0,t1);}

C_noret_decl(trf_19060)
static void C_fcall trf_19060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19060(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19060(t0,t1);}

C_noret_decl(trf_19014)
static void C_fcall trf_19014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19014(t0,t1);}

C_noret_decl(trf_19002)
static void C_fcall trf_19002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_19002(t0,t1);}

C_noret_decl(trf_18971)
static void C_fcall trf_18971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18971(t0,t1);}

C_noret_decl(trf_18898)
static void C_fcall trf_18898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18898(t0,t1);}

C_noret_decl(trf_18886)
static void C_fcall trf_18886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18886(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18886(t0,t1);}

C_noret_decl(trf_18855)
static void C_fcall trf_18855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18855(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18855(t0,t1);}

C_noret_decl(trf_18790)
static void C_fcall trf_18790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18790(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18790(t0,t1);}

C_noret_decl(trf_17307)
static void C_fcall trf_17307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17307(t0,t1);}

C_noret_decl(trf_18513)
static void C_fcall trf_18513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18513(t0,t1);}

C_noret_decl(trf_18383)
static void C_fcall trf_18383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_18383(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_18383(t0,t1);}

C_noret_decl(trf_17835)
static void C_fcall trf_17835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17835(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17835(t0,t1);}

C_noret_decl(trf_17838)
static void C_fcall trf_17838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_17838(t0,t1);}

C_noret_decl(trf_17895)
static void C_fcall trf_17895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17895(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_17895(t0,t1,t2);}

C_noret_decl(trf_17264)
static void C_fcall trf_17264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_17264(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_17264(t0,t1,t2);}

C_noret_decl(trf_11240)
static void C_fcall trf_11240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11240(t0,t1);}

C_noret_decl(trf_11246)
static void C_fcall trf_11246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11246(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_11246(t0,t1,t2,t3,t4);}

C_noret_decl(trf_11337)
static void C_fcall trf_11337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11337(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11337(t0,t1);}

C_noret_decl(trf_11039)
static void C_fcall trf_11039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11039(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11039(t0,t1,t2);}

C_noret_decl(trf_10863)
static void C_fcall trf_10863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10863(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10863(t0,t1,t2);}

C_noret_decl(trf_10890)
static void C_fcall trf_10890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10890(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10890(t0,t1,t2);}

C_noret_decl(trf_10982)
static void C_fcall trf_10982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10982(t0,t1);}

C_noret_decl(trf_10912)
static void C_fcall trf_10912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10912(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10912(t0,t1,t2);}

C_noret_decl(trf_10759)
static void C_fcall trf_10759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10759(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10759(t0,t1,t2);}

C_noret_decl(trf_10119)
static void C_fcall trf_10119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10119(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10119(t0,t1,t2,t3);}

C_noret_decl(trf_11144)
static void C_fcall trf_11144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11144(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11144(t0,t1);}

C_noret_decl(trf_11154)
static void C_fcall trf_11154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11154(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11154(t0,t1,t2);}

C_noret_decl(trf_10551)
static void C_fcall trf_10551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10551(t0,t1);}

C_noret_decl(trf_10655)
static void C_fcall trf_10655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10655(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10655(t0,t1,t2);}

C_noret_decl(trf_10388)
static void C_fcall trf_10388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10388(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10388(t0,t1);}

C_noret_decl(trf_10492)
static void C_fcall trf_10492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10492(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10492(t0,t1,t2);}

C_noret_decl(trf_10233)
static void C_fcall trf_10233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10233(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10233(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10349)
static void C_fcall trf_10349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10349(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10349(t0,t1,t2);}

C_noret_decl(trf_10289)
static void C_fcall trf_10289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10289(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10289(t0,t1,t2);}

C_noret_decl(trf_9957)
static void C_fcall trf_9957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9957(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9957(t0,t1);}

C_noret_decl(trf_9897)
static void C_fcall trf_9897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9897(t0,t1);}

C_noret_decl(trf_9672)
static void C_fcall trf_9672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9672(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9672(t0,t1,t2,t3);}

C_noret_decl(trf_8849)
static void C_fcall trf_8849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8849(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8849(t0,t1,t2,t3);}

C_noret_decl(trf_5875)
static void C_fcall trf_5875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5875(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5875(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8400)
static void C_fcall trf_8400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8400(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8400(t0,t1,t2);}

C_noret_decl(trf_8307)
static void C_fcall trf_8307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8307(t0,t1);}

C_noret_decl(trf_7506)
static void C_fcall trf_7506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7506(t0,t1);}

C_noret_decl(trf_5063)
static void C_fcall trf_5063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5063(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5063(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5066)
static void C_fcall trf_5066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5066(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5066(t0,t1);}

C_noret_decl(trf_8962)
static void C_fcall trf_8962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8962(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8962(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9590)
static void C_fcall trf_9590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9590(t0,t1);}

C_noret_decl(trf_9460)
static void C_fcall trf_9460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9460(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9460(t0,t1);}

C_noret_decl(trf_9336)
static void C_fcall trf_9336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9336(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9336(t0,t1);}

C_noret_decl(trf_9275)
static void C_fcall trf_9275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9275(t0,t1);}

C_noret_decl(trf_9118)
static void C_fcall trf_9118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9118(t0,t1);}

C_noret_decl(trf_9203)
static void C_fcall trf_9203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9203(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9203(t0,t1);}

C_noret_decl(trf_9216)
static void C_fcall trf_9216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9216(t0,t1);}

C_noret_decl(trf_5568)
static void C_fcall trf_5568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5568(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5568(t0,t1,t2,t3);}

C_noret_decl(trf_9033)
static void C_fcall trf_9033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9033(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9033(t0,t1);}

C_noret_decl(trf_19342)
static void C_fcall trf_19342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_19342(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_19342(t0,t1,t2,t3);}

C_noret_decl(trf_7182)
static void C_fcall trf_7182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7182(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7182(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7194)
static void C_fcall trf_7194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7194(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7194(t0,t1,t2);}

C_noret_decl(trf_7185)
static void C_fcall trf_7185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7185(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7185(t0,t1,t2);}

C_noret_decl(trf_6460)
static void C_fcall trf_6460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6460(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6460(t0,t1);}

C_noret_decl(trf_6355)
static void C_fcall trf_6355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6355(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6355(t0,t1);}

C_noret_decl(trf_6055)
static void C_fcall trf_6055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6055(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6055(t0,t1);}

C_noret_decl(trf_6062)
static void C_fcall trf_6062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6062(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6062(t0,t1);}

C_noret_decl(trf_6315)
static void C_fcall trf_6315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6315(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6315(t0,t1);}

C_noret_decl(trf_6065)
static void C_fcall trf_6065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6065(t0,t1);}

C_noret_decl(trf_6073)
static void C_fcall trf_6073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6073(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6073(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6175)
static void C_fcall trf_6175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6175(t0,t1);}

C_noret_decl(trf_6183)
static void C_fcall trf_6183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6183(t0,t1);}

C_noret_decl(trf_5983)
static void C_fcall trf_5983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5983(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5983(t0,t1);}

C_noret_decl(trf_6040)
static void C_fcall trf_6040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6040(t0,t1);}

C_noret_decl(trf_5990)
static void C_fcall trf_5990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5990(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5990(t0,t1);}

C_noret_decl(trf_5963)
static void C_fcall trf_5963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5963(t0,t1);}

C_noret_decl(trf_5908)
static void C_fcall trf_5908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5908(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5908(t0,t1,t2);}

C_noret_decl(trf_5928)
static void C_fcall trf_5928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5928(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5928(t0,t1,t2);}

C_noret_decl(trf_5878)
static void C_fcall trf_5878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5878(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5878(t0,t1,t2);}

C_noret_decl(trf_5763)
static void C_fcall trf_5763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5763(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5763(t0,t1);}

C_noret_decl(trf_5769)
static void C_fcall trf_5769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5769(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5769(t0,t1,t2,t3);}

C_noret_decl(trf_5800)
static void C_fcall trf_5800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5800(t0,t1);}

C_noret_decl(trf_5678)
static void C_fcall trf_5678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5678(t0,t1,t2);}

C_noret_decl(trf_5698)
static void C_fcall trf_5698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5698(t0,t1);}

C_noret_decl(trf_5631)
static void C_fcall trf_5631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5631(t0,t1,t2);}

C_noret_decl(trf_5651)
static void C_fcall trf_5651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5651(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5651(t0,t1);}

C_noret_decl(trf_5519)
static void C_fcall trf_5519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5519(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5519(t0,t1,t2);}

C_noret_decl(trf_5525)
static void C_fcall trf_5525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5525(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5525(t0,t1,t2,t3);}

C_noret_decl(trf_5489)
static void C_fcall trf_5489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5489(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5489(t0,t1,t2,t3);}

C_noret_decl(trf_5495)
static void C_fcall trf_5495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5495(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5495(t0,t1,t2,t3);}

C_noret_decl(trf_5440)
static void C_fcall trf_5440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5440(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5440(t0,t1,t2);}

C_noret_decl(trf_5460)
static void C_fcall trf_5460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5460(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5460(t0,t1,t2,t3);}

C_noret_decl(trf_5391)
static void C_fcall trf_5391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5391(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5391(t0,t1,t2);}

C_noret_decl(trf_5411)
static void C_fcall trf_5411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5411(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5411(t0,t1,t2,t3);}

C_noret_decl(trf_5349)
static void C_fcall trf_5349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5349(t0,t1);}

C_noret_decl(trf_5317)
static void C_fcall trf_5317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5317(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5317(t0,t1,t2);}

C_noret_decl(trf_5323)
static void C_fcall trf_5323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5323(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5323(t0,t1,t2);}

C_noret_decl(trf_5262)
static void C_fcall trf_5262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5262(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5262(t0,t1,t2);}

C_noret_decl(trf_5268)
static void C_fcall trf_5268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5268(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5268(t0,t1,t2,t3);}

C_noret_decl(trf_5275)
static void C_fcall trf_5275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5275(t0,t1);}

C_noret_decl(trf_5223)
static void C_fcall trf_5223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5223(t0,t1);}

C_noret_decl(trf_5239)
static void C_fcall trf_5239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5239(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5239(t0,t1,t2,t3);}

C_noret_decl(trf_5166)
static void C_fcall trf_5166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5166(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5166(t0,t1);}

C_noret_decl(trf_5195)
static void C_fcall trf_5195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5195(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5195(t0,t1,t2,t3);}

C_noret_decl(trf_4906)
static void C_fcall trf_4906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4906(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4906(t0,t1,t2,t3);}

C_noret_decl(trf_4747)
static void C_fcall trf_4747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4747(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4747(t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2514)){
C_save(t1);
C_rereclaim2(2514*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,313);
lf[0]=C_h_intern(&lf[0],8,"irregex\077");
lf[1]=C_h_intern(&lf[1],13,"*irregex-tag*");
lf[2]=C_h_intern(&lf[2],11,"irregex-dfa");
lf[3]=C_h_intern(&lf[3],18,"irregex-dfa/search");
lf[4]=C_h_intern(&lf[4],19,"irregex-dfa/extract");
lf[5]=C_h_intern(&lf[5],11,"irregex-nfa");
lf[6]=C_h_intern(&lf[6],13,"irregex-flags");
lf[7]=C_h_intern(&lf[7],18,"irregex-submatches");
lf[8]=C_h_intern(&lf[8],15,"irregex-lengths");
lf[9]=C_h_intern(&lf[9],13,"irregex-names");
lf[10]=C_h_intern(&lf[10],19,"irregex-new-matches");
lf[11]=C_h_intern(&lf[11],19,"*irregex-match-tag*");
lf[12]=C_h_intern(&lf[12],11,"make-vector");
lf[13]=C_h_intern(&lf[13],22,"irregex-reset-matches!");
lf[14]=C_h_intern(&lf[14],19,"irregex-match-data\077");
lf[15]=C_h_intern(&lf[15],28,"irregex-match-num-submatches");
lf[16]=C_h_intern(&lf[16],20,"irregex-match-string");
lf[18]=C_h_intern(&lf[18],5,"error");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\022unknown match name");
lf[21]=C_h_intern(&lf[21],23,"irregex-match-substring");
lf[22]=C_h_intern(&lf[22],13,"\003syssubstring");
lf[23]=C_h_intern(&lf[23],19,"irregex-match-start");
lf[24]=C_h_intern(&lf[24],17,"irregex-match-end");
lf[25]=C_h_intern(&lf[25],1,"/");
lf[29]=C_h_intern(&lf[29],11,"make-string");
lf[33]=C_h_intern(&lf[33],7,"reverse");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\035can\047t take last of empty list");
lf[45]=C_h_intern(&lf[45],1,"i");
lf[46]=C_h_intern(&lf[46],1,"m");
lf[47]=C_h_intern(&lf[47],10,"multi-line");
lf[48]=C_h_intern(&lf[48],1,"s");
lf[49]=C_h_intern(&lf[49],11,"single-line");
lf[50]=C_h_intern(&lf[50],1,"x");
lf[51]=C_h_intern(&lf[51],12,"ignore-space");
lf[52]=C_h_intern(&lf[52],1,"u");
lf[53]=C_h_intern(&lf[53],4,"utf8");
lf[54]=C_h_intern(&lf[54],2,"ci");
lf[55]=C_h_intern(&lf[55],16,"case-insensitive");
lf[56]=C_h_intern(&lf[56],11,"string->sre");
lf[57]=C_h_intern(&lf[57],2,"or");
lf[59]=C_h_intern(&lf[59],16,"\003sysstring->list");
lf[62]=C_h_intern(&lf[62],8,"submatch");
lf[63]=C_h_intern(&lf[63],2,"if");
lf[64]=C_h_intern(&lf[64],10,"look-ahead");
lf[65]=C_h_intern(&lf[65],14,"neg-look-ahead");
lf[66]=C_h_intern(&lf[66],11,"look-behind");
lf[67]=C_h_intern(&lf[67],15,"neg-look-behind");
lf[68]=C_h_intern(&lf[68],3,"seq");
lf[69]=C_h_intern(&lf[69],7,"epsilon");
lf[70]=C_h_intern(&lf[70],10,"\003sysappend");
lf[71]=C_h_intern(&lf[71],14,"submatch-named");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006atomic\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\012look-ahead\376\003\000\000\002\376\001\000\000\016neg-look-ahead\376\003\000\000\002\376\001\000"
"\000\013look-behind\376\003\000\000\002\376\001\000\000\017neg-look-behind\376\003\000\000\002\376\001\000\000\016submatch-named\376\003\000\000\002\376\001\000\000\006w/utf8\376\003"
"\000\000\002\376\001\000\000\010w/noutf8\376\377\016");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[74]=C_h_intern(&lf[74],3,"any");
lf[75]=C_h_intern(&lf[75],4,"nonl");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\030\077 can\047t follow empty sre");
lf[77]=C_h_intern(&lf[77],1,"*");
lf[78]=C_h_intern(&lf[78],2,"*\077");
lf[79]=C_h_intern(&lf[79],1,"+");
lf[80]=C_h_intern(&lf[80],3,"**\077");
lf[81]=C_h_intern(&lf[81],1,"\077");
lf[82]=C_h_intern(&lf[82],2,"\077\077");
lf[83]=C_h_intern(&lf[83],2,"**");
lf[84]=C_h_intern(&lf[84],1,"=");
lf[85]=C_h_intern(&lf[85],2,">=");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000%duplicate repetition (e.g. **) in sre");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000!can\047t repeat empty sre (e.g. ()*)");
lf[90]=C_h_intern(&lf[90],14,"string->symbol");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012look-ahead\376\377\016");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016neg-look-ahead\376\377\016");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\013look-behind\376\377\016");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\017neg-look-behind\376\377\016");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid (\077< sequence");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006atomic\376\377\016");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\042unterminated parenthesis in regexp");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid conditional reference");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\377\016");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\036unsupported Perl-style cluster");
lf[104]=C_h_intern(&lf[104],6,"w/utf8");
lf[105]=C_h_intern(&lf[105],8,"w/noutf8");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\022incomplete cluster");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\036unknown regex cluster modifier");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\026too many )\047s in regexp");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\023incomplete char set");
lf[110]=C_h_intern(&lf[110],1,"~");
lf[111]=C_h_intern(&lf[111],6,"append");
lf[113]=C_h_intern(&lf[113],16,"\003syslist->string");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\014bad char-set");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\032inverted range in char-set");
lf[119]=C_decode_literal(C_heaptop,"\376\000\000\001\000\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000"
"\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001"
"\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001"
"\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000"
"\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377"
"\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000"
"\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001"
"\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001"
"\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000"
"\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377"
"\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000"
"\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376"
"\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\001\376\377\001\000\000\000\002\376\377\001\000"
"\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002"
"\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001"
"\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\002\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000"
"\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377\001\000\000\000\003\376\377"
"\001\000\000\000\003\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\004\376\377\001\000\000\000\005\376\377\001\000\000\000\005\376\377\001\000\000"
"\000\005\376\377\001\000\000\000\005\376\377\001\000\000\000\006\376\377\001\000\000\000\006\376\377\001\000\000\000\000\376\377\001\000\000\000\000");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\032incomplete character class");
lf[121]=C_h_intern(&lf[121],5,"pair\077");
lf[122]=C_h_intern(&lf[122],5,"char\077");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000!collating sequences not supported");
lf[126]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\012\376\377\016");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\032incomplete escape sequence");
lf[128]=C_h_intern(&lf[128],7,"numeric");
lf[129]=C_h_intern(&lf[129],5,"space");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[131]=C_h_intern(&lf[131],12,"alphanumeric");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[133]=C_h_intern(&lf[133],3,"eow");
lf[134]=C_h_intern(&lf[134],3,"bow");
lf[135]=C_h_intern(&lf[135],3,"nwb");
lf[136]=C_h_intern(&lf[136],3,"bos");
lf[137]=C_h_intern(&lf[137],3,"eos");
lf[138]=C_h_intern(&lf[138],7,"newline");
lf[139]=C_h_intern(&lf[139],5,"reset");
lf[140]=C_h_intern(&lf[140],10,"backref-ci");
lf[141]=C_h_intern(&lf[141],7,"backref");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\032interminated named backref");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\036bad \134k usage, expected \134k<...>");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown escape sequence");
lf[145]=C_h_intern(&lf[145],3,"bol");
lf[146]=C_h_intern(&lf[146],3,"eol");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\025incomplete hex escape");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\024bad hex brace escape");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\033incomplete hex brace escape");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\025incomplete hex escape");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\016bad hex escape");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\037unicode codepoint out of range:");
lf[158]=C_h_intern(&lf[158],13,"integer->char");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid utf8 length");
lf[163]=C_h_intern(&lf[163],7,"irregex");
lf[164]=C_h_intern(&lf[164],15,"string->irregex");
lf[165]=C_h_intern(&lf[165],12,"sre->irregex");
lf[168]=C_h_intern(&lf[168],6,"w/case");
lf[169]=C_h_intern(&lf[169],8,"w/nocase");
lf[170]=C_h_intern(&lf[170],1,":");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid sre: empty *");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid sre: empty *\077");
lf[174]=C_h_intern(&lf[174],4,"word");
lf[175]=C_h_intern(&lf[175],5,"word+");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\001_");
lf[177]=C_h_intern(&lf[177],1,"&");
lf[178]=C_h_intern(&lf[178],12,"posix-string");
lf[179]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[180]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[181]=C_h_intern(&lf[181],6,"atomic");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\037unknown named backref in SRE IF");
lf[183]=C_h_intern(&lf[183],11,"string-ci=\077");
lf[184]=C_h_intern(&lf[184],8,"string=\077");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\025unknown backreference");
lf[186]=C_h_intern(&lf[186],3,"dsm");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown regexp operator");
lf[188]=C_h_intern(&lf[188],1,"-");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[191]=C_h_intern(&lf[191],9,"char-ci=\077");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[195]=C_h_intern(&lf[195],3,"max");
lf[196]=C_h_intern(&lf[196],3,"min");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000!sre-length: invalid backreference");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000)sre-length: invalid forward backreference");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\025unknown backreference");
lf[200]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\003>=\077\376\377\016");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\047sre-length-ranges: unknown sre operator");
lf[202]=C_h_intern(&lf[202],2,"=\077");
lf[203]=C_h_intern(&lf[203],3,">=\077");
lf[204]=C_h_intern(&lf[204],6,"commit");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\036sre-length-ranges: unknown sre");
lf[206]=C_h_intern(&lf[206],4,"cons");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\027unknown regexp operator");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\016unknown regexp");
lf[213]=C_h_intern(&lf[213],5,"small");
lf[214]=C_h_intern(&lf[214],4,"fast");
lf[217]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\003any\376\377\016");
lf[218]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\004nonl\376\377\016");
lf[219]=C_h_intern(&lf[219],8,"utf8-any");
lf[220]=C_h_intern(&lf[220],9,"utf8-nonl");
lf[221]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007epsilon\376\003\000\000\002\376\001\000\000\003bos\376\003\000\000\002\376\001\000\000\003eos\376\003\000\000\002\376\001\000\000\003bol\376\003\000\000\002\376\001\000\000\003eol\376\003\000\000\002\376\001\000\000\003b"
"ow\376\003\000\000\002\376\001\000\000\003eow\376\003\000\000\002\376\001\000\000\006commit\376\377\016");
lf[223]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\001+\376\377\016");
lf[225]=C_h_intern(&lf[225],14,"irregex-search");
lf[226]=C_h_intern(&lf[226],22,"irregex-search/matches");
lf[227]=C_h_intern(&lf[227],13,"irregex-match");
lf[228]=C_h_intern(&lf[228],10,"alphabetic");
lf[229]=C_h_intern(&lf[229],5,"alpha");
lf[230]=C_h_intern(&lf[230],8,"alphanum");
lf[231]=C_h_intern(&lf[231],5,"alnum");
lf[232]=C_h_intern(&lf[232],10,"lower-case");
lf[233]=C_h_intern(&lf[233],5,"lower");
lf[234]=C_h_intern(&lf[234],10,"upper-case");
lf[235]=C_h_intern(&lf[235],5,"upper");
lf[236]=C_h_intern(&lf[236],3,"num");
lf[237]=C_h_intern(&lf[237],5,"digit");
lf[238]=C_h_intern(&lf[238],11,"punctuation");
lf[239]=C_h_intern(&lf[239],5,"punct");
lf[240]=C_h_intern(&lf[240],7,"graphic");
lf[241]=C_h_intern(&lf[241],5,"graph");
lf[242]=C_h_intern(&lf[242],5,"blank");
lf[243]=C_h_intern(&lf[243],10,"whitespace");
lf[244]=C_h_intern(&lf[244],5,"white");
lf[245]=C_h_intern(&lf[245],8,"printing");
lf[246]=C_h_intern(&lf[246],5,"print");
lf[247]=C_h_intern(&lf[247],7,"control");
lf[248]=C_h_intern(&lf[248],5,"cntrl");
lf[249]=C_h_intern(&lf[249],9,"hex-digit");
lf[250]=C_h_intern(&lf[250],6,"xdigit");
lf[251]=C_h_intern(&lf[251],5,"ascii");
lf[252]=C_h_intern(&lf[252],10,"ascii-nonl");
lf[253]=C_h_intern(&lf[253],14,"utf8-tail-char");
lf[254]=C_h_intern(&lf[254],11,"utf8-2-char");
lf[255]=C_h_intern(&lf[255],11,"utf8-3-char");
lf[256]=C_h_intern(&lf[256],11,"utf8-4-char");
lf[257]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006w/case\376\003\000\000\002\376\001\000\000\006w/utf8\376\377\016");
lf[258]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007epsilon\376\377\016");
lf[259]=C_h_intern(&lf[259],12,"list->vector");
lf[260]=C_h_intern(&lf[260],3,"car");
lf[261]=C_h_intern(&lf[261],3,"cdr");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000!not a valid sre char-set operator");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\030not a valid sre char-set");
lf[274]=C_h_intern(&lf[274],12,"irregex-fold");
lf[275]=C_h_intern(&lf[275],15,"irregex-replace");
lf[276]=C_h_intern(&lf[276],19,"irregex-apply-match");
lf[277]=C_h_intern(&lf[277],19,"irregex-replace/all");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[279]=C_h_intern(&lf[279],3,"pre");
lf[280]=C_h_intern(&lf[280],4,"post");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\031unknown match replacement");
lf[282]=C_h_intern(&lf[282],7,"regexp\077");
lf[283]=C_h_intern(&lf[283],6,"regexp");
lf[285]=C_h_intern(&lf[285],12,"string-match");
lf[286]=C_h_intern(&lf[286],22,"string-match-positions");
lf[287]=C_h_intern(&lf[287],13,"string-search");
lf[288]=C_h_intern(&lf[288],23,"string-search-positions");
lf[289]=C_h_intern(&lf[289],9,"substring");
lf[290]=C_h_intern(&lf[290],19,"string-split-fields");
lf[291]=C_h_intern(&lf[291],6,"\000infix");
lf[292]=C_h_intern(&lf[292],7,"\000suffix");
lf[293]=C_h_intern(&lf[293],9,"\003syserror");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\037record does not end with suffix");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[296]=C_h_intern(&lf[296],17,"string-substitute");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\030empty substitution match");
lf[298]=C_h_intern(&lf[298],21,"\003sysfragments->string");
lf[299]=C_h_intern(&lf[299],18,"string-substitute*");
lf[300]=C_h_intern(&lf[300],5,"glob\077");
lf[301]=C_h_intern(&lf[301],12,"list->string");
lf[302]=C_h_intern(&lf[302],12,"string->list");
lf[303]=C_h_intern(&lf[303],12,"glob->regexp");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000!unexpected end of character class");
lf[305]=C_h_intern(&lf[305],4,"grep");
lf[306]=C_h_intern(&lf[306],17,"\003syscheck-closure");
lf[307]=C_h_intern(&lf[307],18,"open-output-string");
lf[308]=C_h_intern(&lf[308],17,"get-output-string");
lf[309]=C_h_intern(&lf[309],13,"regexp-escape");
lf[310]=C_h_intern(&lf[310],16,"\003syswrite-char-0");
lf[311]=C_h_intern(&lf[311],17,"register-feature!");
lf[312]=C_h_intern(&lf[312],5,"regex");
C_register_lf2(lf,313,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4471,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 65   register-feature! */
t3=*((C_word*)lf[311]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[312],lf[163]);}

/* k4469 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word t181;
C_word t182;
C_word t183;
C_word t184;
C_word t185;
C_word t186;
C_word t187;
C_word t188;
C_word t189;
C_word t190;
C_word t191;
C_word t192;
C_word t193;
C_word t194;
C_word t195;
C_word t196;
C_word t197;
C_word t198;
C_word t199;
C_word t200;
C_word t201;
C_word t202;
C_word t203;
C_word t204;
C_word t205;
C_word t206;
C_word t207;
C_word t208;
C_word t209;
C_word t210;
C_word t211;
C_word t212;
C_word t213;
C_word t214;
C_word t215;
C_word t216;
C_word t217;
C_word t218;
C_word t219;
C_word t220;
C_word t221;
C_word t222;
C_word t223;
C_word t224;
C_word t225;
C_word t226;
C_word t227;
C_word t228;
C_word t229;
C_word t230;
C_word t231;
C_word t232;
C_word t233;
C_word t234;
C_word t235;
C_word t236;
C_word t237;
C_word t238;
C_word t239;
C_word t240;
C_word t241;
C_word t242;
C_word t243;
C_word t244;
C_word t245;
C_word t246;
C_word t247;
C_word t248;
C_word t249;
C_word t250;
C_word t251;
C_word t252;
C_word t253;
C_word t254;
C_word t255;
C_word t256;
C_word t257;
C_word t258;
C_word t259;
C_word t260;
C_word t261;
C_word t262;
C_word t263;
C_word t264;
C_word t265;
C_word t266;
C_word t267;
C_word t268;
C_word t269;
C_word t270;
C_word t271;
C_word t272;
C_word t273;
C_word t274;
C_word t275;
C_word t276;
C_word t277;
C_word t278;
C_word t279;
C_word t280;
C_word t281;
C_word t282;
C_word t283;
C_word t284;
C_word t285;
C_word t286;
C_word t287;
C_word t288;
C_word t289;
C_word t290;
C_word t291;
C_word t292;
C_word t293;
C_word t294;
C_word t295;
C_word t296;
C_word t297;
C_word t298;
C_word t299;
C_word t300;
C_word t301;
C_word t302;
C_word t303;
C_word t304;
C_word t305;
C_word t306;
C_word t307;
C_word t308;
C_word t309;
C_word t310;
C_word t311;
C_word t312;
C_word t313;
C_word t314;
C_word t315;
C_word t316;
C_word t317;
C_word t318;
C_word t319;
C_word t320;
C_word t321;
C_word t322;
C_word t323;
C_word t324;
C_word t325;
C_word t326;
C_word t327;
C_word t328;
C_word t329;
C_word t330;
C_word t331;
C_word t332;
C_word t333;
C_word t334;
C_word t335;
C_word t336;
C_word t337;
C_word t338;
C_word t339;
C_word t340;
C_word t341;
C_word t342;
C_word t343;
C_word t344;
C_word t345;
C_word t346;
C_word t347;
C_word t348;
C_word t349;
C_word t350;
C_word t351;
C_word t352;
C_word ab[909],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4471,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! irregex? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4480,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[2]+1 /* (set! irregex-dfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4506,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[3]+1 /* (set! irregex-dfa/search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4512,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[4]+1 /* (set! irregex-dfa/extract ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4518,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[5]+1 /* (set! irregex-nfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4524,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[6]+1 /* (set! irregex-flags ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4530,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[7]+1 /* (set! irregex-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4536,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[8]+1 /* (set! irregex-lengths ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4542,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[9]+1 /* (set! irregex-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4548,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[10]+1 /* (set! irregex-new-matches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4554,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[13]+1 /* (set! irregex-reset-matches! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4568,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[14]+1 /* (set! irregex-match-data? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4602,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[15]+1 /* (set! irregex-match-num-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4655,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[16]+1 /* (set! irregex-match-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4673,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[17] /* (set! irregex-match-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4747,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[20] /* (set! irregex-match-valid-index? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4793,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[21]+1 /* (set! irregex-match-substring ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4825,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[23]+1 /* (set! irregex-match-start ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4868,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[24]+1 /* (set! irregex-match-end ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4891,tmp=(C_word)a,a+=2,tmp));
t21=(C_word)C_a_i_cons(&a,2,C_make_character(1114111),C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,C_make_character(57344),t21);
t23=(C_word)C_a_i_cons(&a,2,C_make_character(55295),t22);
t24=(C_word)C_a_i_cons(&a,2,C_make_character(0),t23);
t25=(C_word)C_a_i_cons(&a,2,lf[25],t24);
t26=C_mutate(&lf[26] /* (set! *all-chars* ...) */,t25);
t27=C_mutate(&lf[27] /* (set! string-scan-char ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4906,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate(&lf[28] /* (set! string-cat-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5166,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate(&lf[31] /* (set! zero-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5223,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate(&lf[32] /* (set! take-up-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5262,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate(&lf[34] /* (set! find-tail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5317,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate(&lf[35] /* (set! last ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5349,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate(&lf[37] /* (set! any ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5391,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate(&lf[38] /* (set! every ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5440,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate(&lf[30] /* (set! fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5489,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate(&lf[39] /* (set! filter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5519,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate(&lf[40] /* (set! bit-ior ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5631,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate(&lf[41] /* (set! bit-and ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5678,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate(&lf[42] /* (set! flag-join ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5735,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate(&lf[43] /* (set! flag-clear ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5744,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate(&lf[44] /* (set! symbol-list->flags ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5763,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[56]+1 /* (set! string->sre ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5863,tmp=(C_word)a,a+=2,tmp));
t43=(C_word)C_a_i_cons(&a,2,C_make_character(110),C_make_character(10));
t44=(C_word)C_a_i_cons(&a,2,C_make_character(114),C_make_character(13));
t45=(C_word)C_a_i_cons(&a,2,C_make_character(116),C_make_character(9));
t46=(C_word)C_a_i_cons(&a,2,C_make_character(97),C_make_character(7));
t47=(C_word)C_a_i_cons(&a,2,C_make_character(101),C_make_character(27));
t48=(C_word)C_a_i_cons(&a,2,C_make_character(102),C_make_character(12));
t49=(C_word)C_a_i_cons(&a,2,t48,C_SCHEME_END_OF_LIST);
t50=(C_word)C_a_i_cons(&a,2,t47,t49);
t51=(C_word)C_a_i_cons(&a,2,t46,t50);
t52=(C_word)C_a_i_cons(&a,2,t45,t51);
t53=(C_word)C_a_i_cons(&a,2,t44,t52);
t54=(C_word)C_a_i_cons(&a,2,t43,t53);
t55=C_mutate(&lf[117] /* (set! posix-escape-sequences ...) */,t54);
t56=C_mutate(&lf[118] /* (set! string-parse-hex-escape ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8849,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate(&lf[114] /* (set! high-char? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9652,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate(&lf[60] /* (set! utf8-string-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9672,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate(&lf[153] /* (set! utf8-lowest-digit-of-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9897,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate(&lf[155] /* (set! char->utf8-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9957,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate(&lf[157] /* (set! unicode-range-helper ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10233,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate(&lf[159] /* (set! unicode-range-up-from ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10388,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate(&lf[160] /* (set! unicode-range-up-to ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10551,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate(&lf[161] /* (set! cset->utf8-pattern ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11240,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[163]+1 /* (set! irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11863,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[164]+1 /* (set! string->irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11884,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[165]+1 /* (set! sre->irregex ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11894,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate(&lf[89] /* (set! sre-empty? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12045,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate(&lf[222] /* (set! sre-any? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12173,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate(&lf[86] /* (set! sre-repeater? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12249,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate(&lf[216] /* (set! sre-searcher? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12305,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate(&lf[194] /* (set! sre-consumer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12391,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate(&lf[212] /* (set! sre-has-submatchs? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12477,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate(&lf[167] /* (set! sre-count-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12503,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate(&lf[58] /* (set! sre-sequence ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13598,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate(&lf[61] /* (set! sre-alternate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13623,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate(&lf[173] /* (set! sre-strip-submatches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13648,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate(&lf[193] /* (set! sre-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13798,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate(&lf[224] /* (set! sre-sequence-names ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14028,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate(&lf[215] /* (set! sre-remove-initial-bos ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14064,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[225]+1 /* (set! irregex-search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14216,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[226]+1 /* (set! irregex-search/matches ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14262,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[227]+1 /* (set! irregex-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14421,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate(&lf[209] /* (set! dfa-match/longest ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14599,tmp=(C_word)a,a+=2,tmp));
t85=(C_word)C_a_i_cons(&a,2,lf[74],lf[26]);
t86=(C_word)C_a_i_string(&a,1,C_make_character(10));
t87=(C_word)C_a_i_cons(&a,2,t86,C_SCHEME_END_OF_LIST);
t88=(C_word)C_a_i_cons(&a,2,t87,C_SCHEME_END_OF_LIST);
t89=(C_word)C_a_i_cons(&a,2,lf[26],t88);
t90=(C_word)C_a_i_cons(&a,2,lf[188],t89);
t91=(C_word)C_a_i_cons(&a,2,lf[75],t90);
t92=(C_word)C_a_i_cons(&a,2,C_make_character(90),C_SCHEME_END_OF_LIST);
t93=(C_word)C_a_i_cons(&a,2,C_make_character(65),t92);
t94=(C_word)C_a_i_cons(&a,2,C_make_character(122),t93);
t95=(C_word)C_a_i_cons(&a,2,C_make_character(97),t94);
t96=(C_word)C_a_i_cons(&a,2,lf[25],t95);
t97=(C_word)C_a_i_cons(&a,2,lf[228],t96);
t98=(C_word)C_a_i_cons(&a,2,lf[229],lf[228]);
t99=(C_word)C_a_i_cons(&a,2,C_make_character(57),C_SCHEME_END_OF_LIST);
t100=(C_word)C_a_i_cons(&a,2,C_make_character(48),t99);
t101=(C_word)C_a_i_cons(&a,2,C_make_character(90),t100);
t102=(C_word)C_a_i_cons(&a,2,C_make_character(65),t101);
t103=(C_word)C_a_i_cons(&a,2,C_make_character(122),t102);
t104=(C_word)C_a_i_cons(&a,2,C_make_character(97),t103);
t105=(C_word)C_a_i_cons(&a,2,lf[25],t104);
t106=(C_word)C_a_i_cons(&a,2,lf[131],t105);
t107=(C_word)C_a_i_cons(&a,2,lf[230],lf[131]);
t108=(C_word)C_a_i_cons(&a,2,lf[231],lf[131]);
t109=(C_word)C_a_i_cons(&a,2,C_make_character(122),C_SCHEME_END_OF_LIST);
t110=(C_word)C_a_i_cons(&a,2,C_make_character(97),t109);
t111=(C_word)C_a_i_cons(&a,2,lf[25],t110);
t112=(C_word)C_a_i_cons(&a,2,lf[232],t111);
t113=(C_word)C_a_i_cons(&a,2,lf[233],lf[232]);
t114=(C_word)C_a_i_cons(&a,2,C_make_character(90),C_SCHEME_END_OF_LIST);
t115=(C_word)C_a_i_cons(&a,2,C_make_character(65),t114);
t116=(C_word)C_a_i_cons(&a,2,lf[25],t115);
t117=(C_word)C_a_i_cons(&a,2,lf[234],t116);
t118=(C_word)C_a_i_cons(&a,2,lf[235],lf[234]);
t119=(C_word)C_a_i_cons(&a,2,C_make_character(57),C_SCHEME_END_OF_LIST);
t120=(C_word)C_a_i_cons(&a,2,C_make_character(48),t119);
t121=(C_word)C_a_i_cons(&a,2,lf[25],t120);
t122=(C_word)C_a_i_cons(&a,2,lf[128],t121);
t123=(C_word)C_a_i_cons(&a,2,lf[236],lf[128]);
t124=(C_word)C_a_i_cons(&a,2,lf[237],lf[128]);
t125=(C_word)C_a_i_cons(&a,2,C_make_character(125),C_SCHEME_END_OF_LIST);
t126=(C_word)C_a_i_cons(&a,2,C_make_character(123),t125);
t127=(C_word)C_a_i_cons(&a,2,C_make_character(95),t126);
t128=(C_word)C_a_i_cons(&a,2,C_make_character(93),t127);
t129=(C_word)C_a_i_cons(&a,2,C_make_character(92),t128);
t130=(C_word)C_a_i_cons(&a,2,C_make_character(91),t129);
t131=(C_word)C_a_i_cons(&a,2,C_make_character(64),t130);
t132=(C_word)C_a_i_cons(&a,2,C_make_character(63),t131);
t133=(C_word)C_a_i_cons(&a,2,C_make_character(59),t132);
t134=(C_word)C_a_i_cons(&a,2,C_make_character(58),t133);
t135=(C_word)C_a_i_cons(&a,2,C_make_character(47),t134);
t136=(C_word)C_a_i_cons(&a,2,C_make_character(46),t135);
t137=(C_word)C_a_i_cons(&a,2,C_make_character(45),t136);
t138=(C_word)C_a_i_cons(&a,2,C_make_character(44),t137);
t139=(C_word)C_a_i_cons(&a,2,C_make_character(42),t138);
t140=(C_word)C_a_i_cons(&a,2,C_make_character(41),t139);
t141=(C_word)C_a_i_cons(&a,2,C_make_character(40),t140);
t142=(C_word)C_a_i_cons(&a,2,C_make_character(39),t141);
t143=(C_word)C_a_i_cons(&a,2,C_make_character(38),t142);
t144=(C_word)C_a_i_cons(&a,2,C_make_character(37),t143);
t145=(C_word)C_a_i_cons(&a,2,C_make_character(35),t144);
t146=(C_word)C_a_i_cons(&a,2,C_make_character(34),t145);
t147=(C_word)C_a_i_cons(&a,2,C_make_character(33),t146);
t148=(C_word)C_a_i_cons(&a,2,lf[57],t147);
t149=(C_word)C_a_i_cons(&a,2,lf[238],t148);
t150=(C_word)C_a_i_cons(&a,2,lf[239],lf[238]);
t151=(C_word)C_a_i_cons(&a,2,C_make_character(126),C_SCHEME_END_OF_LIST);
t152=(C_word)C_a_i_cons(&a,2,C_make_character(124),t151);
t153=(C_word)C_a_i_cons(&a,2,C_make_character(96),t152);
t154=(C_word)C_a_i_cons(&a,2,C_make_character(94),t153);
t155=(C_word)C_a_i_cons(&a,2,C_make_character(62),t154);
t156=(C_word)C_a_i_cons(&a,2,C_make_character(61),t155);
t157=(C_word)C_a_i_cons(&a,2,C_make_character(60),t156);
t158=(C_word)C_a_i_cons(&a,2,C_make_character(43),t157);
t159=(C_word)C_a_i_cons(&a,2,C_make_character(36),t158);
t160=(C_word)C_a_i_cons(&a,2,lf[238],t159);
t161=(C_word)C_a_i_cons(&a,2,lf[131],t160);
t162=(C_word)C_a_i_cons(&a,2,lf[57],t161);
t163=(C_word)C_a_i_cons(&a,2,lf[240],t162);
t164=(C_word)C_a_i_cons(&a,2,lf[241],lf[240]);
t165=(C_word)C_a_i_cons(&a,2,C_make_character(9),C_SCHEME_END_OF_LIST);
t166=(C_word)C_a_i_cons(&a,2,C_make_character(32),t165);
t167=(C_word)C_a_i_cons(&a,2,lf[57],t166);
t168=(C_word)C_a_i_cons(&a,2,lf[242],t167);
t169=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t170=(C_word)C_a_i_cons(&a,2,lf[242],t169);
t171=(C_word)C_a_i_cons(&a,2,lf[57],t170);
t172=(C_word)C_a_i_cons(&a,2,lf[243],t171);
t173=(C_word)C_a_i_cons(&a,2,lf[129],lf[243]);
t174=(C_word)C_a_i_cons(&a,2,lf[244],lf[243]);
t175=(C_word)C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t176=(C_word)C_a_i_cons(&a,2,lf[240],t175);
t177=(C_word)C_a_i_cons(&a,2,lf[57],t176);
t178=(C_word)C_a_i_cons(&a,2,lf[245],t177);
t179=(C_word)C_a_i_cons(&a,2,lf[246],lf[245]);
t180=(C_word)C_a_i_cons(&a,2,C_make_character(31),C_SCHEME_END_OF_LIST);
t181=(C_word)C_a_i_cons(&a,2,C_make_character(0),t180);
t182=(C_word)C_a_i_cons(&a,2,lf[25],t181);
t183=(C_word)C_a_i_cons(&a,2,lf[247],t182);
t184=(C_word)C_a_i_cons(&a,2,lf[248],lf[247]);
t185=(C_word)C_a_i_cons(&a,2,C_make_character(70),C_SCHEME_END_OF_LIST);
t186=(C_word)C_a_i_cons(&a,2,C_make_character(65),t185);
t187=(C_word)C_a_i_cons(&a,2,C_make_character(102),t186);
t188=(C_word)C_a_i_cons(&a,2,C_make_character(97),t187);
t189=(C_word)C_a_i_cons(&a,2,lf[25],t188);
t190=(C_word)C_a_i_cons(&a,2,t189,C_SCHEME_END_OF_LIST);
t191=(C_word)C_a_i_cons(&a,2,lf[128],t190);
t192=(C_word)C_a_i_cons(&a,2,lf[57],t191);
t193=(C_word)C_a_i_cons(&a,2,lf[249],t192);
t194=(C_word)C_a_i_cons(&a,2,lf[250],lf[249]);
t195=(C_word)C_a_i_cons(&a,2,C_make_character(127),C_SCHEME_END_OF_LIST);
t196=(C_word)C_a_i_cons(&a,2,C_make_character(0),t195);
t197=(C_word)C_a_i_cons(&a,2,lf[25],t196);
t198=(C_word)C_a_i_cons(&a,2,lf[251],t197);
t199=(C_word)C_a_i_cons(&a,2,C_make_character(127),C_SCHEME_END_OF_LIST);
t200=(C_word)C_a_i_cons(&a,2,C_make_character(11),t199);
t201=(C_word)C_a_i_cons(&a,2,C_make_character(9),t200);
t202=(C_word)C_a_i_cons(&a,2,C_make_character(0),t201);
t203=(C_word)C_a_i_cons(&a,2,lf[25],t202);
t204=(C_word)C_a_i_cons(&a,2,lf[252],t203);
t205=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t206=(C_word)C_a_i_cons(&a,2,C_make_character(13),t205);
t207=(C_word)C_a_i_cons(&a,2,lf[68],t206);
t208=(C_word)C_a_i_cons(&a,2,C_make_character(13),C_SCHEME_END_OF_LIST);
t209=(C_word)C_a_i_cons(&a,2,C_make_character(10),t208);
t210=(C_word)C_a_i_cons(&a,2,lf[25],t209);
t211=(C_word)C_a_i_cons(&a,2,t210,C_SCHEME_END_OF_LIST);
t212=(C_word)C_a_i_cons(&a,2,t207,t211);
t213=(C_word)C_a_i_cons(&a,2,lf[57],t212);
t214=(C_word)C_a_i_cons(&a,2,lf[138],t213);
t215=(C_word)C_a_i_cons(&a,2,C_make_character(95),C_SCHEME_END_OF_LIST);
t216=(C_word)C_a_i_cons(&a,2,lf[131],t215);
t217=(C_word)C_a_i_cons(&a,2,lf[57],t216);
t218=(C_word)C_a_i_cons(&a,2,t217,C_SCHEME_END_OF_LIST);
t219=(C_word)C_a_i_cons(&a,2,lf[79],t218);
t220=(C_word)C_a_i_cons(&a,2,lf[133],C_SCHEME_END_OF_LIST);
t221=(C_word)C_a_i_cons(&a,2,t219,t220);
t222=(C_word)C_a_i_cons(&a,2,lf[134],t221);
t223=(C_word)C_a_i_cons(&a,2,lf[68],t222);
t224=(C_word)C_a_i_cons(&a,2,lf[174],t223);
t225=(C_word)C_a_i_cons(&a,2,C_make_character(193),C_SCHEME_END_OF_LIST);
t226=(C_word)C_a_i_cons(&a,2,C_make_character(128),t225);
t227=(C_word)C_a_i_cons(&a,2,lf[25],t226);
t228=(C_word)C_a_i_cons(&a,2,lf[253],t227);
t229=(C_word)C_a_i_cons(&a,2,C_make_character(223),C_SCHEME_END_OF_LIST);
t230=(C_word)C_a_i_cons(&a,2,C_make_character(194),t229);
t231=(C_word)C_a_i_cons(&a,2,lf[25],t230);
t232=(C_word)C_a_i_cons(&a,2,lf[253],C_SCHEME_END_OF_LIST);
t233=(C_word)C_a_i_cons(&a,2,t231,t232);
t234=(C_word)C_a_i_cons(&a,2,lf[68],t233);
t235=(C_word)C_a_i_cons(&a,2,lf[254],t234);
t236=(C_word)C_a_i_cons(&a,2,C_make_character(239),C_SCHEME_END_OF_LIST);
t237=(C_word)C_a_i_cons(&a,2,C_make_character(224),t236);
t238=(C_word)C_a_i_cons(&a,2,lf[25],t237);
t239=(C_word)C_a_i_cons(&a,2,lf[253],C_SCHEME_END_OF_LIST);
t240=(C_word)C_a_i_cons(&a,2,lf[253],t239);
t241=(C_word)C_a_i_cons(&a,2,t238,t240);
t242=(C_word)C_a_i_cons(&a,2,lf[68],t241);
t243=(C_word)C_a_i_cons(&a,2,lf[255],t242);
t244=(C_word)C_a_i_cons(&a,2,C_make_character(247),C_SCHEME_END_OF_LIST);
t245=(C_word)C_a_i_cons(&a,2,C_make_character(240),t244);
t246=(C_word)C_a_i_cons(&a,2,lf[25],t245);
t247=(C_word)C_a_i_cons(&a,2,lf[253],C_SCHEME_END_OF_LIST);
t248=(C_word)C_a_i_cons(&a,2,lf[253],t247);
t249=(C_word)C_a_i_cons(&a,2,lf[253],t248);
t250=(C_word)C_a_i_cons(&a,2,t246,t249);
t251=(C_word)C_a_i_cons(&a,2,lf[68],t250);
t252=(C_word)C_a_i_cons(&a,2,lf[256],t251);
t253=(C_word)C_a_i_cons(&a,2,lf[256],C_SCHEME_END_OF_LIST);
t254=(C_word)C_a_i_cons(&a,2,lf[255],t253);
t255=(C_word)C_a_i_cons(&a,2,lf[254],t254);
t256=(C_word)C_a_i_cons(&a,2,lf[251],t255);
t257=(C_word)C_a_i_cons(&a,2,lf[57],t256);
t258=(C_word)C_a_i_cons(&a,2,lf[219],t257);
t259=(C_word)C_a_i_cons(&a,2,lf[256],C_SCHEME_END_OF_LIST);
t260=(C_word)C_a_i_cons(&a,2,lf[255],t259);
t261=(C_word)C_a_i_cons(&a,2,lf[254],t260);
t262=(C_word)C_a_i_cons(&a,2,lf[252],t261);
t263=(C_word)C_a_i_cons(&a,2,lf[57],t262);
t264=(C_word)C_a_i_cons(&a,2,lf[220],t263);
t265=(C_word)C_a_i_cons(&a,2,t264,C_SCHEME_END_OF_LIST);
t266=(C_word)C_a_i_cons(&a,2,t258,t265);
t267=(C_word)C_a_i_cons(&a,2,t252,t266);
t268=(C_word)C_a_i_cons(&a,2,t243,t267);
t269=(C_word)C_a_i_cons(&a,2,t235,t268);
t270=(C_word)C_a_i_cons(&a,2,t228,t269);
t271=(C_word)C_a_i_cons(&a,2,t224,t270);
t272=(C_word)C_a_i_cons(&a,2,t214,t271);
t273=(C_word)C_a_i_cons(&a,2,t204,t272);
t274=(C_word)C_a_i_cons(&a,2,t198,t273);
t275=(C_word)C_a_i_cons(&a,2,t194,t274);
t276=(C_word)C_a_i_cons(&a,2,t193,t275);
t277=(C_word)C_a_i_cons(&a,2,t184,t276);
t278=(C_word)C_a_i_cons(&a,2,t183,t277);
t279=(C_word)C_a_i_cons(&a,2,t179,t278);
t280=(C_word)C_a_i_cons(&a,2,t178,t279);
t281=(C_word)C_a_i_cons(&a,2,t174,t280);
t282=(C_word)C_a_i_cons(&a,2,t173,t281);
t283=(C_word)C_a_i_cons(&a,2,t172,t282);
t284=(C_word)C_a_i_cons(&a,2,t168,t283);
t285=(C_word)C_a_i_cons(&a,2,t164,t284);
t286=(C_word)C_a_i_cons(&a,2,t163,t285);
t287=(C_word)C_a_i_cons(&a,2,t150,t286);
t288=(C_word)C_a_i_cons(&a,2,t149,t287);
t289=(C_word)C_a_i_cons(&a,2,t124,t288);
t290=(C_word)C_a_i_cons(&a,2,t123,t289);
t291=(C_word)C_a_i_cons(&a,2,t122,t290);
t292=(C_word)C_a_i_cons(&a,2,t118,t291);
t293=(C_word)C_a_i_cons(&a,2,t117,t292);
t294=(C_word)C_a_i_cons(&a,2,t113,t293);
t295=(C_word)C_a_i_cons(&a,2,t112,t294);
t296=(C_word)C_a_i_cons(&a,2,t108,t295);
t297=(C_word)C_a_i_cons(&a,2,t107,t296);
t298=(C_word)C_a_i_cons(&a,2,t106,t297);
t299=(C_word)C_a_i_cons(&a,2,t98,t298);
t300=(C_word)C_a_i_cons(&a,2,t97,t299);
t301=(C_word)C_a_i_cons(&a,2,t91,t300);
t302=(C_word)C_a_i_cons(&a,2,t85,t301);
t303=C_mutate(&lf[189] /* (set! sre-named-definitions ...) */,t302);
t304=C_mutate(&lf[211] /* (set! sre->nfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14706,tmp=(C_word)a,a+=2,tmp));
t305=C_mutate(&lf[210] /* (set! nfa->dfa ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_15564,tmp=(C_word)a,a+=2,tmp));
t306=C_mutate(&lf[263] /* (set! nfa-join-transitions! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16082,tmp=(C_word)a,a+=2,tmp));
t307=C_mutate(&lf[265] /* (set! split-char-range ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16556,tmp=(C_word)a,a+=2,tmp));
t308=C_mutate(&lf[266] /* (set! intersect-char-ranges ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16630,tmp=(C_word)a,a+=2,tmp));
t309=C_mutate(&lf[262] /* (set! nfa-closure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16746,tmp=(C_word)a,a+=2,tmp));
t310=C_mutate(&lf[264] /* (set! insert-sorted ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16862,tmp=(C_word)a,a+=2,tmp));
t311=C_mutate(&lf[166] /* (set! sre-cset->procedure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19260,tmp=(C_word)a,a+=2,tmp));
t312=C_mutate(&lf[124] /* (set! sre->cset ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19377,tmp=(C_word)a,a+=2,tmp));
t313=C_mutate(&lf[267] /* (set! cset-contains? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19798,tmp=(C_word)a,a+=2,tmp));
t314=C_mutate(&lf[273] /* (set! char-ranges-overlap? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19848,tmp=(C_word)a,a+=2,tmp));
t315=C_mutate(&lf[268] /* (set! cset-union ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19993,tmp=(C_word)a,a+=2,tmp));
t316=C_mutate(&lf[270] /* (set! cset-difference ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20085,tmp=(C_word)a,a+=2,tmp));
t317=C_mutate(&lf[269] /* (set! cset-intersection ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20211,tmp=(C_word)a,a+=2,tmp));
t318=C_mutate(&lf[123] /* (set! cset-complement ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20334,tmp=(C_word)a,a+=2,tmp));
t319=C_mutate(&lf[112] /* (set! cset-case-insensitive ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20344,tmp=(C_word)a,a+=2,tmp));
t320=C_mutate((C_word*)lf[274]+1 /* (set! irregex-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20509,tmp=(C_word)a,a+=2,tmp));
t321=C_mutate((C_word*)lf[275]+1 /* (set! irregex-replace ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20622,tmp=(C_word)a,a+=2,tmp));
t322=C_mutate((C_word*)lf[277]+1 /* (set! irregex-replace/all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20674,tmp=(C_word)a,a+=2,tmp));
t323=C_mutate((C_word*)lf[276]+1 /* (set! irregex-apply-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20730,tmp=(C_word)a,a+=2,tmp));
t324=C_mutate((C_word*)lf[282]+1 /* (set! regexp? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20912,tmp=(C_word)a,a+=2,tmp));
t325=C_mutate((C_word*)lf[283]+1 /* (set! regexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20930,tmp=(C_word)a,a+=2,tmp));
t326=C_mutate(&lf[284] /* (set! unregexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21033,tmp=(C_word)a,a+=2,tmp));
t327=C_mutate((C_word*)lf[285]+1 /* (set! string-match ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21054,tmp=(C_word)a,a+=2,tmp));
t328=C_mutate((C_word*)lf[286]+1 /* (set! string-match-positions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21100,tmp=(C_word)a,a+=2,tmp));
t329=C_mutate((C_word*)lf[287]+1 /* (set! string-search ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21162,tmp=(C_word)a,a+=2,tmp));
t330=C_mutate((C_word*)lf[288]+1 /* (set! string-search-positions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21274,tmp=(C_word)a,a+=2,tmp));
t331=*((C_word*)lf[33]+1);
t332=*((C_word*)lf[289]+1);
t333=*((C_word*)lf[288]+1);
t334=C_mutate((C_word*)lf[290]+1 /* (set! string-split-fields ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21394,a[2]=t331,a[3]=t333,a[4]=t332,tmp=(C_word)a,a+=5,tmp));
t335=*((C_word*)lf[289]+1);
t336=*((C_word*)lf[33]+1);
t337=*((C_word*)lf[29]+1);
t338=*((C_word*)lf[288]+1);
t339=C_mutate((C_word*)lf[296]+1 /* (set! string-substitute ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21576,a[2]=t338,a[3]=t336,a[4]=t335,tmp=(C_word)a,a+=5,tmp));
t340=*((C_word*)lf[296]+1);
t341=C_mutate((C_word*)lf[299]+1 /* (set! string-substitute* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21831,a[2]=t340,tmp=(C_word)a,a+=3,tmp));
t342=C_mutate((C_word*)lf[300]+1 /* (set! glob? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21883,tmp=(C_word)a,a+=2,tmp));
t343=*((C_word*)lf[301]+1);
t344=*((C_word*)lf[302]+1);
t345=C_mutate((C_word*)lf[303]+1 /* (set! glob->regexp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_21968,tmp=(C_word)a,a+=2,tmp));
t346=*((C_word*)lf[287]+1);
t347=*((C_word*)lf[283]+1);
t348=C_mutate((C_word*)lf[305]+1 /* (set! grep ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_22245,a[2]=t347,a[3]=t346,tmp=(C_word)a,a+=4,tmp));
t349=*((C_word*)lf[307]+1);
t350=*((C_word*)lf[308]+1);
t351=C_mutate((C_word*)lf[309]+1 /* (set! regexp-escape ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_22312,tmp=(C_word)a,a+=2,tmp));
t352=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t352+1)))(2,t352,C_SCHEME_UNDEFINED);}

/* regexp-escape in k4469 */
static void C_ccall f_22312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_22312,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[309]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_22319,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 321  open-output-string */
t5=*((C_word*)lf[307]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k22317 in regexp-escape in k4469 */
static void C_ccall f_22319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22319,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_22327,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_22327(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k22317 in regexp-escape in k4469 */
static void C_fcall f_22327(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_22327,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
/* regex.scm: 324  get-output-string */
t3=*((C_word*)lf[308]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_22346,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 327  ##sys#write-char-0 */
t5=*((C_word*)lf[310]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_22359,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 331  ##sys#write-char-0 */
t5=*((C_word*)lf[310]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k22357 in loop in k22317 in regexp-escape in k4469 */
static void C_ccall f_22359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 332  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_22327(t3,((C_word*)t0)[2],t2);}

/* k22344 in loop in k22317 in regexp-escape in k4469 */
static void C_ccall f_22346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_22349,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 328  ##sys#write-char-0 */
t3=*((C_word*)lf[310]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k22347 in k22344 in loop in k22317 in regexp-escape in k4469 */
static void C_ccall f_22349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 329  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_22327(t3,((C_word*)t0)[2],t2);}

/* grep in k4469 */
static void C_ccall f_22245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4rv,(void*)f_22245r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_22245r(t0,t1,t2,t3,t4);}}

static void C_ccall f_22245r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(10);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_22300,tmp=(C_word)a,a+=2,tmp):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_list_2(t3,lf[305]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_22255,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t6,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* regex.scm: 302  ##sys#check-closure */
t9=*((C_word*)lf[306]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t6,lf[305]);}

/* k22253 in grep in k4469 */
static void C_ccall f_22255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_22258,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 303  regexp */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k22256 in k22253 in grep in k4469 */
static void C_ccall f_22258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22258,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_22263,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_22263(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k22256 in k22253 in grep in k4469 */
static void C_fcall f_22263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_22263,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_22282,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_22296,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 309  acc */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}}

/* k22294 in loop in k22256 in k22253 in grep in k4469 */
static void C_ccall f_22296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 309  string-search */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k22280 in loop in k22256 in k22253 in grep in k4469 */
static void C_ccall f_22282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22282,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_22289,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 310  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_22263(t3,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 311  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_22263(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k22287 in k22280 in loop in k22256 in k22253 in grep in k4469 */
static void C_ccall f_22289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22289,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f_22300 in grep in k4469 */
static void C_ccall f_22300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_22300,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* glob->regexp in k4469 */
static void C_ccall f_21968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_21968,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[303]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21979,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21983,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t6=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k21981 in glob->regexp in k4469 */
static void C_ccall f_21983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21983,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21985,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_21985(t5,((C_word*)t0)[2],t1);}

/* loop in k21981 in glob->regexp in k4469 */
static void C_fcall f_21985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_21985,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_22015,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_22019,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 272  loop */
t18=t6;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_22032,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 273  loop */
t18=t5;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(91):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_22045,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_22047,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_22047(t9,t5,t4);
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_22225,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 291  loop */
t18=t7;
t19=t4;
t1=t18;
t2=t19;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_22236,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_22240,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 292  loop */
t18=t8;
t19=t4;
t1=t18;
t2=t19;
goto loop;}}}}

/* k22238 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k22234 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22236,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(92),t2));}

/* k22223 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22225,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k21981 in glob->regexp in k4469 */
static void C_fcall f_22047(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_22047,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(C_make_character(93),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_22067,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
/* regex.scm: 280  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_21985(t7,t5,t6);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_22077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(C_make_character(45),t6);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=t5;
f_22077(t9,(C_word)C_i_pairp(t8));}
else{
t8=t5;
f_22077(t8,C_SCHEME_FALSE);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k22075 in loop2 in loop in k21981 in glob->regexp in k4469 */
static void C_fcall f_22077(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_22077,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_22092,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_22096,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
/* regex.scm: 282  loop2 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_22047(t6,t4,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_22106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t6=t2;
f_22106(t6,(C_word)C_eqp(C_make_character(45),t5));}
else{
t5=t2;
f_22106(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_22106(t4,C_SCHEME_FALSE);}}}

/* k22104 in k22075 in loop2 in loop in k21981 in glob->regexp in k4469 */
static void C_fcall f_22106(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_22106,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_22129,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_22133,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cdddr(((C_word*)t0)[5]);
/* regex.scm: 286  loop2 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_22047(t7,t5,t6);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_22154,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 288  loop2 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_22047(t5,t3,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* regex.scm: 290  error */
t2=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[303],lf[304],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}}

/* k22152 in k22104 in k22075 in loop2 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22154,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k22131 in k22104 in k22075 in loop2 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k22127 in k22104 in k22075 in loop2 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22129,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,C_make_character(45),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k22094 in k22075 in loop2 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k22090 in k22075 in loop2 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22092,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(45),t2));}

/* k22065 in loop2 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22067,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(93),t1));}

/* k22043 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22045,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(91),t1));}

/* k22030 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22032,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k22017 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k22013 in loop in k21981 in glob->regexp in k4469 */
static void C_ccall f_22015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_22015,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(42),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(46),t2));}

/* k21977 in glob->regexp in k4469 */
static void C_ccall f_21979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* glob? in k4469 */
static void C_ccall f_21883(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_21883,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[300]);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21896,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_21896(t9,t1,t5);}

/* loop in glob? in k4469 */
static void C_fcall f_21896(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21896,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t2))){
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(42));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_21915(t6,t4);}
else{
t6=(C_word)C_eqp(t3,C_make_character(93));
t7=t5;
f_21915(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,C_make_character(63))));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k21913 in loop in glob? in k4469 */
static void C_fcall f_21915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(C_fix(0),((C_word*)t0)[5]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[3],t3);
t5=(C_word)C_eqp(C_make_character(92),t4);
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 257  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_21896(t8,((C_word*)t0)[4],t7);}}}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 259  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_21896(t3,((C_word*)t0)[4],t2);}}

/* string-substitute* in k4469 */
static void C_ccall f_21831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_21831r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_21831r(t0,t1,t2,t3,t4);}}

static void C_ccall f_21831r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(7);
t5=(C_word)C_i_check_string_2(t2,lf[299]);
t6=(C_word)C_i_check_list_2(t3,lf[299]);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21846,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_21846(t12,t1,t2,t3);}

/* loop in string-substitute* in k4469 */
static void C_fcall f_21846(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21846,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21863,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_slot(t4,C_fix(1));
/* regex.scm: 243  string-substitute */
t8=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t5,t6,t7,t2,((C_word*)t0)[2]);}}

/* k21861 in loop in string-substitute* in k4469 */
static void C_ccall f_21863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 243  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_21846(t3,((C_word*)t0)[2],t1,t2);}

/* string-substitute in k4469 */
static void C_ccall f_21576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+36)){
C_save_and_reclaim((void*)tr5rv,(void*)f_21576r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_21576r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_21576r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a=C_alloc(36);
t6=(C_word)C_i_check_string_2(t3,lf[296]);
t7=(C_word)C_i_check_string_2(t4,lf[296]);
t8=(C_word)C_notvemptyp(t5);
t9=(C_truep(t8)?(C_word)C_slot(t5,C_fix(0)):C_fix(1));
t10=(C_word)C_block_size(t3);
t11=(C_word)C_block_size(t4);
t12=(C_word)C_u_fixnum_difference(t10,C_fix(1));
t13=C_SCHEME_END_OF_LIST;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_fix(0);
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21597,a[2]=t16,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t22=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_21612,a[2]=t4,a[3]=t10,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t18,a[7]=t12,tmp=(C_word)a,a+=8,tmp));
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_set_block_item(t24,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_21718,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t14,a[5]=((C_word*)t0)[3],a[6]=t16,a[7]=t4,a[8]=((C_word*)t0)[4],a[9]=t20,a[10]=t24,a[11]=t18,a[12]=t9,a[13]=t2,tmp=(C_word)a,a+=14,tmp));
t26=((C_word*)t24)[1];
f_21718(t26,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k4469 */
static void C_fcall f_21718(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21718,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_21722,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[3]))){
/* regex.scm: 214  string-search-positions */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[13],((C_word*)t0)[7],t2);}
else{
t5=t4;
f_21722(2,t5,C_SCHEME_FALSE);}}

/* k21720 in loop in string-substitute in k4469 */
static void C_ccall f_21722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21722,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_fixnum_difference(t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* regex.scm: 219  ##sys#error */
t8=*((C_word*)lf[293]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[14],lf[296],lf[297],((C_word*)t0)[13]);}
else{
t8=(C_word)C_fixnump(((C_word*)t0)[12]);
t9=(C_word)C_i_not(t8);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[12]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_21762,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_u_i_car(t2);
/* regex.scm: 223  substring */
t13=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,((C_word*)t0)[6],((C_word*)t0)[5],t12);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_21780,a[2]=t3,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 227  substring */
t12=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t11,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_21813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* regex.scm: 230  substring */
t4=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k21811 in k21720 in loop in string-substitute in k4469 */
static void C_ccall f_21813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21813,2,t0,t1);}
t2=f_21597(C_a_i(&a,3),((C_word*)((C_word*)t0)[6])[1],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21809,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 231  reverse */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k21807 in k21811 in k21720 in loop in string-substitute in k4469 */
static void C_ccall f_21809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 231  ##sys#fragments->string */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k21778 in k21720 in loop in string-substitute in k4469 */
static void C_ccall f_21780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21780,2,t0,t1);}
t2=f_21597(C_a_i(&a,3),((C_word*)((C_word*)t0)[6])[1],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 228  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_21718(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k21760 in k21720 in loop in string-substitute in k4469 */
static void C_ccall f_21762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21762,2,t0,t1);}
t2=f_21597(C_a_i(&a,3),((C_word*)((C_word*)t0)[7])[1],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21755,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 224  substitute */
t4=((C_word*)((C_word*)t0)[3])[1];
f_21612(t4,t3,((C_word*)t0)[2]);}

/* k21753 in k21760 in k21720 in loop in string-substitute in k4469 */
static void C_ccall f_21755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 225  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_21718(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* substitute in string-substitute in k4469 */
static void C_fcall f_21612(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21612,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_21618,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_21618(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k4469 */
static void C_fcall f_21618(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_21618,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21632,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=((C_word*)t0)[7];
/* regex.scm: 200  push */
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,f_21597(C_a_i(&a,3),((C_word*)((C_word*)t0)[8])[1],t6));}
else{
/* regex.scm: 200  substring */
t6=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:(C_word)C_u_i_char_numericp(t7));
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t7));
t11=(C_word)C_u_fixnum_difference(t10,C_fix(48));
t12=(C_word)C_u_i_list_ref(((C_word*)t0)[4],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_21685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 207  substring */
t14=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t13,((C_word*)t0)[7],t2,t3);}
else{
t10=(C_word)C_u_fixnum_plus(t5,C_fix(1));
/* regex.scm: 210  loop */
t19=t1;
t20=t2;
t21=t10;
t1=t19;
t2=t20;
t3=t21;
goto loop;}}
else{
/* regex.scm: 211  loop */
t19=t1;
t20=t2;
t21=t5;
t1=t19;
t2=t20;
t3=t21;
goto loop;}}}

/* k21683 in loop in substitute in string-substitute in k4469 */
static void C_ccall f_21685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21685,2,t0,t1);}
t2=f_21597(C_a_i(&a,3),((C_word*)((C_word*)t0)[9])[1],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_21673,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* regex.scm: 208  substring */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k21671 in k21683 in loop in substitute in string-substitute in k4469 */
static void C_ccall f_21673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21673,2,t0,t1);}
t2=f_21597(C_a_i(&a,3),((C_word*)((C_word*)t0)[6])[1],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 209  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_21618(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k21630 in loop in substitute in string-substitute in k4469 */
static void C_ccall f_21632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21632,2,t0,t1);}
/* regex.scm: 200  push */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_21597(C_a_i(&a,3),((C_word*)((C_word*)t0)[2])[1],t1));}

/* push in string-substitute in k4469 */
static C_word C_fcall f_21597(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k4469 */
static void C_ccall f_21394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_21394r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_21394r(t0,t1,t2,t3,t4);}}

static void C_ccall f_21394r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(16);
t5=(C_word)C_i_check_string_2(t3,lf[290]);
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t6,C_fix(0));
t9=(C_truep(t8)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_TRUE);
t10=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t11=(C_truep(t10)?(C_word)C_slot(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_21413,a[2]=t11,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_eqp(t9,lf[292]);
if(C_truep(t13)){
t14=t12;
f_21413(t14,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21512,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp));}
else{
t14=(C_word)C_eqp(t9,lf[291]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21532,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t16=t12;
f_21413(t16,t15);}
else{
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21558,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t16=t12;
f_21413(t16,t15);}}}

/* f_21558 in string-split-fields in k4469 */
static void C_ccall f_21558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_21558,4,t0,t1,t2,t3);}
/* regex.scm: 160  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* f_21532 in string-split-fields in k4469 */
static void C_ccall f_21532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_21532,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=(C_word)C_a_i_cons(&a,2,lf[295],t2);
/* regex.scm: 158  reverse */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21557,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 159  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k21555 */
static void C_ccall f_21557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21557,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* regex.scm: 159  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_21512 in string-split-fields in k4469 */
static void C_ccall f_21512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_21512,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* regex.scm: 152  ##sys#error */
t4=*((C_word*)lf[293]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[290],lf[294],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* regex.scm: 154  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k21411 in string-split-fields in k4469 */
static void C_fcall f_21413(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21413,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[291]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[292]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21496,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21501,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_21421,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_21421(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k21411 in string-split-fields in k4469 */
static void C_fcall f_21421(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21421,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_21425,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* regex.scm: 165  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k21423 in loop in k21411 in string-split-fields in k4469 */
static void C_ccall f_21425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21425,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* regex.scm: 172  fini */
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21467,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t4,C_fix(2));
/* regex.scm: 173  fetch */
t10=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21486,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 174  fetch */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* regex.scm: 175  fini */
t2=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k21484 in k21423 in loop in k21411 in string-split-fields in k4469 */
static void C_ccall f_21486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21486,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 174  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_21421(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k21465 in k21423 in loop in k21411 in string-split-fields in k4469 */
static void C_ccall f_21467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21467,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 173  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_21421(t4,((C_word*)t0)[2],t2,t3);}

/* f_21501 in k21411 in string-split-fields in k4469 */
static void C_ccall f_21501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_21501,5,t0,t1,t2,t3,t4);}
/* regex.scm: 163  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_21496 in k21411 in string-split-fields in k4469 */
static void C_ccall f_21496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_21496,5,t0,t1,t2,t3,t4);}
/* regex.scm: 162  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k4469 */
static void C_ccall f_21274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_21274r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_21274r(t0,t1,t2,t3,t4);}}

static void C_ccall f_21274r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21276,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21340,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21349,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start41644185 */
t8=t7;
f_21349(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-range41654183 */
t10=t6;
f_21340(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body41624170 */
t12=t5;
f_21276(t12,t1,t8,t10);}}}

/* def-start4164 in string-search-positions in k4469 */
static void C_fcall f_21349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21349,NULL,2,t0,t1);}
/* def-range41654183 */
t2=((C_word*)t0)[2];
f_21340(t2,t1,C_fix(0));}

/* def-range4165 in string-search-positions in k4469 */
static void C_fcall f_21340(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21340,NULL,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* body41624170 */
t4=((C_word*)t0)[2];
f_21276(t4,t1,t2,t3);}

/* body4162 in string-search-positions in k4469 */
static void C_fcall f_21276(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21276,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21280,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 124  unregexp */
f_21033(t4,((C_word*)t0)[2]);}

/* k21278 in body4162 in string-search-positions in k4469 */
static void C_ccall f_21280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21280,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21289,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21335,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[2]);
/* regex.scm: 126  min */
t6=*((C_word*)lf[196]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k21333 in k21278 in body4162 in string-search-positions in k4469 */
static void C_ccall f_21335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 126  irregex-search */
t2=*((C_word*)lf[225]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k21287 in k21278 in body4162 in string-search-positions in k4469 */
static void C_ccall f_21289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21289,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21299,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 127  irregex-match-num-submatches */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k21297 in k21287 in k21278 in body4162 in string-search-positions in k4469 */
static void C_ccall f_21299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21299,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21301,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_21301(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k21297 in k21287 in k21278 in body4162 in string-search-positions in k4469 */
static void C_fcall f_21301(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_21301,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=((C_word*)t0)[3];
t6=t2;
t7=(C_word)C_fixnum_shift_left(t6,C_fix(1));
t8=(C_word)C_u_fixnum_plus(C_fix(3),t7);
t9=(C_word)C_slot(t5,t8);
t10=((C_word*)t0)[3];
t11=t2;
t12=(C_word)C_fixnum_shift_left(t11,C_fix(1));
t13=(C_word)C_u_fixnum_plus(C_fix(4),t12);
t14=(C_word)C_slot(t10,t13);
t15=(C_word)C_a_i_list(&a,2,t9,t14);
t16=(C_word)C_a_i_cons(&a,2,t15,t3);
/* regex.scm: 131  loop */
t19=t1;
t20=t4;
t21=t16;
t1=t19;
t2=t20;
t3=t21;
goto loop;}}

/* string-search in k4469 */
static void C_ccall f_21162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_21162r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_21162r(t0,t1,t2,t3,t4);}}

static void C_ccall f_21162r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21164,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21220,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21229,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start41214142 */
t8=t7;
f_21229(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-range41224140 */
t10=t6;
f_21220(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body41194127 */
t12=t5;
f_21164(t12,t1,t8,t10);}}}

/* def-start4121 in string-search in k4469 */
static void C_fcall f_21229(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21229,NULL,2,t0,t1);}
/* def-range41224140 */
t2=((C_word*)t0)[2];
f_21220(t2,t1,C_fix(0));}

/* def-range4122 in string-search in k4469 */
static void C_fcall f_21220(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21220,NULL,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* body41194127 */
t4=((C_word*)t0)[2];
f_21164(t4,t1,t2,t3);}

/* body4119 in string-search in k4469 */
static void C_fcall f_21164(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21164,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21168,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 114  unregexp */
f_21033(t4,((C_word*)t0)[2]);}

/* k21166 in body4119 in string-search in k4469 */
static void C_ccall f_21168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21168,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_21177,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21215,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[2]);
/* regex.scm: 116  min */
t6=*((C_word*)lf[196]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k21213 in k21166 in body4119 in string-search in k4469 */
static void C_ccall f_21215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 116  irregex-search */
t2=*((C_word*)lf[225]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k21175 in k21166 in body4119 in string-search in k4469 */
static void C_ccall f_21177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21177,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21187,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 117  irregex-match-num-submatches */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k21185 in k21175 in k21166 in body4119 in string-search in k4469 */
static void C_ccall f_21187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21187,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21189,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_21189(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k21185 in k21175 in k21166 in body4119 in string-search in k4469 */
static void C_fcall f_21189(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21189,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21211,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 121  irregex-match-substring */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k21209 in loop in k21185 in k21175 in k21166 in body4119 in string-search in k4469 */
static void C_ccall f_21211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21211,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 121  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_21189(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* string-match-positions in k4469 */
static void C_ccall f_21100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_21100,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21104,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 103  unregexp */
f_21033(t4,t2);}

/* k21102 in string-match-positions in k4469 */
static void C_ccall f_21104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 104  irregex-match */
t3=*((C_word*)lf[227]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}

/* k21105 in k21102 in string-match-positions in k4469 */
static void C_ccall f_21107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21107,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21117,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 105  irregex-match-num-submatches */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k21115 in k21105 in k21102 in string-match-positions in k4469 */
static void C_ccall f_21117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21117,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21119,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_21119(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k21115 in k21105 in k21102 in string-match-positions in k4469 */
static void C_fcall f_21119(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_21119,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t5=(C_word)C_a_i_list(&a,2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t3));}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=((C_word*)t0)[3];
t6=t2;
t7=(C_word)C_fixnum_shift_left(t6,C_fix(1));
t8=(C_word)C_u_fixnum_plus(C_fix(3),t7);
t9=(C_word)C_slot(t5,t8);
t10=((C_word*)t0)[3];
t11=t2;
t12=(C_word)C_fixnum_shift_left(t11,C_fix(1));
t13=(C_word)C_u_fixnum_plus(C_fix(4),t12);
t14=(C_word)C_slot(t10,t13);
t15=(C_word)C_a_i_list(&a,2,t9,t14);
t16=(C_word)C_a_i_cons(&a,2,t15,t3);
/* regex.scm: 109  loop */
t20=t1;
t21=t4;
t22=t16;
t1=t20;
t2=t21;
t3=t22;
goto loop;}}

/* string-match in k4469 */
static void C_ccall f_21054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_21054,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21058,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 94   unregexp */
f_21033(t4,t2);}

/* k21056 in string-match in k4469 */
static void C_ccall f_21058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 95   irregex-match */
t3=*((C_word*)lf[227]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}

/* k21059 in k21056 in string-match in k4469 */
static void C_ccall f_21061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21061,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21071,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 96   irregex-match-num-submatches */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k21069 in k21059 in k21056 in string-match in k4469 */
static void C_ccall f_21071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21071,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_21073,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_21073(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k21069 in k21059 in k21056 in string-match in k4469 */
static void C_fcall f_21073(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21073,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3));}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_21098,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 100  irregex-match-substring */
t6=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k21096 in loop in k21069 in k21059 in k21056 in string-match in k4469 */
static void C_ccall f_21098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21098,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 100  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_21073(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* unregexp in k4469 */
static void C_fcall f_21033(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_21033,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21040,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 86   regexp? */
t4=*((C_word*)lf[282]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k21038 in unregexp in k4469 */
static void C_ccall f_21040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_21040,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_block_ref(t3,C_fix(1)));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_21049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 87   irregex? */
t3=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k21047 in k21038 in unregexp in k4469 */
static void C_ccall f_21049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 88   irregex */
t2=*((C_word*)lf[163]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* regexp in k4469 */
static void C_ccall f_20930(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_20930r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_20930r(t0,t1,t2,t3);}}

static void C_ccall f_20930r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20932,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20963,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20968,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20973,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-caseless40384064 */
t8=t7;
f_20973(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-extended40394062 */
t10=t6;
f_20968(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-utf840404059 */
t12=t5;
f_20963(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body40364045 */
t14=t4;
f_20932(t14,t1,t8,t10,t12);}}}}

/* def-caseless4038 in regexp in k4469 */
static void C_fcall f_20973(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20973,NULL,2,t0,t1);}
/* def-extended40394062 */
t2=((C_word*)t0)[2];
f_20968(t2,t1,C_SCHEME_FALSE);}

/* def-extended4039 in regexp in k4469 */
static void C_fcall f_20968(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20968,NULL,3,t0,t1,t2);}
/* def-utf840404059 */
t3=((C_word*)t0)[2];
f_20963(t3,t1,t2,C_SCHEME_FALSE);}

/* def-utf84040 in regexp in k4469 */
static void C_fcall f_20963(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20963,NULL,4,t0,t1,t2,t3);}
/* body40364045 */
t4=((C_word*)t0)[2];
f_20932(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body4036 in regexp in k4469 */
static void C_fcall f_20932(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20932,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20940,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20944,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t7,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t9=(C_word)C_a_i_cons(&a,2,lf[45],((C_word*)t7)[1]);
t10=C_set_block_item(t7,0,t9);
t11=t8;
f_20944(t11,t10);}
else{
t9=t8;
f_20944(t9,C_SCHEME_UNDEFINED);}}

/* k20942 in body4036 in regexp in k4469 */
static void C_fcall f_20944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20944,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_cons(&a,2,lf[50],((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=t2;
f_20947(t5,t4);}
else{
t3=t2;
f_20947(t3,C_SCHEME_UNDEFINED);}}

/* k20945 in k20942 in body4036 in regexp in k4469 */
static void C_fcall f_20947(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20947,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_a_i_cons(&a,2,lf[53],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)((C_word*)t0)[4])[1];
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[163]+1),((C_word*)t0)[2],t4);}
else{
t2=((C_word*)((C_word*)t0)[4])[1];
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[163]+1),((C_word*)t0)[2],t2);}}

/* k20938 in body4036 in regexp in k4469 */
static void C_ccall f_20940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20940,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[283],t1));}

/* regexp? in k4469 */
static void C_ccall f_20912(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_20912,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[283]));}

/* irregex-apply-match in k4469 */
static void C_ccall f_20730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20730,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20736,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_20736(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in irregex-apply-match in k4469 */
static void C_fcall f_20736(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_20736,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_integerp(t4))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20764,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_i_car(t2);
/* irregex-match-substring */
t8=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_closurep(t5))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_u_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20795,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* g38573858 */
t9=t7;
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[2]);}
else{
t6=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t6))){
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_eqp(t7,lf[279]);
if(C_truep(t8)){
t9=(C_word)C_slot(t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20825,a[2]=t9,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20829,a[2]=((C_word*)t0)[2],a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-string */
t12=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[2]);}
else{
t9=(C_word)C_eqp(t7,lf[280]);
if(C_truep(t9)){
t10=(C_word)C_slot(t2,C_fix(1));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20854,a[2]=t10,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20858,a[2]=((C_word*)t0)[2],a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-string */
t13=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t0)[2]);}
else{
t10=(C_word)C_u_i_car(t2);
/* error */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[281],t10);}}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* lp3843 */
t28=t1;
t29=t7;
t30=t9;
t1=t28;
t2=t29;
t3=t30;
goto loop;}}}}}

/* k20856 in lp in irregex-apply-match in k4469 */
static void C_ccall f_20858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20862,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* irregex-match-end */
t3=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k20860 in k20856 in lp in irregex-apply-match in k4469 */
static void C_ccall f_20862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20870,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* irregex-match-string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k20868 in k20860 in k20856 in lp in irregex-apply-match in k4469 */
static void C_ccall f_20870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_header_size(t1));
/* substring */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20852 in lp in irregex-apply-match in k4469 */
static void C_ccall f_20854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20854,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp3843 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20736(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20827 in lp in irregex-apply-match in k4469 */
static void C_ccall f_20829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20833,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-match-start */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k20831 in k20827 in lp in irregex-apply-match in k4469 */
static void C_ccall f_20833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* substring */
t2=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k20823 in lp in irregex-apply-match in k4469 */
static void C_ccall f_20825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20825,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp3843 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20736(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20793 in lp in irregex-apply-match in k4469 */
static void C_ccall f_20795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20795,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* lp3843 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20736(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20762 in lp in irregex-apply-match in k4469 */
static void C_ccall f_20764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20764,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
/* lp3843 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_20736(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_a_i_cons(&a,2,lf[278],((C_word*)t0)[5]);
/* lp3843 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_20736(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* irregex-replace/all in k4469 */
static void C_ccall f_20674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_20674r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_20674r(t0,t1,t2,t3,t4);}}

static void C_ccall f_20674r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20680,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20707,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* irregex-fold */
t7=*((C_word*)lf[274]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,t2,t5,C_SCHEME_END_OF_LIST,t3,t6);}

/* a20706 in irregex-replace/all in k4469 */
static void C_ccall f_20707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20707,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[2]));
t5=t2;
t6=(C_word)C_eqp(t5,t4);
if(C_truep(t6)){
t7=t3;
/* string-cat-reverse */
f_5166(t1,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20728,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* substring */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[2],t2,t4);}}

/* k20726 in a20706 in irregex-replace/all in k4469 */
static void C_ccall f_20728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20728,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* string-cat-reverse */
f_5166(((C_word*)t0)[2],t2);}

/* a20679 in irregex-replace/all in k4469 */
static void C_ccall f_20680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_20680,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_20684,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* irregex-match-start */
t6=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_fix(0));}

/* k20682 in a20679 in irregex-replace/all in k4469 */
static void C_ccall f_20684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20691,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* irregex-apply-match */
t3=*((C_word*)lf[276]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k20689 in k20682 in a20679 in irregex-replace/all in k4469 */
static void C_ccall f_20691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20691,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=((C_word*)t0)[4];
/* append */
t6=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[3],t1,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20705,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* substring */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k20703 in k20689 in k20682 in a20679 in irregex-replace/all in k4469 */
static void C_ccall f_20705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20705,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* append */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* irregex-replace in k4469 */
static void C_ccall f_20622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_20622r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_20622r(t0,t1,t2,t3,t4);}}

static void C_ccall f_20622r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20626,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20672,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* irregex */
t7=*((C_word*)lf[163]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k20670 in irregex-replace in k4469 */
static void C_ccall f_20672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* irregex-search */
t2=*((C_word*)lf[225]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k20624 in irregex-replace in k4469 */
static void C_ccall f_20626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20626,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20640,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20664,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-match-end */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_fix(0));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k20662 in k20624 in irregex-replace in k4469 */
static void C_ccall f_20664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
/* substring */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],((C_word*)t0)[3],t1,t2);}

/* k20638 in k20624 in irregex-replace in k4469 */
static void C_ccall f_20640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20644,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* irregex-apply-match */
t4=*((C_word*)lf[276]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k20646 in k20638 in k20624 in irregex-replace in k4469 */
static void C_ccall f_20648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20656,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20660,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-start */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_fix(0));}

/* k20658 in k20646 in k20638 in k20624 in irregex-replace in k4469 */
static void C_ccall f_20660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* substring */
t2=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

/* k20654 in k20646 in k20638 in k20624 in irregex-replace in k4469 */
static void C_ccall f_20656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20656,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* append */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k20642 in k20638 in k20624 in irregex-replace in k4469 */
static void C_ccall f_20644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20644,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* string-cat-reverse */
f_5166(((C_word*)t0)[2],t2);}

/* irregex-fold in k4469 */
static void C_ccall f_20509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_20509r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_20509r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_20509r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20513,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* irregex */
t8=*((C_word*)lf[163]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k20511 in irregex-fold in k4469 */
static void C_ccall f_20513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_20516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* irregex-new-matches */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k20514 in k20511 in irregex-fold in k4469 */
static void C_ccall f_20516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20516,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[7]):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_20619,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_20522,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t6=(C_word)C_i_pairp(t5);
t7=t4;
f_20522(t7,(C_truep(t6)?(C_word)C_u_i_cadr(((C_word*)t0)[7]):C_fix(0)));}
else{
t5=t4;
f_20522(t5,C_fix(0));}}

/* k20520 in k20514 in k20511 in irregex-fold in k4469 */
static void C_fcall f_20522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20522,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_20525,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
t5=(C_word)C_i_pairp(t4);
t6=t2;
f_20525(t6,(C_truep(t5)?(C_word)C_u_i_caddr(((C_word*)t0)[2]):(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[8]))));}
else{
t4=t2;
f_20525(t4,(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[8])));}}
else{
t3=t2;
f_20525(t3,(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[8])));}}

/* k20523 in k20520 in k20514 in k20511 in irregex-fold in k4469 */
static void C_fcall f_20525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20525,NULL,2,t0,t1);}
t2=((C_word*)t0)[9];
t3=((C_word*)t0)[8];
t4=(C_word)C_i_setslot(t2,C_fix(1),t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_20533,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[9],a[6]=t6,a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_20533(t8,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k20523 in k20520 in k20514 in k20511 in irregex-fold in k4469 */
static void C_fcall f_20533(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20533,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[8];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
/* finish3801 */
t6=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_20546,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* irregex-search/matches */
t7=*((C_word*)lf[226]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t6,((C_word*)t0)[3],((C_word*)t0)[2],t2,((C_word*)t0)[8],((C_word*)t0)[5]);}}

/* k20544 in lp in k20523 in k20520 in k20514 in k20511 in irregex-fold in k4469 */
static void C_ccall f_20546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20546,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_20558,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* irregex-match-end */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_fix(0));}
else{
/* finish3801 */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k20556 in k20544 in lp in k20523 in k20520 in k20514 in k20511 in irregex-fold in k4469 */
static void C_ccall f_20558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20561,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* kons3794 */
t3=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k20559 in k20556 in k20544 in lp in k20523 in k20520 in k20514 in k20511 in irregex-fold in k4469 */
static void C_ccall f_20561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20564,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* irregex-reset-matches! */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k20562 in k20559 in k20556 in k20544 in lp in k20523 in k20520 in k20514 in k20511 in irregex-fold in k4469 */
static void C_ccall f_20564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3812 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_20533(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_20619 in k20514 in k20511 in irregex-fold in k4469 */
static void C_ccall f_20619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20619,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* cset-case-insensitive in k4469 */
static void C_ccall f_20344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_20344,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20350,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_20350(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* lp in cset-case-insensitive in k4469 */
static void C_fcall f_20350(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20350,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20366,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_car(t2);
t7=t4;
f_20366(t7,(C_word)C_u_i_char_alphabeticp(t6));}
else{
t6=t4;
f_20366(t6,C_SCHEME_FALSE);}}}

/* k20364 in lp in cset-case-insensitive in k4469 */
static void C_fcall f_20366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20366,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_u_i_char_upper_casep(t2);
t4=(C_truep(t3)?(C_word)C_u_i_char_downcase(t2):(C_word)C_u_i_char_upcase(t2));
t5=(C_word)C_u_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[4]);
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20386,a[2]=t4,a[3]=t6,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* cset-contains? */
f_19798(t8,t6,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20403,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_caar(((C_word*)t0)[5]);
if(C_truep((C_word)C_u_i_char_alphabeticp(t4))){
t5=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t6=t2;
f_20403(t6,(C_word)C_u_i_char_alphabeticp(t5));}
else{
t5=t2;
f_20403(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_20403(t4,C_SCHEME_FALSE);}}}

/* k20401 in k20364 in lp in cset-case-insensitive in k4469 */
static void C_fcall f_20403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20403,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20414,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20418,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
/* cset-union */
t7=lf[268];
f_19993(4,t7,t4,((C_word*)t0)[2],t6);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20461,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
/* cset-union */
t6=lf[268];
f_19993(4,t6,t3,((C_word*)t0)[2],t5);}}

/* k20459 in k20401 in k20364 in lp in cset-case-insensitive in k4469 */
static void C_ccall f_20461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3774 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_20350(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k20416 in k20401 in k20364 in lp in cset-case-insensitive in k4469 */
static void C_ccall f_20418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20418,2,t0,t1);}
t2=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t3=(C_word)C_u_i_char_upper_casep(t2);
t4=(C_truep(t3)?(C_word)C_u_i_char_downcase(t2):(C_word)C_u_i_char_upcase(t2));
t5=(C_word)C_u_i_cdar(((C_word*)t0)[3]);
t6=(C_word)C_u_i_char_upper_casep(t5);
t7=(C_truep(t6)?(C_word)C_u_i_char_downcase(t5):(C_word)C_u_i_char_upcase(t5));
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
/* cset-union */
t10=lf[268];
f_19993(4,t10,((C_word*)t0)[2],t1,t9);}

/* k20412 in k20401 in k20364 in lp in cset-case-insensitive in k4469 */
static void C_ccall f_20414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3774 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_20350(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k20384 in k20364 in lp in cset-case-insensitive in k4469 */
static void C_ccall f_20386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20386,2,t0,t1);}
if(C_truep(t1)){
/* lp3774 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_20350(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* lp3774 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_20350(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2);}}

/* cset-complement in k4469 */
static void C_fcall f_20334(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20334,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20342,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* sre->cset */
f_19377(t3,lf[26],C_SCHEME_END_OF_LIST);}

/* k20340 in cset-complement in k4469 */
static void C_ccall f_20342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-difference */
f_20085(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* cset-intersection in k4469 */
static void C_ccall f_20211(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_20211,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20217,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_20217(t7,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* intersect in cset-intersection in k4469 */
static void C_fcall f_20217(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20217,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20227,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20324,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5317(t5,t6,t2);}}

/* a20323 in intersect in cset-intersection in k4469 */
static void C_ccall f_20324(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_20324,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_19848(t1,t2,t3);}

/* k20225 in intersect in cset-intersection in k4469 */
static void C_ccall f_20227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20227,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20231,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* g37553756 */
t3=t2;
f_20231(t3,((C_word*)t0)[2],t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* intersect3742 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_20217(t3,((C_word*)t0)[2],((C_word*)t0)[3],t2,((C_word*)t0)[5]);}}

/* g3755 in k20225 in intersect in cset-intersection in k4469 */
static void C_fcall f_20231(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20231,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20237,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20296,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_car(t2);
t6=(C_truep((C_word)C_charp(t5))?(C_word)C_a_i_cons(&a,2,t5,t5):t5);
t7=(C_word)C_u_i_car(((C_word*)t0)[3]);
if(C_truep((C_word)C_charp(t7))){
t8=(C_word)C_a_i_cons(&a,2,t7,t7);
/* intersect-char-ranges */
f_16630(t4,t6,t8);}
else{
/* intersect-char-ranges */
f_16630(t4,t6,t7);}}

/* k20294 in g3755 in k20225 in intersect in cset-intersection in k4469 */
static void C_ccall f_20296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a20236 in g3755 in k20225 in intersect in cset-intersection in k4469 */
static void C_ccall f_20237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_20237,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_20241,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20288,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5262(t8,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k20286 in a20236 in g3755 in k20225 in intersect in cset-intersection in k4469 */
static void C_ccall f_20288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k20239 in a20236 in g3755 in k20225 in intersect in cset-intersection in k4469 */
static void C_ccall f_20241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20241,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1):t1);
t3=(C_truep(((C_word*)t0)[9])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2):t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_20250,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t6=lf[268];
f_19993(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t5=t4;
f_20250(2,t5,((C_word*)t0)[2]);}}

/* k20248 in k20239 in a20236 in g3755 in k20225 in intersect in cset-intersection in k4469 */
static void C_ccall f_20250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_20253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* cset-union */
t4=lf[268];
f_19993(4,t4,t2,t1,t3);}
else{
t3=t2;
f_20253(2,t3,t1);}}

/* k20251 in k20248 in k20239 in a20236 in g3755 in k20225 in intersect in cset-intersection in k4469 */
static void C_ccall f_20253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_20260,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t4=lf[268];
f_19993(4,t4,t2,((C_word*)t0)[2],t3);}

/* k20258 in k20251 in k20248 in k20239 in a20236 in g3755 in k20225 in intersect in cset-intersection in k4469 */
static void C_ccall f_20260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* intersect3742 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_20217(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cset-difference in k4469 */
static void C_fcall f_20085(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_20085,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_u_i_car(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20108,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20197,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5317(t4,t5,t2);}
else{
t4=(C_word)C_slot(t3,C_fix(1));
/* cset-difference */
t9=t1;
t10=t2;
t11=t4;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* a20196 in cset-difference in k4469 */
static void C_ccall f_20197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_20197,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_19848(t1,t2,t3);}

/* k20106 in cset-difference in k4469 */
static void C_ccall f_20108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20108,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* g37253726 */
t3=t2;
f_20112(t3,((C_word*)t0)[2],t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* cset-difference */
f_20085(((C_word*)t0)[2],((C_word*)t0)[3],t2);}}

/* g3725 in k20106 in cset-difference in k4469 */
static void C_fcall f_20112(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20112,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20118,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20169,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_car(t2);
t6=(C_truep((C_word)C_charp(t5))?(C_word)C_a_i_cons(&a,2,t5,t5):t5);
t7=(C_word)C_u_i_car(((C_word*)t0)[3]);
if(C_truep((C_word)C_charp(t7))){
t8=(C_word)C_a_i_cons(&a,2,t7,t7);
/* intersect-char-ranges */
f_16630(t4,t6,t8);}
else{
/* intersect-char-ranges */
f_16630(t4,t6,t7);}}

/* k20167 in g3725 in k20106 in cset-difference in k4469 */
static void C_ccall f_20169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a20117 in g3725 in k20106 in cset-difference in k4469 */
static void C_ccall f_20118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_20118,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_20122,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20161,a[2]=t7,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5262(t8,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k20159 in a20117 in g3725 in k20106 in cset-difference in k4469 */
static void C_ccall f_20161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k20120 in a20117 in g3725 in k20106 in cset-difference in k4469 */
static void C_ccall f_20122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20122,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1):t1);
t3=(C_truep(((C_word*)t0)[6])?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2):t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20131,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* cset-union */
t6=lf[268];
f_19993(4,t6,t4,((C_word*)t0)[2],t5);}
else{
t5=t4;
f_20131(2,t5,((C_word*)t0)[2]);}}

/* k20129 in k20120 in a20117 in g3725 in k20106 in cset-difference in k4469 */
static void C_ccall f_20131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* cset-union */
t4=lf[268];
f_19993(4,t4,t2,t1,t3);}
else{
t3=t1;
/* cset-difference */
f_20085(((C_word*)t0)[4],((C_word*)t0)[3],t3);}}

/* k20132 in k20129 in k20120 in a20117 in g3725 in k20106 in cset-difference in k4469 */
static void C_ccall f_20134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-difference */
f_20085(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cset-union in k4469 */
static void C_ccall f_19993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19993,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20003,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_20075,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5317(t4,t5,t2);}}

/* a20074 in cset-union in k4469 */
static void C_ccall f_20075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_20075,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* char-ranges-overlap? */
f_19848(t1,t2,t3);}

/* k20001 in cset-union in k4469 */
static void C_ccall f_20003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20003,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20007,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* g37103711 */
t3=t2;
f_20007(t3,((C_word*)t0)[2],t1);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* cset-union */
t5=lf[268];
f_19993(4,t5,((C_word*)t0)[2],t3,t4);}}

/* g3710 in k20001 in cset-union in k4469 */
static void C_fcall f_20007(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_20007,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20015,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_20023,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_20051,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5262(t5,((C_word*)t0)[2],t2);}

/* k20049 in g3710 in k20001 in cset-union in k4469 */
static void C_ccall f_20051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k20021 in g3710 in k20001 in cset-union in k4469 */
static void C_ccall f_20023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_20023,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_truep((C_word)C_charp(t2))?(C_word)C_a_i_cons(&a,2,t2,t2):t2);
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
t5=(C_truep((C_word)C_charp(t4))?(C_word)C_a_i_cons(&a,2,t4,t4):t4);
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_u_i_car(t5);
t8=(C_word)C_fixnum_less_or_equal_p(t6,t7);
t9=(C_truep(t8)?(C_word)C_u_i_car(t3):(C_word)C_u_i_car(t5));
t10=(C_word)C_slot(t3,C_fix(1));
t11=(C_word)C_slot(t5,C_fix(1));
t12=(C_word)C_fixnum_greater_or_equal_p(t10,t11);
t13=(C_truep(t12)?(C_word)C_slot(t3,C_fix(1)):(C_word)C_slot(t5,C_fix(1)));
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=(C_word)C_a_i_list(&a,1,t14);
/* cset-union */
t16=lf[268];
f_19993(4,t16,((C_word*)t0)[2],t1,t15);}

/* k20013 in g3710 in k20001 in cset-union in k4469 */
static void C_ccall f_20015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* cset-union */
t3=lf[268];
f_19993(4,t3,((C_word*)t0)[2],t1,t2);}

/* char-ranges-overlap? in k4469 */
static void C_fcall f_19848(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19848,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19864,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t6))){
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t2,C_fix(1));
t9=t4;
f_19864(t9,(C_word)C_fixnum_less_or_equal_p(t7,t8));}
else{
t7=t4;
f_19864(t7,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t3))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(t3,t5));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* char-ranges-overlap? */
t12=t1;
t13=t3;
t14=t2;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_eqvp(t2,t3));}}}

/* k19862 in char-ranges-overlap? in k4469 */
static void C_fcall f_19864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t3))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_u_i_car(((C_word*)t0)[3]);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(t4,t5));}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* cset-contains? in k4469 */
static void C_fcall f_19798(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19798,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19804,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f27494,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* find-tail */
f_5317(t5,t4,t2);}

/* f27494 in cset-contains? in k4469 */
static void C_ccall f27494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_u_i_car(t1):C_SCHEME_FALSE));}

/* a19803 in cset-contains? in k4469 */
static void C_ccall f_19804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_19804,3,t0,t1,t2);}
t3=(C_word)C_i_eqvp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,((C_word*)t0)[2]))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t5));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* sre->cset in k4469 */
static void C_fcall f_19377(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19377,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19387,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_19387(t9,t1,t2,t5);}

/* lp in sre->cset in k4469 */
static void C_fcall f_19387(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19387,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19390,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t5))){
if(C_truep(t3)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19416,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_u_i_car(t2);
/* string->list */
t8=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t6=(C_word)C_u_i_car(t2);
/* string->list */
t7=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[110]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19443,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19447,a[2]=t4,a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_u_i_cadr(t2);
/* rec3559 */
t11=t4;
f_19390(t11,t9,t10);}
else{
t8=(C_word)C_eqp(t6,lf[177]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19507,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_u_i_cadr(t2);
/* rec3559 */
t11=t4;
f_19390(t11,t9,t10);}
else{
t9=(C_word)C_eqp(t6,lf[188]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_19565,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19573,a[2]=t4,a[3]=t2,a[4]=t10,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_u_i_cadr(t2);
/* rec3559 */
t13=t4;
f_19390(t13,t11,t12);}
else{
t10=(C_word)C_eqp(t6,lf[25]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19629,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19639,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_slot(t2,C_fix(1));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13742,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=((C_word*)t15)[1];
f_13742(t17,t12,t13,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_eqp(t6,lf[57]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19656,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(C_word)C_u_i_cadr(t2);
/* rec3559 */
t14=t4;
f_19390(t14,t12,t13);}
else{
t12=(C_word)C_eqp(t6,lf[168]);
if(C_truep(t12)){
t13=(C_word)C_slot(t2,C_fix(1));
t14=f_13623(C_a_i(&a,3),t13);
/* lp3550 */
t43=t1;
t44=t14;
t45=C_SCHEME_FALSE;
t1=t43;
t2=t44;
t3=t45;
goto loop;}
else{
t13=(C_word)C_eqp(t6,lf[169]);
if(C_truep(t13)){
t14=(C_word)C_slot(t2,C_fix(1));
t15=f_13623(C_a_i(&a,3),t14);
/* lp3550 */
t43=t1;
t44=t15;
t45=C_SCHEME_TRUE;
t1=t43;
t2=t44;
t3=t45;
goto loop;}
else{
/* error */
t14=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[271],t2);}}}}}}}}}
else{
if(C_truep((C_word)C_charp(t2))){
t5=(C_word)C_a_i_string(&a,1,t2);
t6=(C_word)C_a_i_list(&a,1,t5);
/* rec3559 */
t7=t4;
f_19390(t7,t1,t6);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t5=(C_word)C_a_i_list(&a,1,t2);
/* rec3559 */
t6=t4;
f_19390(t6,t1,t5);}
else{
t5=(C_word)C_u_i_assq(t2,lf[189]);
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
/* rec3559 */
t7=t4;
f_19390(t7,t1,t6);}
else{
/* error */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[272],t2);}}}}}

/* k19654 in lp in sre->cset in k4469 */
static void C_ccall f_19656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19656,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19660,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19666,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t9,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_19666(t11,t6,t7);}

/* loop3640 in k19654 in lp in sre->cset in k4469 */
static void C_fcall f_19666(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19666,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19695,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* g36563657 */
t5=((C_word*)t0)[2];
f_19390(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k19693 in loop3640 in k19654 in lp in sre->cset in k4469 */
static void C_ccall f_19695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19695,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop36403653 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_19666(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop36403653 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_19666(t6,((C_word*)t0)[3],t5);}}

/* k19658 in k19654 in lp in sre->cset in k4469 */
static void C_ccall f_19660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5489(((C_word*)t0)[3],lf[268],((C_word*)t0)[2],t1);}

/* lp in lp in sre->cset in k4469 */
static void C_fcall f_13742(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_13742,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13765,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13769,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_i_car(t2);
/* string->list */
t8=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* lp2103 */
t12=t1;
t13=t5;
t14=t7;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}}

/* k13767 in lp in lp in sre->cset in k4469 */
static void C_ccall f_13769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k13763 in lp in lp in sre->cset in k4469 */
static void C_ccall f_13765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2103 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_13742(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k19637 in lp in sre->cset in k4469 */
static void C_ccall f_19639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19639,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19301,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_19301(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* lp in k19637 in lp in sre->cset in k4469 */
static void C_fcall f_19301(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19301,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_cddr(t2);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_i_cadr(t2);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* lp3537 */
t10=t1;
t11=t4;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k19627 in lp in sre->cset in k4469 */
static void C_ccall f_19629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* cset-case-insensitive */
t2=lf[112];
f_20344(3,t2,((C_word*)t0)[2],t1);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k19571 in lp in sre->cset in k4469 */
static void C_ccall f_19573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19573,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19577,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19583,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t9,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_19583(t11,t6,t7);}

/* loop3616 in k19571 in lp in sre->cset in k4469 */
static void C_fcall f_19583(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19583,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19612,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* g36323633 */
t5=((C_word*)t0)[2];
f_19390(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k19610 in loop3616 in k19571 in lp in sre->cset in k4469 */
static void C_ccall f_19612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19612,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop36163629 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_19583(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop36163629 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_19583(t6,((C_word*)t0)[3],t5);}}

/* k19575 in k19571 in lp in sre->cset in k4469 */
static void C_ccall f_19577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5489(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a19564 in lp in sre->cset in k4469 */
static void C_ccall f_19565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_19565,4,t0,t1,t2,t3);}
/* cset-difference */
f_20085(t1,t3,t2);}

/* k19505 in lp in sre->cset in k4469 */
static void C_ccall f_19507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19507,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19511,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19517,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t9,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_19517(t11,t6,t7);}

/* loop3591 in k19505 in lp in sre->cset in k4469 */
static void C_fcall f_19517(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19517,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19546,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* g36073608 */
t5=((C_word*)t0)[2];
f_19390(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k19544 in loop3591 in k19505 in lp in sre->cset in k4469 */
static void C_ccall f_19546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19546,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop35913604 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_19517(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop35913604 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_19517(t6,((C_word*)t0)[3],t5);}}

/* k19509 in k19505 in lp in sre->cset in k4469 */
static void C_ccall f_19511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5489(((C_word*)t0)[3],lf[269],((C_word*)t0)[2],t1);}

/* k19445 in lp in sre->cset in k4469 */
static void C_ccall f_19447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19447,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19451,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_19457,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t9,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_19457(t11,t6,t7);}

/* loop3568 in k19445 in lp in sre->cset in k4469 */
static void C_fcall f_19457(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19457,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_19486,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* g35843585 */
t5=((C_word*)t0)[2];
f_19390(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k19484 in loop3568 in k19445 in lp in sre->cset in k4469 */
static void C_ccall f_19486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19486,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop35683581 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_19457(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop35683581 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_19457(t6,((C_word*)t0)[3],t5);}}

/* k19449 in k19445 in lp in sre->cset in k4469 */
static void C_ccall f_19451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5489(((C_word*)t0)[3],lf[268],((C_word*)t0)[2],t1);}

/* k19441 in lp in sre->cset in k4469 */
static void C_ccall f_19443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-complement */
f_20334(((C_word*)t0)[2],t1);}

/* k19414 in lp in sre->cset in k4469 */
static void C_ccall f_19416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-case-insensitive */
t2=lf[112];
f_20344(3,t2,((C_word*)t0)[2],t1);}

/* rec in lp in sre->cset in k4469 */
static void C_fcall f_19390(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19390,NULL,3,t0,t1,t2);}
/* lp3550 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_19387(t3,t1,t2,((C_word*)t0)[2]);}

/* sre-cset->procedure in k4469 */
static void C_fcall f_19260(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_19260,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19262,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_19262 in sre-cset->procedure in k4469 */
static void C_ccall f_19262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_19262,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19269,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
t8=t3;
if(C_truep((C_word)C_fixnum_lessp(t8,t7))){
t9=(C_word)C_subchar(t2,t3);
/* cset-contains? */
f_19798(t6,((C_word*)t0)[2],t9);}
else{
t9=t6;
f_19269(2,t9,C_SCHEME_FALSE);}}

/* k19267 */
static void C_ccall f_19269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* next3528 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3532 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* insert-sorted in k4469 */
static void C_fcall f_16862(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_16862,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
t4=(C_word)C_u_i_car(t3);
t5=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,t4))){
t6=(C_word)C_u_i_car(t3);
t7=t2;
t8=(C_word)C_eqp(t7,t6);
if(C_truep(t8)){
t9=t3;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,t2,t3));}}
else{
t6=(C_word)C_u_i_car(t3);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16902,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t3,C_fix(1));
/* insert-sorted */
t14=t7;
t15=t2;
t16=t8;
t1=t14;
t2=t15;
t3=t16;
goto loop;}}}

/* k16900 in insert-sorted in k4469 */
static void C_ccall f_16902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16902,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* nfa-closure in k4469 */
static void C_fcall f_16746(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16746,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16752,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_16752(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in nfa-closure in k4469 */
static void C_fcall f_16752(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(21);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_16752,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_u_i_memq(t4,t3))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lp2947 */
t19=t1;
t20=t5;
t21=t3;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16779,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16791,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16799,a[2]=t10,a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16836,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_u_i_car(t2);
t14=(C_word)C_u_i_assq(t13,((C_word*)t0)[2]);
t15=(C_word)C_slot(t14,C_fix(1));
/* filter */
f_5519(t11,t12,t15);}}}

/* a16835 in lp in nfa-closure in k4469 */
static void C_ccall f_16836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_16836,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[69],t3));}

/* k16797 in lp in nfa-closure in k4469 */
static void C_ccall f_16799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16799,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16801,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_16801(t5,((C_word*)t0)[2],t1);}

/* loop2958 in k16797 in lp in nfa-closure in k4469 */
static void C_fcall f_16801(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16801,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[261]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16830,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g29742975 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k16828 in loop2958 in k16797 in lp in nfa-closure in k4469 */
static void C_ccall f_16830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16830,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop29582971 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_16801(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop29582971 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_16801(t6,((C_word*)t0)[3],t5);}}

/* k16789 in lp in nfa-closure in k4469 */
static void C_ccall f_16791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k16777 in lp in nfa-closure in k4469 */
static void C_ccall f_16779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16783,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* insert-sorted */
f_16862(t2,t3,((C_word*)t0)[2]);}

/* k16781 in k16777 in lp in nfa-closure in k4469 */
static void C_ccall f_16783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2947 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_16752(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* intersect-char-ranges in k4469 */
static void C_fcall f_16630(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_16630,NULL,3,t1,t2,t3);}
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_fixnum_greaterp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16644,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* intersect-char-ranges */
t16=t6;
t17=t3;
t18=t2;
t1=t16;
t2=t17;
t3=t18;
goto loop;}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16663,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t6,t8))){
t11=(C_word)C_fix((C_word)C_character_code(t8));
t12=(C_word)C_u_fixnum_difference(t11,C_fix(1));
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=t10;
f_16663(t14,(C_truep((C_word)C_i_eqvp(t6,t13))?t6:(C_word)C_a_i_cons(&a,2,t6,t13)));}
else{
t11=t10;
f_16663(t11,C_SCHEME_FALSE);}}}

/* k16661 in intersect-char-ranges in k4469 */
static void C_fcall f_16663(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16663,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16667,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],((C_word*)t0)[5]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t4=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=t2;
f_16667(t6,(C_truep((C_word)C_i_eqvp(t5,((C_word*)t0)[4]))?t5:(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[4])));}
else{
t3=t2;
f_16667(t3,C_SCHEME_FALSE);}}

/* k16665 in k16661 in intersect-char-ranges in k4469 */
static void C_fcall f_16667(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16667,NULL,2,t0,t1);}
t2=(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[6],((C_word*)t0)[5]))?(C_truep((C_word)C_i_eqvp(((C_word*)t0)[4],((C_word*)t0)[6]))?((C_word*)t0)[4]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[6])):(C_truep((C_word)C_i_eqvp(((C_word*)t0)[4],((C_word*)t0)[5]))?((C_word*)t0)[4]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[5])));
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],((C_word*)t0)[5]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t4=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
if(C_truep((C_word)C_i_eqvp(t5,((C_word*)t0)[6]))){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,5,((C_word*)t0)[2],t1,t2,C_SCHEME_FALSE,t5));}
else{
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[6]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,5,((C_word*)t0)[2],t1,t2,C_SCHEME_FALSE,t6));}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,5,((C_word*)t0)[2],t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE));}}

/* k16642 in intersect-char-ranges in k4469 */
static void C_ccall f_16644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* reverse */
t2=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* split-char-range in k4469 */
static void C_fcall f_16556(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16556,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16564,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_eqvp(t3,t5))){
t6=t4;
f_16564(t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_fix((C_word)C_character_code(t3));
t8=(C_word)C_u_fixnum_difference(t7,C_fix(1));
t9=(C_word)C_make_character((C_word)C_unfix(t8));
t10=t4;
f_16564(t10,(C_truep((C_word)C_i_eqvp(t6,t9))?t6:(C_word)C_a_i_cons(&a,2,t6,t9)));}}

/* k16562 in split-char-range in k4469 */
static void C_fcall f_16564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16564,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[3],t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t1,C_SCHEME_FALSE));}
else{
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[3]));
t4=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_eqvp(t5,t6))){
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,2,t1,t5));}
else{
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,2,t1,t7));}}}

/* nfa-join-transitions! in k4469 */
static void C_fcall f_16082(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16082,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16085,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_car(t3);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16113,a[2]=t8,a[3]=t2,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_16113(t10,t1,t2,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_u_i_caar(t3);
t7=(C_word)C_u_i_cdar(t3);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16291,a[2]=t6,a[3]=t7,a[4]=t9,a[5]=t4,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_16291(t11,t1,t2,C_SCHEME_END_OF_LIST);}}

/* lp in nfa-join-transitions! in k4469 */
static void C_fcall f_16291(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16291,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t6=(C_word)C_a_i_list(&a,2,t4,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[6]));}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_16319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t6))){
t7=(C_word)C_u_i_caar(t2);
t8=t4;
f_16319(t8,(C_word)C_fixnum_less_or_equal_p(t7,((C_word*)t0)[3]));}
else{
t7=t4;
f_16319(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_16319(t6,C_SCHEME_FALSE);}}}

/* k16317 in lp in nfa-join-transitions! in k4469 */
static void C_fcall f_16319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16319,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16324,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16363,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[9]);
t5=(C_word)C_u_i_caar(((C_word*)t0)[10]);
/* split-char-range */
f_16556(t3,t4,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16377,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_caar(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caaar(((C_word*)t0)[10]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t5,((C_word*)t0)[3]))){
t6=(C_word)C_u_i_cdaar(((C_word*)t0)[10]);
t7=t4;
f_16476(t7,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t6));}
else{
t6=t4;
f_16476(t6,C_SCHEME_FALSE);}}
else{
t4=t2;
f_16377(t4,C_SCHEME_FALSE);}}}

/* k16474 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_fcall f_16476(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[5];
f_16377(t3,t2);}
else{
t2=(C_word)C_u_i_caaar(((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[3],t2))){
t3=(C_word)C_u_i_cdaar(((C_word*)t0)[4]);
t4=((C_word*)t0)[5];
f_16377(t4,(C_word)C_fixnum_less_or_equal_p(t3,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[5];
f_16377(t3,C_SCHEME_FALSE);}}}

/* k16375 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_fcall f_16377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16377,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16382,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16447,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_u_i_caar(((C_word*)t0)[8]);
/* intersect-char-ranges */
f_16630(t3,t4,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* lp2881 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_16291(t5,((C_word*)t0)[4],t2,t4);}}

/* k16445 in k16375 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a16381 in k16375 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_16382,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t8=(C_word)C_u_i_car(((C_word*)t0)[5]);
t9=(C_word)C_i_setslot(t8,C_fix(0),t4);
t10=(C_word)C_u_i_car(((C_word*)t0)[5]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_16435,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t7,a[5]=t6,a[6]=t2,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=t10,tmp=(C_word)a,a+=12,tmp);
t12=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* insert-sorted */
f_16862(t11,t12,t7);}

/* k16433 in a16381 in k16375 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16435,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[11],C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16395,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t5=t3;
f_16395(t5,(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_16395(t4,((C_word*)t0)[2]);}}

/* k16393 in k16433 in a16381 in k16375 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_fcall f_16395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16395,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16398,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t2;
f_16398(t4,(C_word)C_a_i_cons(&a,2,t3,t1));}
else{
t3=t2;
f_16398(t3,t1);}}

/* k16396 in k16393 in k16433 in a16381 in k16375 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_fcall f_16398(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16398,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* join2857 */
f_16085(t2,t1,((C_word*)t0)[2],t3);}

/* k16403 in k16396 in k16393 in k16433 in a16381 in k16375 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* join2857 */
f_16085(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* k16361 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a16323 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16324(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_16324,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16351,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t7=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
/* insert-sorted */
f_16862(t5,t6,t7);}

/* k16349 in a16323 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16351,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[8],C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16335,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* join2857 */
f_16085(t3,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k16333 in k16349 in a16323 in k16317 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* join2857 */
f_16085(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* lp in nfa-join-transitions! in k4469 */
static void C_fcall f_16113(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16113,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]));}
else{
t4=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[4],t4))){
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_16148,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t8=(C_word)C_u_i_cdar(t2);
/* insert-sorted */
f_16862(t6,t7,t8);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16162,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_u_i_caaar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t7,((C_word*)t0)[4]))){
t8=(C_word)C_u_i_cdaar(t2);
t9=t5;
f_16162(t9,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[4],t8));}
else{
t8=t5;
f_16162(t8,C_SCHEME_FALSE);}}
else{
t7=t5;
f_16162(t7,C_SCHEME_FALSE);}}}}

/* k16160 in lp in nfa-join-transitions! in k4469 */
static void C_fcall f_16162(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16162,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16167,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16229,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* split-char-range */
f_16556(t3,t4,t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
/* lp2862 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_16113(t5,((C_word*)t0)[3],t2,t4);}}

/* k16227 in k16160 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a16166 in k16160 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_16167,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_16217,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t6=(C_word)C_u_i_cdar(((C_word*)t0)[4]);
/* insert-sorted */
f_16862(t4,t5,t6);}

/* k16215 in a16166 in k16160 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16217,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16179,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16183,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_u_i_cdar(((C_word*)t0)[4]);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t5);
t7=t4;
f_16183(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t4;
f_16183(t5,C_SCHEME_END_OF_LIST);}}

/* k16181 in k16215 in a16166 in k16160 in lp in nfa-join-transitions! in k4469 */
static void C_fcall f_16183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16183,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(C_word)C_u_i_cdar(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* append */
t6=*((C_word*)lf[111]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,((C_word*)t0)[3],t1,t4,((C_word*)t0)[2],t5);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* append */
t3=*((C_word*)lf[111]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],t1,C_SCHEME_END_OF_LIST,((C_word*)t0)[2],t2);}}

/* k16177 in k16215 in a16166 in k16160 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16179,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k16146 in lp in nfa-join-transitions! in k4469 */
static void C_ccall f_16148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* join in nfa-join-transitions! in k4469 */
static void C_fcall f_16085(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16085,NULL,4,t1,t2,t3,t4);}
t5=t3;
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,t3,t4);
/* nfa-join-transitions! */
f_16082(t1,t2,t6);}
else{
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* nfa->dfa in k4469 */
static void C_fcall f_15564(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15564,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_car(t3):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15714,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_caar(t2);
t8=(C_word)C_a_i_list(&a,1,t7);
/* nfa-closure */
f_16746(t6,t2,t8);}

/* k15712 in nfa->dfa in k4469 */
static void C_ccall f_15714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15714,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15577,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_15577(t6,((C_word*)t0)[2],t2,C_fix(0),C_SCHEME_END_OF_LIST);}

/* lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_15577(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15577,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15591,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_assoc(t5,t4))){
t6=(C_word)C_slot(t2,C_fix(1));
/* lp2654 */
t15=t1;
t16=t6;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15610,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=t6,tmp=(C_word)a,a+=9,tmp);
t8=((C_word*)t0)[2];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15959,a[2]=t10,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_15959(t12,t7,C_SCHEME_END_OF_LIST,t6,C_SCHEME_END_OF_LIST);}}}

/* lp in lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_15959(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15959,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15977,a[2]=t6,a[3]=t10,a[4]=t8,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_15977(t12,t1,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_u_i_assq(t5,((C_word*)t0)[3]);
t7=(C_truep(t6)?(C_word)C_slot(t6,C_fix(1)):C_SCHEME_END_OF_LIST);
t8=(C_word)C_slot(t3,C_fix(1));
/* lp2812 */
t23=t1;
t24=t7;
t25=t8;
t26=t4;
t1=t23;
t2=t24;
t3=t25;
t4=t26;
goto loop;}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_eqp(lf[69],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(1));
/* lp2812 */
t23=t1;
t24=t7;
t25=t3;
t26=t4;
t1=t23;
t2=t24;
t3=t25;
t4=t26;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_16072,a[2]=t3,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_u_i_car(t2);
/* nfa-join-transitions! */
f_16082(t8,t4,t9);}}}

/* k16070 in lp in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_16072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2812 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_15959(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop2824 in lp in lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_15977(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15977,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16004,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16023,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g28402841 */
t6=t3;
f_16004(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k16021 in loop2824 in lp in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_16023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16023,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop28242837 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_15977(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop28242837 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_15977(t6,((C_word*)t0)[3],t5);}}

/* g2840 in loop2824 in lp in lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_16004(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16004,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16016,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* nfa-closure */
f_16746(t4,((C_word*)t0)[2],t5);}

/* k16014 in g2840 in loop2824 in lp in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_16016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16016,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k15608 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15610,2,t0,t1);}
t2=(C_word)C_u_i_memq(C_fix(0),((C_word*)t0)[8]);
t3=(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t4=(C_word)C_i_not(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_15622,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t4)){
t6=t5;
f_15622(t6,t4);}
else{
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t7=t5;
f_15622(t7,(C_word)C_fixnum_lessp(t6,((C_word*)t0)[7]));}}

/* k15620 in k15608 in lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_15622(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15622,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15657,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15663,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_15663(t11,t7,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2679 in k15620 in k15608 in lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_15663(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15663,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[261]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15692,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g26952696 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k15690 in loop2679 in k15620 in k15608 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15692,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop26792692 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_15663(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop26792692 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_15663(t6,((C_word*)t0)[3],t5);}}

/* k15655 in k15620 in k15608 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k15627 in k15620 in k15608 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15629,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_15653,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t4=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k15651 in k15627 in k15620 in k15608 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15653,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k15643 in k15651 in k15627 in k15620 in k15608 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15645,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
/* lp2654 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_15577(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15591,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15734,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15859,a[2]=t1,a[3]=t7,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15918,a[2]=t9,a[3]=t14,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t16=((C_word*)t14)[1];
f_15918(t16,t12,t1);}

/* loop2737 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_15918(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15918,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[260]+1);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop27372750 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop27372750 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k15857 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15863,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
/* zero-to */
f_5223(t2,t3);}

/* k15861 in k15857 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15863,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15865,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_15865(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop2710 in k15861 in k15857 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_15865(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15865,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[206]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15898,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* g27302731 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k15896 in loop2710 in k15861 in k15857 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15898,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_15878(t4,(C_word)C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_15878(t5,t4);}}

/* k15876 in k15896 in loop2710 in k15861 in k15857 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_15878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* loop27102724 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_15865(t5,((C_word*)t0)[2],t3,t4);}

/* k15732 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15736,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15751,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15753,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_15753(t11,t7,((C_word*)t0)[2]);}

/* loop2762 in k15732 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_15753(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15753,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15780,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15851,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g27782779 */
t6=t3;
f_15780(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k15849 in loop2762 in k15732 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15851,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop27622775 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_15753(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop27622775 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_15753(t6,((C_word*)t0)[3],t5);}}

/* g2778 in loop2762 in k15732 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_15780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15780,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15792,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_u_i_cddr(t2);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15798,a[2]=t5,a[3]=t11,a[4]=t7,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_15798(t13,t8,t9);}

/* loop2783 in g2778 in loop2762 in k15732 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_fcall f_15798(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_15798,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_15825,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_15825(C_a_i(&a,3),t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop27832796 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop27832796 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g2799 in loop2783 in g2778 in loop2762 in k15732 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static C_word C_fcall f_15825(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_slot(t1,C_fix(1));
t4=f_15736(((C_word*)t0)[2],t3);
return((C_word)C_a_i_cons(&a,2,t2,t4));}

/* k15790 in g2778 in loop2762 in k15732 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15792,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k15749 in k15732 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static void C_ccall f_15751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->vector */
t2=*((C_word*)lf[259]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* renumber in k15732 in k15589 in lp in k15712 in nfa->dfa in k4469 */
static C_word C_fcall f_15736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_assoc(t1,((C_word*)t0)[2]);
return((C_word)C_slot(t2,C_fix(1)));}

/* sre->nfa in k4469 */
static void C_fcall f_14706(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14706,NULL,3,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_u_i_car(t3):C_fix(0));
t7=(C_word)C_a_i_list(&a,1,C_fix(0));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14724,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t10)[1];
f_14724(t12,t1,t4,C_fix(1),t6,t8);}

/* lp in sre->nfa in k4469 */
static void C_fcall f_14724(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_14724,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14727,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14741,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t12=t5;
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t12))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14823,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14827,a[2]=t13,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_u_i_car(t2);
/* string->list */
t16=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t14,t15);}
else{
t13=(C_word)C_u_i_car(t2);
t14=(C_word)C_eqp(lf[69],t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14848,a[2]=t1,a[3]=t9,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_slot(t2,C_fix(1));
/* lp2454 */
t49=t15;
t50=t16;
t51=t3;
t52=t4;
t53=t5;
t1=t49;
t2=t50;
t3=t51;
t4=t52;
t5=t53;
goto loop;}
else{
t15=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t15))){
t16=(C_word)C_u_i_car(t2);
t17=(C_word)C_u_i_char_upper_casep(t16);
t18=(C_truep(t17)?(C_word)C_u_i_char_downcase(t16):(C_word)C_u_i_char_upcase(t16));
t19=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_14871,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t18,a[7]=t1,a[8]=t9,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t20=t4;
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f25581,a[2]=t19,a[3]=t18,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* bit-and */
f_5678(t21,t20,C_fix(2));}
else{
t16=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t16))){
t17=(C_word)C_u_i_car(t2);
t18=(C_word)C_u_i_assq(t17,lf[189]);
if(C_truep(t18)){
t19=(C_word)C_slot(t18,C_fix(1));
t20=(C_word)C_slot(t2,C_fix(1));
t21=(C_word)C_a_i_cons(&a,2,t19,t20);
/* lp2454 */
t49=t1;
t50=t21;
t51=t3;
t52=t4;
t53=t5;
t1=t49;
t2=t50;
t3=t51;
t4=t52;
t5=t53;
goto loop;}
else{
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_i_stringp(t18))){
t19=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14981,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t20=(C_word)C_u_i_caar(t2);
/* string->list */
t21=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t21+1)))(3,t21,t19,t20);}
else{
t19=(C_word)C_u_i_caar(t2);
t20=(C_word)C_eqp(t19,lf[68]);
t21=(C_truep(t20)?t20:(C_word)C_eqp(t19,lf[170]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15004,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_u_i_cdar(t2);
t24=(C_word)C_slot(t2,C_fix(1));
/* append */
t25=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t22,t23,t24);}
else{
t22=(C_word)C_eqp(t19,lf[168]);
t23=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_15021,a[2]=t9,a[3]=t19,a[4]=t5,a[5]=t3,a[6]=t4,a[7]=t7,a[8]=t1,a[9]=((C_word*)t0)[2],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t22)){
t24=t23;
f_15021(t24,t22);}
else{
t24=(C_word)C_eqp(t19,lf[169]);
if(C_truep(t24)){
t25=t23;
f_15021(t25,t24);}
else{
t25=(C_word)C_eqp(t19,lf[104]);
t26=t23;
f_15021(t26,(C_truep(t25)?t25:(C_word)C_eqp(t19,lf[105])));}}}}}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}}}}}}

/* k15019 in lp in sre->nfa in k4469 */
static void C_fcall f_15021(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15021,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15024,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
/* lp2454 */
t4=((C_word*)((C_word*)t0)[9])[1];
f_14724(t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[25]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_15075,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[2],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_15075(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[188]);
if(C_truep(t4)){
t5=t3;
f_15075(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[3],lf[177]);
t6=t3;
f_15075(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[3],lf[110])));}}}}

/* k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_fcall f_15075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15075,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_15078,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[8]);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f25590,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* bit-and */
f_5678(t5,t4,C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[57]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15206,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2454 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_14724(t5,t3,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[81]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2454 */
t6=((C_word*)((C_word*)t0)[7])[1];
f_14724(t6,t4,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[79]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[2],lf[77]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* lp2454 */
t8=((C_word*)((C_word*)t0)[7])[1];
f_14724(t8,t6,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[2],lf[62]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[2],lf[71]));
if(C_truep(t7)){
t8=(C_word)C_u_i_cdar(((C_word*)t0)[8]);
t9=f_13598(C_a_i(&a,3),t8);
t10=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
/* lp2454 */
t12=((C_word*)((C_word*)t0)[7])[1];
f_14724(t12,((C_word*)t0)[9],t11,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t8=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}

/* k15367 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15369,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15457,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* new-state-number2459 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_14727(t4,t3,t1);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15455 in k15367 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2454 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_14724(t2,((C_word*)t0)[4],lf[258],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15373 in k15367 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15378,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15453,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2459 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_14727(t5,t4,t1);}

/* k15451 in k15373 in k15367 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2454 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14724(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15376 in k15373 in k15367 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15378,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15384,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_caar(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[77],t3);
if(C_truep(t4)){
t5=(C_word)C_u_i_car(t1);
t6=(C_word)C_u_i_caar(((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,lf[69],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15433,a[2]=t5,a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_u_i_cdar(t1);
/* ##sys#append */
t10=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,C_SCHEME_END_OF_LIST);}
else{
t5=t2;
f_15384(t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15431 in k15376 in k15373 in k15367 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15433,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_15384(t3,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}

/* k15382 in k15376 in k15373 in k15367 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_fcall f_15384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15384,NULL,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[69],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_cdar(((C_word*)t0)[4]);
/* ##sys#append */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k15401 in k15382 in k15376 in k15373 in k15367 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15403,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t2);
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k15307 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15309,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15315,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15353,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2459 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_14727(t5,t4,t1);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15351 in k15307 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2454 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14724(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15313 in k15307 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15315,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_caar(((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[69],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15337,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_cdar(t1);
/* ##sys#append */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15335 in k15313 in k15307 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15337,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}

/* k15204 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_15209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_cddar(((C_word*)t0)[4]);
t4=f_13623(C_a_i(&a,3),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15288,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2459 */
t7=((C_word*)((C_word*)t0)[5])[1];
f_14727(t7,t6,t1);}
else{
t3=t2;
f_15209(2,t3,C_SCHEME_FALSE);}}

/* k15286 in k15204 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2454 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14724(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15207 in k15204 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15212,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_cadar(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15273,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2459 */
t6=((C_word*)((C_word*)t0)[5])[1];
f_14727(t6,t5,t1);}
else{
t3=t2;
f_15212(2,t3,C_SCHEME_FALSE);}}

/* k15271 in k15207 in k15204 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2454 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14724(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15210 in k15207 in k15204 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15212,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_15238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* new-state-number2459 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14727(t3,t2,t1);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15236 in k15210 in k15207 in k15204 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15238,2,t0,t1);}
t2=(C_word)C_u_i_caar(((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,lf[69],t2);
t4=(C_word)C_u_i_caar(((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,lf[69],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t3,t6);
t8=(C_word)C_a_i_cons(&a,2,t1,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15226,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15230,a[2]=((C_word*)t0)[4],a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* take-up-to */
f_5262(t10,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k15228 in k15236 in k15210 in k15207 in k15204 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_15234,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k15232 in k15228 in k15236 in k15210 in k15207 in k15204 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k15224 in k15236 in k15210 in k15207 in k15204 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15226,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f25590 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f25590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25590,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(2),t1);
/* sre->cset */
f_19377(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t2));}

/* k15076 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15078,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(t2,C_fix(1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15094,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp2454 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_14724(t6,t4,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15105,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp2454 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_14724(t6,t4,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k15103 in k15076 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15105,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15131,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_15133,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_15133(t10,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2566 in k15103 in k15076 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_fcall f_15133(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_15133,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15143,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_slot(t4,C_fix(1));
t7=(C_word)C_a_i_list(&a,3,lf[25],t5,t6);
t8=t3;
f_15143(t8,(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST));}
else{
t5=t3;
f_15143(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k15141 in loop2566 in k15103 in k15076 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_fcall f_15143(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop25662579 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_15133(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop25662579 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_15133(t5,((C_word*)t0)[3],t4);}}

/* k15129 in k15103 in k15076 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15131,2,t0,t1);}
t2=f_13623(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15119,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2459 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_14727(t5,t4,((C_word*)t0)[4]);}

/* k15117 in k15129 in k15103 in k15076 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15123,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
/* bit-and */
f_5678(t2,t3,C_fix(65533));}

/* k15121 in k15117 in k15129 in k15103 in k15076 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2454 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14724(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k15092 in k15076 in k15073 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15094,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2460 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_14741(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k15022 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15024,2,t0,t1);}
t2=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t3=(C_word)C_u_i_memq(t2,lf[257]);
t4=(C_truep(t3)?lf[43]:lf[42]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_u_i_caar(((C_word*)t0)[6]);
if(C_truep((C_truep((C_word)C_eqp(t6,lf[168]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[169]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* g25362537 */
t7=t4;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],C_fix(2));}
else{
/* g25362537 */
t7=t4;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],C_fix(32));}}

/* k15028 in k15022 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_15030,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_word)C_u_i_cdar(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_15044,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* new-state-number2459 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_14727(t4,t3,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k15042 in k15028 in k15022 in k15019 in lp in sre->nfa in k4469 */
static void C_ccall f_15044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2454 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14724(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k15002 in lp in sre->nfa in k4469 */
static void C_ccall f_15004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2454 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14724(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14979 in lp in sre->nfa in k4469 */
static void C_ccall f_14981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14981,2,t0,t1);}
t2=f_13623(C_a_i(&a,3),t1);
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
/* lp2454 */
t5=((C_word*)((C_word*)t0)[6])[1];
f_14724(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f25581 in lp in sre->nfa in k4469 */
static void C_ccall f25581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(C_fix(2),t1);
if(C_truep(t2)){
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
t4=(C_word)C_i_eqvp(t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
f_14871(t5,(C_word)C_i_not(t4));}
else{
t3=((C_word*)t0)[2];
f_14871(t3,C_SCHEME_FALSE);}}

/* k14869 in lp in sre->nfa in k4469 */
static void C_fcall f_14871(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14871,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14878,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
/* lp2454 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_14724(t4,t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14893,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
/* lp2454 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_14724(t4,t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k14891 in k14869 in lp in sre->nfa in k4469 */
static void C_ccall f_14893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14893,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2460 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_14741(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k14876 in k14869 in lp in sre->nfa in k4469 */
static void C_ccall f_14878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14878,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
/* extend-state2460 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_14741(t3,((C_word*)t0)[3],t1,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* k14846 in lp in sre->nfa in k4469 */
static void C_ccall f_14848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14848,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* extend-state2460 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_14741(t3,((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,1,t2));}

/* k14825 in lp in sre->nfa in k4469 */
static void C_ccall f_14827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* append */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k14821 in lp in sre->nfa in k4469 */
static void C_ccall f_14823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2454 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_14724(t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* extend-state in lp in sre->nfa in k4469 */
static void C_fcall f_14741(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14741,NULL,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14756,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* new-state-number2459 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_14727(t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k14754 in extend-state in lp in sre->nfa in k4469 */
static void C_ccall f_14756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14756,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14762,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_14762(t10,t6,((C_word*)t0)[2]);}

/* loop2468 in k14754 in extend-state in lp in sre->nfa in k4469 */
static void C_fcall f_14762(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_14762,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14789,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_14789(C_a_i(&a,3),t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop24682481 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop24682481 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g2484 in loop2468 in k14754 in extend-state in lp in sre->nfa in k4469 */
static C_word C_fcall f_14789(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_u_i_caar(((C_word*)t0)[2]);
return((C_word)C_a_i_cons(&a,2,t1,t2));}

/* k14758 in k14754 in extend-state in lp in sre->nfa in k4469 */
static void C_ccall f_14760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14760,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]));}

/* new-state-number in lp in sre->nfa in k4469 */
static void C_fcall f_14727(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14727,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_caar(t2);
t4=(C_word)C_u_fixnum_plus(C_fix(1),t3);
/* max */
t5=*((C_word*)lf[195]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}

/* dfa-match/longest in k4469 */
static void C_fcall f_14599(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14599,NULL,5,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(0));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(0));
t10=(C_word)C_u_i_car(t9);
t11=(C_truep(t10)?t4:C_SCHEME_FALSE);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14613,a[2]=t13,a[3]=t2,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_14613(t15,t1,t4,t7,t11);}

/* lp in dfa-match/longest in k4469 */
static void C_fcall f_14613(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14613,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,t6))){
t7=t4;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(C_word)C_subchar(((C_word*)t0)[4],t2);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14651,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_slot(t3,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f27441,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* find-tail */
f_5317(t10,t8,t9);}}

/* f27441 in lp in dfa-match/longest in k4469 */
static void C_ccall f27441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_i_car(t1):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,t4);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
if(C_truep((C_word)C_u_i_car(t5))){
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* lp2426 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_14613(t8,((C_word*)t0)[3],t6,t5,t7);}
else{
t7=((C_word*)t0)[2];
/* lp2426 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_14613(t8,((C_word*)t0)[3],t6,t5,t7);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* a14650 in lp in dfa-match/longest in k4469 */
static void C_ccall f_14651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14651,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_eqvp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,((C_word*)t0)[2]))){
t7=(C_word)C_u_i_cdar(t2);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t7));}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* irregex-match in k4469 */
static void C_ccall f_14421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14421,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14425,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* irregex */
t5=*((C_word*)lf[163]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k14423 in irregex-match in k4469 */
static void C_ccall f_14425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14428,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* irregex-new-matches */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k14426 in k14423 in irregex-match in k4469 */
static void C_ccall f_14428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14428,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t3=t1;
t4=((C_word*)t0)[4];
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa */
t7=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}

/* k14438 in k14426 in k14423 in irregex-match in k4469 */
static void C_ccall f_14440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14440,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14465,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* irregex-dfa */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14468,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* irregex-nfa */
t3=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k14466 in k14438 in k14426 in k14423 in irregex-match in k4469 */
static void C_ccall f_14468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14471,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14485,tmp=(C_word)a,a+=2,tmp);
/* matcher2376 */
t4=t1;
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4],t3);}

/* a14484 in k14466 in k14438 in k14426 in k14423 in irregex-match in k4469 */
static void C_ccall f_14485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14485,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k14469 in k14466 in k14438 in k14426 in k14423 in irregex-match in k4469 */
static void C_ccall f_14471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
t3=(C_word)C_fixnum_shift_left(C_fix(0),C_fix(1));
t4=(C_word)C_u_fixnum_plus(C_fix(3),t3);
t5=(C_word)C_i_setslot(t2,t4,C_fix(0));
t6=((C_word*)t0)[3];
t7=t1;
t8=(C_word)C_fixnum_shift_left(C_fix(0),C_fix(1));
t9=(C_word)C_u_fixnum_plus(C_fix(4),t8);
t10=(C_word)C_i_setslot(t6,t9,t7);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14463 in k14438 in k14426 in k14423 in irregex-match in k4469 */
static void C_ccall f_14465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* dfa-match/longest */
f_14599(((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k14441 in k14438 in k14426 in k14423 in irregex-match in k4469 */
static void C_ccall f_14443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14443,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(t1,((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
t3=(C_word)C_fixnum_shift_left(C_fix(0),C_fix(1));
t4=(C_word)C_u_fixnum_plus(C_fix(3),t3);
t5=(C_word)C_i_setslot(t2,t4,C_fix(0));
t6=((C_word*)t0)[5];
t7=t1;
t8=(C_word)C_fixnum_shift_left(C_fix(0),C_fix(1));
t9=(C_word)C_u_fixnum_plus(C_fix(4),t8);
t10=(C_word)C_i_setslot(t6,t9,t7);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14458,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa/extract */
t12=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14456 in k14441 in k14438 in k14426 in k14423 in irregex-match in k4469 */
static void C_ccall f_14458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14461,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* g23702371 */
t3=t1;
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k14459 in k14456 in k14441 in k14438 in k14426 in k14423 in irregex-match in k4469 */
static void C_ccall f_14461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* irregex-search/matches in k4469 */
static void C_ccall f_14262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_14262,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14269,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* irregex-dfa */
t8=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k14267 in irregex-search/matches in k4469 */
static void C_ccall f_14269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14269,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* irregex-flags */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14385,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* irregex-nfa */
t3=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k14383 in k14267 in irregex-search/matches in k4469 */
static void C_ccall f_14385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14385,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14390,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_14390(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k14383 in k14267 in irregex-search/matches in k4469 */
static void C_fcall f_14390(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14390,NULL,3,t0,t1,t2);}
t3=t2;
t4=((C_word*)t0)[6];
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14400,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14418,tmp=(C_word)a,a+=2,tmp);
/* matcher2334 */
t7=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,((C_word*)t0)[2],t2,((C_word*)t0)[5],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* a14417 in lp in k14383 in k14267 in irregex-search/matches in k4469 */
static void C_ccall f_14418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14418,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k14398 in lp in k14383 in k14267 in irregex-search/matches in k4469 */
static void C_ccall f_14400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=(C_word)C_fixnum_shift_left(C_fix(0),C_fix(1));
t5=(C_word)C_u_fixnum_plus(C_fix(3),t4);
t6=(C_word)C_i_setslot(t2,t5,t3);
t7=((C_word*)t0)[5];
t8=t1;
t9=(C_word)C_fixnum_shift_left(C_fix(0),C_fix(1));
t10=(C_word)C_u_fixnum_plus(C_fix(4),t9);
t11=(C_word)C_i_setslot(t7,t10,t8);
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,((C_word*)t0)[5]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* lp2335 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14390(t3,((C_word*)t0)[3],t2);}}

/* k14380 in k14267 in irregex-search/matches in k4469 */
static void C_ccall f_14382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f25563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* bit-and */
f_5678(t2,t1,C_fix(1));}

/* f25563 in k14380 in k14267 in irregex-search/matches in k4469 */
static void C_ccall f25563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25563,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa */
t5=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14300,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14378,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* irregex-dfa/search */
t5=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}}

/* k14376 */
static void C_ccall f_14378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14378,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_slot(t1,C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14520,a[2]=t7,a[3]=t1,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_14520(t9,((C_word*)t0)[2],t3,t5);}

/* lp in k14376 */
static void C_fcall f_14520(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14520,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep((C_word)C_u_i_car(t4))){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,((C_word*)t0)[5]))){
t6=(C_word)C_subchar(((C_word*)t0)[4],t2);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14555,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t3,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f27431,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* find-tail */
f_5317(t9,t7,t8);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* f27431 in lp in k14376 */
static void C_ccall f27431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_i_car(t1):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[4];
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t4,t5);
/* lp2400 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_14520(t7,((C_word*)t0)[2],t3,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a14554 in lp in k14376 */
static void C_ccall f_14555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14555,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_eqvp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_caar(t2);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t6,((C_word*)t0)[2]))){
t7=(C_word)C_u_i_cdar(t2);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],t7));}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}

/* k14298 */
static void C_ccall f_14300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14300,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* irregex-lengths */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14372 in k14298 */
static void C_ccall f_14374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14374,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_slot(t2,C_fix(1)))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_fixnum_difference(((C_word*)t0)[8],t4);
/* max */
t6=*((C_word*)lf[195]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,((C_word*)t0)[2],t5);}
else{
t4=t3;
f_14309(2,t4,((C_word*)t0)[2]);}}

/* k14307 in k14372 in k14298 */
static void C_ccall f_14309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14309,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[8]);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14315,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* irregex-dfa */
t5=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* k14313 in k14307 in k14372 in k14298 */
static void C_ccall f_14315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14315,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14320,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_14320(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k14313 in k14307 in k14372 in k14298 */
static void C_fcall f_14320(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14320,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,((C_word*)t0)[8]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14330,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* dfa-match/longest */
f_14599(t4,((C_word*)t0)[3],((C_word*)t0)[6],t2,((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k14328 in lp in k14313 in k14307 in k14372 in k14298 */
static void C_ccall f_14330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14330,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
t4=(C_word)C_fixnum_shift_left(C_fix(0),C_fix(1));
t5=(C_word)C_u_fixnum_plus(C_fix(3),t4);
t6=(C_word)C_i_setslot(t2,t5,t3);
t7=((C_word*)t0)[7];
t8=t1;
t9=(C_word)C_fixnum_shift_left(C_fix(0),C_fix(1));
t10=(C_word)C_u_fixnum_plus(C_fix(4),t9);
t11=(C_word)C_i_setslot(t7,t10,t8);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14342,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa/extract */
t13=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* lp2317 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14320(t3,((C_word*)t0)[5],t2);}}

/* k14340 in k14328 in lp in k14313 in k14307 in k14372 in k14298 */
static void C_ccall f_14342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14345,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* g23282329 */
t3=t1;
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k14343 in k14340 in k14328 in lp in k14313 in k14307 in k14372 in k14298 */
static void C_ccall f_14345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k14295 */
static void C_ccall f_14297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* dfa-match/longest */
f_14599(((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k14276 */
static void C_ccall f_14278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14278,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=(C_word)C_fixnum_shift_left(C_fix(0),C_fix(1));
t5=(C_word)C_u_fixnum_plus(C_fix(3),t4);
t6=(C_word)C_i_setslot(t2,t5,t3);
t7=((C_word*)t0)[6];
t8=t1;
t9=(C_word)C_fixnum_shift_left(C_fix(0),C_fix(1));
t10=(C_word)C_u_fixnum_plus(C_fix(4),t9);
t11=(C_word)C_i_setslot(t7,t10,t8);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14290,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* irregex-dfa/extract */
t13=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14288 in k14276 */
static void C_ccall f_14290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14293,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* g23042305 */
t3=t1;
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k14291 in k14288 in k14276 */
static void C_ccall f_14293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* irregex-search in k4469 */
static void C_ccall f_14216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_14216r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_14216r(t0,t1,t2,t3,t4);}}

static void C_ccall f_14216r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14220,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* irregex */
t6=*((C_word*)lf[163]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k14218 in irregex-search in k4469 */
static void C_ccall f_14220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14220,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[4]):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14226,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_i_pairp(t5);
t7=t4;
f_14226(t7,(C_truep(t6)?(C_word)C_u_i_cadr(((C_word*)t0)[4]):(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]))));}
else{
t5=t4;
f_14226(t5,(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3])));}}

/* k14224 in k14218 in irregex-search in k4469 */
static void C_fcall f_14226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14226,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14229,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* irregex-new-matches */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k14227 in k14224 in k14218 in irregex-search in k4469 */
static void C_ccall f_14229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=t1;
t3=((C_word*)t0)[6];
t4=(C_word)C_i_setslot(t2,C_fix(1),t3);
/* irregex-search/matches */
t5=*((C_word*)lf[226]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sre-remove-initial-bos in k4469 */
static void C_ccall f_14064(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14064,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[68]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14083,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_14083(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[170]);
if(C_truep(t6)){
t7=t5;
f_14083(t7,t6);}
else{
t7=(C_word)C_eqp(t3,lf[62]);
if(C_truep(t7)){
t8=t5;
f_14083(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[77]);
t9=t5;
f_14083(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[79])));}}}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k14081 in sre-remove-initial-bos in k4469 */
static void C_fcall f_14083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14083,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_eqp(lf[136],t3);
if(C_truep(t4)){
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
t6=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,t5,t6));}
else{
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14121,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-remove-initial-bos */
t8=lf[215];
f_14064(3,t8,t6,t7);}}
else{
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[57]);
if(C_truep(t2)){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14154,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14160,a[2]=t4,a[3]=t10,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_14160(t12,t7,t8);}
else{
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}

/* loop2247 in k14081 in sre-remove-initial-bos in k4469 */
static void C_fcall f_14160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14160,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=lf[215];
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14189,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g22632264 */
t6=lf[215];
f_14064(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k14187 in loop2247 in k14081 in sre-remove-initial-bos in k4469 */
static void C_ccall f_14189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14189,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop22472260 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_14160(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop22472260 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_14160(t6,((C_word*)t0)[3],t5);}}

/* k14152 in k14081 in sre-remove-initial-bos in k4469 */
static void C_ccall f_14154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14154,2,t0,t1);}
/* sre-alternate */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13623(C_a_i(&a,3),t1));}

/* k14119 in k14081 in sre-remove-initial-bos in k4469 */
static void C_ccall f_14121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14121,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* sre-sequence-names in k4469 */
static void C_fcall f_14028(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14028,NULL,4,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t4;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14058,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_u_i_car(t2);
/* sre-count-submatches */
f_12503(t6,t7);}}

/* k14056 in sre-sequence-names in k4469 */
static void C_ccall f_14058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14058,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14050,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* sre-names */
f_13798(t3,t4,((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k14048 in k14056 in sre-sequence-names in k4469 */
static void C_ccall f_14050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-sequence-names */
f_14028(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sre-names in k4469 */
static void C_fcall f_13798(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_13798,NULL,4,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_eqp(t5,lf[62]);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(1));
t8=f_13598(C_a_i(&a,3),t7);
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* sre-names */
t39=t1;
t40=t8;
t41=t9;
t42=t4;
t1=t39;
t2=t40;
t3=t41;
t4=t42;
goto loop;}
else{
t7=(C_word)C_eqp(t5,lf[71]);
if(C_truep(t7)){
t8=(C_word)C_u_i_cddr(t2);
t9=f_13598(C_a_i(&a,3),t8);
t10=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t11=(C_word)C_u_i_cadr(t2);
t12=(C_word)C_a_i_cons(&a,2,t11,t3);
t13=(C_word)C_a_i_cons(&a,2,t12,t4);
/* sre-names */
t39=t1;
t40=t9;
t41=t10;
t42=t13;
t1=t39;
t2=t40;
t3=t41;
t4=t42;
goto loop;}
else{
t8=(C_word)C_eqp(t5,lf[186]);
if(C_truep(t8)){
t9=(C_word)C_u_i_cdddr(t2);
t10=f_13598(C_a_i(&a,3),t9);
t11=(C_word)C_u_i_cadr(t2);
t12=(C_word)C_u_fixnum_plus(t3,t11);
/* sre-names */
t39=t1;
t40=t10;
t41=t12;
t42=t4;
t1=t39;
t2=t40;
t3=t41;
t4=t42;
goto loop;}
else{
t9=(C_word)C_eqp(t5,lf[68]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13896,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_13896(t11,t9);}
else{
t11=(C_word)C_eqp(t5,lf[170]);
if(C_truep(t11)){
t12=t10;
f_13896(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[57]);
if(C_truep(t12)){
t13=t10;
f_13896(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[77]);
if(C_truep(t13)){
t14=t10;
f_13896(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[79]);
if(C_truep(t14)){
t15=t10;
f_13896(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[81]);
if(C_truep(t15)){
t16=t10;
f_13896(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[78]);
if(C_truep(t16)){
t17=t10;
f_13896(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[82]);
if(C_truep(t17)){
t18=t10;
f_13896(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[168]);
if(C_truep(t18)){
t19=t10;
f_13896(t19,t18);}
else{
t19=(C_word)C_eqp(t5,lf[169]);
if(C_truep(t19)){
t20=t10;
f_13896(t20,t19);}
else{
t20=(C_word)C_eqp(t5,lf[181]);
if(C_truep(t20)){
t21=t10;
f_13896(t21,t20);}
else{
t21=(C_word)C_eqp(t5,lf[64]);
if(C_truep(t21)){
t22=t10;
f_13896(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[66]);
if(C_truep(t22)){
t23=t10;
f_13896(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[65]);
t24=t10;
f_13896(t24,(C_truep(t23)?t23:(C_word)C_eqp(t5,lf[67])));}}}}}}}}}}}}}}}}}
else{
t5=t4;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k13894 in sre-names in k4469 */
static void C_fcall f_13896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* sre-sequence-names */
f_14028(((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[84]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[2],lf[85]));
if(C_truep(t3)){
t4=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
/* sre-sequence-names */
f_14028(((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[83]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[2],lf[80]));
if(C_truep(t5)){
t6=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
/* sre-sequence-names */
f_14028(((C_word*)t0)[5],t6,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}}

/* sre-strip-submatches in k4469 */
static void C_ccall f_13648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(11);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)tr3,(void*)f_13648,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[62]);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(1));
t6=f_13598(C_a_i(&a,3),t5);
/* sre-strip-submatches */
t19=t1;
t20=t6;
t1=t19;
t2=t20;
c=3;
goto loop;}
else{
t5=(C_word)C_eqp(t3,lf[186]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cdddr(t2);
t7=f_13598(C_a_i(&a,3),t6);
/* sre-strip-submatches */
t19=t1;
t20=t7;
t1=t19;
t2=t20;
c=3;
goto loop;}
else{
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13697,a[2]=t7,a[3]=t11,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_13697(t13,t1,t2);}}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop2080 in sre-strip-submatches in k4469 */
static void C_fcall f_13697(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13697,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=lf[173];
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13726,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g20962097 */
t6=lf[173];
f_13648(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k13724 in loop2080 in sre-strip-submatches in k4469 */
static void C_ccall f_13726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13726,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop20802093 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_13697(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop20802093 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_13697(t6,((C_word*)t0)[3],t5);}}

/* sre-alternate in k4469 */
static C_word C_fcall f_13623(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[69]);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_i_nullp(t2);
return((C_truep(t3)?(C_word)C_u_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[57],t1)));}}

/* sre-sequence in k4469 */
static C_word C_fcall f_13598(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[69]);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_i_nullp(t2);
return((C_truep(t3)?(C_word)C_u_i_car(t1):(C_word)C_a_i_cons(&a,2,lf[68],t1)));}}

/* sre-count-submatches in k4469 */
static void C_fcall f_12503(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12503,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12509,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_12509(4,t6,t1,t2,C_fix(0));}

/* count in sre-count-submatches in k4469 */
static void C_ccall f_12509(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12509,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_eqp(t4,lf[62]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,lf[71]));
if(C_truep(t6)){
t7=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t8=(C_word)C_slot(t2,C_fix(1));
/* fold */
f_5489(t1,((C_word*)((C_word*)t0)[2])[1],t7,t8);}
else{
t7=(C_word)C_eqp(t4,lf[186]);
if(C_truep(t7)){
t8=(C_word)C_u_i_cadr(t2);
t9=(C_word)C_u_i_caddr(t2);
t10=(C_word)C_u_fixnum_plus(t8,t9);
t11=(C_word)C_u_fixnum_plus(t3,t10);
t12=(C_word)C_slot(t2,C_fix(1));
/* fold */
f_5489(t1,((C_word*)((C_word*)t0)[2])[1],t11,t12);}
else{
t8=t3;
t9=(C_word)C_slot(t2,C_fix(1));
/* fold */
f_5489(t1,((C_word*)((C_word*)t0)[2])[1],t8,t9);}}}
else{
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* sre-has-submatchs? in k4469 */
static void C_ccall f_12477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12477,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(lf[62],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_slot(t2,C_fix(1));
/* any */
f_5391(t1,lf[212],t5);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* sre-consumer? in k4469 */
static void C_ccall f_12391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12391,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[77]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[79]));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=f_13598(C_a_i(&a,3),t6);
/* sre-any? */
t8=lf[222];
f_12173(3,t8,t1,t7);}
else{
t6=(C_word)C_eqp(t3,lf[68]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12430,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_12430(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[170]);
t9=t7;
f_12430(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[62])));}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[137],t2));}}

/* k12428 in sre-consumer? in k4469 */
static void C_fcall f_12430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12430,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12443,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* last */
f_5349(t3,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[57]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_5440(((C_word*)t0)[3],lf[194],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k12441 in k12428 in sre-consumer? in k4469 */
static void C_ccall f_12443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-consumer? */
t2=lf[194];
f_12391(3,t2,((C_word*)t0)[2],t1);}

/* sre-searcher? in k4469 */
static void C_ccall f_12305(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12305,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[77]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[79]));
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=f_13598(C_a_i(&a,3),t6);
/* sre-any? */
t8=lf[222];
f_12173(3,t8,t1,t7);}
else{
t6=(C_word)C_eqp(t3,lf[68]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12344,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_12344(t8,t6);}
else{
t8=(C_word)C_eqp(t3,lf[170]);
t9=t7;
f_12344(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[62])));}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[136],t2));}}

/* k12342 in sre-searcher? in k4469 */
static void C_fcall f_12344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-searcher? */
t4=lf[216];
f_12305(3,t4,((C_word*)t0)[3],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[57]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_5440(((C_word*)t0)[3],lf[216],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* sre-repeater? in k4469 */
static C_word C_fcall f_12249(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_memq(t2,lf[223]);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_u_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t4,lf[62]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[68]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[170]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t5=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_cddr(t1);
if(C_truep((C_word)C_i_nullp(t6))){
t7=(C_word)C_u_i_cadr(t1);
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}
else{
return(C_SCHEME_FALSE);}}

/* sre-any? in k4469 */
static void C_ccall f_12173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12173,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[74]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_eqp(t4,lf[68]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12198,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_12198(t7,t5);}
else{
t7=(C_word)C_eqp(t4,lf[170]);
t8=t6;
f_12198(t8,(C_truep(t7)?t7:(C_word)C_eqp(t4,lf[62])));}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k12196 in sre-any? in k4469 */
static void C_fcall f_12198(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* sre-any? */
t5=lf[222];
f_12173(3,t5,((C_word*)t0)[3],t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[57]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* every */
f_5440(((C_word*)t0)[3],lf[222],t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* sre-empty? in k4469 */
static void C_ccall f_12045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12045,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_eqp(t3,lf[77]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12064,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_12064(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[81]);
if(C_truep(t6)){
t7=t5;
f_12064(t7,t6);}
else{
t7=(C_word)C_eqp(t3,lf[64]);
if(C_truep(t7)){
t8=t5;
f_12064(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[66]);
if(C_truep(t8)){
t9=t5;
f_12064(t9,t8);}
else{
t9=(C_word)C_eqp(t3,lf[65]);
t10=t5;
f_12064(t10,(C_truep(t9)?t9:(C_word)C_eqp(t3,lf[67])));}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_memq(t2,lf[221]));}}

/* k12062 in sre-empty? in k4469 */
static void C_fcall f_12064(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12064,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[83]);
if(C_truep(t2)){
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t4=(C_word)C_i_numberp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_eqp(t6,C_fix(0)));}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],lf[57]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* any */
f_5391(((C_word*)t0)[4],lf[89],t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[3],lf[170]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12113,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_12113(t6,t4);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[3],lf[68]);
if(C_truep(t6)){
t7=t5;
f_12113(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],lf[62]);
if(C_truep(t7)){
t8=t5;
f_12113(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[3],lf[79]);
t9=t5;
f_12113(t9,(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[3],lf[181])));}}}}}}}

/* k12111 in k12062 in sre-empty? in k4469 */
static void C_fcall f_12113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* every */
f_5440(((C_word*)t0)[2],lf[89],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* sre->irregex in k4469 */
static void C_ccall f_11894(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_11894r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_11894r(t0,t1,t2,t3);}}

static void C_ccall f_11894r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11898,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* symbol-list->flags */
f_5763(t4,t3);}

/* k11896 in sre->irregex in k4469 */
static void C_ccall f_11898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11901,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=t1;
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f25540,a[2]=t4,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* bit-and */
f_5678(t5,t4,C_fix(32));}

/* f25540 in k11896 in sre->irregex in k4469 */
static void C_ccall f25540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25540,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(32),t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f25534,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* bit-and */
f_5678(t3,((C_word*)t0)[2],C_fix(2));}

/* f25534 */
static void C_ccall f25534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25534,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(2),t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11414,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11414(t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* adjust */
static void C_fcall f_11414(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11414,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11417,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[104]);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=f_13598(C_a_i(&a,3),t8);
/* adjust1382 */
t46=t1;
t47=t9;
t48=C_SCHEME_TRUE;
t49=t4;
t1=t46;
t2=t47;
t3=t48;
t4=t49;
goto loop;}
else{
t8=(C_word)C_eqp(t6,lf[105]);
if(C_truep(t8)){
t9=(C_word)C_slot(t2,C_fix(1));
t10=f_13598(C_a_i(&a,3),t9);
/* adjust1382 */
t46=t1;
t47=t10;
t48=C_SCHEME_FALSE;
t49=t4;
t1=t46;
t2=t47;
t3=t48;
t4=t49;
goto loop;}
else{
t9=(C_word)C_eqp(t6,lf[168]);
if(C_truep(t9)){
t10=(C_word)C_u_i_car(t2);
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11481,a[2]=t10,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_slot(t2,C_fix(1));
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11487,a[2]=t12,a[3]=t18,a[4]=t14,a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp));
t20=((C_word*)t18)[1];
f_11487(t20,t15,t16);}
else{
t10=(C_word)C_eqp(t6,lf[169]);
if(C_truep(t10)){
t11=(C_word)C_u_i_car(t2);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11542,a[2]=t11,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t17=(C_word)C_slot(t2,C_fix(1));
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11548,a[2]=t13,a[3]=t19,a[4]=t15,a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp));
t21=((C_word*)t19)[1];
f_11548(t21,t16,t17);}
else{
t11=(C_word)C_eqp(t6,lf[25]);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11595,a[2]=t5,a[3]=t6,a[4]=t2,a[5]=t1,a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t11)){
t13=t12;
f_11595(t13,t11);}
else{
t13=(C_word)C_eqp(t6,lf[110]);
if(C_truep(t13)){
t14=t12;
f_11595(t14,t13);}
else{
t14=(C_word)C_eqp(t6,lf[177]);
t15=t12;
f_11595(t15,(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[188])));}}}}}}}
else{
t6=t2;
t7=(C_word)C_eqp(t6,lf[74]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[219]);}
else{
t8=(C_word)C_eqp(t6,lf[75]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[220]);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11806,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
if(C_truep((C_word)C_charp(t2))){
t10=t2;
t11=(C_word)C_fix((C_word)C_character_code(t10));
t12=t9;
f_11806(t12,(C_word)C_fixnum_less_or_equal_p(C_fix(128),t11));}
else{
t10=t9;
f_11806(t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_11806(t10,C_SCHEME_FALSE);}}}}}

/* k11804 in adjust */
static void C_fcall f_11806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11806,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11813,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11817,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* char->utf8-list */
f_9957(t7,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11815 in k11804 in adjust */
static void C_ccall f_11817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11817,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11819,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11819(t5,((C_word*)t0)[2],t1);}

/* loop1531 in k11815 in k11804 in adjust */
static void C_fcall f_11819(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11819,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[158]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11848,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g15471548 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11846 in loop1531 in k11815 in k11804 in adjust */
static void C_ccall f_11848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11848,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15311544 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11819(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15311544 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11819(t6,((C_word*)t0)[3],t5);}}

/* k11811 in k11804 in adjust */
static void C_ccall f_11813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11813,2,t0,t1);}
/* sre-sequence */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13598(C_a_i(&a,3),t1));}

/* k11593 in adjust */
static void C_fcall f_11595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11595,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11604,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* sre->cset */
f_19377(t3,((C_word*)t0)[4],(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[77]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=f_13598(C_a_i(&a,3),t3);
t5=(C_word)C_eqp(t4,lf[74]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[217]);}
else{
t6=(C_word)C_eqp(t4,lf[75]);
if(C_truep(t6)){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[218]);}
else{
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11680,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11686,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t14,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_11686(t16,t11,t12);}}}
else{
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11734,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11740,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_11740(t13,t8,t9);}}}

/* loop1499 in k11593 in adjust */
static void C_fcall f_11740(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11740,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11769,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* g15151516 */
t5=((C_word*)t0)[2];
f_11417(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11767 in loop1499 in k11593 in adjust */
static void C_ccall f_11769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11769,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14991512 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11740(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14991512 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11740(t6,((C_word*)t0)[3],t5);}}

/* k11732 in k11593 in adjust */
static void C_ccall f_11734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11734,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop1476 in k11593 in adjust */
static void C_fcall f_11686(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11686,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11715,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* g14921493 */
t5=((C_word*)t0)[2];
f_11417(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11713 in loop1476 in k11593 in adjust */
static void C_ccall f_11715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11715,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14761489 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11686(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14761489 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11686(t6,((C_word*)t0)[3],t5);}}

/* k11678 in k11593 in adjust */
static void C_ccall f_11680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11680,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[77],t1));}

/* k11602 in k11593 in adjust */
static void C_ccall f_11604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11610,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11625,tmp=(C_word)a,a+=2,tmp);
/* any */
f_5391(t2,t3,t1);}

/* a11624 in k11602 in k11593 in adjust */
static void C_ccall f_11625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11625,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_fixnum_less_or_equal_p(C_fix(128),t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=t1;
t8=(C_word)C_fix((C_word)C_character_code(t6));
t9=t7;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_less_or_equal_p(C_fix(128),t8));}}
else{
t3=t1;
t4=t2;
t5=(C_word)C_fix((C_word)C_character_code(t4));
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_fixnum_less_or_equal_p(C_fix(128),t5));}}

/* k11608 in k11602 in k11593 in adjust */
static void C_ccall f_11610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11610,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11620,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* cset->utf8-pattern */
f_11240(t2,((C_word*)t0)[3]);}
else{
/* cset->utf8-pattern */
f_11240(((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11618 in k11608 in k11602 in k11593 in adjust */
static void C_ccall f_11620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11620,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[168],t1));}

/* loop1425 in adjust */
static void C_fcall f_11548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11548,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11575,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11582,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g14411442 */
t6=t3;
f_11575(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11580 in loop1425 in adjust */
static void C_ccall f_11582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11582,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14251438 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11548(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14251438 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11548(t6,((C_word*)t0)[3],t5);}}

/* g1441 in loop1425 in adjust */
static void C_fcall f_11575(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11575,NULL,3,t0,t1,t2);}
/* adjust1382 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11414(t3,t1,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k11540 in adjust */
static void C_ccall f_11542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11542,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop1401 in adjust */
static void C_fcall f_11487(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11487,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11514,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11521,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g14171418 */
t6=t3;
f_11514(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11519 in loop1401 in adjust */
static void C_ccall f_11521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11521,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14011414 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11487(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14011414 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11487(t6,((C_word*)t0)[3],t5);}}

/* g1417 in loop1401 in adjust */
static void C_fcall f_11514(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11514,NULL,3,t0,t1,t2);}
/* adjust1382 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11414(t3,t1,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11479 in adjust */
static void C_ccall f_11481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11481,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* rec in adjust */
static void C_fcall f_11417(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11417,NULL,3,t0,t1,t2);}
/* adjust1382 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_11414(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* sre-searcher? */
t3=lf[216];
f_12305(3,t3,t2,t1);}

/* k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11907,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
/* sre-remove-initial-bos */
t3=lf[215];
f_14064(3,t3,t2,((C_word*)t0)[4]);}
else{
t3=t2;
f_11907(2,t3,((C_word*)t0)[4]);}}

/* k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11910,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_u_i_memq(lf[213],((C_word*)t0)[2]))){
t3=t2;
f_11910(t3,C_fix(1));}
else{
t3=(C_word)C_u_i_memq(lf[214],((C_word*)t0)[2]);
t4=t2;
f_11910(t4,(C_truep(t3)?C_fix(50):C_fix(10)));}}

/* k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_11910(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11910,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11913,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_11913(2,t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11989,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[74],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[77],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[68],t7);
/* sre->nfa */
f_14706(t3,t8,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}}

/* k11987 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11989,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11993,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* g15941595 */
t3=t2;
f_11993(t3,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_11913(2,t2,C_SCHEME_FALSE);}}

/* g1594 in k11987 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_11993(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11993,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=(C_word)C_fixnum_times(((C_word*)t0)[2],t3);
/* nfa->dfa */
f_15564(t1,t2,(C_word)C_a_i_list(&a,1,t4));}

/* k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
/* sre->nfa */
f_14706(t2,((C_word*)t0)[7],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=t2;
f_11916(2,t3,C_SCHEME_FALSE);}}

/* k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11968,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* g16081609 */
t4=t3;
f_11968(t4,t2,t1);}
else{
t3=t2;
f_11919(2,t3,C_SCHEME_FALSE);}}

/* g1608 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_11968(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11968,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=(C_word)C_fixnum_times(((C_word*)t0)[2],t3);
/* nfa->dfa */
f_15564(t1,t2,(C_word)C_a_i_list(&a,1,t4));}

/* k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
t3=((C_word*)t0)[7];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16918,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_16918(t7,t2,t3,C_fix(1),C_SCHEME_FALSE);}
else{
t3=t2;
f_11922(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_11922(2,t3,C_SCHEME_FALSE);}}

/* lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_16918(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16918,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17242,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* sre-has-submatchs? */
t6=lf[212];
f_12477(3,t6,t5,t2);}

/* k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17242,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(t2,lf[170]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[68]));
if(C_truep(t4)){
t5=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t6=f_13598(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16969,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp2992 */
t9=((C_word*)((C_word*)t0)[3])[1];
f_16918(t9,t7,t8,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t5=(C_word)C_eqp(t2,lf[57]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t7=f_13623(C_a_i(&a,3),t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17062,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp2992 */
t10=((C_word*)((C_word*)t0)[3])[1];
f_16918(t10,t8,t9,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t6=(C_word)C_eqp(t2,lf[77]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[79]));
if(C_truep(t7)){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17112,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t14=f_13598(C_a_i(&a,3),t13);
/* lp2992 */
t15=((C_word*)((C_word*)t0)[3])[1];
f_16918(t15,t12,t14,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t8=(C_word)C_eqp(t2,lf[81]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17168,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t11=f_13598(C_a_i(&a,3),t10);
/* lp2992 */
t12=((C_word*)((C_word*)t0)[3])[1];
f_16918(t12,t9,t11,((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t9=(C_word)C_eqp(t2,lf[62]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17193,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t12=f_13598(C_a_i(&a,3),t11);
t13=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* lp2992 */
t14=((C_word*)((C_word*)t0)[3])[1];
f_16918(t14,t10,t12,t13,C_SCHEME_TRUE);}
else{
t10=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* error */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,((C_word*)t0)[5],lf[207],t10);}}}}}}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[208],((C_word*)t0)[6]);}}
else{
t2=((C_word*)t0)[2];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16936,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16945,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* sre->nfa */
f_14706(t4,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_16932,tmp=(C_word)a,a+=2,tmp));}}}

/* f_16932 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_16932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16932,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}

/* k16943 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_16945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* nfa->dfa */
f_15564(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k16934 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_16936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16936,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_16937,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_16937 in k16934 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_16937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16937,6,t0,t1,t2,t3,t4,t5);}
/* dfa-match/longest */
f_14599(t1,((C_word*)t0)[2],t2,t3,t4);}

/* k17191 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17194,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_17194 in k17191 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17194,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17198,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* match-one3090 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k17196 */
static void C_ccall f_17198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(C_truep((C_word)C_i_numberp(t1))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_word)C_fixnum_shift_left(t3,C_fix(1));
t6=(C_word)C_u_fixnum_plus(C_fix(3),t5);
t7=(C_word)C_i_setslot(t2,t6,t4);
t8=((C_word*)t0)[5];
t9=((C_word*)t0)[4];
t10=t1;
t11=(C_word)C_fixnum_shift_left(t9,C_fix(1));
t12=(C_word)C_u_fixnum_plus(C_fix(4),t11);
t13=(C_word)C_i_setslot(t8,t12,t10);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k17166 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17168,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17169,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_17169 in k17166 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17169,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17173,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match-once3079 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k17171 */
static void C_ccall f_17173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k17110 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17112,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17114,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
t5=(C_word)C_eqp(lf[77],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?((C_word*)((C_word*)t0)[4])[1]:(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17137,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp)));}

/* f_17137 in k17110 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17137,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17141,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* match-once3061 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k17139 */
static void C_ccall f_17141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* match-all3062 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_17114 in k17110 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17114(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17114,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17118,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* match-once3061 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k17116 */
static void C_ccall f_17118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=((C_word*)t0)[2];
t4=t1;
t5=t2;
f_17124(t5,(C_word)C_fixnum_lessp(t3,t4));}
else{
t3=t2;
f_17124(t3,C_SCHEME_FALSE);}}

/* k17122 in k17116 */
static void C_fcall f_17124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* match-all3062 */
t2=((C_word*)((C_word*)t0)[8])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k17060 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17065,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17087,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* sre-count-submatches */
f_12503(t3,t4);}

/* k17085 in k17060 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
/* lp2992 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_16918(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k17063 in k17060 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17065,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17066,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_17066 in k17063 in k17060 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17066,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17070,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* match-first3049 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k17068 */
static void C_ccall f_17070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[7]))){
t2=t1;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* match-rest3050 */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2]);}}

/* k16967 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_16969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16972,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17038,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* sre-count-submatches */
f_12503(t3,t4);}

/* k17036 in k16967 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t1);
/* lp2992 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_16918(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k16970 in k16967 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_16972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_16973,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_16973 in k16970 in k16967 in k17240 in lp in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_16973(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_16973,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_16979,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t4,a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_16979(t9,t1,t4,C_SCHEME_FALSE);}

/* lp */
static void C_fcall f_16979(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_16979,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[8];
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_16989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* match-left3023 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,((C_word*)t0)[4],((C_word*)t0)[8],t2,((C_word*)t0)[3]);}}

/* k16987 in lp */
static void C_ccall f_16989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_16992,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[7]))){
/* match-right3024 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[9],((C_word*)t0)[2]);}
else{
t3=t2;
f_16992(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_16992(2,t3,C_SCHEME_FALSE);}}

/* k16990 in k16987 in lp */
static void C_ccall f_16992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_16992,2,t0,t1);}
if(C_truep((C_word)C_i_eqvp(t1,((C_word*)t0)[6]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17015,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_17015(t5,t3);}
else{
if(C_truep(t1)){
t5=t1;
t6=((C_word*)t0)[3];
t7=t4;
f_17015(t7,(C_word)C_fixnum_greaterp(t5,t6));}
else{
t5=t4;
f_17015(t5,C_SCHEME_FALSE);}}}}

/* k17013 in k16990 in k16987 in lp */
static void C_fcall f_17015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
/* lp3029 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_16979(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}
else{
t2=((C_word*)t0)[2];
/* lp3029 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_16979(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* sre-count-submatches */
f_12503(t2,((C_word*)t0)[8]);}

/* k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* sre-names */
f_13798(t2,((C_word*)t0)[9],C_fix(1),C_SCHEME_END_OF_LIST);}

/* k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11928,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12566,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=t4;
f_12566(2,t5,(C_word)C_u_i_car(t3));}
else{
/* sre-names */
f_13798(t4,t2,C_fix(1),C_SCHEME_END_OF_LIST);}}

/* k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12569,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13587,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* sre-count-submatches */
f_12503(t3,((C_word*)t0)[2]);}

/* k13585 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_13587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(C_fix(1),t1);
/* make-vector */
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12576,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12578,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_12578(t6,t2,((C_word*)t0)[2],C_fix(1),C_fix(0),C_fix(0),*((C_word*)lf[206]+1));}

/* lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_12578(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12578,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12581,a[2]=t6,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t8))){
/* grow1821 */
t9=t7;
f_12581(t9,t1,C_fix(1));}
else{
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_eqp(t9,lf[25]);
t11=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_12623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t6,a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[4],a[10]=t9,a[11]=t1,a[12]=t7,tmp=(C_word)a,a+=13,tmp);
if(C_truep(t10)){
t12=t11;
f_12623(t12,t10);}
else{
t12=(C_word)C_eqp(t9,lf[110]);
if(C_truep(t12)){
t13=t11;
f_12623(t13,t12);}
else{
t13=(C_word)C_eqp(t9,lf[177]);
t14=t11;
f_12623(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[188])));}}}}
else{
if(C_truep((C_word)C_charp(t2))){
/* grow1821 */
t8=t7;
f_12581(t8,t1,C_fix(1));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=(C_word)C_fix((C_word)C_header_size(t2));
/* grow1821 */
t9=t7;
f_12581(t9,t1,t8);}
else{
t8=t2;
if(C_truep((C_truep((C_word)C_eqp(t8,lf[74]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t8,lf[75]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* grow1821 */
t9=t7;
f_12581(t9,t1,C_fix(1));}
else{
t9=t2;
if(C_truep((C_truep((C_word)C_eqp(t9,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[136]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[137]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[145]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[146]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[134]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[133]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[135]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t9,lf[204]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))))){
/* return1814 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,t4,t5);}
else{
t10=(C_word)C_u_i_assq(t2,lf[189]);
if(C_truep(t10)){
t11=(C_word)C_slot(t10,C_fix(1));
/* lp1809 */
t20=t1;
t21=t11;
t22=t3;
t23=t4;
t24=t5;
t25=t6;
t1=t20;
t2=t21;
t3=t22;
t4=t23;
t5=t24;
t6=t25;
goto loop;}
else{
/* error */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[205],t2);}}}}}}}

/* k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_12623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12623,NULL,2,t0,t1);}
if(C_truep(t1)){
/* grow1821 */
t2=((C_word*)t0)[12];
f_12581(t2,((C_word*)t0)[11],C_fix(1));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[178]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12639,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* string->sre */
t5=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[68]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_12652(t5,t3);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[10],lf[170]);
if(C_truep(t5)){
t6=t4;
f_12652(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[10],lf[168]);
if(C_truep(t6)){
t7=t4;
f_12652(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[10],lf[169]);
t8=t4;
f_12652(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[10],lf[181])));}}}}}}

/* k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_12652(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12652,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12661,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_12661(t6,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_fix(0),C_fix(0));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[57]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12743,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_12743(t7,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE,C_fix(0));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[63]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12828,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_12828(t7,t5);}
else{
t7=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t8=t6;
f_12828(t8,(C_word)C_i_nullp(t7));}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[186]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cdddr(((C_word*)t0)[11]);
t6=f_13598(C_a_i(&a,3),t5);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t8=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t7);
/* lp1809 */
t9=((C_word*)((C_word*)t0)[7])[1];
f_12578(t9,((C_word*)t0)[6],t6,t8,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[62]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[4],lf[71]));
if(C_truep(t6)){
t7=(C_word)C_u_i_car(((C_word*)t0)[11]);
t8=(C_word)C_eqp(lf[62],t7);
t9=(C_truep(t8)?(C_word)C_slot(((C_word*)t0)[11],C_fix(1)):(C_word)C_u_i_cddr(((C_word*)t0)[11]));
t10=f_13598(C_a_i(&a,3),t9);
t11=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12999,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lp1809 */
t13=((C_word*)((C_word*)t0)[7])[1];
f_12578(t13,((C_word*)t0)[6],t10,t11,((C_word*)t0)[10],((C_word*)t0)[9],t12);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[141]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[140]));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13039,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t10))){
t11=t9;
f_13039(2,t11,(C_word)C_u_i_cadr(((C_word*)t0)[11]));}
else{
t11=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t12=(C_word)C_u_i_assq(t11,((C_word*)t0)[2]);
if(C_truep(t12)){
t13=t9;
f_13039(2,t13,(C_word)C_slot(t12,C_fix(1)));}
else{
t13=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
/* error */
t14=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t9,lf[199],t13);}}}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[77]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[4],lf[78]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13152,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t13=f_13598(C_a_i(&a,3),t12);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13161,tmp=(C_word)a,a+=2,tmp);
/* lp1809 */
t15=((C_word*)((C_word*)t0)[7])[1];
f_12578(t15,t11,t13,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t14);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[83]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[80]));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13181,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t14))){
t15=(C_word)C_u_i_caddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_numberp(t15))){
t16=(C_word)C_u_i_cadr(((C_word*)t0)[11]);
t17=(C_word)C_u_i_caddr(((C_word*)t0)[11]);
t18=t13;
f_13181(t18,(C_word)C_fixnum_greaterp(t16,t17));}
else{
t16=t13;
f_13181(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_13181(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[79]);
if(C_truep(t13)){
t14=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t15=f_13598(C_a_i(&a,3),t14);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13325,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* lp1809 */
t17=((C_word*)((C_word*)t0)[7])[1];
f_12578(t17,((C_word*)t0)[6],t15,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[81]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[4],lf[82]));
if(C_truep(t15)){
t16=(C_word)C_slot(((C_word*)t0)[11],C_fix(1));
t17=f_13598(C_a_i(&a,3),t16);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13355,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* lp1809 */
t19=((C_word*)((C_word*)t0)[7])[1];
f_12578(t19,((C_word*)t0)[6],t17,((C_word*)t0)[5],((C_word*)t0)[10],((C_word*)t0)[9],t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[84]);
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13382,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t16)){
t18=t17;
f_13382(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[202]);
if(C_truep(t18)){
t19=t17;
f_13382(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[85]);
t20=t17;
f_13382(t20,(C_truep(t19)?t19:(C_word)C_eqp(((C_word*)t0)[4],lf[203])));}}}}}}}}}}}}}

/* k13380 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_13382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13382,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_u_i_car(((C_word*)t0)[9]);
t4=(C_word)C_u_i_memq(t3,lf[200]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_u_i_cadr(((C_word*)t0)[9]));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
/* ##sys#append */
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[64]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13432,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_13432(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[2],lf[65]);
if(C_truep(t4)){
t5=t3;
f_13432(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[66]);
t6=t3;
f_13432(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[2],lf[67])));}}}}

/* k13430 in k13380 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_13432(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* return1814 */
t2=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[201],((C_word*)t0)[2]);}}

/* k13407 in k13380 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_13409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13409,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
/* lp1809 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_12578(t5,((C_word*)t0)[6],t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a13354 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_13355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13355,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[4])){
if(C_truep(t3)){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t3);
/* return1814 */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}
else{
/* return1814 */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],C_SCHEME_FALSE);}}
else{
/* return1814 */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* a13324 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_13325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13325,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t2);
/* return1814 */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,C_SCHEME_FALSE);}

/* k13179 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_13181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13181,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_13184(t3,t1);}
else{
t3=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t4=t2;
f_13184(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_caddr(((C_word*)t0)[4])));}}

/* k13182 in k13179 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_13184(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13184,NULL,2,t0,t1);}
if(C_truep(t1)){
/* return1814 */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_u_i_caddr(((C_word*)t0)[4]))){
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[4]);
t3=f_13598(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13202,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lp1809 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_12578(t5,((C_word*)t0)[7],t3,((C_word*)t0)[2],C_fix(0),C_fix(0),t4);}
else{
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[4]);
t3=f_13598(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13249,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lp1809 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_12578(t5,((C_word*)t0)[7],t3,((C_word*)t0)[2],C_fix(0),C_fix(0),t4);}}}

/* a13248 in k13182 in k13179 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_13249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13249,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t5=(C_word)C_fixnum_times(t4,t2);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t5);
/* return1814 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,C_SCHEME_FALSE);}

/* a13201 in k13182 in k13179 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_13202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13202,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_fixnum_times(t4,t2);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t5);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(t3)){
t7=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t8=(C_word)C_fixnum_times(t7,t3);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t8);
/* return1814 */
t10=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,t6,t9);}
else{
/* return1814 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,C_SCHEME_FALSE);}}
else{
/* return1814 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,C_SCHEME_FALSE);}}

/* a13160 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_13161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13161,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* k13150 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_13152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* return1814 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k13037 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_13039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13039,2,t0,t1);}
t2=(C_word)C_i_integerp(t1);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_13048(t5,t3);}
else{
t5=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
t6=t1;
t7=(C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t6),(C_word)C_fixnum_lessp(t6,t5));
t8=t4;
f_13048(t8,(C_word)C_i_not(t7));}}

/* k13046 in k13037 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_13048(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[197],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]))){
t2=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t3);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(t5)){
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t5);
/* return1814 */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[8],t6,t7);}
else{
/* return1814 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[8],t6,C_SCHEME_FALSE);}}
else{
/* return1814 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[8],t6,C_SCHEME_FALSE);}}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[8],lf[198],((C_word*)t0)[7]);}}}

/* a12998 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12999,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
/* return1814 */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t2,t3);}

/* k12826 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_12828(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12828,NULL,2,t0,t1);}
if(C_truep(t1)){
/* return1814 */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12834,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* sre-count-submatches */
f_12503(t2,t3);}}

/* k12832 in k12826 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* sre-count-submatches */
f_12503(t2,t3);}

/* k12835 in k12832 in k12826 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t4=(C_word)C_i_numberp(t3);
if(C_truep(t4)){
t5=t2;
f_12844(t5,(C_truep(t4)?lf[69]:(C_word)C_u_i_cadr(((C_word*)t0)[9])));}
else{
t5=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t6=(C_word)C_i_symbolp(t5);
t7=t2;
f_12844(t7,(C_truep(t6)?lf[69]:(C_word)C_u_i_cadr(((C_word*)t0)[9])));}}

/* k12842 in k12835 in k12832 in k12826 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_12844(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12844,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12846,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* lp1809 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_12578(t3,((C_word*)t0)[4],t1,((C_word*)t0)[9],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a12845 in k12842 in k12835 in k12832 in k12826 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12846,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* lp1809 */
t7=((C_word*)((C_word*)t0)[2])[1];
f_12578(t7,t1,t4,t5,C_fix(0),C_fix(0),t6);}

/* a12859 in a12845 in k12842 in k12835 in k12832 in k12826 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12860,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_cdddr(((C_word*)t0)[9]);
t5=(C_word)C_i_pairp(t4);
t6=(C_truep(t5)?(C_word)C_u_i_cadddr(((C_word*)t0)[9]):lf[69]);
t7=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(((C_word*)t0)[8],((C_word*)t0)[7]),((C_word*)t0)[6]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12874,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lp1809 */
t9=((C_word*)((C_word*)t0)[2])[1];
f_12578(t9,t1,t6,t7,C_fix(0),C_fix(0),t8);}

/* a12873 in a12859 in a12845 in k12842 in k12835 in k12832 in k12826 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12874,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12903,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* min */
t5=*((C_word*)lf[196]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],t2);}

/* k12901 in a12873 in a12859 in a12845 in k12842 in k12835 in k12832 in k12826 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12903,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
if(C_truep(((C_word*)t0)[6])){
if(C_truep(((C_word*)t0)[5])){
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12899,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* max */
t4=*((C_word*)lf[195]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
/* return1814 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}}
else{
/* return1814 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}}
else{
/* return1814 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}}

/* k12897 in k12901 in a12873 in a12859 in a12845 in k12842 in k12835 in k12832 in k12826 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t1);
/* return1814 */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* lp2 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_12743(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12743,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t4);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(t5)){
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t5);
/* return1814 */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t6,t7);}
else{
/* return1814 */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,C_SCHEME_FALSE);}}
else{
/* return1814 */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12776,a[2]=t4,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* lp1809 */
t8=((C_word*)((C_word*)t0)[2])[1];
f_12578(t8,t1,t6,t3,C_fix(0),C_fix(0),t7);}}

/* a12775 in lp2 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12776,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12809,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* sre-count-submatches */
f_12503(t5,t6);}

/* k12807 in a12775 in lp2 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12809,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12792,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
/* min */
t4=*((C_word*)lf[196]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=t3;
f_12792(2,t4,((C_word*)t0)[2]);}}

/* k12790 in k12807 in a12775 in lp2 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12796,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(((C_word*)t0)[2])){
/* max */
t3=*((C_word*)lf[195]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* lp21881 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_12743(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}
else{
/* lp21881 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_12743(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k12794 in k12790 in k12807 in a12775 in lp2 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp21881 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_12743(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp2 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_12661(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12661,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t4);
if(C_truep(((C_word*)t0)[5])){
if(C_truep(t5)){
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],t5);
/* return1814 */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t6,t7);}
else{
/* return1814 */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,C_SCHEME_FALSE);}}
else{
/* return1814 */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12694,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* lp1809 */
t8=((C_word*)((C_word*)t0)[2])[1];
f_12578(t8,t1,t6,t3,C_fix(0),C_fix(0),t7);}}

/* a12693 in lp2 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12694,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12724,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* sre-count-submatches */
f_12503(t5,t6);}

/* k12722 in a12693 in lp2 in k12650 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],((C_word*)t0)[7]);
if(C_truep(((C_word*)t0)[6])){
if(C_truep(((C_word*)t0)[5])){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],((C_word*)t0)[5]);
/* lp21865 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_12661(t5,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}
else{
/* lp21865 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_12661(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,C_SCHEME_FALSE);}}
else{
/* lp21865 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_12661(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,C_SCHEME_FALSE);}}

/* k12637 in k12621 in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp1809 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_12578(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* grow in lp in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_12581(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12581,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t2);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t2);
/* return1814 */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}
else{
/* return1814 */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,C_SCHEME_FALSE);}}

/* k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_12576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12576,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[11],C_fix(0),t1);
t3=((C_word*)t0)[11];
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11950,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* bit-ior */
f_5631(t5,C_fix(0),C_fix(1));}
else{
t6=t5;
f_11950(2,t6,C_fix(0));}}

/* k11948 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11957,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* sre-consumer? */
t3=lf[194];
f_12391(3,t3,t2,((C_word*)t0)[2]);}

/* k11955 in k11948 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
/* bit-ior */
f_5631(((C_word*)t0)[2],t2,C_fix(2));}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
f_11934(2,t3,t2);}}

/* k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11934,2,t0,t1);}
if(C_truep(((C_word*)t0)[10])){
t2=((C_word*)t0)[9];
t3=((C_word*)t0)[10];
t4=((C_word*)t0)[8];
t5=((C_word*)t0)[7];
t6=t1;
t7=((C_word*)t0)[6];
t8=((C_word*)t0)[5];
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_vector(&a,9,lf[1],t3,t4,t5,C_SCHEME_FALSE,t6,t7,((C_word*)t0)[4],t8));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11943,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17249,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t8=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_pairp(t8))){
t9=t7;
f_17249(2,t9,(C_word)C_u_i_cadr(t4));}
else{
/* sre-names */
f_13798(t7,t3,C_fix(1),C_SCHEME_END_OF_LIST);}}
else{
/* sre-names */
f_13798(t7,t3,C_fix(1),C_SCHEME_END_OF_LIST);}}}

/* k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17249,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?(C_word)C_u_i_car(((C_word*)t0)[4]):C_fix(0));
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17258,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17261,a[2]=((C_word*)t0)[5],a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_17261(t9,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1),t4,t5);}

/* lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_17261(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17261,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17264,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_stringp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17287,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_u_i_car(t2);
t10=t4;
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f25439,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* bit-and */
f_5678(t11,t10,C_fix(2));}
else{
t8=(C_word)C_u_i_car(t2);
t9=(C_word)C_eqp(t8,lf[110]);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_17307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t2,a[8]=t4,a[9]=t5,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t9)){
t11=t10;
f_17307(t11,t9);}
else{
t11=(C_word)C_eqp(t8,lf[188]);
if(C_truep(t11)){
t12=t10;
f_17307(t12,t11);}
else{
t12=(C_word)C_eqp(t8,lf[177]);
t13=t10;
f_17307(t13,(C_truep(t12)?t12:(C_word)C_eqp(t8,lf[25])));}}}}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t7=t2;
t8=(C_word)C_eqp(t7,lf[74]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18755,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t9=(C_word)C_eqp(t7,lf[75]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18783,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t10=(C_word)C_eqp(t7,lf[136]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18825,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=(C_word)C_eqp(t7,lf[145]);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18845,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t12=(C_word)C_eqp(t7,lf[134]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18879,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=(C_word)C_eqp(t7,lf[137]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18937,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t14=(C_word)C_eqp(t7,lf[146]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18961,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,t15);}
else{
t15=(C_word)C_eqp(t7,lf[133]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_18995,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t16=(C_word)C_eqp(t7,lf[135]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19053,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t17);}
else{
t17=(C_word)C_eqp(t7,lf[69]);
if(C_truep(t17)){
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t5);}
else{
t18=(C_word)C_u_i_assq(t2,lf[189]);
if(C_truep(t18)){
t19=(C_word)C_slot(t18,C_fix(1));
/* rec3122 */
t20=t6;
f_17264(t20,t1,t19);}
else{
/* error */
t19=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[190],t2);}}}}}}}}}}}}
else{
if(C_truep((C_word)C_charp(t2))){
t7=t4;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f25467,a[2]=t2,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* bit-and */
f_5678(t8,t7,C_fix(2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19230,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t8=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* error */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,lf[192],t2);}}}}}

/* k19228 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_19230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_19230,2,t0,t1);}
t2=f_13598(C_a_i(&a,3),t1);
/* rec3122 */
t3=((C_word*)t0)[3];
f_17264(t3,((C_word*)t0)[2],t2);}

/* f25467 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f25467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25467,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(2),t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_19182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp)));}

/* f_19182 */
static void C_ccall f_19182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_19182,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19189,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
t8=t3;
if(C_truep((C_word)C_fixnum_lessp(t8,t7))){
t9=(C_word)C_subchar(t2,t3);
t10=t6;
f_19189(t10,(C_word)C_i_eqvp(((C_word*)t0)[2],t9));}
else{
t9=t6;
f_19189(t9,C_SCHEME_FALSE);}}

/* k19187 */
static void C_fcall f_19189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* next3115 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3516 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_19150 */
static void C_ccall f_19150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_19150,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19157,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
t8=t3;
if(C_truep((C_word)C_fixnum_lessp(t8,t7))){
t9=(C_word)C_subchar(t2,t3);
/* char-ci=? */
t10=*((C_word*)lf[191]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t6,((C_word*)t0)[2],t9);}
else{
t9=t6;
f_19157(2,t9,C_SCHEME_FALSE);}}

/* k19155 */
static void C_ccall f_19157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* next3115 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3510 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_19053 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_19053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_19053,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19060,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t7)){
t8=t6;
f_19060(t8,C_SCHEME_FALSE);}
else{
t8=(C_word)C_fix((C_word)C_header_size(t2));
t9=t3;
if(C_truep((C_word)C_fixnum_lessp(t9,t8))){
t10=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t11=(C_word)C_subchar(t2,t10);
t12=(C_word)C_u_i_char_alphabeticp(t11);
t13=(C_truep(t12)?t12:(C_word)C_u_i_char_numericp(t11));
if(C_truep(t13)){
t14=(C_word)C_subchar(t2,t3);
t15=(C_word)C_u_i_char_alphabeticp(t14);
t16=t6;
f_19060(t16,(C_truep(t15)?t15:(C_word)C_u_i_char_numericp(t14)));}
else{
t14=(C_word)C_subchar(t2,t3);
t15=(C_word)C_u_i_char_alphabeticp(t14);
if(C_truep(t15)){
t16=t6;
f_19060(t16,(C_word)C_i_not(t15));}
else{
t16=(C_word)C_u_i_char_numericp(t14);
t17=t6;
f_19060(t17,(C_word)C_i_not(t16));}}}
else{
t10=t6;
f_19060(t10,C_SCHEME_FALSE);}}}

/* k19058 */
static void C_fcall f_19060(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3115 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3501 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18995 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18995,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_19002,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
t8=t3;
t9=(C_word)C_fixnum_greater_or_equal_p(t8,t7);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_19014,a[2]=t6,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_19014(t11,t9);}
else{
t11=(C_word)C_subchar(t2,t3);
t12=(C_word)C_u_i_char_alphabeticp(t11);
if(C_truep(t12)){
t13=t10;
f_19014(t13,(C_word)C_i_not(t12));}
else{
t13=(C_word)C_u_i_char_numericp(t11);
t14=t10;
f_19014(t14,(C_word)C_i_not(t13));}}}

/* k19012 */
static void C_fcall f_19014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[3],t3);
t5=(C_word)C_u_i_char_alphabeticp(t4);
t6=((C_word*)t0)[2];
f_19002(t6,(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t4)));}
else{
t3=((C_word*)t0)[2];
f_19002(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_19002(t2,C_SCHEME_FALSE);}}

/* k19000 */
static void C_fcall f_19002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3115 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3488 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18961 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18961,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
t7=t3;
t8=(C_word)C_fixnum_greater_or_equal_p(t7,t6);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18971,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t8)){
t10=t9;
f_18971(t10,t8);}
else{
t10=(C_word)C_subchar(t2,t3);
t11=t9;
f_18971(t11,(C_word)C_eqp(C_make_character(10),t10));}}

/* k18969 */
static void C_fcall f_18971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3115 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3479 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18937 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18937,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
t7=t3;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t7,t6))){
/* next3115 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,t2,t3,t4,t5);}
else{
/* fail3475 */
t8=t5;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}}

/* f_18879 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18879,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18886,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_eqp(t3,C_fix(0));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18898,a[2]=t6,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t9=t8;
f_18898(t9,t7);}
else{
t9=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t10=(C_word)C_subchar(t2,t9);
t11=(C_word)C_u_i_char_alphabeticp(t10);
if(C_truep(t11)){
t12=t8;
f_18898(t12,(C_word)C_i_not(t11));}
else{
t12=(C_word)C_u_i_char_numericp(t10);
t13=t8;
f_18898(t13,(C_word)C_i_not(t12));}}}

/* k18896 */
static void C_fcall f_18898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
t4=(C_word)C_subchar(((C_word*)t0)[4],((C_word*)t0)[3]);
t5=(C_word)C_u_i_char_alphabeticp(t4);
t6=((C_word*)t0)[2];
f_18886(t6,(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t4)));}
else{
t4=((C_word*)t0)[2];
f_18886(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_18886(t2,C_SCHEME_FALSE);}}

/* k18884 */
static void C_fcall f_18886(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3115 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3462 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18845 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18845,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_eqp(t3,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18855,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_18855(t8,t6);}
else{
t8=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t9=(C_word)C_subchar(t2,t8);
t10=t7;
f_18855(t10,(C_word)C_eqp(C_make_character(10),t9));}}

/* k18853 */
static void C_fcall f_18855(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3115 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3453 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* f_18825 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18825,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t6)){
/* next3115 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t5);}
else{
/* fail3449 */
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}}

/* f_18783 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18783,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18790,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_fix((C_word)C_header_size(t2));
t8=t3;
if(C_truep((C_word)C_fixnum_lessp(t8,t7))){
t9=(C_word)C_subchar(t2,t3);
t10=(C_word)C_eqp(C_make_character(10),t9);
t11=t6;
f_18790(t11,(C_word)C_i_not(t10));}
else{
t9=t6;
f_18790(t9,C_SCHEME_FALSE);}}

/* k18788 */
static void C_fcall f_18790(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* next3115 */
t3=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3443 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* f_18755 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18755,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_fix((C_word)C_header_size(t2));
t7=t3;
if(C_truep((C_word)C_fixnum_lessp(t7,t6))){
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* next3115 */
t9=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,t2,t8,t4,t5);}
else{
/* fail3439 */
t8=t5;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}}

/* k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_17307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17307,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17314,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[8];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f25445,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* bit-and */
f_5678(t4,t3,C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[57]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_i_length(t3);
switch(t4){
case C_fix(0):
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17334,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);
case C_fix(1):
t5=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* rec3122 */
t6=((C_word*)t0)[5];
f_17264(t6,((C_word*)t0)[10],t5);
default:
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17354,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* rec3122 */
t7=((C_word*)t0)[5];
f_17264(t7,t5,t6);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[168]);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t5=f_13598(C_a_i(&a,3),t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17413,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[8];
/* bit-and */
f_5678(t6,t7,C_fix(65533));}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[169]);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t6=f_13598(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17434,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[8];
/* bit-ior */
f_5631(t7,t8,C_fix(2));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[104]);
if(C_truep(t5)){
t6=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t7=f_13598(C_a_i(&a,3),t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17455,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t9=((C_word*)t0)[8];
/* bit-ior */
f_5631(t8,t9,C_fix(32));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[105]);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t8=f_13598(C_a_i(&a,3),t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17476,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=((C_word*)t0)[8];
/* bit-and */
f_5678(t9,t10,C_fix(65503));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[68]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[6],lf[170]));
if(C_truep(t8)){
t9=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t10=(C_word)C_i_length(t9);
switch(t10){
case C_fix(0):
t11=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,((C_word*)t0)[9]);
case C_fix(1):
t11=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* rec3122 */
t12=((C_word*)t0)[5];
f_17264(t12,((C_word*)t0)[10],t11);
default:
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17514,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t12=(C_word)C_u_i_cddr(((C_word*)t0)[7]);
t13=f_13598(C_a_i(&a,3),t12);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17533,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=t13,a[5]=t11,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t15=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* sre-count-submatches */
f_12503(t14,t15);}}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[81]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17554,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t12=f_13598(C_a_i(&a,3),t11);
/* rec3122 */
t13=((C_word*)t0)[5];
f_17264(t13,t10,t12);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[82]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17582,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t13=f_13598(C_a_i(&a,3),t12);
/* rec3122 */
t14=((C_word*)t0)[5];
f_17264(t14,t11,t13);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[77]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17613,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t13=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t14=f_13598(C_a_i(&a,3),t13);
/* sre-empty? */
t15=lf[89];
f_12045(3,t15,t12,t14);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[78]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17671,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t14=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t15=f_13598(C_a_i(&a,3),t14);
/* sre-empty? */
t16=lf[89];
f_12045(3,t16,t13,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[79]);
if(C_truep(t13)){
t14=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t15=f_13598(C_a_i(&a,3),t14);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17734,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=t15,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t18=f_13598(C_a_i(&a,3),t17);
t19=(C_word)C_a_i_list(&a,2,lf[77],t18);
/* rec3122 */
t20=((C_word*)t0)[5];
f_17264(t20,t16,t19);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[84]);
if(C_truep(t14)){
t15=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t16=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17783,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t15,a[5]=t16,tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_u_i_cddr(((C_word*)t0)[7]);
/* ##sys#append */
t19=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[85]);
if(C_truep(t15)){
t16=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17816,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t16,tmp=(C_word)a,a+=5,tmp);
t18=(C_word)C_u_i_cddr(((C_word*)t0)[7]);
/* ##sys#append */
t19=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,t18,C_SCHEME_END_OF_LIST);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[6],lf[83]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(((C_word*)t0)[6],lf[80]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17835,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t19=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_numberp(t19))){
t20=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_numberp(t20))){
t21=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t22=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t23=t18;
f_17835(t23,(C_word)C_fixnum_greaterp(t21,t22));}
else{
t21=t18;
f_17835(t21,C_SCHEME_FALSE);}}
else{
t20=t18;
f_17835(t20,C_SCHEME_FALSE);}}
else{
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[174]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18056,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t21=(C_word)C_a_i_cons(&a,2,lf[133],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t22=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t19,t20,t21);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[6],lf[175]);
if(C_truep(t19)){
t20=(C_word)C_a_i_cons(&a,2,lf[176],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,lf[131],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[57],t21);
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18121,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],a[4]=t22,tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* ##sys#append */
t25=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t23,t24,C_SCHEME_END_OF_LIST);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[6],lf[178]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18146,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t22=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* string->sre */
t23=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t23+1)))(3,t23,t21,t22);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[6],lf[64]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18159,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t24=f_13598(C_a_i(&a,3),t23);
t25=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18182,tmp=(C_word)a,a+=2,tmp);
/* lp3111 */
t26=((C_word*)((C_word*)t0)[3])[1];
f_17261(t26,t22,t24,((C_word*)t0)[4],((C_word*)t0)[8],t25);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[6],lf[65]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18196,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t24=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t25=f_13598(C_a_i(&a,3),t24);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18219,tmp=(C_word)a,a+=2,tmp);
/* lp3111 */
t27=((C_word*)((C_word*)t0)[3])[1];
f_17261(t27,t23,t25,((C_word*)t0)[4],((C_word*)t0)[8],t26);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[6],lf[66]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18233,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t26=(C_word)C_a_i_cons(&a,2,lf[179],t25);
t27=f_13598(C_a_i(&a,3),t26);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18264,tmp=(C_word)a,a+=2,tmp);
/* lp3111 */
t29=((C_word*)((C_word*)t0)[3])[1];
f_17261(t29,t24,t27,((C_word*)t0)[4],((C_word*)t0)[8],t28);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[6],lf[67]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18282,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t26=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t27=(C_word)C_a_i_cons(&a,2,lf[180],t26);
t28=f_13598(C_a_i(&a,3),t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18313,tmp=(C_word)a,a+=2,tmp);
/* lp3111 */
t30=((C_word*)((C_word*)t0)[3])[1];
f_17261(t30,t25,t28,((C_word*)t0)[4],((C_word*)t0)[8],t29);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[6],lf[181]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18331,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t27=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t28=f_13598(C_a_i(&a,3),t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18354,tmp=(C_word)a,a+=2,tmp);
/* lp3111 */
t30=((C_word*)((C_word*)t0)[3])[1];
f_17261(t30,t26,t28,((C_word*)t0)[4],((C_word*)t0)[8],t29);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[6],lf[63]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_18368,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t28=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* sre-count-submatches */
f_12503(t27,t28);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[6],lf[141]);
t28=(C_truep(t27)?t27:(C_word)C_eqp(((C_word*)t0)[6],lf[140]));
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18510,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t30=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_numberp(t30))){
t31=t29;
f_18510(2,t31,(C_word)C_u_i_cadr(((C_word*)t0)[7]));}
else{
t31=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t32=(C_word)C_u_i_assq(t31,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t32)){
t33=t29;
f_18510(2,t33,(C_word)C_slot(t32,C_fix(1)));}
else{
t33=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* error */
t34=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t29,lf[185],t33);}}}
else{
t29=(C_word)C_eqp(((C_word*)t0)[6],lf[186]);
if(C_truep(t29)){
t30=(C_word)C_u_i_cdddr(((C_word*)t0)[7]);
t31=f_13598(C_a_i(&a,3),t30);
t32=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t33=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t32);
/* lp3111 */
t34=((C_word*)((C_word*)t0)[3])[1];
f_17261(t34,((C_word*)t0)[10],t31,t33,((C_word*)t0)[8],((C_word*)t0)[9]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[6],lf[62]);
if(C_truep(t30)){
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18637,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t32=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t33=f_13598(C_a_i(&a,3),t32);
t34=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t35=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18667,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lp3111 */
t36=((C_word*)((C_word*)t0)[3])[1];
f_17261(t36,t31,t33,t34,((C_word*)t0)[8],t35);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[6],lf[71]);
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18707,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t33=(C_word)C_u_i_cddr(((C_word*)t0)[7]);
/* ##sys#append */
t34=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t32,t33,C_SCHEME_END_OF_LIST);}
else{
/* error */
t32=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,((C_word*)t0)[10],lf[187],((C_word*)t0)[7]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k18705 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18707,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[62],t1);
/* rec3122 */
t3=((C_word*)t0)[3];
f_17264(t3,((C_word*)t0)[2],t2);}

/* a18666 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18667,6,t0,t1,t2,t3,t4,t5);}
t6=t4;
t7=((C_word*)t0)[3];
t8=(C_word)C_fixnum_shift_left(t7,C_fix(1));
t9=(C_word)C_u_fixnum_plus(C_fix(4),t8);
t10=(C_word)C_slot(t6,t9);
t11=t4;
t12=((C_word*)t0)[3];
t13=t3;
t14=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t15=(C_word)C_u_fixnum_plus(C_fix(4),t14);
t16=(C_word)C_i_setslot(t11,t15,t13);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18679,a[2]=t5,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* next3115 */
t18=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t18+1)))(6,t18,t1,t2,t3,t4,t17);}

/* a18678 in a18666 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18679,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=(C_word)C_fixnum_shift_left(t3,C_fix(1));
t5=(C_word)C_u_fixnum_plus(C_fix(4),t4);
t6=(C_word)C_i_setslot(t2,t5,((C_word*)t0)[3]);
/* fail3416 */
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}

/* k18635 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18638,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_18638 in k18635 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18638,6,t0,t1,t2,t3,t4,t5);}
t6=t4;
t7=((C_word*)t0)[3];
t8=(C_word)C_fixnum_shift_left(t7,C_fix(1));
t9=(C_word)C_u_fixnum_plus(C_fix(3),t8);
t10=(C_word)C_slot(t6,t9);
t11=t4;
t12=((C_word*)t0)[3];
t13=t3;
t14=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t15=(C_word)C_u_fixnum_plus(C_fix(3),t14);
t16=(C_word)C_i_setslot(t11,t15,t13);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_18650,a[2]=t5,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* body3412 */
t18=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t18+1)))(6,t18,t1,t2,t3,t4,t17);}

/* a18649 */
static void C_ccall f_18650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18650,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=(C_word)C_fixnum_shift_left(t3,C_fix(1));
t5=(C_word)C_u_fixnum_plus(C_fix(3),t4);
t6=(C_word)C_i_setslot(t2,t5,((C_word*)t0)[3]);
/* fail3423 */
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t1);}

/* k18508 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18513,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(t3,lf[140]);
if(C_truep(t4)){
t5=t2;
f_18513(t5,(C_truep(t4)?*((C_word*)lf[183]+1):*((C_word*)lf[184]+1)));}
else{
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f25461,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_5678(t6,t5,C_fix(2));}}

/* f25461 in k18508 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f25461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(2),t1);
t3=((C_word*)t0)[2];
f_18513(t3,(C_truep(t2)?*((C_word*)lf[183]+1):*((C_word*)lf[184]+1)));}

/* k18511 in k18508 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_18513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18513,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18514,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_18514 in k18511 in k18508 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18514,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_18518,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* irregex-match-substring */
t7=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,((C_word*)t0)[2]);}

/* k18516 */
static void C_ccall f_18518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18518,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_fix((C_word)C_header_size(t1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18552,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[5],((C_word*)t0)[8],t4);}
else{
t7=t5;
f_18536(2,t7,C_SCHEME_FALSE);}}
else{
/* fail3407 */
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}

/* k18550 in k18516 */
static void C_ccall f_18552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* compare3390 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k18534 in k18516 */
static void C_ccall f_18536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3115 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3407 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* k18366 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_18371,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],t1);
/* lp3111 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_17261(t5,t2,t3,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k18369 in k18366 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_18374,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_18473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_u_i_caddr(((C_word*)t0)[9]);
/* sre-count-submatches */
f_12503(t5,t6);}
else{
t4=t2;
f_18374(2,t4,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18478,tmp=(C_word)a,a+=2,tmp));}}

/* f_18478 in k18369 in k18366 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18478,6,t0,t1,t2,t3,t4,t5);}
/* fail3354 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k18471 in k18369 in k18366 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(((C_word*)t0)[8],((C_word*)t0)[7]),t1);
/* lp3111 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_17261(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k18372 in k18369 in k18366 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18374,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_numberp(t2);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_18383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
t5=t4;
f_18383(t5,t3);}
else{
t5=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t6=t4;
f_18383(t6,(C_word)C_i_symbolp(t5));}}

/* k18381 in k18372 in k18369 in k18366 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_18383(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_18383,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18386,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
t5=(C_word)C_u_i_assq(t4,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=t2;
f_18386(2,t6,(C_word)C_slot(t5,C_fix(1)));}
else{
/* error */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,lf[182],((C_word*)t0)[6]);}}
else{
t4=t2;
f_18386(2,t4,(C_word)C_u_i_cadr(((C_word*)t0)[6]));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18429,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp3111 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_17261(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* k18427 in k18381 in k18372 in k18369 in k18366 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18430,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_18430 in k18427 in k18381 in k18372 in k18369 in k18366 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18430,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_18436,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* test3379 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a18435 */
static void C_ccall f_18436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18436,2,t0,t1);}
/* fail3350 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k18384 in k18381 in k18372 in k18369 in k18366 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_18387 in k18384 in k18381 in k18372 in k18369 in k18366 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18387,6,t0,t1,t2,t3,t4,t5);}
t6=t4;
t7=((C_word*)t0)[4];
t8=(C_word)C_fixnum_shift_left(t7,C_fix(1));
t9=(C_word)C_u_fixnum_plus(C_fix(4),t8);
if(C_truep((C_word)C_slot(t6,t9))){
/* pass3349 */
t10=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t1,t2,t3,t4,t5);}
else{
/* fail3350 */
t10=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t1,t2,t3,t4,t5);}}

/* a18353 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18354,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k18329 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18332,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_18332 in k18329 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18332,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_18336,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18347,tmp=(C_word)a,a+=2,tmp);
/* once3337 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a18346 */
static void C_ccall f_18347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18347,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k18334 */
static void C_ccall f_18336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3115 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3345 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* a18312 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18313,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k18280 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18282,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18283,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_18283 in k18280 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18283,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18300,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18304,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(0),t3);}

/* k18302 */
static void C_ccall f_18304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18306,tmp=(C_word)a,a+=2,tmp);
/* check3328 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2],t2);}

/* a18305 in k18302 */
static void C_ccall f_18306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18306,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k18298 */
static void C_ccall f_18300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[7],t1))){
/* fail3336 */
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
/* next3115 */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[7],((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* a18263 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18264,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k18231 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18234,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_18234 in k18231 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18234,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18251,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_18255,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* substring */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(0),t3);}

/* k18253 */
static void C_ccall f_18255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18257,tmp=(C_word)a,a+=2,tmp);
/* check3319 */
t3=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2],t2);}

/* a18256 in k18253 */
static void C_ccall f_18257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18257,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k18249 */
static void C_ccall f_18251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[7],t1))){
/* next3115 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3327 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* a18218 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18219,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k18194 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18196,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18197,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_18197 in k18194 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18197,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18204,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18212,tmp=(C_word)a,a+=2,tmp);
/* check3310 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a18211 */
static void C_ccall f_18212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18212,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k18202 */
static void C_ccall f_18204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* fail3318 */
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
/* next3115 */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* a18181 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18182,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k18157 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_18160,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_18160 in k18157 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_18160,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_18167,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_18175,tmp=(C_word)a,a+=2,tmp);
/* check3301 */
t8=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,t2,t3,t4,t7);}

/* a18174 */
static void C_ccall f_18175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18175,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k18165 */
static void C_ccall f_18167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* next3115 */
t2=((C_word*)t0)[7];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* fail3309 */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* k18144 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* rec3122 */
t2=((C_word*)t0)[3];
f_17264(t2,((C_word*)t0)[2],t1);}

/* k18119 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18121,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[57],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[177],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[79],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[133],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[134],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[68],t10);
/* rec3122 */
t12=((C_word*)t0)[3];
f_17264(t12,((C_word*)t0)[2],t11);}

/* k18054 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_18056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_18056,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[134],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[68],t2);
/* rec3122 */
t4=((C_word*)t0)[3];
f_17264(t4,((C_word*)t0)[2],t3);}

/* k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_17835(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17835,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_17838(t3,t1);}
else{
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t4=t2;
f_17838(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_caddr(((C_word*)t0)[7])));}}

/* k17836 in k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_17838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17838,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_17839,tmp=(C_word)a,a+=2,tmp));}
else{
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
t5=(C_word)C_eqp(lf[83],t4);
t6=(C_truep(t5)?lf[81]:lf[82]);
t7=(C_word)C_u_i_car(((C_word*)t0)[7]);
t8=(C_word)C_eqp(lf[83],t7);
t9=(C_truep(t8)?lf[77]:lf[78]);
t10=(C_word)C_u_i_cdddr(((C_word*)t0)[7]);
t11=f_13598(C_a_i(&a,3),t10);
t12=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_17861,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=t11,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* sre-strip-submatches */
t13=lf[173];
f_13648(3,t13,t12,t11);}}

/* k17859 in k17836 in k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_17864,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(C_word)C_eqp(((C_word*)t0)[12],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
t5=t2;
f_17864(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17945,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17961,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[12]);
/* zero-to */
f_5223(t5,t6);}}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
/* rec3122 */
t5=((C_word*)t0)[2];
f_17264(t5,t2,t4);}}

/* k17959 in k17859 in k17836 in k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* fold */
f_5489(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a17944 in k17859 in k17836 in k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_17945,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
/* lp3111 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_17261(t6,t1,t5,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k17862 in k17859 in k17836 in k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17864,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[8],C_fix(0));
if(C_truep(t2)){
t3=t1;
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17881,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17885,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17893,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_u_fixnum_difference(((C_word*)t0)[8],C_fix(1));
/* zero-to */
f_5223(t9,t10);}}

/* k17891 in k17862 in k17859 in k17836 in k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17893,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_17895,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_17895(t5,((C_word*)t0)[2],t1);}

/* loop3271 in k17891 in k17862 in k17859 in k17836 in k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_17895(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_17895,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_17922,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_17922(t3);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop32713284 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop32713284 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g3287 in loop3271 in k17891 in k17862 in k17859 in k17836 in k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static C_word C_fcall f_17922(C_word t0){
C_word tmp;
C_word t1;
return(((C_word*)t0)[2]);}

/* k17883 in k17862 in k17859 in k17836 in k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17885,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k17879 in k17862 in k17859 in k17836 in k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17881,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[68],t1);
/* lp3111 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_17261(t3,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_17839 in k17836 in k17833 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17839,6,t0,t1,t2,t3,t4,t5);}
/* fail3246 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* k17814 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17816,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
/* rec3122 */
t5=((C_word*)t0)[3];
f_17264(t5,((C_word*)t0)[2],t4);}

/* k17781 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17783,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[83],t3);
/* rec3122 */
t5=((C_word*)t0)[3];
f_17264(t5,((C_word*)t0)[2],t4);}

/* k17732 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3111 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_17261(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k17669 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17671,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],lf[172],((C_word*)t0)[6]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17678,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=f_13598(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17695,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* lp3111 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_17261(t8,t4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t7);}}

/* a17694 in k17669 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17695,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17701,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next3115 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17700 in a17694 in k17669 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17701,2,t0,t1);}
/* body3203 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17676 in k17669 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17678,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));}

/* f_17679 in k17676 in k17669 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17679,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17685,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next3115 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17684 */
static void C_ccall f_17685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17685,2,t0,t1);}
/* body3203 */
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17611 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17613,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],lf[171],((C_word*)t0)[6]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_17620,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=f_13598(C_a_i(&a,3),t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17637,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* lp3111 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_17261(t8,t4,t6,((C_word*)t0)[3],((C_word*)t0)[2],t7);}}

/* a17636 in k17611 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17637,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17643,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body3187 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17642 in a17636 in k17611 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17643,2,t0,t1);}
/* next3115 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17618 in k17611 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17620,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17621,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* f_17621 in k17618 in k17611 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17621,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17627,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body3187 */
t7=((C_word*)((C_word*)t0)[2])[1];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17626 */
static void C_ccall f_17627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17627,2,t0,t1);}
/* next3115 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17580 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17583,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_17583 in k17580 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17583,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17589,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* next3115 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17588 */
static void C_ccall f_17589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17589,2,t0,t1);}
/* body3176 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17552 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17554,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17555,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_17555 in k17552 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17555,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17561,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* body3171 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17560 */
static void C_ccall f_17561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17561,2,t0,t1);}
/* next3115 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17531 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
/* lp3111 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_17261(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17512 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* lp3111 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_17261(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k17474 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3111 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_17261(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k17453 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3111 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_17261(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k17432 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3111 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_17261(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k17411 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp3111 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_17261(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k17352 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17357,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t4=f_13623(C_a_i(&a,3),t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_17380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* sre-count-submatches */
f_12503(t5,t6);}

/* k17378 in k17352 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
/* lp3111 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_17261(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k17355 in k17352 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17357,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_17358,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_17358 in k17355 in k17352 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17358,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_17364,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* first3154 */
t7=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,t2,t3,t4,t6);}

/* a17363 */
static void C_ccall f_17364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_17364,2,t0,t1);}
/* rest3155 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_17334 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17334(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17334,6,t0,t1,t2,t3,t4,t5);}
/* fail3152 */
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* f25445 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f25445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25445,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(2),t1);
/* sre->cset */
f_19377(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t2));}

/* k17312 in k17305 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-cset->procedure */
f_19260(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f25439 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f25439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25439,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(2),t1);
/* sre->cset */
f_19377(((C_word*)t0)[3],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,t2));}

/* k17285 in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre-cset->procedure */
f_19260(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* rec in lp in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_fcall f_17264(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_17264,NULL,3,t0,t1,t2);}
/* lp3111 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_17261(t3,t1,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a17257 in k17247 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_17258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_17258,6,t0,t1,t2,t3,t4,t5);}
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* k11941 in k11932 in k12574 in k12567 in k12564 in k11926 in k11923 in k11920 in k11917 in k11914 in k11911 in k11908 in k11905 in k11902 in k11899 in k11896 in sre->irregex in k4469 */
static void C_ccall f_11943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11943,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_vector(&a,9,lf[1],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,t1,t3,t4,((C_word*)t0)[2],t5));}

/* string->irregex in k4469 */
static void C_ccall f_11884(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_11884r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_11884r(t0,t1,t2,t3);}}

static void C_ccall f_11884r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11892,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,*((C_word*)lf[56]+1),t2,t3);}

/* k11890 in string->irregex in k4469 */
static void C_ccall f_11892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[165]+1),t1,((C_word*)t0)[2]);}

/* irregex in k4469 */
static void C_ccall f_11863(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_11863r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_11863r(t0,t1,t2,t3);}}

static void C_ccall f_11863r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11870,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* irregex? */
t5=*((C_word*)lf[0]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k11868 in irregex in k4469 */
static void C_ccall f_11870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[164]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[165]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}}

/* cset->utf8-pattern in k4469 */
static void C_fcall f_11240(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11240,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11246,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_11246(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in cset->utf8-pattern in k4469 */
static void C_fcall f_11246(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11246,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11260,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11264,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* reverse */
t7=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t5=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t5))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_fix((C_word)C_character_code(t6));
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(128),t7))){
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
/* lp1363 */
t23=t1;
t24=t8;
t25=t10;
t26=t4;
t1=t23;
t2=t24;
t3=t25;
t4=t26;
goto loop;}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t4);
/* lp1363 */
t23=t1;
t24=t8;
t25=t3;
t26=t10;
t1=t23;
t2=t24;
t3=t25;
t4=t26;
goto loop;}}
else{
t6=(C_word)C_u_i_caar(t2);
t7=(C_word)C_fix((C_word)C_character_code(t6));
t8=(C_word)C_fixnum_less_or_equal_p(C_fix(128),t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11337,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t8)){
t10=t9;
f_11337(t10,t8);}
else{
t10=(C_word)C_u_i_cdar(t2);
t11=(C_word)C_fix((C_word)C_character_code(t10));
t12=t9;
f_11337(t12,(C_word)C_fixnum_less_or_equal_p(C_fix(128),t11));}}}}

/* k11335 in lp in cset->utf8-pattern in k4469 */
static void C_fcall f_11337(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11337,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11352,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_u_i_cdar(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10090,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* char->utf8-list */
f_9957(t6,t4);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_i_cdar(((C_word*)t0)[6]);
t4=(C_word)C_u_i_caar(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
/* lp1363 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_11246(t7,((C_word*)t0)[3],t2,((C_word*)t0)[5],t6);}}

/* k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10093,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* char->utf8-list */
f_9957(t2,((C_word*)t0)[2]);}

/* k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10093,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[8]);
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10119,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_10119(t8,((C_word*)t0)[7],((C_word*)t0)[8],t1);}
else{
t5=((C_word*)t0)[8];
t6=t1;
t7=(C_word)C_i_length(t5);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10725,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_u_i_car(t5);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_u_i_car(t5);
t12=(C_word)C_fixnum_less_or_equal_p(t11,C_fix(127));
t13=(C_truep(t12)?(C_word)C_a_i_cons(&a,2,C_make_character(127),C_SCHEME_END_OF_LIST):(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST));
t14=(C_word)C_a_i_cons(&a,2,t10,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[25],t14);
t16=C_SCHEME_END_OF_LIST;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_FALSE;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11033,a[2]=t7,a[3]=t8,a[4]=t6,a[5]=t15,tmp=(C_word)a,a+=6,tmp);
t21=(C_word)C_slot(t5,C_fix(1));
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11039,a[2]=t17,a[3]=t23,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t25=((C_word*)t23)[1];
f_11039(t25,t20,t21);}}

/* loop1210 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_fcall f_11039(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11039,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_make_character(128),t4);
t6=(C_word)C_a_i_cons(&a,2,lf[25],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop12101223 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop12101223 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_11033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11033,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_13598(C_a_i(&a,3),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10733,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10861,a[2]=t9,a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_length(((C_word*)t0)[4]);
t12=(C_word)C_u_fixnum_difference((C_word)C_u_fixnum_difference(t11,((C_word*)t0)[2]),C_fix(1));
/* zero-to */
f_5223(t10,t12);}

/* k10859 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10861,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10863,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_10863(t5,((C_word*)t0)[2],t1);}

/* loop1238 in k10859 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_fcall f_10863(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10863,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10890,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11005,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g12541255 */
t6=t3;
f_10890(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11003 in loop1238 in k10859 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_11005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11005,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12381251 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10863(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12381251 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10863(t6,((C_word*)t0)[3],t5);}}

/* g1254 in loop1238 in k10859 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_fcall f_10890(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10890,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10998,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(t2,((C_word*)t0)[2]),C_fix(1));
/* utf8-lowest-digit-of-length */
f_9897(t3,t4);}

/* k10996 in g1254 in loop1238 in k10859 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10998,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10990,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[2]),C_fix(1));
switch(t5){
case C_fix(1):
t6=t3;
f_10982(t6,(C_word)C_a_i_cons(&a,2,C_make_character(127),C_SCHEME_END_OF_LIST));
case C_fix(2):
t6=t3;
f_10982(t6,(C_word)C_a_i_cons(&a,2,C_make_character(223),C_SCHEME_END_OF_LIST));
case C_fix(3):
t6=t3;
f_10982(t6,(C_word)C_a_i_cons(&a,2,C_make_character(239),C_SCHEME_END_OF_LIST));
case C_fix(4):
t6=t3;
f_10982(t6,(C_word)C_a_i_cons(&a,2,C_make_character(247),C_SCHEME_END_OF_LIST));
default:
/* error */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[162],t5);}}

/* k10988 in k10996 in g1254 in loop1238 in k10859 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10990,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=((C_word*)t0)[2];
f_10982(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k10980 in k10996 in g1254 in loop1238 in k10859 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_fcall f_10982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10982,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[25],t2);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10906,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10910,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[2]);
/* zero-to */
f_5223(t9,t10);}

/* k10908 in k10980 in k10996 in g1254 in loop1238 in k10859 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10910,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10912,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10912(t5,((C_word*)t0)[2],t1);}

/* loop1263 in k10908 in k10980 in k10996 in g1254 in loop1238 in k10859 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_fcall f_10912(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10912,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_make_character(128),t4);
t6=(C_word)C_a_i_cons(&a,2,lf[25],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop12631276 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop12631276 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10904 in k10980 in k10996 in g1254 in loop1238 in k10859 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10906,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* sre-sequence */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13598(C_a_i(&a,3),t2));}

/* k10731 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10841,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_fix((C_word)C_character_code(t5));
t7=(C_word)C_slot(lf[119],t6);
/* utf8-lowest-digit-of-length */
f_9897(t2,t7);}

/* k10839 in k10731 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10841,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[25],t7);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10759,a[2]=t10,a[3]=t16,a[4]=t12,tmp=(C_word)a,a+=5,tmp));
t18=((C_word*)t16)[1];
f_10759(t18,t13,t14);}

/* loop1298 in k10839 in k10731 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_fcall f_10759(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10759,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_make_character(128),t4);
t6=(C_word)C_a_i_cons(&a,2,lf[25],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop12981311 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop12981311 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10751 in k10839 in k10731 in k11031 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10753,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_13598(C_a_i(&a,3),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* append */
t5=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k10723 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10725,2,t0,t1);}
t2=f_13623(C_a_i(&a,3),t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* unicode-range-up-to */
f_10551(t3,((C_word*)t0)[2]);}

/* k10112 in k10723 in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10114,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t1);
t3=f_13623(C_a_i(&a,3),t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[6]);
/* lp1363 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_11246(t5,((C_word*)t0)[4],((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* lp in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_fcall f_10119(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10119,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_make_character((C_word)C_unfix(t7));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10147,a[2]=t1,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
t11=(C_word)C_slot(t3,C_fix(1));
/* lp1062 */
t19=t9;
t20=t10;
t21=t11;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_u_fixnum_plus(t7,C_fix(1));
t9=(C_word)C_u_i_car(t3);
t10=(C_word)C_eqp(t8,t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10176,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* unicode-range-up-from */
f_10388(t11,t2);}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10191,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* unicode-range-up-from */
f_10388(t11,t2);}}}}

/* k10189 in lp in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10191,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_make_character((C_word)C_unfix(t5));
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_u_fixnum_difference(t7,C_fix(1));
t9=(C_word)C_make_character((C_word)C_unfix(t8));
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11144,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_eqp(t6,t9);
if(C_truep(t11)){
t12=t10;
f_11144(t12,t6);}
else{
t12=(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t6,t12);
t14=t10;
f_11144(t14,(C_word)C_a_i_cons(&a,2,lf[25],t13));}}

/* k11142 in k10189 in lp in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_fcall f_11144(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11144,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11154,a[2]=t3,a[3]=t9,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_11154(t11,t6,t7);}

/* loop1335 in k11142 in k10189 in lp in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_fcall f_11154(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11154,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_make_character(128),t4);
t6=(C_word)C_a_i_cons(&a,2,lf[25],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop13351348 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop13351348 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11146 in k11142 in k10189 in lp in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_11148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11148,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=f_13598(C_a_i(&a,3),t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10199,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* unicode-range-up-to */
f_10551(t4,((C_word*)t0)[2]);}

/* k10197 in k11146 in k11142 in k10189 in lp in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10199,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],t1);
/* sre-alternate */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13623(C_a_i(&a,3),t2));}

/* k10174 in lp in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10180,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* unicode-range-up-to */
f_10551(t2,((C_word*)t0)[2]);}

/* k10178 in k10174 in lp in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10180,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* sre-alternate */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13623(C_a_i(&a,3),t2));}

/* k10145 in lp in k10091 in k10088 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_10147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10147,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* sre-sequence */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_13598(C_a_i(&a,3),t2));}

/* k11350 in k11335 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_11352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11352,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* lp1363 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_11246(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k11262 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_11264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11264,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
/* append */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11282,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k11280 in k11262 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_11282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11282,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[25],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* append */
t4=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k11258 in lp in cset->utf8-pattern in k4469 */
static void C_ccall f_11260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11260,2,t0,t1);}
/* sre-alternate */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13623(C_a_i(&a,3),t1));}

/* unicode-range-up-to in k4469 */
static void C_fcall f_10551(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10551,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10571,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10573,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10704,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* reverse */
t9=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k10702 in unicode-range-up-to in k4469 */
static void C_ccall f_10704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10704,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10617,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10621,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10653,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10696,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* reverse */
t12=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}

/* k10694 in k10702 in unicode-range-up-to in k4469 */
static void C_ccall f_10696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k10651 in k10702 in unicode-range-up-to in k4469 */
static void C_ccall f_10653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10653,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10655,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10655(t5,((C_word*)t0)[2],t1);}

/* loop1175 in k10651 in k10702 in unicode-range-up-to in k4469 */
static void C_fcall f_10655(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10655,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[158]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10684,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g11911192 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10682 in loop1175 in k10651 in k10702 in unicode-range-up-to in k4469 */
static void C_ccall f_10684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10684,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11751188 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10655(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11751188 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10655(t6,((C_word*)t0)[3],t5);}}

/* k10619 in k10702 in unicode-range-up-to in k4469 */
static void C_ccall f_10621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10649,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* last */
f_5349(t2,((C_word*)t0)[2]);}

/* k10647 in k10619 in k10702 in unicode-range-up-to in k4469 */
static void C_ccall f_10649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10649,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(128),t3);
t5=(C_word)C_a_i_cons(&a,2,lf[25],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* append */
t7=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k10615 in k10702 in unicode-range-up-to in k4469 */
static void C_ccall f_10617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10617,2,t0,t1);}
t2=f_13598(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* unicode-range-helper */
f_10233(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t3);}

/* a10572 in unicode-range-up-to in k4469 */
static void C_ccall f_10573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10573,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_make_character(128),t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[25],t7));}

/* k10569 in unicode-range-up-to in k4469 */
static void C_ccall f_10571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10571,2,t0,t1);}
t2=f_13623(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
/* sre-sequence */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_13598(C_a_i(&a,3),t3));}

/* unicode-range-up-from in k4469 */
static void C_fcall f_10388(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10388,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10408,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10410,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10541,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* reverse */
t9=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k10539 in unicode-range-up-from in k4469 */
static void C_ccall f_10541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10541,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10454,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10458,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10490,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10533,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* reverse */
t12=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}

/* k10531 in k10539 in unicode-range-up-from in k4469 */
static void C_ccall f_10533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k10488 in k10539 in unicode-range-up-from in k4469 */
static void C_ccall f_10490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10490,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10492,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10492(t5,((C_word*)t0)[2],t1);}

/* loop1141 in k10488 in k10539 in unicode-range-up-from in k4469 */
static void C_fcall f_10492(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10492,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[158]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10521,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g11571158 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10519 in loop1141 in k10488 in k10539 in unicode-range-up-from in k4469 */
static void C_ccall f_10521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10521,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11411154 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10492(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11411154 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10492(t6,((C_word*)t0)[3],t5);}}

/* k10456 in k10539 in unicode-range-up-from in k4469 */
static void C_ccall f_10458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10486,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* last */
f_5349(t2,((C_word*)t0)[2]);}

/* k10484 in k10456 in k10539 in unicode-range-up-from in k4469 */
static void C_ccall f_10486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10486,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[25],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* append */
t7=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],((C_word*)t0)[2],t6);}

/* k10452 in k10539 in unicode-range-up-from in k4469 */
static void C_ccall f_10454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10454,2,t0,t1);}
t2=f_13598(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* unicode-range-helper */
f_10233(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t3);}

/* a10409 in unicode-range-up-from in k4469 */
static void C_ccall f_10410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10410,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
t4=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_cons(&a,2,lf[25],t7));}

/* k10406 in unicode-range-up-from in k4469 */
static void C_ccall f_10408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10408,2,t0,t1);}
t2=f_13623(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
/* sre-sequence */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_13598(C_a_i(&a,3),t3));}

/* unicode-range-helper in k4469 */
static void C_fcall f_10233(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10233,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_a_i_cons(&a,2,t7,t4);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10263,a[2]=t8,a[3]=t6,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10267,a[2]=t2,a[3]=t3,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10349,a[2]=t11,a[3]=t16,a[4]=t13,tmp=(C_word)a,a+=5,tmp));
t18=((C_word*)t16)[1];
f_10349(t18,t14,t4);}}

/* loop1083 in unicode-range-helper in k4469 */
static void C_fcall f_10349(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10349,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[158]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10378,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g10991100 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10376 in loop1083 in unicode-range-helper in k4469 */
static void C_ccall f_10378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10378,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10831096 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10349(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10831096 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10349(t6,((C_word*)t0)[3],t5);}}

/* k10265 in unicode-range-helper in k4469 */
static void C_ccall f_10267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10275,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* one1073 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k10273 in k10265 in unicode-range-helper in k4469 */
static void C_ccall f_10275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10279,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10283,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10289,a[2]=t4,a[3]=t10,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_10289(t12,t7,t8);}

/* loop1106 in k10273 in k10265 in unicode-range-helper in k4469 */
static void C_fcall f_10289(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10289,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_a_i_cons(&a,2,C_make_character(255),C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_make_character(128),t4);
t6=(C_word)C_a_i_cons(&a,2,lf[25],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop11061119 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop11061119 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10281 in k10273 in k10265 in unicode-range-helper in k4469 */
static void C_ccall f_10283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10277 in k10273 in k10265 in unicode-range-helper in k4469 */
static void C_ccall f_10279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10279,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* ##sys#append */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10261 in unicode-range-helper in k4469 */
static void C_ccall f_10263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10263,2,t0,t1);}
t2=f_13598(C_a_i(&a,3),t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[6]);
/* unicode-range-helper */
f_10233(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* char->utf8-list in k4469 */
static void C_fcall f_9957(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9957,NULL,2,t1,t2);}
t3=(C_word)C_fix((C_word)C_character_code(t2));
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(127)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t3));}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(2047)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9983,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_fixnum_divide(t3,C_fix(64));
/* bit-ior */
f_5631(t4,C_fix(192),t5);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(65535)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10008,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_fixnum_divide(t3,C_fix(4096));
/* bit-ior */
f_5631(t4,C_fix(224),t5);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(2097151)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10045,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_fixnum_divide(t3,C_fix(262144));
/* bit-ior */
f_5631(t4,C_fix(240),t5);}
else{
/* error */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[156],t3);}}}}}

/* k10043 in char->utf8-list in k4469 */
static void C_ccall f_10045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10049,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10073,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fixnum_divide(((C_word*)t0)[2],C_fix(4096));
/* bit-and */
f_5678(t3,t4,C_fix(63));}

/* k10071 in k10043 in char->utf8-list in k4469 */
static void C_ccall f_10073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_5631(((C_word*)t0)[2],C_fix(128),t1);}

/* k10047 in k10043 in char->utf8-list in k4469 */
static void C_ccall f_10049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10053,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10065,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fixnum_divide(((C_word*)t0)[2],C_fix(64));
/* bit-and */
f_5678(t3,t4,C_fix(63));}

/* k10063 in k10047 in k10043 in char->utf8-list in k4469 */
static void C_ccall f_10065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_5631(((C_word*)t0)[2],C_fix(128),t1);}

/* k10051 in k10047 in k10043 in char->utf8-list in k4469 */
static void C_ccall f_10053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10057,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10061,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_5678(t3,((C_word*)t0)[2],C_fix(63));}

/* k10059 in k10051 in k10047 in k10043 in char->utf8-list in k4469 */
static void C_ccall f_10061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_5631(((C_word*)t0)[2],C_fix(128),t1);}

/* k10055 in k10051 in k10047 in k10043 in char->utf8-list in k4469 */
static void C_ccall f_10057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10057,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k10006 in char->utf8-list in k4469 */
static void C_ccall f_10008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10012,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10024,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fixnum_divide(((C_word*)t0)[2],C_fix(64));
/* bit-and */
f_5678(t3,t4,C_fix(63));}

/* k10022 in k10006 in char->utf8-list in k4469 */
static void C_ccall f_10024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_5631(((C_word*)t0)[2],C_fix(128),t1);}

/* k10010 in k10006 in char->utf8-list in k4469 */
static void C_ccall f_10012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10016,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10020,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_5678(t3,((C_word*)t0)[2],C_fix(63));}

/* k10018 in k10010 in k10006 in char->utf8-list in k4469 */
static void C_ccall f_10020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_5631(((C_word*)t0)[2],C_fix(128),t1);}

/* k10014 in k10010 in k10006 in char->utf8-list in k4469 */
static void C_ccall f_10016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10016,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9981 in char->utf8-list in k4469 */
static void C_ccall f_9983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9987,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9991,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* bit-and */
f_5678(t3,((C_word*)t0)[2],C_fix(63));}

/* k9989 in k9981 in char->utf8-list in k4469 */
static void C_ccall f_9991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* bit-ior */
f_5631(((C_word*)t0)[2],C_fix(128),t1);}

/* k9985 in k9981 in char->utf8-list in k4469 */
static void C_ccall f_9987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9987,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* utf8-lowest-digit-of-length in k4469 */
static void C_fcall f_9897(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9897,NULL,2,t1,t2);}
t3=t2;
switch(t3){
case C_fix(1):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));
case C_fix(2):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(192));
case C_fix(3):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(224));
case C_fix(4):
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(240));
default:
/* error */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[154],t2);}}

/* utf8-string-ref in k4469 */
static void C_fcall f_9672(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9672,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9675,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t4;
switch(t6){
case C_fix(1):
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_subchar(t2,t3));
case C_fix(2):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9725,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=f_9675(t5,t3);
/* bit-and */
f_5678(t7,t8,C_fix(31));
case C_fix(3):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9778,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=f_9675(t5,t3);
/* bit-and */
f_5678(t7,t8,C_fix(15));
case C_fix(4):
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9847,a[2]=t5,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=f_9675(t5,t3);
/* bit-and */
f_5678(t7,t8,C_fix(7));
default:
/* error */
t7=*((C_word*)lf[18]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,lf[152],t2,t4,t3);}}

/* k9845 in utf8-string-ref in k4469 */
static void C_ccall f_9847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9847,2,t0,t1);}
t2=(C_word)C_fixnum_times(t1,C_fix(262144));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=f_9675(((C_word*)t0)[2],t4);
/* bit-and */
f_5678(t3,t5,C_fix(63));}

/* k9833 in k9845 in utf8-string-ref in k4469 */
static void C_ccall f_9835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9835,2,t0,t1);}
t2=(C_word)C_fixnum_times(t1,C_fix(4096));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(2));
t5=f_9675(((C_word*)t0)[2],t4);
/* bit-and */
f_5678(t3,t5,C_fix(63));}

/* k9821 in k9833 in k9845 in utf8-string-ref in k4469 */
static void C_ccall f_9823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9823,2,t0,t1);}
t2=(C_word)C_fixnum_times(t1,C_fix(64));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9811,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(3));
t5=f_9675(((C_word*)t0)[2],t4);
/* bit-and */
f_5678(t3,t5,C_fix(63));}

/* k9809 in k9821 in k9833 in k9845 in utf8-string-ref in k4469 */
static void C_ccall f_9811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]),((C_word*)t0)[3]),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}

/* k9776 in utf8-string-ref in k4469 */
static void C_ccall f_9778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9778,2,t0,t1);}
t2=(C_word)C_fixnum_times(t1,C_fix(4096));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=f_9675(((C_word*)t0)[2],t4);
/* bit-and */
f_5678(t3,t5,C_fix(63));}

/* k9764 in k9776 in utf8-string-ref in k4469 */
static void C_ccall f_9766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9766,2,t0,t1);}
t2=(C_word)C_fixnum_times(t1,C_fix(64));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9754,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(2));
t5=f_9675(((C_word*)t0)[2],t4);
/* bit-and */
f_5678(t3,t5,C_fix(63));}

/* k9752 in k9764 in k9776 in utf8-string-ref in k4469 */
static void C_ccall f_9754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(((C_word*)t0)[4],((C_word*)t0)[3]),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}

/* k9723 in utf8-string-ref in k4469 */
static void C_ccall f_9725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9725,2,t0,t1);}
t2=(C_word)C_fixnum_times(t1,C_fix(64));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9713,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=f_9675(((C_word*)t0)[2],t4);
/* bit-and */
f_5678(t3,t5,C_fix(63));}

/* k9711 in k9723 in utf8-string-ref in k4469 */
static void C_ccall f_9713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}

/* byte in utf8-string-ref in k4469 */
static C_word C_fcall f_9675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
return((C_word)C_fix((C_word)C_character_code(t2)));}

/* high-char? in k4469 */
static void C_ccall f_9652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9652,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_character_code(t2));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fixnum_less_or_equal_p(C_fix(128),t3));}

/* string-parse-hex-escape in k4469 */
static void C_fcall f_8849(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8849,NULL,4,t1,t2,t3,t4);}
t5=t3;
t6=t4;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,t6))){
/* error */
t7=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[147],t2,t3);}
else{
t7=(C_word)C_subchar(t2,t3);
t8=(C_word)C_eqp(C_make_character(123),t7);
if(C_truep(t8)){
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t10=t2;
t11=(C_word)C_a_i_list(&a,1,t9);
t12=(C_word)C_fix((C_word)C_header_size(t10));
t13=(C_word)C_i_pairp(t11);
t14=(C_truep(t13)?(C_word)C_u_i_car(t11):C_fix(0));
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4964,a[2]=t10,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t16=f_4964(t15,t14);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8880,a[2]=t16,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t18=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* substring */
t19=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t17,t2,t18,t16);}
else{
/* error */
t17=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,t1,lf[149],t2,t3);}}
else{
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t10=t4;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t9,t10))){
/* error */
t11=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t1,lf[150],t2,t3);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8916,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_u_fixnum_plus(t3,C_fix(2));
/* substring */
t13=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,t2,t3,t12);}}}}

/* k8914 in string-parse-hex-escape in k4469 */
static void C_ccall f_8916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8919,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->number */
C_string_to_number(4,0,t2,t1,C_fix(16));}

/* k8917 in k8914 in string-parse-hex-escape in k4469 */
static void C_ccall f_8919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8919,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(2));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[151],((C_word*)t0)[2]);}}

/* k8878 in string-parse-hex-escape in k4469 */
static void C_ccall f_8880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8883,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* string->number */
C_string_to_number(4,0,t2,t1,C_fix(16));}

/* k8881 in k8878 in string-parse-hex-escape in k4469 */
static void C_ccall f_8883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8883,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_make_character((C_word)C_unfix(t1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[3]));}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[148],((C_word*)t0)[2]);}}

/* scan in string-parse-hex-escape in k4469 */
static C_word C_fcall f_4964(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
return(C_SCHEME_FALSE);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[2],t1);
t5=(C_word)C_eqp(C_make_character(125),t4);
if(C_truep(t5)){
return(t1);}
else{
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}}

/* string->sre in k4469 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5863r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5863r(t0,t1,t2,t3);}}

static void C_ccall f_5863r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5870,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* symbol-list->flags */
f_5763(t5,t3);}

/* k5868 in string->sre in k4469 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5870,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5875,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5875(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in k5868 in string->sre in k4469 */
static void C_fcall f_5875(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word t181;
C_word t182;
C_word t183;
C_word t184;
C_word t185;
C_word t186;
C_word t187;
C_word t188;
C_word t189;
C_word t190;
C_word t191;
C_word t192;
C_word t193;
C_word t194;
C_word t195;
C_word t196;
C_word t197;
C_word t198;
C_word t199;
C_word t200;
C_word t201;
C_word t202;
C_word t203;
C_word t204;
C_word t205;
C_word t206;
C_word t207;
C_word t208;
C_word t209;
C_word t210;
C_word t211;
C_word t212;
C_word t213;
C_word t214;
C_word t215;
C_word t216;
C_word t217;
C_word t218;
C_word t219;
C_word t220;
C_word t221;
C_word t222;
C_word t223;
C_word t224;
C_word t225;
C_word t226;
C_word t227;
C_word t228;
C_word t229;
C_word t230;
C_word t231;
C_word t232;
C_word t233;
C_word t234;
C_word t235;
C_word t236;
C_word t237;
C_word t238;
C_word t239;
C_word t240;
C_word t241;
C_word t242;
C_word t243;
C_word t244;
C_word t245;
C_word *a;
loop:
a=C_alloc(72);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5875,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5878,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5908,a[2]=t8,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t20=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5963,a[2]=((C_word*)t0)[4],a[3]=t10,a[4]=t5,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t21=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5983,a[2]=t2,a[3]=t8,a[4]=((C_word*)t0)[4],a[5]=t10,a[6]=t5,a[7]=t3,a[8]=t4,tmp=(C_word)a,a+=9,tmp));
t22=t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6055,a[2]=t12,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t23=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6355,a[2]=t12,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t24=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t24,((C_word*)t0)[3]))){
if(C_truep((C_word)C_i_pairp(t6))){
/* error */
t25=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t1,lf[73],((C_word*)t0)[4]);}
else{
/* collect/terms417 */
t25=t15;
f_6055(t25,t1);}}
else{
t25=(C_word)C_subchar(((C_word*)t0)[4],t2);
switch(t25){
case C_make_character(46):
t26=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t27=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t28=t4;
t29=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f25183,a[2]=t12,a[3]=t6,a[4]=t4,a[5]=t27,a[6]=t26,a[7]=t1,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* bit-and */
f_5678(t29,t28,C_fix(8));
case C_make_character(63):
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6429,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* collect/single416 */
t27=((C_word*)t14)[1];
f_5983(t27,t26);
default:
t26=(C_word)C_eqp(t25,C_make_character(43));
t27=(C_truep(t26)?t26:(C_word)C_eqp(t25,C_make_character(42)));
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6626,a[2]=t25,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* collect/single416 */
t29=((C_word*)t14)[1];
f_5983(t29,t28);}
else{
switch(t25){
case C_make_character(40):
t28=(C_word)C_u_fixnum_plus(t2,C_fix(1));
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t28,((C_word*)t0)[3]))){
/* error */
t29=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t29+1)))(4,t29,t1,lf[91],((C_word*)t0)[4]);}
else{
t29=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t30=(C_word)C_subchar(((C_word*)t0)[4],t29);
t31=(C_word)C_eqp(C_make_character(63),t30);
if(C_truep(t31)){
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t32,((C_word*)t0)[3]))){
/* error */
t33=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t33+1)))(4,t33,t1,lf[92],((C_word*)t0)[4]);}
else{
t33=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t34=(C_word)C_subchar(((C_word*)t0)[4],t33);
switch(t34){
case C_make_character(35):
t35=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6738,a[2]=t12,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t36=(C_word)C_u_fixnum_plus(t2,C_fix(3));
/* string-scan-char */
f_4906(t35,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t36));
case C_make_character(58):
t35=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t36=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t37=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6778,a[2]=t17,a[3]=t36,a[4]=t35,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t38=t4;
/* bit-and */
f_5678(t37,t38,C_fix(65534));
case C_make_character(61):
t35=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t36=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t37=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6803,a[2]=t17,a[3]=t36,a[4]=t35,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t38=t4;
/* bit-and */
f_5678(t37,t38,C_fix(65534));
case C_make_character(33):
t35=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t36=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t37=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6828,a[2]=t17,a[3]=t36,a[4]=t35,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t38=t4;
/* bit-and */
f_5678(t37,t38,C_fix(65534));
case C_make_character(60):
t35=(C_word)C_u_fixnum_plus(t2,C_fix(3));
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t35,((C_word*)t0)[3]))){
/* error */
t36=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t36+1)))(4,t36,t1,lf[95],((C_word*)t0)[4]);}
else{
t36=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t37=(C_word)C_subchar(((C_word*)t0)[4],t36);
switch(t37){
case C_make_character(61):
t38=(C_word)C_u_fixnum_plus(t2,C_fix(4));
t39=(C_word)C_u_fixnum_plus(t2,C_fix(4));
t40=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6871,a[2]=t17,a[3]=t39,a[4]=t38,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t41=t4;
/* bit-and */
f_5678(t40,t41,C_fix(65534));
case C_make_character(33):
t38=(C_word)C_u_fixnum_plus(t2,C_fix(4));
t39=(C_word)C_u_fixnum_plus(t2,C_fix(4));
t40=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6896,a[2]=t17,a[3]=t39,a[4]=t38,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t41=t4;
/* bit-and */
f_5678(t40,t41,C_fix(65534));
default:
t38=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6903,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t17,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t39=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t40=(C_word)C_subchar(((C_word*)t0)[4],t39);
if(C_truep((C_word)C_u_i_char_alphabeticp(t40))){
t41=(C_word)C_u_fixnum_plus(t2,C_fix(4));
/* string-scan-char */
f_4906(t38,((C_word*)t0)[4],C_make_character(62),(C_word)C_a_i_list(&a,1,t41));}
else{
t41=t38;
f_6903(2,t41,C_SCHEME_FALSE);}}}
case C_make_character(62):
t35=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t36=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t37=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6995,a[2]=t17,a[3]=t36,a[4]=t35,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t38=t4;
/* bit-and */
f_5678(t37,t38,C_fix(65534));
case C_make_character(40):
t35=(C_word)C_u_fixnum_plus(t2,C_fix(3));
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t35,((C_word*)t0)[3]))){
/* error */
t36=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t36+1)))(4,t36,t1,lf[100],((C_word*)t0)[4]);}
else{
t36=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t37=(C_word)C_subchar(((C_word*)t0)[4],t36);
if(C_truep((C_word)C_u_i_char_numericp(t37))){
t38=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7023,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t17,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t39=(C_word)C_u_fixnum_plus(t2,C_fix(3));
/* string-scan-char */
f_4906(t38,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t39));}
else{
t38=(C_word)C_u_fixnum_plus(t2,C_fix(3));
t39=(C_word)C_subchar(((C_word*)t0)[4],t38);
if(C_truep((C_word)C_u_i_char_alphabeticp(t39))){
t40=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7083,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=t17,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t41=(C_word)C_u_fixnum_plus(t2,C_fix(3));
/* string-scan-char */
f_4906(t40,((C_word*)t0)[4],C_make_character(41),(C_word)C_a_i_list(&a,1,t41));}
else{
t40=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t41=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t42=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7140,a[2]=t17,a[3]=t41,a[4]=t40,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t43=t4;
/* bit-and */
f_5678(t42,t43,C_fix(65534));}}}
case C_make_character(123):
/* error */
t35=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t35+1)))(4,t35,t1,lf[103],((C_word*)t0)[4]);
default:
t35=t4;
t36=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_set_block_item(t38,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7182,a[2]=t12,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t38,a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[3],a[9]=t35,tmp=(C_word)a,a+=10,tmp));
t40=((C_word*)t38)[1];
f_7182(t40,t1,t36,t4,C_SCHEME_FALSE);}}}
else{
t32=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t33=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t34=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6713,a[2]=t17,a[3]=t33,a[4]=t32,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t35=t4;
/* bit-ior */
f_5631(t34,t35,C_fix(1));}}
case C_make_character(41):
if(C_truep((C_word)C_i_nullp(t6))){
/* error */
t28=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t28+1)))(4,t28,t1,lf[108],((C_word*)t0)[4]);}
else{
t28=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t29=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t30=(C_word)C_u_i_caar(t6);
t31=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7448,a[2]=t30,a[3]=t29,a[4]=t28,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* collect/terms417 */
t32=t15;
f_6055(t32,t31);}
case C_make_character(91):
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7463,a[2]=t12,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7487,a[2]=t28,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t30=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t31=((C_word*)t0)[4];
t32=t4;
t33=(C_word)C_fix((C_word)C_header_size(t31));
t34=(C_word)C_subchar(t31,t30);
t35=(C_word)C_eqp(C_make_character(94),t34);
t36=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f25244,a[2]=t29,a[3]=t30,a[4]=t32,a[5]=t35,a[6]=t31,a[7]=t33,tmp=(C_word)a,a+=8,tmp);
/* bit-and */
f_5678(t36,t32,C_fix(32));
case C_make_character(123):
t28=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t29=(C_word)C_fixnum_greater_or_equal_p(t28,((C_word*)t0)[3]);
t30=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7506,a[2]=t14,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[2],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t29)){
t31=t30;
f_7506(t31,t29);}
else{
t31=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t32=(C_word)C_subchar(((C_word*)t0)[4],t31);
t33=(C_word)C_u_i_char_numericp(t32);
if(C_truep(t33)){
t34=t30;
f_7506(t34,(C_word)C_i_not(t33));}
else{
t34=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t35=(C_word)C_subchar(((C_word*)t0)[4],t34);
t36=(C_word)C_eqp(C_make_character(44),t35);
t37=t30;
f_7506(t37,(C_word)C_i_not(t36));}}
case C_make_character(92):
t28=(C_word)C_u_fixnum_plus(t2,C_fix(1));
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t28,((C_word*)t0)[3]))){
/* error */
t29=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t29+1)))(4,t29,t1,lf[127],((C_word*)t0)[4]);}
else{
t29=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t30=(C_word)C_subchar(((C_word*)t0)[4],t29);
switch(t30){
case C_make_character(100):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7753,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7757,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t35=((C_word*)t12)[1];
f_5963(t35,t34);
case C_make_character(68):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(C_word)C_a_i_cons(&a,2,lf[128],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[110],t33);
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7786,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t34,tmp=(C_word)a,a+=9,tmp);
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7790,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t37=((C_word*)t12)[1];
f_5963(t37,t36);
case C_make_character(115):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7819,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7823,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t35=((C_word*)t12)[1];
f_5963(t35,t34);
case C_make_character(83):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(C_word)C_a_i_cons(&a,2,lf[129],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[110],t33);
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7852,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t34,tmp=(C_word)a,a+=9,tmp);
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7856,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t37=((C_word*)t12)[1];
f_5963(t37,t36);
case C_make_character(119):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(C_word)C_a_i_cons(&a,2,lf[130],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,lf[131],t34);
t36=(C_word)C_a_i_cons(&a,2,lf[57],t35);
t37=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7889,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t36,tmp=(C_word)a,a+=9,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7893,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t39=((C_word*)t12)[1];
f_5963(t39,t38);
case C_make_character(87):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(C_word)C_a_i_cons(&a,2,lf[132],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,lf[131],t34);
t36=(C_word)C_a_i_cons(&a,2,lf[57],t35);
t37=(C_word)C_a_i_cons(&a,2,t36,C_SCHEME_END_OF_LIST);
t38=(C_word)C_a_i_cons(&a,2,lf[110],t37);
t39=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7934,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t38,tmp=(C_word)a,a+=9,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7938,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t41=((C_word*)t12)[1];
f_5963(t41,t40);
case C_make_character(98):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(C_word)C_a_i_cons(&a,2,lf[133],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[134],t33);
t35=(C_word)C_a_i_cons(&a,2,lf[57],t34);
t36=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7987,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t35,tmp=(C_word)a,a+=9,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7991,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t38=((C_word*)t12)[1];
f_5963(t38,t37);
case C_make_character(66):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8024,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8028,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t35=((C_word*)t12)[1];
f_5963(t35,t34);
case C_make_character(65):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8053,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8057,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t35=((C_word*)t12)[1];
f_5963(t35,t34);
case C_make_character(90):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(C_word)C_a_i_cons(&a,2,C_make_character(10),C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[81],t33);
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8090,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t34,tmp=(C_word)a,a+=9,tmp);
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8094,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t37=((C_word*)t12)[1];
f_5963(t37,t36);
case C_make_character(122):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8123,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8127,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t35=((C_word*)t12)[1];
f_5963(t35,t34);
case C_make_character(82):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8152,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8156,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t35=((C_word*)t12)[1];
f_5963(t35,t34);
case C_make_character(75):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8181,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8185,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t35=((C_word*)t12)[1];
f_5963(t35,t34);
case C_make_character(60):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8210,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8214,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t35=((C_word*)t12)[1];
f_5963(t35,t34);
case C_make_character(62):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8239,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8243,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t35=((C_word*)t12)[1];
f_5963(t35,t34);
case C_make_character(120):
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8254,a[2]=t12,a[3]=t6,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8282,a[2]=t31,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t33=(C_word)C_u_fixnum_plus(t2,C_fix(2));
/* string-parse-hex-escape */
f_8849(t32,((C_word*)t0)[4],t33,((C_word*)t0)[3]);
case C_make_character(107):
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_subchar(((C_word*)t0)[4],t31);
if(C_truep((C_truep((C_word)C_eqp(t32,C_make_character(60)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t32,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t32,C_make_character(39)))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t33=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8307,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t12,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t4,tmp=(C_word)a,a+=9,tmp);
switch(t32){
case C_make_character(60):
t34=t33;
f_8307(t34,C_make_character(62));
case C_make_character(123):
t34=t33;
f_8307(t34,C_make_character(125));
case C_make_character(40):
t34=t33;
f_8307(t34,C_make_character(41));
default:
t34=(C_word)C_eqp(t32,C_make_character(91));
t35=t33;
f_8307(t35,(C_truep(t34)?C_make_character(93):t32));}}
else{
/* error */
t33=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t33+1)))(4,t33,t1,lf[143],((C_word*)t0)[4]);}
case C_make_character(81):
t31=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8391,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect415 */
t32=((C_word*)t12)[1];
f_5963(t32,t31);
default:
if(C_truep((C_word)C_u_i_char_numericp(t30))){
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=((C_word*)t0)[4];
t33=(C_word)C_a_i_list(&a,1,t31);
t34=(C_word)C_fix((C_word)C_header_size(t32));
t35=(C_word)C_i_pairp(t33);
t36=(C_truep(t35)?(C_word)C_u_i_car(t33):C_fix(0));
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5022,a[2]=t32,a[3]=t34,tmp=(C_word)a,a+=4,tmp);
t38=f_5022(t37,t36);
t39=(C_truep(t38)?t38:((C_word*)t0)[3]);
t40=t4;
t41=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f25260,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t12,a[5]=t6,a[6]=t4,a[7]=t39,a[8]=t1,a[9]=((C_word*)t0)[2],tmp=(C_word)a,a+=10,tmp);
/* bit-and */
f_5678(t41,t40,C_fix(2));}
else{
if(C_truep((C_word)C_u_i_char_alphabeticp(t30))){
t31=(C_word)C_u_i_assq(t30,lf[117]);
if(C_truep(t31)){
t32=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t33=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t34=(C_word)C_slot(t31,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8597,a[2]=t6,a[3]=t4,a[4]=t33,a[5]=t32,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t34,tmp=(C_word)a,a+=9,tmp);
/* collect415 */
t36=((C_word*)t12)[1];
f_5963(t36,t35);}
else{
/* error */
t32=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t32+1)))(5,t32,t1,lf[144],((C_word*)t0)[4],t30);}}
else{
t31=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t32=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8615,a[2]=t6,a[3]=t4,a[4]=t32,a[5]=t31,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t34=((C_word*)t12)[1];
f_5963(t34,t33);}}}}
case C_make_character(124):
t28=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t29=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t30=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8648,a[2]=t6,a[3]=t4,a[4]=t29,a[5]=t28,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t31=((C_word*)t12)[1];
f_5963(t31,t30);
case C_make_character(94):
t28=t4;
t29=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f25273,a[2]=t12,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* bit-and */
f_5678(t29,t28,C_fix(4));
case C_make_character(36):
t28=t4;
t29=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f25279,a[2]=t12,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* bit-and */
f_5678(t29,t28,C_fix(4));
case C_make_character(32):
t28=t4;
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f25285,a[2]=t5,a[3]=t3,a[4]=t12,a[5]=t6,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* bit-and */
f_5678(t29,t28,C_fix(16));
case C_make_character(35):
t28=t4;
t29=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f25291,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t12,a[7]=t6,a[8]=t4,a[9]=t1,a[10]=((C_word*)t0)[2],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* bit-and */
f_5678(t29,t28,C_fix(16));
default:
t28=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* lp407 */
t240=t1;
t241=t28;
t242=t3;
t243=t4;
t244=t5;
t245=t6;
t1=t240;
t2=t241;
t3=t242;
t4=t243;
t5=t244;
t6=t245;
goto loop;}}}}}

/* f25291 in lp in k5868 in string->sre in k4469 */
static void C_ccall f25291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25291,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(16),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8759,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* string-scan-char */
f_4906(t3,((C_word*)t0)[4],C_make_character(10),(C_word)C_a_i_list(&a,1,t4));}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* lp407 */
t4=((C_word*)((C_word*)t0)[10])[1];
f_5875(t4,((C_word*)t0)[9],t3,((C_word*)t0)[3],((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k8757 */
static void C_ccall f_8759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8759,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_u_fixnum_difference(((C_word*)t0)[7],C_fix(1)));
t3=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8777,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5963(t6,t5);}

/* k8775 in k8757 */
static void C_ccall f_8777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5875(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f25285 in lp in k5868 in string->sre in k4469 */
static void C_ccall f25285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25285,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(16),t1);
if(C_truep(t2)){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8737,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5963(t6,t5);}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
/* lp407 */
t4=((C_word*)((C_word*)t0)[8])[1];
f_5875(t4,((C_word*)t0)[7],t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k8735 */
static void C_ccall f_8737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5875(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f25279 in lp in k5868 in string->sre in k4469 */
static void C_ccall f25279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25279,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(4),t1);
t3=(C_truep(t2)?lf[146]:lf[137]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8707,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* collect415 */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5963(t7,t6);}

/* k8705 */
static void C_ccall f_8707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8707,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* f25273 in lp in k5868 in string->sre in k4469 */
static void C_ccall f25273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25273,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(4),t1);
t3=(C_truep(t2)?lf[145]:lf[136]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8676,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* collect415 */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5963(t7,t6);}

/* k8674 */
static void C_ccall f_8676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8676,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8646 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8648,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[57],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8613 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5875(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8595 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8597,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* f25260 in lp in k5868 in string->sre in k4469 */
static void C_ccall f25260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25260,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(2),t1);
t3=(C_truep(t2)?lf[140]:lf[141]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8537,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8541,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* substring */
t7=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,((C_word*)t0)[2],t6,((C_word*)t0)[7]);}

/* k8539 */
static void C_ccall f_8541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k8535 */
static void C_ccall f_8537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8537,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8529,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5963(t6,t5);}

/* k8527 in k8535 */
static void C_ccall f_8529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8523 in k8535 */
static void C_ccall f_8525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8525,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_5875(t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* scan in lp in k5868 in string->sre in k4469 */
static C_word C_fcall f_5022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
return(C_SCHEME_FALSE);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_word)C_u_i_char_numericp(t4))){
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}
else{
return(t1);}}}

/* k8389 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8391,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8400,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_8400(t6,((C_word*)t0)[2],t2);}

/* lp2 in k8389 in lp in k5868 in string->sre in k4469 */
static void C_fcall f_8400(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8400,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(2));
/* lp407 */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5875(t5,t1,t2,t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[3],t2);
t5=(C_word)C_eqp(C_make_character(92),t4);
if(C_truep(t5)){
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t6,((C_word*)t0)[9]))){
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(2));
/* lp407 */
t9=((C_word*)((C_word*)t0)[7])[1];
f_5875(t9,t1,t7,t8,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=(C_word)C_subchar(((C_word*)t0)[3],t7);
t9=(C_word)C_eqp(C_make_character(69),t8);
if(C_truep(t9)){
t10=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t11=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8462,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=t10,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t13=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(2));
/* substring */
t14=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t12,((C_word*)t0)[3],t13,t2);}
else{
t10=(C_word)C_u_fixnum_plus(t2,C_fix(2));
/* lp2786 */
t20=t1;
t21=t10;
t1=t20;
t2=t21;
goto loop;}}}
else{
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* lp2786 */
t20=t1;
t21=t6;
t1=t20;
t2=t21;
goto loop;}}}

/* k8460 in lp2 in k8389 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8462,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[8]);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8305 in lp in k5868 in string->sre in k4469 */
static void C_fcall f_8307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8307,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(2));
/* string-scan-char */
f_4906(t2,((C_word*)t0)[3],t1,(C_word)C_a_i_list(&a,1,t3));}

/* k8308 in k8305 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(3));
/* substring */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[3],t3,t1);}
else{
t3=t2;
f_8313(2,t3,C_SCHEME_FALSE);}}

/* k8311 in k8308 in k8305 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8313,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f25252,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* bit-and */
f_5678(t3,t2,C_fix(2));}

/* f25252 in k8311 in k8308 in k8305 in lp in k5868 in string->sre in k4469 */
static void C_ccall f25252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25252,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(2),t1);
t3=(C_truep(t2)?lf[140]:lf[141]);
t4=((C_word*)t0)[9];
if(C_truep(t4)){
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8360,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t6,a[6]=t5,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* string->symbol */
t8=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[3]);}
else{
/* error */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[7],lf[142],((C_word*)t0)[2]);}}

/* k8358 */
static void C_ccall f_8360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8360,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8348,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8352,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5963(t6,t5);}

/* k8350 in k8358 */
static void C_ccall f_8352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8346 in k8358 */
static void C_ccall f_8348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8348,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8280 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8253 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8254,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8278,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* collect415 */
t8=((C_word*)((C_word*)t0)[2])[1];
f_5963(t8,t7);}

/* k8276 in a8253 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8272 in a8253 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8274,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8241 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8237 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8239,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[133],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8212 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8208 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8210,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[134],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8183 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8179 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8181,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[139],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8154 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8150 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8152,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[138],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8125 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8121 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8123,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[137],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8092 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8088 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8090,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[137],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
/* lp407 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5875(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k8055 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8051 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8053,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[136],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k8026 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8022 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_8024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8024,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[135],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7989 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7985 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7987,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7936 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7932 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7934,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7891 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7887 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7889,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7854 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7850 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7852,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7821 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7817 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7819,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[129],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7788 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7784 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7786,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7755 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7751 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7753,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[128],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7504 in lp in k5868 in string->sre in k4469 */
static void C_fcall f_7506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7506,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* lp407 */
t3=((C_word*)((C_word*)t0)[9])[1];
f_5875(t3,((C_word*)t0)[8],t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7516,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* collect/single416 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5983(t3,t2);}}

/* k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7516,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* string-scan-char */
f_4906(t4,((C_word*)t0)[2],C_make_character(125),(C_word)C_a_i_list(&a,1,t5));}

/* k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7528,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7669,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* substring */
t5=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,t1);}

/* k7667 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7669,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5063,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5063(t6,((C_word*)t0)[2],C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* lp in k7667 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_fcall f_5063(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5063,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5066,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5087,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* collect184 */
t8=t5;
f_5066(t8,t7);}
else{
t7=(C_word)C_subchar(((C_word*)t0)[4],t2);
t8=(C_word)C_eqp(C_make_character(44),t7);
if(C_truep(t8)){
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5108,a[2]=t10,a[3]=t9,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* collect184 */
t12=t5;
f_5066(t12,t11);}
else{
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* lp174 */
t15=t1;
t16=t9;
t17=t3;
t18=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
goto loop;}}}

/* k5106 in lp in k7667 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp174 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5063(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5085 in lp in k7667 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* reverse */
t2=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* collect in lp in k7667 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_fcall f_5066(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5066,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5074,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* substring */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5072 in collect in lp in k7667 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5074,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k7526 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_car(t1);
/* string->number */
C_string_to_number(3,0,t2,t3);}

/* k7529 in k7526 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7531,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
/* string->number */
C_string_to_number(3,0,t3,t5);}
else{
t5=t3;
f_7537(2,t5,C_SCHEME_FALSE);}}

/* k7535 in k7529 in k7526 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7537,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[84],t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t9=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
if(C_truep(t1)){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t1,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[83],t7);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t8,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t10=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[85],t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7635,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* ##sys#append */
t9=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}}

/* k7633 in k7535 in k7529 in k7526 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7598 in k7535 in k7529 in k7526 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7600,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7564 in k7535 in k7529 in k7526 in k7523 in k7514 in k7504 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7566,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* f25244 in lp in k5868 in string->sre in k4469 */
static void C_ccall f25244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25244,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(32),t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f25236,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* bit-and */
f_5678(t7,((C_word*)t0)[4],C_fix(4));}
else{
/* go874 */
t6=((C_word*)t4)[1];
f_8962(t6,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* f25236 */
static void C_ccall f25236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(4),t1);
if(C_truep(t2)){
/* go874 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8962(t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[126],C_SCHEME_END_OF_LIST);}
else{
/* go874 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8962(t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* go */
static void C_fcall f_8962(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8962,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,((C_word*)t0)[8]))){
/* error */
t6=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,lf[109]);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[7],t2);
switch(t6){
case C_make_character(93):
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=(C_word)C_a_i_cons(&a,2,C_make_character(93),t3);
/* go874 */
t43=t1;
t44=t9;
t45=t10;
t46=t4;
t1=t43;
t2=t44;
t3=t45;
t4=t46;
goto loop;}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f25220,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* bit-and */
f_5678(t9,((C_word*)t0)[3],C_fix(2));}
case C_make_character(45):
t7=t2;
t8=(C_word)C_eqp(t7,((C_word*)t0)[2]);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9118,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t6,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t8)){
t10=t9;
f_9118(t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9275,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t12=t2;
t13=(C_word)C_eqp(t12,t11);
if(C_truep(t13)){
t14=(C_word)C_subchar(((C_word*)t0)[7],((C_word*)t0)[2]);
t15=t10;
f_9275(t15,(C_word)C_eqp(C_make_character(94),t14));}
else{
t14=t10;
f_9275(t14,C_SCHEME_FALSE);}}
case C_make_character(91):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=(C_word)C_subchar(((C_word*)t0)[7],t7);
t9=(C_word)C_eqp(C_make_character(94),t8);
t10=(C_truep(t9)?(C_word)C_u_fixnum_plus(t2,C_fix(2)):(C_word)C_u_fixnum_plus(t2,C_fix(1)));
t11=(C_word)C_subchar(((C_word*)t0)[7],t10);
t12=(C_word)C_eqp(t11,C_make_character(58));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9327,a[2]=t10,a[3]=t9,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_u_fixnum_plus(t10,C_fix(1));
/* string-scan-char */
f_4906(t13,((C_word*)t0)[7],C_make_character(58),(C_word)C_a_i_list(&a,1,t14));}
else{
t13=(C_word)C_eqp(t11,C_make_character(61));
t14=(C_truep(t13)?t13:(C_word)C_eqp(t11,C_make_character(46)));
if(C_truep(t14)){
/* error */
t15=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[125],((C_word*)t0)[7]);}
else{
t15=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t16=(C_word)C_a_i_cons(&a,2,C_make_character(91),t3);
/* go874 */
t43=t1;
t44=t15;
t45=t16;
t46=t4;
t1=t43;
t2=t44;
t3=t45;
t4=t46;
goto loop;}}
case C_make_character(92):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=(C_word)C_subchar(((C_word*)t0)[7],t7);
t9=(C_word)C_eqp(t8,C_make_character(100));
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9460,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=t8,a[5]=t3,a[6]=t4,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t9)){
t11=t10;
f_9460(t11,t9);}
else{
t11=(C_word)C_eqp(t8,C_make_character(68));
if(C_truep(t11)){
t12=t10;
f_9460(t12,t11);}
else{
t12=(C_word)C_eqp(t8,C_make_character(115));
if(C_truep(t12)){
t13=t10;
f_9460(t13,t12);}
else{
t13=(C_word)C_eqp(t8,C_make_character(83));
if(C_truep(t13)){
t14=t10;
f_9460(t14,t13);}
else{
t14=(C_word)C_eqp(t8,C_make_character(119));
t15=t10;
f_9460(t15,(C_truep(t14)?t14:(C_word)C_eqp(t8,C_make_character(87))));}}}}
default:
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9590,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[4])){
t8=(C_word)C_fix((C_word)C_character_code(t6));
t9=t7;
f_9590(t9,(C_word)C_and((C_word)C_fixnum_less_or_equal_p(C_fix(128),t8),(C_word)C_fixnum_less_or_equal_p(t8,C_fix(255))));}
else{
t8=t7;
f_9590(t8,C_SCHEME_FALSE);}}}}

/* k9588 in go */
static void C_fcall f_9590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9590,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[8]));
t3=(C_word)C_slot(lf[119],t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9608,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* utf8-string-ref */
f_9672(t5,((C_word*)t0)[2],((C_word*)t0)[7],t3);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)t0)[6]);
/* go874 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_8962(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3]);}}

/* k9606 in k9588 in go */
static void C_ccall f_9608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9608,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* go874 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8962(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k9458 in go */
static void C_fcall f_9460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9460,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9463,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9490,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_string(&a,2,C_make_character(92),((C_word*)t0)[4]);
/* string->sre */
t5=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],C_make_character(120));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9505,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9517,a[2]=t3,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(2));
/* string-parse-hex-escape */
f_8849(t4,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}
else{
t3=(C_word)C_u_i_assq(((C_word*)t0)[4],lf[117]);
t4=(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):((C_word*)t0)[4]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(2));
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(1));
t7=(C_word)C_subchar(((C_word*)t0)[3],t6);
t8=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t9=(C_word)C_a_i_cons(&a,2,t7,t8);
/* go874 */
t10=((C_word*)((C_word*)t0)[8])[1];
f_8962(t10,((C_word*)t0)[7],t5,t9,((C_word*)t0)[6]);}}}

/* k9515 in k9458 in go */
static void C_ccall f_9517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9504 in k9458 in go */
static void C_ccall f_9505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9505,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
/* go874 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8962(t5,t1,t3,t4,((C_word*)t0)[2]);}

/* k9488 in k9458 in go */
static void C_ccall f_9490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre->cset */
f_19377(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9461 in k9458 in go */
static void C_ccall f_9463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9463,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9474,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9486,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5519(t4,*((C_word*)lf[122]+1),t1);}

/* k9484 in k9461 in k9458 in go */
static void C_ccall f_9486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9472 in k9461 in k9458 in go */
static void C_ccall f_9474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9478,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9482,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5519(t3,*((C_word*)lf[121]+1),((C_word*)t0)[2]);}

/* k9480 in k9472 in k9461 in k9458 in go */
static void C_ccall f_9482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9476 in k9472 in k9461 in k9458 in go */
static void C_ccall f_9478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* go874 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8962(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9325 in go */
static void C_ccall f_9327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9327,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
t4=t3;
f_9336(t4,t2);}
else{
t4=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t5=(C_word)C_subchar(((C_word*)t0)[7],t4);
t6=(C_word)C_eqp(C_make_character(93),t5);
t7=t3;
f_9336(t7,(C_word)C_i_not(t6));}}

/* k9334 in k9325 in go */
static void C_fcall f_9336(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9336,NULL,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[9],lf[120],((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9342,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9375,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9379,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* substring */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[8],t5,((C_word*)t0)[7]);}}

/* k9377 in k9334 in k9325 in go */
static void C_ccall f_9379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9373 in k9334 in k9325 in go */
static void C_ccall f_9375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sre->cset */
f_19377(((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9340 in k9334 in k9325 in go */
static void C_ccall f_9342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
/* cset-complement */
f_20334(t2,t1);}
else{
t3=t2;
f_9345(2,t3,t1);}}

/* k9343 in k9340 in k9334 in k9325 in go */
static void C_ccall f_9345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9345,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9356,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9368,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5519(t4,*((C_word*)lf[122]+1),t1);}

/* k9366 in k9343 in k9340 in k9334 in k9325 in go */
static void C_ccall f_9368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9354 in k9343 in k9340 in k9334 in k9325 in go */
static void C_ccall f_9356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9360,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9364,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* filter */
f_5519(t3,*((C_word*)lf[121]+1),((C_word*)t0)[2]);}

/* k9362 in k9354 in k9343 in k9340 in k9334 in k9325 in go */
static void C_ccall f_9364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9358 in k9354 in k9343 in k9340 in k9334 in k9325 in go */
static void C_ccall f_9360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* go874 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_8962(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9273 in go */
static void C_fcall f_9275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
f_9118(t3,t2);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_subchar(((C_word*)t0)[2],t2);
t4=((C_word*)t0)[4];
f_9118(t4,(C_word)C_eqp(C_make_character(93),t3));}}

/* k9116 in go */
static void C_fcall f_9118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9118,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
/* go874 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_8962(t4,((C_word*)t0)[6],t2,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[8]))){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[6],lf[115]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[8]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9149,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(C_make_character(92),t4);
t7=(C_truep(t6)?(C_word)C_u_i_assq(t4,lf[117]):C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9181,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9182,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
t10=f_9182(C_a_i(&a,6),t9,t7);
C_apply(4,0,((C_word*)t0)[6],t5,t10);}
else{
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9203,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t8,a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_make_character(92),t4);
if(C_truep(t10)){
t11=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(2));
t12=(C_word)C_subchar(((C_word*)t0)[4],t11);
t13=t9;
f_9203(t13,(C_word)C_eqp(t12,C_make_character(120)));}
else{
t11=t9;
f_9203(t11,C_SCHEME_FALSE);}}}}}

/* k9201 in k9116 in go */
static void C_fcall f_9203(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9203,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[9],C_fix(3));
/* string-parse-hex-escape */
f_8849(((C_word*)t0)[8],((C_word*)t0)[7],t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9216,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t4=t2;
f_9216(t4,(C_word)C_and((C_word)C_fixnum_less_or_equal_p(C_fix(128),t3),(C_word)C_fixnum_less_or_equal_p(t3,C_fix(255))));}
else{
t3=t2;
f_9216(t3,C_SCHEME_FALSE);}}}

/* k9214 in k9201 in k9116 in go */
static void C_fcall f_9216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9216,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[6]));
t3=(C_word)C_slot(lf[119],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* utf8-string-ref */
f_9672(t4,((C_word*)t0)[2],t5,t3);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],t3);}}

/* k9224 in k9214 in k9201 in k9116 in go */
static void C_ccall f_9226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9226,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus((C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1)),((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* g929 in k9116 in go */
static C_word C_fcall f_9182(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(3));
return((C_word)C_a_i_list(&a,2,t2,t3));}

/* k9179 in k9116 in go */
static void C_ccall f_9181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9148 in k9116 in go */
static void C_ccall f_9149(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9149,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[5]))){
/* error */
t4=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[116],((C_word*)t0)[5],t2);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
/* go874 */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8962(t7,t1,t3,t4,t6);}}

/* f25220 in go */
static void C_ccall f25220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25220,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(2),t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
/* filter */
f_5519(t3,lf[114],((C_word*)t0)[2]);}
else{
t4=t3;
f_9004(2,t4,C_SCHEME_END_OF_LIST);}}

/* k9002 */
static void C_ccall f_9004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9007,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=lf[114];
t4=((C_word*)t0)[2];
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5568,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_5568(t8,t2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_9007(2,t3,((C_word*)t0)[2]);}}

/* lp in k9002 */
static void C_fcall f_5568(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5568,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(128),t6))){
t7=t3;
/* lp315 */
t11=t1;
t12=t4;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* lp315 */
t11=t1;
t12=t4;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* k9005 in k9002 */
static void C_ccall f_9007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9012,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9029,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9078,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(((C_word*)t0)[2])?lf[112]:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9090,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9085,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9089,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* reverse */
t9=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t1);}
else{
t5=t4;
f_9033(t5,C_SCHEME_END_OF_LIST);}}

/* k9087 in k9005 in k9002 */
static void C_ccall f_9089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g892893 */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9083 in k9005 in k9002 */
static void C_ccall f_9085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_9090 in k9005 in k9002 */
static void C_ccall f_9090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9090,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9076 in k9005 in k9002 */
static void C_ccall f_9078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9078,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[2];
f_9033(t3,(C_word)C_a_i_list(&a,1,t2));}

/* k9031 in k9005 in k9002 */
static void C_fcall f_9033(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9033,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9043,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9061,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}
else{
/* append */
t2=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_END_OF_LIST);}}

/* k9059 in k9031 in k9005 in k9002 */
static void C_ccall f_9061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cset-case-insensitive */
t2=lf[112];
f_20344(3,t2,((C_word*)t0)[2],t1);}

/* k9041 in k9031 in k9005 in k9002 */
static void C_ccall f_9043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_19342,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_19342(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* lp in k9041 in k9031 in k9005 in k9002 */
static void C_fcall f_19342(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_19342,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_cdar(t2);
t6=(C_word)C_u_i_caar(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
t8=(C_word)C_a_i_cons(&a,2,t5,t7);
/* lp3543 */
t10=t1;
t11=t4;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k9052 in k9041 in k9031 in k9005 in k9002 */
static void C_ccall f_9054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9054,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[25],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* append */
t4=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k9027 in k9005 in k9002 */
static void C_ccall f_9029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9029,2,t0,t1);}
t2=f_9012(C_a_i(&a,6),((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* g889 in k9005 in k9002 */
static C_word C_fcall f_9012(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
return((C_truep(((C_word*)t0)[2])?(C_word)C_a_i_cons(&a,2,lf[110],t1):f_13623(C_a_i(&a,3),t1)));}

/* k7485 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7462 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7463,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7483,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* collect415 */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5963(t7,t6);}

/* k7481 in a7462 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7483,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k7446 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7448,2,t0,t1);}
t2=(C_word)C_u_i_cdar(((C_word*)t0)[7]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lp407 */
t5=((C_word*)((C_word*)t0)[6])[1];
f_5875(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t4);}

/* k6711 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6717,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6355(t3,t2);}

/* k6715 in k6711 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5875(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* lp2 in lp in k5868 in string->sre in k4469 */
static void C_fcall f_7182(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7182,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7185,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7194,a[2]=((C_word*)t0)[9],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t10,((C_word*)t0)[8]))){
/* error */
t11=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t1,lf[106],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t11=(C_word)C_subchar(((C_word*)t0)[7],t2);
switch(t11){
case C_make_character(105):
t12=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7243,a[2]=t4,a[3]=t12,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join634 */
t14=t5;
f_7185(t14,t13,C_fix(2));
case C_make_character(109):
t12=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7260,a[2]=t4,a[3]=t12,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join634 */
t14=t5;
f_7185(t14,t13,C_fix(4));
case C_make_character(120):
t12=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7277,a[2]=t4,a[3]=t12,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join634 */
t14=t5;
f_7185(t14,t13,C_fix(16));
case C_make_character(117):
t12=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7297,a[2]=t4,a[3]=t12,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* join634 */
t14=t5;
f_7185(t14,t13,C_fix(32));
case C_make_character(45):
t12=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t13=(C_word)C_i_not(t4);
/* lp2624 */
t30=t1;
t31=t12;
t32=t3;
t33=t13;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
goto loop;
case C_make_character(41):
t12=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t13=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7342,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t13,a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7346,a[2]=t14,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* collect415 */
t16=((C_word*)((C_word*)t0)[2])[1];
f_5963(t16,t15);
case C_make_character(58):
t12=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t13=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7367,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t13,a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* new-res635 */
t15=((C_word*)t7)[1];
f_7194(t15,t14,C_SCHEME_END_OF_LIST);
default:
/* error */
t12=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[107],((C_word*)t0)[7]);}}}

/* k7365 in lp2 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7379,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* collect415 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5963(t3,t2);}

/* k7377 in k7365 in lp2 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7379,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
/* lp407 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5875(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k7344 in lp2 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* new-res635 */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7194(t2,((C_word*)t0)[2],t1);}

/* k7340 in lp2 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5875(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7295 in lp2 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2624 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7182(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7275 in lp2 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2624 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7182(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7258 in lp2 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2624 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7182(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7241 in lp2 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp2624 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_7182(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* new-res in lp2 in lp in k5868 in string->sre in k4469 */
static void C_fcall f_7194(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7194,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f25199,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* bit-and */
f_5678(t3,((C_word*)t0)[2],C_fix(32));}

/* f25199 in new-res in lp2 in lp in k5868 in string->sre in k4469 */
static void C_ccall f25199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25199,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(32),t1);
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f25193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* bit-and */
f_5678(t4,t3,C_fix(32));}

/* f25193 */
static void C_ccall f25193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25193,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(32),t1);
t3=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t2)?(C_word)C_a_i_cons(&a,2,lf[104],((C_word*)t0)[3]):(C_word)C_a_i_cons(&a,2,lf[105],((C_word*)t0)[3])));}}

/* join in lp2 in lp in k5868 in string->sre in k4469 */
static void C_fcall f_7185(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7185,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[3])){
t3=lf[43];
t4=lf[43];
t5=t1;
t6=((C_word*)t0)[2];
t7=t2;
t8=(C_word)C_u_fixnum_difference(C_fix(65535),t7);
/* bit-and */
f_5678(t5,t6,t8);}
else{
t3=lf[42];
t4=lf[42];
t5=t1;
t6=((C_word*)t0)[2];
t7=t2;
if(C_truep(t7)){
/* bit-ior */
f_5631(t5,t6,t7);}
else{
t8=t5;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t6);}}}

/* k7138 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7144,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6355(t3,t2);}

/* k7142 in k7138 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5875(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[102],t1);}

/* k7081 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7086,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7117,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(3));
/* substring */
t5=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,t1);}

/* k7115 in k7081 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7084 in k7081 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7086,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7101,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
/* bit-and */
f_5678(t4,t5,C_fix(65534));}

/* k7099 in k7084 in k7081 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7101,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[63],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7109,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* save418 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6355(t5,t4);}

/* k7107 in k7099 in k7084 in k7081 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5875(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7021 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7026,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7066,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[2],C_fix(3));
/* substring */
t5=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[3],t4,t1);}

/* k7064 in k7021 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k7024 in k7021 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7026,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7050,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t6=((C_word*)t0)[3];
/* bit-and */
f_5678(t5,t6,C_fix(65534));}
else{
/* error */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],lf[101],((C_word*)t0)[2]);}}

/* k7048 in k7024 in k7021 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7050,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[63],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7058,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* save418 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6355(t5,t4);}

/* k7056 in k7048 in k7024 in k7021 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5875(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6993 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6999,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6355(t3,t2);}

/* k6997 in k6993 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5875(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[99],t1);}

/* k6901 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6903,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t3=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6921,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t5=((C_word*)t0)[2];
/* bit-and */
f_5678(t4,t5,C_fix(65534));}
else{
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],lf[98],((C_word*)t0)[3]);}}

/* k6919 in k6901 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6933,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6941,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(3));
/* substring */
t5=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k6939 in k6919 in k6901 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->symbol */
t2=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6931 in k6919 in k6901 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6933,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[71],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6929,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* save418 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6355(t5,t4);}

/* k6927 in k6931 in k6919 in k6901 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5875(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6894 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6900,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6355(t3,t2);}

/* k6898 in k6894 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5875(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[97],t1);}

/* k6869 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6875,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6355(t3,t2);}

/* k6873 in k6869 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5875(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[96],t1);}

/* k6826 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6832,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6355(t3,t2);}

/* k6830 in k6826 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5875(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[94],t1);}

/* k6801 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6807,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6355(t3,t2);}

/* k6805 in k6801 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5875(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[93],t1);}

/* k6776 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6782,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* save418 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6355(t3,t2);}

/* k6780 in k6776 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5875(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* k6736 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6738,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(t1,((C_word*)t0)[7]);
t3=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5963(t5,t4);}

/* k6751 in k6736 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp407 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5875(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6624 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6626,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_a_i_string(&a,1,((C_word*)t0)[2]);
/* string->symbol */
t5=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k6630 in k6624 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6632,2,t0,t1);}
t2=f_12249(((C_word*)t0)[9]);
if(C_truep(t2)){
/* error */
t3=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],lf[87],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* sre-empty? */
t4=lf[89];
f_12045(3,t4,t3,((C_word*)t0)[9]);}}

/* k6645 in k6630 in k6624 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6647,2,t0,t1);}
if(C_truep(t1)){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[10],lf[88],((C_word*)t0)[9],((C_word*)t0)[8]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
/* lp407 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5875(t7,((C_word*)t0)[10],t2,t3,((C_word*)t0)[3],t6,((C_word*)t0)[2]);}}

/* k6427 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6429,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* error */
t2=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],lf[76],((C_word*)t0)[6],t1);}
else{
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[77]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6483,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t10=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(t6,lf[79]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6508,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t11=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(t6,lf[81]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6525,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t12=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(t6,lf[83]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6542,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t13=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_eqp(t6,lf[84]);
if(C_truep(t11)){
t12=(C_word)C_u_i_cadr(t2);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6567,a[2]=t5,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_slot(t2,C_fix(1));
/* ##sys#append */
t15=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(t6,lf[85]);
if(C_truep(t12)){
t13=(C_word)C_u_i_cadr(t2);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6596,a[2]=t5,a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t15=(C_word)C_u_i_cddr(t2);
/* ##sys#append */
t16=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t14,t15,C_SCHEME_END_OF_LIST);}
else{
t13=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t14=t5;
f_6460(t14,(C_word)C_a_i_cons(&a,2,lf[81],t13));}}}}}}}
else{
t6=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t7=t5;
f_6460(t7,(C_word)C_a_i_cons(&a,2,lf[81],t6));}}}

/* k6594 in k6427 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6596,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_6460(t4,(C_word)C_a_i_cons(&a,2,lf[80],t3));}

/* k6565 in k6427 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6567,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_6460(t3,(C_word)C_a_i_cons(&a,2,lf[80],t2));}

/* k6540 in k6427 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6542,2,t0,t1);}
t2=((C_word*)t0)[2];
f_6460(t2,(C_word)C_a_i_cons(&a,2,lf[80],t1));}

/* k6523 in k6427 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6525,2,t0,t1);}
t2=((C_word*)t0)[2];
f_6460(t2,(C_word)C_a_i_cons(&a,2,lf[82],t1));}

/* k6506 in k6427 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6508,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1);
t3=(C_word)C_a_i_cons(&a,2,C_fix(1),t2);
t4=((C_word*)t0)[2];
f_6460(t4,(C_word)C_a_i_cons(&a,2,lf[80],t3));}

/* k6481 in k6427 in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6483,2,t0,t1);}
t2=((C_word*)t0)[2];
f_6460(t2,(C_word)C_a_i_cons(&a,2,lf[78],t1));}

/* k6458 in k6427 in lp in k5868 in string->sre in k4469 */
static void C_fcall f_6460(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6460,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* lp407 */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5875(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* f25183 in lp in k5868 in string->sre in k4469 */
static void C_ccall f25183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25183,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(8),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f25173,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5963(t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f25177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* collect415 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5963(t4,t3);}}

/* f25177 */
static void C_ccall f25177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25177,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[75],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* f25173 */
static void C_ccall f25173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25173,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[74],t1);
/* lp407 */
t3=((C_word*)((C_word*)t0)[7])[1];
f_5875(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* save in lp in k5868 in string->sre in k4469 */
static void C_fcall f_6355(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6355,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6367,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* collect415 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5963(t3,t2);}

/* k6365 in save in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6367,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]));}

/* collect/terms in lp in k5868 in string->sre in k4469 */
static void C_fcall f_6055(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6055,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6059,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* collect415 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5963(t3,t2);}

/* k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6062,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6353,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* last */
f_5349(t3,t1);}
else{
t3=t2;
f_6062(t3,C_SCHEME_FALSE);}}

/* k6351 in k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6062(t2,(C_word)C_u_i_memq(t1,lf[72]));}

/* k6060 in k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static void C_fcall f_6062(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6062,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6065,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6315,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t4=(C_word)C_u_i_car(t1);
t5=t3;
f_6315(t5,(C_word)C_eqp(lf[71],t4));}
else{
t4=t3;
f_6315(t4,C_SCHEME_FALSE);}}

/* k6313 in k6060 in k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static void C_fcall f_6315(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6315,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6326,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[2])){
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_6065(t3,(C_word)C_a_i_list(&a,1,t2));}
else{
t2=((C_word*)t0)[4];
f_6065(t2,C_SCHEME_FALSE);}}}

/* k6324 in k6313 in k6060 in k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6326,2,t0,t1);}
t2=(C_word)C_u_i_cadr(t1);
t3=((C_word*)t0)[2];
f_6065(t3,(C_word)C_a_i_list(&a,2,lf[71],t2));}

/* k6063 in k6060 in k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static void C_fcall f_6065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6065,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6068,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(lf[71],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6297,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6308,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
t6=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}
else{
t3=t2;
f_6068(2,t3,((C_word*)t0)[2]);}}

/* k6306 in k6063 in k6060 in k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k6295 in k6063 in k6060 in k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cddr(t1);
/* reverse */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k6066 in k6063 in k6060 in k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static void C_ccall f_6068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6068,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6073,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6073(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* lp in k6066 in k6063 in k6060 in k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static void C_fcall f_6073(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6073,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6076,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t6=f_6076(C_a_i(&a,6),t5);
t7=f_13623(C_a_i(&a,3),t6);
t8=((C_word*)t0)[4];
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f25167,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* bit-and */
f_5678(t9,t8,C_fix(1));}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(lf[57],t6);
if(C_truep(t7)){
t8=(C_word)C_slot(t2,C_fix(1));
t9=f_6076(C_a_i(&a,6),t5);
/* lp479 */
t18=t1;
t19=t8;
t20=C_SCHEME_END_OF_LIST;
t21=t9;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
/* lp479 */
t18=t1;
t19=t8;
t20=t10;
t21=t4;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}}}

/* f25167 in lp in k6066 in k6063 in k6060 in k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static void C_ccall f25167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25167,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(1),t1);
t3=(C_truep(t2)?(C_word)C_a_i_list(&a,2,lf[62],((C_word*)t0)[4]):((C_word*)t0)[4]);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_u_i_car(((C_word*)t0)[3]);
t5=(C_word)C_eqp(lf[63],t4);
if(C_truep(t5)){
if(C_truep((C_word)C_i_pairp(t3))){
t6=(C_word)C_u_i_car(t3);
if(C_truep((C_truep((C_word)C_eqp(t6,lf[64]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[65]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[66]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[67]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_eqp(lf[68],t7);
if(C_truep(t8)){
t9=(C_word)C_u_i_cadr(t3);
t10=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_u_i_cddr(t3);
t12=f_13598(C_a_i(&a,3),t11);
t13=(C_word)C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t9,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_cons(&a,2,lf[63],t14));}
else{
t11=(C_word)C_a_i_cons(&a,2,lf[69],C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_cons(&a,2,lf[63],t12));}}
else{
t9=(C_word)C_u_i_cadadr(t3);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6175,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_pairp(t11))){
t12=(C_word)C_u_i_cddadr(t3);
/* sre-sequence */
t13=t10;
f_6175(t13,f_13598(C_a_i(&a,3),t12));}
else{
t12=t10;
f_6175(t12,lf[69]);}}}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[69]);}}
else{
t6=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],((C_word*)t0)[3],t6);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6173 */
static void C_fcall f_6175(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6175,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* sre-alternate */
t5=t2;
f_6183(t5,f_13623(C_a_i(&a,3),t4));}
else{
/* sre-alternate */
t4=t2;
f_6183(t4,f_13623(C_a_i(&a,3),C_SCHEME_END_OF_LIST));}}

/* k6181 in k6173 */
static void C_fcall f_6183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6183,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,lf[63],t4));}

/* shift in lp in k6066 in k6063 in k6060 in k6057 in collect/terms in lp in k5868 in string->sre in k4469 */
static C_word C_fcall f_6076(C_word *a,C_word t0){
C_word tmp;
C_word t1;
C_word t2;
t1=f_13598(C_a_i(&a,3),((C_word*)t0)[3]);
return((C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* collect/single in lp in k5868 in string->sre in k4469 */
static void C_fcall f_5983(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5983,NULL,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f25161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* bit-and */
f_5678(t3,t2,C_fix(32));}

/* f25161 in collect/single in lp in k5868 in string->sre in k4469 */
static void C_ccall f25161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25161,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(32),t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5990,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6040,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=((C_word*)t0)[2];
t6=t4;
f_6040(t6,(C_word)C_fixnum_greaterp(t5,C_fix(1)));}
else{
t5=t4;
f_6040(t5,C_SCHEME_FALSE);}}

/* k6038 */
static void C_fcall f_6040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6040,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9862,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
f_5990(t5,f_9862(t4,t2));}
else{
t2=((C_word*)t0)[2];
f_5990(t2,(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1)));}}

/* lp in k6038 */
static C_word C_fcall f_9862(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
t2=t1;
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
return(C_fix(0));}
else{
t4=(C_word)C_subchar(((C_word*)t0)[2],t1);
t5=(C_word)C_fix((C_word)C_character_code(t4));
t6=(C_word)C_fixnum_lessp(t5,C_fix(128));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greater_or_equal_p(t5,C_fix(192)));
if(C_truep(t7)){
return(t1);}
else{
t8=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t10=t8;
t1=t10;
goto loop;}}}

/* k5988 */
static void C_fcall f_5990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5990,NULL,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[9];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
t4=((C_word*)t0)[8];
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5999,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6027,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_u_fixnum_difference(((C_word*)t0)[2],t1);
/* utf8-string-ref */
f_9672(t5,((C_word*)t0)[5],t1,t6);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[5],t1);
/* cased-char413 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5878(t7,t4,t6);}}}

/* k6025 in k5988 */
static void C_ccall f_6027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-char413 */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5878(t2,((C_word*)t0)[2],t1);}

/* k5997 in k5988 */
static void C_ccall f_5999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5999,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6019,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6023,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* substring */
t7=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* k6021 in k5997 in k5988 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-string414 */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5908(t2,((C_word*)t0)[2],t1);}

/* k6017 in k5997 in k5988 */
static void C_ccall f_6019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6019,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* collect in lp in k5868 in string->sre in k4469 */
static void C_fcall f_5963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5963,NULL,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=((C_word*)t0)[4];
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5977,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5981,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* substring */
t7=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k5979 in collect in lp in k5868 in string->sre in k4469 */
static void C_ccall f_5981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* cased-string414 */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5908(t2,((C_word*)t0)[2],t1);}

/* k5975 in collect in lp in k5868 in string->sre in k4469 */
static void C_ccall f_5977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5977,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* cased-string in lp in k5868 in string->sre in k4469 */
static void C_fcall f_5908(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5908,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f25153,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* bit-and */
f_5678(t4,t3,C_fix(2));}

/* f25153 in cased-string in lp in k5868 in string->sre in k4469 */
static void C_ccall f25153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25153,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(2),t1);
if(C_truep(t2)){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5922,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5926,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* string->list */
t9=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5924 */
static void C_ccall f_5926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5926,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5928(t5,((C_word*)t0)[2],t1);}

/* loop429 in k5924 */
static void C_fcall f_5928(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5928,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5957,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* g445446 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5878(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5955 in loop429 in k5924 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5957,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop429442 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5928(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop429442 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5928(t6,((C_word*)t0)[3],t5);}}

/* k5920 */
static void C_ccall f_5922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5922,2,t0,t1);}
/* sre-sequence */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_13598(C_a_i(&a,3),t1));}

/* cased-char in lp in k5868 in string->sre in k4469 */
static void C_fcall f_5878(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5878,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f25145,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* bit-and */
f_5678(t4,t3,C_fix(2));}

/* f25145 in cased-char in lp in k5868 in string->sre in k4469 */
static void C_ccall f25145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f25145,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(2),t1);
t3=(C_truep(t2)?(C_word)C_u_i_char_alphabeticp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
t5=(C_word)C_u_i_char_upper_casep(t4);
t6=(C_truep(t5)?(C_word)C_u_i_char_downcase(t4):(C_word)C_u_i_char_upcase(t4));
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[57],t8));}
else{
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* symbol-list->flags in k4469 */
static void C_fcall f_5763(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5763,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5769,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5769(t6,t1,t2,C_fix(0));}

/* lp in symbol-list->flags in k4469 */
static void C_fcall f_5769(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5769,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5787,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_eqp(t6,lf[45]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5800,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=t8;
f_5800(t9,t7);}
else{
t9=(C_word)C_eqp(t6,lf[54]);
t10=t8;
f_5800(t10,(C_truep(t9)?t9:(C_word)C_eqp(t6,lf[55])));}}
else{
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5798 in lp in symbol-list->flags in k4469 */
static void C_fcall f_5800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
/* bit-ior */
f_5631(((C_word*)t0)[6],t2,C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[46]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[47]));
if(C_truep(t3)){
t4=((C_word*)t0)[7];
/* bit-ior */
f_5631(((C_word*)t0)[6],t4,C_fix(4));}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[48]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[49]));
if(C_truep(t5)){
t6=((C_word*)t0)[7];
/* bit-ior */
f_5631(((C_word*)t0)[6],t6,C_fix(8));}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[50]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[51]));
if(C_truep(t7)){
t8=((C_word*)t0)[7];
/* bit-ior */
f_5631(((C_word*)t0)[6],t8,C_fix(16));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[52]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[53]));
if(C_truep(t9)){
t10=((C_word*)t0)[7];
/* bit-ior */
f_5631(((C_word*)t0)[6],t10,C_fix(32));}
else{
t10=((C_word*)t0)[7];
/* lp363 */
t11=((C_word*)((C_word*)t0)[4])[1];
f_5769(t11,((C_word*)t0)[3],((C_word*)t0)[2],t10);}}}}}}

/* k5785 in lp in symbol-list->flags in k4469 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp363 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5769(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* flag-clear in k4469 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5744,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(C_fix(65535),t3);
/* bit-and */
f_5678(t1,t2,t4);}

/* flag-join in k4469 */
static void C_ccall f_5735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5735,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* bit-ior */
f_5631(t1,t2,t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* bit-and in k4469 */
static void C_fcall f_5678(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5678,NULL,3,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(0));}
else{
t5=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_fix(0));}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5698,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_fixnumoddp(t2))){
t7=(C_word)C_i_fixnumoddp(t3);
t8=t6;
f_5698(t8,(C_truep(t7)?C_fix(1):C_fix(0)));}
else{
t7=t6;
f_5698(t7,C_fix(0));}}}}

/* k5696 in bit-and in k4469 */
static void C_fcall f_5698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5698,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5706,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_shift_right(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(1));
/* bit-and */
f_5678(t2,t3,t4);}

/* k5704 in k5696 in bit-and in k4469 */
static void C_ccall f_5706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_times(C_fix(2),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2));}

/* bit-ior in k4469 */
static void C_fcall f_5631(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5631,NULL,3,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5651,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_fixnumoddp(t2);
if(C_truep(t7)){
t8=t6;
f_5651(t8,(C_truep(t7)?C_fix(1):C_fix(0)));}
else{
t8=(C_word)C_i_fixnumoddp(t3);
t9=t6;
f_5651(t9,(C_truep(t8)?C_fix(1):C_fix(0)));}}}}

/* k5649 in bit-ior in k4469 */
static void C_fcall f_5651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5651,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5659,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_shift_right(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(1));
/* bit-ior */
f_5631(t2,t3,t4);}

/* k5657 in k5649 in bit-ior in k4469 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_times(C_fix(2),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t2));}

/* filter in k4469 */
static void C_fcall f_5519(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5519,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5525,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5525(t7,t1,t3,C_SCHEME_END_OF_LIST);}

/* lp in filter in k4469 */
static void C_fcall f_5525(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5525,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* reverse */
t4=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5549,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_u_i_car(t2);
/* pred306 */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k5547 in lp in filter in k4469 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5549,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
/* lp308 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5525(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
/* lp308 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5525(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* fold in k4469 */
static void C_fcall f_5489(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5489,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5495,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5495(t8,t1,t4,t3);}

/* lp in fold in k4469 */
static void C_fcall f_5495(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5495,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5513,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* kons298 */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t3);}}

/* k5511 in lp in fold in k4469 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lp301 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5495(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* every in k4469 */
static void C_fcall f_5440(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5440,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5460,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_5460(t10,t1,t5,t6);}}

/* lp in every in k4469 */
static void C_fcall f_5460(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5460,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* pred284 */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5476,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* pred284 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k5474 in lp in every in k4469 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lp291 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5460(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* any in k4469 */
static void C_fcall f_5391(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5391,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_slot(t3,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5411,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5411(t9,t1,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* lp in any in k4469 */
static void C_fcall f_5411(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5411,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* pred270 */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5424,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* pred270 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k5422 in lp in any in k4469 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* lp274 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5411(t4,((C_word*)t0)[4],t2,t3);}}

/* last in k4469 */
static void C_fcall f_5349(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5349,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5364,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_5364(t2));}
else{
/* error */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[36],t2);}}

/* lp in last in k4469 */
static C_word C_fcall f_5364(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
t2=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}
else{
return((C_word)C_u_i_car(t1));}}

/* find-tail in k4469 */
static void C_fcall f_5317(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5317,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5323,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5323(t7,t1,t3);}

/* lp in find-tail in k4469 */
static void C_fcall f_5323(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5323,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* pred253 */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k5334 in lp in find-tail in k4469 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* lp255 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5323(t3,((C_word*)t0)[4],t2);}}

/* take-up-to in k4469 */
static void C_fcall f_5262(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5262,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5268,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5268(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* lp in take-up-to in k4469 */
static void C_fcall f_5268(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5268,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5275,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_eqp(t2,((C_word*)t0)[2]);
t6=t4;
f_5275(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_5275(t5,C_SCHEME_FALSE);}}

/* k5273 in lp in take-up-to in k4469 */
static void C_fcall f_5275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5275,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
/* lp235 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5268(t5,((C_word*)t0)[2],t2,t4);}
else{
/* reverse */
t2=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* zero-to in k4469 */
static void C_fcall f_5223(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5223,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5239,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_5239(t8,t1,t4,C_SCHEME_END_OF_LIST);}}

/* lp in zero-to in k4469 */
static void C_fcall f_5239(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5239,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,C_fix(0),t3));}
else{
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t2,t3);
/* lp228 */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* string-cat-reverse in k4469 */
static void C_fcall f_5166(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5166,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5174,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5176,tmp=(C_word)a,a+=2,tmp);
/* fold */
f_5489(t3,t4,C_fix(0),t2);}

/* a5175 in string-cat-reverse in k4469 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5176,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(t2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_fixnum_plus(t4,t3));}

/* k5172 in string-cat-reverse in k4469 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5174,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5190,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* make-string */
t5=*((C_word*)lf[29]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}

/* k5188 in k5172 in string-cat-reverse in k4469 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5193,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5195,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5195(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k5188 in k5172 in string-cat-reverse in k4469 */
static void C_fcall f_5195(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5195,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(C_word)C_u_fixnum_difference(t2,t5);
t7=((C_word*)t0)[3];
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5139,a[2]=t7,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t9=f_5139(t8,C_fix(0),t6);
t10=(C_word)C_slot(t3,C_fix(1));
/* lp216 */
t13=t1;
t14=t6;
t15=t10;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* doloop200 in lp in k5188 in k5172 in string-cat-reverse in k4469 */
static C_word C_fcall f_5139(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
t3=t1;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=C_SCHEME_UNDEFINED;
return(t4);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
t5=(C_word)C_setsubchar(((C_word*)t0)[2],t2,t4);
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k5191 in k5188 in k5172 in string-cat-reverse in k4469 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-scan-char in k4469 */
static void C_fcall f_4906(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4906,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fix((C_word)C_header_size(t2));
t6=(C_word)C_i_pairp(t4);
t7=(C_truep(t6)?(C_word)C_u_i_car(t4):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4919,a[2]=t3,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,f_4919(t8,t7));}

/* scan in string-scan-char in k4469 */
static C_word C_fcall f_4919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=t1;
t3=(C_word)C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
return(C_SCHEME_FALSE);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[3],t1);
if(C_truep((C_word)C_i_eqvp(((C_word*)t0)[2],t4))){
return(t1);}
else{
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* irregex-match-end in k4469 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4891r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4891r(t0,t1,t2,t3);}}

static void C_ccall f_4891r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4899,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_4747(t4,t2,t3);}

/* k4897 in irregex-match-end in k4469 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* irregex-match-valid-index? */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_4793(((C_word*)t0)[2],t1));}

/* irregex-match-start in k4469 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4868r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4868r(t0,t1,t2,t3);}}

static void C_ccall f_4868r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4872,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_4747(t4,t2,t3);}

/* k4870 in irregex-match-start in k4469 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_4793(((C_word*)t0)[3],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_shift_left(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(C_fix(3),t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_slot(((C_word*)t0)[3],t4));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* irregex-match-substring in k4469 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4825r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4825r(t0,t1,t2,t3);}}

static void C_ccall f_4825r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4829,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* irregex-match-index */
f_4747(t4,t2,t3);}

/* k4827 in irregex-match-substring in k4469 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4829,2,t0,t1);}
t2=f_4793(((C_word*)t0)[3],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* irregex-match-string */
t4=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k4840 in k4827 in irregex-match-substring in k4469 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_fixnum_shift_left(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_u_fixnum_plus(C_fix(3),t2);
t4=(C_word)C_slot(((C_word*)t0)[3],t3);
t5=(C_word)C_fixnum_shift_left(((C_word*)t0)[4],C_fix(1));
t6=(C_word)C_u_fixnum_plus(C_fix(4),t5);
t7=(C_word)C_slot(((C_word*)t0)[3],t6);
/* substring */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],t1,t4,t7);}

/* irregex-match-valid-index? in k4469 */
static C_word C_fcall f_4793(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t3=(C_word)C_fixnum_shift_left(t2,C_fix(1));
t4=(C_word)C_u_fixnum_plus(C_fix(3),t3);
t5=(C_word)C_fix((C_word)C_header_size(t1));
if(C_truep((C_word)C_fixnum_lessp(t4,t5))){
t6=(C_word)C_fixnum_shift_left(t2,C_fix(1));
t7=(C_word)C_u_fixnum_plus(C_fix(4),t6);
return((C_word)C_slot(t1,t7));}
else{
return(C_SCHEME_FALSE);}}

/* irregex-match-index in k4469 */
static void C_fcall f_4747(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4747,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
if(C_truep((C_word)C_i_numberp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_i_car(t3));}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_u_i_assq(t5,t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_slot(t7,C_fix(1)));}
else{
t8=(C_word)C_u_i_car(t3);
/* error */
t9=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t1,lf[19],t8);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}}

/* irregex-match-string in k4469 */
static void C_ccall f_4673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4673,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* irregex-match-num-submatches in k4469 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4655,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(t2));
t4=(C_word)C_u_fixnum_difference(t3,C_fix(3));
t5=(C_word)C_fixnum_shift_right(t4,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u_fixnum_difference(t5,C_fix(1)));}

/* irregex-match-data? in k4469 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4602,3,t0,t1,t2);}
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(5)))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(lf[11],t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* irregex-reset-matches! in k4469 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4568,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(t2));
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4578,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_4578(t5,t4));}

/* doloop49 in irregex-reset-matches! in k4469 */
static C_word C_fcall f_4578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
t2=t1;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(3)))){
t3=((C_word*)t0)[2];
return(t3);}
else{
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[2],t1,C_SCHEME_FALSE);
t4=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t7=t4;
t1=t7;
goto loop;}}

/* irregex-new-matches in k4469 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4554,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4562,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* irregex-submatches */
t4=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4560 in irregex-new-matches in k4469 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4566,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* irregex-names */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4564 in k4560 in irregex-new-matches in k4469 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4566,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4632,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_fixnum_plus(C_fix(1),t3);
t6=(C_word)C_fixnum_times(C_fix(2),t5);
t7=(C_word)C_u_fixnum_plus(t6,C_fix(3));
/* make-vector */
t8=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t7,C_SCHEME_FALSE);}

/* k4630 in k4564 in k4560 in irregex-new-matches in k4469 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(0),lf[11]);
t3=(C_word)C_i_set_i_slot(t1,C_fix(1),C_SCHEME_FALSE);
t4=(C_word)C_i_setslot(t1,C_fix(2),((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* irregex-names in k4469 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4548,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(8)));}

/* irregex-lengths in k4469 */
static void C_ccall f_4542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4542,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(7)));}

/* irregex-submatches in k4469 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4536,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(6)));}

/* irregex-flags in k4469 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4530,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(5)));}

/* irregex-nfa in k4469 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4524,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(4)));}

/* irregex-dfa/extract in k4469 */
static void C_ccall f_4518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4518,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* irregex-dfa/search in k4469 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4512,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* irregex-dfa in k4469 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4506,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* irregex? in k4469 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4480,3,t0,t1,t2);}
if(C_truep((C_word)C_i_vectorp(t2))){
t3=(C_word)C_fix((C_word)C_header_size(t2));
t4=(C_word)C_eqp(C_fix(9),t3);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(lf[1],t5));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[1076] = {
{"toplevel:regex_scm",(void*)C_regex_toplevel},
{"f_4471:regex_scm",(void*)f_4471},
{"f_22312:regex_scm",(void*)f_22312},
{"f_22319:regex_scm",(void*)f_22319},
{"f_22327:regex_scm",(void*)f_22327},
{"f_22359:regex_scm",(void*)f_22359},
{"f_22346:regex_scm",(void*)f_22346},
{"f_22349:regex_scm",(void*)f_22349},
{"f_22245:regex_scm",(void*)f_22245},
{"f_22255:regex_scm",(void*)f_22255},
{"f_22258:regex_scm",(void*)f_22258},
{"f_22263:regex_scm",(void*)f_22263},
{"f_22296:regex_scm",(void*)f_22296},
{"f_22282:regex_scm",(void*)f_22282},
{"f_22289:regex_scm",(void*)f_22289},
{"f_22300:regex_scm",(void*)f_22300},
{"f_21968:regex_scm",(void*)f_21968},
{"f_21983:regex_scm",(void*)f_21983},
{"f_21985:regex_scm",(void*)f_21985},
{"f_22240:regex_scm",(void*)f_22240},
{"f_22236:regex_scm",(void*)f_22236},
{"f_22225:regex_scm",(void*)f_22225},
{"f_22047:regex_scm",(void*)f_22047},
{"f_22077:regex_scm",(void*)f_22077},
{"f_22106:regex_scm",(void*)f_22106},
{"f_22154:regex_scm",(void*)f_22154},
{"f_22133:regex_scm",(void*)f_22133},
{"f_22129:regex_scm",(void*)f_22129},
{"f_22096:regex_scm",(void*)f_22096},
{"f_22092:regex_scm",(void*)f_22092},
{"f_22067:regex_scm",(void*)f_22067},
{"f_22045:regex_scm",(void*)f_22045},
{"f_22032:regex_scm",(void*)f_22032},
{"f_22019:regex_scm",(void*)f_22019},
{"f_22015:regex_scm",(void*)f_22015},
{"f_21979:regex_scm",(void*)f_21979},
{"f_21883:regex_scm",(void*)f_21883},
{"f_21896:regex_scm",(void*)f_21896},
{"f_21915:regex_scm",(void*)f_21915},
{"f_21831:regex_scm",(void*)f_21831},
{"f_21846:regex_scm",(void*)f_21846},
{"f_21863:regex_scm",(void*)f_21863},
{"f_21576:regex_scm",(void*)f_21576},
{"f_21718:regex_scm",(void*)f_21718},
{"f_21722:regex_scm",(void*)f_21722},
{"f_21813:regex_scm",(void*)f_21813},
{"f_21809:regex_scm",(void*)f_21809},
{"f_21780:regex_scm",(void*)f_21780},
{"f_21762:regex_scm",(void*)f_21762},
{"f_21755:regex_scm",(void*)f_21755},
{"f_21612:regex_scm",(void*)f_21612},
{"f_21618:regex_scm",(void*)f_21618},
{"f_21685:regex_scm",(void*)f_21685},
{"f_21673:regex_scm",(void*)f_21673},
{"f_21632:regex_scm",(void*)f_21632},
{"f_21597:regex_scm",(void*)f_21597},
{"f_21394:regex_scm",(void*)f_21394},
{"f_21558:regex_scm",(void*)f_21558},
{"f_21532:regex_scm",(void*)f_21532},
{"f_21557:regex_scm",(void*)f_21557},
{"f_21512:regex_scm",(void*)f_21512},
{"f_21413:regex_scm",(void*)f_21413},
{"f_21421:regex_scm",(void*)f_21421},
{"f_21425:regex_scm",(void*)f_21425},
{"f_21486:regex_scm",(void*)f_21486},
{"f_21467:regex_scm",(void*)f_21467},
{"f_21501:regex_scm",(void*)f_21501},
{"f_21496:regex_scm",(void*)f_21496},
{"f_21274:regex_scm",(void*)f_21274},
{"f_21349:regex_scm",(void*)f_21349},
{"f_21340:regex_scm",(void*)f_21340},
{"f_21276:regex_scm",(void*)f_21276},
{"f_21280:regex_scm",(void*)f_21280},
{"f_21335:regex_scm",(void*)f_21335},
{"f_21289:regex_scm",(void*)f_21289},
{"f_21299:regex_scm",(void*)f_21299},
{"f_21301:regex_scm",(void*)f_21301},
{"f_21162:regex_scm",(void*)f_21162},
{"f_21229:regex_scm",(void*)f_21229},
{"f_21220:regex_scm",(void*)f_21220},
{"f_21164:regex_scm",(void*)f_21164},
{"f_21168:regex_scm",(void*)f_21168},
{"f_21215:regex_scm",(void*)f_21215},
{"f_21177:regex_scm",(void*)f_21177},
{"f_21187:regex_scm",(void*)f_21187},
{"f_21189:regex_scm",(void*)f_21189},
{"f_21211:regex_scm",(void*)f_21211},
{"f_21100:regex_scm",(void*)f_21100},
{"f_21104:regex_scm",(void*)f_21104},
{"f_21107:regex_scm",(void*)f_21107},
{"f_21117:regex_scm",(void*)f_21117},
{"f_21119:regex_scm",(void*)f_21119},
{"f_21054:regex_scm",(void*)f_21054},
{"f_21058:regex_scm",(void*)f_21058},
{"f_21061:regex_scm",(void*)f_21061},
{"f_21071:regex_scm",(void*)f_21071},
{"f_21073:regex_scm",(void*)f_21073},
{"f_21098:regex_scm",(void*)f_21098},
{"f_21033:regex_scm",(void*)f_21033},
{"f_21040:regex_scm",(void*)f_21040},
{"f_21049:regex_scm",(void*)f_21049},
{"f_20930:regex_scm",(void*)f_20930},
{"f_20973:regex_scm",(void*)f_20973},
{"f_20968:regex_scm",(void*)f_20968},
{"f_20963:regex_scm",(void*)f_20963},
{"f_20932:regex_scm",(void*)f_20932},
{"f_20944:regex_scm",(void*)f_20944},
{"f_20947:regex_scm",(void*)f_20947},
{"f_20940:regex_scm",(void*)f_20940},
{"f_20912:regex_scm",(void*)f_20912},
{"f_20730:regex_scm",(void*)f_20730},
{"f_20736:regex_scm",(void*)f_20736},
{"f_20858:regex_scm",(void*)f_20858},
{"f_20862:regex_scm",(void*)f_20862},
{"f_20870:regex_scm",(void*)f_20870},
{"f_20854:regex_scm",(void*)f_20854},
{"f_20829:regex_scm",(void*)f_20829},
{"f_20833:regex_scm",(void*)f_20833},
{"f_20825:regex_scm",(void*)f_20825},
{"f_20795:regex_scm",(void*)f_20795},
{"f_20764:regex_scm",(void*)f_20764},
{"f_20674:regex_scm",(void*)f_20674},
{"f_20707:regex_scm",(void*)f_20707},
{"f_20728:regex_scm",(void*)f_20728},
{"f_20680:regex_scm",(void*)f_20680},
{"f_20684:regex_scm",(void*)f_20684},
{"f_20691:regex_scm",(void*)f_20691},
{"f_20705:regex_scm",(void*)f_20705},
{"f_20622:regex_scm",(void*)f_20622},
{"f_20672:regex_scm",(void*)f_20672},
{"f_20626:regex_scm",(void*)f_20626},
{"f_20664:regex_scm",(void*)f_20664},
{"f_20640:regex_scm",(void*)f_20640},
{"f_20648:regex_scm",(void*)f_20648},
{"f_20660:regex_scm",(void*)f_20660},
{"f_20656:regex_scm",(void*)f_20656},
{"f_20644:regex_scm",(void*)f_20644},
{"f_20509:regex_scm",(void*)f_20509},
{"f_20513:regex_scm",(void*)f_20513},
{"f_20516:regex_scm",(void*)f_20516},
{"f_20522:regex_scm",(void*)f_20522},
{"f_20525:regex_scm",(void*)f_20525},
{"f_20533:regex_scm",(void*)f_20533},
{"f_20546:regex_scm",(void*)f_20546},
{"f_20558:regex_scm",(void*)f_20558},
{"f_20561:regex_scm",(void*)f_20561},
{"f_20564:regex_scm",(void*)f_20564},
{"f_20619:regex_scm",(void*)f_20619},
{"f_20344:regex_scm",(void*)f_20344},
{"f_20350:regex_scm",(void*)f_20350},
{"f_20366:regex_scm",(void*)f_20366},
{"f_20403:regex_scm",(void*)f_20403},
{"f_20461:regex_scm",(void*)f_20461},
{"f_20418:regex_scm",(void*)f_20418},
{"f_20414:regex_scm",(void*)f_20414},
{"f_20386:regex_scm",(void*)f_20386},
{"f_20334:regex_scm",(void*)f_20334},
{"f_20342:regex_scm",(void*)f_20342},
{"f_20211:regex_scm",(void*)f_20211},
{"f_20217:regex_scm",(void*)f_20217},
{"f_20324:regex_scm",(void*)f_20324},
{"f_20227:regex_scm",(void*)f_20227},
{"f_20231:regex_scm",(void*)f_20231},
{"f_20296:regex_scm",(void*)f_20296},
{"f_20237:regex_scm",(void*)f_20237},
{"f_20288:regex_scm",(void*)f_20288},
{"f_20241:regex_scm",(void*)f_20241},
{"f_20250:regex_scm",(void*)f_20250},
{"f_20253:regex_scm",(void*)f_20253},
{"f_20260:regex_scm",(void*)f_20260},
{"f_20085:regex_scm",(void*)f_20085},
{"f_20197:regex_scm",(void*)f_20197},
{"f_20108:regex_scm",(void*)f_20108},
{"f_20112:regex_scm",(void*)f_20112},
{"f_20169:regex_scm",(void*)f_20169},
{"f_20118:regex_scm",(void*)f_20118},
{"f_20161:regex_scm",(void*)f_20161},
{"f_20122:regex_scm",(void*)f_20122},
{"f_20131:regex_scm",(void*)f_20131},
{"f_20134:regex_scm",(void*)f_20134},
{"f_19993:regex_scm",(void*)f_19993},
{"f_20075:regex_scm",(void*)f_20075},
{"f_20003:regex_scm",(void*)f_20003},
{"f_20007:regex_scm",(void*)f_20007},
{"f_20051:regex_scm",(void*)f_20051},
{"f_20023:regex_scm",(void*)f_20023},
{"f_20015:regex_scm",(void*)f_20015},
{"f_19848:regex_scm",(void*)f_19848},
{"f_19864:regex_scm",(void*)f_19864},
{"f_19798:regex_scm",(void*)f_19798},
{"f27494:regex_scm",(void*)f27494},
{"f_19804:regex_scm",(void*)f_19804},
{"f_19377:regex_scm",(void*)f_19377},
{"f_19387:regex_scm",(void*)f_19387},
{"f_19656:regex_scm",(void*)f_19656},
{"f_19666:regex_scm",(void*)f_19666},
{"f_19695:regex_scm",(void*)f_19695},
{"f_19660:regex_scm",(void*)f_19660},
{"f_13742:regex_scm",(void*)f_13742},
{"f_13769:regex_scm",(void*)f_13769},
{"f_13765:regex_scm",(void*)f_13765},
{"f_19639:regex_scm",(void*)f_19639},
{"f_19301:regex_scm",(void*)f_19301},
{"f_19629:regex_scm",(void*)f_19629},
{"f_19573:regex_scm",(void*)f_19573},
{"f_19583:regex_scm",(void*)f_19583},
{"f_19612:regex_scm",(void*)f_19612},
{"f_19577:regex_scm",(void*)f_19577},
{"f_19565:regex_scm",(void*)f_19565},
{"f_19507:regex_scm",(void*)f_19507},
{"f_19517:regex_scm",(void*)f_19517},
{"f_19546:regex_scm",(void*)f_19546},
{"f_19511:regex_scm",(void*)f_19511},
{"f_19447:regex_scm",(void*)f_19447},
{"f_19457:regex_scm",(void*)f_19457},
{"f_19486:regex_scm",(void*)f_19486},
{"f_19451:regex_scm",(void*)f_19451},
{"f_19443:regex_scm",(void*)f_19443},
{"f_19416:regex_scm",(void*)f_19416},
{"f_19390:regex_scm",(void*)f_19390},
{"f_19260:regex_scm",(void*)f_19260},
{"f_19262:regex_scm",(void*)f_19262},
{"f_19269:regex_scm",(void*)f_19269},
{"f_16862:regex_scm",(void*)f_16862},
{"f_16902:regex_scm",(void*)f_16902},
{"f_16746:regex_scm",(void*)f_16746},
{"f_16752:regex_scm",(void*)f_16752},
{"f_16836:regex_scm",(void*)f_16836},
{"f_16799:regex_scm",(void*)f_16799},
{"f_16801:regex_scm",(void*)f_16801},
{"f_16830:regex_scm",(void*)f_16830},
{"f_16791:regex_scm",(void*)f_16791},
{"f_16779:regex_scm",(void*)f_16779},
{"f_16783:regex_scm",(void*)f_16783},
{"f_16630:regex_scm",(void*)f_16630},
{"f_16663:regex_scm",(void*)f_16663},
{"f_16667:regex_scm",(void*)f_16667},
{"f_16644:regex_scm",(void*)f_16644},
{"f_16556:regex_scm",(void*)f_16556},
{"f_16564:regex_scm",(void*)f_16564},
{"f_16082:regex_scm",(void*)f_16082},
{"f_16291:regex_scm",(void*)f_16291},
{"f_16319:regex_scm",(void*)f_16319},
{"f_16476:regex_scm",(void*)f_16476},
{"f_16377:regex_scm",(void*)f_16377},
{"f_16447:regex_scm",(void*)f_16447},
{"f_16382:regex_scm",(void*)f_16382},
{"f_16435:regex_scm",(void*)f_16435},
{"f_16395:regex_scm",(void*)f_16395},
{"f_16398:regex_scm",(void*)f_16398},
{"f_16405:regex_scm",(void*)f_16405},
{"f_16363:regex_scm",(void*)f_16363},
{"f_16324:regex_scm",(void*)f_16324},
{"f_16351:regex_scm",(void*)f_16351},
{"f_16335:regex_scm",(void*)f_16335},
{"f_16113:regex_scm",(void*)f_16113},
{"f_16162:regex_scm",(void*)f_16162},
{"f_16229:regex_scm",(void*)f_16229},
{"f_16167:regex_scm",(void*)f_16167},
{"f_16217:regex_scm",(void*)f_16217},
{"f_16183:regex_scm",(void*)f_16183},
{"f_16179:regex_scm",(void*)f_16179},
{"f_16148:regex_scm",(void*)f_16148},
{"f_16085:regex_scm",(void*)f_16085},
{"f_15564:regex_scm",(void*)f_15564},
{"f_15714:regex_scm",(void*)f_15714},
{"f_15577:regex_scm",(void*)f_15577},
{"f_15959:regex_scm",(void*)f_15959},
{"f_16072:regex_scm",(void*)f_16072},
{"f_15977:regex_scm",(void*)f_15977},
{"f_16023:regex_scm",(void*)f_16023},
{"f_16004:regex_scm",(void*)f_16004},
{"f_16016:regex_scm",(void*)f_16016},
{"f_15610:regex_scm",(void*)f_15610},
{"f_15622:regex_scm",(void*)f_15622},
{"f_15663:regex_scm",(void*)f_15663},
{"f_15692:regex_scm",(void*)f_15692},
{"f_15657:regex_scm",(void*)f_15657},
{"f_15629:regex_scm",(void*)f_15629},
{"f_15653:regex_scm",(void*)f_15653},
{"f_15645:regex_scm",(void*)f_15645},
{"f_15591:regex_scm",(void*)f_15591},
{"f_15918:regex_scm",(void*)f_15918},
{"f_15859:regex_scm",(void*)f_15859},
{"f_15863:regex_scm",(void*)f_15863},
{"f_15865:regex_scm",(void*)f_15865},
{"f_15898:regex_scm",(void*)f_15898},
{"f_15878:regex_scm",(void*)f_15878},
{"f_15734:regex_scm",(void*)f_15734},
{"f_15753:regex_scm",(void*)f_15753},
{"f_15851:regex_scm",(void*)f_15851},
{"f_15780:regex_scm",(void*)f_15780},
{"f_15798:regex_scm",(void*)f_15798},
{"f_15825:regex_scm",(void*)f_15825},
{"f_15792:regex_scm",(void*)f_15792},
{"f_15751:regex_scm",(void*)f_15751},
{"f_15736:regex_scm",(void*)f_15736},
{"f_14706:regex_scm",(void*)f_14706},
{"f_14724:regex_scm",(void*)f_14724},
{"f_15021:regex_scm",(void*)f_15021},
{"f_15075:regex_scm",(void*)f_15075},
{"f_15369:regex_scm",(void*)f_15369},
{"f_15457:regex_scm",(void*)f_15457},
{"f_15375:regex_scm",(void*)f_15375},
{"f_15453:regex_scm",(void*)f_15453},
{"f_15378:regex_scm",(void*)f_15378},
{"f_15433:regex_scm",(void*)f_15433},
{"f_15384:regex_scm",(void*)f_15384},
{"f_15403:regex_scm",(void*)f_15403},
{"f_15309:regex_scm",(void*)f_15309},
{"f_15353:regex_scm",(void*)f_15353},
{"f_15315:regex_scm",(void*)f_15315},
{"f_15337:regex_scm",(void*)f_15337},
{"f_15206:regex_scm",(void*)f_15206},
{"f_15288:regex_scm",(void*)f_15288},
{"f_15209:regex_scm",(void*)f_15209},
{"f_15273:regex_scm",(void*)f_15273},
{"f_15212:regex_scm",(void*)f_15212},
{"f_15238:regex_scm",(void*)f_15238},
{"f_15230:regex_scm",(void*)f_15230},
{"f_15234:regex_scm",(void*)f_15234},
{"f_15226:regex_scm",(void*)f_15226},
{"f25590:regex_scm",(void*)f25590},
{"f_15078:regex_scm",(void*)f_15078},
{"f_15105:regex_scm",(void*)f_15105},
{"f_15133:regex_scm",(void*)f_15133},
{"f_15143:regex_scm",(void*)f_15143},
{"f_15131:regex_scm",(void*)f_15131},
{"f_15119:regex_scm",(void*)f_15119},
{"f_15123:regex_scm",(void*)f_15123},
{"f_15094:regex_scm",(void*)f_15094},
{"f_15024:regex_scm",(void*)f_15024},
{"f_15030:regex_scm",(void*)f_15030},
{"f_15044:regex_scm",(void*)f_15044},
{"f_15004:regex_scm",(void*)f_15004},
{"f_14981:regex_scm",(void*)f_14981},
{"f25581:regex_scm",(void*)f25581},
{"f_14871:regex_scm",(void*)f_14871},
{"f_14893:regex_scm",(void*)f_14893},
{"f_14878:regex_scm",(void*)f_14878},
{"f_14848:regex_scm",(void*)f_14848},
{"f_14827:regex_scm",(void*)f_14827},
{"f_14823:regex_scm",(void*)f_14823},
{"f_14741:regex_scm",(void*)f_14741},
{"f_14756:regex_scm",(void*)f_14756},
{"f_14762:regex_scm",(void*)f_14762},
{"f_14789:regex_scm",(void*)f_14789},
{"f_14760:regex_scm",(void*)f_14760},
{"f_14727:regex_scm",(void*)f_14727},
{"f_14599:regex_scm",(void*)f_14599},
{"f_14613:regex_scm",(void*)f_14613},
{"f27441:regex_scm",(void*)f27441},
{"f_14651:regex_scm",(void*)f_14651},
{"f_14421:regex_scm",(void*)f_14421},
{"f_14425:regex_scm",(void*)f_14425},
{"f_14428:regex_scm",(void*)f_14428},
{"f_14440:regex_scm",(void*)f_14440},
{"f_14468:regex_scm",(void*)f_14468},
{"f_14485:regex_scm",(void*)f_14485},
{"f_14471:regex_scm",(void*)f_14471},
{"f_14465:regex_scm",(void*)f_14465},
{"f_14443:regex_scm",(void*)f_14443},
{"f_14458:regex_scm",(void*)f_14458},
{"f_14461:regex_scm",(void*)f_14461},
{"f_14262:regex_scm",(void*)f_14262},
{"f_14269:regex_scm",(void*)f_14269},
{"f_14385:regex_scm",(void*)f_14385},
{"f_14390:regex_scm",(void*)f_14390},
{"f_14418:regex_scm",(void*)f_14418},
{"f_14400:regex_scm",(void*)f_14400},
{"f_14382:regex_scm",(void*)f_14382},
{"f25563:regex_scm",(void*)f25563},
{"f_14378:regex_scm",(void*)f_14378},
{"f_14520:regex_scm",(void*)f_14520},
{"f27431:regex_scm",(void*)f27431},
{"f_14555:regex_scm",(void*)f_14555},
{"f_14300:regex_scm",(void*)f_14300},
{"f_14374:regex_scm",(void*)f_14374},
{"f_14309:regex_scm",(void*)f_14309},
{"f_14315:regex_scm",(void*)f_14315},
{"f_14320:regex_scm",(void*)f_14320},
{"f_14330:regex_scm",(void*)f_14330},
{"f_14342:regex_scm",(void*)f_14342},
{"f_14345:regex_scm",(void*)f_14345},
{"f_14297:regex_scm",(void*)f_14297},
{"f_14278:regex_scm",(void*)f_14278},
{"f_14290:regex_scm",(void*)f_14290},
{"f_14293:regex_scm",(void*)f_14293},
{"f_14216:regex_scm",(void*)f_14216},
{"f_14220:regex_scm",(void*)f_14220},
{"f_14226:regex_scm",(void*)f_14226},
{"f_14229:regex_scm",(void*)f_14229},
{"f_14064:regex_scm",(void*)f_14064},
{"f_14083:regex_scm",(void*)f_14083},
{"f_14160:regex_scm",(void*)f_14160},
{"f_14189:regex_scm",(void*)f_14189},
{"f_14154:regex_scm",(void*)f_14154},
{"f_14121:regex_scm",(void*)f_14121},
{"f_14028:regex_scm",(void*)f_14028},
{"f_14058:regex_scm",(void*)f_14058},
{"f_14050:regex_scm",(void*)f_14050},
{"f_13798:regex_scm",(void*)f_13798},
{"f_13896:regex_scm",(void*)f_13896},
{"f_13648:regex_scm",(void*)f_13648},
{"f_13697:regex_scm",(void*)f_13697},
{"f_13726:regex_scm",(void*)f_13726},
{"f_13623:regex_scm",(void*)f_13623},
{"f_13598:regex_scm",(void*)f_13598},
{"f_12503:regex_scm",(void*)f_12503},
{"f_12509:regex_scm",(void*)f_12509},
{"f_12477:regex_scm",(void*)f_12477},
{"f_12391:regex_scm",(void*)f_12391},
{"f_12430:regex_scm",(void*)f_12430},
{"f_12443:regex_scm",(void*)f_12443},
{"f_12305:regex_scm",(void*)f_12305},
{"f_12344:regex_scm",(void*)f_12344},
{"f_12249:regex_scm",(void*)f_12249},
{"f_12173:regex_scm",(void*)f_12173},
{"f_12198:regex_scm",(void*)f_12198},
{"f_12045:regex_scm",(void*)f_12045},
{"f_12064:regex_scm",(void*)f_12064},
{"f_12113:regex_scm",(void*)f_12113},
{"f_11894:regex_scm",(void*)f_11894},
{"f_11898:regex_scm",(void*)f_11898},
{"f25540:regex_scm",(void*)f25540},
{"f25534:regex_scm",(void*)f25534},
{"f_11414:regex_scm",(void*)f_11414},
{"f_11806:regex_scm",(void*)f_11806},
{"f_11817:regex_scm",(void*)f_11817},
{"f_11819:regex_scm",(void*)f_11819},
{"f_11848:regex_scm",(void*)f_11848},
{"f_11813:regex_scm",(void*)f_11813},
{"f_11595:regex_scm",(void*)f_11595},
{"f_11740:regex_scm",(void*)f_11740},
{"f_11769:regex_scm",(void*)f_11769},
{"f_11734:regex_scm",(void*)f_11734},
{"f_11686:regex_scm",(void*)f_11686},
{"f_11715:regex_scm",(void*)f_11715},
{"f_11680:regex_scm",(void*)f_11680},
{"f_11604:regex_scm",(void*)f_11604},
{"f_11625:regex_scm",(void*)f_11625},
{"f_11610:regex_scm",(void*)f_11610},
{"f_11620:regex_scm",(void*)f_11620},
{"f_11548:regex_scm",(void*)f_11548},
{"f_11582:regex_scm",(void*)f_11582},
{"f_11575:regex_scm",(void*)f_11575},
{"f_11542:regex_scm",(void*)f_11542},
{"f_11487:regex_scm",(void*)f_11487},
{"f_11521:regex_scm",(void*)f_11521},
{"f_11514:regex_scm",(void*)f_11514},
{"f_11481:regex_scm",(void*)f_11481},
{"f_11417:regex_scm",(void*)f_11417},
{"f_11901:regex_scm",(void*)f_11901},
{"f_11904:regex_scm",(void*)f_11904},
{"f_11907:regex_scm",(void*)f_11907},
{"f_11910:regex_scm",(void*)f_11910},
{"f_11989:regex_scm",(void*)f_11989},
{"f_11993:regex_scm",(void*)f_11993},
{"f_11913:regex_scm",(void*)f_11913},
{"f_11916:regex_scm",(void*)f_11916},
{"f_11968:regex_scm",(void*)f_11968},
{"f_11919:regex_scm",(void*)f_11919},
{"f_16918:regex_scm",(void*)f_16918},
{"f_17242:regex_scm",(void*)f_17242},
{"f_16932:regex_scm",(void*)f_16932},
{"f_16945:regex_scm",(void*)f_16945},
{"f_16936:regex_scm",(void*)f_16936},
{"f_16937:regex_scm",(void*)f_16937},
{"f_17193:regex_scm",(void*)f_17193},
{"f_17194:regex_scm",(void*)f_17194},
{"f_17198:regex_scm",(void*)f_17198},
{"f_17168:regex_scm",(void*)f_17168},
{"f_17169:regex_scm",(void*)f_17169},
{"f_17173:regex_scm",(void*)f_17173},
{"f_17112:regex_scm",(void*)f_17112},
{"f_17137:regex_scm",(void*)f_17137},
{"f_17141:regex_scm",(void*)f_17141},
{"f_17114:regex_scm",(void*)f_17114},
{"f_17118:regex_scm",(void*)f_17118},
{"f_17124:regex_scm",(void*)f_17124},
{"f_17062:regex_scm",(void*)f_17062},
{"f_17087:regex_scm",(void*)f_17087},
{"f_17065:regex_scm",(void*)f_17065},
{"f_17066:regex_scm",(void*)f_17066},
{"f_17070:regex_scm",(void*)f_17070},
{"f_16969:regex_scm",(void*)f_16969},
{"f_17038:regex_scm",(void*)f_17038},
{"f_16972:regex_scm",(void*)f_16972},
{"f_16973:regex_scm",(void*)f_16973},
{"f_16979:regex_scm",(void*)f_16979},
{"f_16989:regex_scm",(void*)f_16989},
{"f_16992:regex_scm",(void*)f_16992},
{"f_17015:regex_scm",(void*)f_17015},
{"f_11922:regex_scm",(void*)f_11922},
{"f_11925:regex_scm",(void*)f_11925},
{"f_11928:regex_scm",(void*)f_11928},
{"f_12566:regex_scm",(void*)f_12566},
{"f_13587:regex_scm",(void*)f_13587},
{"f_12569:regex_scm",(void*)f_12569},
{"f_12578:regex_scm",(void*)f_12578},
{"f_12623:regex_scm",(void*)f_12623},
{"f_12652:regex_scm",(void*)f_12652},
{"f_13382:regex_scm",(void*)f_13382},
{"f_13432:regex_scm",(void*)f_13432},
{"f_13409:regex_scm",(void*)f_13409},
{"f_13355:regex_scm",(void*)f_13355},
{"f_13325:regex_scm",(void*)f_13325},
{"f_13181:regex_scm",(void*)f_13181},
{"f_13184:regex_scm",(void*)f_13184},
{"f_13249:regex_scm",(void*)f_13249},
{"f_13202:regex_scm",(void*)f_13202},
{"f_13161:regex_scm",(void*)f_13161},
{"f_13152:regex_scm",(void*)f_13152},
{"f_13039:regex_scm",(void*)f_13039},
{"f_13048:regex_scm",(void*)f_13048},
{"f_12999:regex_scm",(void*)f_12999},
{"f_12828:regex_scm",(void*)f_12828},
{"f_12834:regex_scm",(void*)f_12834},
{"f_12837:regex_scm",(void*)f_12837},
{"f_12844:regex_scm",(void*)f_12844},
{"f_12846:regex_scm",(void*)f_12846},
{"f_12860:regex_scm",(void*)f_12860},
{"f_12874:regex_scm",(void*)f_12874},
{"f_12903:regex_scm",(void*)f_12903},
{"f_12899:regex_scm",(void*)f_12899},
{"f_12743:regex_scm",(void*)f_12743},
{"f_12776:regex_scm",(void*)f_12776},
{"f_12809:regex_scm",(void*)f_12809},
{"f_12792:regex_scm",(void*)f_12792},
{"f_12796:regex_scm",(void*)f_12796},
{"f_12661:regex_scm",(void*)f_12661},
{"f_12694:regex_scm",(void*)f_12694},
{"f_12724:regex_scm",(void*)f_12724},
{"f_12639:regex_scm",(void*)f_12639},
{"f_12581:regex_scm",(void*)f_12581},
{"f_12576:regex_scm",(void*)f_12576},
{"f_11950:regex_scm",(void*)f_11950},
{"f_11957:regex_scm",(void*)f_11957},
{"f_11934:regex_scm",(void*)f_11934},
{"f_17249:regex_scm",(void*)f_17249},
{"f_17261:regex_scm",(void*)f_17261},
{"f_19230:regex_scm",(void*)f_19230},
{"f25467:regex_scm",(void*)f25467},
{"f_19182:regex_scm",(void*)f_19182},
{"f_19189:regex_scm",(void*)f_19189},
{"f_19150:regex_scm",(void*)f_19150},
{"f_19157:regex_scm",(void*)f_19157},
{"f_19053:regex_scm",(void*)f_19053},
{"f_19060:regex_scm",(void*)f_19060},
{"f_18995:regex_scm",(void*)f_18995},
{"f_19014:regex_scm",(void*)f_19014},
{"f_19002:regex_scm",(void*)f_19002},
{"f_18961:regex_scm",(void*)f_18961},
{"f_18971:regex_scm",(void*)f_18971},
{"f_18937:regex_scm",(void*)f_18937},
{"f_18879:regex_scm",(void*)f_18879},
{"f_18898:regex_scm",(void*)f_18898},
{"f_18886:regex_scm",(void*)f_18886},
{"f_18845:regex_scm",(void*)f_18845},
{"f_18855:regex_scm",(void*)f_18855},
{"f_18825:regex_scm",(void*)f_18825},
{"f_18783:regex_scm",(void*)f_18783},
{"f_18790:regex_scm",(void*)f_18790},
{"f_18755:regex_scm",(void*)f_18755},
{"f_17307:regex_scm",(void*)f_17307},
{"f_18707:regex_scm",(void*)f_18707},
{"f_18667:regex_scm",(void*)f_18667},
{"f_18679:regex_scm",(void*)f_18679},
{"f_18637:regex_scm",(void*)f_18637},
{"f_18638:regex_scm",(void*)f_18638},
{"f_18650:regex_scm",(void*)f_18650},
{"f_18510:regex_scm",(void*)f_18510},
{"f25461:regex_scm",(void*)f25461},
{"f_18513:regex_scm",(void*)f_18513},
{"f_18514:regex_scm",(void*)f_18514},
{"f_18518:regex_scm",(void*)f_18518},
{"f_18552:regex_scm",(void*)f_18552},
{"f_18536:regex_scm",(void*)f_18536},
{"f_18368:regex_scm",(void*)f_18368},
{"f_18371:regex_scm",(void*)f_18371},
{"f_18478:regex_scm",(void*)f_18478},
{"f_18473:regex_scm",(void*)f_18473},
{"f_18374:regex_scm",(void*)f_18374},
{"f_18383:regex_scm",(void*)f_18383},
{"f_18429:regex_scm",(void*)f_18429},
{"f_18430:regex_scm",(void*)f_18430},
{"f_18436:regex_scm",(void*)f_18436},
{"f_18386:regex_scm",(void*)f_18386},
{"f_18387:regex_scm",(void*)f_18387},
{"f_18354:regex_scm",(void*)f_18354},
{"f_18331:regex_scm",(void*)f_18331},
{"f_18332:regex_scm",(void*)f_18332},
{"f_18347:regex_scm",(void*)f_18347},
{"f_18336:regex_scm",(void*)f_18336},
{"f_18313:regex_scm",(void*)f_18313},
{"f_18282:regex_scm",(void*)f_18282},
{"f_18283:regex_scm",(void*)f_18283},
{"f_18304:regex_scm",(void*)f_18304},
{"f_18306:regex_scm",(void*)f_18306},
{"f_18300:regex_scm",(void*)f_18300},
{"f_18264:regex_scm",(void*)f_18264},
{"f_18233:regex_scm",(void*)f_18233},
{"f_18234:regex_scm",(void*)f_18234},
{"f_18255:regex_scm",(void*)f_18255},
{"f_18257:regex_scm",(void*)f_18257},
{"f_18251:regex_scm",(void*)f_18251},
{"f_18219:regex_scm",(void*)f_18219},
{"f_18196:regex_scm",(void*)f_18196},
{"f_18197:regex_scm",(void*)f_18197},
{"f_18212:regex_scm",(void*)f_18212},
{"f_18204:regex_scm",(void*)f_18204},
{"f_18182:regex_scm",(void*)f_18182},
{"f_18159:regex_scm",(void*)f_18159},
{"f_18160:regex_scm",(void*)f_18160},
{"f_18175:regex_scm",(void*)f_18175},
{"f_18167:regex_scm",(void*)f_18167},
{"f_18146:regex_scm",(void*)f_18146},
{"f_18121:regex_scm",(void*)f_18121},
{"f_18056:regex_scm",(void*)f_18056},
{"f_17835:regex_scm",(void*)f_17835},
{"f_17838:regex_scm",(void*)f_17838},
{"f_17861:regex_scm",(void*)f_17861},
{"f_17961:regex_scm",(void*)f_17961},
{"f_17945:regex_scm",(void*)f_17945},
{"f_17864:regex_scm",(void*)f_17864},
{"f_17893:regex_scm",(void*)f_17893},
{"f_17895:regex_scm",(void*)f_17895},
{"f_17922:regex_scm",(void*)f_17922},
{"f_17885:regex_scm",(void*)f_17885},
{"f_17881:regex_scm",(void*)f_17881},
{"f_17839:regex_scm",(void*)f_17839},
{"f_17816:regex_scm",(void*)f_17816},
{"f_17783:regex_scm",(void*)f_17783},
{"f_17734:regex_scm",(void*)f_17734},
{"f_17671:regex_scm",(void*)f_17671},
{"f_17695:regex_scm",(void*)f_17695},
{"f_17701:regex_scm",(void*)f_17701},
{"f_17678:regex_scm",(void*)f_17678},
{"f_17679:regex_scm",(void*)f_17679},
{"f_17685:regex_scm",(void*)f_17685},
{"f_17613:regex_scm",(void*)f_17613},
{"f_17637:regex_scm",(void*)f_17637},
{"f_17643:regex_scm",(void*)f_17643},
{"f_17620:regex_scm",(void*)f_17620},
{"f_17621:regex_scm",(void*)f_17621},
{"f_17627:regex_scm",(void*)f_17627},
{"f_17582:regex_scm",(void*)f_17582},
{"f_17583:regex_scm",(void*)f_17583},
{"f_17589:regex_scm",(void*)f_17589},
{"f_17554:regex_scm",(void*)f_17554},
{"f_17555:regex_scm",(void*)f_17555},
{"f_17561:regex_scm",(void*)f_17561},
{"f_17533:regex_scm",(void*)f_17533},
{"f_17514:regex_scm",(void*)f_17514},
{"f_17476:regex_scm",(void*)f_17476},
{"f_17455:regex_scm",(void*)f_17455},
{"f_17434:regex_scm",(void*)f_17434},
{"f_17413:regex_scm",(void*)f_17413},
{"f_17354:regex_scm",(void*)f_17354},
{"f_17380:regex_scm",(void*)f_17380},
{"f_17357:regex_scm",(void*)f_17357},
{"f_17358:regex_scm",(void*)f_17358},
{"f_17364:regex_scm",(void*)f_17364},
{"f_17334:regex_scm",(void*)f_17334},
{"f25445:regex_scm",(void*)f25445},
{"f_17314:regex_scm",(void*)f_17314},
{"f25439:regex_scm",(void*)f25439},
{"f_17287:regex_scm",(void*)f_17287},
{"f_17264:regex_scm",(void*)f_17264},
{"f_17258:regex_scm",(void*)f_17258},
{"f_11943:regex_scm",(void*)f_11943},
{"f_11884:regex_scm",(void*)f_11884},
{"f_11892:regex_scm",(void*)f_11892},
{"f_11863:regex_scm",(void*)f_11863},
{"f_11870:regex_scm",(void*)f_11870},
{"f_11240:regex_scm",(void*)f_11240},
{"f_11246:regex_scm",(void*)f_11246},
{"f_11337:regex_scm",(void*)f_11337},
{"f_10090:regex_scm",(void*)f_10090},
{"f_10093:regex_scm",(void*)f_10093},
{"f_11039:regex_scm",(void*)f_11039},
{"f_11033:regex_scm",(void*)f_11033},
{"f_10861:regex_scm",(void*)f_10861},
{"f_10863:regex_scm",(void*)f_10863},
{"f_11005:regex_scm",(void*)f_11005},
{"f_10890:regex_scm",(void*)f_10890},
{"f_10998:regex_scm",(void*)f_10998},
{"f_10990:regex_scm",(void*)f_10990},
{"f_10982:regex_scm",(void*)f_10982},
{"f_10910:regex_scm",(void*)f_10910},
{"f_10912:regex_scm",(void*)f_10912},
{"f_10906:regex_scm",(void*)f_10906},
{"f_10733:regex_scm",(void*)f_10733},
{"f_10841:regex_scm",(void*)f_10841},
{"f_10759:regex_scm",(void*)f_10759},
{"f_10753:regex_scm",(void*)f_10753},
{"f_10725:regex_scm",(void*)f_10725},
{"f_10114:regex_scm",(void*)f_10114},
{"f_10119:regex_scm",(void*)f_10119},
{"f_10191:regex_scm",(void*)f_10191},
{"f_11144:regex_scm",(void*)f_11144},
{"f_11154:regex_scm",(void*)f_11154},
{"f_11148:regex_scm",(void*)f_11148},
{"f_10199:regex_scm",(void*)f_10199},
{"f_10176:regex_scm",(void*)f_10176},
{"f_10180:regex_scm",(void*)f_10180},
{"f_10147:regex_scm",(void*)f_10147},
{"f_11352:regex_scm",(void*)f_11352},
{"f_11264:regex_scm",(void*)f_11264},
{"f_11282:regex_scm",(void*)f_11282},
{"f_11260:regex_scm",(void*)f_11260},
{"f_10551:regex_scm",(void*)f_10551},
{"f_10704:regex_scm",(void*)f_10704},
{"f_10696:regex_scm",(void*)f_10696},
{"f_10653:regex_scm",(void*)f_10653},
{"f_10655:regex_scm",(void*)f_10655},
{"f_10684:regex_scm",(void*)f_10684},
{"f_10621:regex_scm",(void*)f_10621},
{"f_10649:regex_scm",(void*)f_10649},
{"f_10617:regex_scm",(void*)f_10617},
{"f_10573:regex_scm",(void*)f_10573},
{"f_10571:regex_scm",(void*)f_10571},
{"f_10388:regex_scm",(void*)f_10388},
{"f_10541:regex_scm",(void*)f_10541},
{"f_10533:regex_scm",(void*)f_10533},
{"f_10490:regex_scm",(void*)f_10490},
{"f_10492:regex_scm",(void*)f_10492},
{"f_10521:regex_scm",(void*)f_10521},
{"f_10458:regex_scm",(void*)f_10458},
{"f_10486:regex_scm",(void*)f_10486},
{"f_10454:regex_scm",(void*)f_10454},
{"f_10410:regex_scm",(void*)f_10410},
{"f_10408:regex_scm",(void*)f_10408},
{"f_10233:regex_scm",(void*)f_10233},
{"f_10349:regex_scm",(void*)f_10349},
{"f_10378:regex_scm",(void*)f_10378},
{"f_10267:regex_scm",(void*)f_10267},
{"f_10275:regex_scm",(void*)f_10275},
{"f_10289:regex_scm",(void*)f_10289},
{"f_10283:regex_scm",(void*)f_10283},
{"f_10279:regex_scm",(void*)f_10279},
{"f_10263:regex_scm",(void*)f_10263},
{"f_9957:regex_scm",(void*)f_9957},
{"f_10045:regex_scm",(void*)f_10045},
{"f_10073:regex_scm",(void*)f_10073},
{"f_10049:regex_scm",(void*)f_10049},
{"f_10065:regex_scm",(void*)f_10065},
{"f_10053:regex_scm",(void*)f_10053},
{"f_10061:regex_scm",(void*)f_10061},
{"f_10057:regex_scm",(void*)f_10057},
{"f_10008:regex_scm",(void*)f_10008},
{"f_10024:regex_scm",(void*)f_10024},
{"f_10012:regex_scm",(void*)f_10012},
{"f_10020:regex_scm",(void*)f_10020},
{"f_10016:regex_scm",(void*)f_10016},
{"f_9983:regex_scm",(void*)f_9983},
{"f_9991:regex_scm",(void*)f_9991},
{"f_9987:regex_scm",(void*)f_9987},
{"f_9897:regex_scm",(void*)f_9897},
{"f_9672:regex_scm",(void*)f_9672},
{"f_9847:regex_scm",(void*)f_9847},
{"f_9835:regex_scm",(void*)f_9835},
{"f_9823:regex_scm",(void*)f_9823},
{"f_9811:regex_scm",(void*)f_9811},
{"f_9778:regex_scm",(void*)f_9778},
{"f_9766:regex_scm",(void*)f_9766},
{"f_9754:regex_scm",(void*)f_9754},
{"f_9725:regex_scm",(void*)f_9725},
{"f_9713:regex_scm",(void*)f_9713},
{"f_9675:regex_scm",(void*)f_9675},
{"f_9652:regex_scm",(void*)f_9652},
{"f_8849:regex_scm",(void*)f_8849},
{"f_8916:regex_scm",(void*)f_8916},
{"f_8919:regex_scm",(void*)f_8919},
{"f_8880:regex_scm",(void*)f_8880},
{"f_8883:regex_scm",(void*)f_8883},
{"f_4964:regex_scm",(void*)f_4964},
{"f_5863:regex_scm",(void*)f_5863},
{"f_5870:regex_scm",(void*)f_5870},
{"f_5875:regex_scm",(void*)f_5875},
{"f25291:regex_scm",(void*)f25291},
{"f_8759:regex_scm",(void*)f_8759},
{"f_8777:regex_scm",(void*)f_8777},
{"f25285:regex_scm",(void*)f25285},
{"f_8737:regex_scm",(void*)f_8737},
{"f25279:regex_scm",(void*)f25279},
{"f_8707:regex_scm",(void*)f_8707},
{"f25273:regex_scm",(void*)f25273},
{"f_8676:regex_scm",(void*)f_8676},
{"f_8648:regex_scm",(void*)f_8648},
{"f_8615:regex_scm",(void*)f_8615},
{"f_8597:regex_scm",(void*)f_8597},
{"f25260:regex_scm",(void*)f25260},
{"f_8541:regex_scm",(void*)f_8541},
{"f_8537:regex_scm",(void*)f_8537},
{"f_8529:regex_scm",(void*)f_8529},
{"f_8525:regex_scm",(void*)f_8525},
{"f_5022:regex_scm",(void*)f_5022},
{"f_8391:regex_scm",(void*)f_8391},
{"f_8400:regex_scm",(void*)f_8400},
{"f_8462:regex_scm",(void*)f_8462},
{"f_8307:regex_scm",(void*)f_8307},
{"f_8310:regex_scm",(void*)f_8310},
{"f_8313:regex_scm",(void*)f_8313},
{"f25252:regex_scm",(void*)f25252},
{"f_8360:regex_scm",(void*)f_8360},
{"f_8352:regex_scm",(void*)f_8352},
{"f_8348:regex_scm",(void*)f_8348},
{"f_8282:regex_scm",(void*)f_8282},
{"f_8254:regex_scm",(void*)f_8254},
{"f_8278:regex_scm",(void*)f_8278},
{"f_8274:regex_scm",(void*)f_8274},
{"f_8243:regex_scm",(void*)f_8243},
{"f_8239:regex_scm",(void*)f_8239},
{"f_8214:regex_scm",(void*)f_8214},
{"f_8210:regex_scm",(void*)f_8210},
{"f_8185:regex_scm",(void*)f_8185},
{"f_8181:regex_scm",(void*)f_8181},
{"f_8156:regex_scm",(void*)f_8156},
{"f_8152:regex_scm",(void*)f_8152},
{"f_8127:regex_scm",(void*)f_8127},
{"f_8123:regex_scm",(void*)f_8123},
{"f_8094:regex_scm",(void*)f_8094},
{"f_8090:regex_scm",(void*)f_8090},
{"f_8057:regex_scm",(void*)f_8057},
{"f_8053:regex_scm",(void*)f_8053},
{"f_8028:regex_scm",(void*)f_8028},
{"f_8024:regex_scm",(void*)f_8024},
{"f_7991:regex_scm",(void*)f_7991},
{"f_7987:regex_scm",(void*)f_7987},
{"f_7938:regex_scm",(void*)f_7938},
{"f_7934:regex_scm",(void*)f_7934},
{"f_7893:regex_scm",(void*)f_7893},
{"f_7889:regex_scm",(void*)f_7889},
{"f_7856:regex_scm",(void*)f_7856},
{"f_7852:regex_scm",(void*)f_7852},
{"f_7823:regex_scm",(void*)f_7823},
{"f_7819:regex_scm",(void*)f_7819},
{"f_7790:regex_scm",(void*)f_7790},
{"f_7786:regex_scm",(void*)f_7786},
{"f_7757:regex_scm",(void*)f_7757},
{"f_7753:regex_scm",(void*)f_7753},
{"f_7506:regex_scm",(void*)f_7506},
{"f_7516:regex_scm",(void*)f_7516},
{"f_7525:regex_scm",(void*)f_7525},
{"f_7669:regex_scm",(void*)f_7669},
{"f_5063:regex_scm",(void*)f_5063},
{"f_5108:regex_scm",(void*)f_5108},
{"f_5087:regex_scm",(void*)f_5087},
{"f_5066:regex_scm",(void*)f_5066},
{"f_5074:regex_scm",(void*)f_5074},
{"f_7528:regex_scm",(void*)f_7528},
{"f_7531:regex_scm",(void*)f_7531},
{"f_7537:regex_scm",(void*)f_7537},
{"f_7635:regex_scm",(void*)f_7635},
{"f_7600:regex_scm",(void*)f_7600},
{"f_7566:regex_scm",(void*)f_7566},
{"f25244:regex_scm",(void*)f25244},
{"f25236:regex_scm",(void*)f25236},
{"f_8962:regex_scm",(void*)f_8962},
{"f_9590:regex_scm",(void*)f_9590},
{"f_9608:regex_scm",(void*)f_9608},
{"f_9460:regex_scm",(void*)f_9460},
{"f_9517:regex_scm",(void*)f_9517},
{"f_9505:regex_scm",(void*)f_9505},
{"f_9490:regex_scm",(void*)f_9490},
{"f_9463:regex_scm",(void*)f_9463},
{"f_9486:regex_scm",(void*)f_9486},
{"f_9474:regex_scm",(void*)f_9474},
{"f_9482:regex_scm",(void*)f_9482},
{"f_9478:regex_scm",(void*)f_9478},
{"f_9327:regex_scm",(void*)f_9327},
{"f_9336:regex_scm",(void*)f_9336},
{"f_9379:regex_scm",(void*)f_9379},
{"f_9375:regex_scm",(void*)f_9375},
{"f_9342:regex_scm",(void*)f_9342},
{"f_9345:regex_scm",(void*)f_9345},
{"f_9368:regex_scm",(void*)f_9368},
{"f_9356:regex_scm",(void*)f_9356},
{"f_9364:regex_scm",(void*)f_9364},
{"f_9360:regex_scm",(void*)f_9360},
{"f_9275:regex_scm",(void*)f_9275},
{"f_9118:regex_scm",(void*)f_9118},
{"f_9203:regex_scm",(void*)f_9203},
{"f_9216:regex_scm",(void*)f_9216},
{"f_9226:regex_scm",(void*)f_9226},
{"f_9182:regex_scm",(void*)f_9182},
{"f_9181:regex_scm",(void*)f_9181},
{"f_9149:regex_scm",(void*)f_9149},
{"f25220:regex_scm",(void*)f25220},
{"f_9004:regex_scm",(void*)f_9004},
{"f_5568:regex_scm",(void*)f_5568},
{"f_9007:regex_scm",(void*)f_9007},
{"f_9089:regex_scm",(void*)f_9089},
{"f_9085:regex_scm",(void*)f_9085},
{"f_9090:regex_scm",(void*)f_9090},
{"f_9078:regex_scm",(void*)f_9078},
{"f_9033:regex_scm",(void*)f_9033},
{"f_9061:regex_scm",(void*)f_9061},
{"f_9043:regex_scm",(void*)f_9043},
{"f_19342:regex_scm",(void*)f_19342},
{"f_9054:regex_scm",(void*)f_9054},
{"f_9029:regex_scm",(void*)f_9029},
{"f_9012:regex_scm",(void*)f_9012},
{"f_7487:regex_scm",(void*)f_7487},
{"f_7463:regex_scm",(void*)f_7463},
{"f_7483:regex_scm",(void*)f_7483},
{"f_7448:regex_scm",(void*)f_7448},
{"f_6713:regex_scm",(void*)f_6713},
{"f_6717:regex_scm",(void*)f_6717},
{"f_7182:regex_scm",(void*)f_7182},
{"f_7367:regex_scm",(void*)f_7367},
{"f_7379:regex_scm",(void*)f_7379},
{"f_7346:regex_scm",(void*)f_7346},
{"f_7342:regex_scm",(void*)f_7342},
{"f_7297:regex_scm",(void*)f_7297},
{"f_7277:regex_scm",(void*)f_7277},
{"f_7260:regex_scm",(void*)f_7260},
{"f_7243:regex_scm",(void*)f_7243},
{"f_7194:regex_scm",(void*)f_7194},
{"f25199:regex_scm",(void*)f25199},
{"f25193:regex_scm",(void*)f25193},
{"f_7185:regex_scm",(void*)f_7185},
{"f_7140:regex_scm",(void*)f_7140},
{"f_7144:regex_scm",(void*)f_7144},
{"f_7083:regex_scm",(void*)f_7083},
{"f_7117:regex_scm",(void*)f_7117},
{"f_7086:regex_scm",(void*)f_7086},
{"f_7101:regex_scm",(void*)f_7101},
{"f_7109:regex_scm",(void*)f_7109},
{"f_7023:regex_scm",(void*)f_7023},
{"f_7066:regex_scm",(void*)f_7066},
{"f_7026:regex_scm",(void*)f_7026},
{"f_7050:regex_scm",(void*)f_7050},
{"f_7058:regex_scm",(void*)f_7058},
{"f_6995:regex_scm",(void*)f_6995},
{"f_6999:regex_scm",(void*)f_6999},
{"f_6903:regex_scm",(void*)f_6903},
{"f_6921:regex_scm",(void*)f_6921},
{"f_6941:regex_scm",(void*)f_6941},
{"f_6933:regex_scm",(void*)f_6933},
{"f_6929:regex_scm",(void*)f_6929},
{"f_6896:regex_scm",(void*)f_6896},
{"f_6900:regex_scm",(void*)f_6900},
{"f_6871:regex_scm",(void*)f_6871},
{"f_6875:regex_scm",(void*)f_6875},
{"f_6828:regex_scm",(void*)f_6828},
{"f_6832:regex_scm",(void*)f_6832},
{"f_6803:regex_scm",(void*)f_6803},
{"f_6807:regex_scm",(void*)f_6807},
{"f_6778:regex_scm",(void*)f_6778},
{"f_6782:regex_scm",(void*)f_6782},
{"f_6738:regex_scm",(void*)f_6738},
{"f_6753:regex_scm",(void*)f_6753},
{"f_6626:regex_scm",(void*)f_6626},
{"f_6632:regex_scm",(void*)f_6632},
{"f_6647:regex_scm",(void*)f_6647},
{"f_6429:regex_scm",(void*)f_6429},
{"f_6596:regex_scm",(void*)f_6596},
{"f_6567:regex_scm",(void*)f_6567},
{"f_6542:regex_scm",(void*)f_6542},
{"f_6525:regex_scm",(void*)f_6525},
{"f_6508:regex_scm",(void*)f_6508},
{"f_6483:regex_scm",(void*)f_6483},
{"f_6460:regex_scm",(void*)f_6460},
{"f25183:regex_scm",(void*)f25183},
{"f25177:regex_scm",(void*)f25177},
{"f25173:regex_scm",(void*)f25173},
{"f_6355:regex_scm",(void*)f_6355},
{"f_6367:regex_scm",(void*)f_6367},
{"f_6055:regex_scm",(void*)f_6055},
{"f_6059:regex_scm",(void*)f_6059},
{"f_6353:regex_scm",(void*)f_6353},
{"f_6062:regex_scm",(void*)f_6062},
{"f_6315:regex_scm",(void*)f_6315},
{"f_6326:regex_scm",(void*)f_6326},
{"f_6065:regex_scm",(void*)f_6065},
{"f_6308:regex_scm",(void*)f_6308},
{"f_6297:regex_scm",(void*)f_6297},
{"f_6068:regex_scm",(void*)f_6068},
{"f_6073:regex_scm",(void*)f_6073},
{"f25167:regex_scm",(void*)f25167},
{"f_6175:regex_scm",(void*)f_6175},
{"f_6183:regex_scm",(void*)f_6183},
{"f_6076:regex_scm",(void*)f_6076},
{"f_5983:regex_scm",(void*)f_5983},
{"f25161:regex_scm",(void*)f25161},
{"f_6040:regex_scm",(void*)f_6040},
{"f_9862:regex_scm",(void*)f_9862},
{"f_5990:regex_scm",(void*)f_5990},
{"f_6027:regex_scm",(void*)f_6027},
{"f_5999:regex_scm",(void*)f_5999},
{"f_6023:regex_scm",(void*)f_6023},
{"f_6019:regex_scm",(void*)f_6019},
{"f_5963:regex_scm",(void*)f_5963},
{"f_5981:regex_scm",(void*)f_5981},
{"f_5977:regex_scm",(void*)f_5977},
{"f_5908:regex_scm",(void*)f_5908},
{"f25153:regex_scm",(void*)f25153},
{"f_5926:regex_scm",(void*)f_5926},
{"f_5928:regex_scm",(void*)f_5928},
{"f_5957:regex_scm",(void*)f_5957},
{"f_5922:regex_scm",(void*)f_5922},
{"f_5878:regex_scm",(void*)f_5878},
{"f25145:regex_scm",(void*)f25145},
{"f_5763:regex_scm",(void*)f_5763},
{"f_5769:regex_scm",(void*)f_5769},
{"f_5800:regex_scm",(void*)f_5800},
{"f_5787:regex_scm",(void*)f_5787},
{"f_5744:regex_scm",(void*)f_5744},
{"f_5735:regex_scm",(void*)f_5735},
{"f_5678:regex_scm",(void*)f_5678},
{"f_5698:regex_scm",(void*)f_5698},
{"f_5706:regex_scm",(void*)f_5706},
{"f_5631:regex_scm",(void*)f_5631},
{"f_5651:regex_scm",(void*)f_5651},
{"f_5659:regex_scm",(void*)f_5659},
{"f_5519:regex_scm",(void*)f_5519},
{"f_5525:regex_scm",(void*)f_5525},
{"f_5549:regex_scm",(void*)f_5549},
{"f_5489:regex_scm",(void*)f_5489},
{"f_5495:regex_scm",(void*)f_5495},
{"f_5513:regex_scm",(void*)f_5513},
{"f_5440:regex_scm",(void*)f_5440},
{"f_5460:regex_scm",(void*)f_5460},
{"f_5476:regex_scm",(void*)f_5476},
{"f_5391:regex_scm",(void*)f_5391},
{"f_5411:regex_scm",(void*)f_5411},
{"f_5424:regex_scm",(void*)f_5424},
{"f_5349:regex_scm",(void*)f_5349},
{"f_5364:regex_scm",(void*)f_5364},
{"f_5317:regex_scm",(void*)f_5317},
{"f_5323:regex_scm",(void*)f_5323},
{"f_5336:regex_scm",(void*)f_5336},
{"f_5262:regex_scm",(void*)f_5262},
{"f_5268:regex_scm",(void*)f_5268},
{"f_5275:regex_scm",(void*)f_5275},
{"f_5223:regex_scm",(void*)f_5223},
{"f_5239:regex_scm",(void*)f_5239},
{"f_5166:regex_scm",(void*)f_5166},
{"f_5176:regex_scm",(void*)f_5176},
{"f_5174:regex_scm",(void*)f_5174},
{"f_5190:regex_scm",(void*)f_5190},
{"f_5195:regex_scm",(void*)f_5195},
{"f_5139:regex_scm",(void*)f_5139},
{"f_5193:regex_scm",(void*)f_5193},
{"f_4906:regex_scm",(void*)f_4906},
{"f_4919:regex_scm",(void*)f_4919},
{"f_4891:regex_scm",(void*)f_4891},
{"f_4899:regex_scm",(void*)f_4899},
{"f_4868:regex_scm",(void*)f_4868},
{"f_4872:regex_scm",(void*)f_4872},
{"f_4825:regex_scm",(void*)f_4825},
{"f_4829:regex_scm",(void*)f_4829},
{"f_4842:regex_scm",(void*)f_4842},
{"f_4793:regex_scm",(void*)f_4793},
{"f_4747:regex_scm",(void*)f_4747},
{"f_4673:regex_scm",(void*)f_4673},
{"f_4655:regex_scm",(void*)f_4655},
{"f_4602:regex_scm",(void*)f_4602},
{"f_4568:regex_scm",(void*)f_4568},
{"f_4578:regex_scm",(void*)f_4578},
{"f_4554:regex_scm",(void*)f_4554},
{"f_4562:regex_scm",(void*)f_4562},
{"f_4566:regex_scm",(void*)f_4566},
{"f_4632:regex_scm",(void*)f_4632},
{"f_4548:regex_scm",(void*)f_4548},
{"f_4542:regex_scm",(void*)f_4542},
{"f_4536:regex_scm",(void*)f_4536},
{"f_4530:regex_scm",(void*)f_4530},
{"f_4524:regex_scm",(void*)f_4524},
{"f_4518:regex_scm",(void*)f_4518},
{"f_4512:regex_scm",(void*)f_4512},
{"f_4506:regex_scm",(void*)f_4506},
{"f_4480:regex_scm",(void*)f_4480},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
