/* Generated from srfi-4.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:17
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: srfi-4.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file usrfi-4.c
   unit: srfi_4
*/

#include "chicken.h"

#define C_u8peek(b, i)         C_fix(((unsigned char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s8peek(b, i)         C_fix(((char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_u16peek(b, i)        C_fix(((unsigned short *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s16peek(b, i)        C_fix(((short *)C_data_pointer(b))[ C_unfix(i) ])
#ifdef C_SIXTY_FOUR
# define C_a_u32peek(ptr, d, b, i) C_fix(((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_fix(((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#else
# define C_a_u32peek(ptr, d, b, i) C_unsigned_int_to_num(ptr, ((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_int_to_num(ptr, ((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#endif
#define C_u8poke(b, i, x)      ((((unsigned char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s8poke(b, i, x)      ((((char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u16poke(b, i, x)     ((((unsigned short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s16poke(b, i, x)     ((((short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u32poke(b, i, x)     ((((C_u32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_unsigned_int(x)), C_SCHEME_UNDEFINED)
#define C_s32poke(b, i, x)     ((((C_s32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_int(x)), C_SCHEME_UNDEFINED)
#define C_f32poke(b, i, x)     ((((float *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_f64poke(b, i, x)     ((((double *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_copy_subvector(to, from, start_to, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to) + C_unfix(start_to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[173];
static double C_possibly_force_alignment;


/* from ext-free in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub194(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub194(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_ret:
#undef return

return C_r;}

/* from ext-alloc */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub189(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub189(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) return(C_SCHEME_FALSE);C_block_header(buf) = C_make_header(C_BYTEVECTOR_TYPE, bytes);return(buf);
C_ret:
#undef return

return C_r;}

C_noret_decl(C_srfi_4_toplevel)
C_externexport void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1219)
static void C_ccall f_1219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1223)
static void C_ccall f_1223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1231)
static void C_ccall f_1231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_ccall f_1247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1395)
static void C_ccall f_1395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_ccall f_1435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3570)
static void C_ccall f_3570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3566)
static void C_ccall f_3566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2628)
static void C_ccall f_2628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3554)
static void C_ccall f_3554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3508)
static void C_fcall f_3508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3503)
static void C_fcall f_3503(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3441)
static void C_fcall f_3441(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_fcall f_3477(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_fcall f_3430(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3384)
static void C_fcall f_3384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_fcall f_3379(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3334)
static void C_fcall f_3334(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3272)
static void C_fcall f_3272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_fcall f_3267(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3258)
static void C_fcall f_3258(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3221)
static void C_fcall f_3221(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_fcall f_3236(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3128)
static void C_fcall f_3128(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_fcall f_2936(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4005)
static void C_ccall f4005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f4012)
static void C_ccall f4012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f4019)
static void C_ccall f4019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f4026)
static void C_ccall f4026(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f4033)
static void C_ccall f4033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f4040)
static void C_ccall f4040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f4047)
static void C_ccall f4047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f4054)
static void C_ccall f4054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2744)
static void C_fcall f_2744(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_fcall f_2715(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2697)
static void C_fcall f_2697(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2699)
static void C_ccall f_2699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2571)
static void C_fcall f_2571(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_fcall f_2582(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2453)
static void C_fcall f_2453(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_fcall f_2470(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2393)
static void C_fcall f_2393(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_fcall f_2388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2383)
static void C_fcall f_2383(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2331)
static void C_fcall f_2331(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_fcall f_2353(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2358)
static C_word C_fcall f_2358(C_word t0,C_word t1);
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2269)
static void C_fcall f_2269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_fcall f_2264(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2259)
static void C_fcall f_2259(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2207)
static void C_fcall f_2207(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_fcall f_2229(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static C_word C_fcall f_2234(C_word t0,C_word t1);
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2145)
static void C_fcall f_2145(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_fcall f_2140(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2135)
static void C_fcall f_2135(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2090)
static void C_fcall f_2090(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static C_word C_fcall f_2114(C_word t0,C_word t1);
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2028)
static void C_fcall f_2028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2018)
static void C_fcall f_2018(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1973)
static void C_fcall f_1973(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static C_word C_fcall f_1997(C_word t0,C_word t1);
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1911)
static void C_fcall f_1911(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_fcall f_1906(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1901)
static void C_fcall f_1901(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1856)
static void C_fcall f_1856(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static C_word C_fcall f_1880(C_word t0,C_word t1);
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1794)
static void C_fcall f_1794(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_fcall f_1789(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1784)
static void C_fcall f_1784(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1739)
static void C_fcall f_1739(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1763)
static C_word C_fcall f_1763(C_word t0,C_word t1);
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1677)
static void C_fcall f_1677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_fcall f_1672(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1667)
static void C_fcall f_1667(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1622)
static void C_fcall f_1622(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static C_word C_fcall f_1646(C_word t0,C_word t1);
C_noret_decl(f_1503)
static void C_ccall f_1503(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1503)
static void C_ccall f_1503r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1560)
static void C_fcall f_1560(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_fcall f_1555(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1550)
static void C_fcall f_1550(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1505)
static void C_fcall f_1505(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1529)
static C_word C_fcall f_1529(C_word t0,C_word t1);
C_noret_decl(f_1478)
static void C_ccall f_1478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1485)
static void C_fcall f_1485(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_fcall f_1460(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_fcall f_1369(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1371)
static void C_ccall f_1371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1280)
static void C_fcall f_1280(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1292)
static void C_ccall f_1292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_fcall f_1263(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_fcall f_1249(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1206)
static void C_fcall f_1206(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1194)
static void C_ccall f_1194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1179)
static void C_ccall f_1179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1176)
static void C_ccall f_1176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1170)
static void C_ccall f_1170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1167)
static void C_ccall f_1167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1164)
static void C_ccall f_1164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1158)
static void C_ccall f_1158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1137)
static void C_ccall f_1137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;

C_noret_decl(trf_3508)
static void C_fcall trf_3508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3508(t0,t1);}

C_noret_decl(trf_3503)
static void C_fcall trf_3503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3503(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3503(t0,t1,t2);}

C_noret_decl(trf_3441)
static void C_fcall trf_3441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3441(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3441(t0,t1,t2,t3);}

C_noret_decl(trf_3477)
static void C_fcall trf_3477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3477(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3477(t0,t1);}

C_noret_decl(trf_3430)
static void C_fcall trf_3430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3430(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3430(t0,t1,t2);}

C_noret_decl(trf_3384)
static void C_fcall trf_3384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3384(t0,t1);}

C_noret_decl(trf_3379)
static void C_fcall trf_3379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3379(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3379(t0,t1,t2);}

C_noret_decl(trf_3334)
static void C_fcall trf_3334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3334(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3334(t0,t1,t2,t3);}

C_noret_decl(trf_3272)
static void C_fcall trf_3272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3272(t0,t1);}

C_noret_decl(trf_3267)
static void C_fcall trf_3267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3267(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3267(t0,t1,t2);}

C_noret_decl(trf_3258)
static void C_fcall trf_3258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3258(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3258(t0,t1,t2,t3);}

C_noret_decl(trf_3221)
static void C_fcall trf_3221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3221(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3221(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3236)
static void C_fcall trf_3236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3236(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3236(t0,t1,t2);}

C_noret_decl(trf_3128)
static void C_fcall trf_3128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3128(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3128(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2936)
static void C_fcall trf_2936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2936(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2936(t0,t1,t2);}

C_noret_decl(trf_2744)
static void C_fcall trf_2744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2744(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2744(t0,t1,t2,t3);}

C_noret_decl(trf_2715)
static void C_fcall trf_2715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2715(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2715(t0,t1,t2,t3);}

C_noret_decl(trf_2697)
static void C_fcall trf_2697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2697(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2697(t0,t1,t2);}

C_noret_decl(trf_2571)
static void C_fcall trf_2571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2571(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2571(t0,t1,t2);}

C_noret_decl(trf_2582)
static void C_fcall trf_2582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2582(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2582(t0,t1,t2);}

C_noret_decl(trf_2453)
static void C_fcall trf_2453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2453(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2453(t0,t1,t2,t3);}

C_noret_decl(trf_2470)
static void C_fcall trf_2470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2470(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2470(t0,t1,t2,t3);}

C_noret_decl(trf_2393)
static void C_fcall trf_2393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2393(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2393(t0,t1);}

C_noret_decl(trf_2388)
static void C_fcall trf_2388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2388(t0,t1,t2);}

C_noret_decl(trf_2383)
static void C_fcall trf_2383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2383(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2383(t0,t1,t2,t3);}

C_noret_decl(trf_2331)
static void C_fcall trf_2331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2331(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2331(t0,t1,t2,t3);}

C_noret_decl(trf_2353)
static void C_fcall trf_2353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2353(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2353(t0,t1);}

C_noret_decl(trf_2269)
static void C_fcall trf_2269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2269(t0,t1);}

C_noret_decl(trf_2264)
static void C_fcall trf_2264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2264(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2264(t0,t1,t2);}

C_noret_decl(trf_2259)
static void C_fcall trf_2259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2259(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2259(t0,t1,t2,t3);}

C_noret_decl(trf_2207)
static void C_fcall trf_2207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2207(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2207(t0,t1,t2,t3);}

C_noret_decl(trf_2229)
static void C_fcall trf_2229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2229(t0,t1);}

C_noret_decl(trf_2145)
static void C_fcall trf_2145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2145(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2145(t0,t1);}

C_noret_decl(trf_2140)
static void C_fcall trf_2140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2140(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2140(t0,t1,t2);}

C_noret_decl(trf_2135)
static void C_fcall trf_2135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2135(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2135(t0,t1,t2,t3);}

C_noret_decl(trf_2090)
static void C_fcall trf_2090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2090(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2090(t0,t1,t2,t3);}

C_noret_decl(trf_2028)
static void C_fcall trf_2028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2028(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2028(t0,t1);}

C_noret_decl(trf_2023)
static void C_fcall trf_2023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2023(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2023(t0,t1,t2);}

C_noret_decl(trf_2018)
static void C_fcall trf_2018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2018(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2018(t0,t1,t2,t3);}

C_noret_decl(trf_1973)
static void C_fcall trf_1973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1973(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1973(t0,t1,t2,t3);}

C_noret_decl(trf_1911)
static void C_fcall trf_1911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1911(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1911(t0,t1);}

C_noret_decl(trf_1906)
static void C_fcall trf_1906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1906(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1906(t0,t1,t2);}

C_noret_decl(trf_1901)
static void C_fcall trf_1901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1901(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1901(t0,t1,t2,t3);}

C_noret_decl(trf_1856)
static void C_fcall trf_1856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1856(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1856(t0,t1,t2,t3);}

C_noret_decl(trf_1794)
static void C_fcall trf_1794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1794(t0,t1);}

C_noret_decl(trf_1789)
static void C_fcall trf_1789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1789(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1789(t0,t1,t2);}

C_noret_decl(trf_1784)
static void C_fcall trf_1784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1784(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1784(t0,t1,t2,t3);}

C_noret_decl(trf_1739)
static void C_fcall trf_1739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1739(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1739(t0,t1,t2,t3);}

C_noret_decl(trf_1677)
static void C_fcall trf_1677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1677(t0,t1);}

C_noret_decl(trf_1672)
static void C_fcall trf_1672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1672(t0,t1,t2);}

C_noret_decl(trf_1667)
static void C_fcall trf_1667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1667(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1667(t0,t1,t2,t3);}

C_noret_decl(trf_1622)
static void C_fcall trf_1622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1622(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1622(t0,t1,t2,t3);}

C_noret_decl(trf_1560)
static void C_fcall trf_1560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1560(t0,t1);}

C_noret_decl(trf_1555)
static void C_fcall trf_1555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1555(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1555(t0,t1,t2);}

C_noret_decl(trf_1550)
static void C_fcall trf_1550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1550(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1550(t0,t1,t2,t3);}

C_noret_decl(trf_1505)
static void C_fcall trf_1505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1505(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1505(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1485)
static void C_fcall trf_1485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1485(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1485(t0,t1);}

C_noret_decl(trf_1460)
static void C_fcall trf_1460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1460(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1460(t0,t1,t2,t3);}

C_noret_decl(trf_1369)
static void C_fcall trf_1369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1369(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1369(t0,t1,t2,t3);}

C_noret_decl(trf_1280)
static void C_fcall trf_1280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1280(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1280(t0,t1,t2,t3);}

C_noret_decl(trf_1263)
static void C_fcall trf_1263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1263(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1263(t0,t1,t2,t3);}

C_noret_decl(trf_1249)
static void C_fcall trf_1249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1249(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1249(t0,t1,t2,t3);}

C_noret_decl(trf_1206)
static void C_fcall trf_1206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1206(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1206(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_4_toplevel"));
C_check_nursery_minimum(42);
if(!C_demand(42)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1544)){
C_save(t1);
C_rereclaim2(1544*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(42);
C_initialize_lf(lf,173);
lf[0]=C_h_intern(&lf[0],24,"\003syscheck-exact-interval");
lf[1]=C_h_intern(&lf[1],9,"\003syserror");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[3]=C_h_intern(&lf[3],26,"\003syscheck-inexact-interval");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[21]=C_h_intern(&lf[21],15,"u8vector-length");
lf[22]=C_h_intern(&lf[22],15,"s8vector-length");
lf[23]=C_h_intern(&lf[23],16,"u16vector-length");
lf[24]=C_h_intern(&lf[24],16,"s16vector-length");
lf[25]=C_h_intern(&lf[25],16,"u32vector-length");
lf[26]=C_h_intern(&lf[26],16,"s32vector-length");
lf[27]=C_h_intern(&lf[27],16,"f32vector-length");
lf[28]=C_h_intern(&lf[28],16,"f64vector-length");
lf[29]=C_h_intern(&lf[29],15,"\003syscheck-range");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[31]=C_h_intern(&lf[31],13,"u8vector-set!");
lf[32]=C_h_intern(&lf[32],13,"s8vector-set!");
lf[33]=C_h_intern(&lf[33],14,"u16vector-set!");
lf[34]=C_h_intern(&lf[34],14,"s16vector-set!");
lf[35]=C_h_intern(&lf[35],14,"u32vector-set!");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[38]=C_h_intern(&lf[38],14,"s32vector-set!");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[40]=C_h_intern(&lf[40],14,"f32vector-set!");
lf[41]=C_h_intern(&lf[41],14,"f64vector-set!");
lf[42]=C_h_intern(&lf[42],12,"u8vector-ref");
lf[43]=C_h_intern(&lf[43],12,"s8vector-ref");
lf[44]=C_h_intern(&lf[44],13,"u16vector-ref");
lf[45]=C_h_intern(&lf[45],13,"s16vector-ref");
lf[46]=C_h_intern(&lf[46],13,"u32vector-ref");
lf[47]=C_h_intern(&lf[47],13,"s32vector-ref");
lf[48]=C_h_intern(&lf[48],13,"f32vector-ref");
lf[49]=C_h_intern(&lf[49],13,"f64vector-ref");
lf[50]=C_h_intern(&lf[50],14,"set-finalizer!");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000:not enough memory - cannot allocate external number vector");
lf[52]=C_h_intern(&lf[52],19,"\003sysallocate-vector");
lf[53]=C_h_intern(&lf[53],21,"release-number-vector");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\047bad argument type - not a number vector");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376"
"\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[56]=C_h_intern(&lf[56],13,"make-u8vector");
lf[57]=C_h_intern(&lf[57],8,"u8vector");
lf[58]=C_h_intern(&lf[58],13,"make-s8vector");
lf[59]=C_h_intern(&lf[59],8,"s8vector");
lf[60]=C_h_intern(&lf[60],4,"fin\077");
lf[61]=C_h_intern(&lf[61],14,"make-u16vector");
lf[62]=C_h_intern(&lf[62],9,"u16vector");
lf[63]=C_h_intern(&lf[63],14,"make-s16vector");
lf[64]=C_h_intern(&lf[64],9,"s16vector");
lf[65]=C_h_intern(&lf[65],14,"make-u32vector");
lf[66]=C_h_intern(&lf[66],9,"u32vector");
lf[67]=C_h_intern(&lf[67],14,"make-s32vector");
lf[68]=C_h_intern(&lf[68],9,"s32vector");
lf[69]=C_h_intern(&lf[69],14,"make-f32vector");
lf[70]=C_h_intern(&lf[70],9,"f32vector");
lf[71]=C_h_intern(&lf[71],14,"make-f64vector");
lf[72]=C_h_intern(&lf[72],9,"f64vector");
lf[73]=C_h_intern(&lf[73],27,"\003syserror-not-a-proper-list");
lf[74]=C_h_intern(&lf[74],14,"list->u8vector");
lf[75]=C_h_intern(&lf[75],14,"list->s8vector");
lf[76]=C_h_intern(&lf[76],15,"list->u16vector");
lf[77]=C_h_intern(&lf[77],15,"list->s16vector");
lf[78]=C_h_intern(&lf[78],15,"list->u32vector");
lf[79]=C_h_intern(&lf[79],15,"list->s32vector");
lf[80]=C_h_intern(&lf[80],15,"list->f32vector");
lf[81]=C_h_intern(&lf[81],15,"list->f64vector");
lf[82]=C_h_intern(&lf[82],14,"u8vector->list");
lf[83]=C_h_intern(&lf[83],14,"s8vector->list");
lf[84]=C_h_intern(&lf[84],15,"u16vector->list");
lf[85]=C_h_intern(&lf[85],15,"s16vector->list");
lf[86]=C_h_intern(&lf[86],15,"u32vector->list");
lf[87]=C_h_intern(&lf[87],15,"s32vector->list");
lf[88]=C_h_intern(&lf[88],15,"f32vector->list");
lf[89]=C_h_intern(&lf[89],15,"f64vector->list");
lf[90]=C_h_intern(&lf[90],9,"u8vector\077");
lf[91]=C_h_intern(&lf[91],9,"s8vector\077");
lf[92]=C_h_intern(&lf[92],10,"u16vector\077");
lf[93]=C_h_intern(&lf[93],10,"s16vector\077");
lf[94]=C_h_intern(&lf[94],10,"u32vector\077");
lf[95]=C_h_intern(&lf[95],10,"s32vector\077");
lf[96]=C_h_intern(&lf[96],10,"f32vector\077");
lf[97]=C_h_intern(&lf[97],10,"f64vector\077");
lf[98]=C_h_intern(&lf[98],13,"\003sysmake-blob");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[101]=C_h_intern(&lf[101],21,"u8vector->blob/shared");
lf[102]=C_h_intern(&lf[102],21,"s8vector->blob/shared");
lf[103]=C_h_intern(&lf[103],22,"u16vector->blob/shared");
lf[104]=C_h_intern(&lf[104],22,"s16vector->blob/shared");
lf[105]=C_h_intern(&lf[105],22,"u32vector->blob/shared");
lf[106]=C_h_intern(&lf[106],22,"s32vector->blob/shared");
lf[107]=C_h_intern(&lf[107],22,"f32vector->blob/shared");
lf[108]=C_h_intern(&lf[108],22,"f64vector->blob/shared");
lf[109]=C_h_intern(&lf[109],14,"u8vector->blob");
lf[110]=C_h_intern(&lf[110],14,"s8vector->blob");
lf[111]=C_h_intern(&lf[111],15,"u16vector->blob");
lf[112]=C_h_intern(&lf[112],15,"s16vector->blob");
lf[113]=C_h_intern(&lf[113],15,"u32vector->blob");
lf[114]=C_h_intern(&lf[114],15,"s32vector->blob");
lf[115]=C_h_intern(&lf[115],15,"f32vector->blob");
lf[116]=C_h_intern(&lf[116],15,"f64vector->blob");
lf[117]=C_h_intern(&lf[117],21,"blob->u8vector/shared");
lf[118]=C_h_intern(&lf[118],21,"blob->s8vector/shared");
lf[119]=C_h_intern(&lf[119],22,"blob->u16vector/shared");
lf[120]=C_h_intern(&lf[120],22,"blob->s16vector/shared");
lf[121]=C_h_intern(&lf[121],22,"blob->u32vector/shared");
lf[122]=C_h_intern(&lf[122],22,"blob->s32vector/shared");
lf[123]=C_h_intern(&lf[123],22,"blob->f32vector/shared");
lf[124]=C_h_intern(&lf[124],22,"blob->f64vector/shared");
lf[125]=C_h_intern(&lf[125],14,"blob->u8vector");
lf[126]=C_h_intern(&lf[126],14,"blob->s8vector");
lf[127]=C_h_intern(&lf[127],15,"blob->u16vector");
lf[128]=C_h_intern(&lf[128],15,"blob->s16vector");
lf[129]=C_h_intern(&lf[129],15,"blob->u32vector");
lf[130]=C_h_intern(&lf[130],15,"blob->s32vector");
lf[131]=C_h_intern(&lf[131],15,"blob->f32vector");
lf[132]=C_h_intern(&lf[132],15,"blob->f64vector");
lf[133]=C_h_intern(&lf[133],18,"\003sysuser-read-hook");
lf[134]=C_h_intern(&lf[134],4,"read");
lf[135]=C_h_intern(&lf[135],2,"u8");
lf[136]=C_h_intern(&lf[136],2,"s8");
lf[137]=C_h_intern(&lf[137],3,"u16");
lf[138]=C_h_intern(&lf[138],3,"s16");
lf[139]=C_h_intern(&lf[139],3,"u32");
lf[140]=C_h_intern(&lf[140],3,"s32");
lf[141]=C_h_intern(&lf[141],3,"f32");
lf[142]=C_h_intern(&lf[142],3,"f64");
lf[143]=C_h_intern(&lf[143],1,"f");
lf[144]=C_h_intern(&lf[144],1,"F");
lf[145]=C_h_intern(&lf[145],14,"\003sysread-error");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal bytevector syntax");
lf[147]=C_h_intern(&lf[147],19,"\003sysuser-print-hook");
lf[148]=C_h_intern(&lf[148],9,"\003sysprint");
lf[150]=C_h_intern(&lf[150],11,"subu8vector");
lf[151]=C_h_intern(&lf[151],12,"subu16vector");
lf[152]=C_h_intern(&lf[152],12,"subu32vector");
lf[153]=C_h_intern(&lf[153],11,"subs8vector");
lf[154]=C_h_intern(&lf[154],12,"subs16vector");
lf[155]=C_h_intern(&lf[155],12,"subs32vector");
lf[156]=C_h_intern(&lf[156],12,"subf32vector");
lf[157]=C_h_intern(&lf[157],12,"subf64vector");
lf[158]=C_h_intern(&lf[158],14,"write-u8vector");
lf[159]=C_h_intern(&lf[159],16,"\003syswrite-char-0");
lf[160]=C_h_intern(&lf[160],14,"\003syscheck-port");
lf[161]=C_h_intern(&lf[161],19,"\003sysstandard-output");
lf[162]=C_h_intern(&lf[162],14,"read-u8vector!");
lf[163]=C_h_intern(&lf[163],16,"\003sysread-string!");
lf[164]=C_h_intern(&lf[164],18,"\003sysstandard-input");
lf[165]=C_h_intern(&lf[165],18,"open-output-string");
lf[166]=C_h_intern(&lf[166],17,"get-output-string");
lf[167]=C_h_intern(&lf[167],13,"read-u8vector");
lf[168]=C_h_intern(&lf[168],19,"\003syswrite-char/port");
lf[169]=C_h_intern(&lf[169],15,"\003sysread-char-0");
lf[170]=C_h_intern(&lf[170],17,"register-feature!");
lf[171]=C_h_intern(&lf[171],6,"srfi-4");
lf[172]=C_h_intern(&lf[172],18,"getter-with-setter");
C_register_lf2(lf,173,create_ptable());
t2=C_mutate((C_word*)lf[0]+1 /* (set! check-exact-interval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1122,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! check-inexact-interval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1137,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[5] /* (set! u8vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1158,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[6] /* (set! s8vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1161,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[7] /* (set! u16vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1164,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[8] /* (set! s16vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1167,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[9] /* (set! u32vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1170,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[10] /* (set! s32vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1173,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[11] /* (set! f32vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1176,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[12] /* (set! f64vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1179,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[13] /* (set! u8vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1182,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[14] /* (set! s8vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1185,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[15] /* (set! u16vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1188,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[16] /* (set! s16vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1191,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[17] /* (set! u32vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1194,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[18] /* (set! s32vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1197,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[19] /* (set! f32vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1200,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[20] /* (set! f64vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1203,tmp=(C_word)a,a+=2,tmp));
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1206,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1219,a[2]=t20,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 141  len */
f_1206(t21,lf[57],C_SCHEME_FALSE,lf[21]);}

/* k1217 */
static void C_ccall f_1219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1219,2,t0,t1);}
t2=C_mutate((C_word*)lf[21]+1 /* (set! u8vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 142  len */
f_1206(t3,lf[59],C_SCHEME_FALSE,lf[22]);}

/* k1221 in k1217 */
static void C_ccall f_1223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1223,2,t0,t1);}
t2=C_mutate((C_word*)lf[22]+1 /* (set! s8vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 143  len */
f_1206(t3,lf[62],C_fix(1),lf[23]);}

/* k1225 in k1221 in k1217 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1227,2,t0,t1);}
t2=C_mutate((C_word*)lf[23]+1 /* (set! u16vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 144  len */
f_1206(t3,lf[64],C_fix(1),lf[24]);}

/* k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1231,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! s16vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 145  len */
f_1206(t3,lf[66],C_fix(2),lf[25]);}

/* k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1235,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1 /* (set! u32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 146  len */
f_1206(t3,lf[68],C_fix(2),lf[26]);}

/* k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1 /* (set! s32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 147  len */
f_1206(t3,lf[70],C_fix(2),lf[27]);}

/* k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1243,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1 /* (set! f32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1247,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 148  len */
f_1206(t3,lf[72],C_fix(3),lf[28]);}

/* k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1247,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! f64vector-length ...) */,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1249,tmp=(C_word)a,a+=2,tmp));
t12=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1263,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1280,tmp=(C_word)a,a+=2,tmp));
t14=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1369,tmp=(C_word)a,a+=2,tmp));
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1395,a[2]=t8,a[3]=t6,a[4]=t10,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 204  setu */
f_1280(t15,*((C_word*)lf[21]+1),lf[13],lf[31]);}

/* k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1395,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! u8vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 205  set */
f_1263(t3,*((C_word*)lf[22]+1),lf[14],lf[32]);}

/* k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1399,2,t0,t1);}
t2=C_mutate((C_word*)lf[32]+1 /* (set! s8vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 206  setu */
f_1280(t3,*((C_word*)lf[23]+1),lf[15],lf[33]);}

/* k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1403,2,t0,t1);}
t2=C_mutate((C_word*)lf[33]+1 /* (set! u16vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 207  set */
f_1263(t3,*((C_word*)lf[24]+1),lf[16],lf[34]);}

/* k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1407,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1 /* (set! s16vector-set! ...) */,t1);
t3=*((C_word*)lf[25]+1);
t4=lf[17];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1335,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=C_mutate((C_word*)lf[35]+1 /* (set! u32vector-set! ...) */,t5);
t7=*((C_word*)lf[26]+1);
t8=lf[18];
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1308,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t10=C_mutate((C_word*)lf[38]+1 /* (set! s32vector-set! ...) */,t9);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 210  setf */
f_1369(t11,*((C_word*)lf[27]+1),lf[19],lf[40]);}

/* k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1419,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1 /* (set! f32vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 211  setf */
f_1369(t3,*((C_word*)lf[28]+1),lf[20],lf[41]);}

/* k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1 /* (set! f64vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3586,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 214  get */
f_1249(t4,*((C_word*)lf[21]+1),lf[5],lf[42]);}

/* k3584 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 214  getter-with-setter */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[31]+1));}

/* k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1427,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! u8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3582,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 217  get */
f_1249(t4,*((C_word*)lf[22]+1),lf[6],lf[43]);}

/* k3580 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 217  getter-with-setter */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[32]+1));}

/* k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1431,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* (set! s8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3578,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 220  get */
f_1249(t4,*((C_word*)lf[23]+1),lf[7],lf[44]);}

/* k3576 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 220  getter-with-setter */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[33]+1));}

/* k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1435,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1 /* (set! u16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3574,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 223  get */
f_1249(t4,*((C_word*)lf[24]+1),lf[8],lf[45]);}

/* k3572 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 223  getter-with-setter */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[34]+1));}

/* k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1439,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! s16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3570,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 227  get */
f_1249(t4,*((C_word*)lf[25]+1),lf[9],lf[46]);}

/* k3568 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 226  getter-with-setter */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[35]+1));}

/* k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1443,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1 /* (set! u32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3566,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 231  get */
f_1249(t4,*((C_word*)lf[26]+1),lf[10],lf[47]);}

/* k3564 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 230  getter-with-setter */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[38]+1));}

/* k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1447,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1 /* (set! s32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3562,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 235  get */
f_1249(t4,*((C_word*)lf[27]+1),lf[11],lf[48]);}

/* k3560 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 234  getter-with-setter */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[40]+1));}

/* k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1451,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1 /* (set! f32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1455,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3558,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 239  get */
f_1249(t4,*((C_word*)lf[28]+1),lf[12],lf[49]);}

/* k3556 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 238  getter-with-setter */
t2=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[41]+1));}

/* k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1455,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1 /* (set! f64vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1458,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[50]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1460,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[53]+1 /* (set! release-number-vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1478,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[56]+1 /* (set! make-u8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1503,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=C_mutate((C_word*)lf[58]+1 /* (set! make-s8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1620,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t9=C_mutate((C_word*)lf[61]+1 /* (set! make-u16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1737,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[63]+1 /* (set! make-s16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1854,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[65]+1 /* (set! make-u32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1971,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t12=C_mutate((C_word*)lf[67]+1 /* (set! make-s32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2088,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t13=C_mutate((C_word*)lf[69]+1 /* (set! make-f32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2205,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t14=C_mutate((C_word*)lf[71]+1 /* (set! make-f64vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2329,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2453,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2493,a[2]=t15,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 398  init */
f_2453(t16,*((C_word*)lf[56]+1),*((C_word*)lf[31]+1),lf[74]);}

/* k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! list->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 399  init */
f_2453(t3,*((C_word*)lf[58]+1),*((C_word*)lf[32]+1),lf[75]);}

/* k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2497,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! list->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 400  init */
f_2453(t3,*((C_word*)lf[61]+1),*((C_word*)lf[33]+1),lf[76]);}

/* k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2501,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! list->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 401  init */
f_2453(t3,*((C_word*)lf[63]+1),*((C_word*)lf[34]+1),lf[77]);}

/* k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! list->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 402  init */
f_2453(t3,*((C_word*)lf[65]+1),*((C_word*)lf[35]+1),lf[78]);}

/* k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2509,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! list->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 403  init */
f_2453(t3,*((C_word*)lf[67]+1),*((C_word*)lf[38]+1),lf[79]);}

/* k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2513,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! list->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 404  init */
f_2453(t3,*((C_word*)lf[69]+1),*((C_word*)lf[40]+1),lf[80]);}

/* k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! list->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 405  init */
f_2453(t3,*((C_word*)lf[71]+1),*((C_word*)lf[41]+1),lf[81]);}

/* k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1 /* (set! list->f64vector ...) */,t1);
t3=*((C_word*)lf[74]+1);
t4=C_mutate((C_word*)lf[57]+1 /* (set! u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2523,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[75]+1);
t6=C_mutate((C_word*)lf[59]+1 /* (set! s8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2529,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[76]+1);
t8=C_mutate((C_word*)lf[62]+1 /* (set! u16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2535,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[77]+1);
t10=C_mutate((C_word*)lf[64]+1 /* (set! s16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2541,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[78]+1);
t12=C_mutate((C_word*)lf[66]+1 /* (set! u32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2547,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[79]+1);
t14=C_mutate((C_word*)lf[68]+1 /* (set! s32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2553,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[80]+1);
t16=C_mutate((C_word*)lf[70]+1 /* (set! f32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2559,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[81]+1);
t18=C_mutate((C_word*)lf[72]+1 /* (set! f64vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2565,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2571,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2608,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 456  init */
f_2571(t20,*((C_word*)lf[21]+1),lf[5]);}

/* k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2608,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1 /* (set! u8vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 457  init */
f_2571(t3,*((C_word*)lf[22]+1),lf[6]);}

/* k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2612,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1 /* (set! s8vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 458  init */
f_2571(t3,*((C_word*)lf[23]+1),lf[7]);}

/* k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2616,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1 /* (set! u16vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 459  init */
f_2571(t3,*((C_word*)lf[24]+1),lf[8]);}

/* k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2620,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! s16vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 460  init */
f_2571(t3,*((C_word*)lf[25]+1),lf[9]);}

/* k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2624,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* (set! u32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 461  init */
f_2571(t3,*((C_word*)lf[26]+1),lf[10]);}

/* k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2628,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! s32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 462  init */
f_2571(t3,*((C_word*)lf[27]+1),lf[11]);}

/* k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1 /* (set! f32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2636,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 463  init */
f_2571(t3,*((C_word*)lf[28]+1),lf[12]);}

/* k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2636,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! f64vector->list ...) */,t1);
t3=C_mutate((C_word*)lf[90]+1 /* (set! u8vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2638,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[91]+1 /* (set! s8vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2644,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[92]+1 /* (set! u16vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2650,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[93]+1 /* (set! s16vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2656,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[94]+1 /* (set! u32vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2662,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[95]+1 /* (set! s32vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2668,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[96]+1 /* (set! f32vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2674,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[97]+1 /* (set! f64vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2680,tmp=(C_word)a,a+=2,tmp));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2697,tmp=(C_word)a,a+=2,tmp));
t18=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2715,tmp=(C_word)a,a+=2,tmp));
t19=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2744,tmp=(C_word)a,a+=2,tmp));
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f4054,tmp=(C_word)a,a+=2,tmp);
t21=C_mutate((C_word*)lf[101]+1 /* (set! u8vector->blob/shared ...) */,t20);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f4047,tmp=(C_word)a,a+=2,tmp);
t23=C_mutate((C_word*)lf[102]+1 /* (set! s8vector->blob/shared ...) */,t22);
t24=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f4040,tmp=(C_word)a,a+=2,tmp);
t25=C_mutate((C_word*)lf[103]+1 /* (set! u16vector->blob/shared ...) */,t24);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f4033,tmp=(C_word)a,a+=2,tmp);
t27=C_mutate((C_word*)lf[104]+1 /* (set! s16vector->blob/shared ...) */,t26);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f4026,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[105]+1 /* (set! u32vector->blob/shared ...) */,t28);
t30=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f4019,tmp=(C_word)a,a+=2,tmp);
t31=C_mutate((C_word*)lf[106]+1 /* (set! s32vector->blob/shared ...) */,t30);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f4012,tmp=(C_word)a,a+=2,tmp);
t33=C_mutate((C_word*)lf[107]+1 /* (set! f32vector->blob/shared ...) */,t32);
t34=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f4005,tmp=(C_word)a,a+=2,tmp);
t35=C_mutate((C_word*)lf[108]+1 /* (set! f64vector->blob/shared ...) */,t34);
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2810,a[2]=t12,a[3]=t14,a[4]=t16,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 524  pack-copy */
f_2697(t36,lf[57],lf[109]);}

/* k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2810,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1 /* (set! u8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 525  pack-copy */
f_2697(t3,lf[59],lf[110]);}

/* k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2814,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1 /* (set! s8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 526  pack-copy */
f_2697(t3,lf[62],lf[111]);}

/* k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2818,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1 /* (set! u16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 527  pack-copy */
f_2697(t3,lf[64],lf[112]);}

/* k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1 /* (set! s16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 528  pack-copy */
f_2697(t3,lf[66],lf[113]);}

/* k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! u32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 529  pack-copy */
f_2697(t3,lf[68],lf[114]);}

/* k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1 /* (set! s32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 530  pack-copy */
f_2697(t3,lf[70],lf[115]);}

/* k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2834,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1 /* (set! f32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 531  pack-copy */
f_2697(t3,lf[72],lf[116]);}

/* k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2838,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1 /* (set! f64vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 533  unpack */
f_2715(t3,lf[57],C_SCHEME_TRUE,lf[117]);}

/* k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1 /* (set! blob->u8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 534  unpack */
f_2715(t3,lf[59],C_SCHEME_TRUE,lf[118]);}

/* k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1 /* (set! blob->s8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 535  unpack */
f_2715(t3,lf[62],C_fix(2),lf[119]);}

/* k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
t2=C_mutate((C_word*)lf[119]+1 /* (set! blob->u16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 536  unpack */
f_2715(t3,lf[64],C_fix(2),lf[120]);}

/* k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1 /* (set! blob->s16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 537  unpack */
f_2715(t3,lf[66],C_fix(4),lf[121]);}

/* k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=C_mutate((C_word*)lf[121]+1 /* (set! blob->u32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 538  unpack */
f_2715(t3,lf[68],C_fix(4),lf[122]);}

/* k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1 /* (set! blob->s32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 539  unpack */
f_2715(t3,lf[70],C_fix(4),lf[123]);}

/* k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1 /* (set! blob->f32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 540  unpack */
f_2715(t3,lf[72],C_fix(8),lf[124]);}

/* k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2870,2,t0,t1);}
t2=C_mutate((C_word*)lf[124]+1 /* (set! blob->f64vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 542  unpack-copy */
f_2744(t3,lf[57],C_SCHEME_TRUE,lf[125]);}

/* k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2874,2,t0,t1);}
t2=C_mutate((C_word*)lf[125]+1 /* (set! blob->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 543  unpack-copy */
f_2744(t3,lf[59],C_SCHEME_TRUE,lf[126]);}

/* k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2878,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1 /* (set! blob->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 544  unpack-copy */
f_2744(t3,lf[62],C_fix(2),lf[127]);}

/* k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2882,2,t0,t1);}
t2=C_mutate((C_word*)lf[127]+1 /* (set! blob->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 545  unpack-copy */
f_2744(t3,lf[64],C_fix(2),lf[128]);}

/* k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1 /* (set! blob->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 546  unpack-copy */
f_2744(t3,lf[66],C_fix(4),lf[129]);}

/* k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=C_mutate((C_word*)lf[129]+1 /* (set! blob->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 547  unpack-copy */
f_2744(t3,lf[68],C_fix(4),lf[130]);}

/* k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1 /* (set! blob->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 548  unpack-copy */
f_2744(t3,lf[70],C_fix(4),lf[131]);}

/* k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=C_mutate((C_word*)lf[131]+1 /* (set! blob->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 549  unpack-copy */
f_2744(t3,lf[72],C_fix(8),lf[132]);}

/* k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[88],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2902,2,t0,t1);}
t2=C_mutate((C_word*)lf[132]+1 /* (set! blob->f64vector ...) */,t1);
t3=*((C_word*)lf[133]+1);
t4=*((C_word*)lf[134]+1);
t5=(C_word)C_a_i_list(&a,16,lf[135],*((C_word*)lf[74]+1),lf[136],*((C_word*)lf[75]+1),lf[137],*((C_word*)lf[76]+1),lf[138],*((C_word*)lf[77]+1),lf[139],*((C_word*)lf[78]+1),lf[140],*((C_word*)lf[79]+1),lf[141],*((C_word*)lf[80]+1),lf[142],*((C_word*)lf[81]+1));
t6=C_mutate((C_word*)lf[133]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2907,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=*((C_word*)lf[147]+1);
t8=C_mutate((C_word*)lf[147]+1 /* (set! user-print-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2968,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[149] /* (set! subvector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3128,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[150]+1 /* (set! subu8vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3171,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[151]+1 /* (set! subu16vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3177,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[152]+1 /* (set! subu32vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3183,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[153]+1 /* (set! subs8vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3189,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[154]+1 /* (set! subs16vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3195,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[155]+1 /* (set! subs32vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3201,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[156]+1 /* (set! subf32vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3207,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[157]+1 /* (set! subf64vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3213,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[158]+1 /* (set! write-u8vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3219,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[162]+1 /* (set! read-u8vector! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3332,tmp=(C_word)a,a+=2,tmp));
t20=*((C_word*)lf[165]+1);
t21=*((C_word*)lf[166]+1);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3430,tmp=(C_word)a,a+=2,tmp);
t23=C_mutate((C_word*)lf[167]+1 /* (set! read-u8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3439,a[2]=t20,a[3]=t21,a[4]=t22,tmp=(C_word)a,a+=5,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3554,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 671  register-feature! */
t25=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t25+1)))(3,t25,t24,lf[171]);}

/* k3552 in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_3439r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3439r(t0,t1,t2);}}

static void C_ccall f_3439r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3503,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3508,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n10241055 */
t6=t5;
f_3508(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-p10251053 */
t8=t4;
f_3503(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body10221030 */
t10=t3;
f_3441(t10,t1,t6,t8);}}}

/* def-n1024 in read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3508,NULL,2,t0,t1);}
/* def-p10251053 */
t2=((C_word*)t0)[2];
f_3503(t2,t1,C_SCHEME_FALSE);}

/* def-p1025 in read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3503(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3503,NULL,3,t0,t1,t2);}
/* body10221030 */
t3=((C_word*)t0)[2];
f_3441(t3,t1,t2,*((C_word*)lf[164]+1));}

/* body1022 in read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3441(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3441,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 651  ##sys#check-port */
t5=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[167]);}

/* k3443 in body1022 in read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],lf[167]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 653  ##sys#allocate-vector */
t4=*((C_word*)lf[52]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[7],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 660  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3470 in k3443 in body1022 in read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3472,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3477(t5,((C_word*)t0)[2]);}

/* loop in k3470 in k3443 in body1022 in read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3477(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3477,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 662  ##sys#read-char-0 */
t3=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3479 in loop in k3470 in k3443 in body1022 in read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3481,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3490,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 664  get-output-string */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3499,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 668  ##sys#write-char/port */
t3=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}

/* k3497 in k3479 in loop in k3470 in k3443 in body1022 in read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 669  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3477(t2,((C_word*)t0)[2]);}

/* k3488 in k3479 in loop in k3470 in k3443 in body1022 in read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(t1);
/* srfi-4.scm: 666  wrap */
f_3430(((C_word*)t0)[2],t1,t2);}

/* k3452 in k3443 in body1022 in read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 654  ##sys#read-string! */
t3=*((C_word*)lf[163]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],t1,((C_word*)t0)[2],C_fix(0));}

/* k3455 in k3452 in k3443 in body1022 in read-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[57],((C_word*)t0)[5]));}
else{
/* srfi-4.scm: 658  wrap */
f_3430(((C_word*)t0)[3],((C_word*)t0)[5],t1);}}

/* wrap in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3430(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3430,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3438,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 646  ##sys#allocate-vector */
t5=*((C_word*)lf[52]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3436 in wrap in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3438,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_substring_copy(((C_word*)t0)[4],t1,C_fix(0),((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[57],t1));}

/* read-u8vector! in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3332r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3332r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3332r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3334,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3379,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3384,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port976997 */
t9=t8;
f_3384(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start977995 */
t11=t7;
f_3379(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
/* body974982 */
t13=t6;
f_3334(t13,t1,t9,t11);}}}

/* def-port976 in read-u8vector! in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3384,NULL,2,t0,t1);}
/* def-start977995 */
t2=((C_word*)t0)[2];
f_3379(t2,t1,*((C_word*)lf[164]+1));}

/* def-start977 in read-u8vector! in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3379(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3379,NULL,3,t0,t1,t2);}
/* body974982 */
t3=((C_word*)t0)[2];
f_3334(t3,t1,t2,C_fix(0));}

/* body974 in read-u8vector! in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3334(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3334,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3338,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 630  ##sys#check-port */
t5=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[162]);}

/* k3336 in body974 in read-u8vector! in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[162]);
t3=(C_word)C_i_check_structure_2(((C_word*)t0)[5],lf[57],lf[162]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[4])[1],lf[162]);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1]);
t7=(C_word)C_block_size(t4);
if(C_truep((C_word)C_fixnum_greaterp(t6,t7))){
t8=(C_word)C_block_size(t4);
t9=(C_word)C_u_fixnum_difference(t8,((C_word*)t0)[6]);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
/* srfi-4.scm: 638  ##sys#read-string! */
t11=*((C_word*)lf[163]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1],t4,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
/* srfi-4.scm: 638  ##sys#read-string! */
t8=*((C_word*)lf[163]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1],t4,((C_word*)t0)[2],((C_word*)t0)[6]);}}
else{
/* srfi-4.scm: 638  ##sys#read-string! */
t5=*((C_word*)lf[163]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1],t4,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* write-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_3219r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3219r(t0,t1,t2,t3);}}

static void C_ccall f_3219r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3221,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3258,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3267,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3272,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-port926952 */
t8=t7;
f_3272(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-from927950 */
t10=t6;
f_3267(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-to928947 */
t12=t5;
f_3258(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body924933 */
t14=t4;
f_3221(t14,t1,t8,t10,t12);}}}}

/* def-port926 in write-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3272,NULL,2,t0,t1);}
/* def-from927950 */
t2=((C_word*)t0)[2];
f_3267(t2,t1,*((C_word*)lf[161]+1));}

/* def-from927 in write-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3267(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3267,NULL,3,t0,t1,t2);}
/* def-to928947 */
t3=((C_word*)t0)[2];
f_3258(t3,t1,t2,C_fix(0));}

/* def-to928 in write-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3258(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3258,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_8vector_length(((C_word*)t0)[3]);
/* body924933 */
t5=((C_word*)t0)[2];
f_3221(t5,t1,t2,t3,t4);}

/* body924 in write-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3221(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3221,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(((C_word*)t0)[2],lf[57],lf[158]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3228,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 623  ##sys#check-port */
t7=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,lf[158]);}

/* k3226 in body924 in write-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3228,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3236(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop938 in k3226 in body924 in write-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3236(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3236,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3246,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_make_character((C_word)C_unfix((C_word)C_u8peek(((C_word*)t0)[3],t2)));
/* srfi-4.scm: 627  ##sys#write-char-0 */
t5=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* k3244 in doloop938 in k3226 in body924 in write-u8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3236(t3,((C_word*)t0)[2],t2);}

/* subf64vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3213,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 619  subvector */
f_3128(t1,t2,lf[72],C_fix(8),t3,t4,lf[157]);}

/* subf32vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3207,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 618  subvector */
f_3128(t1,t2,lf[70],C_fix(4),t3,t4,lf[156]);}

/* subs32vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3201,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 617  subvector */
f_3128(t1,t2,lf[68],C_fix(4),t3,t4,lf[155]);}

/* subs16vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3195,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 616  subvector */
f_3128(t1,t2,lf[64],C_fix(2),t3,t4,lf[154]);}

/* subs8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3189,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 615  subvector */
f_3128(t1,t2,lf[59],C_fix(1),t3,t4,lf[153]);}

/* subu32vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3183,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 614  subvector */
f_3128(t1,t2,lf[66],C_fix(4),t3,t4,lf[152]);}

/* subu16vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3177,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 613  subvector */
f_3128(t1,t2,lf[62],C_fix(2),t3,t4,lf[151]);}

/* subu8vector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3171,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 612  subvector */
f_3128(t1,t2,lf[57],C_fix(1),t3,t4,lf[150]);}

/* subvector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_3128(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3128,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(C_word)C_i_check_structure_2(t2,t3,t7);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_block_size(t9);
t11=(C_word)C_fixnum_divide(t10,t4);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3141,a[2]=t7,a[3]=t11,a[4]=t1,a[5]=t9,a[6]=t3,a[7]=t4,a[8]=t5,a[9]=t6,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_u_fixnum_plus(t11,C_fix(1));
/* srfi-4.scm: 603  ##sys#check-range */
t14=*((C_word*)lf[29]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t12,t5,C_fix(0),t13,t7);}

/* k3139 in subvector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 604  ##sys#check-range */
t4=*((C_word*)lf[29]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[9],C_fix(0),t3,((C_word*)t0)[2]);}

/* k3142 in k3139 in subvector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3144,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_fixnum_times(((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 606  ##sys#allocate-vector */
t5=*((C_word*)lf[52]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3148 in k3142 in k3139 in subvector in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3150,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_a_i_record(&a,2,((C_word*)t0)[7],t1);
t4=(C_word)C_fixnum_times(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_copy_subvector(t1,((C_word*)t0)[4],C_fix(0),t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* ##sys#user-print-hook in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2968,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[82]+1),C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[135],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[57],t6);
t8=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[83]+1),C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[136],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[59],t9);
t11=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[84]+1),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[137],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[62],t12);
t14=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[85]+1),C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[138],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[64],t15);
t17=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[86]+1),C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,lf[139],t17);
t19=(C_word)C_a_i_cons(&a,2,lf[66],t18);
t20=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[87]+1),C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,lf[140],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[68],t21);
t23=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[88]+1),C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,lf[141],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[70],t24);
t26=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[89]+1),C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[142],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[72],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,t25,t29);
t31=(C_word)C_a_i_cons(&a,2,t22,t30);
t32=(C_word)C_a_i_cons(&a,2,t19,t31);
t33=(C_word)C_a_i_cons(&a,2,t16,t32);
t34=(C_word)C_a_i_cons(&a,2,t13,t33);
t35=(C_word)C_a_i_cons(&a,2,t10,t34);
t36=(C_word)C_a_i_cons(&a,2,t7,t35);
t37=(C_word)C_u_i_assq((C_word)C_slot(t2,C_fix(0)),t36);
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2978,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t37,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 590  ##sys#print */
t39=*((C_word*)lf[148]+1);
((C_proc5)(void*)(*((C_word*)t39+1)))(5,t39,t38,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
/* srfi-4.scm: 593  old-hook */
t38=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t38+1)))(5,t38,t1,t2,t3,t4);}}

/* k2976 in ##sys#user-print-hook in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
/* srfi-4.scm: 591  ##sys#print */
t4=*((C_word*)lf[148]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k2979 in k2976 in ##sys#user-print-hook in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
t2=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* g853854 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2989 in k2979 in k2976 in ##sys#user-print-hook in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 592  ##sys#print */
t2=*((C_word*)lf[148]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2907,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2917,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 567  read */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* srfi-4.scm: 572  old-hook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k2915 in ##sys#user-read-hook in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2917,2,t0,t1);}
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=(C_word)C_eqp(t3,lf[143]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[144]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_u_i_memq(t3,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* g833834 */
t8=t7;
f_2936(t8,((C_word*)t0)[5],t6);}
else{
/* srfi-4.scm: 571  ##sys#read-error */
t7=*((C_word*)lf[145]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[5],((C_word*)t0)[2],lf[146],t3);}}}

/* g833 in k2915 in ##sys#user-read-hook in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2936(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2936,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2947,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 570  read */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2945 in g833 in k2915 in ##sys#user-read-hook in k2900 in k2896 in k2892 in k2888 in k2884 in k2880 in k2876 in k2872 in k2868 in k2864 in k2860 in k2856 in k2852 in k2848 in k2844 in k2840 in k2836 in k2832 in k2828 in k2824 in k2820 in k2816 in k2812 in k2808 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g836837 */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f4005 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f4005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f4005,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[72],lf[108]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f4012 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f4012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f4012,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[70],lf[107]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f4019 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f4019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f4019,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[68],lf[106]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f4026 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f4026(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f4026,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[66],lf[105]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f4033 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f4033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f4033,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[64],lf[104]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f4040 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f4040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f4040,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[62],lf[103]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f4047 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f4047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f4047,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[59],lf[102]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f4054 in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f4054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f4054,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[57],lf[101]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unpack-copy in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2744(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2744,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2746,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_2746 in unpack-copy in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2746,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 507  ##sys#make-blob */
t6=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k2754 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2756,2,t0,t1);}
t2=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(((C_word*)t0)[6],((C_word*)t0)[7])));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,((C_word*)t0)[4],(C_word)C_copy_block(((C_word*)t0)[3],t1)));}
else{
/* srfi-4.scm: 513  ##sys#error */
t4=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[5],((C_word*)t0)[2],lf[100],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* unpack in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2715(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2715,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2717,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_2717 in unpack in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2717,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(t4,((C_word*)t0)[3])));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,2,((C_word*)t0)[2],t2));}
else{
/* srfi-4.scm: 501  ##sys#error */
t7=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,((C_word*)t0)[4],lf[99],((C_word*)t0)[2],t4,((C_word*)t0)[3]);}}

/* pack-copy in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2697(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2697,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2699,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_2699 in pack-copy in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2699,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2709,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_block_size(t4);
/* srfi-4.scm: 491  ##sys#make-blob */
t7=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k2707 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_copy_block(((C_word*)t0)[2],t1));}

/* f64vector? in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2680,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[72]));}

/* f32vector? in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2674,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[70]));}

/* s32vector? in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2668,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[68]));}

/* u32vector? in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2662,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[66]));}

/* s16vector? in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2656,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[64]));}

/* u16vector? in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2650,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[62]));}

/* s8vector? in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2644,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[59]));}

/* u8vector? in k2634 in k2630 in k2626 in k2622 in k2618 in k2614 in k2610 in k2606 in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2638,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[57]));}

/* init in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2571(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2571,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2573,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_2573 in init in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2573,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2577,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 449  length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2575 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2577,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2582(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2575 */
static void C_fcall f_2582(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2582,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 453  ref */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}}

/* k2594 in loop in k2575 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2600,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 454  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2582(t4,t2,t3);}

/* k2598 in k2594 in loop in k2575 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2600,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f64vector in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2565r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2565r(t0,t1,t2);}}

static void C_ccall f_2565r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 440  list->f64vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f32vector in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2559r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2559r(t0,t1,t2);}}

static void C_ccall f_2559r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 436  list->f32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s32vector in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2553r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2553r(t0,t1,t2);}}

static void C_ccall f_2553r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 432  list->s32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u32vector in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2547r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2547r(t0,t1,t2);}}

static void C_ccall f_2547r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 428  list->u32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s16vector in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2541r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2541r(t0,t1,t2);}}

static void C_ccall f_2541r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 424  list->s16vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u16vector in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2535r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2535r(t0,t1,t2);}}

static void C_ccall f_2535r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 420  list->u16vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s8vector in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2529r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2529r(t0,t1,t2);}}

static void C_ccall f_2529r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 416  list->s8vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u8vector in k2519 in k2515 in k2511 in k2507 in k2503 in k2499 in k2495 in k2491 in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2523r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2523r(t0,t1,t2);}}

static void C_ccall f_2523r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 412  list->u8vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* init in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2453(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2453,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2455,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_2455 in init in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2455,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2465,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 390  make */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k2463 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2465,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2470(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop668 in k2463 */
static void C_fcall f_2470(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2470,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=((C_word*)t0)[5];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2477,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* srfi-4.scm: 395  set */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[5],t3,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-4.scm: 396  ##sys#error-not-a-proper-list */
t6=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}}

/* k2475 in doloop668 in k2463 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2470(t2,((C_word*)t0)[4],(C_word)C_slot(((C_word*)t0)[3],C_fix(1)),(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f64vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2329r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2329r(t0,t1,t2,t3);}}

static void C_ccall f_2329r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2383,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2388,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2393,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init611645 */
t8=t7;
f_2393(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?612643 */
t10=t6;
f_2388(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin613640 */
t12=t5;
f_2383(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body609618 */
t14=t4;
f_2331(t14,t1,t8,t10);}}}}

/* def-init611 in make-f64vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2393,NULL,2,t0,t1);}
/* def-ext?612643 */
t2=((C_word*)t0)[2];
f_2388(t2,t1,C_SCHEME_FALSE);}

/* def-ext?612 in make-f64vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2388,NULL,3,t0,t1,t2);}
/* def-fin613640 */
t3=((C_word*)t0)[2];
f_2383(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin613 in make-f64vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2383(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2383,NULL,4,t0,t1,t2,t3);}
/* body609618 */
t4=((C_word*)t0)[2];
f_2331(t4,t1,t2,t3);}

/* body609 in make-f64vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2331(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2331,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[71]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2382,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 369  alloc */
f_1460(t6,lf[71],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(3)),t3);}

/* k2380 in body609 in make-f64vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2382,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[72],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=*((C_word*)lf[60]+1);
if(C_truep(t4)){
/* srfi-4.scm: 370  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2341(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2341(2,t4,C_SCHEME_UNDEFINED);}}

/* k2339 in k2380 in body609 in make-f64vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[71]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2353(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 376  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2370 in k2339 in k2380 in body609 in make-f64vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2353(t3,t2);}

/* k2351 in k2339 in k2380 in body609 in make-f64vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2353(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2353,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2358,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2358(t2,C_fix(0)));}

/* doloop629 in k2351 in k2339 in k2380 in body609 in make-f64vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static C_word C_fcall f_2358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_u_i_f64vector_set(((C_word*)t0)[3],t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-f32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2205r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2205r(t0,t1,t2,t3);}}

static void C_ccall f_2205r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2259,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2264,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2269,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init554588 */
t8=t7;
f_2269(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?555586 */
t10=t6;
f_2264(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin556583 */
t12=t5;
f_2259(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body552561 */
t14=t4;
f_2207(t14,t1,t8,t10);}}}}

/* def-init554 in make-f32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2269,NULL,2,t0,t1);}
/* def-ext?555586 */
t2=((C_word*)t0)[2];
f_2264(t2,t1,C_SCHEME_FALSE);}

/* def-ext?555 in make-f32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2264(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2264,NULL,3,t0,t1,t2);}
/* def-fin556583 */
t3=((C_word*)t0)[2];
f_2259(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin556 in make-f32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2259(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2259,NULL,4,t0,t1,t2,t3);}
/* body552561 */
t4=((C_word*)t0)[2];
f_2207(t4,t1,t2,t3);}

/* body552 in make-f32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2207(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2207,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[69]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 354  alloc */
f_1460(t6,lf[69],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2256 in body552 in make-f32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[70],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=*((C_word*)lf[60]+1);
if(C_truep(t4)){
/* srfi-4.scm: 355  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2217(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2217(2,t4,C_SCHEME_UNDEFINED);}}

/* k2215 in k2256 in body552 in make-f32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2217,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[69]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2229(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2248,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 361  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2246 in k2215 in k2256 in body552 in make-f32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2229(t3,t2);}

/* k2227 in k2215 in k2256 in body552 in make-f32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2229(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2229,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2234(t2,C_fix(0)));}

/* doloop572 in k2227 in k2215 in k2256 in body552 in make-f32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static C_word C_fcall f_2234(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_u_i_f32vector_set(((C_word*)t0)[3],t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-s32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2088r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2088r(t0,t1,t2,t3);}}

static void C_ccall f_2088r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2135,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2145,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init500531 */
t8=t7;
f_2145(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?501529 */
t10=t6;
f_2140(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin502526 */
t12=t5;
f_2135(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body498507 */
t14=t4;
f_2090(t14,t1,t8,t10);}}}}

/* def-init500 in make-s32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2145(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2145,NULL,2,t0,t1);}
/* def-ext?501529 */
t2=((C_word*)t0)[2];
f_2140(t2,t1,C_SCHEME_FALSE);}

/* def-ext?501 in make-s32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2140(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2140,NULL,3,t0,t1,t2);}
/* def-fin502526 */
t3=((C_word*)t0)[2];
f_2135(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin502 in make-s32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2135(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2135,NULL,4,t0,t1,t2,t3);}
/* body498507 */
t4=((C_word*)t0)[2];
f_2090(t4,t1,t2,t3);}

/* body498 in make-s32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2090(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2090,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[67]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 341  alloc */
f_1460(t5,lf[67],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2132 in body498 in make-s32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[68],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2100,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=*((C_word*)lf[60]+1);
if(C_truep(t4)){
/* srfi-4.scm: 342  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2100(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2100(2,t4,C_SCHEME_UNDEFINED);}}

/* k2098 in k2132 in body498 in make-s32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2100,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[67]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2114(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop516 in k2098 in k2132 in body498 in make-s32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static C_word C_fcall f_2114(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_s32poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-u32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1971r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1971r(t0,t1,t2,t3);}}

static void C_ccall f_1971r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2018,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2023,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2028,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init446477 */
t8=t7;
f_2028(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?447475 */
t10=t6;
f_2023(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin448472 */
t12=t5;
f_2018(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body444453 */
t14=t4;
f_1973(t14,t1,t8,t10);}}}}

/* def-init446 in make-u32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2028,NULL,2,t0,t1);}
/* def-ext?447475 */
t2=((C_word*)t0)[2];
f_2023(t2,t1,C_SCHEME_FALSE);}

/* def-ext?447 in make-u32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2023,NULL,3,t0,t1,t2);}
/* def-fin448472 */
t3=((C_word*)t0)[2];
f_2018(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin448 in make-u32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_2018(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2018,NULL,4,t0,t1,t2,t3);}
/* body444453 */
t4=((C_word*)t0)[2];
f_1973(t4,t1,t2,t3);}

/* body444 in make-u32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1973(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1973,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[65]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 328  alloc */
f_1460(t5,lf[65],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2015 in body444 in make-u32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[66],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=*((C_word*)lf[60]+1);
if(C_truep(t4)){
/* srfi-4.scm: 329  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1983(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1983(2,t4,C_SCHEME_UNDEFINED);}}

/* k1981 in k2015 in body444 in make-u32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1983,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[65]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1997(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop462 in k1981 in k2015 in body444 in make-u32vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static C_word C_fcall f_1997(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_u32poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-s16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1854r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1854r(t0,t1,t2,t3);}}

static void C_ccall f_1854r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1901,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1906,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init392423 */
t8=t7;
f_1911(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?393421 */
t10=t6;
f_1906(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin394418 */
t12=t5;
f_1901(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body390399 */
t14=t4;
f_1856(t14,t1,t8,t10);}}}}

/* def-init392 in make-s16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1911,NULL,2,t0,t1);}
/* def-ext?393421 */
t2=((C_word*)t0)[2];
f_1906(t2,t1,C_SCHEME_FALSE);}

/* def-ext?393 in make-s16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1906(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1906,NULL,3,t0,t1,t2);}
/* def-fin394418 */
t3=((C_word*)t0)[2];
f_1901(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin394 in make-s16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1901(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1901,NULL,4,t0,t1,t2,t3);}
/* body390399 */
t4=((C_word*)t0)[2];
f_1856(t4,t1,t2,t3);}

/* body390 in make-s16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1856(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1856,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[63]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 315  alloc */
f_1460(t5,lf[63],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1898 in body390 in make-s16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[64],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=*((C_word*)lf[60]+1);
if(C_truep(t4)){
/* srfi-4.scm: 316  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1866(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1866(2,t4,C_SCHEME_UNDEFINED);}}

/* k1864 in k1898 in body390 in make-s16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 320  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-32768),C_fix(32767),lf[63]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1873 in k1864 in k1898 in body390 in make-s16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1880(t2,C_fix(0)));}

/* doloop408 in k1873 in k1864 in k1898 in body390 in make-s16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static C_word C_fcall f_1880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_s16poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-u16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1737r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1737r(t0,t1,t2,t3);}}

static void C_ccall f_1737r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1789,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1794,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init338369 */
t8=t7;
f_1794(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?339367 */
t10=t6;
f_1789(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin340364 */
t12=t5;
f_1784(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body336345 */
t14=t4;
f_1739(t14,t1,t8,t10);}}}}

/* def-init338 in make-u16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1794,NULL,2,t0,t1);}
/* def-ext?339367 */
t2=((C_word*)t0)[2];
f_1789(t2,t1,C_SCHEME_FALSE);}

/* def-ext?339 in make-u16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1789(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1789,NULL,3,t0,t1,t2);}
/* def-fin340364 */
t3=((C_word*)t0)[2];
f_1784(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin340 in make-u16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1784(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1784,NULL,4,t0,t1,t2,t3);}
/* body336345 */
t4=((C_word*)t0)[2];
f_1739(t4,t1,t2,t3);}

/* body336 in make-u16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1739(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1739,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[61]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 302  alloc */
f_1460(t5,lf[61],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k1781 in body336 in make-u16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1783,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[62],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1749,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=*((C_word*)lf[60]+1);
if(C_truep(t4)){
/* srfi-4.scm: 303  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1749(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1749(2,t4,C_SCHEME_UNDEFINED);}}

/* k1747 in k1781 in body336 in make-u16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 307  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(65535),lf[61]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1756 in k1747 in k1781 in body336 in make-u16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1763,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1763(t2,C_fix(0)));}

/* doloop354 in k1756 in k1747 in k1781 in body336 in make-u16vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static C_word C_fcall f_1763(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_u16poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-s8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1620r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1620r(t0,t1,t2,t3);}}

static void C_ccall f_1620r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1667,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1672,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1677,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init284315 */
t8=t7;
f_1677(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?285313 */
t10=t6;
f_1672(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin286310 */
t12=t5;
f_1667(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body282291 */
t14=t4;
f_1622(t14,t1,t8,t10);}}}}

/* def-init284 in make-s8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1677,NULL,2,t0,t1);}
/* def-ext?285313 */
t2=((C_word*)t0)[2];
f_1672(t2,t1,C_SCHEME_FALSE);}

/* def-ext?285 in make-s8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1672,NULL,3,t0,t1,t2);}
/* def-fin286310 */
t3=((C_word*)t0)[2];
f_1667(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin286 in make-s8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1667(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1667,NULL,4,t0,t1,t2,t3);}
/* body282291 */
t4=((C_word*)t0)[2];
f_1622(t4,t1,t2,t3);}

/* body282 in make-s8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1622(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1622,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[58]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 289  alloc */
f_1460(t5,lf[58],((C_word*)t0)[5],t3);}

/* k1664 in body282 in make-s8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1666,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[59],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1632,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=*((C_word*)lf[60]+1);
if(C_truep(t4)){
/* srfi-4.scm: 290  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1632(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1632(2,t4,C_SCHEME_UNDEFINED);}}

/* k1630 in k1664 in body282 in make-s8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1632,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 294  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-128),C_fix(127),lf[58]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1639 in k1630 in k1664 in body282 in make-s8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1646(t2,C_fix(0)));}

/* doloop300 in k1639 in k1630 in k1664 in body282 in make-s8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static C_word C_fcall f_1646(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_s8poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* make-u8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1503(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1503r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1503r(t0,t1,t2,t3);}}

static void C_ccall f_1503r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1550,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1555,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1560,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init229260 */
t8=t7;
f_1560(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?230258 */
t10=t6;
f_1555(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin?231255 */
t12=t5;
f_1550(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body227236 */
t14=t4;
f_1505(t14,t1,t8,t10,t12);}}}}

/* def-init229 in make-u8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1560,NULL,2,t0,t1);}
/* def-ext?230258 */
t2=((C_word*)t0)[2];
f_1555(t2,t1,C_SCHEME_FALSE);}

/* def-ext?230 in make-u8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1555(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1555,NULL,3,t0,t1,t2);}
/* def-fin?231255 */
t3=((C_word*)t0)[2];
f_1550(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin?231 in make-u8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1550(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1550,NULL,4,t0,t1,t2,t3);}
/* body227236 */
t4=((C_word*)t0)[2];
f_1505(t4,t1,t2,t3,C_SCHEME_TRUE);}

/* body227 in make-u8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1505(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1505,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[56]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* srfi-4.scm: 276  alloc */
f_1460(t6,lf[56],((C_word*)t0)[5],t3);}

/* k1547 in body227 in make-u8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1549,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[57],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=((C_word*)t0)[4];
if(C_truep(t4)){
/* srfi-4.scm: 277  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1515(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1515(2,t4,C_SCHEME_UNDEFINED);}}

/* k1513 in k1547 in body227 in make-u8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 281  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(255),lf[56]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1522 in k1513 in k1547 in body227 in make-u8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1529(t2,C_fix(0)));}

/* doloop245 in k1522 in k1513 in k1547 in body227 in make-u8vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static C_word C_fcall f_1529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
t4=(C_word)C_u8poke((C_word)C_slot(((C_word*)t0)[3],C_fix(1)),t2,t3);
t6=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t6;
goto loop;}}

/* release-number-vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1478,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1485,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1485(t5,(C_word)C_u_i_memq(t4,lf[55]));}
else{
t4=t3;
f_1485(t4,C_SCHEME_FALSE);}}

/* k1483 in release-number-vector in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1485(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub194(C_SCHEME_UNDEFINED,t3));}
else{
/* srfi-4.scm: 271  ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[53],lf[54],((C_word*)t0)[2]);}}

/* alloc in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1460(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1460,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=(C_word)stub189(C_SCHEME_UNDEFINED,t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* srfi-4.scm: 261  ##sys#error */
t7=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,lf[51],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1476,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 262  ##sys#allocate-vector */
t6=*((C_word*)lf[52]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k1474 in alloc in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_string_to_bytevector(t1);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ext-free in k1453 in k1449 in k1445 in k1441 in k1437 in k1433 in k1429 in k1425 in k1421 in k1417 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1458,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub194(C_SCHEME_UNDEFINED,t2));}

/* f_1308 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1308,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1312,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 179  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1310 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1315,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fits_in_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1315(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 181  ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[38],lf[39],((C_word*)t0)[2]);}}

/* k1313 in k1310 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 182  ##sys#check-range */
t3=*((C_word*)lf[29]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[38]);}

/* k1316 in k1313 in k1310 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_s32poke((C_word)C_slot(t3,C_fix(1)),t4,t5));}

/* f_1335 in k1405 in k1401 in k1397 in k1393 in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1335,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1339,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 187  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1337 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1342,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_negativep(((C_word*)t0)[2]))){
/* srfi-4.scm: 189  ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[35],lf[36],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_fits_in_unsigned_int_p(((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t2;
f_1342(2,t4,t3);}
else{
/* srfi-4.scm: 191  ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[35],lf[37],((C_word*)t0)[2]);}}}

/* k1340 in k1337 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 192  ##sys#check-range */
t3=*((C_word*)lf[29]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[35]);}

/* k1343 in k1340 in k1337 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u32poke((C_word)C_slot(t3,C_fix(1)),t4,t5));}

/* setf in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1369(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1369,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1371,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_1371 in setf in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1371,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1375,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 197  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1373 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1375,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1381,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 199  ##sys#check-range */
t4=*((C_word*)lf[29]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1379 in k1373 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
/* srfi-4.scm: 200  upd */
t4=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t3);}
else{
/* srfi-4.scm: 202  exact->inexact */
C_exact_to_inexact(3,0,t2,((C_word*)t0)[2]);}}

/* k1386 in k1379 in k1373 */
static void C_ccall f_1388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 200  upd */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setu in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1280(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1280,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1282,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_1282 in setu in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1282,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1286,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 170  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1284 */
static void C_ccall f_1286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1286,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1292,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[7],C_fix(0)))){
/* srfi-4.scm: 173  ##sys#error */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[6],lf[30],((C_word*)t0)[7]);}
else{
t4=t3;
f_1292(2,t4,C_SCHEME_UNDEFINED);}}

/* k1290 in k1284 */
static void C_ccall f_1292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1295,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 174  ##sys#check-range */
t3=*((C_word*)lf[29]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1293 in k1290 in k1284 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 175  upd */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1263(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1263,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1265,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_1265 in set in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1265,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1269,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 163  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1267 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1269,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1275,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 165  ##sys#check-range */
t4=*((C_word*)lf[29]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1273 in k1267 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 166  upd */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* get in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_fcall f_1249(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1249,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1251,a[2]=t2,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp));}

/* f_1251 in get in k1245 in k1241 in k1237 in k1233 in k1229 in k1225 in k1221 in k1217 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1251,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1255,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 157  length */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1253 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 158  ##sys#check-range */
t3=*((C_word*)lf[29]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),t1,((C_word*)t0)[2]);}

/* k1256 in k1253 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 159  acc */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* len */
static void C_fcall f_1206(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1206,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1208,a[2]=t3,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));}

/* f_1208 in len */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1208,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_block_size((C_word)C_slot(t2,C_fix(1)));
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_fixnum_shift_right(t4,((C_word*)t0)[2]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* ##sys#f64vector-set! */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1203,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_i_f64vector_set(t2,t3,t4));}

/* ##sys#f32vector-set! */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1200,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_i_f32vector_set(t2,t3,t4));}

/* ##sys#s32vector-set! */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1197,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u32vector-set! */
static void C_ccall f_1194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1194,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s16vector-set! */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1191,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u16vector-set! */
static void C_ccall f_1188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1188,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s8vector-set! */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1185,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u8vector-set! */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1182,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f64vector-ref */
static void C_ccall f_1179(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1179,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_f64vector_ref(&a,2,t2,t3));}

/* ##sys#f32vector-ref */
static void C_ccall f_1176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1176,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_f32vector_ref(&a,2,t2,t3));}

/* ##sys#s32vector-ref */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1173,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_s32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u32vector-ref */
static void C_ccall f_1170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1170,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_u32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s16vector-ref */
static void C_ccall f_1167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1167,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u16vector-ref */
static void C_ccall f_1164(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1164,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s8vector-ref */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1161,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u8vector-ref */
static void C_ccall f_1158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1158,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#check-inexact-interval */
static void C_ccall f_1137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1137,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_number_2(t2,t5);
t7=(C_word)C_i_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_i_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 97   ##sys#error */
t9=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[4],t2,t3,t4);}
else{
t9=C_SCHEME_UNDEFINED;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* ##sys#check-exact-interval */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1122,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_exact_2(t2,t5);
t7=(C_word)C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 91   ##sys#error */
t9=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t1,t5,lf[2],t2,t3,t4);}
else{
t9=C_SCHEME_UNDEFINED;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[286] = {
{"toplevel:srfi_4_scm",(void*)C_srfi_4_toplevel},
{"f_1219:srfi_4_scm",(void*)f_1219},
{"f_1223:srfi_4_scm",(void*)f_1223},
{"f_1227:srfi_4_scm",(void*)f_1227},
{"f_1231:srfi_4_scm",(void*)f_1231},
{"f_1235:srfi_4_scm",(void*)f_1235},
{"f_1239:srfi_4_scm",(void*)f_1239},
{"f_1243:srfi_4_scm",(void*)f_1243},
{"f_1247:srfi_4_scm",(void*)f_1247},
{"f_1395:srfi_4_scm",(void*)f_1395},
{"f_1399:srfi_4_scm",(void*)f_1399},
{"f_1403:srfi_4_scm",(void*)f_1403},
{"f_1407:srfi_4_scm",(void*)f_1407},
{"f_1419:srfi_4_scm",(void*)f_1419},
{"f_1423:srfi_4_scm",(void*)f_1423},
{"f_3586:srfi_4_scm",(void*)f_3586},
{"f_1427:srfi_4_scm",(void*)f_1427},
{"f_3582:srfi_4_scm",(void*)f_3582},
{"f_1431:srfi_4_scm",(void*)f_1431},
{"f_3578:srfi_4_scm",(void*)f_3578},
{"f_1435:srfi_4_scm",(void*)f_1435},
{"f_3574:srfi_4_scm",(void*)f_3574},
{"f_1439:srfi_4_scm",(void*)f_1439},
{"f_3570:srfi_4_scm",(void*)f_3570},
{"f_1443:srfi_4_scm",(void*)f_1443},
{"f_3566:srfi_4_scm",(void*)f_3566},
{"f_1447:srfi_4_scm",(void*)f_1447},
{"f_3562:srfi_4_scm",(void*)f_3562},
{"f_1451:srfi_4_scm",(void*)f_1451},
{"f_3558:srfi_4_scm",(void*)f_3558},
{"f_1455:srfi_4_scm",(void*)f_1455},
{"f_2493:srfi_4_scm",(void*)f_2493},
{"f_2497:srfi_4_scm",(void*)f_2497},
{"f_2501:srfi_4_scm",(void*)f_2501},
{"f_2505:srfi_4_scm",(void*)f_2505},
{"f_2509:srfi_4_scm",(void*)f_2509},
{"f_2513:srfi_4_scm",(void*)f_2513},
{"f_2517:srfi_4_scm",(void*)f_2517},
{"f_2521:srfi_4_scm",(void*)f_2521},
{"f_2608:srfi_4_scm",(void*)f_2608},
{"f_2612:srfi_4_scm",(void*)f_2612},
{"f_2616:srfi_4_scm",(void*)f_2616},
{"f_2620:srfi_4_scm",(void*)f_2620},
{"f_2624:srfi_4_scm",(void*)f_2624},
{"f_2628:srfi_4_scm",(void*)f_2628},
{"f_2632:srfi_4_scm",(void*)f_2632},
{"f_2636:srfi_4_scm",(void*)f_2636},
{"f_2810:srfi_4_scm",(void*)f_2810},
{"f_2814:srfi_4_scm",(void*)f_2814},
{"f_2818:srfi_4_scm",(void*)f_2818},
{"f_2822:srfi_4_scm",(void*)f_2822},
{"f_2826:srfi_4_scm",(void*)f_2826},
{"f_2830:srfi_4_scm",(void*)f_2830},
{"f_2834:srfi_4_scm",(void*)f_2834},
{"f_2838:srfi_4_scm",(void*)f_2838},
{"f_2842:srfi_4_scm",(void*)f_2842},
{"f_2846:srfi_4_scm",(void*)f_2846},
{"f_2850:srfi_4_scm",(void*)f_2850},
{"f_2854:srfi_4_scm",(void*)f_2854},
{"f_2858:srfi_4_scm",(void*)f_2858},
{"f_2862:srfi_4_scm",(void*)f_2862},
{"f_2866:srfi_4_scm",(void*)f_2866},
{"f_2870:srfi_4_scm",(void*)f_2870},
{"f_2874:srfi_4_scm",(void*)f_2874},
{"f_2878:srfi_4_scm",(void*)f_2878},
{"f_2882:srfi_4_scm",(void*)f_2882},
{"f_2886:srfi_4_scm",(void*)f_2886},
{"f_2890:srfi_4_scm",(void*)f_2890},
{"f_2894:srfi_4_scm",(void*)f_2894},
{"f_2898:srfi_4_scm",(void*)f_2898},
{"f_2902:srfi_4_scm",(void*)f_2902},
{"f_3554:srfi_4_scm",(void*)f_3554},
{"f_3439:srfi_4_scm",(void*)f_3439},
{"f_3508:srfi_4_scm",(void*)f_3508},
{"f_3503:srfi_4_scm",(void*)f_3503},
{"f_3441:srfi_4_scm",(void*)f_3441},
{"f_3445:srfi_4_scm",(void*)f_3445},
{"f_3472:srfi_4_scm",(void*)f_3472},
{"f_3477:srfi_4_scm",(void*)f_3477},
{"f_3481:srfi_4_scm",(void*)f_3481},
{"f_3499:srfi_4_scm",(void*)f_3499},
{"f_3490:srfi_4_scm",(void*)f_3490},
{"f_3454:srfi_4_scm",(void*)f_3454},
{"f_3457:srfi_4_scm",(void*)f_3457},
{"f_3430:srfi_4_scm",(void*)f_3430},
{"f_3438:srfi_4_scm",(void*)f_3438},
{"f_3332:srfi_4_scm",(void*)f_3332},
{"f_3384:srfi_4_scm",(void*)f_3384},
{"f_3379:srfi_4_scm",(void*)f_3379},
{"f_3334:srfi_4_scm",(void*)f_3334},
{"f_3338:srfi_4_scm",(void*)f_3338},
{"f_3219:srfi_4_scm",(void*)f_3219},
{"f_3272:srfi_4_scm",(void*)f_3272},
{"f_3267:srfi_4_scm",(void*)f_3267},
{"f_3258:srfi_4_scm",(void*)f_3258},
{"f_3221:srfi_4_scm",(void*)f_3221},
{"f_3228:srfi_4_scm",(void*)f_3228},
{"f_3236:srfi_4_scm",(void*)f_3236},
{"f_3246:srfi_4_scm",(void*)f_3246},
{"f_3213:srfi_4_scm",(void*)f_3213},
{"f_3207:srfi_4_scm",(void*)f_3207},
{"f_3201:srfi_4_scm",(void*)f_3201},
{"f_3195:srfi_4_scm",(void*)f_3195},
{"f_3189:srfi_4_scm",(void*)f_3189},
{"f_3183:srfi_4_scm",(void*)f_3183},
{"f_3177:srfi_4_scm",(void*)f_3177},
{"f_3171:srfi_4_scm",(void*)f_3171},
{"f_3128:srfi_4_scm",(void*)f_3128},
{"f_3141:srfi_4_scm",(void*)f_3141},
{"f_3144:srfi_4_scm",(void*)f_3144},
{"f_3150:srfi_4_scm",(void*)f_3150},
{"f_2968:srfi_4_scm",(void*)f_2968},
{"f_2978:srfi_4_scm",(void*)f_2978},
{"f_2981:srfi_4_scm",(void*)f_2981},
{"f_2991:srfi_4_scm",(void*)f_2991},
{"f_2907:srfi_4_scm",(void*)f_2907},
{"f_2917:srfi_4_scm",(void*)f_2917},
{"f_2936:srfi_4_scm",(void*)f_2936},
{"f_2947:srfi_4_scm",(void*)f_2947},
{"f4005:srfi_4_scm",(void*)f4005},
{"f4012:srfi_4_scm",(void*)f4012},
{"f4019:srfi_4_scm",(void*)f4019},
{"f4026:srfi_4_scm",(void*)f4026},
{"f4033:srfi_4_scm",(void*)f4033},
{"f4040:srfi_4_scm",(void*)f4040},
{"f4047:srfi_4_scm",(void*)f4047},
{"f4054:srfi_4_scm",(void*)f4054},
{"f_2744:srfi_4_scm",(void*)f_2744},
{"f_2746:srfi_4_scm",(void*)f_2746},
{"f_2756:srfi_4_scm",(void*)f_2756},
{"f_2715:srfi_4_scm",(void*)f_2715},
{"f_2717:srfi_4_scm",(void*)f_2717},
{"f_2697:srfi_4_scm",(void*)f_2697},
{"f_2699:srfi_4_scm",(void*)f_2699},
{"f_2709:srfi_4_scm",(void*)f_2709},
{"f_2680:srfi_4_scm",(void*)f_2680},
{"f_2674:srfi_4_scm",(void*)f_2674},
{"f_2668:srfi_4_scm",(void*)f_2668},
{"f_2662:srfi_4_scm",(void*)f_2662},
{"f_2656:srfi_4_scm",(void*)f_2656},
{"f_2650:srfi_4_scm",(void*)f_2650},
{"f_2644:srfi_4_scm",(void*)f_2644},
{"f_2638:srfi_4_scm",(void*)f_2638},
{"f_2571:srfi_4_scm",(void*)f_2571},
{"f_2573:srfi_4_scm",(void*)f_2573},
{"f_2577:srfi_4_scm",(void*)f_2577},
{"f_2582:srfi_4_scm",(void*)f_2582},
{"f_2596:srfi_4_scm",(void*)f_2596},
{"f_2600:srfi_4_scm",(void*)f_2600},
{"f_2565:srfi_4_scm",(void*)f_2565},
{"f_2559:srfi_4_scm",(void*)f_2559},
{"f_2553:srfi_4_scm",(void*)f_2553},
{"f_2547:srfi_4_scm",(void*)f_2547},
{"f_2541:srfi_4_scm",(void*)f_2541},
{"f_2535:srfi_4_scm",(void*)f_2535},
{"f_2529:srfi_4_scm",(void*)f_2529},
{"f_2523:srfi_4_scm",(void*)f_2523},
{"f_2453:srfi_4_scm",(void*)f_2453},
{"f_2455:srfi_4_scm",(void*)f_2455},
{"f_2465:srfi_4_scm",(void*)f_2465},
{"f_2470:srfi_4_scm",(void*)f_2470},
{"f_2477:srfi_4_scm",(void*)f_2477},
{"f_2329:srfi_4_scm",(void*)f_2329},
{"f_2393:srfi_4_scm",(void*)f_2393},
{"f_2388:srfi_4_scm",(void*)f_2388},
{"f_2383:srfi_4_scm",(void*)f_2383},
{"f_2331:srfi_4_scm",(void*)f_2331},
{"f_2382:srfi_4_scm",(void*)f_2382},
{"f_2341:srfi_4_scm",(void*)f_2341},
{"f_2372:srfi_4_scm",(void*)f_2372},
{"f_2353:srfi_4_scm",(void*)f_2353},
{"f_2358:srfi_4_scm",(void*)f_2358},
{"f_2205:srfi_4_scm",(void*)f_2205},
{"f_2269:srfi_4_scm",(void*)f_2269},
{"f_2264:srfi_4_scm",(void*)f_2264},
{"f_2259:srfi_4_scm",(void*)f_2259},
{"f_2207:srfi_4_scm",(void*)f_2207},
{"f_2258:srfi_4_scm",(void*)f_2258},
{"f_2217:srfi_4_scm",(void*)f_2217},
{"f_2248:srfi_4_scm",(void*)f_2248},
{"f_2229:srfi_4_scm",(void*)f_2229},
{"f_2234:srfi_4_scm",(void*)f_2234},
{"f_2088:srfi_4_scm",(void*)f_2088},
{"f_2145:srfi_4_scm",(void*)f_2145},
{"f_2140:srfi_4_scm",(void*)f_2140},
{"f_2135:srfi_4_scm",(void*)f_2135},
{"f_2090:srfi_4_scm",(void*)f_2090},
{"f_2134:srfi_4_scm",(void*)f_2134},
{"f_2100:srfi_4_scm",(void*)f_2100},
{"f_2114:srfi_4_scm",(void*)f_2114},
{"f_1971:srfi_4_scm",(void*)f_1971},
{"f_2028:srfi_4_scm",(void*)f_2028},
{"f_2023:srfi_4_scm",(void*)f_2023},
{"f_2018:srfi_4_scm",(void*)f_2018},
{"f_1973:srfi_4_scm",(void*)f_1973},
{"f_2017:srfi_4_scm",(void*)f_2017},
{"f_1983:srfi_4_scm",(void*)f_1983},
{"f_1997:srfi_4_scm",(void*)f_1997},
{"f_1854:srfi_4_scm",(void*)f_1854},
{"f_1911:srfi_4_scm",(void*)f_1911},
{"f_1906:srfi_4_scm",(void*)f_1906},
{"f_1901:srfi_4_scm",(void*)f_1901},
{"f_1856:srfi_4_scm",(void*)f_1856},
{"f_1900:srfi_4_scm",(void*)f_1900},
{"f_1866:srfi_4_scm",(void*)f_1866},
{"f_1875:srfi_4_scm",(void*)f_1875},
{"f_1880:srfi_4_scm",(void*)f_1880},
{"f_1737:srfi_4_scm",(void*)f_1737},
{"f_1794:srfi_4_scm",(void*)f_1794},
{"f_1789:srfi_4_scm",(void*)f_1789},
{"f_1784:srfi_4_scm",(void*)f_1784},
{"f_1739:srfi_4_scm",(void*)f_1739},
{"f_1783:srfi_4_scm",(void*)f_1783},
{"f_1749:srfi_4_scm",(void*)f_1749},
{"f_1758:srfi_4_scm",(void*)f_1758},
{"f_1763:srfi_4_scm",(void*)f_1763},
{"f_1620:srfi_4_scm",(void*)f_1620},
{"f_1677:srfi_4_scm",(void*)f_1677},
{"f_1672:srfi_4_scm",(void*)f_1672},
{"f_1667:srfi_4_scm",(void*)f_1667},
{"f_1622:srfi_4_scm",(void*)f_1622},
{"f_1666:srfi_4_scm",(void*)f_1666},
{"f_1632:srfi_4_scm",(void*)f_1632},
{"f_1641:srfi_4_scm",(void*)f_1641},
{"f_1646:srfi_4_scm",(void*)f_1646},
{"f_1503:srfi_4_scm",(void*)f_1503},
{"f_1560:srfi_4_scm",(void*)f_1560},
{"f_1555:srfi_4_scm",(void*)f_1555},
{"f_1550:srfi_4_scm",(void*)f_1550},
{"f_1505:srfi_4_scm",(void*)f_1505},
{"f_1549:srfi_4_scm",(void*)f_1549},
{"f_1515:srfi_4_scm",(void*)f_1515},
{"f_1524:srfi_4_scm",(void*)f_1524},
{"f_1529:srfi_4_scm",(void*)f_1529},
{"f_1478:srfi_4_scm",(void*)f_1478},
{"f_1485:srfi_4_scm",(void*)f_1485},
{"f_1460:srfi_4_scm",(void*)f_1460},
{"f_1476:srfi_4_scm",(void*)f_1476},
{"f_1458:srfi_4_scm",(void*)f_1458},
{"f_1308:srfi_4_scm",(void*)f_1308},
{"f_1312:srfi_4_scm",(void*)f_1312},
{"f_1315:srfi_4_scm",(void*)f_1315},
{"f_1318:srfi_4_scm",(void*)f_1318},
{"f_1335:srfi_4_scm",(void*)f_1335},
{"f_1339:srfi_4_scm",(void*)f_1339},
{"f_1342:srfi_4_scm",(void*)f_1342},
{"f_1345:srfi_4_scm",(void*)f_1345},
{"f_1369:srfi_4_scm",(void*)f_1369},
{"f_1371:srfi_4_scm",(void*)f_1371},
{"f_1375:srfi_4_scm",(void*)f_1375},
{"f_1381:srfi_4_scm",(void*)f_1381},
{"f_1388:srfi_4_scm",(void*)f_1388},
{"f_1280:srfi_4_scm",(void*)f_1280},
{"f_1282:srfi_4_scm",(void*)f_1282},
{"f_1286:srfi_4_scm",(void*)f_1286},
{"f_1292:srfi_4_scm",(void*)f_1292},
{"f_1295:srfi_4_scm",(void*)f_1295},
{"f_1263:srfi_4_scm",(void*)f_1263},
{"f_1265:srfi_4_scm",(void*)f_1265},
{"f_1269:srfi_4_scm",(void*)f_1269},
{"f_1275:srfi_4_scm",(void*)f_1275},
{"f_1249:srfi_4_scm",(void*)f_1249},
{"f_1251:srfi_4_scm",(void*)f_1251},
{"f_1255:srfi_4_scm",(void*)f_1255},
{"f_1258:srfi_4_scm",(void*)f_1258},
{"f_1206:srfi_4_scm",(void*)f_1206},
{"f_1208:srfi_4_scm",(void*)f_1208},
{"f_1203:srfi_4_scm",(void*)f_1203},
{"f_1200:srfi_4_scm",(void*)f_1200},
{"f_1197:srfi_4_scm",(void*)f_1197},
{"f_1194:srfi_4_scm",(void*)f_1194},
{"f_1191:srfi_4_scm",(void*)f_1191},
{"f_1188:srfi_4_scm",(void*)f_1188},
{"f_1185:srfi_4_scm",(void*)f_1185},
{"f_1182:srfi_4_scm",(void*)f_1182},
{"f_1179:srfi_4_scm",(void*)f_1179},
{"f_1176:srfi_4_scm",(void*)f_1176},
{"f_1173:srfi_4_scm",(void*)f_1173},
{"f_1170:srfi_4_scm",(void*)f_1170},
{"f_1167:srfi_4_scm",(void*)f_1167},
{"f_1164:srfi_4_scm",(void*)f_1164},
{"f_1161:srfi_4_scm",(void*)f_1161},
{"f_1158:srfi_4_scm",(void*)f_1158},
{"f_1137:srfi_4_scm",(void*)f_1137},
{"f_1122:srfi_4_scm",(void*)f_1122},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
