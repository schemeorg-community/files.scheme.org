/* Generated from eval.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:17
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: eval.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file ueval.c
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME    "."
#endif

#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif

#ifndef C_BINARY_VERSION
# define C_BINARY_VERSION      0
#endif


#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[396];
static double C_possibly_force_alignment;


/* from ##sys#clear-trace-buffer in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static C_word C_fcall stub2513(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2513(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_clear_trace_buffer();
return C_r;}

C_noret_decl(C_eval_toplevel)
C_externexport void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10468)
static void C_ccall f_10468(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10468)
static void C_ccall f_10468r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10472)
static void C_fcall f_10472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10497)
static void C_ccall f_10497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10487)
static void C_ccall f_10487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10495)
static void C_ccall f_10495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10480)
static void C_ccall f_10480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10475)
static void C_ccall f_10475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6767)
static void C_ccall f_6767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6862)
static void C_ccall f_6862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6943)
static void C_ccall f_6943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10462)
static void C_ccall f_10462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10458)
static void C_ccall f_10458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10454)
static void C_ccall f_10454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10450)
static void C_ccall f_10450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_fcall f_7493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7498)
static void C_ccall f_7498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10422)
static void C_ccall f_10422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10401)
static void C_fcall f_10401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10408)
static void C_ccall f_10408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10365)
static void C_fcall f_10365(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10394)
static void C_ccall f_10394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10357)
static void C_ccall f_10357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10359)
static void C_ccall f_10359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7514)
static void C_ccall f_7514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10329)
static void C_ccall f_10329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10349)
static void C_ccall f_10349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10345)
static void C_ccall f_10345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10335)
static void C_ccall f_10335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7868)
static void C_ccall f_7868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8890)
static void C_ccall f_8890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10320)
static void C_ccall f_10320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9241)
static void C_ccall f_9241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9245)
static void C_ccall f_9245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10316)
static void C_ccall f_10316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9248)
static void C_ccall f_9248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9519)
static void C_ccall f_9519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10308)
static void C_ccall f_10308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9541)
static void C_ccall f_9541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9926)
static void C_ccall f_9926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10299)
static void C_ccall f_10299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10306)
static void C_ccall f_10306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10289)
static C_word C_fcall f_10289(C_word t0,C_word t1);
C_noret_decl(f_10274)
static void C_ccall f_10274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10278)
static void C_ccall f_10278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10283)
static void C_ccall f_10283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10287)
static void C_ccall f_10287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10252)
static void C_ccall f_10252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10256)
static void C_ccall f_10256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10261)
static void C_ccall f_10261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10265)
static void C_ccall f_10265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10272)
static void C_ccall f_10272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10226)
static void C_ccall f_10226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10232)
static void C_ccall f_10232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10236)
static void C_ccall f_10236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10250)
static void C_ccall f_10250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10239)
static void C_ccall f_10239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10246)
static void C_ccall f_10246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10210)
static void C_ccall f_10210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10216)
static void C_ccall f_10216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10224)
static void C_ccall f_10224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10173)
static void C_ccall f_10173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10177)
static void C_ccall f_10177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10182)
static void C_ccall f_10182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10186)
static void C_ccall f_10186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10208)
static void C_ccall f_10208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10204)
static void C_ccall f_10204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10200)
static void C_ccall f_10200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10189)
static void C_ccall f_10189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10196)
static void C_ccall f_10196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10147)
static void C_ccall f_10147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10153)
static void C_ccall f_10153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10157)
static void C_ccall f_10157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10171)
static void C_ccall f_10171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10160)
static void C_ccall f_10160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10167)
static void C_ccall f_10167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10134)
static C_word C_fcall f_10134(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_10108)
static void C_ccall f_10108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10112)
static void C_ccall f_10112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10117)
static void C_ccall f_10117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10121)
static void C_ccall f_10121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10132)
static void C_ccall f_10132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10128)
static void C_ccall f_10128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10092)
static void C_ccall f_10092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10098)
static void C_ccall f_10098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10106)
static void C_ccall f_10106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10080)
static void C_ccall f_10080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10086)
static void C_ccall f_10086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10090)
static void C_ccall f_10090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10071)
static void C_fcall f_10071(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10075)
static void C_ccall f_10075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10012)
static void C_fcall f_10012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10022)
static void C_ccall f_10022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10047)
static void C_ccall f_10047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10059)
static void C_ccall f_10059(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_10059)
static void C_ccall f_10059r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_10065)
static void C_ccall f_10065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10053)
static void C_ccall f_10053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10028)
static void C_ccall f_10028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10034)
static void C_ccall f_10034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10038)
static void C_ccall f_10038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10041)
static void C_ccall f_10041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10045)
static void C_ccall f_10045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10017)
static void C_ccall f_10017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9937)
static void C_ccall f_9937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9947)
static void C_ccall f_9947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9950)
static void C_ccall f_9950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9964)
static void C_fcall f_9964(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9982)
static void C_ccall f_9982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9951)
static void C_fcall f_9951(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9928)
static void C_ccall f_9928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9562)
static void C_ccall f_9562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9606)
static void C_ccall f_9606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9609)
static void C_ccall f_9609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9911)
static void C_ccall f_9911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9915)
static void C_ccall f_9915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9919)
static void C_ccall f_9919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9691)
static void C_ccall f_9691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9697)
static void C_fcall f_9697(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9894)
static void C_ccall f_9894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9900)
static void C_ccall f_9900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9704)
static void C_ccall f_9704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9707)
static void C_ccall f_9707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9892)
static void C_ccall f_9892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9722)
static void C_ccall f_9722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9725)
static void C_ccall f_9725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9740)
static void C_ccall f_9740(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9740)
static void C_ccall f_9740r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9758)
static void C_fcall f_9758(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9846)
static void C_ccall f_9846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9774)
static void C_ccall f_9774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9782)
static void C_fcall f_9782(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9794)
static void C_ccall f_9794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9797)
static void C_ccall f_9797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9809)
static void C_ccall f_9809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9812)
static void C_ccall f_9812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9800)
static void C_ccall f_9800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9826)
static void C_ccall f_9826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9777)
static void C_ccall f_9777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9762)
static void C_ccall f_9762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9744)
static void C_ccall f_9744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9587)
static void C_fcall f_9587(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9592)
static void C_ccall f_9592(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9747)
static void C_ccall f_9747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9731)
static void C_ccall f_9731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9626)
static void C_ccall f_9626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9631)
static void C_ccall f_9631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9634)
static void C_ccall f_9634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9639)
static void C_ccall f_9639(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9639)
static void C_ccall f_9639r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9646)
static void C_ccall f_9646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9686)
static void C_ccall f_9686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9649)
static void C_ccall f_9649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9661)
static void C_fcall f_9661(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9670)
static void C_ccall f_9670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9664)
static void C_ccall f_9664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9652)
static void C_ccall f_9652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9655)
static void C_ccall f_9655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9617)
static C_word C_fcall f_9617(C_word t0);
C_noret_decl(f_9611)
static C_word C_fcall f_9611(C_word t0);
C_noret_decl(f_9565)
static void C_fcall f_9565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9571)
static void C_ccall f_9571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9559)
static void C_ccall f_9559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9543)
static void C_ccall f_9543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9554)
static void C_ccall f_9554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9557)
static void C_ccall f_9557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9547)
static void C_ccall f_9547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9524)
static void C_ccall f_9524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9533)
static void C_ccall f_9533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9528)
static void C_ccall f_9528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9464)
static void C_ccall f_9464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9468)
static void C_ccall f_9468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9471)
static void C_ccall f_9471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9474)
static void C_ccall f_9474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9477)
static void C_ccall f_9477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9480)
static void C_ccall f_9480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9483)
static void C_ccall f_9483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9486)
static void C_ccall f_9486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9489)
static void C_ccall f_9489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9492)
static void C_ccall f_9492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9443)
static void C_fcall f_9443(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9447)
static void C_ccall f_9447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9450)
static void C_ccall f_9450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9419)
static void C_fcall f_9419(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9425)
static void C_fcall f_9425(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9435)
static void C_ccall f_9435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9277)
static void C_ccall f_9277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9277)
static void C_ccall f_9277r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9348)
static void C_ccall f_9348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9395)
static void C_ccall f_9395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9405)
static void C_ccall f_9405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9358)
static void C_ccall f_9358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9360)
static void C_fcall f_9360(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9384)
static void C_ccall f_9384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9370)
static void C_ccall f_9370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9318)
static void C_fcall f_9318(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9283)
static void C_fcall f_9283(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9299)
static void C_ccall f_9299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9305)
static void C_ccall f_9305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9296)
static void C_ccall f_9296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9258)
static void C_fcall f_9258(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9262)
static void C_ccall f_9262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9225)
static void C_fcall f_9225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9227)
static void C_ccall f_9227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9231)
static void C_ccall f_9231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9187)
static void C_ccall f_9187(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9187)
static void C_ccall f_9187r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9194)
static void C_ccall f_9194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9201)
static void C_ccall f_9201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9143)
static void C_ccall f_9143(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9143)
static void C_ccall f_9143r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9021)
static void C_ccall f_9021(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9021)
static void C_ccall f_9021r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9115)
static void C_ccall f_9115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9125)
static void C_ccall f_9125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9113)
static void C_ccall f_9113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9042)
static void C_fcall f_9042(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9066)
static void C_fcall f_9066(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9085)
static void C_ccall f_9085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9060)
static void C_ccall f_9060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8913)
static void C_ccall f_8913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_8913)
static void C_ccall f_8913r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_8923)
static void C_ccall f_8923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8928)
static void C_fcall f_8928(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8955)
static void C_fcall f_8955(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8984)
static void C_fcall f_8984(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8988)
static void C_ccall f_8988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8949)
static void C_ccall f_8949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8897)
static void C_ccall f_8897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8834)
static void C_ccall f_8834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8838)
static void C_ccall f_8838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8846)
static C_word C_fcall f_8846(C_word t0,C_word t1);
C_noret_decl(f_8226)
static void C_ccall f_8226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8650)
static void C_fcall f_8650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8759)
static void C_fcall f_8759(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8768)
static void C_fcall f_8768(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8775)
static void C_fcall f_8775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8766)
static void C_ccall f_8766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_fcall f_8679(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8746)
static void C_ccall f_8746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8706)
static void C_fcall f_8706(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8710)
static void C_ccall f_8710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8737)
static void C_ccall f_8737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8733)
static void C_ccall f_8733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8713)
static void C_ccall f_8713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8718)
static void C_ccall f_8718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8673)
static void C_ccall f_8673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8669)
static void C_ccall f_8669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8295)
static void C_fcall f_8295(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8305)
static void C_ccall f_8305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8467)
static void C_ccall f_8467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8612)
static void C_ccall f_8612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8619)
static void C_ccall f_8619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8482)
static void C_ccall f_8482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8501)
static void C_fcall f_8501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8533)
static void C_fcall f_8533(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8527)
static void C_ccall f_8527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8523)
static void C_ccall f_8523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8505)
static void C_ccall f_8505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8497)
static void C_ccall f_8497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8489)
static void C_ccall f_8489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8372)
static void C_ccall f_8372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8393)
static void C_fcall f_8393(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8401)
static void C_ccall f_8401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8389)
static void C_ccall f_8389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8325)
static void C_ccall f_8325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8312)
static void C_ccall f_8312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_fcall f_8254(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8273)
static void C_ccall f_8273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8266)
static void C_ccall f_8266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8229)
static void C_fcall f_8229(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8248)
static void C_ccall f_8248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8242)
static void C_ccall f_8242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8177)
static void C_ccall f_8177(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8183)
static void C_fcall f_8183(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8197)
static void C_ccall f_8197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8200)
static void C_fcall f_8200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8207)
static void C_ccall f_8207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8171)
static void C_ccall f_8171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8138)
static void C_ccall f_8138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8148)
static void C_ccall f_8148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8151)
static void C_ccall f_8151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8158)
static void C_fcall f_8158(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8125)
static void C_ccall f_8125(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8125)
static void C_ccall f_8125r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8131)
static void C_ccall f_8131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8111)
static void C_ccall f_8111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8122)
static void C_ccall f_8122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8069)
static void C_ccall f_8069(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8069)
static void C_ccall f_8069r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8075)
static void C_fcall f_8075(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8090)
static void C_ccall f_8090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7992)
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7992)
static void C_ccall f_7992r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8052)
static void C_ccall f_8052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7999)
static void C_fcall f_7999(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8029)
static void C_ccall f_8029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8035)
static void C_ccall f_8035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8017)
static void C_ccall f_8017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7897)
static void C_ccall f_7897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7945)
static void C_ccall f_7945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7947)
static void C_fcall f_7947(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7960)
static void C_ccall f_7960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_fcall f_7899(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7919)
static void C_ccall f_7919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7869)
static void C_ccall f_7869r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7708)
static void C_ccall f_7708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7813)
static void C_fcall f_7813(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7830)
static void C_ccall f_7830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7730)
static void C_ccall f_7730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_fcall f_7735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7774)
static void C_ccall f_7774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7761)
static void C_ccall f_7761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7711)
static void C_fcall f_7711(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7622)
static void C_ccall f_7622(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7622)
static void C_ccall f_7622r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7629)
static void C_ccall f_7629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7639)
static void C_ccall f_7639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7516)
static void C_ccall f_7516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7520)
static void C_ccall f_7520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7612)
static void C_ccall f_7612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7616)
static void C_ccall f_7616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7529)
static void C_fcall f_7529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7598)
static void C_ccall f_7598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7594)
static void C_ccall f_7594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7532)
static void C_ccall f_7532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7581)
static void C_ccall f_7581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7584)
static void C_ccall f_7584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7535)
static void C_ccall f_7535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7540)
static void C_fcall f_7540(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7574)
static void C_ccall f_7574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7553)
static void C_ccall f_7553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7507)
static void C_fcall f_7507(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7488)
static void C_ccall f_7488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7471)
static void C_ccall f_7471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7482)
static void C_ccall f_7482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7439)
static void C_ccall f_7439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7409)
static void C_ccall f_7409(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7409)
static void C_ccall f_7409r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7364)
static void C_fcall f_7364(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7359)
static void C_fcall f_7359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6993)
static void C_fcall f_6993(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7358)
static void C_ccall f_7358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6997)
static void C_fcall f_6997(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7280)
static void C_ccall f_7280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7295)
static void C_ccall f_7295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7298)
static void C_fcall f_7298(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7301)
static void C_ccall f_7301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7310)
static void C_ccall f_7310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7316)
static void C_ccall f_7316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7000)
static void C_ccall f_7000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7271)
static void C_ccall f_7271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7259)
static void C_ccall f_7259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7262)
static void C_ccall f_7262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7265)
static void C_ccall f_7265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7006)
static void C_ccall f_7006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7244)
static void C_ccall f_7244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7216)
static void C_ccall f_7216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7240)
static void C_ccall f_7240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7232)
static void C_ccall f_7232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7009)
static void C_ccall f_7009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7203)
static void C_ccall f_7203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7191)
static void C_ccall f_7191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7042)
static void C_ccall f_7042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7054)
static void C_ccall f_7054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7176)
static void C_ccall f_7176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7064)
static void C_ccall f_7064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7069)
static void C_fcall f_7069(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7079)
static void C_ccall f_7079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7134)
static void C_fcall f_7134(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7142)
static void C_fcall f_7142(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7098)
static void C_ccall f_7098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7113)
static void C_ccall f_7113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7103)
static void C_ccall f_7103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7082)
static void C_ccall f_7082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7012)
static void C_ccall f_7012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6945)
static void C_fcall f_6945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static C_word C_fcall f_6955(C_word t0,C_word t1);
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6882)
static void C_fcall f_6882(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6877)
static void C_ccall f_6877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6864)
static void C_ccall f_6864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6780)
static void C_ccall f_6780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6793)
static void C_fcall f_6793(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6826)
static void C_ccall f_6826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6807)
static void C_ccall f_6807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6783)
static void C_fcall f_6783(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6770)
static void C_ccall f_6770r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6778)
static void C_ccall f_6778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6451)
static void C_fcall f_6451(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6702)
static void C_fcall f_6702(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6736)
static void C_ccall f_6736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6729)
static void C_fcall f_6729(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6644)
static void C_ccall f_6644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6645)
static void C_ccall f_6645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6649)
static void C_fcall f_6649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6656)
static void C_ccall f_6656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6662)
static void C_fcall f_6662(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6696)
static void C_ccall f_6696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6689)
static void C_fcall f_6689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6610)
static void C_ccall f_6610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6611)
static void C_ccall f_6611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6615)
static void C_fcall f_6615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6629)
static void C_ccall f_6629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6562)
static void C_ccall f_6562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6566)
static void C_ccall f_6566(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6570)
static void C_fcall f_6570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6580)
static void C_ccall f_6580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6588)
static void C_ccall f_6588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6528)
static void C_ccall f_6528(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6532)
static void C_fcall f_6532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6542)
static void C_ccall f_6542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6546)
static void C_ccall f_6546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6496)
static void C_ccall f_6496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6501)
static void C_fcall f_6501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6504)
static void C_ccall f_6504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f11720)
static void C_ccall f11720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f11716)
static void C_ccall f11716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6425)
static C_word C_fcall f_6425(C_word t0,C_word t1);
C_noret_decl(f_3571)
static void C_fcall f_3571(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_fcall f_3754(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static void C_fcall f_3774(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_fcall f_6225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6159)
static void C_fcall f_6159(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6167)
static void C_fcall f_6167(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6144)
static void C_ccall f_6144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6043)
static void C_ccall f_6043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6045)
static void C_fcall f_6045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6067)
static void C_ccall f_6067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6083)
static void C_ccall f_6083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6057)
static void C_ccall f_6057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6039)
static void C_ccall f_6039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5985)
static void C_fcall f_5985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6019)
static void C_ccall f_6019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6012)
static void C_fcall f_6012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5908)
static void C_ccall f_5908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5911)
static void C_ccall f_5911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5937)
static void C_fcall f_5937(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5751)
static void C_fcall f_5751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5829)
static void C_ccall f_5829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5778)
static void C_fcall f_5778(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5802)
static C_word C_fcall f_5802(C_word t0);
C_noret_decl(f_5791)
static void C_fcall f_5791(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5655)
static void C_fcall f_5655(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5675)
static void C_fcall f_5675(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5629)
static void C_ccall f_5629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5558)
static void C_ccall f_5558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5476)
static void C_fcall f_5476(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_fcall f_5503(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_fcall f_5440(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5448)
static C_word C_fcall f_5448(C_word t0,C_word t1);
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_fcall f_5355(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_fcall f_5382(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5304)
static void C_ccall f_5304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5268)
static void C_fcall f_5268(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5219)
static void C_fcall f_5219(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5232)
static void C_fcall f_5232(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5217)
static void C_ccall f_5217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6379)
static void C_fcall f_6379(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6408)
static void C_ccall f_6408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5113)
static void C_ccall f_5113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5113)
static void C_ccall f_5113r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5085)
static void C_ccall f_5085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_fcall f_4829(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_fcall f_4773(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4771)
static void C_ccall f_4771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_fcall f_4676(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_fcall f_4641(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_fcall f_4592(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4605)
static void C_fcall f_4605(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_fcall f_4532(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_fcall f_4559(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_fcall f_4502(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3801)
static void C_ccall f_3801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3827)
static void C_ccall f_3827(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3819)
static void C_ccall f_3819(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_fcall f_3641(C_word t0,C_word t1) C_noret;
C_noret_decl(f10596)
static void C_ccall f10596(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f10591)
static void C_ccall f10591(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3520)
static void C_fcall f_3520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3529)
static void C_ccall f_3529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_fcall f_3413(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_fcall f_3425(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3442)
static void C_fcall f_3442(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3472)
static C_word C_fcall f_3472(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3398)
static void C_fcall f_3398(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3372)
static void C_fcall f_3372(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3309)
static void C_ccall f_3309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_fcall f_3261(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3187)
static void C_fcall f_3187(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3210)
static void C_fcall f_3210(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3113)
static void C_fcall f_3113(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static C_word C_fcall f_3056(C_word t0,C_word t1);
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992r(C_word t0,C_word t1,C_word t3) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_10289,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))),*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_10274,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_10252,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_10226,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_10210,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_10173,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_10147,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_10108,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_10092,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x,s=0,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
return C_truep(C_callback_wrapper((void *)f_10080,0));}

C_noret_decl(trf_10472)
static void C_fcall trf_10472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10472(t0,t1);}

C_noret_decl(trf_7493)
static void C_fcall trf_7493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7493(t0,t1);}

C_noret_decl(trf_10401)
static void C_fcall trf_10401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10401(t0,t1);}

C_noret_decl(trf_10365)
static void C_fcall trf_10365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10365(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10365(t0,t1,t2);}

C_noret_decl(trf_10071)
static void C_fcall trf_10071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10071(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10071(t0,t1,t2);}

C_noret_decl(trf_10012)
static void C_fcall trf_10012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10012(t0,t1);}

C_noret_decl(trf_9964)
static void C_fcall trf_9964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9964(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9964(t0,t1);}

C_noret_decl(trf_9951)
static void C_fcall trf_9951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9951(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9951(t0,t1);}

C_noret_decl(trf_9697)
static void C_fcall trf_9697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9697(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9697(t0,t1);}

C_noret_decl(trf_9758)
static void C_fcall trf_9758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9758(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9758(t0,t1,t2,t3);}

C_noret_decl(trf_9782)
static void C_fcall trf_9782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9782(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9782(t0,t1,t2);}

C_noret_decl(trf_9587)
static void C_fcall trf_9587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9587(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9587(t0,t1);}

C_noret_decl(trf_9661)
static void C_fcall trf_9661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9661(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9661(t0,t1);}

C_noret_decl(trf_9565)
static void C_fcall trf_9565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9565(t0,t1);}

C_noret_decl(trf_9443)
static void C_fcall trf_9443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9443(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9443(t0,t1,t2,t3);}

C_noret_decl(trf_9419)
static void C_fcall trf_9419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9419(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9419(t0,t1,t2);}

C_noret_decl(trf_9425)
static void C_fcall trf_9425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9425(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9425(t0,t1,t2);}

C_noret_decl(trf_9360)
static void C_fcall trf_9360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9360(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9360(t0,t1,t2);}

C_noret_decl(trf_9318)
static void C_fcall trf_9318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9318(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9318(t0,t1,t2);}

C_noret_decl(trf_9283)
static void C_fcall trf_9283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9283(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9283(t0,t1,t2,t3);}

C_noret_decl(trf_9258)
static void C_fcall trf_9258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9258(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9258(t0,t1);}

C_noret_decl(trf_9225)
static void C_fcall trf_9225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9225(t0,t1);}

C_noret_decl(trf_9042)
static void C_fcall trf_9042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9042(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9042(t0,t1,t2,t3);}

C_noret_decl(trf_9066)
static void C_fcall trf_9066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9066(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9066(t0,t1,t2,t3);}

C_noret_decl(trf_8928)
static void C_fcall trf_8928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8928(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8928(t0,t1,t2);}

C_noret_decl(trf_8955)
static void C_fcall trf_8955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8955(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8955(t0,t1,t2);}

C_noret_decl(trf_8984)
static void C_fcall trf_8984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8984(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8984(t0,t1);}

C_noret_decl(trf_8650)
static void C_fcall trf_8650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8650(t0,t1);}

C_noret_decl(trf_8759)
static void C_fcall trf_8759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8759(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8759(t0,t1);}

C_noret_decl(trf_8768)
static void C_fcall trf_8768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8768(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8768(t0,t1,t2);}

C_noret_decl(trf_8775)
static void C_fcall trf_8775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8775(t0,t1);}

C_noret_decl(trf_8679)
static void C_fcall trf_8679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8679(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8679(t0,t1,t2);}

C_noret_decl(trf_8706)
static void C_fcall trf_8706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8706(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8706(t0,t1,t2);}

C_noret_decl(trf_8295)
static void C_fcall trf_8295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8295(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8295(t0,t1,t2,t3);}

C_noret_decl(trf_8501)
static void C_fcall trf_8501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8501(t0,t1);}

C_noret_decl(trf_8533)
static void C_fcall trf_8533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8533(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8533(t0,t1,t2);}

C_noret_decl(trf_8393)
static void C_fcall trf_8393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8393(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8393(t0,t1);}

C_noret_decl(trf_8254)
static void C_fcall trf_8254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8254(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8254(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8229)
static void C_fcall trf_8229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8229(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8229(t0,t1,t2,t3);}

C_noret_decl(trf_8183)
static void C_fcall trf_8183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8183(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8183(t0,t1,t2);}

C_noret_decl(trf_8200)
static void C_fcall trf_8200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8200(t0,t1);}

C_noret_decl(trf_8158)
static void C_fcall trf_8158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8158(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8158(t0,t1,t2);}

C_noret_decl(trf_8075)
static void C_fcall trf_8075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8075(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8075(t0,t1,t2);}

C_noret_decl(trf_7999)
static void C_fcall trf_7999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7999(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7999(t0,t1);}

C_noret_decl(trf_7947)
static void C_fcall trf_7947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7947(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7947(t0,t1,t2);}

C_noret_decl(trf_7899)
static void C_fcall trf_7899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7899(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7899(t0,t1,t2);}

C_noret_decl(trf_7813)
static void C_fcall trf_7813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7813(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7813(t0,t1,t2);}

C_noret_decl(trf_7735)
static void C_fcall trf_7735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7735(t0,t1,t2);}

C_noret_decl(trf_7711)
static void C_fcall trf_7711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7711(t0,t1);}

C_noret_decl(trf_7529)
static void C_fcall trf_7529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7529(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7529(t0,t1);}

C_noret_decl(trf_7540)
static void C_fcall trf_7540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7540(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7540(t0,t1,t2);}

C_noret_decl(trf_7507)
static void C_fcall trf_7507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7507(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7507(t0,t1,t2);}

C_noret_decl(trf_7364)
static void C_fcall trf_7364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7364(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7364(t0,t1);}

C_noret_decl(trf_7359)
static void C_fcall trf_7359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7359(t0,t1,t2);}

C_noret_decl(trf_6993)
static void C_fcall trf_6993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6993(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6993(t0,t1,t2,t3);}

C_noret_decl(trf_6997)
static void C_fcall trf_6997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6997(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6997(t0,t1);}

C_noret_decl(trf_7298)
static void C_fcall trf_7298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7298(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7298(t0,t1);}

C_noret_decl(trf_7069)
static void C_fcall trf_7069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7069(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7069(t0,t1,t2);}

C_noret_decl(trf_7134)
static void C_fcall trf_7134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7134(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7134(t0,t1,t2);}

C_noret_decl(trf_7142)
static void C_fcall trf_7142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7142(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7142(t0,t1,t2);}

C_noret_decl(trf_6945)
static void C_fcall trf_6945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6945(t0,t1);}

C_noret_decl(trf_6882)
static void C_fcall trf_6882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6882(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6882(t0,t1,t2);}

C_noret_decl(trf_6793)
static void C_fcall trf_6793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6793(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6793(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6783)
static void C_fcall trf_6783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6783(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6783(t0,t1);}

C_noret_decl(trf_6451)
static void C_fcall trf_6451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6451(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6451(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6702)
static void C_fcall trf_6702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6702(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6702(t0,t1,t2);}

C_noret_decl(trf_6729)
static void C_fcall trf_6729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6729(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6729(t0,t1,t2);}

C_noret_decl(trf_6649)
static void C_fcall trf_6649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6649(t0,t1);}

C_noret_decl(trf_6662)
static void C_fcall trf_6662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6662(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6662(t0,t1,t2);}

C_noret_decl(trf_6689)
static void C_fcall trf_6689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6689(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6689(t0,t1,t2);}

C_noret_decl(trf_6615)
static void C_fcall trf_6615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6615(t0,t1);}

C_noret_decl(trf_6570)
static void C_fcall trf_6570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6570(t0,t1);}

C_noret_decl(trf_6532)
static void C_fcall trf_6532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6532(t0,t1);}

C_noret_decl(trf_6501)
static void C_fcall trf_6501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6501(t0,t1);}

C_noret_decl(trf_3571)
static void C_fcall trf_3571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3571(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3571(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_3754)
static void C_fcall trf_3754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3754(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3754(t0,t1);}

C_noret_decl(trf_3774)
static void C_fcall trf_3774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3774(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3774(t0,t1);}

C_noret_decl(trf_6225)
static void C_fcall trf_6225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6225(t0,t1);}

C_noret_decl(trf_6159)
static void C_fcall trf_6159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6159(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6159(t0,t1,t2);}

C_noret_decl(trf_6167)
static void C_fcall trf_6167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6167(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6167(t0,t1,t2);}

C_noret_decl(trf_6045)
static void C_fcall trf_6045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6045(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6045(t0,t1,t2);}

C_noret_decl(trf_5985)
static void C_fcall trf_5985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5985(t0,t1,t2);}

C_noret_decl(trf_6012)
static void C_fcall trf_6012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6012(t0,t1,t2);}

C_noret_decl(trf_5937)
static void C_fcall trf_5937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5937(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5937(t0,t1,t2);}

C_noret_decl(trf_5751)
static void C_fcall trf_5751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5751(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5751(t0,t1,t2);}

C_noret_decl(trf_5778)
static void C_fcall trf_5778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5778(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5778(t0,t1,t2);}

C_noret_decl(trf_5791)
static void C_fcall trf_5791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5791(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5791(t0,t1);}

C_noret_decl(trf_5655)
static void C_fcall trf_5655(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5655(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5655(t0,t1,t2,t3);}

C_noret_decl(trf_5675)
static void C_fcall trf_5675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5675(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5675(t0,t1,t2);}

C_noret_decl(trf_5476)
static void C_fcall trf_5476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5476(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5476(t0,t1,t2);}

C_noret_decl(trf_5503)
static void C_fcall trf_5503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5503(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5503(t0,t1,t2);}

C_noret_decl(trf_5440)
static void C_fcall trf_5440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5440(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5440(t0,t1,t2);}

C_noret_decl(trf_5355)
static void C_fcall trf_5355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5355(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5355(t0,t1,t2);}

C_noret_decl(trf_5382)
static void C_fcall trf_5382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5382(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5382(t0,t1,t2);}

C_noret_decl(trf_5268)
static void C_fcall trf_5268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5268(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5268(t0,t1,t2);}

C_noret_decl(trf_5219)
static void C_fcall trf_5219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5219(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5219(t0,t1,t2,t3);}

C_noret_decl(trf_5232)
static void C_fcall trf_5232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5232(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5232(t0,t1);}

C_noret_decl(trf_6379)
static void C_fcall trf_6379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6379(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6379(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4829)
static void C_fcall trf_4829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4829(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4829(t0,t1,t2);}

C_noret_decl(trf_4773)
static void C_fcall trf_4773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4773(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4773(t0,t1,t2);}

C_noret_decl(trf_4676)
static void C_fcall trf_4676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4676(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4676(t0,t1,t2);}

C_noret_decl(trf_4641)
static void C_fcall trf_4641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4641(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4641(t0,t1,t2);}

C_noret_decl(trf_4592)
static void C_fcall trf_4592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4592(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4592(t0,t1,t2,t3);}

C_noret_decl(trf_4605)
static void C_fcall trf_4605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4605(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4605(t0,t1);}

C_noret_decl(trf_4532)
static void C_fcall trf_4532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4532(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4532(t0,t1,t2);}

C_noret_decl(trf_4559)
static void C_fcall trf_4559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4559(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4559(t0,t1,t2);}

C_noret_decl(trf_4502)
static void C_fcall trf_4502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4502(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4502(t0,t1,t2,t3);}

C_noret_decl(trf_3641)
static void C_fcall trf_3641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3641(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3641(t0,t1);}

C_noret_decl(trf_3520)
static void C_fcall trf_3520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3520(t0,t1);}

C_noret_decl(trf_3413)
static void C_fcall trf_3413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3413(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3413(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3425)
static void C_fcall trf_3425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3425(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3425(t0,t1,t2,t3);}

C_noret_decl(trf_3442)
static void C_fcall trf_3442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3442(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3442(t0,t1,t2);}

C_noret_decl(trf_3398)
static void C_fcall trf_3398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3398(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3398(t0,t1,t2,t3);}

C_noret_decl(trf_3359)
static void C_fcall trf_3359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3359(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3359(t0,t1,t2,t3);}

C_noret_decl(trf_3372)
static void C_fcall trf_3372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3372(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3372(t0,t1);}

C_noret_decl(trf_3261)
static void C_fcall trf_3261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3261(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3261(t0,t1,t2);}

C_noret_decl(trf_3187)
static void C_fcall trf_3187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3187(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3187(t0,t1,t2);}

C_noret_decl(trf_3210)
static void C_fcall trf_3210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3210(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3210(t0,t1,t2);}

C_noret_decl(trf_3218)
static void C_fcall trf_3218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3218(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3218(t0,t1,t2);}

C_noret_decl(trf_3113)
static void C_fcall trf_3113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3113(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3113(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(6424)){
C_save(t1);
C_rereclaim2(6424*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,396);
lf[0]=C_h_intern(&lf[0],24,"\003syscore-library-modules");
lf[1]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\007lolevel\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\005files\376\003\000\000\002\376\001\000\000\003tcp\376\003\000\000"
"\002\376\001\000\000\005regex\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\006srfi-4\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002"
"\376\001\000\000\007srfi-14\376\003\000\000\002\376\001\000\000\007srfi-18\376\003\000\000\002\376\001\000\000\007srfi-69\376\003\000\000\002\376\001\000\000\017data-structures\376\003\000\000\002\376\001\000\000"
"\005ports\376\003\000\000\002\376\001\000\000\016chicken-syntax\376\377\016");
lf[2]=C_h_intern(&lf[2],28,"\003sysexplicit-library-modules");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[7]=C_h_intern(&lf[7],18,"\003syschicken-prefix");
lf[8]=C_h_intern(&lf[8],17,"\003sysstring-append");
lf[9]=C_h_intern(&lf[9],12,"chicken-home");
lf[10]=C_h_intern(&lf[10],17,"\003syspeek-c-string");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\015share/chicken");
lf[12]=C_h_intern(&lf[12],15,"\003syshash-symbol");
lf[13]=C_h_intern(&lf[13],18,"\003syshash-table-ref");
lf[14]=C_h_intern(&lf[14],19,"\003syshash-table-set!");
lf[15]=C_h_intern(&lf[15],22,"\003syshash-table-update!");
lf[16]=C_h_intern(&lf[16],23,"\003syshash-table-for-each");
lf[17]=C_h_intern(&lf[17],28,"\003sysarbitrary-unbound-symbol");
lf[18]=C_h_intern(&lf[18],23,"\003syshash-table-location");
lf[19]=C_h_intern(&lf[19],20,"\003syseval-environment");
lf[20]=C_h_intern(&lf[20],26,"\003sysenvironment-is-mutable");
lf[21]=C_h_intern(&lf[21],18,"\003syseval-decorator");
lf[22]=C_h_intern(&lf[22],20,"\003sysmake-lambda-info");
lf[23]=C_h_intern(&lf[23],17,"get-output-string");
lf[24]=C_h_intern(&lf[24],5,"write");
lf[25]=C_h_intern(&lf[25],18,"open-output-string");
lf[26]=C_h_intern(&lf[26],19,"\003sysdecorate-lambda");
lf[27]=C_h_intern(&lf[27],19,"\003sysunbound-in-eval");
lf[28]=C_h_intern(&lf[28],20,"\003syseval-debug-level");
lf[29]=C_h_intern(&lf[29],7,"reverse");
lf[30]=C_h_intern(&lf[30],20,"with-input-from-file");
lf[31]=C_h_intern(&lf[31],7,"display");
lf[32]=C_h_intern(&lf[32],22,"\003syscompile-to-closure");
lf[33]=C_h_intern(&lf[33],7,"\003sysget");
lf[34]=C_h_intern(&lf[34],16,"\004coremacro-alias");
lf[35]=C_h_intern(&lf[35],19,"\003sysundefined-value");
lf[36]=C_h_intern(&lf[36],18,"\003syscurrent-module");
lf[37]=C_h_intern(&lf[37],21,"\003sysmacro-environment");
lf[38]=C_h_intern(&lf[38],28,"\003syscurrent-meta-environment");
lf[39]=C_h_intern(&lf[39],16,"\003sysdynamic-wind");
lf[40]=C_h_intern(&lf[40],26,"\003sysmeta-macro-environment");
lf[41]=C_h_intern(&lf[41],9,"\003syserror");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\020unbound variable");
lf[43]=C_h_intern(&lf[43],21,"\003syssyntax-error-hook");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000!reference to undefined identifier");
lf[45]=C_h_intern(&lf[45],32,"\003syssymbol-has-toplevel-binding\077");
lf[46]=C_h_intern(&lf[46],14,"\004coreprimitive");
lf[47]=C_h_intern(&lf[47],21,"\003sysalias-global-hook");
lf[48]=C_h_intern(&lf[48],5,"quote");
lf[49]=C_h_intern(&lf[49],16,"\003sysstrip-syntax");
lf[50]=C_h_intern(&lf[50],16,"\003syscheck-syntax");
lf[51]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[52]=C_h_intern(&lf[52],6,"syntax");
lf[53]=C_h_intern(&lf[53],11,"\004coresyntax");
lf[54]=C_h_intern(&lf[54],15,"\004coreglobal-ref");
lf[55]=C_h_intern(&lf[55],10,"\004corecheck");
lf[56]=C_h_intern(&lf[56],14,"\004coreimmutable");
lf[57]=C_h_intern(&lf[57],14,"\004coreundefined");
lf[58]=C_h_intern(&lf[58],2,"if");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[61]=C_h_intern(&lf[61],5,"begin");
lf[62]=C_h_intern(&lf[62],10,"\004corebegin");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[64]=C_h_intern(&lf[64],10,"\003sysappend");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[66]=C_h_intern(&lf[66],4,"set!");
lf[67]=C_h_intern(&lf[67],9,"\004coreset!");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000 assignment to immutable variable");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\042assignment of undefined identifier");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[71]=C_h_intern(&lf[71],3,"let");
lf[72]=C_h_intern(&lf[72],8,"\004corelet");
lf[73]=C_h_intern(&lf[73],15,"\003sysmake-vector");
lf[74]=C_h_intern(&lf[74],21,"\003syscanonicalize-body");
lf[75]=C_h_intern(&lf[75],6,"append");
lf[76]=C_h_intern(&lf[76],4,"cons");
lf[77]=C_h_intern(&lf[77],6,"gensym");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[79]=C_h_intern(&lf[79],6,"letrec");
lf[80]=C_h_intern(&lf[80],11,"\004coreletrec");
lf[81]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[83]=C_h_intern(&lf[83],6,"lambda");
lf[84]=C_h_intern(&lf[84],11,"\004corelambda");
lf[85]=C_h_intern(&lf[85],1,"\077");
lf[86]=C_h_intern(&lf[86],10,"\003sysvector");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[89]=C_h_intern(&lf[89],25,"\003sysdecompose-lambda-list");
lf[90]=C_h_intern(&lf[90],31,"\003sysexpand-extended-lambda-list");
lf[91]=C_h_intern(&lf[91],25,"\003sysextended-lambda-list\077");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[93]=C_h_intern(&lf[93],10,"let-syntax");
lf[94]=C_h_intern(&lf[94],18,"\003syser-transformer");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012let-syntax\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_"
"\376\377\001\000\000\000\001");
lf[96]=C_h_intern(&lf[96],13,"letrec-syntax");
lf[97]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015letrec-syntax\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000"
"\000\001_\376\377\001\000\000\000\001");
lf[98]=C_h_intern(&lf[98],18,"\004coredefine-syntax");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[100]=C_h_intern(&lf[100],28,"\003sysextend-macro-environment");
lf[101]=C_h_intern(&lf[101],23,"\003syscurrent-environment");
lf[102]=C_h_intern(&lf[102],26,"\003sysregister-syntax-export");
lf[103]=C_h_intern(&lf[103],27,"\004coredefine-compiler-syntax");
lf[104]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[105]=C_h_intern(&lf[105],24,"\004corelet-compiler-syntax");
lf[106]=C_h_intern(&lf[106],11,"\004coremodule");
lf[107]=C_h_intern(&lf[107],29,"\003sysinitial-macro-environment");
lf[108]=C_h_intern(&lf[108],19,"\003sysfinalize-module");
lf[109]=C_h_intern(&lf[109],19,"\003sysregister-module");
lf[110]=C_h_intern(&lf[110],6,"module");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\031modules may not be nested");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[113]=C_h_intern(&lf[113],16,"\004coreloop-lambda");
lf[114]=C_h_intern(&lf[114],17,"\004corenamed-lambda");
lf[115]=C_h_intern(&lf[115],23,"\004corerequire-for-syntax");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[117]=C_h_intern(&lf[117],11,"\003sysrequire");
lf[118]=C_h_intern(&lf[118],31,"\003syslookup-runtime-requirements");
lf[119]=C_h_intern(&lf[119],22,"\004corerequire-extension");
lf[120]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[121]=C_h_intern(&lf[121],22,"\003sysdo-the-right-thing");
lf[122]=C_h_intern(&lf[122],24,"\004coreelaborationtimeonly");
lf[123]=C_h_intern(&lf[123],23,"\004coreelaborationtimetoo");
lf[124]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[125]=C_h_intern(&lf[125],19,"\004corecompiletimetoo");
lf[126]=C_h_intern(&lf[126],20,"\004corecompiletimeonly");
lf[127]=C_h_intern(&lf[127],13,"\004corecallunit");
lf[128]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[129]=C_h_intern(&lf[129],12,"\004coredeclare");
lf[130]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[131]=C_h_intern(&lf[131],10,"\000compiling");
lf[132]=C_h_intern(&lf[132],12,"\003sysfeatures");
lf[133]=C_h_intern(&lf[133],28,"\010compilerprocess-declaration");
lf[134]=C_h_intern(&lf[134],8,"\003syswarn");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000,declarations are ignored in interpreted code");
lf[136]=C_h_intern(&lf[136],18,"\004coredefine-inline");
lf[137]=C_h_intern(&lf[137],20,"\004coredefine-constant");
lf[138]=C_h_intern(&lf[138],6,"define");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000%cannot evaluate compiler-special-form");
lf[140]=C_h_intern(&lf[140],8,"\004coreapp");
lf[141]=C_h_intern(&lf[141],8,"location");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000%cannot evaluate compiler-special-form");
lf[143]=C_h_intern(&lf[143],11,"\004coreinline");
lf[144]=C_h_intern(&lf[144],20,"\004coreinline_allocate");
lf[145]=C_h_intern(&lf[145],19,"\004coreforeign-lambda");
lf[146]=C_h_intern(&lf[146],28,"\004coredefine-foreign-variable");
lf[147]=C_h_intern(&lf[147],29,"\004coredefine-external-variable");
lf[148]=C_h_intern(&lf[148],17,"\004corelet-location");
lf[149]=C_h_intern(&lf[149],22,"\004coreforeign-primitive");
lf[150]=C_h_intern(&lf[150],20,"\004coreforeign-lambda*");
lf[151]=C_h_intern(&lf[151],24,"\004coredefine-foreign-type");
lf[152]=C_h_intern(&lf[152],10,"\003sysexpand");
lf[153]=C_h_intern(&lf[153],18,"\003syscurrent-thread");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal non-atomic object");
lf[155]=C_h_intern(&lf[155],11,"\003sysnumber\077");
lf[156]=C_h_intern(&lf[156],8,"keyword\077");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[158]=C_h_intern(&lf[158],16,"\003syseval-handler");
lf[159]=C_h_intern(&lf[159],12,"eval-handler");
lf[160]=C_h_intern(&lf[160],4,"eval");
lf[161]=C_h_intern(&lf[161],24,"\003syssyntax-error-culprit");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\032illegal lambda-list syntax");
lf[163]=C_h_intern(&lf[163],12,"load-verbose");
lf[164]=C_h_intern(&lf[164],14,"\003sysabort-load");
lf[165]=C_h_intern(&lf[165],27,"\003syscurrent-source-filename");
lf[166]=C_h_intern(&lf[166],21,"\003syscurrent-load-path");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[168]=C_h_intern(&lf[168],18,"\003sysdload-disabled");
lf[169]=C_h_intern(&lf[169],22,"set-dynamic-load-mode!");
lf[170]=C_h_intern(&lf[170],21,"\003sysset-dlopen-flags!");
lf[171]=C_h_intern(&lf[171],6,"global");
lf[172]=C_h_intern(&lf[172],5,"local");
lf[173]=C_h_intern(&lf[173],4,"lazy");
lf[174]=C_h_intern(&lf[174],3,"now");
lf[175]=C_h_intern(&lf[175],15,"\003syssignal-hook");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid dynamic-load mode");
lf[177]=C_h_intern(&lf[177],4,"read");
lf[178]=C_h_intern(&lf[178],7,"newline");
lf[179]=C_h_intern(&lf[179],12,"flush-output");
lf[180]=C_h_intern(&lf[180],15,"open-input-file");
lf[181]=C_h_intern(&lf[181],16,"close-input-port");
lf[182]=C_h_intern(&lf[182],13,"string-append");
lf[183]=C_h_intern(&lf[183],8,"\003sysload");
lf[184]=C_h_intern(&lf[184],31,"\003sysread-error-with-line-number");
lf[185]=C_h_intern(&lf[185],17,"\003sysdisplay-times");
lf[186]=C_h_intern(&lf[186],14,"\003sysstop-timer");
lf[187]=C_h_intern(&lf[187],15,"\003sysstart-timer");
lf[188]=C_h_intern(&lf[188],4,"load");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\036unable to load compiled module");
lf[190]=C_h_intern(&lf[190],9,"peek-char");
lf[191]=C_h_intern(&lf[191],13,"\003syssubstring");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[193]=C_h_intern(&lf[193],30,"call-with-current-continuation");
lf[194]=C_h_intern(&lf[194],9,"\003sysdload");
lf[195]=C_h_intern(&lf[195],17,"\003sysmake-c-string");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[197]=C_h_intern(&lf[197],11,"\000file-error");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\012; loading ");
lf[201]=C_h_intern(&lf[201],13,"\003sysfile-info");
lf[202]=C_h_intern(&lf[202],26,"\003sysload-dynamic-extension");
lf[203]=C_h_intern(&lf[203],11,"\000type-error");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a port or string");
lf[205]=C_h_intern(&lf[205],5,"port\077");
lf[206]=C_h_intern(&lf[206],20,"\003sysexpand-home-path");
lf[207]=C_h_intern(&lf[207],13,"load-relative");
lf[208]=C_h_intern(&lf[208],12,"load-noisily");
lf[209]=C_h_intern(&lf[209],15,"\003sysget-keyword");
lf[210]=C_h_intern(&lf[210],8,"\000printer");
lf[211]=C_h_intern(&lf[211],5,"\000time");
lf[212]=C_h_intern(&lf[212],10,"\000evaluator");
lf[213]=C_h_intern(&lf[213],26,"\003sysload-library-extension");
lf[214]=C_h_intern(&lf[214],6,"cygwin");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014cygchicken-0\376\377\016");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012libchicken\376\377\016");
lf[217]=C_h_intern(&lf[217],34,"\003sysdefault-dynamic-load-libraries");
lf[218]=C_h_intern(&lf[218],22,"dynamic-load-libraries");
lf[219]=C_h_intern(&lf[219],18,"\003sysload-library-0");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\022; loading library ");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[224]=C_h_intern(&lf[224],24,"\003sysstring->c-identifier");
lf[225]=C_h_intern(&lf[225],16,"\003sys->feature-id");
lf[226]=C_h_intern(&lf[226],16,"\003sysload-library");
lf[227]=C_h_intern(&lf[227],12,"load-library");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\026unable to load library");
lf[229]=C_h_intern(&lf[229],31,"\003syscanonicalize-extension-path");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension path");
lf[231]=C_h_intern(&lf[231],18,"\003syssymbol->string");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[235]=C_h_intern(&lf[235],19,"\003sysrepository-path");
lf[236]=C_h_intern(&lf[236],15,"repository-path");
lf[237]=C_h_intern(&lf[237],14,"\003syssetup-mode");
lf[238]=C_h_intern(&lf[238],12,"file-exists\077");
lf[239]=C_h_intern(&lf[239],18,"\003sysfind-extension");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[241]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[242]=C_h_intern(&lf[242],21,"\003sysinclude-pathnames");
lf[243]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[244]=C_h_intern(&lf[244],21,"\003sysloaded-extensions");
lf[245]=C_h_intern(&lf[245],14,"string->symbol");
lf[246]=C_h_intern(&lf[246],18,"\003sysload-extension");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot load core library");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot load extension");
lf[249]=C_h_intern(&lf[249],11,"\003sysprovide");
lf[250]=C_h_intern(&lf[250],7,"provide");
lf[251]=C_h_intern(&lf[251],13,"\003sysprovided\077");
lf[252]=C_h_intern(&lf[252],9,"provided\077");
lf[253]=C_h_intern(&lf[253],7,"require");
lf[254]=C_h_intern(&lf[254],12,"\003sysfor-each");
lf[255]=C_h_intern(&lf[255],25,"\003sysextension-information");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[259]=C_h_intern(&lf[259],21,"extension-information");
lf[260]=C_h_intern(&lf[260],18,"require-at-runtime");
lf[261]=C_h_intern(&lf[261],12,"vector->list");
lf[262]=C_h_intern(&lf[262],14,"dynamic/syntax");
lf[263]=C_h_intern(&lf[263],7,"dynamic");
lf[264]=C_h_intern(&lf[264],11,"lset-adjoin");
lf[265]=C_h_intern(&lf[265],3,"eq\077");
lf[266]=C_h_intern(&lf[266],26,"\010compilerfile-requirements");
lf[267]=C_h_intern(&lf[267],6,"import");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\006srfi-2\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\007srfi-10\376\003\000\000\002\376\001\000\000\007srfi"
"-12\376\003\000\000\002\376\001\000\000\007srfi-23\376\003\000\000\002\376\001\000\000\007srfi-28\376\003\000\000\002\376\001\000\000\007srfi-30\376\003\000\000\002\376\001\000\000\007srfi-31\376\003\000\000\002\376\001\000\000"
"\007srfi-39\376\003\000\000\002\376\001\000\000\007srfi-55\376\003\000\000\002\376\001\000\000\007srfi-88\376\003\000\000\002\376\001\000\000\007srfi-98\376\377\016");
lf[269]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[270]=C_h_intern(&lf[270],4,"uses");
lf[271]=C_h_intern(&lf[271],11,"import-only");
lf[272]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[273]=C_h_intern(&lf[273],17,"require-extension");
lf[274]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\006srfi-8\376\003\000\000\002\376\001\000\000\006srfi-9\376\003\000\000\002\376\001\000\000\007srfi-11\376\003\000\000\002\376\001\000\000\007srfi-"
"15\376\003\000\000\002\376\001\000\000\007srfi-16\376\003\000\000\002\376\001\000\000\007srfi-17\376\003\000\000\002\376\001\000\000\007srfi-26\376\377\016");
lf[275]=C_h_intern(&lf[275],12,"\003sysfeature\077");
lf[276]=C_h_intern(&lf[276],4,"srfi");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\005srfi-");
lf[278]=C_h_intern(&lf[278],16,"\003syssyntax-error");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid SRFI number");
lf[280]=C_h_intern(&lf[280],6,"rename");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid extension specifier");
lf[282]=C_h_intern(&lf[282],6,"except");
lf[283]=C_h_intern(&lf[283],4,"only");
lf[284]=C_h_intern(&lf[284],6,"prefix");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid extension specifier");
lf[286]=C_h_intern(&lf[286],11,"string-copy");
lf[289]=C_h_intern(&lf[289],11,"environment");
lf[291]=C_h_intern(&lf[291],16,"\003sysenvironment\077");
lf[292]=C_h_intern(&lf[292],18,"\003syscopy-env-table");
lf[293]=C_h_intern(&lf[293],23,"\003sysenvironment-symbols");
lf[294]=C_h_intern(&lf[294],18,"\003syswalk-namespace");
lf[295]=C_h_intern(&lf[295],23,"interaction-environment");
lf[296]=C_h_intern(&lf[296],25,"scheme-report-environment");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[298]=C_h_intern(&lf[298],11,"make-vector");
lf[299]=C_h_intern(&lf[299],16,"null-environment");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[301]=C_h_intern(&lf[301],28,"\003sysresolve-include-filename");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\013 major GCs\012");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\013 minor GCs\012");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\013 mutations\012");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\027 seconds in (major) GC\012");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\021 seconds elapsed\012");
lf[309]=C_h_intern(&lf[309],18,"\003sysrepl-eval-hook");
lf[310]=C_h_intern(&lf[310],27,"\003sysrepl-print-length-limit");
lf[311]=C_h_intern(&lf[311],18,"\003sysrepl-read-hook");
lf[312]=C_h_intern(&lf[312],19,"\003sysrepl-print-hook");
lf[313]=C_h_intern(&lf[313],16,"\003syswrite-char-0");
lf[314]=C_h_intern(&lf[314],9,"\003sysprint");
lf[315]=C_h_intern(&lf[315],27,"\003syswith-print-length-limit");
lf[316]=C_h_intern(&lf[316],11,"repl-prompt");
lf[317]=C_h_intern(&lf[317],20,"\003sysread-prompt-hook");
lf[318]=C_h_intern(&lf[318],16,"\003sysflush-output");
lf[319]=C_h_intern(&lf[319],19,"\003sysstandard-output");
lf[320]=C_h_intern(&lf[320],22,"\003sysclear-trace-buffer");
lf[321]=C_h_intern(&lf[321],16,"print-call-chain");
lf[322]=C_h_intern(&lf[322],5,"reset");
lf[323]=C_h_intern(&lf[323],4,"repl");
lf[324]=C_h_intern(&lf[324],18,"\003sysstandard-error");
lf[325]=C_h_intern(&lf[325],18,"\003sysstandard-input");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\006\012Error");
lf[329]=C_h_intern(&lf[329],17,"\003syserror-handler");
lf[330]=C_h_intern(&lf[330],20,"\003syswarnings-enabled");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\005 (in ");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000FWarning: the following toplevel variables are referenced but unbound:\012");
lf[334]=C_h_intern(&lf[334],15,"\003sysread-char-0");
lf[335]=C_h_intern(&lf[335],15,"\003syspeek-char-0");
lf[336]=C_h_intern(&lf[336],21,"\003sysenable-qualifiers");
lf[337]=C_h_intern(&lf[337],17,"\003sysreset-handler");
lf[338]=C_h_intern(&lf[338],28,"\003syssharp-comma-reader-ctors");
lf[339]=C_h_intern(&lf[339],18,"define-reader-ctor");
lf[340]=C_h_intern(&lf[340],18,"\003sysuser-read-hook");
lf[341]=C_h_intern(&lf[341],9,"read-char");
lf[342]=C_h_intern(&lf[342],14,"\003sysread-error");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000!invalid sharp-comma external form");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000!undefined sharp-comma constructor");
lf[347]=C_h_intern(&lf[347],19,"print-error-message");
lf[348]=C_h_intern(&lf[348],22,"with-exception-handler");
lf[350]=C_h_intern(&lf[350],6,"\003sysgc");
lf[352]=C_h_intern(&lf[352],17,"\003systhread-yield!");
lf[355]=C_h_intern(&lf[355],17,"open-input-string");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000(Error: not enough room for result string");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\010No error");
lf[366]=C_h_intern(&lf[366],15,"\003sysmake-string");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\004#;> ");
lf[368]=C_h_intern(&lf[368],14,"make-parameter");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000srfi-8\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-2\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\010\000s"
"rfi-10\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001\000\000\010\000srfi-61\376\377\016");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\014dynamic-wind\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003"
"\000\000\002\376\001\000\000\031scheme-report-environment\376\003\000\000\002\376\001\000\000\020null-environment\376\003\000\000\002\376\001\000\000\027interaction"
"-environment\376\377\016");
lf[371]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376"
"\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000"
"\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005"
"caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaa"
"r\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadad"
"r\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdadd"
"r\376\003\000\000\002\376\001\000\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-c"
"ar!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006lengt"
"h\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\007reverse\376\003\000\000\002\376\001\000\000"
"\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004assq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003"
"\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077"
"\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010complex\077\376\003\000\000\002\376\001\000\000\010ine"
"xact\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\005zero\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001\000\000\005even\077\376\003\000\000\002\376\001\000\000\011po"
"sitive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376"
"\001\000\000\001*\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001"
"\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376\001\000"
"\000\003abs\376\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016"
"exact->inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\004expt\376\003"
"\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376"
"\003\000\000\002\376\001\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000"
"\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003"
"\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002"
"\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015cha"
"r-numeric\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\020char-lower-case\077\376\003\000\000\002\376\001\000\000\013char-upc"
"ase\376\003\000\000\002\376\001\000\000\015char-downcase\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000"
"\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376\001\000\000\011string>"
"=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376\001\000\000\013string-"
"ci>\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\015s"
"tring-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string-set!\376\003\000\000\002\376\001\000\000\015string-append\376\003\000\000"
"\002\376\001\000\000\013string-copy\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\011substring"
"\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\012vector-ref"
"\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\015vector-length\376\003\000\000"
"\002\376\001\000\000\014vector->list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\012procedur"
"e\077\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\005force\376\003\000\000\002\376\001\000\000\036call-wi"
"th-current-continuation\376\003\000\000\002\376\001\000\000\013input-port\077\376\003\000\000\002\376\001\000\000\014output-port\077\376\003\000\000\002\376\001\000\000\022curr"
"ent-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-file\376\003\000\000\002\376\001"
"\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002"
"\376\001\000\000\020close-input-port\376\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\004load\376\003\000\000\002\376\001\000\000\004read\376\003\000\000"
"\002\376\001\000\000\013eof-object\077\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007"
"display\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\024with-input-from-file\376\003\000\000\002\376"
"\001\000\000\023with-output-to-file\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\012\003sysvalues\376\003\000\000\002\376\001"
"\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\010\003syslis"
"t\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\377\016");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[373]=C_h_intern(&lf[373],18,"\003sysnumber->string");
lf[374]=C_h_intern(&lf[374],24,"get-environment-variable");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\022CHICKEN_REPOSITORY");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[377]=C_h_intern(&lf[377],5,"linux");
lf[378]=C_h_intern(&lf[378],6,"netbsd");
lf[379]=C_h_intern(&lf[379],7,"openbsd");
lf[380]=C_h_intern(&lf[380],7,"freebsd");
lf[381]=C_h_intern(&lf[381],16,"software-version");
lf[382]=C_h_intern(&lf[382],14,"build-platform");
lf[383]=C_h_intern(&lf[383],7,"windows");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\004.dll");
lf[385]=C_h_intern(&lf[385],6,"macosx");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[387]=C_h_intern(&lf[387],4,"hpux");
lf[388]=C_h_intern(&lf[388],4,"hppa");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003.sl");
lf[390]=C_h_intern(&lf[390],12,"machine-type");
lf[391]=C_h_intern(&lf[391],13,"software-type");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\012C_toplevel");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
C_register_lf2(lf,396,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2955,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_expand_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2953 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2955,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! core-library-modules ...) */,lf[1]);
t3=C_set_block_item(lf[2] /* explicit-library-modules */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate(&lf[3] /* (set! constant62 ...) */,lf[4]);
t5=C_mutate(&lf[5] /* (set! constant70 ...) */,lf[6]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 137  get-environment-variable */
t7=*((C_word*)lf[374]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[395]);}

/* k2986 in k2953 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_block_size(t1);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_subchar(t1,t4);
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* eval.scm: 138  ##sys#string-append */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t1,lf[393]);}
else{
/* eval.scm: 138  ##sys#string-append */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t1,lf[394]);}}
else{
t3=t2;
f_2991(2,t3,C_SCHEME_FALSE);}}

/* k2989 in k2986 in k2953 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1 /* (set! chicken-prefix ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2992,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[9]+1 /* (set! chicken-home ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3019,tmp=(C_word)a,a+=2,tmp));
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate((C_word*)lf[12]+1 /* (set! hash-symbol ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3031,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[13]+1 /* (set! hash-table-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3046,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[14]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3101,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[15]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3161,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[16]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3181,tmp=(C_word)a,a+=2,tmp));
t13=(C_word)C_slot(lf[17],C_fix(0));
t14=C_mutate((C_word*)lf[18]+1 /* (set! hash-table-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(lf[19] /* eval-environment */,0,C_SCHEME_FALSE);
t16=C_set_block_item(lf[20] /* environment-is-mutable */,0,C_SCHEME_FALSE);
t17=C_mutate((C_word*)lf[21]+1 /* (set! eval-decorator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3309,tmp=(C_word)a,a+=2,tmp));
t18=C_set_block_item(lf[27] /* unbound-in-eval */,0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[28] /* eval-debug-level */,0,C_fix(1));
t20=*((C_word*)lf[24]+1);
t21=*((C_word*)lf[29]+1);
t22=*((C_word*)lf[25]+1);
t23=*((C_word*)lf[23]+1);
t24=*((C_word*)lf[30]+1);
t25=(C_word)C_slot(lf[17],C_fix(0));
t26=*((C_word*)lf[31]+1);
t27=C_mutate((C_word*)lf[32]+1 /* (set! compile-to-closure ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3353,a[2]=t21,a[3]=t25,tmp=(C_word)a,a+=4,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6767,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10468,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 817  make-parameter */
t30=*((C_word*)lf[368]+1);
((C_proc3)(void*)(*((C_word*)t30+1)))(3,t30,t28,t29);}

/* a10467 in k2989 in k2986 in k2953 */
static void C_ccall f_10468(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_10468r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_10468r(t0,t1,t2,t3);}}

static void C_ccall f_10468r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[20]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10472,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[289]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_10472(t15,t14);}
else{
t10=C_SCHEME_UNDEFINED;
t11=t8;
f_10472(t11,t10);}}
else{
t9=t8;
f_10472(t9,C_SCHEME_UNDEFINED);}}

/* k10470 in a10467 in k2989 in k2986 in k2953 */
static void C_fcall f_10472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10472,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10475,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10480,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10497,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t14=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a10496 in k10470 in a10467 in k2989 in k2986 in k2953 */
static void C_ccall f_10497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10497,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[20]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[19]+1));
t4=C_mutate((C_word*)lf[20]+1 /* (set! environment-is-mutable ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[19]+1 /* (set! eval-environment ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* a10486 in k10470 in a10467 in k2989 in k2986 in k2953 */
static void C_ccall f_10487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10495,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 829  ##sys#current-environment */
t3=*((C_word*)lf[101]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10493 in a10486 in k10470 in a10467 in k2989 in k2986 in k2953 */
static void C_ccall f_10495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 829  ##sys#compile-to-closure */
t2=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* a10479 in k10470 in a10467 in k2989 in k2986 in k2953 */
static void C_ccall f_10480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10480,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[20]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[19]+1));
t4=C_mutate((C_word*)lf[20]+1 /* (set! environment-is-mutable ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[19]+1 /* (set! eval-environment ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* k10473 in k10470 in a10467 in k2989 in k2986 in k2953 */
static void C_ccall f_10475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g13931394 */
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6767,2,t0,t1);}
t2=C_mutate((C_word*)lf[158]+1 /* (set! eval-handler ...) */,t1);
t3=C_mutate((C_word*)lf[159]+1 /* (set! eval-handler ...) */,*((C_word*)lf[158]+1));
t4=C_mutate((C_word*)lf[160]+1 /* (set! eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6770,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[29]+1);
t6=C_mutate((C_word*)lf[89]+1 /* (set! decompose-lambda-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6780,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6862,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 861  make-parameter */
t9=*((C_word*)lf[368]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6862,2,t0,t1);}
t2=C_mutate((C_word*)lf[163]+1 /* (set! load-verbose ...) */,t1);
t3=C_mutate((C_word*)lf[164]+1 /* (set! abort-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6864,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[165] /* current-source-filename */,0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[166]+1 /* (set! current-load-path ...) */,lf[167]);
t6=C_set_block_item(lf[168] /* dload-disabled */,0,C_SCHEME_FALSE);
t7=C_mutate((C_word*)lf[169]+1 /* (set! set-dynamic-load-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6870,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[177]+1);
t9=*((C_word*)lf[24]+1);
t10=*((C_word*)lf[31]+1);
t11=*((C_word*)lf[178]+1);
t12=*((C_word*)lf[179]+1);
t13=*((C_word*)lf[160]+1);
t14=*((C_word*)lf[180]+1);
t15=*((C_word*)lf[181]+1);
t16=*((C_word*)lf[182]+1);
t17=*((C_word*)lf[163]+1);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6943,a[2]=((C_word*)t0)[2],a[3]=t17,a[4]=t10,a[5]=t12,a[6]=t14,a[7]=t15,a[8]=t9,a[9]=t11,a[10]=t8,a[11]=t13,tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 895  ##sys#make-c-string */
t19=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[392]);}

/* k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6945,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[183]+1 /* (set! load ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp));
t4=C_mutate((C_word*)lf[188]+1 /* (set! load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7409,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[207]+1 /* (set! load-relative ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7431,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[208]+1 /* (set! load-noisily ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7467,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10462,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 988  software-type */
t9=*((C_word*)lf[391]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k10460 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10462,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[383]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_7493(t3,lf[384]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10458,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 989  software-version */
t4=*((C_word*)lf[381]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10456 in k10460 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10458,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[385]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_7493(t3,lf[386]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10454,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 990  software-version */
t4=*((C_word*)lf[381]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10452 in k10456 in k10460 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10454,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[387]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10450,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 991  machine-type */
t4=*((C_word*)lf[390]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_7493(t3,lf[3]);}}

/* k10448 in k10452 in k10456 in k10460 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,lf[388]);
t3=((C_word*)t0)[2];
f_7493(t3,(C_truep(t2)?lf[389]:lf[3]));}

/* k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7493,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[213]+1 /* (set! load-library-extension ...) */,t1);
t3=C_mutate((C_word*)lf[202]+1 /* (set! load-dynamic-extension ...) */,lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7498,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 997  build-platform */
t5=*((C_word*)lf[382]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7498,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[214]);
t3=(C_truep(t2)?lf[215]:lf[216]);
t4=C_mutate((C_word*)lf[217]+1 /* (set! default-dynamic-load-libraries ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7505,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10401,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10422,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1003 software-version */
t8=*((C_word*)lf[381]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* k10420 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_truep((C_word)C_eqp(t1,lf[377]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t1,lf[378]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t1,lf[379]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t1,lf[380]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t2=(C_word)C_i_zerop(C_fix((C_word)C_BINARY_VERSION));
t3=((C_word*)t0)[2];
f_10401(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_10401(t2,C_SCHEME_FALSE);}}

/* k10399 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_10401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10401,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10408,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1008 number->string */
C_number_to_string(3,0,t2,C_fix((C_word)C_BINARY_VERSION));}
else{
t2=((C_word*)t0)[2];
f_7505(2,t2,*((C_word*)lf[213]+1));}}

/* k10406 in k10399 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1005 string-append */
t2=*((C_word*)lf[182]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],*((C_word*)lf[213]+1),lf[376],t1);}

/* k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7507,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7514,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10357,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10365,a[2]=t2,a[3]=t5,a[4]=t10,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_10365(t12,t8,*((C_word*)lf[217]+1));}

/* loop1713 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_10365(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10365,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10394,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* g17291730 */
t5=((C_word*)t0)[2];
f_7507(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10392 in loop1713 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10394,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop17131726 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10365(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop17131726 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10365(t6,((C_word*)t0)[3],t5);}}

/* k10355 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10359,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1012 make-parameter */
t3=*((C_word*)lf[368]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a10358 in k10355 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10359,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7514,2,t0,t1);}
t2=C_mutate((C_word*)lf[218]+1 /* (set! dynamic-load-libraries ...) */,t1);
t3=*((C_word*)lf[163]+1);
t4=*((C_word*)lf[182]+1);
t5=*((C_word*)lf[218]+1);
t6=*((C_word*)lf[31]+1);
t7=C_mutate((C_word*)lf[219]+1 /* (set! load-library-0 ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7516,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[226]+1 /* (set! load-library ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7622,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[227]+1 /* (set! load-library ...) */,*((C_word*)lf[226]+1));
t10=*((C_word*)lf[29]+1);
t11=*((C_word*)lf[182]+1);
t12=C_mutate((C_word*)lf[229]+1 /* (set! canonicalize-extension-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7708,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(22)))){
/* ##sys#peek-c-string */
t14=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t13,C_mpointer(&a,(void*)C_private_repository_path()),C_fix(0));}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10329,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1104 get-environment-variable */
t15=*((C_word*)lf[374]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[375]);}}

/* k10327 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10329,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_7868(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10345,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10349,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fudge(C_fix(42));
/* eval.scm: 1108 ##sys#number->string */
t6=*((C_word*)lf[373]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k10347 in k10327 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1106 ##sys#string-append */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[372],t1);}

/* k10343 in k10327 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1105 ##sys#chicken-prefix */
t2=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10333 in k10327 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10335,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_7868(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_EGG_HOME),C_fix(0));}}

/* k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7868,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_mutate((C_word*)lf[235]+1 /* (set! repository-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7869,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[236]+1 /* (set! repository-path ...) */,*((C_word*)lf[235]+1));
t6=C_set_block_item(lf[237] /* setup-mode */,0,C_SCHEME_FALSE);
t7=*((C_word*)lf[238]+1);
t8=*((C_word*)lf[182]+1);
t9=C_mutate((C_word*)lf[239]+1 /* (set! find-extension ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7893,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(lf[244] /* loaded-extensions */,0,C_SCHEME_END_OF_LIST);
t11=*((C_word*)lf[245]+1);
t12=C_mutate((C_word*)lf[246]+1 /* (set! load-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7992,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[249]+1 /* (set! provide ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8069,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[250]+1 /* (set! provide ...) */,*((C_word*)lf[249]+1));
t15=C_mutate((C_word*)lf[251]+1 /* (set! provided? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8111,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[252]+1 /* (set! provided? ...) */,*((C_word*)lf[251]+1));
t17=C_mutate((C_word*)lf[117]+1 /* (set! require ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8125,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[253]+1 /* (set! require ...) */,*((C_word*)lf[117]+1));
t19=*((C_word*)lf[30]+1);
t20=*((C_word*)lf[238]+1);
t21=*((C_word*)lf[182]+1);
t22=*((C_word*)lf[177]+1);
t23=C_mutate((C_word*)lf[255]+1 /* (set! extension-information ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8138,a[2]=t21,a[3]=t20,a[4]=t22,a[5]=t19,tmp=(C_word)a,a+=6,tmp));
t24=C_mutate((C_word*)lf[259]+1 /* (set! extension-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8171,tmp=(C_word)a,a+=2,tmp));
t25=*((C_word*)lf[30]+1);
t26=*((C_word*)lf[177]+1);
t27=C_mutate((C_word*)lf[118]+1 /* (set! lookup-runtime-requirements ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8177,tmp=(C_word)a,a+=2,tmp));
t28=*((C_word*)lf[261]+1);
t29=C_mutate((C_word*)lf[121]+1 /* (set! do-the-right-thing ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8226,tmp=(C_word)a,a+=2,tmp));
t30=*((C_word*)lf[286]+1);
t31=C_mutate((C_word*)lf[224]+1 /* (set! string->c-identifier ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8834,a[2]=t30,tmp=(C_word)a,a+=3,tmp));
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1333 make-vector */
t33=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t33+1)))(4,t33,t32,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8890,2,t0,t1);}
t2=C_mutate(&lf[287] /* (set! r4rs-environment ...) */,t1);
t3=lf[288] /* r5rs-environment */ =C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[289],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[290] /* (set! interaction-environment ...) */,t4);
t6=C_mutate((C_word*)lf[291]+1 /* (set! environment? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8897,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[292]+1 /* (set! copy-env-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8913,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[293]+1 /* (set! environment-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9021,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[295]+1 /* (set! interaction-environment ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9140,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[296]+1 /* (set! scheme-report-environment ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9143,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[298]+1);
t12=C_mutate((C_word*)lf[299]+1 /* (set! null-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9187,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9225,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9241,a[2]=t13,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10320,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1417 initb */
f_9225(t15,lf[287]);}

/* k10318 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[254]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[371]);}

/* k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1438 ##sys#copy-env-table */
t3=*((C_word*)lf[292]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[287],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9245,2,t0,t1);}
t2=C_mutate(&lf[288] /* (set! r5rs-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9248,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10316,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1440 initb */
f_9225(t4,lf[288]);}

/* k10314 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[254]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[370]);}

/* k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9252,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1447 chicken-home */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9252,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[242]+1 /* (set! include-pathnames ...) */,t2);
t4=*((C_word*)lf[182]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9258,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[301]+1 /* (set! resolve-include-filename ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9277,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[31]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9419,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9443,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[185]+1 /* (set! display-times ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9464,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1516 append */
t12=*((C_word*)lf[75]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,lf[369],*((C_word*)lf[132]+1));}

/* k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9519,2,t0,t1);}
t2=C_mutate((C_word*)lf[132]+1 /* (set! features ...) */,t1);
t3=C_set_block_item(lf[309] /* repl-eval-hook */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[310] /* repl-print-length-limit */,0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[311] /* repl-read-hook */,0,C_SCHEME_FALSE);
t6=C_mutate((C_word*)lf[312]+1 /* (set! repl-print-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9524,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9541,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10308,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1530 make-parameter */
t9=*((C_word*)lf[368]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a10307 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10308,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[367]);}

/* k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9541,2,t0,t1);}
t2=C_mutate((C_word*)lf[316]+1 /* (set! repl-prompt ...) */,t1);
t3=*((C_word*)lf[316]+1);
t4=C_mutate((C_word*)lf[317]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9543,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[320]+1 /* (set! clear-trace-buffer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9559,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[160]+1);
t7=*((C_word*)lf[177]+1);
t8=*((C_word*)lf[193]+1);
t9=*((C_word*)lf[321]+1);
t10=*((C_word*)lf[179]+1);
t11=*((C_word*)lf[163]+1);
t12=*((C_word*)lf[322]+1);
t13=C_mutate((C_word*)lf[323]+1 /* (set! repl ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9562,a[2]=t8,a[3]=t6,a[4]=t7,a[5]=t11,a[6]=t9,a[7]=t10,tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9926,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1647 make-vector */
t15=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9926,2,t0,t1);}
t2=C_mutate((C_word*)lf[338]+1 /* (set! sharp-comma-reader-ctors ...) */,t1);
t3=C_mutate((C_word*)lf[339]+1 /* (set! define-reader-ctor ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9928,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[340]+1);
t5=*((C_word*)lf[341]+1);
t6=*((C_word*)lf[177]+1);
t7=C_mutate((C_word*)lf[340]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9937,a[2]=t4,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=lf[345] /* last-error */ =C_SCHEME_FALSE;;
t9=C_mutate(&lf[346] /* (set! run-safe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10012,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[349] /* (set! store-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10071,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[351] /* (set! CHICKEN_yield ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10080,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[353] /* (set! CHICKEN_eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10092,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[354] /* (set! CHICKEN_eval_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10108,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[356] /* (set! store-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10134,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[358] /* (set! CHICKEN_eval_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10147,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[359] /* (set! CHICKEN_eval_string_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10173,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[360] /* (set! CHICKEN_apply ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10210,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[361] /* (set! CHICKEN_apply_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10226,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[362] /* (set! CHICKEN_read ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10252,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[363] /* (set! CHICKEN_load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10274,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[364] /* (set! CHICKEN_get_error_message ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10289,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[22]+1 /* (set! make-lambda-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10299,tmp=(C_word)a,a+=2,tmp));
t23=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10299,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10306,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1778 ##sys#make-string */
t5=*((C_word*)lf[366]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k10304 in ##sys#make-lambda-info in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static C_word C_fcall f_10289(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
t3=lf[345];
if(C_truep(t3)){
return(f_10134(t3,t2,t1));}
else{
return(f_10134(lf[365],t2,t1));}}

/* CHICKEN_load in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10274,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10278,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k10276 in CHICKEN_load in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10283,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1768 run-safe */
f_10012(((C_word*)t0)[2],t2);}

/* a10282 in k10276 in CHICKEN_load in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10287,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1768 load */
t3=*((C_word*)lf[188]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10285 in a10282 in k10276 in CHICKEN_load in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10252,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10256,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k10254 in CHICKEN_read in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10256,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10261,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1762 run-safe */
f_10012(((C_word*)t0)[2],t3);}

/* a10260 in k10254 in CHICKEN_read in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10265,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1764 open-input-string */
t3=*((C_word*)lf[355]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10263 in a10260 in k10254 in CHICKEN_read in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1765 read */
t3=*((C_word*)lf[177]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k10270 in k10263 in a10260 in k10254 in CHICKEN_read in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1765 store-result */
f_10071(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_10226,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10232,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1755 run-safe */
f_10012(t1,t6);}

/* a10231 in CHICKEN_apply_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1757 open-output-string */
t3=*((C_word*)lf[25]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10234 in a10231 in CHICKEN_apply_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10239,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10250,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10248 in k10234 in a10231 in CHICKEN_apply_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1758 write */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10237 in k10234 in a10231 in CHICKEN_apply_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1759 get-output-string */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10244 in k10237 in k10234 in a10231 in CHICKEN_apply_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1759 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_10134(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10210,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10216,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1750 run-safe */
f_10012(t1,t5);}

/* a10215 in CHICKEN_apply in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10224,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10222 in a10215 in CHICKEN_apply in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1750 store-result */
f_10071(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10173,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10177,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k10175 in CHICKEN_eval_string_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10177,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10182,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1741 run-safe */
f_10012(((C_word*)t0)[2],t4);}

/* a10181 in k10175 in CHICKEN_eval_string_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1743 open-output-string */
t3=*((C_word*)lf[25]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10184 in a10181 in k10175 in CHICKEN_eval_string_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10189,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10200,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10204,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10208,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1744 open-input-string */
t6=*((C_word*)lf[355]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k10206 in k10184 in a10181 in k10175 in CHICKEN_eval_string_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1744 read */
t2=*((C_word*)lf[177]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10202 in k10184 in a10181 in k10175 in CHICKEN_eval_string_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1744 eval */
t2=*((C_word*)lf[160]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10198 in k10184 in a10181 in k10175 in CHICKEN_eval_string_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1744 write */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10187 in k10184 in a10181 in k10175 in CHICKEN_eval_string_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1745 get-output-string */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10194 in k10187 in k10184 in a10181 in k10175 in CHICKEN_eval_string_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1745 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_10134(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10147,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10153,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1732 run-safe */
f_10012(t1,t5);}

/* a10152 in CHICKEN_eval_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1734 open-output-string */
t3=*((C_word*)lf[25]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10155 in a10152 in CHICKEN_eval_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10160,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10171,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1735 eval */
t4=*((C_word*)lf[160]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10169 in k10155 in a10152 in CHICKEN_eval_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1735 write */
t2=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10158 in k10155 in a10152 in CHICKEN_eval_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1736 get-output-string */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10165 in k10158 in k10155 in a10152 in CHICKEN_eval_to_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1736 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_10134(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static C_word C_fcall f_10134(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[345] /* (set! last-error ...) */,lf[357]);
return(C_SCHEME_FALSE);}
else{
t5=(C_word)C_copy_result_string(t1,t3,t4);
return(t5);}}

/* CHICKEN_eval_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10108,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10112,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k10110 in CHICKEN_eval_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10112,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10117,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1713 run-safe */
f_10012(((C_word*)t0)[2],t3);}

/* a10116 in k10110 in CHICKEN_eval_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10121,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1715 open-input-string */
t3=*((C_word*)lf[355]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10119 in a10116 in k10110 in CHICKEN_eval_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10132,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1716 read */
t4=*((C_word*)lf[177]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k10130 in k10119 in a10116 in k10110 in CHICKEN_eval_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1716 eval */
t2=*((C_word*)lf[160]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10126 in k10119 in a10116 in k10110 in CHICKEN_eval_string in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1716 store-result */
f_10071(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10092,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10098,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1708 run-safe */
f_10012(t1,t4);}

/* a10097 in CHICKEN_eval in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10106,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1710 eval */
t3=*((C_word*)lf[160]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10104 in a10097 in CHICKEN_eval in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1710 store-result */
f_10071(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10086,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1705 run-safe */
f_10012(t1,t2);}

/* a10085 in CHICKEN_yield in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10090,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1705 ##sys#thread-yield! */
t3=*((C_word*)lf[352]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10088 in a10085 in CHICKEN_yield in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_10071(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10071,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10075,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1699 ##sys#gc */
t5=*((C_word*)lf[350]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k10073 in store-result in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}}

/* run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_10012(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10012,NULL,2,t1,t2);}
t3=lf[345] /* last-error */ =C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10017,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10022,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t6=*((C_word*)lf[193]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a10021 in run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10022,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10028,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10047,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[348]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a10046 in a10021 in run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10053,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10059,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a10058 in a10046 in a10021 in run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10059(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_10059r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_10059r(t0,t1,t2);}}

static void C_ccall f_10059r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10065,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k27142719 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a10064 in a10058 in a10046 in a10021 in run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10065,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a10052 in a10046 in a10021 in run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10053,2,t0,t1);}
/* eval.scm: 1692 thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a10027 in a10021 in run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10028,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10034,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k27142719 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a10033 in a10027 in a10021 in run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10038,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1688 open-output-string */
t3=*((C_word*)lf[25]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10036 in a10033 in a10027 in a10021 in run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10041,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1689 print-error-message */
t3=*((C_word*)lf[347]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k10039 in k10036 in a10033 in a10027 in a10021 in run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10045,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1690 get-output-string */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10043 in k10039 in k10036 in a10033 in a10027 in a10021 in run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[345] /* (set! last-error ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k10015 in run-safe in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_10017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g27172718 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9937,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9947,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1659 read-char */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* eval.scm: 1671 old */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k9945 in ##sys#user-read-hook in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9950,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1660 read */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9948 in k9945 in ##sys#user-read-hook in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9951,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9964,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_9964(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_9964(t6,(C_word)C_i_not(t5));}}

/* k9962 in k9948 in k9945 in ##sys#user-read-hook in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9964(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9964,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1663 err */
t2=((C_word*)t0)[5];
f_9951(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9982,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1667 ##sys#hash-table-ref */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[338]+1),t2);}
else{
/* eval.scm: 1666 err */
t3=((C_word*)t0)[5];
f_9951(t3,((C_word*)t0)[4]);}}}

/* k9980 in k9962 in k9948 in k9945 in ##sys#user-read-hook in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 1670 ##sys#read-error */
t2=*((C_word*)lf[342]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[344],((C_word*)t0)[2]);}}

/* err in k9948 in k9945 in ##sys#user-read-hook in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9951(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9951,NULL,2,t0,t1);}
/* eval.scm: 1661 ##sys#read-error */
t2=*((C_word*)lf[342]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[343],((C_word*)t0)[2]);}

/* define-reader-ctor in k9924 in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9928,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[339]);
/* eval.scm: 1651 ##sys#hash-table-set! */
t5=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[338]+1),t2,t3);}

/* repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9565,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[325]+1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[319]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[324]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9606,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t8,a[11]=t6,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1560 ##sys#error-handler */
t10=*((C_word*)lf[329]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9609,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 1561 ##sys#reset-handler */
t3=*((C_word*)lf[337]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[38],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9609,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[27]+1);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9611,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9617,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp));
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9626,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t8,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9691,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9911,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1575 ##sys#dynamic-wind */
t14=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,((C_word*)t0)[2],t11,t12,t13);}

/* a9910 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9915,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1639 load-verbose */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k9913 in a9910 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9915,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1 /* (set! unbound-in-eval ...) */,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1641 ##sys#error-handler */
t4=*((C_word*)lf[329]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9917 in k9913 in a9910 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1642 ##sys#reset-handler */
t2=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9691,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_9697(t5,t1);}

/* loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9697(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9697,NULL,2,t0,t1);}
t2=f_9611(((C_word*)((C_word*)t0)[7])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9704,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9894,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1598 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9893 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9894,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9900,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1600 ##sys#reset-handler */
t4=*((C_word*)lf[337]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9899 in a9893 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9900,2,t0,t1);}
t2=C_set_block_item(lf[184] /* read-error-with-line-number */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[336] /* enable-qualifiers */,0,C_SCHEME_TRUE);
t4=f_9617(((C_word*)((C_word*)t0)[3])[1]);
/* eval.scm: 1605 c */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,C_SCHEME_FALSE);}

/* k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1606 ##sys#read-prompt-hook */
t3=*((C_word*)lf[317]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9707,2,t0,t1);}
t2=*((C_word*)lf[311]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g26042605 */
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9713,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9722,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9892,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1609 ##sys#peek-char-0 */
t4=*((C_word*)lf[335]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[325]+1));}}

/* k9890 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 1610 ##sys#read-char-0 */
t3=*((C_word*)lf[334]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[325]+1));}
else{
t3=((C_word*)t0)[2];
f_9722(2,t3,C_SCHEME_UNDEFINED);}}

/* k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1611 ##sys#clear-trace-buffer */
t3=*((C_word*)lf[320]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9725,2,t0,t1);}
t2=C_set_block_item(lf[27] /* unbound-in-eval */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9731,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9740,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9740(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_9740r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9740r(t0,t1,t2);}}

static void C_ccall f_9740r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9744,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(*((C_word*)lf[330]+1))?(C_word)C_i_pairp(*((C_word*)lf[27]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9758,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_9758(t8,t3,*((C_word*)lf[27]+1),C_SCHEME_END_OF_LIST);}
else{
t5=t3;
f_9744(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9758(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9758,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9762,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9774,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1618 ##sys#print */
t6=*((C_word*)lf[314]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[333],C_SCHEME_FALSE,*((C_word*)lf[324]+1));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(9));}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_u_i_memq(t5,t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9846,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9846(2,t8,t6);}
else{
t8=(C_word)C_u_i_caar(t2);
/* eval.scm: 1633 ##sys#symbol-has-toplevel-binding? */
t9=*((C_word*)lf[45]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}}

/* k9844 in loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9846,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1634 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9758(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* eval.scm: 1635 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9758(t5,((C_word*)t0)[3],t2,t4);}}

/* k9772 in loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9777,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9782,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_9782(t6,t2,((C_word*)t0)[2]);}

/* loop2642 in k9772 in loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9782(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9782,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9826,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9794,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1623 ##sys#print */
t6=*((C_word*)lf[314]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[332],C_SCHEME_FALSE,*((C_word*)lf[324]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9792 in loop2642 in k9772 in loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* eval.scm: 1624 ##sys#print */
t4=*((C_word*)lf[314]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[324]+1));}

/* k9795 in k9792 in loop2642 in k9772 in loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9800,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9809,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1626 ##sys#print */
t4=*((C_word*)lf[314]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[331],C_SCHEME_FALSE,*((C_word*)lf[324]+1));}
else{
/* eval.scm: 1629 ##sys#write-char-0 */
t3=*((C_word*)lf[313]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],C_make_character(10),*((C_word*)lf[324]+1));}}

/* k9807 in k9795 in k9792 in loop2642 in k9772 in loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9812,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 1627 ##sys#print */
t4=*((C_word*)lf[314]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[324]+1));}

/* k9810 in k9807 in k9795 in k9792 in loop2642 in k9772 in loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1628 ##sys#write-char-0 */
t2=*((C_word*)lf[313]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),*((C_word*)lf[324]+1));}

/* k9798 in k9795 in k9792 in loop2642 in k9772 in loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1629 ##sys#write-char-0 */
t2=*((C_word*)lf[313]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[324]+1));}

/* k9824 in loop2642 in k9772 in loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9782(t3,((C_word*)t0)[2],t2);}

/* k9775 in k9772 in loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1631 ##sys#flush-output */
t2=*((C_word*)lf[318]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[324]+1));}

/* k9760 in loop in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}

/* k9742 in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9747,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9587,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_9587(t6,t4);}
else{
t6=(C_word)C_u_i_car(t3);
t7=t5;
f_9587(t7,(C_word)C_eqp(C_SCHEME_UNDEFINED,t6));}}

/* k9585 in k9742 in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9587,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1637 loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_9697(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9592,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[254]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a9591 in k9585 in k9742 in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9592(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9592,3,t0,t1,t2);}
t3=*((C_word*)lf[312]+1);
/* g25672568 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,*((C_word*)lf[319]+1));}

/* k9745 in k9742 in a9739 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1637 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9697(t2,((C_word*)t0)[2]);}

/* a9730 in k9723 in k9720 in k9711 in k9705 in k9702 in loop in a9690 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9731,2,t0,t1);}
t2=*((C_word*)lf[309]+1);
if(C_truep(t2)){
/* g26172618 */
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[3]);}
else{
/* g26172618 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[3]);}}

/* a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9631,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1577 load-verbose */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9629 in a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9631,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1578 load-verbose */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}

/* k9632 in k9629 in a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9639,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1579 ##sys#error-handler */
t3=*((C_word*)lf[329]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* a9638 in k9632 in k9629 in a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9639(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_9639r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9639r(t0,t1,t2,t3);}}

static void C_ccall f_9639r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=f_9617(((C_word*)((C_word*)t0)[5])[1]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9646,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1582 ##sys#print */
t6=*((C_word*)lf[314]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[328],C_SCHEME_FALSE,*((C_word*)lf[324]+1));}

/* k9644 in a9638 in k9632 in k9629 in a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9649,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9686,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1584 ##sys#print */
t4=*((C_word*)lf[314]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[327],C_SCHEME_FALSE,*((C_word*)lf[324]+1));}
else{
t3=t2;
f_9649(2,t3,C_SCHEME_UNDEFINED);}}

/* k9684 in k9644 in a9638 in k9632 in k9629 in a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1585 ##sys#print */
t2=*((C_word*)lf[314]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[324]+1));}

/* k9647 in k9644 in a9638 in k9632 in k9629 in a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9652,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9661,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=t3;
f_9661(t5,(C_word)C_i_nullp(t4));}
else{
t4=t3;
f_9661(t4,C_SCHEME_FALSE);}}

/* k9659 in k9647 in k9644 in a9638 in k9632 in k9629 in a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9661(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9661,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1588 ##sys#print */
t3=*((C_word*)lf[314]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[326],C_SCHEME_FALSE,*((C_word*)lf[324]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1591 ##sys#write-char-0 */
t3=*((C_word*)lf[313]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[324]+1));}}

/* k9668 in k9659 in k9647 in k9644 in a9638 in k9632 in k9629 in a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1592 write-err */
f_9565(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9662 in k9659 in k9647 in k9644 in a9638 in k9632 in k9629 in a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1589 write-err */
f_9565(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9650 in k9647 in k9644 in a9638 in k9632 in k9629 in a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1593 print-call-chain */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[324]+1));}

/* k9653 in k9650 in k9647 in k9644 in a9638 in k9632 in k9629 in a9625 in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1594 flush-output */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[324]+1));}

/* resetports in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static C_word C_fcall f_9617(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate((C_word*)lf[325]+1 /* (set! standard-input ...) */,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[319]+1 /* (set! standard-output ...) */,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[324]+1 /* (set! standard-error ...) */,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k9607 in k9604 in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static C_word C_fcall f_9611(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[325]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[319]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[324]+1));
return(t3);}

/* write-err in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9565(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9565,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9571,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[254]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a9570 in write-err in repl in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9571,3,t0,t1,t2);}
t3=*((C_word*)lf[312]+1);
/* g25442545 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,*((C_word*)lf[324]+1));}

/* ##sys#clear-trace-buffer in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9559,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2513(C_SCHEME_UNDEFINED));}

/* ##sys#read-prompt-hook in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9547,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9554,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1535 repl-prompt */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k9552 in ##sys#read-prompt-hook in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9557,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* g25102511 */
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9555 in k9552 in ##sys#read-prompt-hook in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1535 ##sys#print */
t2=*((C_word*)lf[314]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,*((C_word*)lf[319]+1));}

/* k9545 in ##sys#read-prompt-hook in k9539 in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1536 ##sys#flush-output */
t2=*((C_word*)lf[318]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[319]+1));}

/* ##sys#repl-print-hook in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9524,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9528,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9533,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1527 ##sys#with-print-length-limit */
t6=*((C_word*)lf[315]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[310]+1),t5);}

/* a9532 in ##sys#repl-print-hook in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9533,2,t0,t1);}
t2=*((C_word*)lf[314]+1);
/* g25062507 */
t3=t2;
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k9526 in ##sys#repl-print-hook in k9517 in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1528 ##sys#write-char-0 */
t2=*((C_word*)lf[313]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##sys#display-times in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9464,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9468,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1501 display-rj */
t5=((C_word*)t0)[2];
f_9443(t5,t3,t4,C_fix(8));}

/* k9466 in ##sys#display-times in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1502 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[308]);}

/* k9469 in k9466 in ##sys#display-times in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1503 display-rj */
t4=((C_word*)t0)[2];
f_9443(t4,t2,t3,C_fix(8));}

/* k9472 in k9469 in k9466 in ##sys#display-times in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1504 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[307]);}

/* k9475 in k9472 in k9469 in k9466 in ##sys#display-times in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1505 display-rj */
t4=((C_word*)t0)[2];
f_9443(t4,t2,t3,C_fix(8));}

/* k9478 in k9475 in k9472 in k9469 in k9466 in ##sys#display-times in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1506 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[306]);}

/* k9481 in k9478 in k9475 in k9472 in k9469 in k9466 in ##sys#display-times in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1507 display-rj */
t4=((C_word*)t0)[2];
f_9443(t4,t2,t3,C_fix(8));}

/* k9484 in k9481 in k9478 in k9475 in k9472 in k9469 in k9466 in ##sys#display-times in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1508 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[305]);}

/* k9487 in k9484 in k9481 in k9478 in k9475 in k9472 in k9469 in k9466 in ##sys#display-times in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9492,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1509 display-rj */
t4=((C_word*)t0)[2];
f_9443(t4,t2,t3,C_fix(8));}

/* k9490 in k9487 in k9484 in k9481 in k9478 in k9475 in k9472 in k9469 in k9466 in ##sys#display-times in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1510 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[304]);}

/* display-rj in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9443(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9443,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9447,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_9447(2,t5,lf[303]);}
else{
/* eval.scm: 1496 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k9445 in display-rj in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9447,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9450,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1498 spaces */
t5=((C_word*)t0)[2];
f_9419(t5,t3,t4);}

/* k9448 in k9445 in display-rj in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1499 display */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9419(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9419,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9425,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9425(t6,t1,t2);}

/* doloop2475 in spaces in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9425(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9425,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9435,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1493 display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k9433 in doloop2475 in spaces in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9425(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr4rv,(void*)f_9277r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_9277r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9277r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(19);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9283,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9318,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9348,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1469 test */
t14=((C_word*)t10)[1];
f_9318(t14,t13,t2);}

/* k9346 in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9348,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9358,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9395,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1473 ##sys#repository-path */
t4=*((C_word*)lf[235]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_9358(2,t3,*((C_word*)lf[242]+1));}}}

/* k9393 in k9346 in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9395,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1475 ##sys#repository-path */
t3=*((C_word*)lf[235]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 1471 ##sys#append */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[242]+1),C_SCHEME_END_OF_LIST);}}

/* k9403 in k9393 in k9346 in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9405,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1471 ##sys#append */
t3=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],*((C_word*)lf[242]+1),t2);}

/* k9356 in k9346 in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9358,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_9360(t5,((C_word*)t0)[2],t1);}

/* loop in k9356 in k9346 in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9360(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9360,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9370,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9384,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1479 string-append */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,lf[302],((C_word*)t0)[5]);}}

/* k9382 in loop in k9356 in k9346 in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1479 test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9318(t2,((C_word*)t0)[2],t1);}

/* k9368 in loop in k9356 in k9346 in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1482 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9360(t3,((C_word*)t0)[4],t2);}}

/* test in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9318(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9318,NULL,3,t0,t1,t2);}
t3=(C_word)C_fudge(C_fix(24));
t4=(C_truep(t3)?(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[5],*((C_word*)lf[202]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[202]+1),lf[5])):(C_word)C_a_i_list(&a,1,lf[5]));
/* eval.scm: 1464 test2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9283(t5,t1,t2,t4);}

/* test2 in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9283(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9283,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9296,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1458 exists? */
f_9258(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9299,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* eval.scm: 1459 ##sys#string-append */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k9297 in test2 in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9305,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1460 exists? */
f_9258(t2,t1);}

/* k9303 in k9297 in test2 in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1462 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9283(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k9294 in test2 in ##sys#resolve-include-filename in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9258(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9258,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9262,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1453 ##sys#file-info */
t4=*((C_word*)lf[201]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k9260 in exists? in k9250 in k9246 in k9243 in k9239 in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9225(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9225,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9227,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_9227 in initb in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9227,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9231,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1414 ##sys#hash-table-location */
t4=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k9229 */
static void C_ccall f_9231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9187(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_9187r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_9187r(t0,t1,t2,t3);}}

static void C_ccall f_9187r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[299]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9194,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
if(C_truep(t6)){
if(C_truep(t6)){
/* eval.scm: 1405 ##sys#error */
t7=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[299],lf[300],t2);}
else{
t7=t5;
f_9194(2,t7,C_SCHEME_UNDEFINED);}}
else{
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(5)))){
/* eval.scm: 1405 ##sys#error */
t7=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[299],lf[300],t2);}
else{
t7=t5;
f_9194(2,t7,C_SCHEME_UNDEFINED);}}}

/* k9192 in null-environment in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9201,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1408 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k9199 in k9192 in null-environment in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9201,2,t0,t1);}
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[3]))){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,3,lf[289],t1,t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[289],t1,C_SCHEME_FALSE));}}

/* scheme-report-environment in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9143(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_9143r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_9143r(t0,t1,t2,t3);}}

static void C_ccall f_9143r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,lf[296]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9163,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1396 ##sys#copy-env-table */
t9=*((C_word*)lf[292]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[287],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9176,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1397 ##sys#copy-env-table */
t9=*((C_word*)lf[292]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[288],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1398 ##sys#error */
t8=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[296],lf[297],t2);}}

/* k9174 in scheme-report-environment in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9176,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[289],t1,((C_word*)t0)[2]));}

/* k9161 in scheme-report-environment in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9163,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[289],t1,((C_word*)t0)[2]));}

/* interaction-environment in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9140,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[290]);}

/* ##sys#environment-symbols in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9021(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_9021r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_9021r(t0,t1,t2,t3);}}

static void C_ccall f_9021r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_structure(t2,lf[289]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_header_size(t7));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9042,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9042(t12,t1,C_fix(0),C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9113,a[2]=t1,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9115,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1383 ##sys#walk-namespace */
t12=*((C_word*)lf[294]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* a9114 in ##sys#environment-symbols in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9115,3,t0,t1,t2);}
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9125,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_9125(2,t5,t3);}
else{
/* eval.scm: 1385 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k9123 in a9114 in ##sys#environment-symbols in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9125,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k9111 in ##sys#environment-symbols in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* doloop2334 in ##sys#environment-symbols in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9042(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9042,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9060,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(((C_word*)t0)[3],t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9066,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_9066(t10,t5,t6,t3);}}

/* loop in doloop2334 in ##sys#environment-symbols in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_9066(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9066,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9085,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_9085(2,t8,t6);}
else{
/* eval.scm: 1377 pred */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t5);}}}

/* k9083 in loop in doloop2334 in ##sys#environment-symbols in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9085,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* eval.scm: 1378 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9066(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1379 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9066(t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k9058 in doloop2334 in ##sys#environment-symbols in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_9060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_9042(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#copy-env-table in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5rv,(void*)f_8913r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_8913r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_8913r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8923,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t2,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1344 ##sys#make-vector */
t10=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,C_SCHEME_END_OF_LIST);}

/* k8921 in ##sys#copy-env-table in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8923,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_8928(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop2310 in k8921 in ##sys#copy-env-table in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8928(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8928,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
t3=((C_word*)t0)[7];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8949,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8955(t8,t3,t4);}}

/* copy in doloop2310 in k8921 in ##sys#copy-env-table in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8955(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8955,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_i_not(((C_word*)t0)[5]);
t6=(C_truep(t5)?t5:(C_word)C_u_i_memq(t4,((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8984,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep(((C_word*)t0)[3])){
t9=((C_word*)t0)[2];
t10=t7;
f_8984(t10,(C_word)C_a_i_vector(&a,3,t4,t8,t9));}
else{
t9=(C_word)C_slot(t3,C_fix(2));
t10=t7;
f_8984(t10,(C_word)C_a_i_vector(&a,3,t4,t8,t9));}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1360 copy */
t13=t1;
t14=t7;
t1=t13;
t2=t14;
goto loop;}}}

/* k8982 in copy in doloop2310 in k8921 in ##sys#copy-env-table in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8984(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8984,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8988,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1359 copy */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8955(t4,t2,t3);}

/* k8986 in k8982 in copy in doloop2310 in k8921 in ##sys#copy-env-table in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8988,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8947 in doloop2310 in k8921 in ##sys#copy-env-table in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8928(t4,((C_word*)t0)[2],t3);}

/* ##sys#environment? in k8888 in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8897,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[289]))){
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(C_fix(3),t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#string->c-identifier in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8834,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8838,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1322 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8836 in ##sys#string->c-identifier in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8838,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8846,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_8846(t3,C_fix(0)));}

/* doloop2279 in k8836 in ##sys#string->c-identifier in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static C_word C_fcall f_8846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
return(t2);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_word)C_u_i_char_alphabeticp(t2))){
t3=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t15=t3;
t1=t15;
goto loop;}
else{
t3=(C_word)C_u_i_char_numericp(t2);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
if(C_truep(t4)){
t5=(C_word)C_setsubchar(((C_word*)t0)[2],t1,C_make_character(95));
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t15=t6;
t1=t15;
goto loop;}
else{
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t15=t5;
t1=t15;
goto loop;}}
else{
t5=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_setsubchar(((C_word*)t0)[2],t1,C_make_character(95));
t7=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t15=t7;
t1=t15;
goto loop;}
else{
t6=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t15=t6;
t1=t15;
goto loop;}}}}}

/* ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8226,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8229,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t12=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8254,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8295,a[2]=t6,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8650,a[2]=t10,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t15=(C_word)C_u_i_car(t2);
t16=t14;
f_8650(t16,(C_word)C_i_symbolp(t15));}
else{
t15=t14;
f_8650(t15,C_SCHEME_FALSE);}}

/* k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8650,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[276]);
if(C_truep(t3)){
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8669,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8673,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8679,a[2]=t8,a[3]=t14,a[4]=t10,a[5]=t5,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_8679(t16,t11,t12);}
else{
t4=(C_word)C_eqp(t2,lf[280]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8759,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_8759(t6,t4);}
else{
t6=(C_word)C_eqp(t2,lf[282]);
if(C_truep(t6)){
t7=t5;
f_8759(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[283]);
t8=t5;
f_8759(t8,(C_truep(t7)?t7:(C_word)C_eqp(t2,lf[284])));}}}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
/* eval.scm: 1313 doit */
t2=((C_word*)((C_word*)t0)[2])[1];
f_8295(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[4]);}
else{
/* eval.scm: 1314 ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[285],((C_word*)t0)[4]);}}}

/* k8757 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8759(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8759,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8768,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8768(t6,t2,((C_word*)t0)[2]);}
else{
/* eval.scm: 1311 ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[281],((C_word*)t0)[2]);}}

/* follow in k8757 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8768(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8768,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8775,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t3;
f_8775(t5,(C_word)C_i_pairp(t4));}
else{
t4=t3;
f_8775(t4,C_SCHEME_FALSE);}}

/* k8773 in follow in k8757 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* eval.scm: 1308 follow */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8768(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k8764 in k8757 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1305 doit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8295(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop2209 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8679(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8679,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8706,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8746,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g22252226 */
t6=t3;
f_8706(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8744 in loop2209 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8746,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop22092222 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8679(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop22092222 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8679(t6,((C_word*)t0)[3],t5);}}

/* g2225 in loop2209 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8706(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8706,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8710,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_8710(2,t4,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1297 ##sys#syntax-error */
t4=*((C_word*)lf[278]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[273],lf[279],t2);}}

/* k8708 in g2225 in loop2209 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8713,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8733,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8737,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1298 number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}

/* k8735 in k8708 in g2225 in loop2209 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[277],t1);}

/* k8731 in k8708 in g2225 in loop2209 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1298 string->symbol */
t2=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8711 in k8708 in g2225 in loop2209 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8718,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8724,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8723 in k8711 in k8708 in g2225 in loop2209 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8724,4,t0,t1,t2,t3);}
t4=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t4)){
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* a8717 in k8711 in k8708 in g2225 in loop2209 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8718,2,t0,t1);}
/* eval.scm: 1299 doit */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8295(t2,t1,((C_word*)t0)[2],((C_word*)t0)[2]);}

/* k8671 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8667 in k8648 in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8669,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[62],t1);
/* eval.scm: 1303 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8295(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8295,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_memq(t2,lf[268]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_8305(2,t6,t4);}
else{
if(C_truep(((C_word*)t0)[3])){
t6=t5;
f_8305(2,t6,(C_word)C_u_i_memq(t2,lf[274]));}
else{
/* eval.scm: 1238 ##sys#feature? */
t6=*((C_word*)lf[275]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}}

/* k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8305,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8312,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1239 impform */
t3=((C_word*)((C_word*)t0)[6])[1];
f_8254(t3,t2,lf[269],((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[0]+1)))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8325,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[270],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[129],t5);
/* eval.scm: 1242 impform */
t7=((C_word*)((C_word*)t0)[6])[1];
f_8254(t7,t2,t6,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[48],t3);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[226],t6);
/* eval.scm: 1242 impform */
t8=((C_word*)((C_word*)t0)[6])[1];
f_8254(t8,t2,t7,((C_word*)t0)[5],C_SCHEME_TRUE);}}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[2]+1)))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8372,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1249 ##sys#extension-information */
t3=*((C_word*)lf[255]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[273]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1264 ##sys#extension-information */
t3=*((C_word*)lf[255]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[273]);}}}}

/* k8465 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8467,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[52],t1);
t3=(C_word)C_u_i_assq(lf[271],t1);
t4=(C_word)C_u_i_assq(lf[260],t1);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8482,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
/* eval.scm: 1269 add-req */
t6=((C_word*)((C_word*)t0)[2])[1];
f_8229(t6,t5,((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t6=t5;
f_8482(2,t6,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8612,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1283 add-req */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8229(t3,t2,((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* k8610 in k8465 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8619,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[48],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[117],t5);
/* eval.scm: 1285 impform */
t7=((C_word*)((C_word*)t0)[3])[1];
f_8254(t7,t2,t6,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8617 in k8610 in k8465 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1284 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k8480 in k8465 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8489,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8497,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[48],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[115],t7);
t9=t4;
f_8501(t9,(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST));}
else{
t5=t4;
f_8501(t5,C_SCHEME_END_OF_LIST);}}

/* k8499 in k8480 in k8465 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8501,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8505,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:(C_truep(((C_word*)t0)[4])?C_SCHEME_FALSE:((C_word*)t0)[3]));
if(C_truep(t3)){
/* ##sys#append */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8523,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8527,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(C_truep(((C_word*)t0)[4])?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8533,a[2]=t6,a[3]=t12,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_8533(t14,t9,t10);}}

/* loop2155 in k8499 in k8480 in k8465 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8533(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8533,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[48],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop21552168 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop21552168 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8525 in k8499 in k8480 in k8465 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8521 in k8499 in k8480 in k8465 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8523,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[117],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t3,C_SCHEME_END_OF_LIST);}

/* k8503 in k8499 in k8480 in k8465 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8495 in k8480 in k8465 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8497,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[62],t1);
/* eval.scm: 1271 impform */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8254(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8487 in k8480 in k8465 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1270 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k8370 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8372,2,t0,t1);}
t2=(C_word)C_u_i_assq(lf[271],t1);
t3=(C_word)C_u_i_assq(lf[52],t1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8389,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[48],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[115],t8);
t10=t5;
f_8393(t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}
else{
t6=t5;
f_8393(t6,C_SCHEME_END_OF_LIST);}}

/* k8391 in k8370 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8393,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8401,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[6])){
/* eval.scm: 1255 impform */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8254(t3,t2,lf[272],((C_word*)t0)[4],C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[270],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[129],t5);
/* eval.scm: 1255 impform */
t7=((C_word*)((C_word*)t0)[5])[1];
f_8254(t7,t2,t6,((C_word*)t0)[4],C_SCHEME_FALSE);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[48],t3);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[226],t6);
/* eval.scm: 1255 impform */
t8=((C_word*)((C_word*)t0)[5])[1];
f_8254(t8,t2,t7,((C_word*)t0)[4],C_SCHEME_FALSE);}}}

/* k8399 in k8391 in k8370 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8401,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t3=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8387 in k8370 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8389,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[62],t1);
/* eval.scm: 1252 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8323 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1241 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k8310 in k8303 in doit in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1239 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* impform in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8254(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8254,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8266,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8273,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t6;
f_8273(2,t8,t7);}
else{
/* eval.scm: 1231 ##sys#current-module */
t8=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t6);}}
else{
t7=t6;
f_8273(2,t7,C_SCHEME_FALSE);}}

/* k8271 in impform in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8273,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[267],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t5=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t4,C_SCHEME_END_OF_LIST);}
else{
/* ##sys#append */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k8264 in impform in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8266,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[62],t2));}

/* add-req in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8229(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8229,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
t4=(C_truep(t3)?lf[262]:lf[263]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8242,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8248,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1223 ##sys#hash-table-update! */
t7=*((C_word*)lf[15]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,*((C_word*)lf[266]+1),t4,t5,t6);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* a8247 in add-req in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8248,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a8241 in add-req in ##sys#do-the-right-thing in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8242,3,t0,t1,t2);}
t3=*((C_word*)lf[264]+1);
/* g20612062 */
t4=t3;
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,*((C_word*)lf[265]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8177(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8177,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8183,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8183(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8183(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8183,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8197,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 1212 ##sys#extension-information */
t5=*((C_word*)lf[255]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k8195 in loop1 in ##sys#lookup-runtime-requirements in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_assq(lf[260],t1);
t4=t2;
f_8200(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_8200(t3,C_SCHEME_FALSE);}}

/* k8198 in k8195 in loop1 in ##sys#lookup-runtime-requirements in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8200,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8207,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1216 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8183(t5,t3,t4);}

/* k8205 in k8198 in k8195 in loop1 in ##sys#lookup-runtime-requirements in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1211 append */
t2=*((C_word*)lf[75]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-information in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8171,3,t0,t1,t2);}
/* eval.scm: 1202 ##sys#extension-information */
t3=*((C_word*)lf[255]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[259]);}

/* ##sys#extension-information in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8138,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8142,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1194 ##sys#repository-path */
t5=*((C_word*)lf[235]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k8140 in ##sys#extension-information in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8142,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8148,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1195 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8146 in k8140 in ##sys#extension-information in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8151,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1196 string-append */
t3=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],lf[257],t1,lf[258]);}

/* k8149 in k8146 in k8140 in ##sys#extension-information in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8154,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8169,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1197 string-append */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[256]);}

/* k8167 in k8149 in k8146 in k8140 in ##sys#extension-information in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1197 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8152 in k8149 in k8146 in k8140 in ##sys#extension-information in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8154,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8158,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* g20082009 */
t3=t2;
f_8158(t3,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* g2008 in k8152 in k8149 in k8146 in k8140 in ##sys#extension-information in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8158(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8158,NULL,3,t0,t1,t2);}
/* g20172018 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#require in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8125(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_8125r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8125r(t0,t1,t2);}}

static void C_ccall f_8125r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8131,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[254]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a8130 in ##sys#require in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8131,3,t0,t1,t2);}
t3=*((C_word*)lf[246]+1);
/* g19851986 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[253]);}

/* ##sys#provided? in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8111,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8122,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1175 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[252]);}

/* k8120 in ##sys#provided? in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[244]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8069(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_8069r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8069r(t0,t1,t2);}}

static void C_ccall f_8069r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8075,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8075(t6,t1,t2);}

/* loop1947 in ##sys#provide in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_8075(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8075,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_check_symbol_2(t3,lf[250]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8090,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1168 ##sys#canonicalize-extension-path */
t6=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[250]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8088 in loop1947 in ##sys#provide in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8090,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[244]+1));
t3=C_mutate((C_word*)lf[244]+1 /* (set! loaded-extensions ...) */,t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_8075(t5,((C_word*)t0)[2],t4);}

/* ##sys#load-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4rv,(void*)f_7992r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_7992r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7992r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_vemptyp(t4);
t7=(C_truep(t6)?C_SCHEME_TRUE:(C_word)C_slot(t4,C_fix(0)));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7999,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t5)[1]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8052,a[2]=t8,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1147 string->symbol */
t10=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,((C_word*)t5)[1]);}
else{
t9=t8;
f_7999(t9,(C_word)C_i_check_symbol_2(((C_word*)t5)[1],t3));}}

/* k8050 in ##sys#load-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7999(t3,t2);}

/* k7997 in ##sys#load-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7999(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7999,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1149 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}

/* k8000 in k7997 in ##sys#load-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8002,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[244]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[0]+1)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1152 ##sys#load-library-0 */
t4=*((C_word*)lf[219]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8029,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1156 ##sys#find-extension */
t4=*((C_word*)lf[239]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k8027 in k8000 in k7997 in ##sys#load-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8029,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8035,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1158 ##sys#load */
t3=*((C_word*)lf[183]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[4])){
/* eval.scm: 1161 ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[3],lf[248],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k8033 in k8027 in k8000 in k7997 in ##sys#load-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8035,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[244]+1));
t3=C_mutate((C_word*)lf[244]+1 /* (set! loaded-extensions ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* k8015 in k8000 in k7997 in ##sys#load-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_8017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(((C_word*)t0)[4])){
/* eval.scm: 1154 ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[3],lf[247],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* ##sys#find-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7893,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7897,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1123 ##sys#repository-path */
t5=*((C_word*)lf[235]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7895 in ##sys#find-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7899,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7945,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(*((C_word*)lf[237]+1))?lf[241]:C_SCHEME_END_OF_LIST);
t5=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t6=(C_truep(((C_word*)t0)[2])?*((C_word*)lf[242]+1):C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[237]+1))){
/* eval.scm: 1132 ##sys#append */
t7=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t3,t4,t5,t6,C_SCHEME_END_OF_LIST);}
else{
/* eval.scm: 1132 ##sys#append */
t7=*((C_word*)lf[64]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t3,t4,t5,t6,lf[243]);}}

/* k7943 in k7895 in ##sys#find-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7945,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7947,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7947(t5,((C_word*)t0)[2],t1);}

/* loop in k7943 in k7895 in ##sys#find-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7947(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7947,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7960,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1139 check */
t5=((C_word*)t0)[2];
f_7899(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7958 in loop in k7943 in k7895 in ##sys#find-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1140 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7947(t3,((C_word*)t0)[4],t2);}}

/* check in k7895 in ##sys#find-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7899(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7899,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7903,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1125 string-append */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[240],((C_word*)t0)[2]);}

/* k7901 in check in k7895 in ##sys#find-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7909,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[168]+1);
if(C_truep(t3)){
t4=t2;
f_7909(2,t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_fudge(C_fix(24)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7938,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1129 ##sys#string-append */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,*((C_word*)lf[202]+1));}
else{
t4=t2;
f_7909(2,t4,C_SCHEME_FALSE);}}}
else{
t3=t2;
f_7909(2,t3,C_SCHEME_FALSE);}}

/* k7936 in k7901 in check in k7895 in ##sys#find-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1129 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7907 in k7901 in check in k7895 in ##sys#find-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t1;
if(C_truep(t3)){
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7919,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1130 ##sys#string-append */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[5]);}}

/* k7917 in k7907 in k7901 in check in k7895 in ##sys#find-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1130 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7910 in k7907 in k7901 in check in k7895 in ##sys#find-extension in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#repository-path in k7866 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7869(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7869r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7869r(t0,t1,t2);}}

static void C_ccall f_7869r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
if(C_truep((C_word)C_vemptyp(t2))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
if(C_truep(t3)){
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)((C_word*)t0)[2])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

/* ##sys#canonicalize-extension-path in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7708,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7711,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7730,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=t5;
f_7730(2,t6,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1077 ##sys#symbol->string */
t6=*((C_word*)lf[231]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7813,a[2]=t4,a[3]=t7,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7813(t9,t5,t2);}
else{
t6=t5;
f_7730(2,t6,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7813(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7813,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[232]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7830,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1084 ##sys#symbol->string */
t5=*((C_word*)lf[231]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_7830(2,t5,t3);}
else{
/* eval.scm: 1086 err */
t5=((C_word*)t0)[2];
f_7711(t5,t4);}}}}

/* k7828 in loop in ##sys#canonicalize-extension-path in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7830,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[233]:lf[234]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7838,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1090 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7813(t7,t5,t6);}

/* k7836 in k7828 in loop in ##sys#canonicalize-extension-path in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1082 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7728 in ##sys#canonicalize-extension-path in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7730,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7735,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7735(t5,((C_word*)t0)[2],t1);}

/* check in k7728 in ##sys#canonicalize-extension-path in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7735,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1093 err */
t5=((C_word*)t0)[3];
f_7711(t5,t1);}
else{
t5=(C_word)C_subchar(t2,C_fix(0));
t6=(C_word)C_eqp(C_make_character(92),t5);
t7=(C_truep(t6)?t6:(C_word)C_eqp(C_make_character(47),t5));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7761,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1095 ##sys#substring */
t9=*((C_word*)lf[191]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,t2,C_fix(1),t3);}
else{
t8=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t9=(C_word)C_subchar(t2,t8);
t10=(C_word)C_eqp(C_make_character(92),t9);
t11=(C_truep(t10)?t10:(C_word)C_eqp(C_make_character(47),t9));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7774,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1097 ##sys#substring */
t14=*((C_word*)lf[191]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t12,t2,C_fix(0),t13);}
else{
t12=t2;
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}}}

/* k7772 in check in k7728 in ##sys#canonicalize-extension-path in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1097 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7735(t2,((C_word*)t0)[2],t1);}

/* k7759 in check in k7728 in ##sys#canonicalize-extension-path in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1095 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7735(t2,((C_word*)t0)[2],t1);}

/* err in ##sys#canonicalize-extension-path in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7711,NULL,2,t0,t1);}
/* eval.scm: 1074 ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[230],((C_word*)t0)[2]);}

/* ##sys#load-library in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7622(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7622r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7622r(t0,t1,t2,t3);}}

static void C_ccall f_7622r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[227]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7629,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 1051 ##sys#load-library-0 */
t7=*((C_word*)lf[219]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t2,t6);}
else{
/* eval.scm: 1051 ##sys#load-library-0 */
t6=*((C_word*)lf[219]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_SCHEME_FALSE);}}

/* k7627 in ##sys#load-library in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7629,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k7637 in k7627 in ##sys#load-library in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1052 ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[227],lf[228],((C_word*)t0)[2],t1);}

/* ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7516,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7520,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1024 ##sys#->feature-id */
t5=*((C_word*)lf[225]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7520,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[132]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7529,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_7529(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7612,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1029 ##sys#string-append */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[213]+1));}}}

/* k7610 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7616,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1030 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7614 in k7610 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7616,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7529(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7527 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7529,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7594,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7598,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1035 ##sys#string->c-identifier */
t6=*((C_word*)lf[224]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k7596 in k7527 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1033 string-append */
t2=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[222],t1,lf[223]);}

/* k7592 in k7527 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1032 ##sys#make-c-string */
t2=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7530 in k7527 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7535,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7581,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1037 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7579 in k7530 in k7527 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7581,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1038 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[221]);}
else{
t2=((C_word*)t0)[3];
f_7535(2,t2,C_SCHEME_UNDEFINED);}}

/* k7582 in k7579 in k7530 in k7527 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1039 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7585 in k7582 in k7579 in k7530 in k7527 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1040 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[220]);}

/* k7533 in k7530 in k7527 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7535,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7540,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7540(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k7533 in k7530 in k7527 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7540(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7540,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7553,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7574,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1043 ##sys#make-c-string */
t6=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k7572 in loop in k7533 in k7530 in k7527 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1043 ##sys#dload */
t2=*((C_word*)lf[194]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7551 in loop in k7533 in k7530 in k7527 in k7518 in ##sys#load-library-0 in k7512 in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7553,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[5],*((C_word*)lf[132]+1)))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],*((C_word*)lf[132]+1));
t3=C_mutate((C_word*)lf[132]+1 /* (set! features ...) */,t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1046 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7540(t3,((C_word*)t0)[4],t2);}}

/* complete in k7503 in k7496 in k7491 in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7507(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7507,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[8]+1);
/* g17091710 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* load-noisily in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7467(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_7467r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7467r(t0,t1,t2,t3);}}

static void C_ccall f_7467r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7471,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7488,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[209]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[212],t3,t5);}

/* a7487 in load-noisily in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7488,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7469 in load-noisily in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7474,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7485,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[209]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[211],((C_word*)t0)[2],t3);}

/* a7484 in k7469 in load-noisily in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7485,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7472 in k7469 in load-noisily in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7477,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7482,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[209]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[210],((C_word*)t0)[2],t3);}

/* a7481 in k7472 in k7469 in load-noisily in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7482,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7475 in k7472 in k7469 in load-noisily in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 985  ##sys#load */
t2=*((C_word*)lf[183]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1);}

/* load-relative in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7431r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7431r(t0,t1,t2,t3);}}

static void C_ccall f_7431r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7439,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_subchar(t2,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t6=t4;
f_7439(2,t6,t2);}
else{
/* eval.scm: 981  ##sys#string-append */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[166]+1),t2);}}

/* k7437 in load-relative in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 978  ##sys#load */
t3=*((C_word*)lf[183]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t3=(C_word)C_u_i_car(t2);
/* eval.scm: 978  ##sys#load */
t4=*((C_word*)lf[183]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t1,t3,C_SCHEME_FALSE);}}

/* load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7409(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7409r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7409r(t0,t1,t2,t3);}}

static void C_ccall f_7409r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
if(C_truep((C_word)C_vemptyp(t3))){
/* eval.scm: 975  ##sys#load */
t4=*((C_word*)lf[183]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 975  ##sys#load */
t5=*((C_word*)lf[183]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t4,C_SCHEME_FALSE);}}

/* ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_6991r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6991r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6991r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(24);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t4,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7359,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7364,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer14931651 */
t10=t9;
f_7364(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer14941649 */
t12=t8;
f_7359(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body14911499 */
t14=t7;
f_6993(t14,t1,t10,t12);}}}

/* def-timer1493 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7364(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7364,NULL,2,t0,t1);}
/* def-printer14941649 */
t2=((C_word*)t0)[2];
f_7359(t2,t1,C_SCHEME_FALSE);}

/* def-printer1494 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7359,NULL,3,t0,t1,t2);}
/* body14911499 */
t3=((C_word*)t0)[2];
f_6993(t3,t1,t2,C_SCHEME_FALSE);}

/* body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_6993(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6993,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_6997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],a[16]=t1,a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[15],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[7])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7358,a[2]=t4,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 907  ##sys#expand-home-path */
t6=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=t4;
f_6997(t5,C_SCHEME_UNDEFINED);}}

/* k7356 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6997(t3,t2);}

/* k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_6997(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6997,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_7000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7280,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 910  port? */
t6=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* k7278 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7280,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_7000(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 912  ##sys#file-info */
t3=*((C_word*)lf[201]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
/* eval.scm: 903  ##sys#signal-hook */
t3=*((C_word*)lf[175]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[203],lf[188],lf[204],t2);}}}

/* k7293 in k7278 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t2;
f_7298(t6,(C_word)C_i_not(((C_word*)((C_word*)t0)[2])[1]));}
else{
t4=t2;
f_7298(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7298(t3,C_SCHEME_FALSE);}}

/* k7296 in k7293 in k7278 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7298(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7298,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_7000(2,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 918  ##sys#string-append */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[202]+1));}}

/* k7299 in k7296 in k7293 in k7278 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[168]+1);
if(C_truep(t3)){
t4=t2;
f_7307(2,t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_fudge(C_fix(24)))){
/* eval.scm: 921  ##sys#file-info */
t4=*((C_word*)lf[201]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t1);}
else{
t4=t2;
f_7307(2,t4,C_SCHEME_FALSE);}}}

/* k7305 in k7299 in k7296 in k7293 in k7278 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7307,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
f_7000(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 923  ##sys#string-append */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[5]);}}

/* k7308 in k7305 in k7299 in k7296 in k7293 in k7278 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 924  ##sys#file-info */
t3=*((C_word*)lf[201]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k7314 in k7308 in k7305 in k7299 in k7296 in k7293 in k7278 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_7000(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_7000(2,t3,C_SCHEME_FALSE);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=((C_word*)t0)[5];
f_7000(2,t4,t3);}}}

/* k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7000,2,t0,t1);}
t2=((C_word*)t0)[18];
t3=(C_truep(t2)?t2:((C_word*)t0)[17]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_7006,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=t3,a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=t1,a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 929  ##sys#signal-hook */
t7=*((C_word*)lf[175]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[197],lf[188],lf[198],((C_word*)((C_word*)t0)[7])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7271,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 930  load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k7269 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7271,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7259,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 931  display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[200]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_7006(2,t4,t3);}}

/* k7257 in k7269 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7262,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 932  display */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7260 in k7257 in k7269 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 933  display */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[199]);}

/* k7263 in k7260 in k7257 in k7269 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 934  flush-output */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7244,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 936  ##sys#make-c-string */
t5=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_7009(2,t3,C_SCHEME_FALSE);}}

/* k7242 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 936  ##sys#dload */
t2=*((C_word*)lf[194]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k7214 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7216,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[5];
f_7009(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 937  has-sep? */
f_6945(t2,((C_word*)t0)[3]);}}

/* k7238 in k7214 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7240,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_7009(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7236,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 938  ##sys#string-append */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[196],((C_word*)t0)[2]);}}

/* k7234 in k7238 in k7214 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 938  ##sys#make-c-string */
t2=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7230 in k7238 in k7214 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 938  ##sys#dload */
t2=*((C_word*)lf[194]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7012,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 939  call-with-current-continuation */
t4=*((C_word*)lf[193]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7017,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[13];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_7021,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t4,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[13])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7203,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 945  has-sep? */
f_6945(t8,((C_word*)t0)[13]);}
else{
t8=t7;
f_7021(2,t8,C_SCHEME_FALSE);}}

/* k7201 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(t1,C_fix(1));
/* eval.scm: 946  ##sys#substring */
t3=*((C_word*)lf[191]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_7021(2,t2,lf[192]);}}

/* k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7021,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7022,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7031,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t13,a[7]=t11,a[8]=t9,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7042,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7191,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* ##sys#dynamic-wind */
t17=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a7190 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7191,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[184]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[165]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[166]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[164]+1));
t6=C_mutate((C_word*)lf[184]+1 /* (set! read-error-with-line-number ...) */,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[165]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[166]+1 /* (set! current-load-path ...) */,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[164]+1 /* (set! abort-load ...) */,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7046,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 948  open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_7046(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7051,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7054,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7182,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 949  ##sys#dynamic-wind */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a7181 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7182,2,t0,t1);}
/* eval.scm: 971  close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7058,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 952  peek-char */
t3=*((C_word*)lf[190]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7176,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_7061(2,t4,C_SCHEME_UNDEFINED);}}

/* k7174 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 954  ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[188],lf[189],((C_word*)t0)[2],t1);}

/* k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 955  read */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7064,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_7069(t5,((C_word*)t0)[2],t1);}

/* doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7069,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7079,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 958  printer */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_7079(2,t4,C_SCHEME_UNDEFINED);}}}

/* k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7082,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7091,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 959  ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}

/* a7124 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_7125r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7125r(t0,t1,t2);}}

static void C_ccall f_7125r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
if(C_truep(((C_word*)t0)[4])){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7134,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7134(t6,t1,t2);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop1621 in a7124 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7134(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7134,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7142,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7152,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g16281629 */
t6=t3;
f_7142(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7150 in loop1621 in a7124 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7134(t3,((C_word*)t0)[2],t2);}

/* g1628 in loop1621 in a7124 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_7142(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7142,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7146,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 968  write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7144 in g1628 in loop1621 in a7124 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 969  newline */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a7090 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7091,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7098,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[187]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 963  evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}}

/* k7096 in a7090 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7103,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7109,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a7108 in k7096 in a7090 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_7109r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7109r(t0,t1,t2);}}

static void C_ccall f_7109r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7113,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7120,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[186]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7118 in a7108 in k7096 in a7090 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
t2=*((C_word*)lf[185]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7111 in a7108 in k7096 in a7090 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7102 in k7096 in a7090 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7103,2,t0,t1);}
/* eval.scm: 962  evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k7080 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7089,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 956  read */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7087 in k7080 in k7077 in doloop1603 in k7062 in k7059 in k7056 in a7053 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_7069(t2,((C_word*)t0)[2],t1);}

/* a7050 in k7044 in a7041 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7051,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a7030 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7031,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[184]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[165]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[166]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[164]+1));
t6=C_mutate((C_word*)lf[184]+1 /* (set! read-error-with-line-number ...) */,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[165]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[166]+1 /* (set! current-load-path ...) */,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[164]+1 /* (set! abort-load ...) */,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* f_7022 in k7019 in a7016 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7022,2,t0,t1);}
/* eval.scm: 947  abrt */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k7010 in k7007 in k7004 in k6998 in k6995 in body1491 in ##sys#load in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_7012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* has-sep? in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_6945(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6945,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6955,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6955(t5,t4));}

/* loop in has-sep? in k6941 in k6860 in k6765 in k2989 in k2986 in k2953 */
static C_word C_fcall f_6955(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_truep((C_word)C_eqp(t2,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
return(t1);}
else{
t3=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* set-dynamic-load-mode! in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6870,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6877,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6882,a[2]=t6,a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6882(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_6882(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6882,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6895,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[171]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 882  loop */
t20=t1;
t21=t7;
t1=t20;
t2=t21;
goto loop;}
else{
t6=(C_word)C_eqp(t3,lf[172]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 882  loop */
t20=t1;
t21=t8;
t1=t20;
t2=t21;
goto loop;}
else{
t7=(C_word)C_eqp(t3,lf[173]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 882  loop */
t20=t1;
t21=t9;
t1=t20;
t2=t21;
goto loop;}
else{
t8=(C_word)C_eqp(t3,lf[174]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 882  loop */
t20=t1;
t21=t10;
t1=t20;
t2=t21;
goto loop;}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 881  ##sys#signal-hook */
t10=*((C_word*)lf[175]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[169],lf[176],t9);}}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6893 in loop in set-dynamic-load-mode! in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 882  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6882(t3,((C_word*)t0)[2],t2);}

/* k6875 in set-dynamic-load-mode! in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 883  ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_6864 in k6860 in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6864,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6780,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6783,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6793,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6793(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_6793(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6793,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6807,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 850  reverse */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6826,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 852  reverse */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_fixnum_plus(t4,C_fix(1));
/* eval.scm: 854  loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 853  err */
t6=((C_word*)t0)[2];
f_6783(t6,t1);}}}
else{
/* eval.scm: 851  err */
t6=((C_word*)t0)[2];
f_6783(t6,t1);}}}

/* k6824 in loop in ##sys#decompose-lambda-list in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 852  k */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6805 in loop in ##sys#decompose-lambda-list in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 850  k */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k6765 in k2989 in k2986 in k2953 */
static void C_fcall f_6783(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6783,NULL,2,t0,t1);}
t2=C_set_block_item(lf[161] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
/* eval.scm: 847  ##sys#syntax-error-hook */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[162],((C_word*)t0)[2]);}

/* eval in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6770(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6770r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6770r(t0,t1,t2,t3);}}

static void C_ccall f_6770r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6778,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 835  ##sys#eval-handler */
t5=*((C_word*)lf[158]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6776 in eval in k6765 in k2989 in k2986 in k2953 */
static void C_ccall f_6778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+35)){
C_save_and_reclaim((void*)tr5rv,(void*)f_3353r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_3353r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3353r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a=C_alloc(35);
t6=(C_word)C_vemptyp(t5);
t7=(C_truep(t6)?C_SCHEME_FALSE:(C_word)C_slot(t5,C_fix(0)));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3359,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t21=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3398,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t22=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3413,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t23=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3520,tmp=(C_word)a,a+=2,tmp));
t24=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3571,a[2]=t19,a[3]=((C_word*)t0)[2],a[4]=t11,a[5]=t15,a[6]=t17,a[7]=((C_word*)t0)[3],a[8]=t13,tmp=(C_word)a,a+=9,tmp));
t25=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6451,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t26=(C_word)C_fixnum_greaterp(*((C_word*)lf[28]+1),C_fix(0));
/* eval.scm: 814  compile */
t27=((C_word*)t17)[1];
f_3571(t27,t1,t2,t3,C_SCHEME_FALSE,t26,t7,t4);}

/* compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_6451(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6451,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6455,a[2]=t6,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 778  compile */
t9=((C_word*)((C_word*)t0)[2])[1];
f_3571(t9,t7,t8,t3,C_SCHEME_FALSE,t4,t5,t6);}

/* k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6455,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6425,tmp=(C_word)a,a+=2,tmp);
t4=f_6425(t2,C_fix(0));
t5=((C_word*)t0)[8];
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 783  ##sys#syntax-error-hook */
t6=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[7],lf[157],((C_word*)t0)[8]);
case C_fix(0):
t6=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6477,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
case C_fix(1):
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6496,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 787  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3571(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(2):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 791  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3571(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(3):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=t5,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 796  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3571(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(4):
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 802  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3571(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
default:
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6644,a[2]=t5,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6702,a[2]=t7,a[3]=t12,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp));
t14=((C_word*)t12)[1];
f_6702(t14,t10,t2);}}

/* loop1321 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_6702(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6702,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6729,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6736,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g13371338 */
t6=t3;
f_6729(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6734 in loop1321 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6736,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13211334 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6702(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13211334 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6702(t6,((C_word*)t0)[3],t5);}}

/* g1337 in loop1321 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_6729(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6729,NULL,3,t0,t1,t2);}
/* eval.scm: 809  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3571(t3,t1,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6642 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6644,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp));}

/* f_6645 in k6642 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6645,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6649,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
if(C_truep(t4)){
t6=(C_word)C_emit_eval_trace_info(((C_word*)t0)[2],t5,*((C_word*)lf[153]+1));
t7=t3;
f_6649(t7,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t3;
f_6649(t7,t6);}}

/* k6647 */
static void C_fcall f_6649(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6649,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6656,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6654 in k6647 */
static void C_ccall f_6656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6656,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6660,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6662,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_6662(t10,t6,((C_word*)t0)[2]);}

/* loop1346 in k6654 in k6647 */
static void C_fcall f_6662(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6662,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6689,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6696,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g13621363 */
t6=t3;
f_6689(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6694 in loop1346 in k6654 in k6647 */
static void C_ccall f_6696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6696,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13461359 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6662(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13461359 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6662(t6,((C_word*)t0)[3],t5);}}

/* g1362 in loop1346 in k6654 in k6647 */
static void C_fcall f_6689(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6689,NULL,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k6658 in k6654 in k6647 */
static void C_ccall f_6660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6599 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 803  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3571(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6602 in k6599 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 804  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3571(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6605 in k6602 in k6599 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6610,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=t1,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 805  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3571(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(3)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6608 in k6605 in k6602 in k6599 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6610,2,t0,t1);}
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp));}

/* f_6611 in k6608 in k6605 in k6602 in k6599 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6611,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6615,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
if(C_truep(t4)){
t6=(C_word)C_emit_eval_trace_info(((C_word*)t0)[2],t5,*((C_word*)lf[153]+1));
t7=t3;
f_6615(t7,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t3;
f_6615(t7,t6);}}

/* k6613 */
static void C_fcall f_6615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6615,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k6616 in k6613 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k6623 in k6616 in k6613 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6627 in k6623 in k6616 in k6613 */
static void C_ccall f_6629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6633,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6631 in k6627 in k6623 in k6616 in k6613 */
static void C_ccall f_6633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6637,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6635 in k6631 in k6627 in k6623 in k6616 in k6613 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g13151316 */
t2=((C_word*)t0)[6];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6557 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 797  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3571(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k6560 in k6557 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 798  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3571(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k6563 in k6560 in k6557 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_6566 in k6563 in k6560 in k6557 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6566(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6566,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6570,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
if(C_truep(t4)){
t6=(C_word)C_emit_eval_trace_info(((C_word*)t0)[2],t5,*((C_word*)lf[153]+1));
t7=t3;
f_6570(t7,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t3;
f_6570(t7,t6);}}

/* k6568 */
static void C_fcall f_6570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6570,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6573,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k6571 in k6568 */
static void C_ccall f_6573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6580,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6578 in k6571 in k6568 */
static void C_ccall f_6580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6582 in k6578 in k6571 in k6568 */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6588,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6586 in k6582 in k6578 in k6571 in k6568 */
static void C_ccall f_6588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g13061307 */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6522 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6527,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 792  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3571(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6525 in k6522 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6527,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp));}

/* f_6528 in k6525 in k6522 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6528(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6528,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6532,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
if(C_truep(t4)){
t6=(C_word)C_emit_eval_trace_info(((C_word*)t0)[2],t5,*((C_word*)lf[153]+1));
t7=t3;
f_6532(t7,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t3;
f_6532(t7,t6);}}

/* k6530 */
static void C_fcall f_6532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6532,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6535,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6533 in k6530 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6542,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6540 in k6533 in k6530 */
static void C_ccall f_6542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6546,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6544 in k6540 in k6533 in k6530 */
static void C_ccall f_6546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g12981299 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6494 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_6497 in k6494 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6497,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6501,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
if(C_truep(t4)){
t6=(C_word)C_emit_eval_trace_info(((C_word*)t0)[2],t5,*((C_word*)lf[153]+1));
t7=t3;
f_6501(t7,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t3;
f_6501(t7,t6);}}

/* k6499 */
static void C_fcall f_6501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6501,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6504,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6502 in k6499 */
static void C_ccall f_6504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6511,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6509 in k6502 in k6499 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g12911292 */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_6477 in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6477,3,t0,t1,t2);}
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
if(C_truep(t3)){
t5=(C_word)C_emit_eval_trace_info(((C_word*)t0)[3],t4,*((C_word*)lf[153]+1));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11716,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 786  fn */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f11720,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 786  fn */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}

/* f11720 */
static void C_ccall f11720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g12861287 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f11716 */
static void C_ccall f11716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g12861287 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in k6453 in compile-call in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static C_word C_fcall f_6425(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
return(t3);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_3571(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3571,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t7,a[12]=t3,a[13]=((C_word*)t0)[8],a[14]=t1,a[15]=t2,tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 293  keyword? */
t9=*((C_word*)lf[156]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3578,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3579,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[15]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3591,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[13],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3597,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[14],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* eval.scm: 319  ##sys#number? */
t3=*((C_word*)lf[155]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[15]);}}}

/* k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3698,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[14];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3705,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3713,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);
case C_fix(1):
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3721,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3729,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);
default:
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[14]))){
if(C_truep(((C_word*)t0)[14])){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3742,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3744,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t2=(C_word)C_charp(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t2)){
t4=t3;
f_3754(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[14]);
t5=t3;
f_3754(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[14])));}}}}

/* k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_3754(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3754,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[14]))){
t2=(C_word)C_slot(((C_word*)t0)[14],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t4=((C_word*)t0)[8];
t5=((C_word*)t0)[14];
t6=((C_word*)t0)[7];
if(C_truep(t4)){
t7=(C_word)C_emit_syntax_trace_info(t5,t6,*((C_word*)lf[153]+1));
t8=t3;
f_3774(t8,t7);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t3;
f_3774(t8,t7);}}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[7];
if(C_truep(t3)){
t6=(C_word)C_emit_syntax_trace_info(t4,t5,*((C_word*)lf[153]+1));
/* eval.scm: 755  compile-call */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6451(t7,((C_word*)t0)[13],((C_word*)t0)[14],((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[12]);}
else{
/* eval.scm: 755  compile-call */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6451(t6,((C_word*)t0)[13],((C_word*)t0)[14],((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[12]);}}}
else{
/* eval.scm: 334  ##sys#syntax-error-hook */
t2=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[13],lf[154],((C_word*)t0)[14]);}}}

/* k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_3774(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3774,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* eval.scm: 337  ##sys#expand */
t3=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[14],((C_word*)t0)[12],C_SCHEME_FALSE);}

/* k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3777,2,t0,t1);}
t2=*((C_word*)lf[35]+1);
t3=(C_word)C_eqp(t1,((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t5=(C_word)C_slot(((C_word*)t0)[14],C_fix(0));
/* eval.scm: 341  rename */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3398(t6,t4,t5,((C_word*)t0)[12]);}
else{
/* eval.scm: 340  compile */
t4=((C_word*)((C_word*)t0)[11])[1];
f_3571(t4,((C_word*)t0)[13],t1,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[12]);}}

/* k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3792,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[48]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3801,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 347  ##sys#check-syntax */
t4=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t3,lf[48],((C_word*)t0)[13],lf[51],C_SCHEME_FALSE,((C_word*)t0)[12]);}
else{
t3=(C_word)C_eqp(t1,lf[52]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[53]));
if(C_truep(t4)){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
t6=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3879,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t5=(C_word)C_eqp(t1,lf[54]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
if(C_truep(*((C_word*)lf[19]+1))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 366  ##sys#hash-table-location */
t8=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,*((C_word*)lf[19]+1),t6,C_SCHEME_TRUE);}
else{
t7=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3901,a[2]=t6,tmp=(C_word)a,a+=3,tmp));}}
else{
t6=(C_word)C_eqp(t1,lf[55]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 371  compile */
t8=((C_word*)((C_word*)t0)[11])[1];
f_3571(t8,((C_word*)t0)[14],t7,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[12]);}
else{
t7=(C_word)C_eqp(t1,lf[56]);
if(C_truep(t7)){
t8=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 374  compile */
t9=((C_word*)((C_word*)t0)[11])[1];
f_3571(t9,((C_word*)t0)[14],t8,((C_word*)t0)[10],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[12]);}
else{
t8=(C_word)C_eqp(t1,lf[57]);
if(C_truep(t8)){
t9=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3935,tmp=(C_word)a,a+=2,tmp));}
else{
t9=(C_word)C_eqp(t1,lf[58]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 379  ##sys#check-syntax */
t11=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t11+1)))(7,t11,t10,lf[58],((C_word*)t0)[13],lf[60],C_SCHEME_FALSE,((C_word*)t0)[12]);}
else{
t10=(C_word)C_eqp(t1,lf[61]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t1,lf[62]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 388  ##sys#check-syntax */
t13=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t13+1)))(7,t13,t12,lf[61],((C_word*)t0)[13],lf[65],C_SCHEME_FALSE,((C_word*)t0)[12]);}
else{
t12=(C_word)C_eqp(t1,lf[66]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t1,lf[67]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4117,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 404  ##sys#check-syntax */
t15=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t15+1)))(7,t15,t14,lf[66],((C_word*)t0)[13],lf[70],C_SCHEME_FALSE,((C_word*)t0)[12]);}
else{
t14=(C_word)C_eqp(t1,lf[71]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t1,lf[72]));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4229,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 428  ##sys#check-syntax */
t17=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t17+1)))(7,t17,t16,lf[71],((C_word*)t0)[13],lf[78],C_SCHEME_FALSE,((C_word*)t0)[12]);}
else{
t16=(C_word)C_eqp(t1,lf[79]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t1,lf[80]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4726,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[13],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 480  ##sys#check-syntax */
t19=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t18,lf[79],((C_word*)t0)[13],lf[82]);}
else{
t18=(C_word)C_eqp(t1,lf[83]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(t1,lf[84]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 495  ##sys#check-syntax */
t21=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t21+1)))(7,t21,t20,lf[83],((C_word*)t0)[13],lf[92],C_SCHEME_FALSE,((C_word*)t0)[12]);}
else{
t20=(C_word)C_eqp(t1,lf[93]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5331,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 590  ##sys#check-syntax */
t22=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t22+1)))(7,t22,t21,lf[93],((C_word*)t0)[13],lf[95],C_SCHEME_FALSE,((C_word*)t0)[12]);}
else{
t21=(C_word)C_eqp(t1,lf[96]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5418,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 605  ##sys#check-syntax */
t23=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t23+1)))(7,t23,t22,lf[96],((C_word*)t0)[13],lf[97],C_SCHEME_FALSE,((C_word*)t0)[12]);}
else{
t22=(C_word)C_eqp(t1,lf[98]);
if(C_truep(t22)){
t23=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
t24=(C_word)C_u_i_caddr(((C_word*)t0)[13]);
t25=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5545,a[2]=t24,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 625  rename */
t26=((C_word*)((C_word*)t0)[4])[1];
f_3398(t26,t25,t23,((C_word*)t0)[12]);}
else{
t23=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t23)){
/* eval.scm: 636  compile */
t24=((C_word*)((C_word*)t0)[11])[1];
f_3571(t24,((C_word*)t0)[14],lf[104],((C_word*)t0)[10],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[12]);}
else{
t24=(C_word)C_eqp(t1,lf[105]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5592,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t26=(C_word)C_u_i_cddr(((C_word*)t0)[13]);
/* eval.scm: 640  ##sys#canonicalize-body */
t27=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t27+1)))(5,t27,t25,t26,((C_word*)t0)[12],C_SCHEME_FALSE);}
else{
t25=(C_word)C_eqp(t1,lf[106]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5605,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
t27=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 644  ##sys#strip-syntax */
t28=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t28+1)))(3,t28,t26,t27);}
else{
t26=(C_word)C_eqp(t1,lf[113]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 689  rename */
t28=((C_word*)((C_word*)t0)[4])[1];
f_3398(t28,t27,lf[83],((C_word*)t0)[12]);}
else{
t27=(C_word)C_eqp(t1,lf[114]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5891,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 692  rename */
t29=((C_word*)((C_word*)t0)[4])[1];
f_3398(t29,t28,lf[83],((C_word*)t0)[12]);}
else{
t28=(C_word)C_eqp(t1,lf[115]);
if(C_truep(t28)){
t29=C_SCHEME_END_OF_LIST;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_FALSE;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5908,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_set_block_item(t36,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5985,a[2]=t30,a[3]=t36,a[4]=t32,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t38=((C_word*)t36)[1];
f_5985(t38,t33,t34);}
else{
t29=(C_word)C_eqp(t1,lf[119]);
if(C_truep(t29)){
t30=(C_word)C_u_i_caddr(((C_word*)t0)[13]);
t31=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6039,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6043,a[2]=t31,a[3]=t30,tmp=(C_word)a,a+=4,tmp);
t33=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 709  ##sys#strip-syntax */
t34=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t34+1)))(3,t34,t32,t33);}
else{
t30=(C_word)C_eqp(t1,lf[122]);
t31=(C_truep(t30)?t30:(C_word)C_eqp(t1,lf[123]));
if(C_truep(t31)){
t32=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6103,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t33=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 719  eval/meta */
f_3520(t32,t33);}
else{
t32=(C_word)C_eqp(t1,lf[125]);
if(C_truep(t32)){
t33=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 723  compile */
t34=((C_word*)((C_word*)t0)[11])[1];
f_3571(t34,((C_word*)t0)[14],t33,((C_word*)t0)[10],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[12]);}
else{
t33=(C_word)C_eqp(t1,lf[126]);
t34=(C_truep(t33)?t33:(C_word)C_eqp(t1,lf[127]));
if(C_truep(t34)){
/* eval.scm: 726  compile */
t35=((C_word*)((C_word*)t0)[11])[1];
f_3571(t35,((C_word*)t0)[14],lf[128],((C_word*)t0)[10],C_SCHEME_FALSE,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[12]);}
else{
t35=(C_word)C_eqp(t1,lf[129]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6144,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_u_i_memq(lf[131],*((C_word*)lf[132]+1)))){
t37=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6159,a[2]=t39,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp));
t41=((C_word*)t39)[1];
f_6159(t41,t36,t37);}
else{
/* eval.scm: 731  ##sys#warn */
t37=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t37+1)))(4,t37,t36,lf[135],((C_word*)t0)[13]);}}
else{
t36=(C_word)C_eqp(t1,lf[136]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t1,lf[137]));
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6208,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 735  rename */
t39=((C_word*)((C_word*)t0)[4])[1];
f_3398(t39,t38,lf[138],((C_word*)t0)[12]);}
else{
t38=(C_word)C_eqp(t1,lf[46]);
t39=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6225,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t38)){
t40=t39;
f_6225(t40,t38);}
else{
t40=(C_word)C_eqp(t1,lf[143]);
if(C_truep(t40)){
t41=t39;
f_6225(t41,t40);}
else{
t41=(C_word)C_eqp(t1,lf[144]);
if(C_truep(t41)){
t42=t39;
f_6225(t42,t41);}
else{
t42=(C_word)C_eqp(t1,lf[145]);
if(C_truep(t42)){
t43=t39;
f_6225(t43,t42);}
else{
t43=(C_word)C_eqp(t1,lf[146]);
if(C_truep(t43)){
t44=t39;
f_6225(t44,t43);}
else{
t44=(C_word)C_eqp(t1,lf[147]);
if(C_truep(t44)){
t45=t39;
f_6225(t45,t44);}
else{
t45=(C_word)C_eqp(t1,lf[148]);
if(C_truep(t45)){
t46=t39;
f_6225(t46,t45);}
else{
t46=(C_word)C_eqp(t1,lf[149]);
if(C_truep(t46)){
t47=t39;
f_6225(t47,t46);}
else{
t47=(C_word)C_eqp(t1,lf[150]);
t48=t39;
f_6225(t48,(C_truep(t47)?t47:(C_word)C_eqp(t1,lf[151])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k6223 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_6225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 742  ##sys#syntax-error-hook */
t2=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[9],lf[139],((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[140]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* eval.scm: 745  compile-call */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6451(t4,((C_word*)t0)[9],t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[141]);
if(C_truep(t3)){
/* eval.scm: 749  ##sys#syntax-error-hook */
t4=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[9],lf[142],((C_word*)t0)[8]);}
else{
/* eval.scm: 751  compile-call */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6451(t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k6206 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* ##sys#append */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6210 in k6206 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6212,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* eval.scm: 735  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3571(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1171 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_6159(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6159,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6167,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6174,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g11781179 */
t6=t3;
f_6167(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6172 in loop1171 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6159(t3,((C_word*)t0)[2],t2);}

/* g1178 in loop1171 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_6167(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6167,NULL,3,t0,t1,t2);}
/* eval.scm: 730  ##compiler#process-declaration */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k6142 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 732  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3571(t2,((C_word*)t0)[6],lf[130],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6101 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 720  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3571(t2,((C_word*)t0)[6],lf[124],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6041 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6043,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6045,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6045(t5,((C_word*)t0)[2],t1);}

/* loop in k6041 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_6045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6045,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[120]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6057,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6067,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}}

/* a6066 in loop in k6041 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6067,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6083,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 715  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6045(t6,t4,t5);}

/* k6081 in a6066 in loop in k6041 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6083,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[62],t3));}

/* a6056 in loop in k6041 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6057,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* eval.scm: 713  ##sys#do-the-right-thing */
t3=*((C_word*)lf[121]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6037 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 708  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3571(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1084 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5985,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6012,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6019,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g11001101 */
t6=t3;
f_6012(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6017 in loop1084 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_6019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6019,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10841097 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5985(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10841097 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5985(t6,((C_word*)t0)[3],t5);}}

/* g1100 in loop1084 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_6012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6012,NULL,3,t0,t1,t2);}
/* eval.scm: 696  eval/meta */
f_3520(t1,t2);}

/* k5906 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5911,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,*((C_word*)lf[117]+1),t1);}

/* k5909 in k5906 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 699  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5912 in k5909 in k5906 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5914,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* eval.scm: 700  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3571(t2,((C_word*)t0)[6],lf[116],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5935,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5937,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5937(t11,t7,t1);}}

/* loop1113 in k5912 in k5909 in k5906 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5937(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5937,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[48],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop11131126 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop11131126 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5933 in k5912 in k5909 in k5906 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5929 in k5912 in k5909 in k5906 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5931,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[117],t1);
/* eval.scm: 700  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3571(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5889 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5893 in k5889 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5895,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* eval.scm: 692  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3571(t4,((C_word*)t0)[6],t2,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5860 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* ##sys#append */
t4=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5864 in k5860 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* eval.scm: 689  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3571(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5605,2,t0,t1);}
t2=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5611,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_5611(2,t5,t3);}
else{
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5749,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 659  ##sys#strip-syntax */
t11=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}}

/* k5747 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5749,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5751,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5751(t5,((C_word*)t0)[2],t1);}

/* loop978 in k5747 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5751,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5778,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5829,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g994995 */
t6=t3;
f_5778(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5827 in loop978 in k5747 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5829,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop978991 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5751(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop978991 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5751(t6,((C_word*)t0)[3],t5);}}

/* g994 in loop978 in k5747 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5778(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5778,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5791,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5802,tmp=(C_word)a,a+=2,tmp);
t5=t3;
f_5791(t5,f_5802(t2));}
else{
t4=t3;
f_5791(t4,C_SCHEME_FALSE);}}}

/* loop in g994 in loop978 in k5747 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static C_word C_fcall f_5802(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_u_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k5789 in g994 in loop978 in k5747 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5791(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* eval.scm: 656  ##sys#syntax-error-hook */
t2=*((C_word*)lf[43]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[110],lf[112],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5614,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5739,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 660  ##sys#current-module */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5737 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 661  ##sys#syntax-error-hook */
t2=*((C_word*)lf[43]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[110],lf[111],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5614(2,t2,C_SCHEME_UNDEFINED);}}

/* k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5614,2,t0,t1);}
t2=*((C_word*)lf[36]+1);
t3=*((C_word*)lf[101]+1);
t4=*((C_word*)lf[37]+1);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=t3,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 663  ##sys#register-module */
t6=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5617,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[107]+1);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5618,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t8,t9,t8);}

/* a5644 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5645,2,t0,t1);}
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5655(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in a5644 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5655(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5655,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5665,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 668  reverse */
t5=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5728,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 685  ##sys#current-environment */
t8=*((C_word*)lf[101]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k5734 in loop in a5644 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 682  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3571(t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5726 in loop in a5644 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5728,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 680  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5655(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5663 in loop in a5644 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5668,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5713,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 669  ##sys#current-module */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5711 in k5663 in loop in a5644 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 669  ##sys#finalize-module */
t2=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5666 in k5663 in loop in a5644 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5669,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_5669 in k5666 in k5663 in loop in a5644 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5669,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5675,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5675(t6,t1,((C_word*)t0)[2]);}

/* loop2 */
static void C_fcall f_5675(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5675,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[35]+1));}
else{
t3=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5700,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* g10641065 */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
/* g10671068 */
t5=t4;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[2]);}}}

/* k5698 in loop2 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 677  loop2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5675(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* swap1020 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* g102310241035 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5620 in swap1020 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g102310241035 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k5623 in k5620 in swap1020 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5625,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g102510261036 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5627 in k5623 in k5620 in swap1020 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g102510261036 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k5630 in k5627 in k5623 in k5620 in swap1020 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g102710281037 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5634 in k5630 in k5627 in k5623 in k5620 in swap1020 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g102710281037 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k5637 in k5634 in k5630 in k5627 in k5623 in k5620 in swap1020 in k5615 in k5612 in k5609 in k5603 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5590 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 639  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3571(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5543 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5570,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 627  ##sys#current-module */
t4=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5568 in k5543 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 626  ##sys#register-syntax-export */
t2=*((C_word*)lf[102]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5546 in k5543 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5551,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 631  ##sys#current-environment */
t4=*((C_word*)lf[101]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5556 in k5546 in k5543 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5562,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5566,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 632  eval/meta */
f_3520(t3,((C_word*)t0)[2]);}

/* k5564 in k5556 in k5546 in k5543 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 632  ##sys#er-transformer */
t2=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5560 in k5556 in k5546 in k5543 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 629  ##sys#extend-macro-environment */
t2=*((C_word*)lf[100]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5549 in k5546 in k5543 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 633  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3571(t2,((C_word*)t0)[6],lf[99],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5418,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5476,a[2]=t3,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_5476(t11,t6,t7);}

/* loop923 in k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5476(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5476,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5526,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g939940 */
t6=t3;
f_5503(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5524 in loop923 in k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5526,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop923936 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5476(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop923936 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5476(t6,((C_word*)t0)[3],t5);}}

/* g939 in loop923 in k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5503(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5503,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5515,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5519,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(t2);
/* eval.scm: 611  eval/meta */
f_3520(t5,t6);}

/* k5517 in g939 in loop923 in k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 610  ##sys#er-transformer */
t2=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5513 in g939 in loop923 in k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k5419 in k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5424,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 613  append */
t3=*((C_word*)lf[75]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5422 in k5419 in k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5427,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5440,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5440(t6,t2,((C_word*)t0)[2]);}

/* loop948 in k5422 in k5419 in k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5440(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5440,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5448,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_5448(t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g955 in loop948 in k5422 in k5419 in k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static C_word C_fcall f_5448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_slot(t1,C_fix(1));
return((C_word)C_i_setslot(t2,C_fix(0),((C_word*)t0)[2]));}

/* k5425 in k5422 in k5419 in k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5434,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 619  ##sys#canonicalize-body */
t4=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[3],C_SCHEME_FALSE);}

/* k5432 in k5425 in k5422 in k5419 in k5416 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 618  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3571(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5329 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5334,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5349,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5355,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_5355(t12,t7,t8);}

/* loop896 in k5329 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5355(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5355,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5382,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5405,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g912913 */
t6=t3;
f_5382(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5403 in loop896 in k5329 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5405,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop896909 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5355(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop896909 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5355(t6,((C_word*)t0)[3],t5);}}

/* g912 in loop896 in k5329 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5382(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5382,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5394,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5398,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(t2);
/* eval.scm: 597  eval/meta */
f_3520(t5,t6);}

/* k5396 in g912 in loop896 in k5329 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 596  ##sys#er-transformer */
t2=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5392 in g912 in loop896 in k5329 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5394,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5347 in k5329 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 591  append */
t2=*((C_word*)lf[75]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5332 in k5329 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5341,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 601  ##sys#canonicalize-body */
t4=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,t1,C_SCHEME_FALSE);}

/* k5339 in k5332 in k5329 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 600  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3571(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4883,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[7]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[6];
t9=(C_truep(t8)?(C_word)C_a_i_cons(&a,2,t8,((C_word*)t4)[1]):(C_word)C_a_i_cons(&a,2,lf[85],((C_word*)t4)[1]));
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4895,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t9,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5304,a[2]=t10,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 499  ##sys#extended-lambda-list? */
t12=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t4)[1]);}

/* k5302 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5304,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5315,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4895(2,t2,C_SCHEME_UNDEFINED);}}

/* a5314 in k5302 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5315(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5315,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a5308 in k5302 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5309,2,t0,t1);}
/* eval.scm: 502  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[90]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[43]+1),((C_word*)t0)[2]);}

/* k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4900,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 504  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[89]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4900,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4904,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t1,a[10]=t3,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5268,a[2]=t6,a[3]=t11,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_5268(t13,t9,t2);}

/* loop790 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5268(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5268,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[77]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5297,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g806807 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5295 in loop790 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5297,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop790803 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5268(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop790803 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5268(t6,((C_word*)t0)[3],t5);}}

/* k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5217,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5219,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5219(t11,t7,((C_word*)t0)[2],t1);}

/* loop814 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5219(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5219,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[76]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5252,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* g834835 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k5250 in loop814 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5252,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_5232(t4,(C_word)C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_5232(t5,t4);}}

/* k5230 in k5250 in loop814 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_5232(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* loop814828 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5219(t5,((C_word*)t0)[2],t3,t4);}

/* k5215 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 508  append */
t2=*((C_word*)lf[75]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4907,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5209,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 512  ##sys#canonicalize-body */
t5=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[2])[1],t1,C_SCHEME_FALSE);}

/* k5207 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[6];
if(C_truep(t2)){
/* eval.scm: 511  ##sys#compile-to-closure */
t3=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],t2);}
else{
t3=((C_word*)t0)[2];
/* eval.scm: 511  ##sys#compile-to-closure */
t4=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],t3);}}

/* k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
t2=((C_word*)t0)[7];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[5])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp)));
case C_fix(1):
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
case C_fix(2):
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[5])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp)));
case C_fix(3):
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[5])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp)):(C_truep(((C_word*)t0)[5])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp))));}}

/* f_5171 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5171,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5177,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a5176 */
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5177r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5177r(t0,t1,t2);}}

static void C_ccall f_5177r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5201,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,*((C_word*)lf[86]+1),t2);}
else{
/* eval.scm: 585  ##sys#error */
t5=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[88],((C_word*)t0)[4],t3);}}

/* k5199 in a5176 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5201,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5148 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5148,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5154,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a5153 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr2r,(void*)f_5154r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5154r(t0,t1,t2);}}

static void C_ccall f_5154r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5166,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5170,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_a_i_list(&a,1,t2);
C_apply(4,0,t3,*((C_word*)lf[86]+1),t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6379,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6379(t9,t4,t5,C_fix(0),t2,C_SCHEME_FALSE);}}

/* doloop1249 in a5153 */
static void C_fcall f_6379(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6379,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,1,t4);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6408,a[2]=t4,a[3]=t8,a[4]=t7,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t10=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t10)){
/* eval.scm: 764  ##sys#error */
t11=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t9,lf[87],t2,t3);}
else{
t11=(C_word)C_slot(t4,C_fix(1));
t15=t1;
t16=t7;
t17=t8;
t18=t11;
t19=t4;
t1=t15;
t2=t16;
t3=t17;
t4=t18;
t5=t19;
goto loop;}}}

/* k6406 in doloop1249 in a5153 */
static void C_ccall f_6408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[6])[1];
f_6379(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5168 in a5153 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[86]+1),t1);}

/* k5164 in a5153 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5166,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5126 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5126,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5132,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a5131 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5132,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5144,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 569  ##sys#vector */
t7=*((C_word*)lf[86]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k5142 in a5131 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5144,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5107 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5107,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5113,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a5112 */
static void C_ccall f_5113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_5113r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5113r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5113r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_5079 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5079,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5085,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a5084 */
static void C_ccall f_5085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5085,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5060 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5060,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5066,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a5065 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5066r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5066r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5066r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_5032 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5032,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5038,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a5037 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5038,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5013 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5013,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5019,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a5018 */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5019r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5019r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5019r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_4985 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4985,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a4990 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4991,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_4966 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4966,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4972,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a4971 */
static void C_ccall f_4972(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_4972r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4972r(t0,t1,t2,t3);}}

static void C_ccall f_4972r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_4942 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4942,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4948,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a4947 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4948,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_4923 in k4911 in k4905 in k4902 in a4899 in k4893 in k4881 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4923,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
/* eval.scm: 274  ##sys#eval-decorator */
t6=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t3,((C_word*)t0)[2],t4,t5);}

/* a4928 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4929r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4929r(t0,t1,t2);}}

static void C_ccall f_4929r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4724 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4726,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4747,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4829,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_4829(t12,t8,t2);}

/* loop710 in k4724 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_4829(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4829,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_a_i_list(&a,2,t4,lf[81]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop710723 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop710723 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4745 in k4724 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4751,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4773,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_4773(t11,t7,((C_word*)t0)[2]);}

/* loop734 in k4745 in k4724 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_4773(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4773,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_u_i_cadr(t3);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t4,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[67],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t10=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t9);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t12=(C_word)C_slot(t2,C_fix(1));
/* loop734747 */
t18=t1;
t19=t12;
t1=t18;
t2=t19;
goto loop;}
else{
t10=C_mutate(((C_word *)((C_word*)t0)[2])+1,t9);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t12=(C_word)C_slot(t2,C_fix(1));
/* loop734747 */
t18=t1;
t19=t12;
t1=t18;
t2=t19;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4753 in k4745 in k4724 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4771,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4769 in k4753 in k4745 in k4724 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4771,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[72],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t5=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k4749 in k4745 in k4724 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4751,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[72],t2);
/* eval.scm: 483  compile */
t4=((C_word*)((C_word*)t0)[8])[1];
f_3571(t4,((C_word*)t0)[7],t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4229,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_length(t2);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4238,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4676,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_4676(t12,t8,t2);}

/* loop561 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_4676(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4676,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=(C_word)C_slot(t2,C_fix(1));
/* loop561574 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=(C_word)C_slot(t2,C_fix(1));
/* loop561574 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4238,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4641,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_4641(t10,t6,t1);}

/* loop586 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_4641(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4641,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[77]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g602603 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4668 in loop586 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4670,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop586599 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4641(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop586599 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4641(t6,((C_word*)t0)[3],t5);}}

/* k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[31],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4241,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4247,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4590,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4592,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_4592(t12,t8,((C_word*)t0)[7],t1);}

/* loop611 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_4592(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4592,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[76]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4625,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* g631632 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4623 in loop611 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4625,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_4605(t4,(C_word)C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_4605(t5,t4);}}

/* k4603 in k4623 in loop611 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_4605(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* loop611625 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4592(t5,((C_word*)t0)[2],t3,t4);}

/* k4588 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 434  append */
t2=*((C_word*)lf[75]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4582,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 436  ##sys#canonicalize-body */
t5=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,t1,C_SCHEME_FALSE);}

/* k4580 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 435  ##sys#compile-to-closure */
t2=*((C_word*)lf[32]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4250,2,t0,t1);}
switch(((C_word*)t0)[10]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 441  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3571(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 444  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3571(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 448  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3571(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 456  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3571(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4485,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4532,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_4532(t10,t6,((C_word*)t0)[8]);}}

/* loop663 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_4532(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4532,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4574,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g679680 */
t6=t3;
f_4559(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4572 in loop663 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4574,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop663676 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4532(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop663676 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4532(t6,((C_word*)t0)[3],t5);}}

/* g679 in loop663 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_4559(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4559,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 470  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3571(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4483 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4485,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4486,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4486 in k4483 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4486,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 472  ##sys#make-vector */
t4=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4488 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4493,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4502(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* doloop687 in k4488 */
static void C_fcall f_4502(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4502,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4527,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4525 in doloop687 in k4488 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4502(t5,((C_word*)t0)[2],t3,t4);}

/* k4491 in k4488 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4407 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[10]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 457  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3571(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4410 in k4407 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4412,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 459  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3571(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4416 in k4410 in k4407 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4421,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[8]);
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 460  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3571(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4419 in k4416 in k4410 in k4407 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_4422 in k4419 in k4416 in k4410 in k4407 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4422,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4438,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4436 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4440 in k4436 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4444 in k4440 in k4436 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4448 in k4444 in k4440 in k4436 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4450,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4340 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[10]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 449  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3571(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4343 in k4340 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4345,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 451  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3571(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4349 in k4343 in k4340 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4352,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_4352 in k4349 in k4343 in k4340 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4352,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4368,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4366 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4372,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4370 in k4366 */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4374 in k4370 in k4366 */
static void C_ccall f_4376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4376,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4291 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4296,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[8]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 445  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3571(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4294 in k4291 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4297,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4297 in k4294 in k4291 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4297,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4311 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4315 in k4311 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4257 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4260,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_4260 in k4257 in k4248 in k4245 in k4239 in k4236 in k4227 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4260,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4276,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4274 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4276,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4117,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4125,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4131,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4130 in k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4131,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4135,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
/* eval.scm: 407  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3571(t6,t4,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4133 in a4130 in k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4135,2,t0,t1);}
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4192,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4205,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp)));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4144,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 409  ##sys#alias-global-hook */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_TRUE);}}

/* k4142 in k4133 in a4130 in k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4144,2,t0,t1);}
if(C_truep(*((C_word*)lf[19]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4150,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 411  ##sys#hash-table-location */
t3=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[19]+1),t1,*((C_word*)lf[20]+1));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}}

/* f_4177 in k4142 in k4133 in a4130 in k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4177,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4185,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4183 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4148 in k4142 in k4133 in a4130 in k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4153(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 415  ##sys#error */
t3=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[69],((C_word*)t0)[2]);}}

/* k4151 in k4148 in k4142 in k4133 in a4130 in k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4153,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)t0)[5],C_fix(2)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4160,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4169,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* f_4169 in k4151 in k4148 in k4142 in k4133 in a4130 in k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4169,2,t0,t1);}
/* eval.scm: 418  ##sys#error */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[68],((C_word*)t0)[2]);}

/* f_4160 in k4151 in k4148 in k4142 in k4133 in a4130 in k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4160,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4166 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4205 in k4133 in a4130 in k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4205,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4213,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4211 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4192 in k4133 in a4130 in k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4192,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4204,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4202 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4124 in k4115 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4125,2,t0,t1);}
/* eval.scm: 406  lookup */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3413(t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4003 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4005,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 392  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3571(t4,((C_word*)t0)[6],lf[63],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 393  compile */
t5=((C_word*)((C_word*)t0)[7])[1];
f_3571(t5,((C_word*)t0)[6],t4,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 394  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3571(t6,t4,t5,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4064,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 398  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3571(t6,t4,t5,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4062 in k4003 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* eval.scm: 399  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3571(t4,t2,t3,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k4065 in k4062 in k4003 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_slot(t4,C_fix(1));
/* ##sys#append */
t6=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,C_SCHEME_END_OF_LIST);}

/* k4087 in k4065 in k4062 in k4003 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4089,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[62],t1);
/* eval.scm: 400  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3571(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4068 in k4065 in k4062 in k4003 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_4071 in k4068 in k4065 in k4062 in k4003 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4071,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4075,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4073 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4078,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4076 in k4073 */
static void C_ccall f_4078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4040 in k4003 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4045,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 395  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3571(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4043 in k4040 in k4003 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4046,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_4046 in k4043 in k4040 in k4003 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4046,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4050,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4048 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3943 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 380  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3571(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3946 in k3943 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 381  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3571(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3949 in k3946 in k3943 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 383  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3571(t5,t2,t4,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* eval.scm: 384  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3571(t4,t2,lf[59],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3952 in k3949 in k3946 in k3943 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3955,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_3955 in k3952 in k3949 in k3946 in k3943 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3955,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3960 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_3935 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3935,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_3901 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3901(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3901,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k3893 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3895,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3896,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_3896 in k3893 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3896,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* f_3879 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3799 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3804,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* eval.scm: 348  ##sys#strip-syntax */
t4=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k3802 in k3799 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3804,2,t0,t1);}
switch(t1){
case C_fix(-1):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3811,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3819,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);
case C_fix(1):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3827,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3835,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);
case C_SCHEME_TRUE:
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3843,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_FALSE:
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3851,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);
default:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3859,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3861,a[2]=t1,tmp=(C_word)a,a+=3,tmp)));}}

/* f_3861 in k3802 in k3799 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3861(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3861,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3859 in k3802 in k3799 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3859,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_3851 in k3802 in k3799 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3851(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3851,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_3843 in k3802 in k3799 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_3835 in k3802 in k3799 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3835,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_3827 in k3802 in k3799 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3827(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3827,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_3819 in k3802 in k3799 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3819(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3819,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_3811 in k3802 in k3799 in k3790 in k3775 in k3772 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3811,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_3755 in k3752 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3755,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3744 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_3742 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_3731 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3729 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3729,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_3721 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3721,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_3713 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3713,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_3705 in k3696 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3705,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3597,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=t3,tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3688,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3607,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_u_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3665,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 299  ##sys#get */
t7=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[46]);}
else{
/* eval.scm: 298  ##sys#alias-global-hook */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_FALSE);}}}

/* k3663 in a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_3607(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
f_3607(2,t3,t2);}}

/* k3605 in a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
if(C_truep(*((C_word*)lf[19]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3613,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 301  ##sys#hash-table-location */
t3=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[19]+1),t1,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3641,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[27]+1))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3656,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 314  ##sys#symbol-has-toplevel-binding? */
t4=*((C_word*)lf[45]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}
else{
t3=t2;
f_3641(t3,C_SCHEME_FALSE);}}}

/* k3654 in k3605 in a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3641(t2,(C_word)C_i_not(t1));}

/* k3639 in k3605 in a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_3641(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3641,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,*((C_word*)lf[27]+1));
t4=C_mutate((C_word*)lf[27]+1 /* (set! unbound-in-eval ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f10591,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f10596,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp));}}

/* f10596 in k3639 in k3605 in a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f10596(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f10596,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* f10591 in k3639 in k3605 in a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f10591(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f10591,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k3611 in k3605 in a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3616(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 302  ##sys#syntax-error-hook */
t3=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[44],((C_word*)t0)[2]);}}

/* k3614 in k3611 in k3605 in a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3616,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));}

/* f_3617 in k3614 in k3611 in k3605 in a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3617(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3617,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 309  ##sys#error */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[42],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_3688 in a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3688,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_3679 in a3596 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3679,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a3590 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3591,2,t0,t1);}
/* eval.scm: 295  lookup */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3413(t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_3579 in k3576 in compile in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3579,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* eval/meta in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_3520(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3520,NULL,2,t1,t2);}
t3=*((C_word*)lf[36]+1);
t4=*((C_word*)lf[37]+1);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3524,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 278  ##sys#meta-macro-environment */
t8=*((C_word*)lf[40]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* k3522 in eval/meta in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3524,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3525,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3545,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#dynamic-wind */
t6=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[2],t4,t5,t4);}

/* a3544 in k3522 in eval/meta in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3549,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 282  ##sys#current-meta-environment */
t4=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3554 in a3544 in k3522 in eval/meta in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 279  ##sys#compile-to-closure */
t2=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* k3547 in a3544 in k3522 in eval/meta in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g371372 */
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* swap350 in k3522 in eval/meta in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* g353354361 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3527 in swap350 in k3522 in eval/meta in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g353354361 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k3530 in k3527 in swap350 in k3522 in eval/meta in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3532,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g355356362 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3534 in k3530 in k3527 in swap350 in k3522 in eval/meta in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3539,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g355356362 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3537 in k3534 in k3530 in k3527 in swap350 in k3522 in eval/meta in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* lookup in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_3413(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3413,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3417,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 252  rename */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3398(t6,t5,t2,t4);}

/* k3415 in lookup in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3417,2,t0,t1);}
t2=*((C_word*)lf[35]+1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3425,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3425(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* loop in k3415 in lookup in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_3425(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3425,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 255  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3472,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=f_3472(t6,t4,C_fix(0));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3442,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* g318319 */
t9=t8;
f_3442(t9,t1,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 257  loop */
t12=t1;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}}

/* g318 in loop in k3415 in lookup in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_3442(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3442,NULL,3,t0,t1,t2);}
/* eval.scm: 256  values */
C_values(4,0,t1,((C_word*)t0)[2],t2);}

/* loop in loop in k3415 in lookup in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static C_word C_fcall f_3472(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* rename in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_3398(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3398,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3402,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 247  find-id */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3359(t5,t4,t2,t3);}

/* k3400 in rename in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3402,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 248  ##sys#get */
t3=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[34]);}}

/* k3406 in k3400 in rename in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* find-id in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_3359(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3359,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3372,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caar(t3);
t6=(C_word)C_eqp(t2,t5);
if(C_truep(t6)){
t7=(C_word)C_u_i_cdar(t3);
t8=t4;
f_3372(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t4;
f_3372(t7,C_SCHEME_FALSE);}}}

/* k3370 in find-id in ##sys#compile-to-closure in k2989 in k2986 in k2953 */
static void C_fcall f_3372(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_cdar(((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 244  find-id */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3359(t3,((C_word*)t0)[5],((C_word*)t0)[2],t2);}}

/* ##sys#eval-decorator in k2989 in k2986 in k2953 */
static void C_ccall f_3309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3309,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3315,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3328,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 216  ##sys#decorate-lambda */
t8=*((C_word*)lf[26]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t6,t7);}

/* a3327 in ##sys#eval-decorator in k2989 in k2986 in k2953 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3328,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3336,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3340,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 223  open-output-string */
t6=*((C_word*)lf[25]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3338 in a3327 in ##sys#eval-decorator in k2989 in k2986 in k2953 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3343,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 224  write */
t3=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3341 in k3338 in a3327 in ##sys#eval-decorator in k2989 in k2986 in k2953 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 225  get-output-string */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3344 in k3341 in k3338 in a3327 in ##sys#eval-decorator in k2989 in k2986 in k2953 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 222  ##sys#make-lambda-info */
t2=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3334 in a3327 in ##sys#eval-decorator in k2989 in k2986 in k2953 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3314 in ##sys#eval-decorator in k2989 in k2986 in k2953 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3315,3,t0,t1,t2);}
if(C_truep((C_word)C_immp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_lambdainfop(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##sys#hash-table-location in k2989 in k2986 in k2953 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3249,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3253,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 196  ##sys#hash-symbol */
t7=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3251 in ##sys#hash-table-location in k2989 in k2986 in k2953 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3253,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3261,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3261(t6,((C_word*)t0)[2],t2);}

/* loop in k3251 in ##sys#hash-table-location in k2989 in k2986 in k2953 */
static void C_fcall f_3261(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3261,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 207  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-for-each in k2989 in k2986 in k2953 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3181,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3187,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3187(t8,t1,C_fix(0));}

/* doloop190 in ##sys#hash-table-for-each in k2989 in k2986 in k2953 */
static void C_fcall f_3187(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3187,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3197,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3210,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3210(t8,t3,t4);}}

/* loop197 in doloop190 in ##sys#hash-table-for-each in k2989 in k2986 in k2953 */
static void C_fcall f_3210(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3210,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3218,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3233,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g204205 */
t6=t3;
f_3218(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3231 in loop197 in doloop190 in ##sys#hash-table-for-each in k2989 in k2986 in k2953 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3210(t3,((C_word*)t0)[2],t2);}

/* g204 in loop197 in doloop190 in ##sys#hash-table-for-each in k2989 in k2986 in k2953 */
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3218,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 190  p */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3195 in doloop190 in ##sys#hash-table-for-each in k2989 in k2986 in k2953 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3187(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-update! in k2989 in k2986 in k2953 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3161,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3169,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3173,a[2]=t5,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 184  ##sys#hash-table-ref */
t8=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,t3);}

/* k3171 in ##sys#hash-table-update! in k2989 in k2986 in k2953 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t1;
/* eval.scm: 184  updtfunc */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[3],t3);}
else{
/* eval.scm: 184  valufunc */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3174 in k3171 in ##sys#hash-table-update! in k2989 in k2986 in k2953 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 184  updtfunc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3167 in ##sys#hash-table-update! in k2989 in k2986 in k2953 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 184  ##sys#hash-table-set! */
t2=*((C_word*)lf[14]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#hash-table-set! in k2989 in k2986 in k2953 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3101,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3105,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 174  ##sys#hash-symbol */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3103 in ##sys#hash-table-set! in k2989 in k2986 in k2953 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3105,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3113,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3113(t6,((C_word*)t0)[2],t2);}

/* loop in k3103 in ##sys#hash-table-set! in k2989 in k2986 in k2953 */
static void C_fcall f_3113(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3113,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(0));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t7,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 181  loop */
t12=t1;
t13=t7;
t1=t12;
t2=t13;
goto loop;}}}

/* ##sys#hash-table-ref in k2989 in k2986 in k2953 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3046,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3099,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 167  ##sys#hash-symbol */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3097 in ##sys#hash-table-ref in k2989 in k2986 in k2953 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3099,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3056(t3,t2));}

/* loop in k3097 in ##sys#hash-table-ref in k2989 in k2986 in k2953 */
static C_word C_fcall f_3056(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t1);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t1,C_fix(0));
return((C_word)C_slot(t6,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t9=t6;
t1=t9;
goto loop;}}}

/* ##sys#hash-symbol in k2989 in k2986 in k2953 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3031,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_hash_string(t6));
t8=(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* chicken-home in k2989 in k2986 in k2953 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3023,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 149  ##sys#chicken-prefix */
t3=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[11]);}

/* k3021 in chicken-home in k2989 in k2986 in k2953 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3023,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* ##sys#chicken-prefix in k2989 in k2986 in k2953 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2992r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2992r(t0,t1,t2);}}

static void C_ccall f_2992r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t4)){
/* eval.scm: 143  ##sys#string-append */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[2]);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[784] = {
{"toplevel:eval_scm",(void*)C_eval_toplevel},
{"f_2955:eval_scm",(void*)f_2955},
{"f_2988:eval_scm",(void*)f_2988},
{"f_2991:eval_scm",(void*)f_2991},
{"f_10468:eval_scm",(void*)f_10468},
{"f_10472:eval_scm",(void*)f_10472},
{"f_10497:eval_scm",(void*)f_10497},
{"f_10487:eval_scm",(void*)f_10487},
{"f_10495:eval_scm",(void*)f_10495},
{"f_10480:eval_scm",(void*)f_10480},
{"f_10475:eval_scm",(void*)f_10475},
{"f_6767:eval_scm",(void*)f_6767},
{"f_6862:eval_scm",(void*)f_6862},
{"f_6943:eval_scm",(void*)f_6943},
{"f_10462:eval_scm",(void*)f_10462},
{"f_10458:eval_scm",(void*)f_10458},
{"f_10454:eval_scm",(void*)f_10454},
{"f_10450:eval_scm",(void*)f_10450},
{"f_7493:eval_scm",(void*)f_7493},
{"f_7498:eval_scm",(void*)f_7498},
{"f_10422:eval_scm",(void*)f_10422},
{"f_10401:eval_scm",(void*)f_10401},
{"f_10408:eval_scm",(void*)f_10408},
{"f_7505:eval_scm",(void*)f_7505},
{"f_10365:eval_scm",(void*)f_10365},
{"f_10394:eval_scm",(void*)f_10394},
{"f_10357:eval_scm",(void*)f_10357},
{"f_10359:eval_scm",(void*)f_10359},
{"f_7514:eval_scm",(void*)f_7514},
{"f_10329:eval_scm",(void*)f_10329},
{"f_10349:eval_scm",(void*)f_10349},
{"f_10345:eval_scm",(void*)f_10345},
{"f_10335:eval_scm",(void*)f_10335},
{"f_7868:eval_scm",(void*)f_7868},
{"f_8890:eval_scm",(void*)f_8890},
{"f_10320:eval_scm",(void*)f_10320},
{"f_9241:eval_scm",(void*)f_9241},
{"f_9245:eval_scm",(void*)f_9245},
{"f_10316:eval_scm",(void*)f_10316},
{"f_9248:eval_scm",(void*)f_9248},
{"f_9252:eval_scm",(void*)f_9252},
{"f_9519:eval_scm",(void*)f_9519},
{"f_10308:eval_scm",(void*)f_10308},
{"f_9541:eval_scm",(void*)f_9541},
{"f_9926:eval_scm",(void*)f_9926},
{"f_10299:eval_scm",(void*)f_10299},
{"f_10306:eval_scm",(void*)f_10306},
{"f_10289:eval_scm",(void*)f_10289},
{"f_10274:eval_scm",(void*)f_10274},
{"f_10278:eval_scm",(void*)f_10278},
{"f_10283:eval_scm",(void*)f_10283},
{"f_10287:eval_scm",(void*)f_10287},
{"f_10252:eval_scm",(void*)f_10252},
{"f_10256:eval_scm",(void*)f_10256},
{"f_10261:eval_scm",(void*)f_10261},
{"f_10265:eval_scm",(void*)f_10265},
{"f_10272:eval_scm",(void*)f_10272},
{"f_10226:eval_scm",(void*)f_10226},
{"f_10232:eval_scm",(void*)f_10232},
{"f_10236:eval_scm",(void*)f_10236},
{"f_10250:eval_scm",(void*)f_10250},
{"f_10239:eval_scm",(void*)f_10239},
{"f_10246:eval_scm",(void*)f_10246},
{"f_10210:eval_scm",(void*)f_10210},
{"f_10216:eval_scm",(void*)f_10216},
{"f_10224:eval_scm",(void*)f_10224},
{"f_10173:eval_scm",(void*)f_10173},
{"f_10177:eval_scm",(void*)f_10177},
{"f_10182:eval_scm",(void*)f_10182},
{"f_10186:eval_scm",(void*)f_10186},
{"f_10208:eval_scm",(void*)f_10208},
{"f_10204:eval_scm",(void*)f_10204},
{"f_10200:eval_scm",(void*)f_10200},
{"f_10189:eval_scm",(void*)f_10189},
{"f_10196:eval_scm",(void*)f_10196},
{"f_10147:eval_scm",(void*)f_10147},
{"f_10153:eval_scm",(void*)f_10153},
{"f_10157:eval_scm",(void*)f_10157},
{"f_10171:eval_scm",(void*)f_10171},
{"f_10160:eval_scm",(void*)f_10160},
{"f_10167:eval_scm",(void*)f_10167},
{"f_10134:eval_scm",(void*)f_10134},
{"f_10108:eval_scm",(void*)f_10108},
{"f_10112:eval_scm",(void*)f_10112},
{"f_10117:eval_scm",(void*)f_10117},
{"f_10121:eval_scm",(void*)f_10121},
{"f_10132:eval_scm",(void*)f_10132},
{"f_10128:eval_scm",(void*)f_10128},
{"f_10092:eval_scm",(void*)f_10092},
{"f_10098:eval_scm",(void*)f_10098},
{"f_10106:eval_scm",(void*)f_10106},
{"f_10080:eval_scm",(void*)f_10080},
{"f_10086:eval_scm",(void*)f_10086},
{"f_10090:eval_scm",(void*)f_10090},
{"f_10071:eval_scm",(void*)f_10071},
{"f_10075:eval_scm",(void*)f_10075},
{"f_10012:eval_scm",(void*)f_10012},
{"f_10022:eval_scm",(void*)f_10022},
{"f_10047:eval_scm",(void*)f_10047},
{"f_10059:eval_scm",(void*)f_10059},
{"f_10065:eval_scm",(void*)f_10065},
{"f_10053:eval_scm",(void*)f_10053},
{"f_10028:eval_scm",(void*)f_10028},
{"f_10034:eval_scm",(void*)f_10034},
{"f_10038:eval_scm",(void*)f_10038},
{"f_10041:eval_scm",(void*)f_10041},
{"f_10045:eval_scm",(void*)f_10045},
{"f_10017:eval_scm",(void*)f_10017},
{"f_9937:eval_scm",(void*)f_9937},
{"f_9947:eval_scm",(void*)f_9947},
{"f_9950:eval_scm",(void*)f_9950},
{"f_9964:eval_scm",(void*)f_9964},
{"f_9982:eval_scm",(void*)f_9982},
{"f_9951:eval_scm",(void*)f_9951},
{"f_9928:eval_scm",(void*)f_9928},
{"f_9562:eval_scm",(void*)f_9562},
{"f_9606:eval_scm",(void*)f_9606},
{"f_9609:eval_scm",(void*)f_9609},
{"f_9911:eval_scm",(void*)f_9911},
{"f_9915:eval_scm",(void*)f_9915},
{"f_9919:eval_scm",(void*)f_9919},
{"f_9691:eval_scm",(void*)f_9691},
{"f_9697:eval_scm",(void*)f_9697},
{"f_9894:eval_scm",(void*)f_9894},
{"f_9900:eval_scm",(void*)f_9900},
{"f_9704:eval_scm",(void*)f_9704},
{"f_9707:eval_scm",(void*)f_9707},
{"f_9713:eval_scm",(void*)f_9713},
{"f_9892:eval_scm",(void*)f_9892},
{"f_9722:eval_scm",(void*)f_9722},
{"f_9725:eval_scm",(void*)f_9725},
{"f_9740:eval_scm",(void*)f_9740},
{"f_9758:eval_scm",(void*)f_9758},
{"f_9846:eval_scm",(void*)f_9846},
{"f_9774:eval_scm",(void*)f_9774},
{"f_9782:eval_scm",(void*)f_9782},
{"f_9794:eval_scm",(void*)f_9794},
{"f_9797:eval_scm",(void*)f_9797},
{"f_9809:eval_scm",(void*)f_9809},
{"f_9812:eval_scm",(void*)f_9812},
{"f_9800:eval_scm",(void*)f_9800},
{"f_9826:eval_scm",(void*)f_9826},
{"f_9777:eval_scm",(void*)f_9777},
{"f_9762:eval_scm",(void*)f_9762},
{"f_9744:eval_scm",(void*)f_9744},
{"f_9587:eval_scm",(void*)f_9587},
{"f_9592:eval_scm",(void*)f_9592},
{"f_9747:eval_scm",(void*)f_9747},
{"f_9731:eval_scm",(void*)f_9731},
{"f_9626:eval_scm",(void*)f_9626},
{"f_9631:eval_scm",(void*)f_9631},
{"f_9634:eval_scm",(void*)f_9634},
{"f_9639:eval_scm",(void*)f_9639},
{"f_9646:eval_scm",(void*)f_9646},
{"f_9686:eval_scm",(void*)f_9686},
{"f_9649:eval_scm",(void*)f_9649},
{"f_9661:eval_scm",(void*)f_9661},
{"f_9670:eval_scm",(void*)f_9670},
{"f_9664:eval_scm",(void*)f_9664},
{"f_9652:eval_scm",(void*)f_9652},
{"f_9655:eval_scm",(void*)f_9655},
{"f_9617:eval_scm",(void*)f_9617},
{"f_9611:eval_scm",(void*)f_9611},
{"f_9565:eval_scm",(void*)f_9565},
{"f_9571:eval_scm",(void*)f_9571},
{"f_9559:eval_scm",(void*)f_9559},
{"f_9543:eval_scm",(void*)f_9543},
{"f_9554:eval_scm",(void*)f_9554},
{"f_9557:eval_scm",(void*)f_9557},
{"f_9547:eval_scm",(void*)f_9547},
{"f_9524:eval_scm",(void*)f_9524},
{"f_9533:eval_scm",(void*)f_9533},
{"f_9528:eval_scm",(void*)f_9528},
{"f_9464:eval_scm",(void*)f_9464},
{"f_9468:eval_scm",(void*)f_9468},
{"f_9471:eval_scm",(void*)f_9471},
{"f_9474:eval_scm",(void*)f_9474},
{"f_9477:eval_scm",(void*)f_9477},
{"f_9480:eval_scm",(void*)f_9480},
{"f_9483:eval_scm",(void*)f_9483},
{"f_9486:eval_scm",(void*)f_9486},
{"f_9489:eval_scm",(void*)f_9489},
{"f_9492:eval_scm",(void*)f_9492},
{"f_9443:eval_scm",(void*)f_9443},
{"f_9447:eval_scm",(void*)f_9447},
{"f_9450:eval_scm",(void*)f_9450},
{"f_9419:eval_scm",(void*)f_9419},
{"f_9425:eval_scm",(void*)f_9425},
{"f_9435:eval_scm",(void*)f_9435},
{"f_9277:eval_scm",(void*)f_9277},
{"f_9348:eval_scm",(void*)f_9348},
{"f_9395:eval_scm",(void*)f_9395},
{"f_9405:eval_scm",(void*)f_9405},
{"f_9358:eval_scm",(void*)f_9358},
{"f_9360:eval_scm",(void*)f_9360},
{"f_9384:eval_scm",(void*)f_9384},
{"f_9370:eval_scm",(void*)f_9370},
{"f_9318:eval_scm",(void*)f_9318},
{"f_9283:eval_scm",(void*)f_9283},
{"f_9299:eval_scm",(void*)f_9299},
{"f_9305:eval_scm",(void*)f_9305},
{"f_9296:eval_scm",(void*)f_9296},
{"f_9258:eval_scm",(void*)f_9258},
{"f_9262:eval_scm",(void*)f_9262},
{"f_9225:eval_scm",(void*)f_9225},
{"f_9227:eval_scm",(void*)f_9227},
{"f_9231:eval_scm",(void*)f_9231},
{"f_9187:eval_scm",(void*)f_9187},
{"f_9194:eval_scm",(void*)f_9194},
{"f_9201:eval_scm",(void*)f_9201},
{"f_9143:eval_scm",(void*)f_9143},
{"f_9176:eval_scm",(void*)f_9176},
{"f_9163:eval_scm",(void*)f_9163},
{"f_9140:eval_scm",(void*)f_9140},
{"f_9021:eval_scm",(void*)f_9021},
{"f_9115:eval_scm",(void*)f_9115},
{"f_9125:eval_scm",(void*)f_9125},
{"f_9113:eval_scm",(void*)f_9113},
{"f_9042:eval_scm",(void*)f_9042},
{"f_9066:eval_scm",(void*)f_9066},
{"f_9085:eval_scm",(void*)f_9085},
{"f_9060:eval_scm",(void*)f_9060},
{"f_8913:eval_scm",(void*)f_8913},
{"f_8923:eval_scm",(void*)f_8923},
{"f_8928:eval_scm",(void*)f_8928},
{"f_8955:eval_scm",(void*)f_8955},
{"f_8984:eval_scm",(void*)f_8984},
{"f_8988:eval_scm",(void*)f_8988},
{"f_8949:eval_scm",(void*)f_8949},
{"f_8897:eval_scm",(void*)f_8897},
{"f_8834:eval_scm",(void*)f_8834},
{"f_8838:eval_scm",(void*)f_8838},
{"f_8846:eval_scm",(void*)f_8846},
{"f_8226:eval_scm",(void*)f_8226},
{"f_8650:eval_scm",(void*)f_8650},
{"f_8759:eval_scm",(void*)f_8759},
{"f_8768:eval_scm",(void*)f_8768},
{"f_8775:eval_scm",(void*)f_8775},
{"f_8766:eval_scm",(void*)f_8766},
{"f_8679:eval_scm",(void*)f_8679},
{"f_8746:eval_scm",(void*)f_8746},
{"f_8706:eval_scm",(void*)f_8706},
{"f_8710:eval_scm",(void*)f_8710},
{"f_8737:eval_scm",(void*)f_8737},
{"f_8733:eval_scm",(void*)f_8733},
{"f_8713:eval_scm",(void*)f_8713},
{"f_8724:eval_scm",(void*)f_8724},
{"f_8718:eval_scm",(void*)f_8718},
{"f_8673:eval_scm",(void*)f_8673},
{"f_8669:eval_scm",(void*)f_8669},
{"f_8295:eval_scm",(void*)f_8295},
{"f_8305:eval_scm",(void*)f_8305},
{"f_8467:eval_scm",(void*)f_8467},
{"f_8612:eval_scm",(void*)f_8612},
{"f_8619:eval_scm",(void*)f_8619},
{"f_8482:eval_scm",(void*)f_8482},
{"f_8501:eval_scm",(void*)f_8501},
{"f_8533:eval_scm",(void*)f_8533},
{"f_8527:eval_scm",(void*)f_8527},
{"f_8523:eval_scm",(void*)f_8523},
{"f_8505:eval_scm",(void*)f_8505},
{"f_8497:eval_scm",(void*)f_8497},
{"f_8489:eval_scm",(void*)f_8489},
{"f_8372:eval_scm",(void*)f_8372},
{"f_8393:eval_scm",(void*)f_8393},
{"f_8401:eval_scm",(void*)f_8401},
{"f_8389:eval_scm",(void*)f_8389},
{"f_8325:eval_scm",(void*)f_8325},
{"f_8312:eval_scm",(void*)f_8312},
{"f_8254:eval_scm",(void*)f_8254},
{"f_8273:eval_scm",(void*)f_8273},
{"f_8266:eval_scm",(void*)f_8266},
{"f_8229:eval_scm",(void*)f_8229},
{"f_8248:eval_scm",(void*)f_8248},
{"f_8242:eval_scm",(void*)f_8242},
{"f_8177:eval_scm",(void*)f_8177},
{"f_8183:eval_scm",(void*)f_8183},
{"f_8197:eval_scm",(void*)f_8197},
{"f_8200:eval_scm",(void*)f_8200},
{"f_8207:eval_scm",(void*)f_8207},
{"f_8171:eval_scm",(void*)f_8171},
{"f_8138:eval_scm",(void*)f_8138},
{"f_8142:eval_scm",(void*)f_8142},
{"f_8148:eval_scm",(void*)f_8148},
{"f_8151:eval_scm",(void*)f_8151},
{"f_8169:eval_scm",(void*)f_8169},
{"f_8154:eval_scm",(void*)f_8154},
{"f_8158:eval_scm",(void*)f_8158},
{"f_8125:eval_scm",(void*)f_8125},
{"f_8131:eval_scm",(void*)f_8131},
{"f_8111:eval_scm",(void*)f_8111},
{"f_8122:eval_scm",(void*)f_8122},
{"f_8069:eval_scm",(void*)f_8069},
{"f_8075:eval_scm",(void*)f_8075},
{"f_8090:eval_scm",(void*)f_8090},
{"f_7992:eval_scm",(void*)f_7992},
{"f_8052:eval_scm",(void*)f_8052},
{"f_7999:eval_scm",(void*)f_7999},
{"f_8002:eval_scm",(void*)f_8002},
{"f_8029:eval_scm",(void*)f_8029},
{"f_8035:eval_scm",(void*)f_8035},
{"f_8017:eval_scm",(void*)f_8017},
{"f_7893:eval_scm",(void*)f_7893},
{"f_7897:eval_scm",(void*)f_7897},
{"f_7945:eval_scm",(void*)f_7945},
{"f_7947:eval_scm",(void*)f_7947},
{"f_7960:eval_scm",(void*)f_7960},
{"f_7899:eval_scm",(void*)f_7899},
{"f_7903:eval_scm",(void*)f_7903},
{"f_7938:eval_scm",(void*)f_7938},
{"f_7909:eval_scm",(void*)f_7909},
{"f_7919:eval_scm",(void*)f_7919},
{"f_7912:eval_scm",(void*)f_7912},
{"f_7869:eval_scm",(void*)f_7869},
{"f_7708:eval_scm",(void*)f_7708},
{"f_7813:eval_scm",(void*)f_7813},
{"f_7830:eval_scm",(void*)f_7830},
{"f_7838:eval_scm",(void*)f_7838},
{"f_7730:eval_scm",(void*)f_7730},
{"f_7735:eval_scm",(void*)f_7735},
{"f_7774:eval_scm",(void*)f_7774},
{"f_7761:eval_scm",(void*)f_7761},
{"f_7711:eval_scm",(void*)f_7711},
{"f_7622:eval_scm",(void*)f_7622},
{"f_7629:eval_scm",(void*)f_7629},
{"f_7639:eval_scm",(void*)f_7639},
{"f_7516:eval_scm",(void*)f_7516},
{"f_7520:eval_scm",(void*)f_7520},
{"f_7612:eval_scm",(void*)f_7612},
{"f_7616:eval_scm",(void*)f_7616},
{"f_7529:eval_scm",(void*)f_7529},
{"f_7598:eval_scm",(void*)f_7598},
{"f_7594:eval_scm",(void*)f_7594},
{"f_7532:eval_scm",(void*)f_7532},
{"f_7581:eval_scm",(void*)f_7581},
{"f_7584:eval_scm",(void*)f_7584},
{"f_7587:eval_scm",(void*)f_7587},
{"f_7535:eval_scm",(void*)f_7535},
{"f_7540:eval_scm",(void*)f_7540},
{"f_7574:eval_scm",(void*)f_7574},
{"f_7553:eval_scm",(void*)f_7553},
{"f_7507:eval_scm",(void*)f_7507},
{"f_7467:eval_scm",(void*)f_7467},
{"f_7488:eval_scm",(void*)f_7488},
{"f_7471:eval_scm",(void*)f_7471},
{"f_7485:eval_scm",(void*)f_7485},
{"f_7474:eval_scm",(void*)f_7474},
{"f_7482:eval_scm",(void*)f_7482},
{"f_7477:eval_scm",(void*)f_7477},
{"f_7431:eval_scm",(void*)f_7431},
{"f_7439:eval_scm",(void*)f_7439},
{"f_7409:eval_scm",(void*)f_7409},
{"f_6991:eval_scm",(void*)f_6991},
{"f_7364:eval_scm",(void*)f_7364},
{"f_7359:eval_scm",(void*)f_7359},
{"f_6993:eval_scm",(void*)f_6993},
{"f_7358:eval_scm",(void*)f_7358},
{"f_6997:eval_scm",(void*)f_6997},
{"f_7280:eval_scm",(void*)f_7280},
{"f_7295:eval_scm",(void*)f_7295},
{"f_7298:eval_scm",(void*)f_7298},
{"f_7301:eval_scm",(void*)f_7301},
{"f_7307:eval_scm",(void*)f_7307},
{"f_7310:eval_scm",(void*)f_7310},
{"f_7316:eval_scm",(void*)f_7316},
{"f_7000:eval_scm",(void*)f_7000},
{"f_7271:eval_scm",(void*)f_7271},
{"f_7259:eval_scm",(void*)f_7259},
{"f_7262:eval_scm",(void*)f_7262},
{"f_7265:eval_scm",(void*)f_7265},
{"f_7006:eval_scm",(void*)f_7006},
{"f_7244:eval_scm",(void*)f_7244},
{"f_7216:eval_scm",(void*)f_7216},
{"f_7240:eval_scm",(void*)f_7240},
{"f_7236:eval_scm",(void*)f_7236},
{"f_7232:eval_scm",(void*)f_7232},
{"f_7009:eval_scm",(void*)f_7009},
{"f_7017:eval_scm",(void*)f_7017},
{"f_7203:eval_scm",(void*)f_7203},
{"f_7021:eval_scm",(void*)f_7021},
{"f_7191:eval_scm",(void*)f_7191},
{"f_7042:eval_scm",(void*)f_7042},
{"f_7046:eval_scm",(void*)f_7046},
{"f_7182:eval_scm",(void*)f_7182},
{"f_7054:eval_scm",(void*)f_7054},
{"f_7058:eval_scm",(void*)f_7058},
{"f_7176:eval_scm",(void*)f_7176},
{"f_7061:eval_scm",(void*)f_7061},
{"f_7064:eval_scm",(void*)f_7064},
{"f_7069:eval_scm",(void*)f_7069},
{"f_7079:eval_scm",(void*)f_7079},
{"f_7125:eval_scm",(void*)f_7125},
{"f_7134:eval_scm",(void*)f_7134},
{"f_7152:eval_scm",(void*)f_7152},
{"f_7142:eval_scm",(void*)f_7142},
{"f_7146:eval_scm",(void*)f_7146},
{"f_7091:eval_scm",(void*)f_7091},
{"f_7098:eval_scm",(void*)f_7098},
{"f_7109:eval_scm",(void*)f_7109},
{"f_7120:eval_scm",(void*)f_7120},
{"f_7113:eval_scm",(void*)f_7113},
{"f_7103:eval_scm",(void*)f_7103},
{"f_7082:eval_scm",(void*)f_7082},
{"f_7089:eval_scm",(void*)f_7089},
{"f_7051:eval_scm",(void*)f_7051},
{"f_7031:eval_scm",(void*)f_7031},
{"f_7022:eval_scm",(void*)f_7022},
{"f_7012:eval_scm",(void*)f_7012},
{"f_6945:eval_scm",(void*)f_6945},
{"f_6955:eval_scm",(void*)f_6955},
{"f_6870:eval_scm",(void*)f_6870},
{"f_6882:eval_scm",(void*)f_6882},
{"f_6895:eval_scm",(void*)f_6895},
{"f_6877:eval_scm",(void*)f_6877},
{"f_6864:eval_scm",(void*)f_6864},
{"f_6780:eval_scm",(void*)f_6780},
{"f_6793:eval_scm",(void*)f_6793},
{"f_6826:eval_scm",(void*)f_6826},
{"f_6807:eval_scm",(void*)f_6807},
{"f_6783:eval_scm",(void*)f_6783},
{"f_6770:eval_scm",(void*)f_6770},
{"f_6778:eval_scm",(void*)f_6778},
{"f_3353:eval_scm",(void*)f_3353},
{"f_6451:eval_scm",(void*)f_6451},
{"f_6455:eval_scm",(void*)f_6455},
{"f_6702:eval_scm",(void*)f_6702},
{"f_6736:eval_scm",(void*)f_6736},
{"f_6729:eval_scm",(void*)f_6729},
{"f_6644:eval_scm",(void*)f_6644},
{"f_6645:eval_scm",(void*)f_6645},
{"f_6649:eval_scm",(void*)f_6649},
{"f_6656:eval_scm",(void*)f_6656},
{"f_6662:eval_scm",(void*)f_6662},
{"f_6696:eval_scm",(void*)f_6696},
{"f_6689:eval_scm",(void*)f_6689},
{"f_6660:eval_scm",(void*)f_6660},
{"f_6601:eval_scm",(void*)f_6601},
{"f_6604:eval_scm",(void*)f_6604},
{"f_6607:eval_scm",(void*)f_6607},
{"f_6610:eval_scm",(void*)f_6610},
{"f_6611:eval_scm",(void*)f_6611},
{"f_6615:eval_scm",(void*)f_6615},
{"f_6618:eval_scm",(void*)f_6618},
{"f_6625:eval_scm",(void*)f_6625},
{"f_6629:eval_scm",(void*)f_6629},
{"f_6633:eval_scm",(void*)f_6633},
{"f_6637:eval_scm",(void*)f_6637},
{"f_6559:eval_scm",(void*)f_6559},
{"f_6562:eval_scm",(void*)f_6562},
{"f_6565:eval_scm",(void*)f_6565},
{"f_6566:eval_scm",(void*)f_6566},
{"f_6570:eval_scm",(void*)f_6570},
{"f_6573:eval_scm",(void*)f_6573},
{"f_6580:eval_scm",(void*)f_6580},
{"f_6584:eval_scm",(void*)f_6584},
{"f_6588:eval_scm",(void*)f_6588},
{"f_6524:eval_scm",(void*)f_6524},
{"f_6527:eval_scm",(void*)f_6527},
{"f_6528:eval_scm",(void*)f_6528},
{"f_6532:eval_scm",(void*)f_6532},
{"f_6535:eval_scm",(void*)f_6535},
{"f_6542:eval_scm",(void*)f_6542},
{"f_6546:eval_scm",(void*)f_6546},
{"f_6496:eval_scm",(void*)f_6496},
{"f_6497:eval_scm",(void*)f_6497},
{"f_6501:eval_scm",(void*)f_6501},
{"f_6504:eval_scm",(void*)f_6504},
{"f_6511:eval_scm",(void*)f_6511},
{"f_6477:eval_scm",(void*)f_6477},
{"f11720:eval_scm",(void*)f11720},
{"f11716:eval_scm",(void*)f11716},
{"f_6425:eval_scm",(void*)f_6425},
{"f_3571:eval_scm",(void*)f_3571},
{"f_3578:eval_scm",(void*)f_3578},
{"f_3698:eval_scm",(void*)f_3698},
{"f_3754:eval_scm",(void*)f_3754},
{"f_3774:eval_scm",(void*)f_3774},
{"f_3777:eval_scm",(void*)f_3777},
{"f_3792:eval_scm",(void*)f_3792},
{"f_6225:eval_scm",(void*)f_6225},
{"f_6208:eval_scm",(void*)f_6208},
{"f_6212:eval_scm",(void*)f_6212},
{"f_6159:eval_scm",(void*)f_6159},
{"f_6174:eval_scm",(void*)f_6174},
{"f_6167:eval_scm",(void*)f_6167},
{"f_6144:eval_scm",(void*)f_6144},
{"f_6103:eval_scm",(void*)f_6103},
{"f_6043:eval_scm",(void*)f_6043},
{"f_6045:eval_scm",(void*)f_6045},
{"f_6067:eval_scm",(void*)f_6067},
{"f_6083:eval_scm",(void*)f_6083},
{"f_6057:eval_scm",(void*)f_6057},
{"f_6039:eval_scm",(void*)f_6039},
{"f_5985:eval_scm",(void*)f_5985},
{"f_6019:eval_scm",(void*)f_6019},
{"f_6012:eval_scm",(void*)f_6012},
{"f_5908:eval_scm",(void*)f_5908},
{"f_5911:eval_scm",(void*)f_5911},
{"f_5914:eval_scm",(void*)f_5914},
{"f_5937:eval_scm",(void*)f_5937},
{"f_5935:eval_scm",(void*)f_5935},
{"f_5931:eval_scm",(void*)f_5931},
{"f_5891:eval_scm",(void*)f_5891},
{"f_5895:eval_scm",(void*)f_5895},
{"f_5862:eval_scm",(void*)f_5862},
{"f_5866:eval_scm",(void*)f_5866},
{"f_5605:eval_scm",(void*)f_5605},
{"f_5749:eval_scm",(void*)f_5749},
{"f_5751:eval_scm",(void*)f_5751},
{"f_5829:eval_scm",(void*)f_5829},
{"f_5778:eval_scm",(void*)f_5778},
{"f_5802:eval_scm",(void*)f_5802},
{"f_5791:eval_scm",(void*)f_5791},
{"f_5611:eval_scm",(void*)f_5611},
{"f_5739:eval_scm",(void*)f_5739},
{"f_5614:eval_scm",(void*)f_5614},
{"f_5617:eval_scm",(void*)f_5617},
{"f_5645:eval_scm",(void*)f_5645},
{"f_5655:eval_scm",(void*)f_5655},
{"f_5736:eval_scm",(void*)f_5736},
{"f_5728:eval_scm",(void*)f_5728},
{"f_5665:eval_scm",(void*)f_5665},
{"f_5713:eval_scm",(void*)f_5713},
{"f_5668:eval_scm",(void*)f_5668},
{"f_5669:eval_scm",(void*)f_5669},
{"f_5675:eval_scm",(void*)f_5675},
{"f_5700:eval_scm",(void*)f_5700},
{"f_5618:eval_scm",(void*)f_5618},
{"f_5622:eval_scm",(void*)f_5622},
{"f_5625:eval_scm",(void*)f_5625},
{"f_5629:eval_scm",(void*)f_5629},
{"f_5632:eval_scm",(void*)f_5632},
{"f_5636:eval_scm",(void*)f_5636},
{"f_5639:eval_scm",(void*)f_5639},
{"f_5592:eval_scm",(void*)f_5592},
{"f_5545:eval_scm",(void*)f_5545},
{"f_5570:eval_scm",(void*)f_5570},
{"f_5548:eval_scm",(void*)f_5548},
{"f_5558:eval_scm",(void*)f_5558},
{"f_5566:eval_scm",(void*)f_5566},
{"f_5562:eval_scm",(void*)f_5562},
{"f_5551:eval_scm",(void*)f_5551},
{"f_5418:eval_scm",(void*)f_5418},
{"f_5476:eval_scm",(void*)f_5476},
{"f_5526:eval_scm",(void*)f_5526},
{"f_5503:eval_scm",(void*)f_5503},
{"f_5519:eval_scm",(void*)f_5519},
{"f_5515:eval_scm",(void*)f_5515},
{"f_5421:eval_scm",(void*)f_5421},
{"f_5424:eval_scm",(void*)f_5424},
{"f_5440:eval_scm",(void*)f_5440},
{"f_5448:eval_scm",(void*)f_5448},
{"f_5427:eval_scm",(void*)f_5427},
{"f_5434:eval_scm",(void*)f_5434},
{"f_5331:eval_scm",(void*)f_5331},
{"f_5355:eval_scm",(void*)f_5355},
{"f_5405:eval_scm",(void*)f_5405},
{"f_5382:eval_scm",(void*)f_5382},
{"f_5398:eval_scm",(void*)f_5398},
{"f_5394:eval_scm",(void*)f_5394},
{"f_5349:eval_scm",(void*)f_5349},
{"f_5334:eval_scm",(void*)f_5334},
{"f_5341:eval_scm",(void*)f_5341},
{"f_4883:eval_scm",(void*)f_4883},
{"f_5304:eval_scm",(void*)f_5304},
{"f_5315:eval_scm",(void*)f_5315},
{"f_5309:eval_scm",(void*)f_5309},
{"f_4895:eval_scm",(void*)f_4895},
{"f_4900:eval_scm",(void*)f_4900},
{"f_5268:eval_scm",(void*)f_5268},
{"f_5297:eval_scm",(void*)f_5297},
{"f_4904:eval_scm",(void*)f_4904},
{"f_5219:eval_scm",(void*)f_5219},
{"f_5252:eval_scm",(void*)f_5252},
{"f_5232:eval_scm",(void*)f_5232},
{"f_5217:eval_scm",(void*)f_5217},
{"f_4907:eval_scm",(void*)f_4907},
{"f_5209:eval_scm",(void*)f_5209},
{"f_4913:eval_scm",(void*)f_4913},
{"f_5171:eval_scm",(void*)f_5171},
{"f_5177:eval_scm",(void*)f_5177},
{"f_5201:eval_scm",(void*)f_5201},
{"f_5148:eval_scm",(void*)f_5148},
{"f_5154:eval_scm",(void*)f_5154},
{"f_6379:eval_scm",(void*)f_6379},
{"f_6408:eval_scm",(void*)f_6408},
{"f_5170:eval_scm",(void*)f_5170},
{"f_5166:eval_scm",(void*)f_5166},
{"f_5126:eval_scm",(void*)f_5126},
{"f_5132:eval_scm",(void*)f_5132},
{"f_5144:eval_scm",(void*)f_5144},
{"f_5107:eval_scm",(void*)f_5107},
{"f_5113:eval_scm",(void*)f_5113},
{"f_5079:eval_scm",(void*)f_5079},
{"f_5085:eval_scm",(void*)f_5085},
{"f_5060:eval_scm",(void*)f_5060},
{"f_5066:eval_scm",(void*)f_5066},
{"f_5032:eval_scm",(void*)f_5032},
{"f_5038:eval_scm",(void*)f_5038},
{"f_5013:eval_scm",(void*)f_5013},
{"f_5019:eval_scm",(void*)f_5019},
{"f_4985:eval_scm",(void*)f_4985},
{"f_4991:eval_scm",(void*)f_4991},
{"f_4966:eval_scm",(void*)f_4966},
{"f_4972:eval_scm",(void*)f_4972},
{"f_4942:eval_scm",(void*)f_4942},
{"f_4948:eval_scm",(void*)f_4948},
{"f_4923:eval_scm",(void*)f_4923},
{"f_4929:eval_scm",(void*)f_4929},
{"f_4726:eval_scm",(void*)f_4726},
{"f_4829:eval_scm",(void*)f_4829},
{"f_4747:eval_scm",(void*)f_4747},
{"f_4773:eval_scm",(void*)f_4773},
{"f_4755:eval_scm",(void*)f_4755},
{"f_4771:eval_scm",(void*)f_4771},
{"f_4751:eval_scm",(void*)f_4751},
{"f_4229:eval_scm",(void*)f_4229},
{"f_4676:eval_scm",(void*)f_4676},
{"f_4238:eval_scm",(void*)f_4238},
{"f_4641:eval_scm",(void*)f_4641},
{"f_4670:eval_scm",(void*)f_4670},
{"f_4241:eval_scm",(void*)f_4241},
{"f_4592:eval_scm",(void*)f_4592},
{"f_4625:eval_scm",(void*)f_4625},
{"f_4605:eval_scm",(void*)f_4605},
{"f_4590:eval_scm",(void*)f_4590},
{"f_4247:eval_scm",(void*)f_4247},
{"f_4582:eval_scm",(void*)f_4582},
{"f_4250:eval_scm",(void*)f_4250},
{"f_4532:eval_scm",(void*)f_4532},
{"f_4574:eval_scm",(void*)f_4574},
{"f_4559:eval_scm",(void*)f_4559},
{"f_4485:eval_scm",(void*)f_4485},
{"f_4486:eval_scm",(void*)f_4486},
{"f_4490:eval_scm",(void*)f_4490},
{"f_4502:eval_scm",(void*)f_4502},
{"f_4527:eval_scm",(void*)f_4527},
{"f_4493:eval_scm",(void*)f_4493},
{"f_4409:eval_scm",(void*)f_4409},
{"f_4412:eval_scm",(void*)f_4412},
{"f_4418:eval_scm",(void*)f_4418},
{"f_4421:eval_scm",(void*)f_4421},
{"f_4422:eval_scm",(void*)f_4422},
{"f_4438:eval_scm",(void*)f_4438},
{"f_4442:eval_scm",(void*)f_4442},
{"f_4446:eval_scm",(void*)f_4446},
{"f_4450:eval_scm",(void*)f_4450},
{"f_4342:eval_scm",(void*)f_4342},
{"f_4345:eval_scm",(void*)f_4345},
{"f_4351:eval_scm",(void*)f_4351},
{"f_4352:eval_scm",(void*)f_4352},
{"f_4368:eval_scm",(void*)f_4368},
{"f_4372:eval_scm",(void*)f_4372},
{"f_4376:eval_scm",(void*)f_4376},
{"f_4293:eval_scm",(void*)f_4293},
{"f_4296:eval_scm",(void*)f_4296},
{"f_4297:eval_scm",(void*)f_4297},
{"f_4313:eval_scm",(void*)f_4313},
{"f_4317:eval_scm",(void*)f_4317},
{"f_4259:eval_scm",(void*)f_4259},
{"f_4260:eval_scm",(void*)f_4260},
{"f_4276:eval_scm",(void*)f_4276},
{"f_4117:eval_scm",(void*)f_4117},
{"f_4131:eval_scm",(void*)f_4131},
{"f_4135:eval_scm",(void*)f_4135},
{"f_4144:eval_scm",(void*)f_4144},
{"f_4177:eval_scm",(void*)f_4177},
{"f_4185:eval_scm",(void*)f_4185},
{"f_4150:eval_scm",(void*)f_4150},
{"f_4153:eval_scm",(void*)f_4153},
{"f_4169:eval_scm",(void*)f_4169},
{"f_4160:eval_scm",(void*)f_4160},
{"f_4168:eval_scm",(void*)f_4168},
{"f_4205:eval_scm",(void*)f_4205},
{"f_4213:eval_scm",(void*)f_4213},
{"f_4192:eval_scm",(void*)f_4192},
{"f_4204:eval_scm",(void*)f_4204},
{"f_4125:eval_scm",(void*)f_4125},
{"f_4005:eval_scm",(void*)f_4005},
{"f_4064:eval_scm",(void*)f_4064},
{"f_4067:eval_scm",(void*)f_4067},
{"f_4089:eval_scm",(void*)f_4089},
{"f_4070:eval_scm",(void*)f_4070},
{"f_4071:eval_scm",(void*)f_4071},
{"f_4075:eval_scm",(void*)f_4075},
{"f_4078:eval_scm",(void*)f_4078},
{"f_4042:eval_scm",(void*)f_4042},
{"f_4045:eval_scm",(void*)f_4045},
{"f_4046:eval_scm",(void*)f_4046},
{"f_4050:eval_scm",(void*)f_4050},
{"f_3945:eval_scm",(void*)f_3945},
{"f_3948:eval_scm",(void*)f_3948},
{"f_3951:eval_scm",(void*)f_3951},
{"f_3954:eval_scm",(void*)f_3954},
{"f_3955:eval_scm",(void*)f_3955},
{"f_3962:eval_scm",(void*)f_3962},
{"f_3935:eval_scm",(void*)f_3935},
{"f_3901:eval_scm",(void*)f_3901},
{"f_3895:eval_scm",(void*)f_3895},
{"f_3896:eval_scm",(void*)f_3896},
{"f_3879:eval_scm",(void*)f_3879},
{"f_3801:eval_scm",(void*)f_3801},
{"f_3804:eval_scm",(void*)f_3804},
{"f_3861:eval_scm",(void*)f_3861},
{"f_3859:eval_scm",(void*)f_3859},
{"f_3851:eval_scm",(void*)f_3851},
{"f_3843:eval_scm",(void*)f_3843},
{"f_3835:eval_scm",(void*)f_3835},
{"f_3827:eval_scm",(void*)f_3827},
{"f_3819:eval_scm",(void*)f_3819},
{"f_3811:eval_scm",(void*)f_3811},
{"f_3755:eval_scm",(void*)f_3755},
{"f_3744:eval_scm",(void*)f_3744},
{"f_3742:eval_scm",(void*)f_3742},
{"f_3731:eval_scm",(void*)f_3731},
{"f_3729:eval_scm",(void*)f_3729},
{"f_3721:eval_scm",(void*)f_3721},
{"f_3713:eval_scm",(void*)f_3713},
{"f_3705:eval_scm",(void*)f_3705},
{"f_3597:eval_scm",(void*)f_3597},
{"f_3665:eval_scm",(void*)f_3665},
{"f_3607:eval_scm",(void*)f_3607},
{"f_3656:eval_scm",(void*)f_3656},
{"f_3641:eval_scm",(void*)f_3641},
{"f10596:eval_scm",(void*)f10596},
{"f10591:eval_scm",(void*)f10591},
{"f_3613:eval_scm",(void*)f_3613},
{"f_3616:eval_scm",(void*)f_3616},
{"f_3617:eval_scm",(void*)f_3617},
{"f_3688:eval_scm",(void*)f_3688},
{"f_3679:eval_scm",(void*)f_3679},
{"f_3591:eval_scm",(void*)f_3591},
{"f_3579:eval_scm",(void*)f_3579},
{"f_3520:eval_scm",(void*)f_3520},
{"f_3524:eval_scm",(void*)f_3524},
{"f_3545:eval_scm",(void*)f_3545},
{"f_3556:eval_scm",(void*)f_3556},
{"f_3549:eval_scm",(void*)f_3549},
{"f_3525:eval_scm",(void*)f_3525},
{"f_3529:eval_scm",(void*)f_3529},
{"f_3532:eval_scm",(void*)f_3532},
{"f_3536:eval_scm",(void*)f_3536},
{"f_3539:eval_scm",(void*)f_3539},
{"f_3413:eval_scm",(void*)f_3413},
{"f_3417:eval_scm",(void*)f_3417},
{"f_3425:eval_scm",(void*)f_3425},
{"f_3442:eval_scm",(void*)f_3442},
{"f_3472:eval_scm",(void*)f_3472},
{"f_3398:eval_scm",(void*)f_3398},
{"f_3402:eval_scm",(void*)f_3402},
{"f_3408:eval_scm",(void*)f_3408},
{"f_3359:eval_scm",(void*)f_3359},
{"f_3372:eval_scm",(void*)f_3372},
{"f_3309:eval_scm",(void*)f_3309},
{"f_3328:eval_scm",(void*)f_3328},
{"f_3340:eval_scm",(void*)f_3340},
{"f_3343:eval_scm",(void*)f_3343},
{"f_3346:eval_scm",(void*)f_3346},
{"f_3336:eval_scm",(void*)f_3336},
{"f_3315:eval_scm",(void*)f_3315},
{"f_3249:eval_scm",(void*)f_3249},
{"f_3253:eval_scm",(void*)f_3253},
{"f_3261:eval_scm",(void*)f_3261},
{"f_3181:eval_scm",(void*)f_3181},
{"f_3187:eval_scm",(void*)f_3187},
{"f_3210:eval_scm",(void*)f_3210},
{"f_3233:eval_scm",(void*)f_3233},
{"f_3218:eval_scm",(void*)f_3218},
{"f_3197:eval_scm",(void*)f_3197},
{"f_3161:eval_scm",(void*)f_3161},
{"f_3173:eval_scm",(void*)f_3173},
{"f_3176:eval_scm",(void*)f_3176},
{"f_3169:eval_scm",(void*)f_3169},
{"f_3101:eval_scm",(void*)f_3101},
{"f_3105:eval_scm",(void*)f_3105},
{"f_3113:eval_scm",(void*)f_3113},
{"f_3046:eval_scm",(void*)f_3046},
{"f_3099:eval_scm",(void*)f_3099},
{"f_3056:eval_scm",(void*)f_3056},
{"f_3031:eval_scm",(void*)f_3031},
{"f_3019:eval_scm",(void*)f_3019},
{"f_3023:eval_scm",(void*)f_3023},
{"f_2992:eval_scm",(void*)f_2992},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
