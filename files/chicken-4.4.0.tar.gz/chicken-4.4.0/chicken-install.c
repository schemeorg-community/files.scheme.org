/* Generated from chicken-install.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: chicken-install.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -ignore-repository -output-file chicken-install.c
   used units: library eval srfi_1 posix data_structures utils regex ports extras srfi_13 files chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[307];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_ccall f_1335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1346)
static void C_ccall f_1346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1394)
static void C_fcall f_1394(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_fcall f_1402(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_fcall f_1447(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_fcall f_1474(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1478)
static void C_ccall f_1478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_fcall f_1375(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_fcall f_3645(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3773)
static void C_fcall f_3773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_fcall f_4248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_fcall f_4360(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4343)
static void C_ccall f_4343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4901)
static void C_ccall f4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4896)
static void C_ccall f4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4891)
static void C_ccall f4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4886)
static void C_ccall f4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4881)
static void C_ccall f4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4868)
static void C_ccall f4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_fcall f_1632(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_fcall f_1640(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4861)
static void C_ccall f4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4856)
static void C_ccall f4856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4851)
static void C_ccall f4851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f4846)
static void C_ccall f4846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_fcall f_3709(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_fcall f_2928(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_fcall f_2936(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3025)
static void C_fcall f_3025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_fcall f_3031(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_fcall f_2791(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3128)
static void C_ccall f_3128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3134)
static void C_ccall f_3134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_fcall f_3362(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_fcall f_3370(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3307)
static void C_fcall f_3307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3334)
static C_word C_fcall f_3334(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_fcall f_3263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3290)
static C_word C_fcall f_3290(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_fcall f_3171(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4504)
static void C_ccall f_4504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4466)
static void C_ccall f_4466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3611)
static void C_fcall f_3611(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_fcall f_3589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_fcall f_3487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_fcall f_3532(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_fcall f_3103(C_word t0) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_fcall f_2261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_fcall f_2535(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2584)
static void C_ccall f_2584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_fcall f_2102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_fcall f_2104(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_fcall f_2120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_fcall f_2123(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_fcall f_1992(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_fcall f_2004(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_fcall f_2016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_fcall f_2276(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2689)
static void C_fcall f_2689(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_fcall f_2629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_fcall f_2436(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2446)
static void C_fcall f_2446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2339)
static void C_ccall f_2339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_fcall f_2191(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_fcall f_2359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_fcall f_1754(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1810)
static void C_fcall f_1810(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_fcall f_1672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1682)
static void C_fcall f_1682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1602)
static C_word C_fcall f_1602(C_word t0,C_word t1);

C_noret_decl(trf_1394)
static void C_fcall trf_1394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1394(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1394(t0,t1,t2);}

C_noret_decl(trf_1402)
static void C_fcall trf_1402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1402(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1402(t0,t1,t2);}

C_noret_decl(trf_1447)
static void C_fcall trf_1447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1447(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1447(t0,t1,t2);}

C_noret_decl(trf_1474)
static void C_fcall trf_1474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1474(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1474(t0,t1,t2);}

C_noret_decl(trf_1375)
static void C_fcall trf_1375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1375(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1375(t0,t1,t2);}

C_noret_decl(trf_3645)
static void C_fcall trf_3645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3645(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3645(t0,t1,t2,t3);}

C_noret_decl(trf_3773)
static void C_fcall trf_3773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3773(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3773(t0,t1);}

C_noret_decl(trf_4248)
static void C_fcall trf_4248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4248(t0,t1);}

C_noret_decl(trf_4360)
static void C_fcall trf_4360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4360(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4360(t0,t1,t2);}

C_noret_decl(trf_1632)
static void C_fcall trf_1632(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1632(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1632(t0,t1,t2);}

C_noret_decl(trf_1640)
static void C_fcall trf_1640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1640(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1640(t0,t1,t2);}

C_noret_decl(trf_3709)
static void C_fcall trf_3709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3709(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3709(t0,t1,t2);}

C_noret_decl(trf_2928)
static void C_fcall trf_2928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2928(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2928(t0,t1,t2,t3);}

C_noret_decl(trf_2936)
static void C_fcall trf_2936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2936(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2936(t0,t1,t2,t3);}

C_noret_decl(trf_3025)
static void C_fcall trf_3025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3025(t0,t1);}

C_noret_decl(trf_3031)
static void C_fcall trf_3031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3031(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3031(t0,t1);}

C_noret_decl(trf_2791)
static void C_fcall trf_2791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2791(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2791(t0,t1);}

C_noret_decl(trf_3362)
static void C_fcall trf_3362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3362(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3362(t0,t1,t2);}

C_noret_decl(trf_3370)
static void C_fcall trf_3370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3370(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3370(t0,t1,t2);}

C_noret_decl(trf_3307)
static void C_fcall trf_3307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3307(t0,t1,t2);}

C_noret_decl(trf_3263)
static void C_fcall trf_3263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3263(t0,t1,t2);}

C_noret_decl(trf_3171)
static void C_fcall trf_3171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3171(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3171(t0,t1,t2);}

C_noret_decl(trf_3611)
static void C_fcall trf_3611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3611(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3611(t0,t1,t2);}

C_noret_decl(trf_3589)
static void C_fcall trf_3589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3589(t0,t1);}

C_noret_decl(trf_3487)
static void C_fcall trf_3487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3487(t0,t1);}

C_noret_decl(trf_3532)
static void C_fcall trf_3532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3532(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3532(t0,t1,t2);}

C_noret_decl(trf_3103)
static void C_fcall trf_3103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3103(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3103(t0);}

C_noret_decl(trf_2261)
static void C_fcall trf_2261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2261(t0,t1);}

C_noret_decl(trf_2535)
static void C_fcall trf_2535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2535(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2535(t0,t1,t2);}

C_noret_decl(trf_2102)
static void C_fcall trf_2102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2102(t0,t1);}

C_noret_decl(trf_2104)
static void C_fcall trf_2104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2104(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2104(t0,t1,t2);}

C_noret_decl(trf_2120)
static void C_fcall trf_2120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2120(t0,t1);}

C_noret_decl(trf_2123)
static void C_fcall trf_2123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2123(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2123(t0,t1);}

C_noret_decl(trf_1992)
static void C_fcall trf_1992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1992(t0,t1);}

C_noret_decl(trf_2004)
static void C_fcall trf_2004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2004(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2004(t0,t1);}

C_noret_decl(trf_2016)
static void C_fcall trf_2016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2016(t0,t1);}

C_noret_decl(trf_2276)
static void C_fcall trf_2276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2276(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2276(t0,t1,t2);}

C_noret_decl(trf_2689)
static void C_fcall trf_2689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2689(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2689(t0,t1);}

C_noret_decl(trf_2629)
static void C_fcall trf_2629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2629(t0,t1);}

C_noret_decl(trf_2436)
static void C_fcall trf_2436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2436(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2436(t0,t1,t2);}

C_noret_decl(trf_2446)
static void C_fcall trf_2446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2446(t0,t1);}

C_noret_decl(trf_2191)
static void C_fcall trf_2191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2191(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2191(t0,t1,t2);}

C_noret_decl(trf_2359)
static void C_fcall trf_2359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2359(t0,t1,t2);}

C_noret_decl(trf_1754)
static void C_fcall trf_1754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1754(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1754(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1810)
static void C_fcall trf_1810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1810(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1810(t0,t1);}

C_noret_decl(trf_1672)
static void C_fcall trf_1672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1672(t0,t1);}

C_noret_decl(trf_1682)
static void C_fcall trf_1682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1682(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1401)){
C_save(t1);
C_rereclaim2(1401*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,307);
lf[13]=C_h_intern(&lf[13],4,"http");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[25]=C_h_intern(&lf[25],7,"chicken");
lf[26]=C_h_intern(&lf[26],15,"chicken-version");
lf[27]=C_h_intern(&lf[27],7,"version");
lf[28]=C_h_intern(&lf[28],8,"->string");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\0050.0.0");
lf[30]=C_h_intern(&lf[30],21,"extension-information");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[32]=C_h_intern(&lf[32],24,"\003syscore-library-modules");
lf[38]=C_h_intern(&lf[38],7,"reverse");
lf[39]=C_h_intern(&lf[39],10,"alist-cons");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[41]=C_h_intern(&lf[41],5,"error");
lf[42]=C_h_intern(&lf[42],13,"string-append");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000JYour CHICKEN version is not recent enough to use this extension - version ");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\025 or newer is required");
lf[45]=C_h_intern(&lf[45],20,"setup-api#version>=\077");
lf[46]=C_h_intern(&lf[46],7,"warning");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\0007invalid dependency syntax in extension meta information");
lf[48]=C_h_intern(&lf[48],7,"depends");
lf[49]=C_h_intern(&lf[49],5,"needs");
lf[50]=C_h_intern(&lf[50],12,"test-depends");
lf[51]=C_h_intern(&lf[51],6,"append");
lf[52]=C_h_intern(&lf[52],26,"setup-api#remove-extension");
lf[53]=C_h_intern(&lf[53],5,"print");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000)removing previously installed extension `");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\012 upgrade: ");
lf[57]=C_h_intern(&lf[57],18,"string-intersperse");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[59]=C_h_intern(&lf[59],6,"unzip1");
lf[60]=C_h_intern(&lf[60],20,"setup-api#yes-or-no\077");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[62]=C_h_intern(&lf[62],18,"string-concatenate");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000:The following installed extensions are outdated, because `");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\033\047 requires later versions:\012");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\0000\012Do you want to replace the existing extensions\077\376\377\016");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\003\077\077\077");
lf[67]=C_h_intern(&lf[67],4,"conc");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\002 (");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\012 missing: ");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\033checking dependencies for `");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000)extension is not targeted for this system");
lf[78]=C_h_intern(&lf[78],8,"platform");
lf[79]=C_h_intern(&lf[79],8,"feature\077");
lf[80]=C_h_intern(&lf[80],3,"and");
lf[81]=C_h_intern(&lf[81],5,"every");
lf[82]=C_h_intern(&lf[82],2,"or");
lf[83]=C_h_intern(&lf[83],4,"any\077");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid `platform\047 property");
lf[85]=C_h_intern(&lf[85],3,"not");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid `platform\047 property");
lf[87]=C_h_intern(&lf[87],14,"\000cross-chicken");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\027checking platform for `");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[90]=C_h_intern(&lf[90],20,"with-input-from-file");
lf[91]=C_h_intern(&lf[91],4,"read");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\013extension `");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\024\047 has no .meta file ");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000!- assuming it has no dependencies");
lf[95]=C_h_intern(&lf[95],12,"file-exists\077");
lf[96]=C_h_intern(&lf[96],13,"make-pathname");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[98]=C_h_intern(&lf[98],6,"delete");
lf[99]=C_h_intern(&lf[99],3,"eq\077");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[101]=C_h_intern(&lf[101],9,"condition");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\023TCP connect timeout");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\023HTTP protocol error");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[107]=C_h_intern(&lf[107],19,"print-error-message");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\015Server error:");
lf[109]=C_h_intern(&lf[109],5,"abort");
lf[110]=C_h_intern(&lf[110],3,"exn");
lf[111]=C_h_intern(&lf[111],20,"setup-download-error");
lf[112]=C_h_intern(&lf[112],10,"http-fetch");
lf[113]=C_h_intern(&lf[113],3,"net");
lf[114]=C_h_intern(&lf[114],33,"setup-download#retrieve-extension");
lf[115]=C_h_intern(&lf[115],8,"\000version");
lf[116]=C_h_intern(&lf[116],12,"\000destination");
lf[117]=C_h_intern(&lf[117],6,"\000tests");
lf[118]=C_h_intern(&lf[118],9,"\000username");
lf[119]=C_h_intern(&lf[119],9,"\000password");
lf[120]=C_h_intern(&lf[120],6,"\000trunk");
lf[121]=C_h_intern(&lf[121],11,"\000proxy-host");
lf[122]=C_h_intern(&lf[122],11,"\000proxy-port");
lf[123]=C_h_intern(&lf[123],17,"current-directory");
lf[124]=C_h_intern(&lf[124],22,"with-exception-handler");
lf[125]=C_h_intern(&lf[125],30,"call-with-current-continuation");
lf[126]=C_h_intern(&lf[126],9,"transport");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\027missing transport entry");
lf[128]=C_h_intern(&lf[128],8,"location");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\026missing location entry");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\014 located at ");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\036extension or version not found");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\016retrieving ...");
lf[135]=C_h_intern(&lf[135],26,"setup-api#remove-directory");
lf[136]=C_h_intern(&lf[136],34,"setup-download#temporary-directory");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\007mapped ");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\004 to ");
lf[139]=C_h_intern(&lf[139],17,"delete-duplicates");
lf[140]=C_h_intern(&lf[140],8,"string=\077");
lf[141]=C_h_intern(&lf[141],4,"find");
lf[142]=C_h_intern(&lf[142],10,"append-map");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000/shell command terminated with nonzero exit code");
lf[145]=C_h_intern(&lf[145],6,"system");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[150]=C_h_intern(&lf[150],7,"sprintf");
lf[151]=C_h_intern(&lf[151],25,"\003sysimplicit-exit-handler");
lf[152]=C_h_intern(&lf[152],4,"exit");
lf[153]=C_h_intern(&lf[153],18,"current-error-port");
lf[154]=C_h_intern(&lf[154],7,"newline");
lf[155]=C_h_intern(&lf[155],19,"setup-api#copy-file");
lf[156]=C_h_intern(&lf[156],15,"repository-path");
lf[157]=C_h_intern(&lf[157],5,"write");
lf[158]=C_h_intern(&lf[158],19,"with-output-to-file");
lf[159]=C_h_intern(&lf[159],8,"string<\077");
lf[160]=C_h_intern(&lf[160],14,"symbol->string");
lf[161]=C_h_intern(&lf[161],4,"sort");
lf[162]=C_h_intern(&lf[162],18,"\003sysmodule-exports");
lf[163]=C_h_intern(&lf[163],5,"value");
lf[164]=C_h_intern(&lf[164],6,"syntax");
lf[165]=C_h_intern(&lf[165],6,"print*");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[167]=C_h_intern(&lf[167],15,"\003sysmodule-name");
lf[168]=C_h_intern(&lf[168],16,"\003sysmodule-table");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\023generating database");
lf[170]=C_h_intern(&lf[170],20,"\003syswarnings-enabled");
lf[171]=C_h_intern(&lf[171],17,"get-output-string");
lf[172]=C_h_intern(&lf[172],19,"\003syswrite-char/port");
lf[173]=C_h_intern(&lf[173],7,"display");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\027Failed to import from `");
lf[175]=C_h_intern(&lf[175],18,"open-output-string");
lf[176]=C_h_intern(&lf[176],6,"import");
lf[177]=C_h_intern(&lf[177],4,"eval");
lf[178]=C_h_intern(&lf[178],14,"string->symbol");
lf[179]=C_h_intern(&lf[179],12,"string-match");
lf[180]=C_h_intern(&lf[180],16,"\003sysdynamic-wind");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\034loading import libraries ...");
lf[182]=C_h_intern(&lf[182],6,"regexp");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\034.*/([^/]+)\134.import\134.(scm|so)");
lf[184]=C_h_intern(&lf[184],36,"setup-api#create-temporary-directory");
lf[185]=C_h_intern(&lf[185],4,"glob");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\012*.import.*");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\020~a -s run.scm ~a");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\015tests/run.scm");
lf[190]=C_h_intern(&lf[190],10,"directory\077");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\027 -e \042(sudo-install #t)\042");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(keep-intermediates #t)\042");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(setup-install-mode #f)\042");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(host-extension #t)\042");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\032 -e \042(deployment-mode #t)\042");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\006 -bnq ");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\0008-e \042(require-library setup-api)\042 -e \042(import setup-api)\042");
lf[206]=C_h_intern(&lf[206],19,"setup-api#shellpath");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\004\134\042)\042");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\034 -e \042(installation-prefix \134\042");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[211]=C_h_intern(&lf[211],22,"setup-api#sudo-install");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042))\042");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042 \134\042");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000% -e \042(extension-name-and-version \047(\134\042");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\014-setup-mode ");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\036changing current directory to ");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\013installing ");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\026aborting installation.");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\203You specified `-no-install\047, but this extension has dependencies that are r"
"equired for building. Do you still want to install them\077");
lf[222]=C_h_intern(&lf[222],4,"iota");
lf[223]=C_h_intern(&lf[223],5,"assoc");
lf[224]=C_h_intern(&lf[224],7,"\003sysmap");
lf[225]=C_h_intern(&lf[225],2,"pp");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\016install order:");
lf[227]=C_h_intern(&lf[227],16,"topological-sort");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000;no default location defined - please use `-location\047 option");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000=no default transport defined - please use `-transport\047 option");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[232]=C_h_intern(&lf[232],13,"pathname-file");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\033no setup-scripts to process");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\007*.setup");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\005\270usage: chicken-install [OPTION | EXTENSION[:VERSION]] ...\012\012  -h   -help    "
"                show this message and exit\012  -v   -version                 show "
"version and exit\012       -force                   don\047t ask, install even if vers"
"ions don\047t match\012  -k   -keep                    keep temporary files\012  -l   -lo"
"cation LOCATION       install from given location instead of default\012  -t   -tra"
"nsport TRANSPORT     use given transport instead of default\012       -proxy HOST[:"
"PORT]       download via HTTP proxy\012  -s   -sudo                    use sudo(1) "
"for filesystem operations\012  -r   -retrieve                only retrieve egg into"
" current directory, don\047t install\012  -n   -no-install              do not install"
", just build (implies `-keep\047)\012  -p   -prefix PREFIX           change installati"
"on prefix to PREFIX\012       -host                    when cross-compiling, compil"
"e extension for host\012       -test                    run included test-cases, if"
" available\012       -username USER           set username for transports that requ"
"ire this\012       -password PASS           set password for transports that requir"
"e this\012  -i   -init DIRECTORY          initialize empty alternative repository\012 "
" -u   -update-db               update export database\012       -repository        "
"      print path used for egg installation\012       -deploy                  build"
" extensions for deployment\012       -trunk                   build trunk instead o"
"f tagged version (only local)");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\013-repository");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\005-keep");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\002-r");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\011-retrieve");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\011-location");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\002-t");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\012-transport");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\007-prefix");
lf[251]=C_h_intern(&lf[251],18,"normalize-pathname");
lf[252]=C_h_intern(&lf[252],18,"absolute-pathname\077");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\002-n");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-install");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\002-u");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\012-update-db");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\002-i");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\005-init");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\010~a ~a ~a");
lf[264]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014setup-api.so\376\003\000\000\002\376B\000\000\023setup-api.import.so\376\003\000\000\002\376B\000\000\021setup-download.so\376\003"
"\000\000\002\376B\000\000\030setup-download.import.so\376\003\000\000\002\376B\000\000\021chicken.import.so\376\003\000\000\002\376B\000\000\021lolevel.imp"
"ort.so\376\003\000\000\002\376B\000\000\020srfi-1.import.so\376\003\000\000\002\376B\000\000\020srfi-4.import.so\376\003\000\000\002\376B\000\000\031data-structu"
"res.import.so\376\003\000\000\002\376B\000\000\017ports.import.so\376\003\000\000\002\376B\000\000\017files.import.so\376\003\000\000\002\376B\000\000\017posix.i"
"mport.so\376\003\000\000\002\376B\000\000\021srfi-13.import.so\376\003\000\000\002\376B\000\000\021srfi-69.import.so\376\003\000\000\002\376B\000\000\020extras.i"
"mport.so\376\003\000\000\002\376B\000\000\017regex.import.so\376\003\000\000\002\376B\000\000\021srfi-14.import.so\376\003\000\000\002\376B\000\000\015tcp.import"
".so\376\003\000\000\002\376B\000\000\021foreign.import.so\376\003\000\000\002\376B\000\000\020scheme.import.so\376\003\000\000\002\376B\000\000\021srfi-18.import"
".so\376\003\000\000\002\376B\000\000\017utils.import.so\376\003\000\000\002\376B\000\000\015csi.import.so\376\003\000\000\002\376B\000\000\021irregex.import.so\376\003"
"\000\000\002\376B\000\000\010types.db\376\377\016");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\032copying required files to ");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\006-proxy");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\016(.+)\134:([0-9]+)");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\005-test");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\017-host-extension");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\007-deploy");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\011-username");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\006-trunk");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\011-password");
lf[276]=C_h_intern(&lf[276],6,"string");
lf[277]=C_h_intern(&lf[277],17,"lset-intersection");
lf[278]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000l\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000p\376\003\000\000\002\376\377\012\000\000r\376\003\000"
"\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000u\376\377\016");
lf[279]=C_h_intern(&lf[279],16,"\003sysstring->list");
lf[280]=C_h_intern(&lf[280],9,"substring");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[283]=C_h_intern(&lf[283],18,"pathname-directory");
lf[284]=C_h_intern(&lf[284],18,"pathname-extension");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\014([^:]+):(.+)");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid entry in defaults file");
lf[289]=C_h_intern(&lf[289],6,"server");
lf[290]=C_h_intern(&lf[290],3,"map");
lf[291]=C_h_intern(&lf[291],8,"split-at");
lf[292]=C_h_intern(&lf[292],2,"->");
lf[293]=C_h_intern(&lf[293],10,"list-index");
lf[294]=C_h_intern(&lf[294],9,"read-file");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\016setup.defaults");
lf[296]=C_h_intern(&lf[296],12,"chicken-home");
lf[297]=C_h_intern(&lf[297],22,"command-line-arguments");
lf[298]=C_h_intern(&lf[298],17,"register-feature!");
lf[299]=C_h_intern(&lf[299],15,"chicken-install");
lf[300]=C_h_intern(&lf[300],17,"\003syspeek-c-string");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[302]=C_h_intern(&lf[302],24,"get-environment-variable");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[304]=C_h_intern(&lf[304],11,"\003sysrequire");
lf[305]=C_h_intern(&lf[305],9,"setup-api");
lf[306]=C_h_intern(&lf[306],14,"setup-download");
C_register_lf2(lf,307,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1296,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1294 */
static void C_ccall f_1296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1299,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1297 in k1294 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1302,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1300 in k1297 in k1294 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1305,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1311,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1323,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t2,lf[306]);}

/* k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t2,lf[305]);}

/* k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 66   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[302]))(3,*((C_word*)lf[302]+1),t2,lf[303]);}

/* k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* chicken-install.scm: 67   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),t2,t1,lf[301]);}
else{
t3=t2;
f_1343(2,t3,C_SCHEME_FALSE);}}

/* k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1346(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[300]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1346,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#*program-path* ...) */,t1);
t3=lf[1] /* main#*keep* */ =C_SCHEME_FALSE;;
t4=lf[2] /* main#*force* */ =C_SCHEME_FALSE;;
t5=lf[3] /* main#*prefix* */ =C_SCHEME_FALSE;;
t6=lf[4] /* main#*host-extension* */ =C_SCHEME_FALSE;;
t7=lf[5] /* main#*run-tests* */ =C_SCHEME_FALSE;;
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_FALSE;;
t9=lf[7] /* main#*no-install* */ =C_SCHEME_FALSE;;
t10=lf[8] /* main#*username* */ =C_SCHEME_FALSE;;
t11=lf[9] /* main#*password* */ =C_SCHEME_FALSE;;
t12=lf[10] /* main#*default-sources* */ =C_SCHEME_END_OF_LIST;;
t13=lf[11] /* main#*default-location* */ =C_SCHEME_FALSE;;
t14=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,lf[13]);
t15=C_mutate(&lf[14] /* (set! main#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t16=lf[15] /* main#*proxy-host* */ =C_SCHEME_FALSE;;
t17=lf[16] /* main#*proxy-port* */ =C_SCHEME_FALSE;;
t18=lf[17] /* main#*running-test* */ =C_SCHEME_FALSE;;
t19=lf[18] /* main#*mappings* */ =C_SCHEME_END_OF_LIST;;
t20=lf[19] /* main#*deploy* */ =C_SCHEME_FALSE;;
t21=lf[20] /* main#*trunk* */ =C_SCHEME_FALSE;;
t22=C_mutate(&lf[21] /* (set! main#constant174 ...) */,lf[22]);
t23=C_mutate(&lf[23] /* (set! main#deps ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1602,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate(&lf[24] /* (set! main#ext-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1672,tmp=(C_word)a,a+=2,tmp));
t25=lf[33] /* main#*eggs+dirs+vers* */ =C_SCHEME_END_OF_LIST;;
t26=lf[34] /* main#*dependencies* */ =C_SCHEME_END_OF_LIST;;
t27=lf[35] /* main#*checked* */ =C_SCHEME_END_OF_LIST;;
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4543,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4547,a[2]=t29,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t31=*((C_word*)lf[300]+1);
((C_proc4)(void*)(*((C_word*)t31+1)))(4,t31,t30,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k4545 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 207  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[2],C_retrieve2(lf[0],"main#*program-path*"),t1);}

/* k4541 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 207  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[206]))(3,*((C_word*)lf[206]+1),((C_word*)t0)[2],t1);}

/* k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1959,2,t0,t1);}
t2=C_mutate(&lf[36] /* (set! main#*csi* ...) */,t1);
t3=C_mutate(&lf[37] /* (set! main#retrieve ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2261,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[134] /* (set! main#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3103,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[74] /* (set! main#apply-mappings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3487,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[143] /* (set! main#$system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3589,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[148] /* (set! main#command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3611,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 641  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),t8,lf[299]);}

/* k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4460,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4471,tmp=(C_word)a,a+=2,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t2,t3);}

/* a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4471,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4477,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4510,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t1,t3,t4);}

/* a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4516,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4528 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4529r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4529r(t0,t1,t2);}}

static void C_ccall f_4529r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4535,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k12131218 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4534 in a4528 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4535,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4520,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 649  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[297]))(2,*((C_word*)lf[297]+1),t3);}

/* k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3637,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1557,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 94   chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[296]))(2,*((C_word*)lf[296]+1),t4);}

/* k1555 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 94   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[2],t1,lf[295]);}

/* k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1375,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1553,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 97   file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),t3,t1);}

/* k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 118  read-file */
((C_proc3)C_retrieve_symbol_proc(lf[294]))(3,*((C_word*)lf[294]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3637(2,t2,C_SCHEME_END_OF_LIST);}}

/* k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1392,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1394,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1394(t5,((C_word*)t0)[2],t1);}

/* loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1394(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1394,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1402,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1538,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g196197 */
t6=t3;
f_1402(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1536 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1394(t3,((C_word*)t0)[2],t2);}

/* g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1402(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1402,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1406,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
if(C_truep((C_word)C_i_positivep(t4))){
t5=t3;
f_1406(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 102  broken */
t5=((C_word*)t0)[2];
f_1375(t5,t3,t2);}}
else{
/* chicken-install.scm: 102  broken */
t4=((C_word*)t0)[2];
f_1375(t4,t3,t2);}}

/* k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1406,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[289]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1419,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,1,t5);
/* chicken-install.scm: 106  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),t4,C_retrieve2(lf[10],"main#*default-sources*"),t6);}
else{
t4=(C_word)C_eqp(t2,lf[290]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1441,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[4]);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1447,a[2]=t7,a[3]=t13,a[4]=t9,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_1447(t15,t10,t11);}
else{
/* chicken-install.scm: 117  broken */
t5=((C_word*)t0)[2];
f_1375(t5,((C_word*)t0)[3],((C_word*)t0)[4]);}}}

/* loop210 in k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1447(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1447,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g226227 */
t6=t3;
f_1474(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1510 in loop210 in k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1512,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop210223 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1447(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop210223 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1447(t6,((C_word*)t0)[3],t5);}}

/* g226 in loop210 in k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1474(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1474,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1505,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 112  list-index */
((C_proc4)C_retrieve_symbol_proc(lf[293]))(4,*((C_word*)lf[293]+1),t3,t4,t2);}

/* a1504 in g226 in loop210 in k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1505,3,t0,t1,t2);}
t3=*((C_word*)lf[99]+1);
/* g237238 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,lf[292],t2);}

/* k1476 in g226 in loop210 in k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_1481(2,t3,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 113  broken */
t3=((C_word*)t0)[3];
f_1375(t3,t2,((C_word*)t0)[2]);}}

/* k1479 in k1476 in g226 in loop210 in k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1492,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1491 in k1479 in k1476 in g226 in loop210 in k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1492,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t2,t4));}

/* a1485 in k1479 in k1476 in g226 in loop210 in k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1486,2,t0,t1);}
/* chicken-install.scm: 114  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[291]))(4,*((C_word*)lf[291]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1439 in k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 109  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),((C_word*)t0)[2],C_retrieve2(lf[18],"main#*mappings*"),t1);}

/* k1435 in k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[18] /* (set! main#*mappings* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1417 in k1404 in g196 in loop189 in k1390 in k1551 in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* broken in k1371 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1375(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1375,NULL,3,t0,t1,t2);}
/* chicken-install.scm: 96   error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),t1,lf[288],((C_word*)t0)[2],t2);}

/* k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3637,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 507  regexp */
((C_proc3)C_retrieve_symbol_proc(lf[182]))(3,*((C_word*)lf[182]+1),t4,lf[287]);}

/* k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3645,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3645(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3645(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3645,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t4=t1;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3122,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3481,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3485,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 408  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[156]))(2,*((C_word*)lf[156]+1),t7);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3693,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 513  glob */
((C_proc3)C_retrieve_symbol_proc(lf[185]))(3,*((C_word*)lf[185]+1),t5,lf[234]);}
else{
t5=t4;
f_3661(2,t5,C_SCHEME_UNDEFINED);}}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[235]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_3773(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[285]);
t8=t6;
f_3773(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[286])));}}}

/* k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3773,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 475  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t3,lf[236]);}
else{
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[237]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3785,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3792,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 537  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[156]))(2,*((C_word*)lf[156]+1),t3);}
else{
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[238]))){
t2=lf[2] /* main#*force* */ =C_SCHEME_TRUE;;
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 541  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3645(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[239]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[240]));
if(C_truep(t3)){
t4=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t5=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 544  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3645(t6,((C_word*)t0)[8],t5,((C_word*)t0)[4]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[241]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[242]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3835,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 546  setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[211]))(3,*((C_word*)lf[211]+1),t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[243]);
t7=(C_truep(t6)?t6:(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[244]));
if(C_truep(t7)){
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_TRUE;;
t9=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 550  loop */
t10=((C_word*)((C_word*)t0)[5])[1];
f_3645(t10,((C_word*)t0)[8],t9,((C_word*)t0)[4]);}
else{
t8=(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[245]);
t9=(C_truep(t8)?t8:(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[246]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3871,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t11))){
t12=t10;
f_3871(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4851,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 475  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t12,lf[236]);}}
else{
t10=(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[247]);
t11=(C_truep(t10)?t10:(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[248]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t13))){
t14=t12;
f_3904(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4856,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 475  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t14,lf[236]);}}
else{
t12=(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[249]);
t13=(C_truep(t12)?t12:(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[250]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=t14;
f_3941(2,t16,C_SCHEME_UNDEFINED);}
else{
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4861,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 475  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t16,lf[236]);}}
else{
t14=(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[253]);
t15=(C_truep(t14)?t14:(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[254]));
if(C_truep(t15)){
t16=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t17=lf[7] /* main#*no-install* */ =C_SCHEME_TRUE;;
t18=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 571  loop */
t19=((C_word*)((C_word*)t0)[5])[1];
f_3645(t19,((C_word*)t0)[8],t18,((C_word*)t0)[4]);}
else{
t16=(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[255]);
t17=(C_truep(t16)?t16:(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[256]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 573  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t19);}
else{
t18=(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[257]);
t19=(C_truep(t18)?t18:(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[258]));
if(C_truep(t19)){
t20=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t21=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 577  loop */
t22=((C_word*)((C_word*)t0)[5])[1];
f_3645(t22,((C_word*)t0)[8],t21,((C_word*)t0)[4]);}
else{
t20=(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[259]);
t21=(C_truep(t20)?t20:(C_word)C_i_string_equal_p(((C_word*)t0)[7],lf[260]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4045,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_4045(2,t24,C_SCHEME_UNDEFINED);}
else{
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4868,a[2]=t22,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 475  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t24,lf[236]);}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[267],((C_word*)t0)[7]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4074,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_4074(2,t24,C_SCHEME_UNDEFINED);}
else{
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4881,a[2]=t22,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 475  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t24,lf[236]);}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[269],((C_word*)t0)[7]))){
t22=lf[5] /* main#*run-tests* */ =C_SCHEME_TRUE;;
t23=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 594  loop */
t24=((C_word*)((C_word*)t0)[5])[1];
f_3645(t24,((C_word*)t0)[8],t23,((C_word*)t0)[4]);}
else{
t22=(C_word)C_i_string_equal_p(lf[270],((C_word*)t0)[7]);
t23=(C_truep(t22)?t22:(C_word)C_i_string_equal_p(lf[271],((C_word*)t0)[7]));
if(C_truep(t23)){
t24=lf[4] /* main#*host-extension* */ =C_SCHEME_TRUE;;
t25=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 598  loop */
t26=((C_word*)((C_word*)t0)[5])[1];
f_3645(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[272],((C_word*)t0)[7]))){
t24=lf[19] /* main#*deploy* */ =C_SCHEME_TRUE;;
t25=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 601  loop */
t26=((C_word*)((C_word*)t0)[5])[1];
f_3645(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[273],((C_word*)t0)[7]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t25))){
t26=t24;
f_4177(2,t26,C_SCHEME_UNDEFINED);}
else{
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4886,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 475  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t26,lf[236]);}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[274],((C_word*)t0)[7]))){
t24=lf[20] /* main#*trunk* */ =C_SCHEME_TRUE;;
t25=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* chicken-install.scm: 608  loop */
t26=((C_word*)((C_word*)t0)[5])[1];
f_3645(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[275],((C_word*)t0)[7]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4221,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t25))){
t26=t24;
f_4221(2,t26,C_SCHEME_UNDEFINED);}
else{
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4891,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 475  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t26,lf[236]);}}
else{
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t25=(C_word)C_i_string_length(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_positivep(t25))){
t26=(C_word)C_i_string_ref(((C_word*)t0)[7],C_fix(0));
t27=t24;
f_4248(t27,(C_word)C_eqp(C_make_character(45),t26));}
else{
t26=t24;
f_4248(t26,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}

/* k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_4248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4248,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4257,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4295,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 616  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[280]+1)))(4,*((C_word*)lf[280]+1),t4,((C_word*)t0)[7],C_fix(1));}
else{
t3=((C_word*)t0)[5];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4901,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 475  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t4,lf[236]);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm: 621  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[284]))(3,*((C_word*)lf[284]+1),t2,((C_word*)t0)[7]);}}

/* k4396 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(lf[281],t1))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 622  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4356,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 636  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k4354 in k4396 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4356,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* g12091210 */
t3=t2;
f_4360(t3,((C_word*)t0)[3],t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
/* chicken-install.scm: 639  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3645(t4,((C_word*)t0)[3],t2,t3);}}

/* g1209 in k4354 in k4396 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_4360(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4360,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4372,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_caddr(t2);
/* chicken-install.scm: 638  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[39]))(5,*((C_word*)lf[39]+1),t4,t5,t6,((C_word*)t0)[2]);}

/* k4370 in g1209 in k4354 in k4396 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 638  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3645(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4309 in k4396 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4334,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 627  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),t3,((C_word*)t0)[2]);}

/* k4332 in k4309 in k4396 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4343,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 629  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[252]))(3,*((C_word*)lf[252]+1),t3,t1);}
else{
/* chicken-install.scm: 632  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t2);}}

/* k4341 in k4332 in k4309 in k4396 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4343,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=(C_word)C_a_i_list(&a,2,t2,lf[282]);
/* chicken-install.scm: 624  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[39]))(5,*((C_word*)lf[39]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 631  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t2);}}

/* k4348 in k4341 in k4332 in k4309 in k4396 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 631  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4335 in k4332 in k4309 in k4396 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4337,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[282]);
/* chicken-install.scm: 624  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[39]))(5,*((C_word*)lf[39]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));}

/* k4313 in k4309 in k4396 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4315,2,t0,t1);}
t2=C_mutate(&lf[33] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* chicken-install.scm: 635  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3645(t5,((C_word*)t0)[2],t3,t4);}

/* f4901 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 500  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}

/* k4293 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[279]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4255 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4291,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 617  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[277]))(5,*((C_word*)lf[277]+1),t2,*((C_word*)lf[99]+1),lf[278],t1);}

/* k4289 in k4255 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4291,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4270,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4274,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4280,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f4896,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 475  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t3,lf[236]);}}

/* f4896 in k4289 in k4255 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 500  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}

/* a4279 in k4289 in k4255 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4280,3,t0,t1,t2);}
t3=*((C_word*)lf[276]+1);
/* g12031204 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(45),t2);}

/* k4272 in k4289 in k4255 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-install.scm: 618  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1,t2);}

/* k4268 in k4289 in k4255 in k4246 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 618  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3645(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f4891 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 500  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}

/* k4219 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[9] /* (set! main#*password* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 612  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3645(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* f4886 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 500  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}

/* k4175 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[8] /* (set! main#*username* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 605  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3645(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* f4881 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 500  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}

/* k4072 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 584  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t2,lf[268],t3);}

/* k4075 in k4072 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4077,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=(C_word)C_i_cadr(t2);
t4=C_mutate(&lf[15] /* (set! main#*proxy-host* ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_caddr(t2);
/* chicken-install.scm: 587  string->number */
C_string_to_number(3,0,t5,t6);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[15] /* (set! main#*proxy-host* ...) */,t2);
t4=lf[16] /* main#*proxy-port* */ =C_fix(80);;
t5=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 591  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3645(t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}}

/* k4095 in k4075 in k4072 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[16] /* (set! main#*proxy-port* ...) */,t1);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 591  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3645(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* f4868 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 500  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}

/* k4043 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1621,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 136  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[156]))(2,*((C_word*)lf[156]+1),t4);}

/* k1619 in k4043 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1621,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))?lf[261]:lf[262]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1627,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 140  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t3,lf[265],((C_word*)t0)[3],lf[266]);}

/* k1625 in k1619 in k4043 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1627,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1632,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1632(t5,((C_word*)t0)[2],lf[264]);}

/* loop286 in k1625 in k1619 in k4043 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1632(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1632,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1659,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g293294 */
t6=t3;
f_1640(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1657 in loop286 in k1625 in k1619 in k4043 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1632(t3,((C_word*)t0)[2],t2);}

/* g293 in loop286 in k1625 in k1619 in k4043 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1640(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1640,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1656,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 143  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),t4,((C_word*)t0)[2],t2);}

/* k1654 in g293 in loop286 in k1625 in k1619 in k4043 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 143  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[206]))(3,*((C_word*)lf[206]+1),((C_word*)t0)[2],t1);}

/* k1646 in g293 in loop286 in k1625 in k1619 in k4043 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1652,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 143  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[206]))(3,*((C_word*)lf[206]+1),t2,((C_word*)t0)[2]);}

/* k1650 in k1646 in g293 in loop286 in k1625 in k1619 in k4043 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1652,2,t0,t1);}
/* chicken-install.scm: 143  command */
f_3611(((C_word*)t0)[4],lf[263],(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4046 in k4043 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 581  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(0));}

/* k4014 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 573  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),((C_word*)t0)[2],t1);}

/* k4007 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 574  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(0));}

/* f4861 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 500  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}

/* k3939 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3958,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm: 563  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[252]))(3,*((C_word*)lf[252]+1),t4,t2);}

/* k3956 in k3939 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3958,2,t0,t1);}
if(C_truep(t1)){
t2=C_mutate(&lf[3] /* (set! main#*prefix* ...) */,((C_word*)t0)[7]);
t3=(C_word)C_i_cddr(((C_word*)t0)[6]);
/* chicken-install.scm: 567  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3645(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 566  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t3);}}

/* k3967 in k3956 in k3939 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 566  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3963 in k3956 in k3939 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 565  normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[251]))(3,*((C_word*)lf[251]+1),((C_word*)t0)[2],t1);}

/* k3946 in k3939 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[3] /* (set! main#*prefix* ...) */,t1);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 567  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3645(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* f4856 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f4856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 500  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}

/* k3902 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 557  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[178]+1)))(3,*((C_word*)lf[178]+1),t2,t3);}

/* k3906 in k3902 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,t1);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 558  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3645(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* f4851 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f4851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 500  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}

/* k3869 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[11] /* (set! main#*default-location* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 554  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3645(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k3833 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 547  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3645(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k3790 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 537  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),((C_word*)t0)[2],t1);}

/* k3783 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 538  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(0));}

/* f4846 in k3771 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f4846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 500  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(0));}

/* k3691 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3693,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3707,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3709,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_3709(t11,t7,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 522  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[233]);}}

/* k3756 in k3691 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 523  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}

/* loop1021 in k3691 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3709(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3709,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3744,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 518  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3742 in loop1021 in k3691 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3744,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[230],lf[231]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t5=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t4);
t6=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10211034 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3709(t8,((C_word*)t0)[3],t7);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10211034 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3709(t8,((C_word*)t0)[3],t7);}}

/* k3705 in k3691 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 516  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));}

/* k3701 in k3691 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[33] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=((C_word*)t0)[2];
f_3661(2,t3,t2);}

/* k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3664,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3664(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3678,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[12],"main#*default-transport*"))){
if(C_truep(C_retrieve2(lf[11],"main#*default-location*"))){
t4=C_SCHEME_UNDEFINED;
t5=t2;
f_3664(2,t5,t4);}
else{
/* chicken-install.scm: 528  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t2,lf[228]);}}
else{
/* chicken-install.scm: 526  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t3,lf[229]);}}}

/* k3676 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve2(lf[11],"main#*default-location*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3664(2,t3,t2);}
else{
/* chicken-install.scm: 528  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),((C_word*)t0)[2],lf[228]);}}

/* k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3671,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3675,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 529  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t3,((C_word*)t0)[2]);}

/* k3673 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 529  apply-mappings */
f_3487(((C_word*)t0)[2],t1);}

/* k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3671,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2900,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 365  retrieve */
f_2261(t3,t1);}

/* k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2906,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3101,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 367  topological-sort */
((C_proc4)C_retrieve_symbol_proc(lf[227]))(4,*((C_word*)lf[227]+1),t3,C_retrieve2(lf[34],"main#*dependencies*"),*((C_word*)lf[140]+1));}}

/* k3099 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 367  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t1);}

/* k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2906,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_retrieve2(lf[2],"main#*force*");
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2912,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 370  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t4,lf[226]);}

/* k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 371  pp */
((C_proc3)C_retrieve_symbol_proc(lf[225]))(3,*((C_word*)lf[225]+1),t2,((C_word*)t0)[2]);}

/* k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3093,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[224]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3092 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3093,3,t0,t1,t2);}
t3=*((C_word*)lf[223]+1);
/* g768769 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));}

/* k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2926,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 400  iota */
((C_proc4)C_retrieve_symbol_proc(lf[222]))(4,*((C_word*)lf[222]+1),t2,((C_word*)t0)[4],C_fix(1));}

/* k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2928,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2928(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2928(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2928,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3066,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* g702703 */
t10=t6;
f_2936(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3064 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2928(t4,((C_word*)t0)[2],t2,t3);}

/* g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2936(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2936,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2940,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t6=t5;
f_3025(t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_nequalp(t3,C_fix(1));
t7=t5;
f_3025(t7,(C_truep(t6)?(C_word)C_i_greaterp(((C_word*)t0)[3],C_fix(1)):C_SCHEME_FALSE));}}

/* k3023 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3025,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[7],"main#*no-install*"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3047,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 378  setup-api#yes-or-no? */
((C_proc3)C_retrieve_symbol_proc(lf[60]))(3,*((C_word*)lf[60]+1),t3,lf[221]);}
else{
t3=t2;
f_3031(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_2940(2,t2,C_SCHEME_UNDEFINED);}}

/* k3045 in k3023 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3031(t2,(C_word)C_i_not(t1));}

/* k3029 in k3023 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3031(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3031,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 382  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[220]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_2940(2,t3,t2);}}

/* k3032 in k3029 in k3023 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 383  cleanup */
f_3103(t2);}

/* k3035 in k3032 in k3029 in k3023 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 384  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}

/* k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* chicken-install.scm: 385  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[53]+1)))(7,*((C_word*)lf[53]+1),t2,lf[218],t3,C_make_character(58),t4,lf[219]);}

/* k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 386  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t2,lf[217],t3);}

/* k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2946,2,t0,t1);}
t2=C_retrieve(lf[123]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2950,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t8=*((C_word*)lf[180]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],t6,t7,t6);}

/* a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_lessp(((C_word*)t0)[3],((C_word*)t0)[2]);
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2791,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2891,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 349  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t6,lf[87]);}

/* k2889 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_retrieve2(lf[4],"main#*host-extension*");
t3=((C_word*)t0)[2];
f_2791(t3,(C_truep(t2)?lf[215]:lf[216]));}
else{
t2=((C_word*)t0)[2];
f_2791(t2,lf[215]);}}

/* k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2791(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2791,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[175]))(2,*((C_word*)lf[175]+1),t2);}

/* k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2798,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[173]+1)))(4,*((C_word*)lf[173]+1),t2,lf[214],t1);}

/* k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[173]+1)))(4,*((C_word*)lf[173]+1),t2,t3,((C_word*)t0)[2]);}

/* k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[173]+1)))(4,*((C_word*)lf[173]+1),t2,lf[213],((C_word*)t0)[2]);}

/* k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[173]+1)))(4,*((C_word*)lf[173]+1),t2,t3,((C_word*)t0)[2]);}

/* k2805 in k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[173]+1)))(4,*((C_word*)lf[173]+1),t2,lf[212],((C_word*)t0)[2]);}

/* k2808 in k2805 in k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2813,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),t2,((C_word*)t0)[2]);}

/* k2811 in k2808 in k2805 in k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 355  setup-api#sudo-install */
((C_proc2)C_retrieve_symbol_proc(lf[211]))(2,*((C_word*)lf[211]+1),t2);}

/* k2875 in k2811 in k2808 in k2805 in k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(C_truep(t1)?lf[194]:lf[195]);
t3=(C_truep(C_retrieve2(lf[1],"main#*keep*"))?lf[196]:lf[197]);
t4=(C_truep(C_retrieve2(lf[7],"main#*no-install*"))?(C_truep(((C_word*)t0)[6])?lf[198]:lf[199]):lf[198]);
t5=(C_truep(C_retrieve2(lf[4],"main#*host-extension*"))?lf[200]:lf[201]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2833,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_retrieve2(lf[3],"main#*prefix*"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2856,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[175]))(2,*((C_word*)lf[175]+1),t7);}
else{
t7=t6;
f_2833(2,t7,lf[210]);}}

/* k2854 in k2875 in k2811 in k2808 in k2805 in k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2859,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[173]+1)))(4,*((C_word*)lf[173]+1),t2,lf[209],t1);}

/* k2857 in k2854 in k2875 in k2811 in k2808 in k2805 in k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[173]+1)))(4,*((C_word*)lf[173]+1),t2,C_retrieve2(lf[3],"main#*prefix*"),((C_word*)t0)[2]);}

/* k2860 in k2857 in k2854 in k2875 in k2811 in k2808 in k2805 in k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[173]+1)))(4,*((C_word*)lf[173]+1),t2,lf[208],((C_word*)t0)[2]);}

/* k2863 in k2860 in k2857 in k2854 in k2875 in k2811 in k2808 in k2805 in k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2831 in k2875 in k2811 in k2808 in k2805 in k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2833,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[19],"main#*deploy*"))?lf[202]:lf[203]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2841,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2845,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 362  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[96]))(5,*((C_word*)lf[96]+1),t4,t5,t6,lf[207]);}

/* k2843 in k2831 in k2875 in k2811 in k2808 in k2805 in k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 362  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[206]))(3,*((C_word*)lf[206]+1),((C_word*)t0)[2],t1);}

/* k2839 in k2831 in k2875 in k2811 in k2808 in k2805 in k2802 in k2799 in k2796 in k2793 in k2789 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 346  conc */
((C_proc15)C_retrieve_symbol_proc(lf[67]))(15,*((C_word*)lf[67]+1),((C_word*)t0)[10],C_retrieve2(lf[36],"main#*csi*"),lf[204],((C_word*)t0)[9],lf[205],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_make_character(32),t1);}

/* k2965 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2970,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 389  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t2,lf[193],t1);}

/* k2968 in k2965 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 390  $system */
f_3589(t2,((C_word*)t0)[2]);}

/* k2971 in k2968 in k2965 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2997,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 392  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),t3,lf[192]);}
else{
t3=t2;
f_2979(2,t3,C_SCHEME_FALSE);}}

/* k2995 in k2971 in k2968 in k2965 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 393  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[190]))(3,*((C_word*)lf[190]+1),t2,lf[191]);}
else{
t2=((C_word*)t0)[2];
f_2979(2,t2,C_SCHEME_FALSE);}}

/* k3001 in k2995 in k2971 in k2968 in k2965 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 394  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[189]);}
else{
t2=((C_word*)t0)[2];
f_2979(2,t2,C_SCHEME_FALSE);}}

/* k2977 in k2971 in k2968 in k2965 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
if(C_truep(t1)){
t2=lf[17] /* main#*running-test* */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 396  current-directory */
((C_proc3)C_retrieve_symbol_proc(lf[123]))(3,*((C_word*)lf[123]+1),t3,lf[188]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2981 in k2977 in k2971 in k2968 in k2965 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 397  command */
f_3611(t2,lf[187],(C_word)C_a_i_list(&a,2,C_retrieve2(lf[36],"main#*csi*"),t3));}

/* k2984 in k2981 in k2977 in k2971 in k2968 in k2965 in a2962 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[17] /* main#*running-test* */ =C_SCHEME_FALSE;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* swap718 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* g721722725 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2952 in swap718 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g721722725 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k2955 in k2952 in swap718 in k2944 in k2941 in k2938 in g702 in loop691 in k2924 in k2920 in k2913 in k2910 in k2904 in k2898 in k3669 in k3662 in k3659 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3483 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 408  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[2],t1,lf[186]);}

/* k3479 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 408  glob */
((C_proc3)C_retrieve_symbol_proc(lf[185]))(3,*((C_word*)lf[185]+1),((C_word*)t0)[2],t1);}

/* k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3125,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 409  setup-api#create-temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[184]))(2,*((C_word*)lf[184]+1),t2);}

/* k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3128,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 410  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),t2,t1,C_retrieve2(lf[21],"main#constant174"));}

/* k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3131,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 411  regexp */
((C_proc3)C_retrieve_symbol_proc(lf[182]))(3,*((C_word*)lf[182]+1),t2,lf[183]);}

/* k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3134,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 412  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[181]);}

/* k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3134,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3137,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3351,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3474,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[180]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a3473 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[170]));
t3=C_mutate((C_word*)lf[170]+1 /* (set! warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3356,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3362,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3362(t5,t1,((C_word*)t0)[2]);}

/* loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3362(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3362,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3461,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g805806 */
t6=t3;
f_3370(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3459 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3362(t3,((C_word*)t0)[2],t2);}

/* g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3370(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3370,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3374,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 416  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t3,((C_word*)t0)[2],t2);}

/* k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3382,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t2,t3);}

/* a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3382,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3388,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3420,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t1,t3,t4);}

/* a3419 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3426,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3447 in a3419 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3448r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3448r(t0,t1,t2);}}

static void C_ccall f_3448r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3454,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k809814 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3453 in a3447 in a3419 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3425 in a3419 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3442,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 421  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[178]+1)))(3,*((C_word*)lf[178]+1),t2,t3);}

/* k3440 in a3425 in a3419 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[176],t2);
/* chicken-install.scm: 421  eval */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),((C_word*)t0)[2],t3);}

/* a3387 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3388,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3394,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k809814 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3393 in a3387 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 419  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[153]))(2,*((C_word*)lf[153]+1),t2);}

/* k3400 in a3393 in a3387 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3406,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[175]))(2,*((C_word*)lf[175]+1),t2);}

/* k3404 in k3400 in a3393 in a3387 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[173]+1)))(4,*((C_word*)lf[173]+1),t2,lf[174],t1);}

/* k3407 in k3404 in k3400 in a3393 in a3387 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3412,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[173]+1)))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3410 in k3407 in k3404 in k3400 in a3393 in a3387 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[172]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k3413 in k3410 in k3407 in k3404 in k3400 in a3393 in a3387 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3418,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),t2,((C_word*)t0)[2]);}

/* k3416 in k3413 in k3410 in k3407 in k3404 in k3400 in a3393 in a3387 in a3381 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 418  print-error-message */
((C_proc5)C_retrieve_symbol_proc(lf[107]))(5,*((C_word*)lf[107]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3375 in k3372 in g805 in loop798 in a3355 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g812813 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a3350 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3351,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[170]));
t3=C_mutate((C_word*)lf[170]+1 /* (set! warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 423  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[169]);}

/* k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3204,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3228,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 426  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),t3,t4,C_retrieve(lf[168]));}

/* a3227 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3228,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3235,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 429  ##sys#module-name */
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),t4,t3);}

/* k3233 in a3227 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 430  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[165]+1)))(4,*((C_word*)lf[165]+1),t2,lf[166],t1);}

/* k3236 in k3233 in a3227 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3248 in k3236 in k3233 in a3227 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3249,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3257,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3307,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_3307(t13,t9,t4);}

/* loop854 in a3248 in k3236 in k3233 in a3227 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3307,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_3334(C_a_i(&a,9),t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop854867 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop854867 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g870 in loop854 in a3248 in k3236 in k3233 in a3227 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static C_word C_fcall f_3334(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_car(t1);
return((C_word)C_a_i_list(&a,3,t2,lf[164],((C_word*)t0)[2]));}

/* k3255 in a3248 in k3236 in k3233 in a3227 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3257,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3261,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3263,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3263(t10,t6,((C_word*)t0)[2]);}

/* loop878 in k3255 in a3248 in k3236 in k3233 in a3227 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3263(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3263,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_3290(C_a_i(&a,9),t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop878891 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=(C_word)C_slot(t2,C_fix(1));
/* loop878891 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g894 in loop878 in k3255 in a3248 in k3236 in k3233 in a3227 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static C_word C_fcall f_3290(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_car(t1);
return((C_word)C_a_i_list(&a,3,t2,lf[163],((C_word*)t0)[2]));}

/* k3259 in k3255 in a3248 in k3236 in k3233 in a3227 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 432  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3242 in k3236 in k3233 in a3227 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
/* chicken-install.scm: 431  ##sys#module-exports */
((C_proc3)C_retrieve_symbol_proc(lf[162]))(3,*((C_word*)lf[162]+1),t1,((C_word*)t0)[2]);}

/* k3202 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3206,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 425  sort */
((C_proc4)C_retrieve_symbol_proc(lf[161]))(4,*((C_word*)lf[161]+1),((C_word*)t0)[2],t1,t2);}

/* a3205 in k3202 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3206,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3214,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-install.scm: 437  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[160]+1)))(3,*((C_word*)lf[160]+1),t4,t5);}

/* k3212 in a3205 in k3202 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3218,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 437  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[160]+1)))(3,*((C_word*)lf[160]+1),t2,t3);}

/* k3216 in k3212 in a3205 in k3202 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 437  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[159]+1)))(4,*((C_word*)lf[159]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3141 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3146,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 438  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[154]+1)))(2,*((C_word*)lf[154]+1),t2);}

/* k3144 in k3141 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3165,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 439  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),t2,((C_word*)t0)[3],t3);}

/* a3164 in k3144 in k3141 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3165,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3171,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3171(t5,t1,((C_word*)t0)[2]);}

/* loop905 in a3164 in k3144 in k3141 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3171(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3171,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3189,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 441  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[157]+1)))(3,*((C_word*)lf[157]+1),t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3181 in loop905 in a3164 in k3144 in k3141 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 441  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[154]+1)))(2,*((C_word*)lf[154]+1),((C_word*)t0)[2]);}

/* k3187 in loop905 in a3164 in k3144 in k3141 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3171(t3,((C_word*)t0)[2],t2);}

/* k3147 in k3144 in k3141 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3152,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3159,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3163,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 442  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[156]))(2,*((C_word*)lf[156]+1),t4);}

/* k3161 in k3147 in k3144 in k3141 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 442  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[96]))(4,*((C_word*)lf[96]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[21],"main#constant174"));}

/* k3157 in k3147 in k3144 in k3141 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 442  setup-api#copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[155]))(4,*((C_word*)lf[155]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3150 in k3147 in k3144 in k3141 in k3138 in k3135 in k3132 in k3129 in k3126 in k3123 in k3120 in loop in k3638 in k3635 in k4525 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 443  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[135]))(3,*((C_word*)lf[135]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4518 in a4515 in a4509 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 650  cleanup */
f_3103(((C_word*)t0)[2]);}

/* a4476 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4477,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4483,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k12131218 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4482 in a4476 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4508,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 645  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[153]))(2,*((C_word*)lf[153]+1),t3);}

/* k4506 in a4482 in a4476 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 645  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[154]+1)))(3,*((C_word*)lf[154]+1),((C_word*)t0)[2],t1);}

/* k4485 in a4482 in a4476 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4504,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 646  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[153]))(2,*((C_word*)lf[153]+1),t3);}

/* k4502 in k4485 in a4482 in a4476 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 646  print-error-message */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4488 in k4485 in a4482 in a4476 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 647  cleanup */
f_3103(t2);}

/* k4491 in k4488 in k4485 in a4482 in a4476 in a4470 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[17],"main#*running-test*"))){
/* chicken-install.scm: 648  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(2));}
else{
/* chicken-install.scm: 648  exit */
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),((C_word*)t0)[2],C_fix(1));}}

/* k4458 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* g12161217 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4461 in k4458 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4469,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[151]))(2,*((C_word*)lf[151]+1),t3);}

/* k4467 in k4461 in k4458 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4464 in k4461 in k4458 in k4455 in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_4466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#command in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3611(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3611,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3615,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t4,*((C_word*)lf[150]+1),t2,t3);}

/* k3613 in main#command in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3618,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 471  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t2,lf[149],t1);}

/* k3616 in k3613 in main#command in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 472  $system */
f_3589(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* main#$system in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3589(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3589,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3593,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3606,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))){
/* chicken-install.scm: 464  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),t4,lf[146],t2,lf[147]);}
else{
t5=t2;
/* chicken-install.scm: 462  system */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,t5);}}

/* k3604 in main#$system in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 462  system */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),((C_word*)t0)[2],t1);}

/* k3591 in main#$system in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* chicken-install.scm: 467  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),((C_word*)t0)[3],lf[144],t1,((C_word*)t0)[2]);}}

/* main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3487(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3487,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3505,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3512,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3514,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 450  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[142]))(4,*((C_word*)lf[142]+1),t4,t5,t2);}

/* a3513 in main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3514,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3518,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3573,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 452  find */
((C_proc4)C_retrieve_symbol_proc(lf[141]))(4,*((C_word*)lf[141]+1),t3,t4,C_retrieve2(lf[18],"main#*mappings*"));}

/* a3572 in a3513 in main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3573,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3579,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(t2);
/* chicken-install.scm: 452  find */
((C_proc4)C_retrieve_symbol_proc(lf[141]))(4,*((C_word*)lf[141]+1),t1,t3,t4);}

/* a3578 in a3572 in a3513 in main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3579,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3498,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 447  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t4,t3);}

/* k3496 in a3578 in a3572 in a3513 in main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3502,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 447  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2]);}

/* k3500 in k3496 in a3578 in a3572 in a3513 in main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_equal_p(((C_word*)t0)[2],t1));}

/* k3516 in a3513 in main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3518,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=t1;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_i_cdr(t3);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3532,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_3532(t12,t2,t8);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* loop954 in k3516 in a3513 in main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3532(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3532,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[28]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3561,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g970971 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3559 in loop954 in k3516 in a3513 in main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3561,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop954967 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3532(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop954967 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3532(t6,((C_word*)t0)[3],t5);}}

/* k3510 in main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 449  delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[139]))(4,*((C_word*)lf[139]+1),((C_word*)t0)[2],t1,*((C_word*)lf[140]+1));}

/* k3503 in main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3508,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 458  print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[53]+1)))(6,*((C_word*)lf[53]+1),t2,lf[137],((C_word*)t0)[2],lf[138],t1);}

/* k3506 in k3503 in main#apply-mappings in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* main#cleanup in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_3103(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3103,NULL,1,t1);}
if(C_truep(C_retrieve2(lf[1],"main#*keep*"))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 404  setup-download#temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[136]))(2,*((C_word*)lf[136]+1),t2);}}

/* k3108 in main#cleanup in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 405  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[135]))(3,*((C_word*)lf[135]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2261(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2261,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2265,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 267  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t3,lf[133]);}

/* k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2535,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2535(t6,t2,((C_word*)t0)[2]);}

/* loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2535(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2535,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2613,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_assoc(t4,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2560,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 273  delete */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t6,t5,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"),*((C_word*)lf[99]+1));}
else{
t6=(C_word)C_i_pairp(t4);
t7=(C_truep(t6)?(C_word)C_i_car(t4):t4);
t8=(C_word)C_i_pairp(t4);
t9=(C_truep(t8)?(C_word)C_i_cdr(t4):C_SCHEME_FALSE);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2574,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2580,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t3,t10,t11);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a2579 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2580,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2584,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=t4;
f_2584(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 278  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t4,lf[132]);}}

/* k2582 in a2579 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 279  print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[53]+1)))(6,*((C_word*)lf[53]+1),t2,lf[130],((C_word*)t0)[5],lf[131],((C_word*)t0)[4]);}

/* k2585 in k2582 in a2579 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2587,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));
t4=C_mutate(&lf[33] /* (set! main#*eggs+dirs+vers* ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2102,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(C_retrieve2(lf[11],"main#*default-location*"))?C_retrieve2(lf[12],"main#*default-transport*"):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[11],"main#*default-location*"),C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[128],t4);
t6=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[12],"main#*default-transport*"),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[126],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=t2;
f_2102(t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}
else{
t4=C_retrieve2(lf[10],"main#*default-sources*");
t5=t2;
f_2102(t5,t4);}}

/* k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2102,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2104,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2104(t5,((C_word*)t0)[2],t1);}

/* trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2104(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2104,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken-install.scm: 237  values */
C_values(4,0,t1,C_SCHEME_FALSE,lf[100]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2120,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_i_assq(lf[128],t3);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2168,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t7=t4;
f_2120(t7,(C_word)C_i_cadr(t5));}
else{
/* chicken-install.scm: 240  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),t6,lf[129],t3);}}}

/* k2166 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2120(t2,(C_word)C_i_cadr(t1));}

/* k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2120,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_assq(lf[126],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2158,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t2;
f_2123(t5,(C_word)C_i_cadr(t3));}
else{
/* chicken-install.scm: 242  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),t4,lf[127],((C_word*)t0)[3]);}}

/* k2156 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2123(t2,(C_word)C_i_cadr(t1));}

/* k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2123(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2123,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2133 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2134,4,t0,t1,t2,t3);}
if(C_truep(t2)){
/* chicken-install.scm: 245  values */
C_values(4,0,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1600,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 128  delete */
((C_proc5)C_retrieve_symbol_proc(lf[98]))(5,*((C_word*)lf[98]+1),t4,((C_word*)t0)[2],C_retrieve2(lf[10],"main#*default-sources*"),*((C_word*)lf[99]+1));}}

/* k1598 in a2133 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 248  trying-sources */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2104(t4,((C_word*)t0)[2],t3);}

/* a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2128,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1965,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t4,t5);}

/* a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1970,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1976,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2063,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t1,t3,t4);}

/* a2062 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2082,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2081 in a2062 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2082r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2082r(t0,t1,t2);}}

static void C_ccall f_2082r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2088,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k383388 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2087 in a2081 in a2062 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2068 in a2062 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
/* chicken-install.scm: 214  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t2);}
else{
t3=t2;
f_2077(2,t3,C_SCHEME_FALSE);}}

/* k2075 in a2068 in a2062 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 211  setup-download#retrieve-extension */
((C_proc21)C_retrieve_symbol_proc(lf[114]))(21,*((C_word*)lf[114]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[115],((C_word*)t0)[2],lf[116],t1,lf[117],C_retrieve2(lf[5],"main#*run-tests*"),lf[118],C_retrieve2(lf[8],"main#*username*"),lf[119],C_retrieve2(lf[9],"main#*password*"),lf[120],C_retrieve2(lf[20],"main#*trunk*"),lf[121],C_retrieve2(lf[15],"main#*proxy-host*"),lf[122],C_retrieve2(lf[16],"main#*proxy-port*"));}

/* a1975 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1976,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1982,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k383388 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1981 in a1975 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[101]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1992,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=(C_word)C_i_memv(lf[110],t3);
t6=t4;
f_1992(t6,(C_truep(t5)?(C_word)C_i_memv(lf[113],t3):C_SCHEME_FALSE));}
else{
t5=t4;
f_1992(t5,C_SCHEME_FALSE);}}

/* k1990 in a1981 in a1975 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1992,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1995,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 222  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[103]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memv(lf[110],((C_word*)t0)[2]);
t4=t2;
f_2004(t4,(C_truep(t3)?(C_word)C_i_memv(lf[112],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_2004(t3,C_SCHEME_FALSE);}}}

/* k2002 in k1990 in a1981 in a1975 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2004(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2004,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2007,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 225  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t2,lf[105]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memv(lf[110],((C_word*)t0)[2]);
t4=t2;
f_2016(t4,(C_truep(t3)?(C_word)C_i_memv(lf[111],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_2016(t3,C_SCHEME_FALSE);}}}

/* k2014 in k2002 in k1990 in a1981 in a1975 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2016,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2019,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 228  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[53]+1)))(3,*((C_word*)lf[53]+1),t3,lf[108]);}
else{
t2=((C_word*)t0)[3];
/* chicken-install.scm: 232  abort */
((C_proc3)C_retrieve_symbol_proc(lf[109]))(3,*((C_word*)lf[109]+1),((C_word*)t0)[2],t2);}}

/* k2017 in k2014 in k2002 in k1990 in a1981 in a1975 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2022,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 229  print-error-message */
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),t2,((C_word*)t0)[2]);}

/* k2020 in k2017 in k2014 in k2002 in k1990 in a1981 in a1975 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 230  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[106]);}

/* k2005 in k2002 in k1990 in a1981 in a1975 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 226  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[104]);}

/* k1993 in k1990 in a1981 in a1975 in a1969 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 223  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[102]);}

/* k1963 in a2127 in k2121 in k2118 in trying-sources in k2100 in a2573 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g386387 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2558 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2560,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_mutate(&lf[33] /* (set! main#*eggs+dirs+vers* ...) */,t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2535(t5,((C_word*)t0)[2],t4);}

/* k2611 in loop483 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2535(t3,((C_word*)t0)[2],t2);}

/* k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2276(t5,((C_word*)t0)[2],C_retrieve2(lf[33],"main#*eggs+dirs+vers*"));}}

/* loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2276(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2276,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2522,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_car(t4);
if(C_truep((C_word)C_i_member(t5,C_retrieve2(lf[35],"main#*checked*")))){
t6=(C_word)C_slot(t2,C_fix(1));
t15=t1;
t16=t6;
t1=t15;
t2=t16;
goto loop;}
else{
t6=(C_word)C_i_car(t4);
t7=(C_word)C_a_i_cons(&a,2,t6,C_retrieve2(lf[35],"main#*checked*"));
t8=C_mutate(&lf[35] /* (set! main#*checked* ...) */,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2298,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_cadr(t4);
t11=(C_word)C_i_car(t4);
/* chicken-install.scm: 287  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[96]))(5,*((C_word*)lf[96]+1),t9,t10,t11,lf[97]);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2304,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 288  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),t2,t1);}

/* k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2304,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 289  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[90]))(4,*((C_word*)lf[90]+1),t2,((C_word*)t0)[2],*((C_word*)lf[91]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* chicken-install.scm: 322  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[42]+1)))(6,*((C_word*)lf[42]+1),t2,lf[92],t3,lf[93],lf[94]);}}

/* k2497 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 321  warning */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm: 290  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t2,lf[88],t3,lf[89]);}

/* k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2629,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2639,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 330  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t6,lf[87]);}

/* k2637 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_2313(2,t3,t2);}
else{
t2=(C_word)C_i_assq(lf[78],((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2654(3,t7,((C_word*)t0)[5],t3);}
else{
t3=((C_word*)t0)[5];
f_2313(2,t3,C_SCHEME_FALSE);}}}

/* loop in k2637 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2654,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 334  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t3,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[85],t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=t3;
f_2689(t7,(C_word)C_i_pairp(t6));}
else{
t6=t3;
f_2689(t6,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm: 336  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),t1,lf[86],((C_word*)t0)[2],t3);}}}

/* k2687 in loop in k2637 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2689(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2689,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2702,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 338  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2654(3,t4,t2,t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(lf[80],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 340  every */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_eqp(lf[82],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 342  any? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[83]+1)))(4,*((C_word*)lf[83]+1),t6,((C_word*)((C_word*)t0)[4])[1],t7);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm: 343  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[41]+1)))(5,*((C_word*)lf[41]+1),((C_word*)t0)[7],lf[84],((C_word*)t0)[2],t6);}}}}

/* k2742 in k2687 in loop in k2637 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* chicken-install.scm: 342  fail */
t2=((C_word*)t0)[2];
f_2629(t2,((C_word*)t0)[3]);}}

/* k2716 in k2687 in loop in k2637 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 340  fail */
t2=((C_word*)t0)[3];
f_2629(t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2700 in k2687 in loop in k2637 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* chicken-install.scm: 338  fail */
t2=((C_word*)t0)[2];
f_2629(t2,((C_word*)t0)[3]);}}

/* k2662 in loop in k2637 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* chicken-install.scm: 334  fail */
t2=((C_word*)t0)[2];
f_2629(t2,((C_word*)t0)[3]);}}

/* fail in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2629,NULL,2,t0,t1);}
/* chicken-install.scm: 329  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),t1,lf[77],((C_word*)t0)[2]);}

/* k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm: 292  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t2,lf[75],t3,lf[76]);}

/* k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2327,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2332,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 294  apply-mappings */
f_3487(t6,((C_word*)t5)[1]);}

/* k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2434,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 302  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),t9,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k2432 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2434,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2436(t5,((C_word*)t0)[2],t1);}

/* loop560 in k2432 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2436(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2436,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_car(t4);
t6=t3;
f_2446(t6,(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST));}
else{
t5=t3;
f_2446(t5,(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2444 in loop560 in k2432 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop560573 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2436(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop560573 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2436(t5,((C_word*)t0)[3],t4);}}

/* k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[34],"main#*dependencies*"));
t4=C_mutate(&lf[34] /* (set! main#*dependencies* ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2339,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2418,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 305  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t7,((C_word*)((C_word*)t0)[2])[1],lf[73]);}
else{
t6=t5;
f_2339(2,t6,C_SCHEME_UNDEFINED);}}

/* k2416 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 305  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[2],lf[72],t1);}

/* k2409 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 306  retrieve */
f_2261(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=C_retrieve2(lf[2],"main#*force*");
if(C_truep(t3)){
t4=t2;
f_2345(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2405,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2181,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[2]);
t8=(C_word)C_a_i_list(&a,3,lf[63],t7,lf[64]);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2189,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2191,a[2]=t10,a[3]=t15,a[4]=t12,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_2191(t17,t13,t5);}}
else{
t3=t2;
f_2345(2,t3,C_SCHEME_FALSE);}}

/* loop456 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2191(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2191,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2244,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_car(t4);
/* chicken-install.scm: 260  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),t6,t7);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2242 in loop456 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(lf[27],t1);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):lf[66]);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 258  conc */
((C_proc10)C_retrieve_symbol_proc(lf[67]))(10,*((C_word*)lf[67]+1),((C_word*)t0)[3],lf[68],((C_word*)t0)[2],lf[69],t3,lf[70],t4,lf[71],C_make_character(10));}

/* k2249 in loop456 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2251,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop456469 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2191(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop456469 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2191(t6,((C_word*)t0)[3],t5);}}

/* k2187 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 252  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[65]);}

/* k2179 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 251  string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),((C_word*)t0)[2],t1);}

/* k2403 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 309  setup-api#yes-or-no? */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[2],t1,lf[61]);}

/* k2343 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2345,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 312  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[59]))(3,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2346 in k2343 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2351,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2392,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 313  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t3,t1,lf[58]);}

/* k2390 in k2346 in k2343 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 313  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),((C_word*)t0)[2],lf[56],t1);}

/* k2349 in k2346 in k2343 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2359(t6,t2,((C_word*)t0)[2]);}

/* loop597 in k2349 in k2346 in k2343 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_2359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2359,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2377,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2371,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 316  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[53]+1)))(5,*((C_word*)lf[53]+1),t5,lf[54],t4,lf[55]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2369 in loop597 in k2349 in k2346 in k2343 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 317  setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[52]))(3,*((C_word*)lf[52]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2375 in loop597 in k2349 in k2346 in k2343 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2359(t3,((C_word*)t0)[2],t2);}

/* k2352 in k2349 in k2346 in k2343 in k2337 in k2428 in k2330 in a2326 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 319  retrieve */
f_2261(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1749,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=f_1602(lf[48],t2);
t5=f_1602(lf[49],t2);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
t6=f_1602(lf[50],t2);
/* chicken-install.scm: 160  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t3,t4,t5,t6);}
else{
/* chicken-install.scm: 160  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t3,t4,t5,C_SCHEME_END_OF_LIST);}}

/* k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1754,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1754(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1754(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1754,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1768,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 169  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_symbolp(t5);
t8=(C_truep(t7)?t7:(C_word)C_i_stringp(t5));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1797,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* chicken-install.scm: 174  ext-version */
f_1672(t9,t5);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1810,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_listp(t5))){
t10=(C_word)C_i_length(t5);
if(C_truep((C_word)C_i_nequalp(C_fix(2),t10))){
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_stringp(t11);
if(C_truep(t12)){
t13=t9;
f_1810(t13,t12);}
else{
t13=(C_word)C_i_car(t5);
t14=t9;
f_1810(t14,(C_word)C_i_symbolp(t13));}}
else{
t11=t9;
f_1810(t11,C_SCHEME_FALSE);}}
else{
t10=t9;
f_1810(t10,C_SCHEME_FALSE);}}}}

/* k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1810(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1810,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 180  ext-version */
f_1672(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 197  warning */
((C_proc4)C_retrieve_symbol_proc(lf[46]))(4,*((C_word*)lf[46]+1),t2,lf[47],((C_word*)t0)[2]);}}

/* k1914 in k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 200  loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1754(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1811 in k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1813,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1905,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 183  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 182  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t3,t4);}}

/* k1828 in k1811 in k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1830,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken-install.scm: 182  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1754(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1903 in k1811 in k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 183  setup-api#version>=? */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1899 in k1811 in k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 195  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_1754(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1890,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 184  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t3,t4);}}

/* k1888 in k1899 in k1811 in k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=(C_word)C_i_string_equal_p(lf[40],t1);
t3=(C_truep(t2)?(C_word)C_i_not(C_retrieve2(lf[2],"main#*force*")):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 187  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),t4,lf[43],t5,lf[44]);}
else{
t4=((C_word*)t0)[3];
f_1843(2,t4,C_SCHEME_UNDEFINED);}}

/* k1874 in k1888 in k1899 in k1811 in k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 186  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),((C_word*)t0)[2],t1);}

/* k1841 in k1899 in k1811 in k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1850,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 193  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t3,t4);}

/* k1852 in k1841 in k1899 in k1811 in k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 193  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,t3);}

/* k1856 in k1852 in k1841 in k1899 in k1811 in k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 192  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[39]))(5,*((C_word*)lf[39]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1848 in k1841 in k1899 in k1811 in k1808 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 191  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1754(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1795 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
/* chicken-install.scm: 173  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_1754(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 176  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2]);}}

/* k1802 in k1795 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken-install.scm: 173  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1754(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1766 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1772,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 169  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2]);}

/* k1770 in k1766 in loop in k1747 in a2320 in k2314 in k2311 in k2308 in k2305 in k2302 in k2296 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 169  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2520 in loop528 in k2266 in k2263 in main#retrieve in k1957 in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2276(t3,((C_word*)t0)[2],t2);}

/* main#ext-version in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1672(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1672,NULL,2,t1,t2);}
t3=(C_word)C_eqp(t2,lf[25]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1682,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1682(t5,t3);}
else{
t5=(C_word)C_i_equalp(t2,lf[31]);
if(C_truep(t5)){
t6=t4;
f_1682(t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1722,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 149  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t6,t2);}}}

/* k1720 in main#ext-version in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1682(t2,(C_word)C_i_member(t1,C_retrieve(lf[32])));}

/* k1680 in main#ext-version in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_fcall f_1682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1682,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 150  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1688,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 151  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),t2,((C_word*)t0)[2]);}}

/* k1686 in k1680 in main#ext-version in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
t4=(C_word)C_i_assq(lf[27],t3);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
/* chicken-install.scm: 155  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,t5);}
else{
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[29]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* main#deps in k1344 in k1341 in k1338 in k1333 in k1330 in k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in k1297 in k1294 */
static C_word C_fcall f_1602(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_assq(t1,t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
return((C_truep(t4)?t4:C_SCHEME_END_OF_LIST));}
else{
return(C_SCHEME_END_OF_LIST);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[354] = {
{"toplevel:chicken_install_scm",(void*)C_toplevel},
{"f_1296:chicken_install_scm",(void*)f_1296},
{"f_1299:chicken_install_scm",(void*)f_1299},
{"f_1302:chicken_install_scm",(void*)f_1302},
{"f_1305:chicken_install_scm",(void*)f_1305},
{"f_1308:chicken_install_scm",(void*)f_1308},
{"f_1311:chicken_install_scm",(void*)f_1311},
{"f_1314:chicken_install_scm",(void*)f_1314},
{"f_1317:chicken_install_scm",(void*)f_1317},
{"f_1320:chicken_install_scm",(void*)f_1320},
{"f_1323:chicken_install_scm",(void*)f_1323},
{"f_1326:chicken_install_scm",(void*)f_1326},
{"f_1329:chicken_install_scm",(void*)f_1329},
{"f_1332:chicken_install_scm",(void*)f_1332},
{"f_1335:chicken_install_scm",(void*)f_1335},
{"f_1340:chicken_install_scm",(void*)f_1340},
{"f_1343:chicken_install_scm",(void*)f_1343},
{"f_1346:chicken_install_scm",(void*)f_1346},
{"f_4547:chicken_install_scm",(void*)f_4547},
{"f_4543:chicken_install_scm",(void*)f_4543},
{"f_1959:chicken_install_scm",(void*)f_1959},
{"f_4457:chicken_install_scm",(void*)f_4457},
{"f_4471:chicken_install_scm",(void*)f_4471},
{"f_4510:chicken_install_scm",(void*)f_4510},
{"f_4529:chicken_install_scm",(void*)f_4529},
{"f_4535:chicken_install_scm",(void*)f_4535},
{"f_4516:chicken_install_scm",(void*)f_4516},
{"f_4527:chicken_install_scm",(void*)f_4527},
{"f_1557:chicken_install_scm",(void*)f_1557},
{"f_1373:chicken_install_scm",(void*)f_1373},
{"f_1553:chicken_install_scm",(void*)f_1553},
{"f_1392:chicken_install_scm",(void*)f_1392},
{"f_1394:chicken_install_scm",(void*)f_1394},
{"f_1538:chicken_install_scm",(void*)f_1538},
{"f_1402:chicken_install_scm",(void*)f_1402},
{"f_1406:chicken_install_scm",(void*)f_1406},
{"f_1447:chicken_install_scm",(void*)f_1447},
{"f_1512:chicken_install_scm",(void*)f_1512},
{"f_1474:chicken_install_scm",(void*)f_1474},
{"f_1505:chicken_install_scm",(void*)f_1505},
{"f_1478:chicken_install_scm",(void*)f_1478},
{"f_1481:chicken_install_scm",(void*)f_1481},
{"f_1492:chicken_install_scm",(void*)f_1492},
{"f_1486:chicken_install_scm",(void*)f_1486},
{"f_1441:chicken_install_scm",(void*)f_1441},
{"f_1437:chicken_install_scm",(void*)f_1437},
{"f_1419:chicken_install_scm",(void*)f_1419},
{"f_1375:chicken_install_scm",(void*)f_1375},
{"f_3637:chicken_install_scm",(void*)f_3637},
{"f_3640:chicken_install_scm",(void*)f_3640},
{"f_3645:chicken_install_scm",(void*)f_3645},
{"f_3773:chicken_install_scm",(void*)f_3773},
{"f_4248:chicken_install_scm",(void*)f_4248},
{"f_4398:chicken_install_scm",(void*)f_4398},
{"f_4356:chicken_install_scm",(void*)f_4356},
{"f_4360:chicken_install_scm",(void*)f_4360},
{"f_4372:chicken_install_scm",(void*)f_4372},
{"f_4311:chicken_install_scm",(void*)f_4311},
{"f_4334:chicken_install_scm",(void*)f_4334},
{"f_4343:chicken_install_scm",(void*)f_4343},
{"f_4350:chicken_install_scm",(void*)f_4350},
{"f_4337:chicken_install_scm",(void*)f_4337},
{"f_4315:chicken_install_scm",(void*)f_4315},
{"f4901:chicken_install_scm",(void*)f4901},
{"f_4295:chicken_install_scm",(void*)f_4295},
{"f_4257:chicken_install_scm",(void*)f_4257},
{"f_4291:chicken_install_scm",(void*)f_4291},
{"f4896:chicken_install_scm",(void*)f4896},
{"f_4280:chicken_install_scm",(void*)f_4280},
{"f_4274:chicken_install_scm",(void*)f_4274},
{"f_4270:chicken_install_scm",(void*)f_4270},
{"f4891:chicken_install_scm",(void*)f4891},
{"f_4221:chicken_install_scm",(void*)f_4221},
{"f4886:chicken_install_scm",(void*)f4886},
{"f_4177:chicken_install_scm",(void*)f_4177},
{"f4881:chicken_install_scm",(void*)f4881},
{"f_4074:chicken_install_scm",(void*)f_4074},
{"f_4077:chicken_install_scm",(void*)f_4077},
{"f_4097:chicken_install_scm",(void*)f_4097},
{"f4868:chicken_install_scm",(void*)f4868},
{"f_4045:chicken_install_scm",(void*)f_4045},
{"f_1621:chicken_install_scm",(void*)f_1621},
{"f_1627:chicken_install_scm",(void*)f_1627},
{"f_1632:chicken_install_scm",(void*)f_1632},
{"f_1659:chicken_install_scm",(void*)f_1659},
{"f_1640:chicken_install_scm",(void*)f_1640},
{"f_1656:chicken_install_scm",(void*)f_1656},
{"f_1648:chicken_install_scm",(void*)f_1648},
{"f_1652:chicken_install_scm",(void*)f_1652},
{"f_4048:chicken_install_scm",(void*)f_4048},
{"f_4016:chicken_install_scm",(void*)f_4016},
{"f_4009:chicken_install_scm",(void*)f_4009},
{"f4861:chicken_install_scm",(void*)f4861},
{"f_3941:chicken_install_scm",(void*)f_3941},
{"f_3958:chicken_install_scm",(void*)f_3958},
{"f_3969:chicken_install_scm",(void*)f_3969},
{"f_3965:chicken_install_scm",(void*)f_3965},
{"f_3948:chicken_install_scm",(void*)f_3948},
{"f4856:chicken_install_scm",(void*)f4856},
{"f_3904:chicken_install_scm",(void*)f_3904},
{"f_3908:chicken_install_scm",(void*)f_3908},
{"f4851:chicken_install_scm",(void*)f4851},
{"f_3871:chicken_install_scm",(void*)f_3871},
{"f_3835:chicken_install_scm",(void*)f_3835},
{"f_3792:chicken_install_scm",(void*)f_3792},
{"f_3785:chicken_install_scm",(void*)f_3785},
{"f4846:chicken_install_scm",(void*)f4846},
{"f_3693:chicken_install_scm",(void*)f_3693},
{"f_3758:chicken_install_scm",(void*)f_3758},
{"f_3709:chicken_install_scm",(void*)f_3709},
{"f_3744:chicken_install_scm",(void*)f_3744},
{"f_3707:chicken_install_scm",(void*)f_3707},
{"f_3703:chicken_install_scm",(void*)f_3703},
{"f_3661:chicken_install_scm",(void*)f_3661},
{"f_3678:chicken_install_scm",(void*)f_3678},
{"f_3664:chicken_install_scm",(void*)f_3664},
{"f_3675:chicken_install_scm",(void*)f_3675},
{"f_3671:chicken_install_scm",(void*)f_3671},
{"f_2900:chicken_install_scm",(void*)f_2900},
{"f_3101:chicken_install_scm",(void*)f_3101},
{"f_2906:chicken_install_scm",(void*)f_2906},
{"f_2912:chicken_install_scm",(void*)f_2912},
{"f_2915:chicken_install_scm",(void*)f_2915},
{"f_3093:chicken_install_scm",(void*)f_3093},
{"f_2922:chicken_install_scm",(void*)f_2922},
{"f_2926:chicken_install_scm",(void*)f_2926},
{"f_2928:chicken_install_scm",(void*)f_2928},
{"f_3066:chicken_install_scm",(void*)f_3066},
{"f_2936:chicken_install_scm",(void*)f_2936},
{"f_3025:chicken_install_scm",(void*)f_3025},
{"f_3047:chicken_install_scm",(void*)f_3047},
{"f_3031:chicken_install_scm",(void*)f_3031},
{"f_3034:chicken_install_scm",(void*)f_3034},
{"f_3037:chicken_install_scm",(void*)f_3037},
{"f_2940:chicken_install_scm",(void*)f_2940},
{"f_2943:chicken_install_scm",(void*)f_2943},
{"f_2946:chicken_install_scm",(void*)f_2946},
{"f_2963:chicken_install_scm",(void*)f_2963},
{"f_2891:chicken_install_scm",(void*)f_2891},
{"f_2791:chicken_install_scm",(void*)f_2791},
{"f_2795:chicken_install_scm",(void*)f_2795},
{"f_2798:chicken_install_scm",(void*)f_2798},
{"f_2801:chicken_install_scm",(void*)f_2801},
{"f_2804:chicken_install_scm",(void*)f_2804},
{"f_2807:chicken_install_scm",(void*)f_2807},
{"f_2810:chicken_install_scm",(void*)f_2810},
{"f_2813:chicken_install_scm",(void*)f_2813},
{"f_2877:chicken_install_scm",(void*)f_2877},
{"f_2856:chicken_install_scm",(void*)f_2856},
{"f_2859:chicken_install_scm",(void*)f_2859},
{"f_2862:chicken_install_scm",(void*)f_2862},
{"f_2865:chicken_install_scm",(void*)f_2865},
{"f_2833:chicken_install_scm",(void*)f_2833},
{"f_2845:chicken_install_scm",(void*)f_2845},
{"f_2841:chicken_install_scm",(void*)f_2841},
{"f_2967:chicken_install_scm",(void*)f_2967},
{"f_2970:chicken_install_scm",(void*)f_2970},
{"f_2973:chicken_install_scm",(void*)f_2973},
{"f_2997:chicken_install_scm",(void*)f_2997},
{"f_3003:chicken_install_scm",(void*)f_3003},
{"f_2979:chicken_install_scm",(void*)f_2979},
{"f_2983:chicken_install_scm",(void*)f_2983},
{"f_2986:chicken_install_scm",(void*)f_2986},
{"f_2950:chicken_install_scm",(void*)f_2950},
{"f_2954:chicken_install_scm",(void*)f_2954},
{"f_2957:chicken_install_scm",(void*)f_2957},
{"f_3485:chicken_install_scm",(void*)f_3485},
{"f_3481:chicken_install_scm",(void*)f_3481},
{"f_3122:chicken_install_scm",(void*)f_3122},
{"f_3125:chicken_install_scm",(void*)f_3125},
{"f_3128:chicken_install_scm",(void*)f_3128},
{"f_3131:chicken_install_scm",(void*)f_3131},
{"f_3134:chicken_install_scm",(void*)f_3134},
{"f_3474:chicken_install_scm",(void*)f_3474},
{"f_3356:chicken_install_scm",(void*)f_3356},
{"f_3362:chicken_install_scm",(void*)f_3362},
{"f_3461:chicken_install_scm",(void*)f_3461},
{"f_3370:chicken_install_scm",(void*)f_3370},
{"f_3374:chicken_install_scm",(void*)f_3374},
{"f_3382:chicken_install_scm",(void*)f_3382},
{"f_3420:chicken_install_scm",(void*)f_3420},
{"f_3448:chicken_install_scm",(void*)f_3448},
{"f_3454:chicken_install_scm",(void*)f_3454},
{"f_3426:chicken_install_scm",(void*)f_3426},
{"f_3442:chicken_install_scm",(void*)f_3442},
{"f_3388:chicken_install_scm",(void*)f_3388},
{"f_3394:chicken_install_scm",(void*)f_3394},
{"f_3402:chicken_install_scm",(void*)f_3402},
{"f_3406:chicken_install_scm",(void*)f_3406},
{"f_3409:chicken_install_scm",(void*)f_3409},
{"f_3412:chicken_install_scm",(void*)f_3412},
{"f_3415:chicken_install_scm",(void*)f_3415},
{"f_3418:chicken_install_scm",(void*)f_3418},
{"f_3377:chicken_install_scm",(void*)f_3377},
{"f_3351:chicken_install_scm",(void*)f_3351},
{"f_3137:chicken_install_scm",(void*)f_3137},
{"f_3140:chicken_install_scm",(void*)f_3140},
{"f_3228:chicken_install_scm",(void*)f_3228},
{"f_3235:chicken_install_scm",(void*)f_3235},
{"f_3238:chicken_install_scm",(void*)f_3238},
{"f_3249:chicken_install_scm",(void*)f_3249},
{"f_3307:chicken_install_scm",(void*)f_3307},
{"f_3334:chicken_install_scm",(void*)f_3334},
{"f_3257:chicken_install_scm",(void*)f_3257},
{"f_3263:chicken_install_scm",(void*)f_3263},
{"f_3290:chicken_install_scm",(void*)f_3290},
{"f_3261:chicken_install_scm",(void*)f_3261},
{"f_3243:chicken_install_scm",(void*)f_3243},
{"f_3204:chicken_install_scm",(void*)f_3204},
{"f_3206:chicken_install_scm",(void*)f_3206},
{"f_3214:chicken_install_scm",(void*)f_3214},
{"f_3218:chicken_install_scm",(void*)f_3218},
{"f_3143:chicken_install_scm",(void*)f_3143},
{"f_3146:chicken_install_scm",(void*)f_3146},
{"f_3165:chicken_install_scm",(void*)f_3165},
{"f_3171:chicken_install_scm",(void*)f_3171},
{"f_3183:chicken_install_scm",(void*)f_3183},
{"f_3189:chicken_install_scm",(void*)f_3189},
{"f_3149:chicken_install_scm",(void*)f_3149},
{"f_3163:chicken_install_scm",(void*)f_3163},
{"f_3159:chicken_install_scm",(void*)f_3159},
{"f_3152:chicken_install_scm",(void*)f_3152},
{"f_4520:chicken_install_scm",(void*)f_4520},
{"f_4477:chicken_install_scm",(void*)f_4477},
{"f_4483:chicken_install_scm",(void*)f_4483},
{"f_4508:chicken_install_scm",(void*)f_4508},
{"f_4487:chicken_install_scm",(void*)f_4487},
{"f_4504:chicken_install_scm",(void*)f_4504},
{"f_4490:chicken_install_scm",(void*)f_4490},
{"f_4493:chicken_install_scm",(void*)f_4493},
{"f_4460:chicken_install_scm",(void*)f_4460},
{"f_4463:chicken_install_scm",(void*)f_4463},
{"f_4469:chicken_install_scm",(void*)f_4469},
{"f_4466:chicken_install_scm",(void*)f_4466},
{"f_3611:chicken_install_scm",(void*)f_3611},
{"f_3615:chicken_install_scm",(void*)f_3615},
{"f_3618:chicken_install_scm",(void*)f_3618},
{"f_3589:chicken_install_scm",(void*)f_3589},
{"f_3606:chicken_install_scm",(void*)f_3606},
{"f_3593:chicken_install_scm",(void*)f_3593},
{"f_3487:chicken_install_scm",(void*)f_3487},
{"f_3514:chicken_install_scm",(void*)f_3514},
{"f_3573:chicken_install_scm",(void*)f_3573},
{"f_3579:chicken_install_scm",(void*)f_3579},
{"f_3498:chicken_install_scm",(void*)f_3498},
{"f_3502:chicken_install_scm",(void*)f_3502},
{"f_3518:chicken_install_scm",(void*)f_3518},
{"f_3532:chicken_install_scm",(void*)f_3532},
{"f_3561:chicken_install_scm",(void*)f_3561},
{"f_3512:chicken_install_scm",(void*)f_3512},
{"f_3505:chicken_install_scm",(void*)f_3505},
{"f_3508:chicken_install_scm",(void*)f_3508},
{"f_3103:chicken_install_scm",(void*)f_3103},
{"f_3110:chicken_install_scm",(void*)f_3110},
{"f_2261:chicken_install_scm",(void*)f_2261},
{"f_2265:chicken_install_scm",(void*)f_2265},
{"f_2535:chicken_install_scm",(void*)f_2535},
{"f_2580:chicken_install_scm",(void*)f_2580},
{"f_2584:chicken_install_scm",(void*)f_2584},
{"f_2587:chicken_install_scm",(void*)f_2587},
{"f_2574:chicken_install_scm",(void*)f_2574},
{"f_2102:chicken_install_scm",(void*)f_2102},
{"f_2104:chicken_install_scm",(void*)f_2104},
{"f_2168:chicken_install_scm",(void*)f_2168},
{"f_2120:chicken_install_scm",(void*)f_2120},
{"f_2158:chicken_install_scm",(void*)f_2158},
{"f_2123:chicken_install_scm",(void*)f_2123},
{"f_2134:chicken_install_scm",(void*)f_2134},
{"f_1600:chicken_install_scm",(void*)f_1600},
{"f_2128:chicken_install_scm",(void*)f_2128},
{"f_1970:chicken_install_scm",(void*)f_1970},
{"f_2063:chicken_install_scm",(void*)f_2063},
{"f_2082:chicken_install_scm",(void*)f_2082},
{"f_2088:chicken_install_scm",(void*)f_2088},
{"f_2069:chicken_install_scm",(void*)f_2069},
{"f_2077:chicken_install_scm",(void*)f_2077},
{"f_1976:chicken_install_scm",(void*)f_1976},
{"f_1982:chicken_install_scm",(void*)f_1982},
{"f_1992:chicken_install_scm",(void*)f_1992},
{"f_2004:chicken_install_scm",(void*)f_2004},
{"f_2016:chicken_install_scm",(void*)f_2016},
{"f_2019:chicken_install_scm",(void*)f_2019},
{"f_2022:chicken_install_scm",(void*)f_2022},
{"f_2007:chicken_install_scm",(void*)f_2007},
{"f_1995:chicken_install_scm",(void*)f_1995},
{"f_1965:chicken_install_scm",(void*)f_1965},
{"f_2560:chicken_install_scm",(void*)f_2560},
{"f_2613:chicken_install_scm",(void*)f_2613},
{"f_2268:chicken_install_scm",(void*)f_2268},
{"f_2276:chicken_install_scm",(void*)f_2276},
{"f_2298:chicken_install_scm",(void*)f_2298},
{"f_2304:chicken_install_scm",(void*)f_2304},
{"f_2499:chicken_install_scm",(void*)f_2499},
{"f_2307:chicken_install_scm",(void*)f_2307},
{"f_2310:chicken_install_scm",(void*)f_2310},
{"f_2639:chicken_install_scm",(void*)f_2639},
{"f_2654:chicken_install_scm",(void*)f_2654},
{"f_2689:chicken_install_scm",(void*)f_2689},
{"f_2744:chicken_install_scm",(void*)f_2744},
{"f_2718:chicken_install_scm",(void*)f_2718},
{"f_2702:chicken_install_scm",(void*)f_2702},
{"f_2664:chicken_install_scm",(void*)f_2664},
{"f_2629:chicken_install_scm",(void*)f_2629},
{"f_2313:chicken_install_scm",(void*)f_2313},
{"f_2316:chicken_install_scm",(void*)f_2316},
{"f_2327:chicken_install_scm",(void*)f_2327},
{"f_2332:chicken_install_scm",(void*)f_2332},
{"f_2434:chicken_install_scm",(void*)f_2434},
{"f_2436:chicken_install_scm",(void*)f_2436},
{"f_2446:chicken_install_scm",(void*)f_2446},
{"f_2430:chicken_install_scm",(void*)f_2430},
{"f_2418:chicken_install_scm",(void*)f_2418},
{"f_2411:chicken_install_scm",(void*)f_2411},
{"f_2339:chicken_install_scm",(void*)f_2339},
{"f_2191:chicken_install_scm",(void*)f_2191},
{"f_2244:chicken_install_scm",(void*)f_2244},
{"f_2251:chicken_install_scm",(void*)f_2251},
{"f_2189:chicken_install_scm",(void*)f_2189},
{"f_2181:chicken_install_scm",(void*)f_2181},
{"f_2405:chicken_install_scm",(void*)f_2405},
{"f_2345:chicken_install_scm",(void*)f_2345},
{"f_2348:chicken_install_scm",(void*)f_2348},
{"f_2392:chicken_install_scm",(void*)f_2392},
{"f_2351:chicken_install_scm",(void*)f_2351},
{"f_2359:chicken_install_scm",(void*)f_2359},
{"f_2371:chicken_install_scm",(void*)f_2371},
{"f_2377:chicken_install_scm",(void*)f_2377},
{"f_2354:chicken_install_scm",(void*)f_2354},
{"f_2321:chicken_install_scm",(void*)f_2321},
{"f_1749:chicken_install_scm",(void*)f_1749},
{"f_1754:chicken_install_scm",(void*)f_1754},
{"f_1810:chicken_install_scm",(void*)f_1810},
{"f_1916:chicken_install_scm",(void*)f_1916},
{"f_1813:chicken_install_scm",(void*)f_1813},
{"f_1830:chicken_install_scm",(void*)f_1830},
{"f_1905:chicken_install_scm",(void*)f_1905},
{"f_1901:chicken_install_scm",(void*)f_1901},
{"f_1890:chicken_install_scm",(void*)f_1890},
{"f_1876:chicken_install_scm",(void*)f_1876},
{"f_1843:chicken_install_scm",(void*)f_1843},
{"f_1854:chicken_install_scm",(void*)f_1854},
{"f_1858:chicken_install_scm",(void*)f_1858},
{"f_1850:chicken_install_scm",(void*)f_1850},
{"f_1797:chicken_install_scm",(void*)f_1797},
{"f_1804:chicken_install_scm",(void*)f_1804},
{"f_1768:chicken_install_scm",(void*)f_1768},
{"f_1772:chicken_install_scm",(void*)f_1772},
{"f_2522:chicken_install_scm",(void*)f_2522},
{"f_1672:chicken_install_scm",(void*)f_1672},
{"f_1722:chicken_install_scm",(void*)f_1722},
{"f_1682:chicken_install_scm",(void*)f_1682},
{"f_1688:chicken_install_scm",(void*)f_1688},
{"f_1602:chicken_install_scm",(void*)f_1602},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
