/* Generated from srfi-1.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:17
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: srfi-1.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file usrfi-1.c
   unit: srfi_1
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[125];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_1_toplevel)
C_externexport void C_ccall C_srfi_1_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6150)
static void C_ccall f_6150(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6083)
static void C_ccall f_6083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6110)
static void C_ccall f_6110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6108)
static void C_ccall f_6108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6036)
static void C_ccall f_6036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6060)
static void C_ccall f_6060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6067)
static void C_ccall f_6067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5948)
static void C_ccall f_5948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5954)
static void C_ccall f_5954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5962)
static void C_ccall f_5962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5911)
static void C_ccall f_5911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5861)
static void C_ccall f_5861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5851)
static void C_ccall f_5851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5818)
static void C_ccall f_5818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5725)
static void C_ccall f_5725r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5731)
static void C_ccall f_5731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5767)
static void C_ccall f_5767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5762)
static void C_ccall f_5762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5720)
static void C_ccall f_5720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5663)
static void C_fcall f_5663(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5585)
static void C_ccall f_5585(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5585)
static void C_ccall f_5585r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5605)
static void C_fcall f_5605(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5573)
static void C_fcall f_5573(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5555)
static C_word C_fcall f_5555(C_word t0,C_word t1);
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5515)
static void C_fcall f_5515(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5478)
static void C_fcall f_5478(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5433)
static void C_fcall f_5433(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5367)
static void C_ccall f_5367(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5379)
static void C_fcall f_5379(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5312)
static void C_fcall f_5312(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5325)
static void C_ccall f_5325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5262)
static void C_fcall f_5262(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5284)
static void C_ccall f_5284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5268)
static void C_ccall f_5268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5218)
static void C_ccall f_5218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5142)
static void C_fcall f_5142(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_fcall f_5157(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5085)
static void C_fcall f_5085(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5031)
static void C_fcall f_5031(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5040)
static void C_fcall f_5040(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4995)
static void C_fcall f_4995(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4960)
static void C_fcall f_4960(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4924)
static void C_fcall f_4924(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4788)
static void C_fcall f_4788(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4698)
static void C_fcall f_4698(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4646)
static void C_fcall f_4646(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_fcall f_4469(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_fcall f_4419(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4435)
static void C_ccall f_4435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_fcall f_4361(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4367)
static void C_fcall f_4367(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_fcall f_4316(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4322)
static void C_fcall f_4322(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4242)
static void C_fcall f_4242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4269)
static void C_ccall f_4269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4263)
static void C_ccall f_4263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4121)
static void C_fcall f_4121(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_fcall f_4176(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4182)
static void C_fcall f_4182(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4143)
static void C_fcall f_4143(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4079)
static void C_fcall f_4079(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4046)
static void C_fcall f_4046(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_fcall f_4012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3962)
static void C_fcall f_3962(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static C_word C_fcall f_3979(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3917)
static void C_fcall f_3917(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3943)
static void C_fcall f_3943(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_fcall f_3841(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_fcall f_3038(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3807)
static void C_fcall f_3807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_fcall f_3786(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_fcall f_3661(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3743)
static void C_fcall f_3743(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3695)
static void C_fcall f_3695(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3710)
static void C_ccall f_3710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3704)
static void C_ccall f_3704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3625)
static void C_fcall f_3625(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3566)
static void C_fcall f_3566(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3536)
static void C_fcall f_3536(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3500)
static void C_fcall f_3500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_fcall f_3470(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3431)
static void C_fcall f_3431(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_fcall f_3405(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_fcall f_2841(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3365)
static void C_fcall f_3365(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_fcall f_3334(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2960)
static void C_fcall f_2960(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_3294)
static void C_fcall f_3294(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_fcall f_3260(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_3200)
static void C_fcall f_3200(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3160)
static void C_fcall f_3160(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_fcall f_3109(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_fcall f_2868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2880)
static void C_fcall f_2880(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_fcall f_2787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2799)
static void C_fcall f_2799(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2757)
static C_word C_fcall f_2757(C_word t0,C_word t1);
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2727)
static void C_fcall f_2727(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2651)
static void C_fcall f_2651(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_fcall f_2682(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2567)
static void C_fcall f_2567(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2495)
static void C_fcall f_2495(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2431)
static void C_fcall f_2431(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2375)
static void C_fcall f_2375(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2334)
static void C_fcall f_2334(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2313)
static C_word C_fcall f_2313(C_word t0);
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2223)
static void C_fcall f_2223(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static C_word C_fcall f_2191(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_fcall f_2144(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static C_word C_fcall f_2114(C_word t0,C_word t1);
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2061)
static C_word C_fcall f_2061(C_word t0,C_word t1);
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2024)
static void C_fcall f_2024(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1877)
static C_word C_fcall f_1877(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1791)
static void C_fcall f_1791(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1818)
static void C_fcall f_1818(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1732)
static C_word C_fcall f_1732(C_word t0,C_word t1);
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1675)
static C_word C_fcall f_1675(C_word t0,C_word t1);
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_fcall f_1604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_fcall f_1599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1553)
static void C_fcall f_1553(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1568)
static void C_fcall f_1568(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1521)
static void C_fcall f_1521(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1491)
static void C_fcall f_1491(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1461)
static void C_fcall f_1461(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_fcall f_1405(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;

C_noret_decl(trf_5663)
static void C_fcall trf_5663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5663(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5663(t0,t1,t2,t3);}

C_noret_decl(trf_5605)
static void C_fcall trf_5605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5605(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5605(t0,t1,t2,t3);}

C_noret_decl(trf_5573)
static void C_fcall trf_5573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5573(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5573(t0,t1,t2,t3);}

C_noret_decl(trf_5515)
static void C_fcall trf_5515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5515(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5515(t0,t1,t2,t3);}

C_noret_decl(trf_5478)
static void C_fcall trf_5478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5478(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5478(t0,t1,t2,t3);}

C_noret_decl(trf_5433)
static void C_fcall trf_5433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5433(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5433(t0,t1,t2,t3);}

C_noret_decl(trf_5379)
static void C_fcall trf_5379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5379(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5379(t0,t1,t2,t3);}

C_noret_decl(trf_5312)
static void C_fcall trf_5312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5312(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5312(t0,t1,t2,t3);}

C_noret_decl(trf_5262)
static void C_fcall trf_5262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5262(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5262(t0,t1,t2,t3);}

C_noret_decl(trf_5142)
static void C_fcall trf_5142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5142(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5142(t0,t1);}

C_noret_decl(trf_5157)
static void C_fcall trf_5157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5157(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5157(t0,t1,t2,t3);}

C_noret_decl(trf_5085)
static void C_fcall trf_5085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5085(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5085(t0,t1,t2);}

C_noret_decl(trf_5031)
static void C_fcall trf_5031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5031(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5031(t0,t1);}

C_noret_decl(trf_5040)
static void C_fcall trf_5040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5040(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5040(t0,t1,t2,t3);}

C_noret_decl(trf_4995)
static void C_fcall trf_4995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4995(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4995(t0,t1,t2);}

C_noret_decl(trf_4960)
static void C_fcall trf_4960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4960(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4960(t0,t1,t2);}

C_noret_decl(trf_4924)
static void C_fcall trf_4924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4924(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4924(t0,t1,t2);}

C_noret_decl(trf_4788)
static void C_fcall trf_4788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4788(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4788(t0,t1,t2);}

C_noret_decl(trf_4698)
static void C_fcall trf_4698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4698(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4698(t0,t1,t2);}

C_noret_decl(trf_4646)
static void C_fcall trf_4646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4646(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4646(t0,t1,t2);}

C_noret_decl(trf_4469)
static void C_fcall trf_4469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4469(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4469(t0,t1,t2,t3);}

C_noret_decl(trf_4419)
static void C_fcall trf_4419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4419(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4419(t0,t1,t2,t3);}

C_noret_decl(trf_4361)
static void C_fcall trf_4361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4361(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4361(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4367)
static void C_fcall trf_4367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4367(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4367(t0,t1,t2,t3);}

C_noret_decl(trf_4316)
static void C_fcall trf_4316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4316(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4316(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4322)
static void C_fcall trf_4322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4322(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4322(t0,t1,t2,t3);}

C_noret_decl(trf_4242)
static void C_fcall trf_4242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4242(t0,t1,t2);}

C_noret_decl(trf_4121)
static void C_fcall trf_4121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4121(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4121(t0,t1,t2);}

C_noret_decl(trf_4176)
static void C_fcall trf_4176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4176(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4176(t0,t1,t2,t3);}

C_noret_decl(trf_4182)
static void C_fcall trf_4182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4182(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4182(t0,t1,t2);}

C_noret_decl(trf_4143)
static void C_fcall trf_4143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4143(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4143(t0,t1,t2,t3);}

C_noret_decl(trf_4079)
static void C_fcall trf_4079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4079(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4079(t0,t1,t2);}

C_noret_decl(trf_4046)
static void C_fcall trf_4046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4046(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4046(t0,t1,t2);}

C_noret_decl(trf_4012)
static void C_fcall trf_4012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4012(t0,t1,t2);}

C_noret_decl(trf_3962)
static void C_fcall trf_3962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3962(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3962(t0,t1,t2);}

C_noret_decl(trf_3917)
static void C_fcall trf_3917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3917(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3917(t0,t1,t2);}

C_noret_decl(trf_3943)
static void C_fcall trf_3943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3943(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3943(t0,t1,t2);}

C_noret_decl(trf_3841)
static void C_fcall trf_3841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3841(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3841(t0,t1,t2,t3);}

C_noret_decl(trf_3038)
static void C_fcall trf_3038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3038(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3038(t0,t1,t2);}

C_noret_decl(trf_3807)
static void C_fcall trf_3807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3807(t0,t1,t2);}

C_noret_decl(trf_3786)
static void C_fcall trf_3786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3786(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3786(t0,t1,t2);}

C_noret_decl(trf_3661)
static void C_fcall trf_3661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3661(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3661(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3743)
static void C_fcall trf_3743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3743(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3743(t0,t1,t2,t3);}

C_noret_decl(trf_3695)
static void C_fcall trf_3695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3695(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3695(t0,t1,t2,t3);}

C_noret_decl(trf_3625)
static void C_fcall trf_3625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3625(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3625(t0,t1,t2,t3);}

C_noret_decl(trf_3566)
static void C_fcall trf_3566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3566(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3566(t0,t1,t2,t3);}

C_noret_decl(trf_3536)
static void C_fcall trf_3536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3536(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3536(t0,t1,t2,t3);}

C_noret_decl(trf_3500)
static void C_fcall trf_3500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3500(t0,t1,t2);}

C_noret_decl(trf_3470)
static void C_fcall trf_3470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3470(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3470(t0,t1,t2);}

C_noret_decl(trf_3431)
static void C_fcall trf_3431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3431(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3431(t0,t1,t2);}

C_noret_decl(trf_3405)
static void C_fcall trf_3405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3405(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3405(t0,t1,t2);}

C_noret_decl(trf_2841)
static void C_fcall trf_2841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2841(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2841(t0,t1,t2);}

C_noret_decl(trf_3365)
static void C_fcall trf_3365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3365(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3365(t0,t1,t2,t3);}

C_noret_decl(trf_3334)
static void C_fcall trf_3334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3334(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3334(t0,t1,t2,t3);}

C_noret_decl(trf_2960)
static void C_fcall trf_2960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2960(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2960(t0,t1,t2);}

C_noret_decl(trf_3294)
static void C_fcall trf_3294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3294(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3294(t0,t1,t2);}

C_noret_decl(trf_3260)
static void C_fcall trf_3260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3260(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3260(t0,t1,t2);}

C_noret_decl(trf_3200)
static void C_fcall trf_3200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3200(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3200(t0,t1,t2,t3);}

C_noret_decl(trf_3160)
static void C_fcall trf_3160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3160(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3160(t0,t1,t2,t3);}

C_noret_decl(trf_3109)
static void C_fcall trf_3109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3109(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3109(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2868)
static void C_fcall trf_2868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2868(t0,t1);}

C_noret_decl(trf_2880)
static void C_fcall trf_2880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2880(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2880(t0,t1,t2);}

C_noret_decl(trf_2787)
static void C_fcall trf_2787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2787(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2787(t0,t1);}

C_noret_decl(trf_2799)
static void C_fcall trf_2799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2799(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2799(t0,t1,t2);}

C_noret_decl(trf_2727)
static void C_fcall trf_2727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2727(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2727(t0,t1,t2,t3);}

C_noret_decl(trf_2651)
static void C_fcall trf_2651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2651(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2651(t0,t1,t2,t3);}

C_noret_decl(trf_2682)
static void C_fcall trf_2682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2682(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2682(t0,t1,t2,t3);}

C_noret_decl(trf_2567)
static void C_fcall trf_2567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2567(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2567(t0,t1,t2);}

C_noret_decl(trf_2495)
static void C_fcall trf_2495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2495(t0,t1,t2);}

C_noret_decl(trf_2431)
static void C_fcall trf_2431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2431(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2431(t0,t1,t2);}

C_noret_decl(trf_2375)
static void C_fcall trf_2375(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2375(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2375(t0,t1,t2);}

C_noret_decl(trf_2334)
static void C_fcall trf_2334(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2334(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2334(t0,t1,t2);}

C_noret_decl(trf_2223)
static void C_fcall trf_2223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2223(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2223(t0,t1,t2,t3);}

C_noret_decl(trf_2144)
static void C_fcall trf_2144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2144(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2144(t0,t1,t2,t3);}

C_noret_decl(trf_2024)
static void C_fcall trf_2024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2024(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2024(t0,t1,t2,t3);}

C_noret_decl(trf_1791)
static void C_fcall trf_1791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1791(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1791(t0,t1,t2,t3);}

C_noret_decl(trf_1818)
static void C_fcall trf_1818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1818(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1818(t0,t1,t2,t3);}

C_noret_decl(trf_1604)
static void C_fcall trf_1604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1604(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1604(t0,t1);}

C_noret_decl(trf_1599)
static void C_fcall trf_1599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1599(t0,t1,t2);}

C_noret_decl(trf_1553)
static void C_fcall trf_1553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1553(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1553(t0,t1,t2,t3);}

C_noret_decl(trf_1568)
static void C_fcall trf_1568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1568(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1568(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1521)
static void C_fcall trf_1521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1521(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1521(t0,t1,t2);}

C_noret_decl(trf_1491)
static void C_fcall trf_1491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1491(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1491(t0,t1,t2,t3);}

C_noret_decl(trf_1461)
static void C_fcall trf_1461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1461(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1461(t0,t1,t2,t3);}

C_noret_decl(trf_1405)
static void C_fcall trf_1405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1405(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1405(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr6rv)
static void C_fcall tr6rv(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6rv(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n+1);
t6=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_1_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_1_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1180)){
C_save(t1);
C_rereclaim2(1180*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,125);
lf[0]=C_h_intern(&lf[0],5,"xcons");
lf[1]=C_h_intern(&lf[1],9,"make-list");
lf[2]=C_h_intern(&lf[2],9,"\003syserror");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\037Too many arguments to MAKE-LIST");
lf[4]=C_h_intern(&lf[4],13,"list-tabulate");
lf[5]=C_h_intern(&lf[5],5,"cons*");
lf[6]=C_h_intern(&lf[6],9,"list-copy");
lf[7]=C_h_intern(&lf[7],4,"iota");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\023Negative step count");
lf[9]=C_h_intern(&lf[9],13,"circular-list");
lf[10]=C_h_intern(&lf[10],9,"last-pair");
lf[11]=C_h_intern(&lf[11],12,"proper-list\077");
lf[12]=C_h_intern(&lf[12],5,"list\077");
lf[13]=C_h_intern(&lf[13],12,"dotted-list\077");
lf[14]=C_h_intern(&lf[14],14,"circular-list\077");
lf[15]=C_h_intern(&lf[15],9,"not-pair\077");
lf[16]=C_h_intern(&lf[16],10,"null-list\077");
lf[17]=C_h_intern(&lf[17],5,"list=");
lf[18]=C_h_intern(&lf[18],7,"length+");
lf[19]=C_h_intern(&lf[19],3,"zip");
lf[20]=C_h_intern(&lf[20],3,"map");
lf[21]=C_h_intern(&lf[21],4,"list");
lf[22]=C_h_intern(&lf[22],5,"first");
lf[23]=C_h_intern(&lf[23],3,"car");
lf[24]=C_h_intern(&lf[24],6,"second");
lf[25]=C_h_intern(&lf[25],4,"cadr");
lf[26]=C_h_intern(&lf[26],5,"third");
lf[27]=C_h_intern(&lf[27],5,"caddr");
lf[28]=C_h_intern(&lf[28],6,"fourth");
lf[29]=C_h_intern(&lf[29],6,"cadddr");
lf[30]=C_h_intern(&lf[30],5,"fifth");
lf[31]=C_h_intern(&lf[31],5,"sixth");
lf[32]=C_h_intern(&lf[32],7,"seventh");
lf[33]=C_h_intern(&lf[33],6,"eighth");
lf[34]=C_h_intern(&lf[34],5,"ninth");
lf[35]=C_h_intern(&lf[35],5,"tenth");
lf[36]=C_h_intern(&lf[36],7,"car+cdr");
lf[37]=C_h_intern(&lf[37],4,"take");
lf[38]=C_h_intern(&lf[38],4,"drop");
lf[39]=C_h_intern(&lf[39],5,"take!");
lf[40]=C_h_intern(&lf[40],10,"take-right");
lf[41]=C_h_intern(&lf[41],10,"drop-right");
lf[42]=C_h_intern(&lf[42],11,"drop-right!");
lf[43]=C_h_intern(&lf[43],8,"split-at");
lf[44]=C_h_intern(&lf[44],9,"split-at!");
lf[45]=C_h_intern(&lf[45],4,"last");
lf[46]=C_h_intern(&lf[46],6,"unzip1");
lf[47]=C_h_intern(&lf[47],6,"unzip2");
lf[48]=C_h_intern(&lf[48],6,"unzip3");
lf[49]=C_h_intern(&lf[49],6,"unzip4");
lf[50]=C_h_intern(&lf[50],6,"unzip5");
lf[51]=C_h_intern(&lf[51],7,"append!");
lf[52]=C_h_intern(&lf[52],14,"append-reverse");
lf[53]=C_h_intern(&lf[53],15,"append-reverse!");
lf[54]=C_h_intern(&lf[54],11,"concatenate");
lf[55]=C_h_intern(&lf[55],12,"reduce-right");
lf[56]=C_h_intern(&lf[56],6,"append");
lf[57]=C_h_intern(&lf[57],12,"concatenate!");
lf[60]=C_h_intern(&lf[60],5,"count");
lf[61]=C_h_intern(&lf[61],12,"unfold-right");
lf[62]=C_h_intern(&lf[62],6,"unfold");
lf[63]=C_h_intern(&lf[63],5,"error");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\022Too many arguments");
lf[65]=C_h_intern(&lf[65],4,"fold");
lf[66]=C_h_intern(&lf[66],10,"fold-right");
lf[67]=C_h_intern(&lf[67],15,"pair-fold-right");
lf[68]=C_h_intern(&lf[68],9,"pair-fold");
lf[69]=C_h_intern(&lf[69],6,"reduce");
lf[70]=C_h_intern(&lf[70],10,"append-map");
lf[72]=C_h_intern(&lf[72],11,"append-map!");
lf[73]=C_h_intern(&lf[73],13,"pair-for-each");
lf[74]=C_h_intern(&lf[74],4,"map!");
lf[75]=C_h_intern(&lf[75],10,"filter-map");
lf[76]=C_h_intern(&lf[76],12,"map-in-order");
lf[77]=C_h_intern(&lf[77],6,"filter");
lf[78]=C_h_intern(&lf[78],7,"filter!");
lf[79]=C_h_intern(&lf[79],9,"partition");
lf[80]=C_h_intern(&lf[80],10,"partition!");
lf[81]=C_h_intern(&lf[81],6,"remove");
lf[82]=C_h_intern(&lf[82],7,"remove!");
lf[83]=C_h_intern(&lf[83],6,"delete");
lf[84]=C_h_intern(&lf[84],6,"equal\077");
lf[85]=C_h_intern(&lf[85],7,"delete!");
lf[86]=C_h_intern(&lf[86],6,"member");
lf[87]=C_h_intern(&lf[87],9,"find-tail");
lf[88]=C_h_intern(&lf[88],17,"delete-duplicates");
lf[89]=C_h_intern(&lf[89],18,"delete-duplicates!");
lf[90]=C_h_intern(&lf[90],5,"assoc");
lf[91]=C_h_intern(&lf[91],4,"find");
lf[92]=C_h_intern(&lf[92],10,"alist-cons");
lf[93]=C_h_intern(&lf[93],10,"alist-copy");
lf[94]=C_h_intern(&lf[94],12,"alist-delete");
lf[95]=C_h_intern(&lf[95],13,"alist-delete!");
lf[96]=C_h_intern(&lf[96],10,"take-while");
lf[97]=C_h_intern(&lf[97],10,"drop-while");
lf[98]=C_h_intern(&lf[98],11,"take-while!");
lf[99]=C_h_intern(&lf[99],4,"span");
lf[100]=C_h_intern(&lf[100],5,"span!");
lf[101]=C_h_intern(&lf[101],5,"break");
lf[102]=C_h_intern(&lf[102],6,"break!");
lf[103]=C_h_intern(&lf[103],3,"any");
lf[104]=C_h_intern(&lf[104],5,"every");
lf[105]=C_h_intern(&lf[105],10,"list-index");
lf[106]=C_h_intern(&lf[106],8,"reverse!");
lf[108]=C_h_intern(&lf[108],6,"lset<=");
lf[109]=C_h_intern(&lf[109],5,"lset=");
lf[110]=C_h_intern(&lf[110],11,"lset-adjoin");
lf[111]=C_h_intern(&lf[111],10,"lset-union");
lf[112]=C_h_intern(&lf[112],11,"lset-union!");
lf[113]=C_h_intern(&lf[113],17,"lset-intersection");
lf[114]=C_h_intern(&lf[114],3,"eq\077");
lf[115]=C_h_intern(&lf[115],18,"lset-intersection!");
lf[116]=C_h_intern(&lf[116],15,"lset-difference");
lf[117]=C_h_intern(&lf[117],5,"pair\077");
lf[118]=C_h_intern(&lf[118],16,"lset-difference!");
lf[119]=C_h_intern(&lf[119],8,"lset-xor");
lf[120]=C_h_intern(&lf[120],22,"lset-diff+intersection");
lf[121]=C_h_intern(&lf[121],9,"lset-xor!");
lf[122]=C_h_intern(&lf[122],23,"lset-diff+intersection!");
lf[123]=C_h_intern(&lf[123],17,"register-feature!");
lf[124]=C_h_intern(&lf[124],6,"srfi-1");
C_register_lf2(lf,125,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1385,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 45   register-feature! */
t3=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[124]);}

/* k1383 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word ab[204],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1385,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! xcons ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1387,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[1]+1 /* (set! make-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1393,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[4]+1 /* (set! list-tabulate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1448,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[5]+1 /* (set! cons* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1485,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[6]+1 /* (set! list-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1515,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[7]+1 /* (set! iota ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1545,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[9]+1 /* (set! circular-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1655,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[11]+1 /* (set! proper-list? ...) */,*((C_word*)lf[12]+1));
t10=C_mutate((C_word*)lf[13]+1 /* (set! dotted-list? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1669,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[14]+1 /* (set! circular-list? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1726,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[15]+1 /* (set! not-pair? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1765,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[16]+1 /* (set! null-list? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1768,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[17]+1 /* (set! list= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1771,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[18]+1 /* (set! length+ ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1871,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[19]+1 /* (set! zip ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1920,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[22]+1 /* (set! first ...) */,*((C_word*)lf[23]+1));
t18=C_mutate((C_word*)lf[24]+1 /* (set! second ...) */,*((C_word*)lf[25]+1));
t19=C_mutate((C_word*)lf[26]+1 /* (set! third ...) */,*((C_word*)lf[27]+1));
t20=C_mutate((C_word*)lf[28]+1 /* (set! fourth ...) */,*((C_word*)lf[29]+1));
t21=C_mutate((C_word*)lf[30]+1 /* (set! fifth ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1930,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[31]+1 /* (set! sixth ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1940,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[32]+1 /* (set! seventh ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1950,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[33]+1 /* (set! eighth ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1960,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[34]+1 /* (set! ninth ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1970,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[35]+1 /* (set! tenth ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1984,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[36]+1 /* (set! car+cdr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1998,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[37]+1 /* (set! take ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2015,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[38]+1 /* (set! drop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2052,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[39]+1 /* (set! take! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2081,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[40]+1 /* (set! take-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2104,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[41]+1 /* (set! drop-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2134,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[42]+1 /* (set! drop-right! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2172,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[43]+1 /* (set! split-at ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2214,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[44]+1 /* (set! split-at! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2266,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[45]+1 /* (set! last ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2297,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[10]+1 /* (set! last-pair ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2307,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[46]+1 /* (set! unzip1 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2328,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[47]+1 /* (set! unzip2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2369,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[48]+1 /* (set! unzip3 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2425,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[49]+1 /* (set! unzip4 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2489,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[50]+1 /* (set! unzip5 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2561,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[51]+1 /* (set! append! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2645,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[52]+1 /* (set! append-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2721,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[53]+1 /* (set! append-reverse! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2751,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[54]+1 /* (set! concatenate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2775,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[57]+1 /* (set! concatenate! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2781,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate(&lf[58] /* (set! cdrs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2787,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate(&lf[59] /* (set! cars+cdrs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2868,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[60]+1 /* (set! count ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3097,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[61]+1 /* (set! unfold-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3190,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[62]+1 /* (set! unfold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3236,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[65]+1 /* (set! fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3318,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[66]+1 /* (set! fold-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3389,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[67]+1 /* (set! pair-fold-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3454,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[68]+1 /* (set! pair-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3520,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[69]+1 /* (set! reduce ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3585,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[55]+1 /* (set! reduce-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3605,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[70]+1 /* (set! append-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3649,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[72]+1 /* (set! append-map! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3655,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate(&lf[71] /* (set! really-append-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3661,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[73]+1 /* (set! pair-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3770,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[74]+1 /* (set! map! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3829,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[75]+1 /* (set! filter-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3901,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[76]+1 /* (set! map-in-order ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3996,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[20]+1 /* (set! map ...) */,*((C_word*)lf[76]+1));
t67=C_mutate((C_word*)lf[77]+1 /* (set! filter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4073,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[78]+1 /* (set! filter! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4115,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[79]+1 /* (set! partition ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4236,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[80]+1 /* (set! partition! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4304,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[81]+1 /* (set! remove ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4516,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[82]+1 /* (set! remove! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4532,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[83]+1 /* (set! delete ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4548,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[85]+1 /* (set! delete! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4579,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[86]+1 /* (set! member ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4610,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[88]+1 /* (set! delete-duplicates ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4637,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[89]+1 /* (set! delete-duplicates! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4689,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[90]+1 /* (set! assoc ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4741,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[92]+1 /* (set! alist-cons ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4772,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[93]+1 /* (set! alist-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4782,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[94]+1 /* (set! alist-delete ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4836,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[95]+1 /* (set! alist-delete! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4871,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[91]+1 /* (set! find ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4906,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[87]+1 /* (set! find-tail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4918,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[96]+1 /* (set! take-while ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4954,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[97]+1 /* (set! drop-while ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4989,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[98]+1 /* (set! take-while! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5021,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[99]+1 /* (set! span ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5079,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[100]+1 /* (set! span! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5132,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[101]+1 /* (set! break ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5196,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[102]+1 /* (set! break! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5212,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[103]+1 /* (set! any ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5228,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[104]+1 /* (set! every ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5345,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[105]+1 /* (set! list-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5462,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[106]+1 /* (set! reverse! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5549,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate(&lf[107] /* (set! lset2<= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5573,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[108]+1 /* (set! lset<= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5585,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[109]+1 /* (set! lset= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5643,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[110]+1 /* (set! lset-adjoin ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5707,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[111]+1 /* (set! lset-union ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5725,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[112]+1 /* (set! lset-union! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5773,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[113]+1 /* (set! lset-intersection ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5824,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[115]+1 /* (set! lset-intersection! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5857,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[116]+1 /* (set! lset-difference ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5890,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[118]+1 /* (set! lset-difference! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5927,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[119]+1 /* (set! lset-xor ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5964,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[121]+1 /* (set! lset-xor! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6018,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[120]+1 /* (set! lset-diff+intersection ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6076,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[122]+1 /* (set! lset-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6116,tmp=(C_word)a,a+=2,tmp));
t110=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t110+1)))(2,t110,C_SCHEME_UNDEFINED);}

/* lset-diff+intersection! in k1383 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6116r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6116r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6116r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6123,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1638 every */
t6=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[16]+1),t4);}

/* k6121 in lset-diff+intersection! in k1383 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6123,2,t0,t1);}
if(C_truep(t1)){
/* srfi-1.scm: 1638 values */
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],((C_word*)t0)[3]))){
/* srfi-1.scm: 1639 values */
C_values(4,0,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1640 partition! */
t3=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}}}

/* a6139 in k6121 in lset-diff+intersection! in k1383 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6140,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6148,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6150,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1641 any */
t5=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6149 in a6139 in k6121 in lset-diff+intersection! in k1383 */
static void C_ccall f_6150(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6150,3,t0,t1,t2);}
/* srfi-1.scm: 1641 member */
t3=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k6146 in a6139 in k6121 in lset-diff+intersection! in k1383 */
static void C_ccall f_6148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-diff+intersection in k1383 */
static void C_ccall f_6076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6076r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6076r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6076r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6083,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1629 every */
t6=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[16]+1),t4);}

/* k6081 in lset-diff+intersection in k1383 */
static void C_ccall f_6083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6083,2,t0,t1);}
if(C_truep(t1)){
/* srfi-1.scm: 1629 values */
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],((C_word*)t0)[3]))){
/* srfi-1.scm: 1630 values */
C_values(4,0,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1631 partition */
t3=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}}}

/* a6099 in k6081 in lset-diff+intersection in k1383 */
static void C_ccall f_6100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6100,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6108,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6110,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1632 any */
t5=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6109 in a6099 in k6081 in lset-diff+intersection in k1383 */
static void C_ccall f_6110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6110,3,t0,t1,t2);}
/* srfi-1.scm: 1632 member */
t3=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k6106 in a6099 in k6081 in lset-diff+intersection in k1383 */
static void C_ccall f_6108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-xor! in k1383 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_6018r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6018r(t0,t1,t2,t3);}}

static void C_ccall f_6018r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6024,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1606 reduce */
t5=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a6023 in lset-xor! in k1383 */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6024,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6030,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6036,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6035 in a6023 in lset-xor! in k1383 */
static void C_ccall f_6036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6036,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 1617 lset-difference! */
t4=*((C_word*)lf[118]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 1618 append! */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6060,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1619 pair-fold */
t5=*((C_word*)lf[68]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,t2,((C_word*)t0)[3]);}}}

/* a6059 in a6035 in a6023 in lset-xor! in k1383 */
static void C_ccall f_6060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6060,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6067,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1620 member */
t6=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6065 in a6059 in a6035 in a6023 in lset-xor! in k1383 */
static void C_ccall f_6067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),((C_word*)t0)[4]);
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a6029 in a6023 in lset-xor! in k1383 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6030,2,t0,t1);}
/* srfi-1.scm: 1616 lset-diff+intersection! */
t2=*((C_word*)lf[122]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lset-xor in k1383 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_5964r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5964r(t0,t1,t2,t3);}}

static void C_ccall f_5964r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5970,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1584 reduce */
t5=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a5969 in lset-xor in k1383 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5970,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5976,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5982,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5981 in a5969 in lset-xor in k1383 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5982,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 1595 lset-difference */
t4=*((C_word*)lf[116]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 1596 append */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6006,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1597 fold */
t5=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,t2,((C_word*)t0)[3]);}}}

/* a6005 in a5981 in a5969 in lset-xor in k1383 */
static void C_ccall f_6006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6006,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6013,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1598 member */
t5=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6011 in a6005 in a5981 in a5969 in lset-xor in k1383 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6013,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]));}}

/* a5975 in a5969 in lset-xor in k1383 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5976,2,t0,t1);}
/* srfi-1.scm: 1594 lset-diff+intersection */
t2=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lset-difference! in k1383 */
static void C_ccall f_5927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5927r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5927r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5927r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5931,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1573 filter */
t6=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[117]+1),t4);}

/* k5929 in lset-difference! in k1383 */
static void C_ccall f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5931,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5948,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1576 filter! */
t3=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}}}

/* a5947 in k5929 in lset-difference! in k1383 */
static void C_ccall f_5948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5948,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5954,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1577 every */
t4=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a5953 in a5947 in k5929 in lset-difference! in k1383 */
static void C_ccall f_5954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5954,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5962,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1577 member */
t4=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5960 in a5953 in a5947 in k5929 in lset-difference! in k1383 */
static void C_ccall f_5962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-difference in k1383 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5890r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5890r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5890r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5894,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1563 filter */
t6=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[117]+1),t4);}

/* k5892 in lset-difference in k1383 */
static void C_ccall f_5894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5894,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5911,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1566 filter */
t3=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}}}

/* a5910 in k5892 in lset-difference in k1383 */
static void C_ccall f_5911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5911,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5917,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1567 every */
t4=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a5916 in a5910 in k5892 in lset-difference in k1383 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5917,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5925,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1567 member */
t4=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5923 in a5916 in a5910 in k5892 in lset-difference in k1383 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-intersection! in k1383 */
static void C_ccall f_5857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5857r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5857r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5857r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5861,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1553 delete */
t6=*((C_word*)lf[83]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,t3,t4,*((C_word*)lf[114]+1));}

/* k5859 in lset-intersection! in k1383 */
static void C_ccall f_5861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1554 any */
t3=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[16]+1),t1);}

/* k5865 in k5859 in lset-intersection! in k1383 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5867,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5878,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1556 filter! */
t3=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[3]);}}}

/* a5877 in k5865 in k5859 in lset-intersection! in k1383 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5878,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5884,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1557 every */
t4=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a5883 in a5877 in k5865 in k5859 in lset-intersection! in k1383 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5884,3,t0,t1,t2);}
/* srfi-1.scm: 1557 member */
t3=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* lset-intersection in k1383 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5824r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5824r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5824r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5828,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1544 delete */
t6=*((C_word*)lf[83]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,t3,t4,*((C_word*)lf[114]+1));}

/* k5826 in lset-intersection in k1383 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1545 any */
t3=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[16]+1),t1);}

/* k5832 in k5826 in lset-intersection in k1383 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5834,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5845,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1547 filter */
t3=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[3]);}}}

/* a5844 in k5832 in k5826 in lset-intersection in k1383 */
static void C_ccall f_5845(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5845,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5851,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1548 every */
t4=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a5850 in a5844 in k5832 in k5826 in lset-intersection in k1383 */
static void C_ccall f_5851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5851,3,t0,t1,t2);}
/* srfi-1.scm: 1548 member */
t3=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* lset-union! in k1383 */
static void C_ccall f_5773(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_5773r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5773r(t0,t1,t2,t3);}}

static void C_ccall f_5773r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5779,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1528 reduce */
t5=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a5778 in lset-union! in k1383 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5779,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5803,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1533 pair-fold */
t6=*((C_word*)lf[68]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,t3,t2);}}}}

/* a5802 in a5778 in lset-union! in k1383 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5803,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5813,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5818,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1535 any */
t7=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t3);}

/* a5817 in a5802 in a5778 in lset-union! in k1383 */
static void C_ccall f_5818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5818,3,t0,t1,t2);}
/* srfi-1.scm: 1535 = */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k5811 in a5802 in a5778 in lset-union! in k1383 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),((C_word*)t0)[4]);
t3=((C_word*)t0)[2];
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* lset-union in k1383 */
static void C_ccall f_5725(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_5725r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5725r(t0,t1,t2,t3);}}

static void C_ccall f_5725r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5731,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1515 reduce */
t5=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a5730 in lset-union in k1383 */
static void C_ccall f_5731(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5731,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5755,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1520 fold */
t6=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,t3,t2);}}}}

/* a5754 in a5730 in lset-union in k1383 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5755,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5762,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5767,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1520 any */
t6=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t3);}

/* a5766 in a5754 in a5730 in lset-union in k1383 */
static void C_ccall f_5767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5767,3,t0,t1,t2);}
/* srfi-1.scm: 1520 = */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k5760 in a5754 in a5730 in lset-union in k1383 */
static void C_ccall f_5762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5762,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]));}}

/* lset-adjoin in k1383 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_5707r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5707r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5707r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5713,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1509 fold */
t6=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,t3,t4);}

/* a5712 in lset-adjoin in k1383 */
static void C_ccall f_5713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5713,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5720,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1509 member */
t5=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,t3,((C_word*)t0)[2]);}

/* k5718 in a5712 in lset-adjoin in k1383 */
static void C_ccall f_5720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5720,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]));}}

/* lset= in k1383 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5643r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5643r(t0,t1,t2,t3);}}

static void C_ccall f_5643r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(6);
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_slot(t3,C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5663,a[2]=t2,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_5663(t11,t1,t6,t7);}}

/* lp in lset= in k1383 */
static void C_fcall f_5663(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5663,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_word)C_eqp(t2,t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5685,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
if(C_truep(t8)){
/* srfi-1.scm: 1504 lp */
t12=t1;
t13=t6;
t14=t7;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5694,a[2]=t1,a[3]=t2,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 1503 ##srfi1#lset2<= */
f_5573(t10,((C_word*)t0)[2],t2,t6);}}}

/* k5692 in lp in lset= in k1383 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-1.scm: 1503 ##srfi1#lset2<= */
f_5573(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5683 in lp in lset= in k1383 */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-1.scm: 1504 lp */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5663(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lset<= in k1383 */
static void C_ccall f_5585(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5585r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5585r(t0,t1,t2,t3);}}

static void C_ccall f_5585r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(6);
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_slot(t3,C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5605,a[2]=t2,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_5605(t11,t1,t6,t7);}}

/* lp in lset<= in k1383 */
static void C_fcall f_5605(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5605,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_word)C_eqp(t6,t2);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5627,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
if(C_truep(t8)){
/* srfi-1.scm: 1493 lp */
t11=t1;
t12=t6;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
/* srfi-1.scm: 1492 ##srfi1#lset2<= */
f_5573(t9,((C_word*)t0)[2],t2,t6);}}}

/* k5625 in lp in lset<= in k1383 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-1.scm: 1493 lp */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5605(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##srfi1#lset2<= in k1383 */
static void C_fcall f_5573(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5573,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5579,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1483 every */
t6=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t3);}

/* a5578 in ##srfi1#lset2<= in k1383 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5579,3,t0,t1,t2);}
/* srfi-1.scm: 1483 member */
t3=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* reverse! in k1383 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5549,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5555,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_5555(t2,C_SCHEME_END_OF_LIST));}

/* lp in reverse! in k1383 */
static C_word C_fcall f_5555(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
return(t3);}
else{
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_i_setslot(t1,C_fix(1),t2);
t7=t3;
t8=t1;
t1=t7;
t2=t8;
goto loop;}}

/* list-index in k1383 */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_5462r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5462r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5462r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5478,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5478(t9,t1,t5,C_fix(0));}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5515,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5515(t8,t1,t3,C_fix(0));}}

/* lp in list-index in k1383 */
static void C_fcall f_5515(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5515,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5528,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1452 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k5526 in lp in list-index in k1383 */
static void C_ccall f_5528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-1.scm: 1452 lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5515(t4,((C_word*)t0)[5],t2,t3);}}

/* lp in list-index in k1383 */
static void C_fcall f_5478(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5478,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5489 in lp in list-index in k1383 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5490,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5503,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5501 in a5489 in lp in list-index in k1383 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-1.scm: 1447 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5478(t3,((C_word*)t0)[5],((C_word*)t0)[2],t2);}}

/* a5483 in lp in list-index in k1383 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5484,2,t0,t1);}
/* srfi-1.scm: 1444 ##srfi1#cars+cdrs */
f_2868(t1,((C_word*)t0)[2]);}

/* every in k1383 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5345r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5345r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5345r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5357,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5367,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}
else{
t5=(C_word)C_i_nullp(t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_slot(t3,C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5433,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_5433(t11,t1,t6,t7);}}}

/* lp in every in k1383 */
static void C_fcall f_5433(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5433,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 1435 pred */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5449,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1436 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k5447 in lp in every in k1383 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-1.scm: 1436 lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5433(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5366 in every in k1383 */
static void C_ccall f_5367(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5367,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5379,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5379(t9,t1,t2,t3);}}

/* lp in a5366 in every in k1383 */
static void C_fcall f_5379(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5379,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5385,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5391,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5390 in lp in a5366 in every in k1383 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5391,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5404,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5402 in a5390 in lp in a5366 in every in k1383 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-1.scm: 1428 lp */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5379(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5384 in lp in a5366 in every in k1383 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5385,2,t0,t1);}
/* srfi-1.scm: 1426 ##srfi1#cars+cdrs */
f_2868(t1,((C_word*)t0)[2]);}

/* a5356 in every in k1383 */
static void C_ccall f_5357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5357,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-1.scm: 1423 ##srfi1#cars+cdrs */
f_2868(t1,t2);}

/* any in k1383 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5228r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5228r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5228r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5240,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5250,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5312,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_5312(t10,t1,t5,t6);}}}

/* lp in any in k1383 */
static void C_fcall f_5312(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5312,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 1408 pred */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5325,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1409 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k5323 in lp in any in k1383 */
static void C_ccall f_5325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1409 lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5312(t4,((C_word*)t0)[4],t2,t3);}}

/* a5249 in any in k1383 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5250,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5262,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5262(t7,t1,t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* lp in a5249 in any in k1383 */
static void C_fcall f_5262(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5262,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5268,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5274,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5273 in lp in a5249 in any in k1383 */
static void C_ccall f_5274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5274,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5284,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5282 in a5273 in lp in a5249 in any in k1383 */
static void C_ccall f_5284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* srfi-1.scm: 1401 lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5262(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a5267 in lp in a5249 in any in k1383 */
static void C_ccall f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5268,2,t0,t1);}
/* srfi-1.scm: 1399 ##srfi1#cars+cdrs */
f_2868(t1,((C_word*)t0)[2]);}

/* a5239 in any in k1383 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5240,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-1.scm: 1396 ##srfi1#cars+cdrs */
f_2868(t1,t2);}

/* break! in k1383 */
static void C_ccall f_5212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5212,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5218,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1389 span! */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a5217 in break! in k1383 */
static void C_ccall f_5218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5218,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5226,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1389 pred */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5224 in a5217 in break! in k1383 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* break in k1383 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5196,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5202,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1388 span */
t5=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a5201 in break in k1383 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5202,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5210,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1388 pred */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5208 in a5201 in break in k1383 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* span! in k1383 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5132,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5142,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_5142(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5190,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1378 pred */
t8=t2;
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k5188 in span! in k1383 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5142(t2,(C_word)C_i_not(t1));}

/* k5140 in span! in k1383 */
static void C_fcall f_5142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5142,NULL,2,t0,t1);}
if(C_truep(t1)){
/* srfi-1.scm: 1378 values */
C_values(4,0,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5157,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5157(t7,t2,((C_word*)t0)[3],t3);}}

/* lp in k5140 in span! in k1383 */
static void C_fcall f_5157(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5157,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5173,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1382 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}

/* k5171 in lp in k5140 in span! in k1383 */
static void C_ccall f_5173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 1382 lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5157(t3,((C_word*)t0)[3],((C_word*)t0)[5],t2);}
else{
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(1),C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}}

/* k5146 in k5140 in span! in k1383 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 1385 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* span in k1383 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5079,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5085,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5085(t7,t1,t3);}

/* recur in span in k1383 */
static void C_fcall f_5085(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5085,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 1369 values */
C_values(4,0,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5104,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1371 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k5102 in recur in span in k1383 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5104,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5109,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
/* srfi-1.scm: 1374 values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);}}

/* a5118 in k5102 in recur in span in k1383 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5119,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
/* srfi-1.scm: 1373 values */
C_values(4,0,t1,t4,t3);}

/* a5108 in k5102 in recur in span in k1383 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5109,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1372 recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5085(t3,t1,t2);}

/* take-while! in k1383 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5021,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5031,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_5031(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5073,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1358 pred */
t8=t2;
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k5071 in take-while! in k1383 */
static void C_ccall f_5073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5031(t2,(C_word)C_i_not(t1));}

/* k5029 in take-while! in k1383 */
static void C_fcall f_5031(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5031,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5034,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5040,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5040(t7,t2,((C_word*)t0)[3],t3);}}

/* lp in k5029 in take-while! in k1383 */
static void C_fcall f_5040(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5040,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5056,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1362 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5054 in lp in k5029 in take-while! in k1383 */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 1362 lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5040(t3,((C_word*)t0)[3],((C_word*)t0)[5],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(1),C_SCHEME_END_OF_LIST));}}

/* k5032 in k5029 in take-while! in k1383 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* drop-while in k1383 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4989,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4995,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4995(t7,t1,t3);}

/* lp in drop-while in k1383 */
static void C_fcall f_4995(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4995,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5008,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1352 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k5006 in lp in drop-while in k1383 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-1.scm: 1353 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4995(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* take-while in k1383 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4954,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4960,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4960(t7,t1,t3);}

/* recur in take-while in k1383 */
static void C_fcall f_4960(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4960,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1344 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k4974 in recur in take-while in k1383 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4976,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4983,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1345 recur */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4960(t4,t2,t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k4981 in k4974 in recur in take-while in k1383 */
static void C_ccall f_4983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4983,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* find-tail in k1383 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4918,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4924,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4924(t7,t1,t3);}

/* lp in find-tail in k1383 */
static void C_fcall f_4924(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4924,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4937,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1336 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k4935 in lp in find-tail in k1383 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1337 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4924(t3,((C_word*)t0)[4],t2);}}

/* find in k1383 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4906,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4910,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1329 find-tail */
t5=*((C_word*)lf[87]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k4908 in find in k1383 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_u_i_car(t1):C_SCHEME_FALSE));}

/* alist-delete! in k1383 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4871r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4871r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4871r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[84]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4880,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1322 filter! */
t8=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a4879 in alist-delete! in k1383 */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4880,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4888,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1322 = */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k4886 in a4879 in alist-delete! in k1383 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* alist-delete in k1383 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4836r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4836r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4836r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[84]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4845,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1318 filter */
t8=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a4844 in alist-delete in k1383 */
static void C_ccall f_4845(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4845,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4853,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1318 = */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k4851 in a4844 in alist-delete in k1383 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* alist-copy in k1383 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4782,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4788,a[2]=t4,a[3]=t8,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_4788(t10,t1,t2);}

/* loop842 in alist-copy in k1383 */
static void C_fcall f_4788(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4788,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop842855 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=(C_word)C_slot(t2,C_fix(1));
/* loop842855 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* alist-cons in k1383 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4772,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t4));}

/* assoc in k1383 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4741r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4741r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4741r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[84]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4750,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1308 find */
t8=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a4749 in assoc in k1383 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4750,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1308 = */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t3);}

/* delete-duplicates! in k1383 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4689r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4689r(t0,t1,t2,t3);}}

static void C_ccall f_4689r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?*((C_word*)lf[84]+1):(C_word)C_slot(t3,C_fix(0)));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4698,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4698(t9,t1,t2);}

/* recur in delete-duplicates! in k1383 */
static void C_fcall f_4698(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4698,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4714,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4727,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1298 delete! */
t7=*((C_word*)lf[85]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t3,t4,((C_word*)t0)[2]);}}

/* k4725 in recur in delete-duplicates! in k1383 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 1298 recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4698(t2,((C_word*)t0)[2],t1);}

/* k4712 in recur in delete-duplicates! in k1383 */
static void C_ccall f_4714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4714,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* delete-duplicates in k1383 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4637r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4637r(t0,t1,t2,t3);}}

static void C_ccall f_4637r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?*((C_word*)lf[84]+1):(C_word)C_slot(t3,C_fix(0)));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4646,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4646(t9,t1,t2);}

/* recur in delete-duplicates in k1383 */
static void C_fcall f_4646(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4646,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4662,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4675,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1288 delete */
t7=*((C_word*)lf[83]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t3,t4,((C_word*)t0)[2]);}}

/* k4673 in recur in delete-duplicates in k1383 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 1288 recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4646(t2,((C_word*)t0)[2],t1);}

/* k4660 in recur in delete-duplicates in k1383 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4662,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* member in k1383 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4610r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4610r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4610r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[84]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4619,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1263 find-tail */
t8=*((C_word*)lf[87]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a4618 in member in k1383 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4619,3,t0,t1,t2);}
/* srfi-1.scm: 1263 = */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* delete! in k1383 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4579r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4579r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4579r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[84]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4588,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1258 filter! */
t8=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a4587 in delete! in k1383 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4588,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4596,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1258 = */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k4594 in a4587 in delete! in k1383 */
static void C_ccall f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* delete in k1383 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4548r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4548r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4548r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[84]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4557,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1254 filter */
t8=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a4556 in delete in k1383 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4557,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4565,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1254 = */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k4563 in a4556 in delete in k1383 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* remove! in k1383 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4532,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4538,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1231 filter! */
t5=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a4537 in remove! in k1383 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4538,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4546,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1231 pred */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4544 in a4537 in remove! in k1383 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* remove in k1383 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4516,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4522,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1230 filter */
t5=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a4521 in remove in k1383 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4522,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4530,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1230 pred */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4528 in a4521 in remove in k1383 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* partition! in k1383 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4304,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 1187 values */
C_values(4,0,t1,t3,t3);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4316,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4361,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4410,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t7,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t11=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1212 pred */
t12=t2;
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* k4408 in partition! in k1383 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4410,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4419(t6,((C_word*)t0)[3],((C_word*)t0)[6],t2);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4469,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4469(t6,((C_word*)t0)[3],((C_word*)t0)[6],t2);}}

/* lp in k4408 in partition! in k1383 */
static void C_fcall f_4469(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4469,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4485,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1223 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* srfi-1.scm: 1222 values */
C_values(4,0,t1,t3,((C_word*)t0)[5]);}}

/* k4483 in lp in k4408 in partition! in k1383 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4485,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1224 scan-in */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4316(t4,t2,((C_word*)t0)[6],((C_word*)t0)[3],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1226 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4469(t3,((C_word*)t0)[7],((C_word*)t0)[6],t2);}}

/* k4486 in k4483 in lp in k4408 in partition! in k1383 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 1225 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k4408 in partition! in k1383 */
static void C_fcall f_4419(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4419,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4435,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1216 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* srfi-1.scm: 1215 values */
C_values(4,0,t1,((C_word*)t0)[4],t3);}}

/* k4433 in lp in k4408 in partition! in k1383 */
static void C_ccall f_4435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4435,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* srfi-1.scm: 1216 lp */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4419(t3,((C_word*)t0)[5],((C_word*)t0)[7],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* srfi-1.scm: 1217 scan-out */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4361(t4,t2,((C_word*)t0)[2],((C_word*)t0)[7],t3);}}

/* k4443 in k4433 in lp in k4408 in partition! in k1383 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 1218 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* scan-out in partition! in k1383 */
static void C_fcall f_4361(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4361,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4367(t8,t1,t3,t4);}

/* lp in scan-out in partition! in k1383 */
static void C_fcall f_4367(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4367,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4380,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1205 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),t3));}}

/* k4378 in lp in scan-out in partition! in k1383 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_setslot(((C_word*)t0)[7],C_fix(1),((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1207 scan-in */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4316(t4,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1208 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4367(t3,((C_word*)t0)[4],((C_word*)t0)[6],t2);}}

/* scan-in in partition! in k1383 */
static void C_fcall f_4316(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4316,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4322(t8,t1,t2,t4);}

/* lp in scan-in in partition! in k1383 */
static void C_fcall f_4322(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4322,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4335,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1196 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t3));}}

/* k4333 in lp in scan-in in partition! in k1383 */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* srfi-1.scm: 1197 lp */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4322(t3,((C_word*)t0)[5],((C_word*)t0)[7],t2);}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),((C_word*)t0)[7]);
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* srfi-1.scm: 1199 scan-out */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4361(t4,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],t3);}}

/* partition in k1383 */
static void C_ccall f_4236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4236,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4242,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4242(t7,t1,t3);}

/* recur in partition in k1383 */
static void C_fcall f_4242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4242,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 1154 values */
C_values(4,0,t1,t2,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4263,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4269,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a4268 in recur in partition in k1383 */
static void C_ccall f_4269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4269,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4276,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 1158 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* k4274 in a4268 in recur in partition in k1383 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4276,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* srfi-1.scm: 1159 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[2];
/* srfi-1.scm: 1159 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* srfi-1.scm: 1160 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[4],t2);}
else{
t2=((C_word*)t0)[2];
/* srfi-1.scm: 1160 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[4],t2);}}}

/* a4262 in recur in partition in k1383 */
static void C_ccall f_4263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4263,2,t0,t1);}
/* srfi-1.scm: 1157 recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4242(t2,t1,((C_word*)t0)[2]);}

/* filter! in k1383 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4115,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4121,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4121(t7,t1,t3);}

/* lp in filter! in k1383 */
static void C_fcall f_4121(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4121,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4230,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1119 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k4228 in lp in filter! in k1383 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4230,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4143,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1143 scan-in */
t10=((C_word*)t3)[1];
f_4143(t10,t8,((C_word*)t0)[3],t9);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1119 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4121(t3,((C_word*)t0)[4],t2);}}

/* k4220 in k4228 in lp in filter! in k1383 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* scan-out in k4228 in lp in filter! in k1383 */
static void C_fcall f_4176(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4176,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4182,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4182(t7,t1,t3);}

/* lp in scan-out in k4228 in lp in filter! in k1383 */
static void C_fcall f_4182(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4182,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4195,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1138 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),t2));}}

/* k4193 in lp in scan-out in k4228 in lp in filter! in k1383 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(1),((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 1140 scan-in */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4143(t4,((C_word*)t0)[3],((C_word*)t0)[5],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 1141 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4182(t3,((C_word*)t0)[3],t2);}}

/* scan-in in k4228 in lp in filter! in k1383 */
static void C_fcall f_4143(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4143,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4156,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1132 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4154 in scan-in in k4228 in lp in filter! in k1383 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1133 scan-in */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4143(t3,((C_word*)t0)[4],((C_word*)t0)[6],t2);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1134 scan-out */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4176(t3,((C_word*)t0)[4],((C_word*)t0)[2],t2);}}

/* filter in k1383 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4073,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4079,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4079(t7,t1,t3);}

/* recur in filter in k1383 */
static void C_fcall f_4079(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4079,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4098,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 1068 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k4096 in recur in filter in k1383 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4098,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4101,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1069 recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4079(t3,t2,((C_word*)t0)[6]);}
else{
/* srfi-1.scm: 1072 recur */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4079(t2,((C_word*)t0)[4],((C_word*)t0)[6]);}}

/* k4099 in k4096 in recur in filter in k1383 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4101,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}}

/* map-in-order in k1383 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_3996r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3996r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3996r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4012,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4012(t9,t1,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4046,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4046(t8,t1,t3);}}

/* recur in map-in-order in k1383 */
static void C_fcall f_4046(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4046,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4059,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1046 f */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k4057 in recur in map-in-order in k1383 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4066,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1047 recur */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4046(t3,t2,((C_word*)t0)[2]);}

/* k4064 in k4057 in recur in map-in-order in k1383 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* recur in map-in-order in k1383 */
static void C_fcall f_4012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4012,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4018,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a4023 in recur in map-in-order in k1383 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4024,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4034,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4032 in a4023 in recur in map-in-order in k1383 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4041,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1039 recur */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4012(t3,t2,((C_word*)t0)[2]);}

/* k4039 in k4032 in a4023 in recur in map-in-order in k1383 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4041,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a4017 in recur in map-in-order in k1383 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4018,2,t0,t1);}
/* srfi-1.scm: 1036 ##srfi1#cars+cdrs */
f_2868(t1,((C_word*)t0)[2]);}

/* filter-map in k1383 */
static void C_ccall f_3901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_3901r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3901r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3901r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3917,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3917(t9,t1,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3962,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3962(t8,t1,t3);}}

/* recur in filter-map in k1383 */
static void C_fcall f_3962(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3962,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 1023 recur */
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k3970 in recur in filter-map in k1383 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3975,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* srfi-1.scm: 1024 f */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k3973 in k3970 in recur in filter-map in k1383 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3979,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* g644645 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_3979(C_a_i(&a,3),t2,t1));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* g644 in k3973 in k3970 in recur in filter-map in k1383 */
static C_word C_fcall f_3979(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
return((C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* recur in filter-map in k1383 */
static void C_fcall f_3917(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3917,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3923,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a3928 in recur in filter-map in k1383 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3929,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3939,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k3937 in a3928 in recur in filter-map in k1383 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* g629630 */
t3=t2;
f_3943(t3,((C_word*)t0)[2],t1);}
else{
/* srfi-1.scm: 1017 recur */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3917(t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* g629 in k3937 in a3928 in recur in filter-map in k1383 */
static void C_fcall f_3943(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3943,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3951,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1016 recur */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3917(t4,t3,((C_word*)t0)[2]);}

/* k3949 in g629 in k3937 in a3928 in recur in filter-map in k1383 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a3922 in recur in filter-map in k1383 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3923,2,t0,t1);}
/* srfi-1.scm: 1014 ##srfi1#cars+cdrs */
f_2868(t1,((C_word*)t0)[2]);}

/* map! in k1383 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_3829r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3829r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3829r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3833,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3841,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3841(t9,t5,t3,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3887,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1005 pair-for-each */
t7=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t3);}}

/* a3886 in map! in k1383 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3887,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3895,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1005 f */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3893 in a3886 in map! in k1383 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* lp in map! in k1383 */
static void C_fcall f_3841(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3841,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3853,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a3858 in lp in map! in k1383 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3859,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3874,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
C_apply(5,0,t4,((C_word*)t0)[2],t5,t2);}

/* k3872 in a3858 in lp in map! in k1383 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(0),t1);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 1002 lp */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3841(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* a3852 in lp in map! in k1383 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3853,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3038,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3038(t6,t1,t2);}

/* recur in a3852 in lp in map! in k1383 */
static void C_fcall f_3038(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3038,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3050,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
/* srfi-1.scm: 825  values */
C_values(4,0,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* a3055 in recur in a3852 in lp in map! in k1383 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3056,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3062,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3068,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3067 in a3055 in recur in a3852 in lp in map! in k1383 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3068,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3080,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3079 in a3067 in a3055 in recur in a3852 in lp in map! in k1383 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3080,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
/* srfi-1.scm: 824  values */
C_values(4,0,t1,t4,t5);}

/* a3073 in a3067 in a3055 in recur in a3852 in lp in map! in k1383 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3074,2,t0,t1);}
/* srfi-1.scm: 823  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3038(t2,t1,((C_word*)t0)[2]);}

/* a3061 in a3055 in recur in a3852 in lp in map! in k1383 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3062,2,t0,t1);}
/* srfi-1.scm: 822  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a3049 in recur in a3852 in lp in map! in k1383 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3050,2,t0,t1);}
/* srfi-1.scm: 821  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k3831 in map! in k1383 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pair-for-each in k1383 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_3770r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3770r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3770r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3786,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3786(t9,t1,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3807,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3807(t8,t1,t3);}}

/* lp in pair-for-each in k1383 */
static void C_fcall f_3807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3807,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3820,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 991  proc */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k3818 in lp in pair-for-each in k1383 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 992  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3807(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in pair-for-each in k1383 */
static void C_fcall f_3786(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3786,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3790,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 982  ##srfi1#cdrs */
f_2787(t3,t2);}

/* k3788 in lp in pair-for-each in k1383 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3799,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3797 in k3788 in lp in pair-for-each in k1383 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 985  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3786(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##srfi1#really-append-map in k1383 */
static void C_fcall f_3661(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3661,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3673,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3683,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}
else{
if(C_truep((C_word)C_i_nullp(t4))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_slot(t4,C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3743,a[2]=t3,a[3]=t9,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_3743(t11,t1,t6,t7);}}}

/* recur in ##srfi1#really-append-map in k1383 */
static void C_fcall f_3743(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3743,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3747,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 972  f */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3745 in recur in ##srfi1#really-append-map in k1383 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=t1;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3760,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 974  recur */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3743(t5,t2,t3,t4);}}

/* k3758 in k3745 in recur in ##srfi1#really-append-map in k1383 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 974  appender */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3682 in ##srfi1#really-append-map in k1383 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3683,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3695,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3695(t7,t1,t2,t3);}}

/* recur in a3682 in ##srfi1#really-append-map in k1383 */
static void C_fcall f_3695(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3695,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3699,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}

/* k3697 in recur in a3682 in ##srfi1#really-append-map in k1383 */
static void C_ccall f_3699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3704,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3709 in k3697 in recur in a3682 in ##srfi1#really-append-map in k1383 */
static void C_ccall f_3710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3710,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=((C_word*)t0)[4];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 967  recur */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3695(t5,t4,t2,t3);}}

/* k3722 in a3709 in k3697 in recur in a3682 in ##srfi1#really-append-map in k1383 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 967  appender */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3703 in k3697 in recur in a3682 in ##srfi1#really-append-map in k1383 */
static void C_ccall f_3704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3704,2,t0,t1);}
/* srfi-1.scm: 965  ##srfi1#cars+cdrs */
f_2868(t1,((C_word*)t0)[2]);}

/* a3672 in ##srfi1#really-append-map in k1383 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3673,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-1.scm: 961  ##srfi1#cars+cdrs */
f_2868(t1,t2);}

/* append-map! in k1383 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_3655r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3655r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3655r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* srfi-1.scm: 956  ##srfi1#really-append-map */
f_3661(t1,*((C_word*)lf[51]+1),t2,t3,t4);}

/* append-map in k1383 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_3649r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3649r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3649r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* srfi-1.scm: 954  ##srfi1#really-append-map */
f_3661(t1,*((C_word*)lf[56]+1),t2,t3,t4);}

/* reduce-right in k1383 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3605,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_slot(t4,C_fix(1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3625,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_3625(t10,t1,t5,t6);}}

/* recur in reduce-right in k1383 */
static void C_fcall f_3625(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3625,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3639,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-1.scm: 945  recur */
t9=t4;
t10=t5;
t11=t6;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3637 in recur in reduce-right in k1383 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 945  f */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* reduce in k1383 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3585,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_slot(t4,C_fix(1));
/* srfi-1.scm: 938  fold */
t7=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,t5,t6);}}

/* pair-fold in k1383 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_3520r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3520r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3520r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3536,a[2]=t2,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_3536(t10,t1,t6,t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3566,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3566(t9,t1,t4,t3);}}

/* lp in pair-fold in k1383 */
static void C_fcall f_3566(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3566,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3583,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 929  f */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}}

/* k3581 in lp in pair-fold in k1383 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 929  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3566(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in pair-fold in k1383 */
static void C_fcall f_3536(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3536,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3540,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 922  ##srfi1#cdrs */
f_2787(t4,t2);}

/* k3538 in lp in pair-fold in k1383 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3540,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3553,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3557,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
/* srfi-1.scm: 924  append! */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k3555 in k3538 in lp in pair-fold in k1383 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3551 in k3538 in lp in pair-fold in k1383 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 924  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3536(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pair-fold-right in k1383 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr5r,(void*)f_3454r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3454r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3454r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(10);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3470,a[2]=t8,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3470(t10,t1,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3500,a[2]=t7,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3500(t9,t1,t4);}}

/* recur in pair-fold-right in k1383 */
static void C_fcall f_3500(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3500,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[4];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3514,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 916  recur */
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k3512 in recur in pair-fold-right in k1383 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 916  f */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* recur in pair-fold-right in k1383 */
static void C_fcall f_3470(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3470,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 911  ##srfi1#cdrs */
f_2787(t3,t2);}

/* k3472 in recur in pair-fold-right in k1383 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3495,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 913  recur */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3470(t4,t3,t1);}}

/* k3493 in k3472 in recur in pair-fold-right in k1383 */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3495,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* srfi-1.scm: 913  append! */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3485 in k3472 in recur in pair-fold-right in k1383 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fold-right in k1383 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr5r,(void*)f_3389r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3389r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3389r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(10);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3405,a[2]=t8,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3405(t10,t1,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3431,a[2]=t7,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_3431(t9,t1,t4);}}

/* recur in fold-right in k1383 */
static void C_fcall f_3431(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3431,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[4];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3448,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 904  recur */
t8=t4;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}

/* k3446 in recur in fold-right in k1383 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 904  kons */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* recur in fold-right in k1383 */
static void C_fcall f_3405(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3405,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 897  ##srfi1#cdrs */
f_2787(t3,t2);}

/* k3407 in recur in fold-right in k1383 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3409,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3422,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3426,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 899  recur */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3405(t4,t3,t1);}}

/* k3424 in k3407 in recur in fold-right in k1383 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3426,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2841,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2841(t6,((C_word*)t0)[2],t2);}

/* recur in k3424 in k3407 in recur in fold-right in k1383 */
static void C_fcall f_2841(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2841,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_caar(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2859,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 785  recur */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* k2857 in recur in k3424 in k3407 in recur in fold-right in k1383 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2859,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3420 in k3407 in recur in fold-right in k1383 */
static void C_ccall f_3422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fold in k1383 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_3318r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3318r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3318r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3334,a[2]=t2,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_3334(t10,t1,t6,t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3365,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3365(t9,t1,t4,t3);}}

/* lp in fold in k1383 */
static void C_fcall f_3365(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3365,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3383,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 890  kons */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t3);}}

/* k3381 in lp in fold in k1383 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 890  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3365(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in fold in k1383 */
static void C_fcall f_3334(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3334,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3340,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3345 in lp in fold in k1383 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3346,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=((C_word*)t0)[4];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3360,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}}

/* k3358 in a3345 in lp in fold in k1383 */
static void C_ccall f_3360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 886  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3334(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3339 in lp in fold in k1383 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3340,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2954,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 806  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t4);}

/* a2953 in a3339 in lp in fold in k1383 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2954,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2960(t6,t1,((C_word*)t0)[2]);}

/* recur in a2953 in a3339 in lp in fold in k1383 */
static void C_fcall f_2960(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2960,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2972,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* srfi-1.scm: 815  values */
C_values(4,0,t1,t3,C_SCHEME_END_OF_LIST);}}

/* a2977 in recur in a2953 in a3339 in lp in fold in k1383 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2978,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 811  abort */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2999,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a2998 in a2977 in recur in a2953 in a3339 in lp in fold in k1383 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2999,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3011,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3010 in a2998 in a2977 in recur in a2953 in a3339 in lp in fold in k1383 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3011,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
/* srfi-1.scm: 814  values */
C_values(4,0,t1,t4,t5);}

/* a3004 in a2998 in a2977 in recur in a2953 in a3339 in lp in fold in k1383 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3005,2,t0,t1);}
/* srfi-1.scm: 813  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2960(t2,t1,((C_word*)t0)[2]);}

/* a2992 in a2977 in recur in a2953 in a3339 in lp in fold in k1383 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2993,2,t0,t1);}
/* srfi-1.scm: 812  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a2971 in recur in a2953 in a3339 in lp in fold in k1383 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2972,2,t0,t1);}
/* srfi-1.scm: 810  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* unfold in k1383 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_3236r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_3236r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_3236r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_u_i_car(t6);
t8=(C_word)C_slot(t6,C_fix(1));
if(C_truep((C_word)C_i_pairp(t8))){
C_apply(10,0,t1,*((C_word*)lf[63]+1),lf[64],*((C_word*)lf[62]+1),t2,t3,t4,t5,t6);}
else{
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3260,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t10,a[6]=t7,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_3260(t12,t1,t5);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3294,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3294(t10,t1,t5);}}

/* recur in unfold in k1383 */
static void C_fcall f_3294(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3294,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 876  p */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3299 in recur in unfold in k1383 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 877  f */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3306 in k3299 in recur in unfold in k1383 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3312,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3316,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 877  g */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3314 in k3306 in k3299 in recur in unfold in k1383 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 877  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3294(t2,((C_word*)t0)[2],t1);}

/* k3310 in k3306 in k3299 in recur in unfold in k1383 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3312,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* recur in unfold in k1383 */
static void C_fcall f_3260(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3260,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* srfi-1.scm: 872  p */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3265 in recur in unfold in k1383 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3267,2,t0,t1);}
if(C_truep(t1)){
/* srfi-1.scm: 872  tail-gen */
t2=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3277,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 873  f */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}

/* k3275 in k3265 in recur in unfold in k1383 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3281,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3285,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 873  g */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3283 in k3275 in k3265 in recur in unfold in k1383 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 873  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3260(t2,((C_word*)t0)[2],t1);}

/* k3279 in k3275 in k3265 in recur in unfold in k1383 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3281,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unfold-right in k1383 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr6rv,(void*)f_3190r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest_vector(a,C_rest_count(0));
f_3190r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_3190r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t7=(C_word)C_vemptyp(t6);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(0)));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3200,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_3200(t12,t1,t5,t8);}

/* lp in unfold-right in k1383 */
static void C_fcall f_3200(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3200,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3207,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-1.scm: 856  p */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3205 in lp in unfold-right in k1383 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3207,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 857  g */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3212 in k3205 in lp in unfold-right in k1383 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3222,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 858  f */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3220 in k3212 in k3205 in lp in unfold-right in k1383 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3222,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* srfi-1.scm: 857  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3200(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* count in k1383 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3097r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3097r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3097r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(6);
if(C_truep((C_word)C_i_pairp(t4))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3109,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3109(t8,t1,t3,t4,C_fix(0));}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3160,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3160(t8,t1,t3,C_fix(0));}}

/* lp in count in k1383 */
static void C_fcall f_3160(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3160,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3181,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 845  pred */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k3179 in lp in count in k1383 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 845  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3160(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[5];
/* srfi-1.scm: 845  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3160(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* lp in count in k1383 */
static void C_fcall f_3109(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3109,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t4;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3121,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a3126 in lp in count in k1383 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3127,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=((C_word*)t0)[5];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3148,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[4]);
C_apply(5,0,t5,((C_word*)t0)[2],t6,t2);}}

/* k3146 in a3126 in lp in count in k1383 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 839  lp */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3109(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[6];
/* srfi-1.scm: 839  lp */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3109(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a3120 in lp in count in k1383 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3121,2,t0,t1);}
/* srfi-1.scm: 837  ##srfi1#cars+cdrs */
f_2868(t1,((C_word*)t0)[2]);}

/* ##srfi1#cars+cdrs in k1383 */
static void C_fcall f_2868(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2868,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2874,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 792  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t3);}

/* a2873 in ##srfi1#cars+cdrs in k1383 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2874,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2880,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2880(t6,t1,((C_word*)t0)[2]);}

/* recur in a2873 in ##srfi1#cars+cdrs in k1383 */
static void C_fcall f_2880(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2880,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2892,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
/* srfi-1.scm: 801  values */
C_values(4,0,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* a2897 in recur in a2873 in ##srfi1#cars+cdrs in k1383 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2898,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 797  abort */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2913,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2919,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a2918 in a2897 in recur in a2873 in ##srfi1#cars+cdrs in k1383 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2919,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2931,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a2930 in a2918 in a2897 in recur in a2873 in ##srfi1#cars+cdrs in k1383 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2931,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
/* srfi-1.scm: 800  values */
C_values(4,0,t1,t4,t5);}

/* a2924 in a2918 in a2897 in recur in a2873 in ##srfi1#cars+cdrs in k1383 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2925,2,t0,t1);}
/* srfi-1.scm: 799  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2880(t2,t1,((C_word*)t0)[2]);}

/* a2912 in a2897 in recur in a2873 in ##srfi1#cars+cdrs in k1383 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
/* srfi-1.scm: 798  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a2891 in recur in a2873 in ##srfi1#cars+cdrs in k1383 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
/* srfi-1.scm: 796  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* ##srfi1#cdrs in k1383 */
static void C_fcall f_2787(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2787,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2793,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 774  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t3);}

/* a2792 in ##srfi1#cdrs in k1383 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2793,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2799,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2799(t6,t1,((C_word*)t0)[2]);}

/* recur in a2792 in ##srfi1#cdrs in k1383 */
static void C_fcall f_2799(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2799,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 779  abort */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_slot(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2829,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 780  recur */
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}

/* k2827 in recur in a2792 in ##srfi1#cdrs in k1383 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2829,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* concatenate! in k1383 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2781,3,t0,t1,t2);}
/* srfi-1.scm: 751  reduce-right */
t3=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[51]+1),C_SCHEME_END_OF_LIST,t2);}

/* concatenate in k1383 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2775,3,t0,t1,t2);}
/* srfi-1.scm: 750  reduce-right */
t3=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[56]+1),C_SCHEME_END_OF_LIST,t2);}

/* append-reverse! in k1383 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2751,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2757,tmp=(C_word)a,a+=2,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2757(t2,t3));}

/* lp in append-reverse! in k1383 */
static C_word C_fcall f_2757(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
return(t3);}
else{
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_i_setslot(t1,C_fix(1),t2);
t7=t3;
t8=t1;
t1=t7;
t2=t8;
goto loop;}}

/* append-reverse in k1383 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2721,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2727,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_2727(t7,t1,t2,t3);}

/* lp in append-reverse in k1383 */
static void C_fcall f_2727(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2727,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
/* srfi-1.scm: 740  lp */
t9=t1;
t10=t4;
t11=t6;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* append! in k1383 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2645r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2645r(t0,t1,t2);}}

static void C_ccall f_2645r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2651,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2651(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* lp in append! in k1383 */
static void C_fcall f_2651(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2651,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2680,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 708  last-pair */
t7=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
/* srfi-1.scm: 705  lp */
t8=t1;
t9=t5;
t10=t4;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2678 in lp in append! in k1383 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2680,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2682(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* lp2 in k2678 in lp in append! in k1383 */
static void C_fcall f_2682(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2682,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_setslot(t2,C_fix(1),t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2705,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
/* srfi-1.scm: 714  last-pair */
t8=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}
else{
t8=t2;
/* srfi-1.scm: 714  lp2 */
t10=t1;
t11=t8;
t12=t5;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}

/* k2703 in lp2 in k2678 in lp in append! in k1383 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 714  lp2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2682(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unzip5 in k1383 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2561,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2567,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2567(t6,t1,t2);}

/* recur in unzip5 in k1383 */
static void C_fcall f_2567(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2567,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 686  values */
C_values(7,0,t1,t2,t2,t2,t2,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2595,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a2594 in recur in unzip5 in k1383 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2595,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_u_i_car(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t7,t2);
t9=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
t11=(C_word)C_u_i_caddr(((C_word*)t0)[2]);
t12=(C_word)C_a_i_cons(&a,2,t11,t4);
t13=(C_word)C_u_i_cadddr(((C_word*)t0)[2]);
t14=(C_word)C_a_i_cons(&a,2,t13,t5);
t15=(C_word)C_u_i_cddddr(((C_word*)t0)[2]);
t16=(C_word)C_u_i_car(t15);
t17=(C_word)C_a_i_cons(&a,2,t16,t6);
/* srfi-1.scm: 689  values */
C_values(7,0,t1,t8,t10,t12,t14,t17);}

/* a2584 in recur in unzip5 in k1383 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2585,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 688  recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2567(t3,t1,t2);}

/* unzip4 in k1383 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2489,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2495,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2495(t6,t1,t2);}

/* recur in unzip4 in k1383 */
static void C_fcall f_2495(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2495,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 676  values */
C_values(6,0,t1,t2,t2,t2,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2523,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a2522 in recur in unzip4 in k1383 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2523,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_u_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
t10=(C_word)C_u_i_caddr(((C_word*)t0)[2]);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
t12=(C_word)C_u_i_cadddr(((C_word*)t0)[2]);
t13=(C_word)C_a_i_cons(&a,2,t12,t5);
/* srfi-1.scm: 679  values */
C_values(6,0,t1,t7,t9,t11,t13);}

/* a2512 in recur in unzip4 in k1383 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2513,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 678  recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2495(t3,t1,t2);}

/* unzip3 in k1383 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2425,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2431,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2431(t6,t1,t2);}

/* recur in unzip3 in k1383 */
static void C_fcall f_2431(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2431,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 667  values */
C_values(5,0,t1,t2,t2,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2449,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a2458 in recur in unzip3 in k1383 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2459,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_i_car(((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,t2);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_i_caddr(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,t4);
/* srfi-1.scm: 670  values */
C_values(5,0,t1,t6,t8,t10);}

/* a2448 in recur in unzip3 in k1383 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2449,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 669  recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2431(t3,t1,t2);}

/* unzip2 in k1383 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2369,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2375,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2375(t6,t1,t2);}

/* recur in unzip2 in k1383 */
static void C_fcall f_2375(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2375,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 659  values */
C_values(4,0,t1,t2,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2393,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2403,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a2402 in recur in unzip2 in k1383 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2403,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[2]);
t5=(C_word)C_a_i_cons(&a,2,t4,t2);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-1.scm: 662  values */
C_values(4,0,t1,t5,t7);}

/* a2392 in recur in unzip2 in k1383 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 661  recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2375(t3,t1,t2);}

/* unzip1 in k1383 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2328,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2334,a[2]=t4,a[3]=t8,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2334(t10,t1,t2);}

/* loop268 in unzip1 in k1383 */
static void C_fcall f_2334(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2334,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=*((C_word*)lf[23]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g284285 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2361 in loop268 in unzip1 in k1383 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop268281 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2334(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop268281 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2334(t6,((C_word*)t0)[3],t5);}}

/* last-pair in k1383 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2307,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2313,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2313(t2));}

/* lp in last-pair in k1383 */
static C_word C_fcall f_2313(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
t2=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t5=t2;
t1=t5;
goto loop;}
else{
t3=t1;
return(t3);}}

/* last in k1383 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2297,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2305,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 643  last-pair */
t4=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2303 in last in k1383 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_car(t1));}

/* split-at! in k1383 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2266,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[44]);
t5=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t5)){
/* srfi-1.scm: 636  values */
C_values(4,0,t1,C_SCHEME_END_OF_LIST,t2);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2282,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* srfi-1.scm: 637  drop */
t8=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t2,t7);}}

/* k2280 in split-at! in k1383 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_i_set_i_slot(t1,C_fix(1),C_SCHEME_END_OF_LIST);
/* srfi-1.scm: 640  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* split-at in k1383 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2214,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[43]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2223,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_2223(t8,t1,t2,t3);}

/* recur in split-at in k1383 */
static void C_fcall f_2223(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2223,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* srfi-1.scm: 629  values */
C_values(4,0,t1,C_SCHEME_END_OF_LIST,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2238,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2252,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a2251 in recur in split-at in k1383 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2252,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[2]);
t5=(C_word)C_a_i_cons(&a,2,t4,t2);
/* srfi-1.scm: 631  values */
C_values(4,0,t1,t5,t3);}

/* a2237 in recur in split-at in k1383 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2238,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 630  recur */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2223(t4,t1,t2,t3);}

/* drop-right! in k1383 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2172,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2176,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 570  drop */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k2174 in drop-right! in k1383 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2191(t3,((C_word*)t0)[3],t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* lp in k2174 in drop-right! in k1383 */
static C_word C_fcall f_2191(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_slot(t2,C_fix(1));
t8=t3;
t9=t4;
t1=t8;
t2=t9;
goto loop;}
else{
t3=(C_word)C_i_set_i_slot(t1,C_fix(1),C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
return(t4);}}

/* drop-right in k1383 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2134,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 561  drop */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k2140 in drop-right in k1383 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2144,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2144(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* recur in k2140 in drop-right in k1383 */
static void C_fcall f_2144(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2144,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2162,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-1.scm: 563  recur */
t9=t5;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k2160 in recur in k2140 in drop-right in k1383 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* take-right in k1383 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2104,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2112,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 554  drop */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k2110 in take-right in k1383 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2114,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2114(((C_word*)t0)[2],t1));}

/* lp in k2110 in take-right in k1383 */
static C_word C_fcall f_2114(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_slot(t2,C_fix(1));
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t1;
return(t3);}}

/* take! in k1383 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2081,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[39]);
t5=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2098,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* srfi-1.scm: 545  drop */
t8=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t2,t7);}}

/* k2096 in take! in k1383 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(t1,C_fix(1),C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* drop in k1383 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2052,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[38]);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2061,tmp=(C_word)a,a+=2,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_2061(t2,t3));}

/* iter in drop in k1383 */
static C_word C_fcall f_2061(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=t1;
return(t4);}
else{
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t8=t4;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}

/* take in k1383 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2015,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[37]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2024,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_2024(t8,t1,t2,t3);}

/* recur in take in k1383 */
static void C_fcall f_2024(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2024,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2042,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* srfi-1.scm: 533  recur */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k2040 in recur in take in k1383 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2042,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* car+cdr in k1383 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1998,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[36]);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 523  values */
C_values(4,0,t1,t4,t5);}

/* tenth in k1383 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1984,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=(C_word)C_u_i_cddddr(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_i_cadr(t4));}

/* ninth in k1383 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1970,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=(C_word)C_u_i_cddddr(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_i_car(t4));}

/* eighth in k1383 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1960,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_cadddr(t3));}

/* seventh in k1383 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1950,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_caddr(t3));}

/* sixth in k1383 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1940,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_cadr(t3));}

/* fifth in k1383 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1930,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_car(t3));}

/* zip in k1383 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_1920r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1920r(t0,t1,t2,t3);}}

static void C_ccall f_1920r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_apply(6,0,t1,*((C_word*)lf[20]+1),*((C_word*)lf[21]+1),t2,t3);}

/* length+ in k1383 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1871,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1877,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1877(t2,t2,C_fix(0)));}

/* lp in length+ in k1383 */
static C_word C_fcall f_1877(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t5,C_fix(1));
t9=(C_word)C_eqp(t6,t7);
if(C_truep(t9)){
return(C_SCHEME_FALSE);}
else{
t12=t6;
t13=t7;
t14=t8;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}
else{
return(t5);}}
else{
t4=t3;
return(t4);}}

/* list= in k1383 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1771r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1771r(t0,t1,t2,t3);}}

static void C_ccall f_1771r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1791,a[2]=t2,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_1791(t10,t1,t5,t6);}}

/* lp1 in list= in k1383 */
static void C_fcall f_1791(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1791,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_eqp(t2,t5);
if(C_truep(t7)){
/* srfi-1.scm: 440  lp1 */
t12=t1;
t13=t5;
t14=t6;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t6,a[5]=t5,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_1818(t11,t1,t2,t5);}}}

/* lp2 in lp1 in list= in k1383 */
static void C_fcall f_1818(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1818,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 444  lp1 */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1791(t4,t1,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1846,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 446  = */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}}

/* k1844 in lp2 in lp1 in list= in k1383 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-1.scm: 447  lp2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1818(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* null-list? in k1383 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1768,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_null_list_p(t2));}

/* not-pair? in k1383 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1765,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not_pair_p(t2));}

/* circular-list? in k1383 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1726,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1732,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1732(t2,t2));}

/* lp in circular-list? in k1383 */
static C_word C_fcall f_1732(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
return(t6);}
else{
t8=t4;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}

/* dotted-list? in k1383 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1669,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1675,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1675(t2,t2));}

/* lp in dotted-list? in k1383 */
static C_word C_fcall f_1675(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
return(C_SCHEME_FALSE);}
else{
t10=t4;
t11=t5;
t1=t10;
t2=t11;
goto loop;}}
else{
t4=(C_word)C_i_nullp(t3);
return((C_word)C_i_not(t4));}}
else{
t3=(C_word)C_i_nullp(t1);
return((C_word)C_i_not(t3));}}

/* circular-list in k1383 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1655r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1655r(t0,t1,t2,t3);}}

static void C_ccall f_1655r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1666,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 377  last-pair */
t6=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k1664 in circular-list in k1383 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(1),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}

/* iota in k1383 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1545r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1545r(t0,t1,t2,t3);}}

static void C_ccall f_1545r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_number_2(t2,lf[7]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1552,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_lessp(t2,C_fix(0)))){
/* srfi-1.scm: 315  ##sys#error */
t6=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[7],lf[8],*((C_word*)lf[7]+1),t2);}
else{
t6=t5;
f_1552(2,t6,C_SCHEME_UNDEFINED);}}

/* k1550 in iota in k1383 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1599,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1604,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-start6385 */
t6=t5;
f_1604(t6,((C_word*)t0)[2]);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-step6483 */
t8=t4;
f_1599(t8,((C_word*)t0)[2],t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body6169 */
t10=t3;
f_1553(t10,((C_word*)t0)[2],t6,t8);}}}

/* def-start63 in k1550 in iota in k1383 */
static void C_fcall f_1604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1604,NULL,2,t0,t1);}
/* def-step6483 */
t2=((C_word*)t0)[2];
f_1599(t2,t1,C_fix(0));}

/* def-step64 in k1550 in iota in k1383 */
static void C_fcall f_1599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1599,NULL,3,t0,t1,t2);}
/* body6169 */
t3=((C_word*)t0)[2];
f_1553(t3,t1,t2,C_fix(1));}

/* body61 in k1550 in iota in k1383 */
static void C_fcall f_1553(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1553,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t2,lf[7]);
t5=(C_word)C_i_check_number_2(t3,lf[7]);
t6=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t7=(C_word)C_a_i_times(&a,2,t6,t3);
t8=(C_word)C_a_i_plus(&a,2,t2,t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1568,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_1568(t12,t1,((C_word*)t0)[2],t8,C_SCHEME_END_OF_LIST);}

/* doloop73 in body61 in k1550 in iota in k1383 */
static void C_fcall f_1568(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(11);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1568,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t5=t4;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t6=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t3,t4);
t10=t1;
t11=t5;
t12=t6;
t13=t7;
t1=t10;
t2=t11;
t3=t12;
t4=t13;
goto loop;}}

/* list-copy in k1383 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1515,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1521,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1521(t6,t1,t2);}

/* recur in list-copy in k1383 */
static void C_fcall f_1521(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1521,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1539,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 307  recur */
t8=t4;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1537 in recur in list-copy in k1383 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1539,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* cons* in k1383 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1485r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1485r(t0,t1,t2,t3);}}

static void C_ccall f_1485r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1491,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_1491(t7,t1,t2,t3);}

/* recur in cons* in k1383 */
static void C_fcall f_1491(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1491,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1505,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-1.scm: 299  recur */
t9=t4;
t10=t5;
t11=t6;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1503 in recur in cons* in k1383 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* list-tabulate in k1383 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1448,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[4]);
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1461,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1461(t9,t1,t5,C_SCHEME_END_OF_LIST);}

/* doloop33 in list-tabulate in k1383 */
static void C_fcall f_1461(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1461,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1483,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 288  proc */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}

/* k1481 in doloop33 in list-tabulate in k1383 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1483,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_1461(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* make-list in k1383 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1393r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1393r(t0,t1,t2,t3);}}

static void C_ccall f_1393r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t4=(C_word)C_i_check_exact_2(t2,lf[1]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1400,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_1400(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1400(2,t7,(C_word)C_u_i_car(t3));}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* srfi-1.scm: 271  ##sys#error */
t8=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[1],lf[3],t7);}}}

/* k1398 in make-list in k1383 */
static void C_ccall f_1400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1400,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1405,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1405(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* doloop22 in k1398 in make-list in k1383 */
static void C_fcall f_1405(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1405,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t8=t1;
t9=t4;
t10=t5;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* xcons in k1383 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1387,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,t2));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[424] = {
{"toplevel:srfi_1_scm",(void*)C_srfi_1_toplevel},
{"f_1385:srfi_1_scm",(void*)f_1385},
{"f_6116:srfi_1_scm",(void*)f_6116},
{"f_6123:srfi_1_scm",(void*)f_6123},
{"f_6140:srfi_1_scm",(void*)f_6140},
{"f_6150:srfi_1_scm",(void*)f_6150},
{"f_6148:srfi_1_scm",(void*)f_6148},
{"f_6076:srfi_1_scm",(void*)f_6076},
{"f_6083:srfi_1_scm",(void*)f_6083},
{"f_6100:srfi_1_scm",(void*)f_6100},
{"f_6110:srfi_1_scm",(void*)f_6110},
{"f_6108:srfi_1_scm",(void*)f_6108},
{"f_6018:srfi_1_scm",(void*)f_6018},
{"f_6024:srfi_1_scm",(void*)f_6024},
{"f_6036:srfi_1_scm",(void*)f_6036},
{"f_6060:srfi_1_scm",(void*)f_6060},
{"f_6067:srfi_1_scm",(void*)f_6067},
{"f_6030:srfi_1_scm",(void*)f_6030},
{"f_5964:srfi_1_scm",(void*)f_5964},
{"f_5970:srfi_1_scm",(void*)f_5970},
{"f_5982:srfi_1_scm",(void*)f_5982},
{"f_6006:srfi_1_scm",(void*)f_6006},
{"f_6013:srfi_1_scm",(void*)f_6013},
{"f_5976:srfi_1_scm",(void*)f_5976},
{"f_5927:srfi_1_scm",(void*)f_5927},
{"f_5931:srfi_1_scm",(void*)f_5931},
{"f_5948:srfi_1_scm",(void*)f_5948},
{"f_5954:srfi_1_scm",(void*)f_5954},
{"f_5962:srfi_1_scm",(void*)f_5962},
{"f_5890:srfi_1_scm",(void*)f_5890},
{"f_5894:srfi_1_scm",(void*)f_5894},
{"f_5911:srfi_1_scm",(void*)f_5911},
{"f_5917:srfi_1_scm",(void*)f_5917},
{"f_5925:srfi_1_scm",(void*)f_5925},
{"f_5857:srfi_1_scm",(void*)f_5857},
{"f_5861:srfi_1_scm",(void*)f_5861},
{"f_5867:srfi_1_scm",(void*)f_5867},
{"f_5878:srfi_1_scm",(void*)f_5878},
{"f_5884:srfi_1_scm",(void*)f_5884},
{"f_5824:srfi_1_scm",(void*)f_5824},
{"f_5828:srfi_1_scm",(void*)f_5828},
{"f_5834:srfi_1_scm",(void*)f_5834},
{"f_5845:srfi_1_scm",(void*)f_5845},
{"f_5851:srfi_1_scm",(void*)f_5851},
{"f_5773:srfi_1_scm",(void*)f_5773},
{"f_5779:srfi_1_scm",(void*)f_5779},
{"f_5803:srfi_1_scm",(void*)f_5803},
{"f_5818:srfi_1_scm",(void*)f_5818},
{"f_5813:srfi_1_scm",(void*)f_5813},
{"f_5725:srfi_1_scm",(void*)f_5725},
{"f_5731:srfi_1_scm",(void*)f_5731},
{"f_5755:srfi_1_scm",(void*)f_5755},
{"f_5767:srfi_1_scm",(void*)f_5767},
{"f_5762:srfi_1_scm",(void*)f_5762},
{"f_5707:srfi_1_scm",(void*)f_5707},
{"f_5713:srfi_1_scm",(void*)f_5713},
{"f_5720:srfi_1_scm",(void*)f_5720},
{"f_5643:srfi_1_scm",(void*)f_5643},
{"f_5663:srfi_1_scm",(void*)f_5663},
{"f_5694:srfi_1_scm",(void*)f_5694},
{"f_5685:srfi_1_scm",(void*)f_5685},
{"f_5585:srfi_1_scm",(void*)f_5585},
{"f_5605:srfi_1_scm",(void*)f_5605},
{"f_5627:srfi_1_scm",(void*)f_5627},
{"f_5573:srfi_1_scm",(void*)f_5573},
{"f_5579:srfi_1_scm",(void*)f_5579},
{"f_5549:srfi_1_scm",(void*)f_5549},
{"f_5555:srfi_1_scm",(void*)f_5555},
{"f_5462:srfi_1_scm",(void*)f_5462},
{"f_5515:srfi_1_scm",(void*)f_5515},
{"f_5528:srfi_1_scm",(void*)f_5528},
{"f_5478:srfi_1_scm",(void*)f_5478},
{"f_5490:srfi_1_scm",(void*)f_5490},
{"f_5503:srfi_1_scm",(void*)f_5503},
{"f_5484:srfi_1_scm",(void*)f_5484},
{"f_5345:srfi_1_scm",(void*)f_5345},
{"f_5433:srfi_1_scm",(void*)f_5433},
{"f_5449:srfi_1_scm",(void*)f_5449},
{"f_5367:srfi_1_scm",(void*)f_5367},
{"f_5379:srfi_1_scm",(void*)f_5379},
{"f_5391:srfi_1_scm",(void*)f_5391},
{"f_5404:srfi_1_scm",(void*)f_5404},
{"f_5385:srfi_1_scm",(void*)f_5385},
{"f_5357:srfi_1_scm",(void*)f_5357},
{"f_5228:srfi_1_scm",(void*)f_5228},
{"f_5312:srfi_1_scm",(void*)f_5312},
{"f_5325:srfi_1_scm",(void*)f_5325},
{"f_5250:srfi_1_scm",(void*)f_5250},
{"f_5262:srfi_1_scm",(void*)f_5262},
{"f_5274:srfi_1_scm",(void*)f_5274},
{"f_5284:srfi_1_scm",(void*)f_5284},
{"f_5268:srfi_1_scm",(void*)f_5268},
{"f_5240:srfi_1_scm",(void*)f_5240},
{"f_5212:srfi_1_scm",(void*)f_5212},
{"f_5218:srfi_1_scm",(void*)f_5218},
{"f_5226:srfi_1_scm",(void*)f_5226},
{"f_5196:srfi_1_scm",(void*)f_5196},
{"f_5202:srfi_1_scm",(void*)f_5202},
{"f_5210:srfi_1_scm",(void*)f_5210},
{"f_5132:srfi_1_scm",(void*)f_5132},
{"f_5190:srfi_1_scm",(void*)f_5190},
{"f_5142:srfi_1_scm",(void*)f_5142},
{"f_5157:srfi_1_scm",(void*)f_5157},
{"f_5173:srfi_1_scm",(void*)f_5173},
{"f_5148:srfi_1_scm",(void*)f_5148},
{"f_5079:srfi_1_scm",(void*)f_5079},
{"f_5085:srfi_1_scm",(void*)f_5085},
{"f_5104:srfi_1_scm",(void*)f_5104},
{"f_5119:srfi_1_scm",(void*)f_5119},
{"f_5109:srfi_1_scm",(void*)f_5109},
{"f_5021:srfi_1_scm",(void*)f_5021},
{"f_5073:srfi_1_scm",(void*)f_5073},
{"f_5031:srfi_1_scm",(void*)f_5031},
{"f_5040:srfi_1_scm",(void*)f_5040},
{"f_5056:srfi_1_scm",(void*)f_5056},
{"f_5034:srfi_1_scm",(void*)f_5034},
{"f_4989:srfi_1_scm",(void*)f_4989},
{"f_4995:srfi_1_scm",(void*)f_4995},
{"f_5008:srfi_1_scm",(void*)f_5008},
{"f_4954:srfi_1_scm",(void*)f_4954},
{"f_4960:srfi_1_scm",(void*)f_4960},
{"f_4976:srfi_1_scm",(void*)f_4976},
{"f_4983:srfi_1_scm",(void*)f_4983},
{"f_4918:srfi_1_scm",(void*)f_4918},
{"f_4924:srfi_1_scm",(void*)f_4924},
{"f_4937:srfi_1_scm",(void*)f_4937},
{"f_4906:srfi_1_scm",(void*)f_4906},
{"f_4910:srfi_1_scm",(void*)f_4910},
{"f_4871:srfi_1_scm",(void*)f_4871},
{"f_4880:srfi_1_scm",(void*)f_4880},
{"f_4888:srfi_1_scm",(void*)f_4888},
{"f_4836:srfi_1_scm",(void*)f_4836},
{"f_4845:srfi_1_scm",(void*)f_4845},
{"f_4853:srfi_1_scm",(void*)f_4853},
{"f_4782:srfi_1_scm",(void*)f_4782},
{"f_4788:srfi_1_scm",(void*)f_4788},
{"f_4772:srfi_1_scm",(void*)f_4772},
{"f_4741:srfi_1_scm",(void*)f_4741},
{"f_4750:srfi_1_scm",(void*)f_4750},
{"f_4689:srfi_1_scm",(void*)f_4689},
{"f_4698:srfi_1_scm",(void*)f_4698},
{"f_4727:srfi_1_scm",(void*)f_4727},
{"f_4714:srfi_1_scm",(void*)f_4714},
{"f_4637:srfi_1_scm",(void*)f_4637},
{"f_4646:srfi_1_scm",(void*)f_4646},
{"f_4675:srfi_1_scm",(void*)f_4675},
{"f_4662:srfi_1_scm",(void*)f_4662},
{"f_4610:srfi_1_scm",(void*)f_4610},
{"f_4619:srfi_1_scm",(void*)f_4619},
{"f_4579:srfi_1_scm",(void*)f_4579},
{"f_4588:srfi_1_scm",(void*)f_4588},
{"f_4596:srfi_1_scm",(void*)f_4596},
{"f_4548:srfi_1_scm",(void*)f_4548},
{"f_4557:srfi_1_scm",(void*)f_4557},
{"f_4565:srfi_1_scm",(void*)f_4565},
{"f_4532:srfi_1_scm",(void*)f_4532},
{"f_4538:srfi_1_scm",(void*)f_4538},
{"f_4546:srfi_1_scm",(void*)f_4546},
{"f_4516:srfi_1_scm",(void*)f_4516},
{"f_4522:srfi_1_scm",(void*)f_4522},
{"f_4530:srfi_1_scm",(void*)f_4530},
{"f_4304:srfi_1_scm",(void*)f_4304},
{"f_4410:srfi_1_scm",(void*)f_4410},
{"f_4469:srfi_1_scm",(void*)f_4469},
{"f_4485:srfi_1_scm",(void*)f_4485},
{"f_4488:srfi_1_scm",(void*)f_4488},
{"f_4419:srfi_1_scm",(void*)f_4419},
{"f_4435:srfi_1_scm",(void*)f_4435},
{"f_4445:srfi_1_scm",(void*)f_4445},
{"f_4361:srfi_1_scm",(void*)f_4361},
{"f_4367:srfi_1_scm",(void*)f_4367},
{"f_4380:srfi_1_scm",(void*)f_4380},
{"f_4316:srfi_1_scm",(void*)f_4316},
{"f_4322:srfi_1_scm",(void*)f_4322},
{"f_4335:srfi_1_scm",(void*)f_4335},
{"f_4236:srfi_1_scm",(void*)f_4236},
{"f_4242:srfi_1_scm",(void*)f_4242},
{"f_4269:srfi_1_scm",(void*)f_4269},
{"f_4276:srfi_1_scm",(void*)f_4276},
{"f_4263:srfi_1_scm",(void*)f_4263},
{"f_4115:srfi_1_scm",(void*)f_4115},
{"f_4121:srfi_1_scm",(void*)f_4121},
{"f_4230:srfi_1_scm",(void*)f_4230},
{"f_4222:srfi_1_scm",(void*)f_4222},
{"f_4176:srfi_1_scm",(void*)f_4176},
{"f_4182:srfi_1_scm",(void*)f_4182},
{"f_4195:srfi_1_scm",(void*)f_4195},
{"f_4143:srfi_1_scm",(void*)f_4143},
{"f_4156:srfi_1_scm",(void*)f_4156},
{"f_4073:srfi_1_scm",(void*)f_4073},
{"f_4079:srfi_1_scm",(void*)f_4079},
{"f_4098:srfi_1_scm",(void*)f_4098},
{"f_4101:srfi_1_scm",(void*)f_4101},
{"f_3996:srfi_1_scm",(void*)f_3996},
{"f_4046:srfi_1_scm",(void*)f_4046},
{"f_4059:srfi_1_scm",(void*)f_4059},
{"f_4066:srfi_1_scm",(void*)f_4066},
{"f_4012:srfi_1_scm",(void*)f_4012},
{"f_4024:srfi_1_scm",(void*)f_4024},
{"f_4034:srfi_1_scm",(void*)f_4034},
{"f_4041:srfi_1_scm",(void*)f_4041},
{"f_4018:srfi_1_scm",(void*)f_4018},
{"f_3901:srfi_1_scm",(void*)f_3901},
{"f_3962:srfi_1_scm",(void*)f_3962},
{"f_3972:srfi_1_scm",(void*)f_3972},
{"f_3975:srfi_1_scm",(void*)f_3975},
{"f_3979:srfi_1_scm",(void*)f_3979},
{"f_3917:srfi_1_scm",(void*)f_3917},
{"f_3929:srfi_1_scm",(void*)f_3929},
{"f_3939:srfi_1_scm",(void*)f_3939},
{"f_3943:srfi_1_scm",(void*)f_3943},
{"f_3951:srfi_1_scm",(void*)f_3951},
{"f_3923:srfi_1_scm",(void*)f_3923},
{"f_3829:srfi_1_scm",(void*)f_3829},
{"f_3887:srfi_1_scm",(void*)f_3887},
{"f_3895:srfi_1_scm",(void*)f_3895},
{"f_3841:srfi_1_scm",(void*)f_3841},
{"f_3859:srfi_1_scm",(void*)f_3859},
{"f_3874:srfi_1_scm",(void*)f_3874},
{"f_3853:srfi_1_scm",(void*)f_3853},
{"f_3038:srfi_1_scm",(void*)f_3038},
{"f_3056:srfi_1_scm",(void*)f_3056},
{"f_3068:srfi_1_scm",(void*)f_3068},
{"f_3080:srfi_1_scm",(void*)f_3080},
{"f_3074:srfi_1_scm",(void*)f_3074},
{"f_3062:srfi_1_scm",(void*)f_3062},
{"f_3050:srfi_1_scm",(void*)f_3050},
{"f_3833:srfi_1_scm",(void*)f_3833},
{"f_3770:srfi_1_scm",(void*)f_3770},
{"f_3807:srfi_1_scm",(void*)f_3807},
{"f_3820:srfi_1_scm",(void*)f_3820},
{"f_3786:srfi_1_scm",(void*)f_3786},
{"f_3790:srfi_1_scm",(void*)f_3790},
{"f_3799:srfi_1_scm",(void*)f_3799},
{"f_3661:srfi_1_scm",(void*)f_3661},
{"f_3743:srfi_1_scm",(void*)f_3743},
{"f_3747:srfi_1_scm",(void*)f_3747},
{"f_3760:srfi_1_scm",(void*)f_3760},
{"f_3683:srfi_1_scm",(void*)f_3683},
{"f_3695:srfi_1_scm",(void*)f_3695},
{"f_3699:srfi_1_scm",(void*)f_3699},
{"f_3710:srfi_1_scm",(void*)f_3710},
{"f_3724:srfi_1_scm",(void*)f_3724},
{"f_3704:srfi_1_scm",(void*)f_3704},
{"f_3673:srfi_1_scm",(void*)f_3673},
{"f_3655:srfi_1_scm",(void*)f_3655},
{"f_3649:srfi_1_scm",(void*)f_3649},
{"f_3605:srfi_1_scm",(void*)f_3605},
{"f_3625:srfi_1_scm",(void*)f_3625},
{"f_3639:srfi_1_scm",(void*)f_3639},
{"f_3585:srfi_1_scm",(void*)f_3585},
{"f_3520:srfi_1_scm",(void*)f_3520},
{"f_3566:srfi_1_scm",(void*)f_3566},
{"f_3583:srfi_1_scm",(void*)f_3583},
{"f_3536:srfi_1_scm",(void*)f_3536},
{"f_3540:srfi_1_scm",(void*)f_3540},
{"f_3557:srfi_1_scm",(void*)f_3557},
{"f_3553:srfi_1_scm",(void*)f_3553},
{"f_3454:srfi_1_scm",(void*)f_3454},
{"f_3500:srfi_1_scm",(void*)f_3500},
{"f_3514:srfi_1_scm",(void*)f_3514},
{"f_3470:srfi_1_scm",(void*)f_3470},
{"f_3474:srfi_1_scm",(void*)f_3474},
{"f_3495:srfi_1_scm",(void*)f_3495},
{"f_3487:srfi_1_scm",(void*)f_3487},
{"f_3389:srfi_1_scm",(void*)f_3389},
{"f_3431:srfi_1_scm",(void*)f_3431},
{"f_3448:srfi_1_scm",(void*)f_3448},
{"f_3405:srfi_1_scm",(void*)f_3405},
{"f_3409:srfi_1_scm",(void*)f_3409},
{"f_3426:srfi_1_scm",(void*)f_3426},
{"f_2841:srfi_1_scm",(void*)f_2841},
{"f_2859:srfi_1_scm",(void*)f_2859},
{"f_3422:srfi_1_scm",(void*)f_3422},
{"f_3318:srfi_1_scm",(void*)f_3318},
{"f_3365:srfi_1_scm",(void*)f_3365},
{"f_3383:srfi_1_scm",(void*)f_3383},
{"f_3334:srfi_1_scm",(void*)f_3334},
{"f_3346:srfi_1_scm",(void*)f_3346},
{"f_3360:srfi_1_scm",(void*)f_3360},
{"f_3340:srfi_1_scm",(void*)f_3340},
{"f_2954:srfi_1_scm",(void*)f_2954},
{"f_2960:srfi_1_scm",(void*)f_2960},
{"f_2978:srfi_1_scm",(void*)f_2978},
{"f_2999:srfi_1_scm",(void*)f_2999},
{"f_3011:srfi_1_scm",(void*)f_3011},
{"f_3005:srfi_1_scm",(void*)f_3005},
{"f_2993:srfi_1_scm",(void*)f_2993},
{"f_2972:srfi_1_scm",(void*)f_2972},
{"f_3236:srfi_1_scm",(void*)f_3236},
{"f_3294:srfi_1_scm",(void*)f_3294},
{"f_3301:srfi_1_scm",(void*)f_3301},
{"f_3308:srfi_1_scm",(void*)f_3308},
{"f_3316:srfi_1_scm",(void*)f_3316},
{"f_3312:srfi_1_scm",(void*)f_3312},
{"f_3260:srfi_1_scm",(void*)f_3260},
{"f_3267:srfi_1_scm",(void*)f_3267},
{"f_3277:srfi_1_scm",(void*)f_3277},
{"f_3285:srfi_1_scm",(void*)f_3285},
{"f_3281:srfi_1_scm",(void*)f_3281},
{"f_3190:srfi_1_scm",(void*)f_3190},
{"f_3200:srfi_1_scm",(void*)f_3200},
{"f_3207:srfi_1_scm",(void*)f_3207},
{"f_3214:srfi_1_scm",(void*)f_3214},
{"f_3222:srfi_1_scm",(void*)f_3222},
{"f_3097:srfi_1_scm",(void*)f_3097},
{"f_3160:srfi_1_scm",(void*)f_3160},
{"f_3181:srfi_1_scm",(void*)f_3181},
{"f_3109:srfi_1_scm",(void*)f_3109},
{"f_3127:srfi_1_scm",(void*)f_3127},
{"f_3148:srfi_1_scm",(void*)f_3148},
{"f_3121:srfi_1_scm",(void*)f_3121},
{"f_2868:srfi_1_scm",(void*)f_2868},
{"f_2874:srfi_1_scm",(void*)f_2874},
{"f_2880:srfi_1_scm",(void*)f_2880},
{"f_2898:srfi_1_scm",(void*)f_2898},
{"f_2919:srfi_1_scm",(void*)f_2919},
{"f_2931:srfi_1_scm",(void*)f_2931},
{"f_2925:srfi_1_scm",(void*)f_2925},
{"f_2913:srfi_1_scm",(void*)f_2913},
{"f_2892:srfi_1_scm",(void*)f_2892},
{"f_2787:srfi_1_scm",(void*)f_2787},
{"f_2793:srfi_1_scm",(void*)f_2793},
{"f_2799:srfi_1_scm",(void*)f_2799},
{"f_2829:srfi_1_scm",(void*)f_2829},
{"f_2781:srfi_1_scm",(void*)f_2781},
{"f_2775:srfi_1_scm",(void*)f_2775},
{"f_2751:srfi_1_scm",(void*)f_2751},
{"f_2757:srfi_1_scm",(void*)f_2757},
{"f_2721:srfi_1_scm",(void*)f_2721},
{"f_2727:srfi_1_scm",(void*)f_2727},
{"f_2645:srfi_1_scm",(void*)f_2645},
{"f_2651:srfi_1_scm",(void*)f_2651},
{"f_2680:srfi_1_scm",(void*)f_2680},
{"f_2682:srfi_1_scm",(void*)f_2682},
{"f_2705:srfi_1_scm",(void*)f_2705},
{"f_2561:srfi_1_scm",(void*)f_2561},
{"f_2567:srfi_1_scm",(void*)f_2567},
{"f_2595:srfi_1_scm",(void*)f_2595},
{"f_2585:srfi_1_scm",(void*)f_2585},
{"f_2489:srfi_1_scm",(void*)f_2489},
{"f_2495:srfi_1_scm",(void*)f_2495},
{"f_2523:srfi_1_scm",(void*)f_2523},
{"f_2513:srfi_1_scm",(void*)f_2513},
{"f_2425:srfi_1_scm",(void*)f_2425},
{"f_2431:srfi_1_scm",(void*)f_2431},
{"f_2459:srfi_1_scm",(void*)f_2459},
{"f_2449:srfi_1_scm",(void*)f_2449},
{"f_2369:srfi_1_scm",(void*)f_2369},
{"f_2375:srfi_1_scm",(void*)f_2375},
{"f_2403:srfi_1_scm",(void*)f_2403},
{"f_2393:srfi_1_scm",(void*)f_2393},
{"f_2328:srfi_1_scm",(void*)f_2328},
{"f_2334:srfi_1_scm",(void*)f_2334},
{"f_2363:srfi_1_scm",(void*)f_2363},
{"f_2307:srfi_1_scm",(void*)f_2307},
{"f_2313:srfi_1_scm",(void*)f_2313},
{"f_2297:srfi_1_scm",(void*)f_2297},
{"f_2305:srfi_1_scm",(void*)f_2305},
{"f_2266:srfi_1_scm",(void*)f_2266},
{"f_2282:srfi_1_scm",(void*)f_2282},
{"f_2214:srfi_1_scm",(void*)f_2214},
{"f_2223:srfi_1_scm",(void*)f_2223},
{"f_2252:srfi_1_scm",(void*)f_2252},
{"f_2238:srfi_1_scm",(void*)f_2238},
{"f_2172:srfi_1_scm",(void*)f_2172},
{"f_2176:srfi_1_scm",(void*)f_2176},
{"f_2191:srfi_1_scm",(void*)f_2191},
{"f_2134:srfi_1_scm",(void*)f_2134},
{"f_2142:srfi_1_scm",(void*)f_2142},
{"f_2144:srfi_1_scm",(void*)f_2144},
{"f_2162:srfi_1_scm",(void*)f_2162},
{"f_2104:srfi_1_scm",(void*)f_2104},
{"f_2112:srfi_1_scm",(void*)f_2112},
{"f_2114:srfi_1_scm",(void*)f_2114},
{"f_2081:srfi_1_scm",(void*)f_2081},
{"f_2098:srfi_1_scm",(void*)f_2098},
{"f_2052:srfi_1_scm",(void*)f_2052},
{"f_2061:srfi_1_scm",(void*)f_2061},
{"f_2015:srfi_1_scm",(void*)f_2015},
{"f_2024:srfi_1_scm",(void*)f_2024},
{"f_2042:srfi_1_scm",(void*)f_2042},
{"f_1998:srfi_1_scm",(void*)f_1998},
{"f_1984:srfi_1_scm",(void*)f_1984},
{"f_1970:srfi_1_scm",(void*)f_1970},
{"f_1960:srfi_1_scm",(void*)f_1960},
{"f_1950:srfi_1_scm",(void*)f_1950},
{"f_1940:srfi_1_scm",(void*)f_1940},
{"f_1930:srfi_1_scm",(void*)f_1930},
{"f_1920:srfi_1_scm",(void*)f_1920},
{"f_1871:srfi_1_scm",(void*)f_1871},
{"f_1877:srfi_1_scm",(void*)f_1877},
{"f_1771:srfi_1_scm",(void*)f_1771},
{"f_1791:srfi_1_scm",(void*)f_1791},
{"f_1818:srfi_1_scm",(void*)f_1818},
{"f_1846:srfi_1_scm",(void*)f_1846},
{"f_1768:srfi_1_scm",(void*)f_1768},
{"f_1765:srfi_1_scm",(void*)f_1765},
{"f_1726:srfi_1_scm",(void*)f_1726},
{"f_1732:srfi_1_scm",(void*)f_1732},
{"f_1669:srfi_1_scm",(void*)f_1669},
{"f_1675:srfi_1_scm",(void*)f_1675},
{"f_1655:srfi_1_scm",(void*)f_1655},
{"f_1666:srfi_1_scm",(void*)f_1666},
{"f_1545:srfi_1_scm",(void*)f_1545},
{"f_1552:srfi_1_scm",(void*)f_1552},
{"f_1604:srfi_1_scm",(void*)f_1604},
{"f_1599:srfi_1_scm",(void*)f_1599},
{"f_1553:srfi_1_scm",(void*)f_1553},
{"f_1568:srfi_1_scm",(void*)f_1568},
{"f_1515:srfi_1_scm",(void*)f_1515},
{"f_1521:srfi_1_scm",(void*)f_1521},
{"f_1539:srfi_1_scm",(void*)f_1539},
{"f_1485:srfi_1_scm",(void*)f_1485},
{"f_1491:srfi_1_scm",(void*)f_1491},
{"f_1505:srfi_1_scm",(void*)f_1505},
{"f_1448:srfi_1_scm",(void*)f_1448},
{"f_1461:srfi_1_scm",(void*)f_1461},
{"f_1483:srfi_1_scm",(void*)f_1483},
{"f_1393:srfi_1_scm",(void*)f_1393},
{"f_1400:srfi_1_scm",(void*)f_1400},
{"f_1405:srfi_1_scm",(void*)f_1405},
{"f_1387:srfi_1_scm",(void*)f_1387},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
