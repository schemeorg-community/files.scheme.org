/* Generated from extras.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:17
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: extras.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file uextras.c -extend ./private-namespace.scm
   unit: extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[131];
static double C_possibly_force_alignment;


/* from srand */
static C_word C_fcall stub87(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub87(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned int t0=(unsigned int )C_num_to_unsigned_int(C_a0);
srand(t0);
return C_r;}

C_noret_decl(C_extras_toplevel)
C_externexport void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_895)
static void C_ccall f_895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3594)
static void C_ccall f_3594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3245)
static void C_fcall f_3245(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3283)
static void C_fcall f_3283(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3318)
static void C_fcall f_3318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static C_word C_fcall f_3496(C_word t0,C_word t1);
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_fcall f_3299(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static C_word C_fcall f_3292(C_word t0);
C_noret_decl(f_3255)
static void C_ccall f_3255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_fcall f_1935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_fcall f_2556(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3111)
static void C_fcall f_3111(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3121)
static void C_fcall f_3121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3038)
static void C_ccall f_3038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2890)
static void C_fcall f_2890(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_fcall f_2975(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2934)
static void C_fcall f_2934(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_fcall f_2893(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_fcall f_2813(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2819)
static void C_fcall f_2819(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_fcall f_2804(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_fcall f_2776(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_fcall f_2624(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_fcall f_2592(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_fcall f_2559(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_fcall f_2048(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_fcall f_2382(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_fcall f_2287(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2294)
static void C_fcall f_2294(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_fcall f_2078(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2098)
static void C_fcall f_2098(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_fcall f_2051(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_fcall f_2029(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static C_word C_fcall f_1996(C_word t0);
C_noret_decl(f_1938)
static void C_fcall f_1938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_fcall f_1970(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1805)
static void C_fcall f_1805(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_fcall f_1800(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1769)
static void C_fcall f_1769(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_fcall f_1786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_fcall f_1717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1727)
static void C_ccall f_1727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_fcall f_1624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1543)
static void C_fcall f_1543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_fcall f_1538(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1496)
static void C_fcall f_1496(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1358)
static void C_fcall f_1358(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1428)
static void C_fcall f_1428(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1435)
static void C_fcall f_1435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_fcall f_1369(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1280)
static void C_fcall f_1280(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1119)
static void C_fcall f_1119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_fcall f_1147(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1211)
static void C_fcall f_1211(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1129)
static void C_fcall f_1129(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_969)
static void C_fcall f_969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_fcall f_964(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_959)
static void C_fcall f_959(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_899)
static void C_fcall f_899(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_910)
static void C_ccall f_910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_912)
static void C_fcall f_912(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_932)
static void C_ccall f_932(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3245)
static void C_fcall trf_3245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3245(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3245(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3283)
static void C_fcall trf_3283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3283(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3283(t0,t1,t2,t3);}

C_noret_decl(trf_3318)
static void C_fcall trf_3318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3318(t0,t1);}

C_noret_decl(trf_3299)
static void C_fcall trf_3299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3299(t0,t1);}

C_noret_decl(trf_1935)
static void C_fcall trf_1935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1935(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1935(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2556)
static void C_fcall trf_2556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2556(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2556(t0,t1,t2,t3);}

C_noret_decl(trf_3111)
static void C_fcall trf_3111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3111(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3111(t0,t1,t2);}

C_noret_decl(trf_3121)
static void C_fcall trf_3121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3121(t0,t1);}

C_noret_decl(trf_2890)
static void C_fcall trf_2890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2890(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_2890(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_2975)
static void C_fcall trf_2975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2975(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2975(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2934)
static void C_fcall trf_2934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2934(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2934(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2893)
static void C_fcall trf_2893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2893(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2893(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2813)
static void C_fcall trf_2813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2813(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2813(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2819)
static void C_fcall trf_2819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2819(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2819(t0,t1,t2,t3);}

C_noret_decl(trf_2804)
static void C_fcall trf_2804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2804(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2804(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2776)
static void C_fcall trf_2776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2776(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2776(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2624)
static void C_fcall trf_2624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2624(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2624(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2592)
static void C_fcall trf_2592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2592(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2592(t0,t1,t2,t3);}

C_noret_decl(trf_2559)
static void C_fcall trf_2559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2559(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2559(t0,t1,t2,t3);}

C_noret_decl(trf_2048)
static void C_fcall trf_2048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2048(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2048(t0,t1,t2,t3);}

C_noret_decl(trf_2382)
static void C_fcall trf_2382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2382(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2382(t0,t1,t2);}

C_noret_decl(trf_2287)
static void C_fcall trf_2287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2287(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2287(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2294)
static void C_fcall trf_2294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2294(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2294(t0,t1);}

C_noret_decl(trf_2078)
static void C_fcall trf_2078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2078(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2078(t0,t1,t2,t3);}

C_noret_decl(trf_2098)
static void C_fcall trf_2098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2098(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2098(t0,t1,t2,t3);}

C_noret_decl(trf_2051)
static void C_fcall trf_2051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2051(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2051(t0,t1,t2,t3);}

C_noret_decl(trf_2029)
static void C_fcall trf_2029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2029(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2029(t0,t1,t2,t3);}

C_noret_decl(trf_1938)
static void C_fcall trf_1938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1938(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1938(t0,t1);}

C_noret_decl(trf_1970)
static void C_fcall trf_1970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1970(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1970(t0,t1);}

C_noret_decl(trf_1805)
static void C_fcall trf_1805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1805(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1805(t0,t1);}

C_noret_decl(trf_1800)
static void C_fcall trf_1800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1800(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1800(t0,t1,t2);}

C_noret_decl(trf_1769)
static void C_fcall trf_1769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1769(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1769(t0,t1,t2,t3);}

C_noret_decl(trf_1786)
static void C_fcall trf_1786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1786(t0,t1);}

C_noret_decl(trf_1717)
static void C_fcall trf_1717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1717(t0,t1);}

C_noret_decl(trf_1624)
static void C_fcall trf_1624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1624(t0,t1);}

C_noret_decl(trf_1543)
static void C_fcall trf_1543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1543(t0,t1);}

C_noret_decl(trf_1538)
static void C_fcall trf_1538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1538(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1538(t0,t1,t2);}

C_noret_decl(trf_1496)
static void C_fcall trf_1496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1496(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1496(t0,t1,t2,t3);}

C_noret_decl(trf_1358)
static void C_fcall trf_1358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1358(t0,t1);}

C_noret_decl(trf_1428)
static void C_fcall trf_1428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1428(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1428(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1435)
static void C_fcall trf_1435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1435(t0,t1);}

C_noret_decl(trf_1369)
static void C_fcall trf_1369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1369(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1369(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1280)
static void C_fcall trf_1280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1280(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1280(t0,t1,t2,t3);}

C_noret_decl(trf_1119)
static void C_fcall trf_1119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1119(t0,t1);}

C_noret_decl(trf_1147)
static void C_fcall trf_1147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1147(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1147(t0,t1,t2);}

C_noret_decl(trf_1211)
static void C_fcall trf_1211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1211(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1211(t0,t1);}

C_noret_decl(trf_1129)
static void C_fcall trf_1129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1129(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1129(t0,t1,t2);}

C_noret_decl(trf_969)
static void C_fcall trf_969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_969(t0,t1);}

C_noret_decl(trf_964)
static void C_fcall trf_964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_964(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_964(t0,t1,t2);}

C_noret_decl(trf_959)
static void C_fcall trf_959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_959(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_959(t0,t1,t2,t3);}

C_noret_decl(trf_899)
static void C_fcall trf_899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_899(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_899(t0,t1,t2,t3,t4);}

C_noret_decl(trf_912)
static void C_fcall trf_912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_912(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_912(t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_extras_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("extras_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(840)){
C_save(t1);
C_rereclaim2(840*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,131);
lf[0]=C_h_intern(&lf[0],4,"read");
lf[1]=C_h_intern(&lf[1],7,"reverse");
lf[2]=C_h_intern(&lf[2],20,"call-with-input-file");
lf[3]=C_h_intern(&lf[3],9,"read-file");
lf[4]=C_h_intern(&lf[4],5,"port\077");
lf[5]=C_h_intern(&lf[5],18,"\003sysstandard-input");
lf[6]=C_h_intern(&lf[6],11,"random-seed");
lf[7]=C_h_intern(&lf[7],17,"\003syscheck-integer");
lf[8]=C_h_intern(&lf[8],15,"current-seconds");
lf[9]=C_h_intern(&lf[9],9,"randomize");
lf[10]=C_h_intern(&lf[10],6,"random");
lf[11]=C_h_intern(&lf[11],11,"make-string");
lf[12]=C_h_intern(&lf[12],9,"read-line");
lf[13]=C_h_intern(&lf[13],13,"\003syssubstring");
lf[14]=C_h_intern(&lf[14],15,"\003sysread-char-0");
lf[15]=C_h_intern(&lf[15],9,"peek-char");
lf[16]=C_h_intern(&lf[16],17,"\003sysstring-append");
lf[17]=C_h_intern(&lf[17],15,"\003sysmake-string");
lf[18]=C_h_intern(&lf[18],14,"\003syscheck-port");
lf[19]=C_h_intern(&lf[19],10,"read-lines");
lf[20]=C_h_intern(&lf[20],16,"\003sysread-string!");
lf[21]=C_h_intern(&lf[21],12,"read-string!");
lf[22]=C_h_intern(&lf[22],18,"open-output-string");
lf[23]=C_h_intern(&lf[23],17,"get-output-string");
lf[24]=C_h_intern(&lf[24],20,"\003sysread-string/port");
lf[25]=C_h_intern(&lf[25],11,"read-string");
lf[26]=C_h_intern(&lf[26],12,"write-string");
lf[27]=C_h_intern(&lf[27],10,"read-token");
lf[28]=C_h_intern(&lf[28],16,"\003syswrite-char-0");
lf[29]=C_h_intern(&lf[29],15,"\003syspeek-char-0");
lf[30]=C_h_intern(&lf[30],7,"display");
lf[31]=C_h_intern(&lf[31],19,"\003sysstandard-output");
lf[32]=C_h_intern(&lf[32],7,"newline");
lf[33]=C_h_intern(&lf[33],10,"write-line");
lf[34]=C_h_intern(&lf[34],9,"read-byte");
lf[35]=C_h_intern(&lf[35],10,"write-byte");
lf[37]=C_h_intern(&lf[37],5,"quote");
lf[38]=C_h_intern(&lf[38],10,"quasiquote");
lf[39]=C_h_intern(&lf[39],7,"unquote");
lf[40]=C_h_intern(&lf[40],16,"unquote-splicing");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001`");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\002,@");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\003 . ");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002()");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\005#!eof");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[53]=C_h_intern(&lf[53],12,"vector->list");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\002#t");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\002#f");
lf[56]=C_h_intern(&lf[56],18,"\003sysnumber->string");
lf[57]=C_h_intern(&lf[57],9,"\003sysprint");
lf[58]=C_h_intern(&lf[58],21,"\003sysprocedure->string");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\001x");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\001u");
lf[65]=C_h_intern(&lf[65],9,"char-name");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\002#\134");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\006#<eof>");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\016#<unspecified>");
lf[69]=C_h_intern(&lf[69],19,"\003syspointer->string");
lf[70]=C_h_intern(&lf[70],28,"\003sysarbitrary-unbound-symbol");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\020#<unbound value>");
lf[72]=C_h_intern(&lf[72],19,"\003sysuser-print-hook");
lf[73]=C_h_intern(&lf[73],13,"string-append");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\007#<port ");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\025#<static blob of size");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\017#<blob of size ");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\002#>");
lf[80]=C_h_intern(&lf[80],23,"\003syslambda-info->string");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\016#<lambda info ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\025#<unprintable object>");
lf[83]=C_h_intern(&lf[83],11,"\003sysnumber\077");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[86]=C_h_intern(&lf[86],21,"reverse-string-append");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[88]=C_h_intern(&lf[88],3,"max");
lf[89]=C_h_intern(&lf[89],28,"\003syssymbol->qualified-string");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[97]=C_h_intern(&lf[97],6,"lambda");
lf[98]=C_h_intern(&lf[98],2,"if");
lf[99]=C_h_intern(&lf[99],4,"set!");
lf[100]=C_h_intern(&lf[100],4,"cond");
lf[101]=C_h_intern(&lf[101],4,"case");
lf[102]=C_h_intern(&lf[102],3,"and");
lf[103]=C_h_intern(&lf[103],2,"or");
lf[104]=C_h_intern(&lf[104],3,"let");
lf[105]=C_h_intern(&lf[105],5,"begin");
lf[106]=C_h_intern(&lf[106],2,"do");
lf[107]=C_h_intern(&lf[107],4,"let*");
lf[108]=C_h_intern(&lf[108],6,"letrec");
lf[109]=C_h_intern(&lf[109],6,"define");
lf[110]=C_h_intern(&lf[110],18,"pretty-print-width");
lf[111]=C_h_intern(&lf[111],12,"pretty-print");
lf[112]=C_h_intern(&lf[112],19,"current-output-port");
lf[113]=C_h_intern(&lf[113],2,"pp");
lf[114]=C_h_intern(&lf[114],5,"write");
lf[116]=C_h_intern(&lf[116],9,"\003syserror");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[118]=C_h_intern(&lf[118],16,"\003sysflush-output");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\037illegal format-string character");
lf[120]=C_h_intern(&lf[120],13,"\003systty-port\077");
lf[121]=C_h_intern(&lf[121],7,"fprintf");
lf[122]=C_h_intern(&lf[122],6,"printf");
lf[123]=C_h_intern(&lf[123],7,"sprintf");
lf[124]=C_h_intern(&lf[124],6,"format");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal destination");
lf[126]=C_h_intern(&lf[126],12,"output-port\077");
lf[127]=C_h_intern(&lf[127],17,"register-feature!");
lf[128]=C_h_intern(&lf[128],7,"srfi-28");
lf[129]=C_h_intern(&lf[129],14,"make-parameter");
lf[130]=C_h_intern(&lf[130],6,"extras");
C_register_lf2(lf,131,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_889,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k887 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k890 in k887 */
static void C_ccall f_892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_895,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 65   register-feature! */
t3=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[130]);}

/* k893 in k890 in k887 */
static void C_ccall f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[51],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_895,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=*((C_word*)lf[1]+1);
t4=*((C_word*)lf[2]+1);
t5=C_mutate((C_word*)lf[3]+1 /* (set! read-file ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_897,a[2]=t2,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t6=C_mutate((C_word*)lf[6]+1 /* (set! random-seed ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1031,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[9]+1 /* (set! randomize ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1052,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[10]+1 /* (set! random ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1070,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[11]+1);
t10=C_mutate((C_word*)lf[12]+1 /* (set! read-line ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1109,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[12]+1);
t12=*((C_word*)lf[2]+1);
t13=*((C_word*)lf[1]+1);
t14=C_mutate((C_word*)lf[19]+1 /* (set! read-lines ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1258,a[2]=t12,a[3]=t11,a[4]=t13,tmp=(C_word)a,a+=5,tmp));
t15=C_mutate((C_word*)lf[20]+1 /* (set! read-string! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1348,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[21]+1 /* (set! read-string! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1494,tmp=(C_word)a,a+=2,tmp));
t17=*((C_word*)lf[22]+1);
t18=*((C_word*)lf[23]+1);
t19=C_mutate((C_word*)lf[24]+1 /* (set! read-string/port ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1588,a[2]=t17,a[3]=t18,tmp=(C_word)a,a+=4,tmp));
t20=C_mutate((C_word*)lf[25]+1 /* (set! read-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1645,tmp=(C_word)a,a+=2,tmp));
t21=*((C_word*)lf[22]+1);
t22=*((C_word*)lf[23]+1);
t23=C_mutate((C_word*)lf[27]+1 /* (set! read-token ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1702,a[2]=t21,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t24=*((C_word*)lf[30]+1);
t25=C_mutate((C_word*)lf[26]+1 /* (set! write-string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1764,a[2]=t24,tmp=(C_word)a,a+=3,tmp));
t26=*((C_word*)lf[30]+1);
t27=*((C_word*)lf[32]+1);
t28=C_mutate((C_word*)lf[33]+1 /* (set! write-line ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1850,a[2]=t26,a[3]=t27,tmp=(C_word)a,a+=4,tmp));
t29=C_mutate((C_word*)lf[34]+1 /* (set! read-byte ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1871,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[35]+1 /* (set! write-byte ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1904,tmp=(C_word)a,a+=2,tmp));
t31=*((C_word*)lf[22]+1);
t32=*((C_word*)lf[23]+1);
t33=C_mutate(&lf[36] /* (set! generic-write ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1935,a[2]=t31,a[3]=t32,tmp=(C_word)a,a+=4,tmp));
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 582  make-parameter */
t35=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t35+1)))(3,t35,t34,C_fix(79));}

/* k3212 in k893 in k890 in k887 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1 /* (set! pretty-print-width ...) */,t1);
t3=C_mutate((C_word*)lf[111]+1 /* (set! pretty-print ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3216,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[113]+1 /* (set! pp ...) */,*((C_word*)lf[111]+1));
t5=*((C_word*)lf[114]+1);
t6=*((C_word*)lf[32]+1);
t7=*((C_word*)lf[30]+1);
t8=*((C_word*)lf[22]+1);
t9=*((C_word*)lf[23]+1);
t10=C_mutate(&lf[115] /* (set! fprintf0 ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3245,a[2]=t8,a[3]=t6,a[4]=t7,a[5]=t5,a[6]=t9,tmp=(C_word)a,a+=7,tmp));
t11=C_mutate((C_word*)lf[121]+1 /* (set! fprintf ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3543,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[122]+1 /* (set! printf ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3549,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[123]+1 /* (set! sprintf ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3555,tmp=(C_word)a,a+=2,tmp));
t14=*((C_word*)lf[121]+1);
t15=*((C_word*)lf[123]+1);
t16=*((C_word*)lf[122]+1);
t17=C_mutate((C_word*)lf[124]+1 /* (set! format ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3561,a[2]=t14,a[3]=t15,a[4]=t16,tmp=(C_word)a,a+=5,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3604,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 674  register-feature! */
t19=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[128]);}

/* k3602 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format in k3212 in k893 in k890 in k887 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_3561r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3561r(t0,t1,t2,t3);}}

static void C_ccall f_3561r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3569,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=t2;
if(C_truep(t6)){
if(C_truep((C_word)C_booleanp(t2))){
C_apply(4,0,t1,((C_word*)t0)[4],((C_word*)t4)[1]);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t7=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t4)[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3594,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 669  output-port? */
t8=*((C_word*)lf[126]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}}}
else{
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t4)[1]);}}

/* k3592 in format in k3212 in k893 in k890 in k887 */
static void C_ccall f_3594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3594,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[5])[1]);}
else{
/* extras.scm: 671  ##sys#error */
t2=*((C_word*)lf[116]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[124],lf[125],((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);}}

/* k3567 in format in k3212 in k893 in k890 in k887 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* sprintf in k3212 in k893 in k890 in k887 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3555r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3555r(t0,t1,t2,t3);}}

static void C_ccall f_3555r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* extras.scm: 659  fprintf0 */
t4=lf[115];
f_3245(t4,t1,lf[123],C_SCHEME_FALSE,t2,t3);}

/* printf in k3212 in k893 in k890 in k887 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3549r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3549r(t0,t1,t2,t3);}}

static void C_ccall f_3549r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* extras.scm: 656  fprintf0 */
t4=lf[115];
f_3245(t4,t1,lf[122],*((C_word*)lf[31]+1),t2,t3);}

/* fprintf in k3212 in k893 in k890 in k887 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_3543r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3543r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3543r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* extras.scm: 653  fprintf0 */
t5=lf[115];
f_3245(t5,t1,lf[121],t2,t3,t4);}

/* fprintf0 in k3212 in k893 in k890 in k887 */
static void C_fcall f_3245(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3245,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=t3,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
/* extras.scm: 601  ##sys#check-port */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,t2);}
else{
t7=t6;
f_3249(2,t7,C_SCHEME_UNDEFINED);}}

/* k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[11])){
/* extras.scm: 602  ##sys#tty-port? */
t4=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[11]);}
else{
/* extras.scm: 604  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k3530 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3252(2,t2,((C_word*)t0)[3]);}
else{
/* extras.scm: 604  open-output-string */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3255,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t1,a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3283,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3283(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_fcall f_3283(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[31],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3283,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_string_2(t2,((C_word*)t0)[7]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(C_word)C_block_size(t2);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3292,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t12,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t16,a[10]=t10,a[11]=t8,a[12]=t7,tmp=(C_word)a,a+=13,tmp));
t18=((C_word*)t16)[1];
f_3318(t18,t1);}

/* loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_fcall f_3318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3318,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=f_3292(((C_word*)((C_word*)t0)[10])[1]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_make_character(126));
t5=(C_truep(t4)?(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=f_3292(((C_word*)((C_word*)t0)[10])[1]);
t7=(C_word)C_u_i_char_upcase(t6);
switch(t7){
case C_make_character(83):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3356,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 625  next */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3299(t9,t8);
case C_make_character(65):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3369,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 626  next */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3299(t9,t8);
case C_make_character(67):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 627  next */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3299(t9,t8);
case C_make_character(66):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3399,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 628  next */
t10=((C_word*)((C_word*)t0)[6])[1];
f_3299(t10,t9);
case C_make_character(79):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3412,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3416,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 629  next */
t10=((C_word*)((C_word*)t0)[6])[1];
f_3299(t10,t9);
case C_make_character(88):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3429,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 630  next */
t10=((C_word*)((C_word*)t0)[6])[1];
f_3299(t10,t9);
case C_make_character(33):
/* extras.scm: 631  ##sys#flush-output */
t8=*((C_word*)lf[118]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t3,((C_word*)t0)[7]);
case C_make_character(63):
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 633  next */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3299(t9,t8);
case C_make_character(126):
/* extras.scm: 637  ##sys#write-char-0 */
t8=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,C_make_character(126),((C_word*)t0)[7]);
default:
t8=(C_word)C_eqp(t7,C_make_character(37));
t9=(C_truep(t8)?t8:(C_word)C_eqp(t7,C_make_character(78)));
if(C_truep(t9)){
/* extras.scm: 638  newline */
t10=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t3,((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t6))){
t10=f_3292(((C_word*)((C_word*)t0)[10])[1]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t12=f_3496(t11,t10);
/* extras.scm: 647  loop */
t25=t1;
t1=t25;
goto loop;}
else{
/* extras.scm: 645  ##sys#error */
t10=*((C_word*)lf[116]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t3,((C_word*)t0)[4],lf[119],t6);}}}}
else{
/* extras.scm: 646  ##sys#write-char-0 */
t6=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t2,((C_word*)t0)[7]);}}}

/* skip in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static C_word C_fcall f_3496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_3292(((C_word*)((C_word*)t0)[3])[1]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k3449 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3454,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 634  next */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3299(t3,t2);}

/* k3452 in k3449 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3454,2,t0,t1);}
t2=(C_word)C_i_check_list_2(t1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 636  rec */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3283(t4,t3,((C_word*)t0)[2],t1);}

/* k3458 in k3452 in k3449 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 647  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3318(t2,((C_word*)t0)[2]);}

/* k3431 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 630  ##sys#number->string */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(16));}

/* k3427 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 630  display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3414 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 629  ##sys#number->string */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(8));}

/* k3410 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 629  display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3397 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 628  ##sys#number->string */
t2=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(2));}

/* k3393 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 628  display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3380 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 627  ##sys#write-char-0 */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3367 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 626  display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3354 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 625  write */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3329 in loop in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 647  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3318(t2,((C_word*)t0)[2]);}

/* next in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_fcall f_3299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3299,NULL,2,t0,t1);}
if(C_truep((C_word)C_eqp(((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST))){
/* extras.scm: 615  ##sys#error */
t2=*((C_word*)lf[116]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],lf[117]);}
else{
t2=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(0));
t3=(C_word)C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in rec in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static C_word C_fcall f_3292(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=(C_word)C_subchar(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* k3253 in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3255,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3277,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 650  get-output-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}}
else{
/* extras.scm: 648  get-output-string */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k3275 in k3253 in k3250 in k3247 in fprintf0 in k3212 in k893 in k890 in k887 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 650  ##sys#print */
t2=*((C_word*)lf[57]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* pretty-print in k3212 in k893 in k890 in k887 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3216r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3216r(t0,t1,t2,t3);}}

static void C_ccall f_3216r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3220,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t5=t4;
f_3220(2,t5,(C_word)C_slot(t3,C_fix(0)));}
else{
/* extras.scm: 585  current-output-port */
t5=*((C_word*)lf[112]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3218 in pretty-print in k3212 in k893 in k890 in k887 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3227,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 586  pretty-print-width */
t4=*((C_word*)lf[110]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3225 in k3218 in pretty-print in k3212 in k893 in k890 in k887 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3229,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 586  generic-write */
t3=lf[36];
f_1935(t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1,t2);}

/* a3228 in k3225 in k3218 in pretty-print in k3212 in k893 in k890 in k887 */
static void C_ccall f_3229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3229,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3233,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 586  display */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[2]);}

/* k3231 in a3228 in k3225 in k3218 in pretty-print in k3212 in k893 in k890 in k887 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k3221 in k3218 in pretty-print in k3212 in k893 in k890 in k887 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* generic-write in k893 in k890 in k887 */
static void C_fcall f_1935(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[40],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1935,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1938,tmp=(C_word)a,a+=2,tmp));
t17=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1996,tmp=(C_word)a,a+=2,tmp));
t18=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2029,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2048,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t11,a[7]=t9,a[8]=t13,tmp=(C_word)a,a+=9,tmp));
t20=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2556,a[2]=t7,a[3]=t9,a[4]=t13,a[5]=t4,a[6]=t3,a[7]=t11,tmp=(C_word)a,a+=8,tmp));
if(C_truep(t4)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3203,a[2]=t2,a[3]=t15,a[4]=t1,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 576  make-string */
t22=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,C_fix(1),C_make_character(10));}
else{
/* extras.scm: 577  wr */
t21=((C_word*)t13)[1];
f_2048(t21,t1,t2,C_fix(0));}}

/* k3201 in generic-write in k893 in k890 in k887 */
static void C_ccall f_3203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3207,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 576  pp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2556(t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k3205 in k3201 in generic-write in k893 in k890 in k887 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 576  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2556(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word ab[134],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2556,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t41=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t42=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t11,a[6]=t15,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t43=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t39,a[5]=t13,a[6]=t19,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,tmp=(C_word)a,a+=11,tmp));
t44=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t17,tmp=(C_word)a,a+=5,tmp));
t45=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[7],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t46=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2813,a[2]=((C_word*)t0)[7],a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t47=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t17,a[5]=t7,a[6]=t9,tmp=(C_word)a,a+=7,tmp));
t48=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3038,a[2]=t11,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t49=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3044,a[2]=t11,a[3]=t21,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t50=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3050,a[2]=t11,a[3]=t19,tmp=(C_word)a,a+=4,tmp));
t51=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3056,a[2]=t21,a[3]=t13,tmp=(C_word)a,a+=4,tmp));
t52=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3062,a[2]=t21,a[3]=t11,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t53=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3068,a[2]=t11,a[3]=t13,tmp=(C_word)a,a+=4,tmp));
t54=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3074,a[2]=t11,a[3]=t21,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t55=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3096,a[2]=t11,a[3]=t19,tmp=(C_word)a,a+=4,tmp));
t56=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3102,a[2]=t11,a[3]=t21,a[4]=t19,tmp=(C_word)a,a+=5,tmp));
t57=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3111,a[2]=t37,a[3]=t35,a[4]=t33,a[5]=t31,a[6]=t29,a[7]=t27,a[8]=t25,a[9]=t23,tmp=(C_word)a,a+=10,tmp));
/* extras.scm: 573  pr */
t58=((C_word*)t9)[1];
f_2624(t58,t1,t2,t3,C_fix(0),((C_word*)t11)[1]);}

/* style in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_3111(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3111,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,lf[97]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_3121(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[107]);
if(C_truep(t5)){
t6=t4;
f_3121(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[108]);
t7=t4;
f_3121(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,lf[109])));}}}

/* k3119 in style in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_3121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[10])[1]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[98]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[99]));
if(C_truep(t3)){
t4=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[100]);
if(C_truep(t4)){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[101]);
if(C_truep(t5)){
t6=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)((C_word*)t0)[6])[1]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[102]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[9],lf[103]));
if(C_truep(t7)){
t8=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)((C_word*)t0)[5])[1]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[104]);
if(C_truep(t8)){
t9=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)((C_word*)t0)[4])[1]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[105]);
if(C_truep(t9)){
t10=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[106]);
t11=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}}}}}}}}

/* pp-do in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3102,5,t0,t1,t2,t3,t4);}
/* extras.scm: 551  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2890(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* pp-begin in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3096,5,t0,t1,t2,t3,t4);}
/* extras.scm: 548  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2890(t5,t1,t2,t3,t4,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-let in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3074,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_u_i_car(t5);
t7=(C_word)C_i_symbolp(t6);
/* extras.scm: 545  pp-general */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2890(t8,t1,t2,t3,t4,t7,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}
else{
/* extras.scm: 545  pp-general */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2890(t6,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}}

/* pp-and in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3068,5,t0,t1,t2,t3,t4);}
/* extras.scm: 540  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2776(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-case in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3062,5,t0,t1,t2,t3,t4);}
/* extras.scm: 537  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2890(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-cond in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3056,5,t0,t1,t2,t3,t4);}
/* extras.scm: 534  pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2776(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-if in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3050,5,t0,t1,t2,t3,t4);}
/* extras.scm: 531  pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2890(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-lambda in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3044,5,t0,t1,t2,t3,t4);}
/* extras.scm: 528  pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2890(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-expr-list in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3038,5,t0,t1,t2,t3,t4);}
/* extras.scm: 525  pp-list */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2804(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2890(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2890,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2934,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t14,a[5]=t4,a[6]=t7,tmp=(C_word)a,a+=7,tmp));
t17=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2975,a[2]=t8,a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t18=(C_word)C_u_i_car(t2);
t19=(C_word)C_slot(t2,C_fix(1));
t20=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t10,a[6]=t3,a[7]=t19,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3036,a[2]=t18,a[3]=t20,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 516  out */
t22=((C_word*)((C_word*)t0)[2])[1];
f_2029(t22,t21,lf[96],t3);}

/* k3034 in pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 516  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2048(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2986 in pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[8])?(C_word)C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_u_i_car(((C_word*)t0)[7]);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3003,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3018,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 520  out */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2029(t7,t6,lf[95],t1);}
else{
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 522  tail1 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2893(t5,((C_word*)t0)[4],((C_word*)t0)[7],t3,t1,t4);}}

/* k3016 in k2986 in pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 520  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2048(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3001 in k2986 in pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 521  tail1 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2893(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t1,t3);}

/* tail3 in pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2975(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2975,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm: 512  pp-down */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2813(t5,t1,t2,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* tail2 in pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2934(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2934,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2957,a[2]=t3,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2961,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 508  indent */
t13=((C_word*)((C_word*)t0)[2])[1];
f_2592(t13,t12,t5,t4);}
else{
/* extras.scm: 509  tail3 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2975(t7,t1,t2,t3,t4);}}

/* k2959 in tail2 in pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 508  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2624(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2955 in tail2 in pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 508  tail3 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2975(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tail1 in pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2893(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2893,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?(C_word)C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2916,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 500  indent */
t13=((C_word*)((C_word*)t0)[2])[1];
f_2592(t13,t12,t5,t4);}
else{
/* extras.scm: 501  tail2 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2934(t7,t1,t2,t3,t4,t5);}}

/* k2918 in tail1 in pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 500  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2624(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2914 in tail1 in pp-general in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 500  tail2 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2934(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* pp-down in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2813(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2813,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2819,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_2819(t10,t1,t2,t3);}

/* loop in pp-down in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2819(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2819,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2842,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_u_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=t8,a[5]=t7,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 483  indent */
t10=((C_word*)((C_word*)t0)[4])[1];
f_2592(t10,t9,((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 485  out */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2029(t4,t1,lf[92],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2872,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2876,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2888,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 489  indent */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2592(t8,t7,((C_word*)t0)[3],t3);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2886 in loop in pp-down in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 489  out */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2029(t2,((C_word*)t0)[2],lf[94],t1);}

/* k2882 in loop in pp-down in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 489  indent */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2592(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2874 in loop in pp-down in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2876,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* extras.scm: 488  pr */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2624(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k2870 in loop in pp-down in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 487  out */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2029(t2,((C_word*)t0)[2],lf[93],t1);}

/* k2848 in loop in pp-down in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 483  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2624(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2840 in loop in pp-down in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 482  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2819(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp-list in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2804(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2804,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2808,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 473  out */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2029(t7,t6,lf[91],t3);}

/* k2806 in pp-list in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 474  pp-down */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2813(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-call in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2776(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2776,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2780,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_u_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2802,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 465  out */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2029(t9,t8,lf[90],t3);}

/* k2800 in pp-call in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 465  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2048(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2778 in pp-call in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm: 467  pp-down */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2813(t4,((C_word*)t0)[4],t2,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* pp-expr in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2711,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* extras.scm: 445  read-macro? */
f_1938(t5,t2);}

/* k2716 in pp-expr in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=(C_word)C_u_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2729,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t5=f_1996(((C_word*)t0)[13]);
/* extras.scm: 447  out */
t6=((C_word*)((C_word*)t0)[7])[1];
f_2029(t6,t4,t5,((C_word*)t0)[6]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2745,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* extras.scm: 452  style */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3111(t4,t3,t2);}
else{
/* extras.scm: 459  pp-list */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2804(t3,((C_word*)t0)[11],((C_word*)t0)[13],((C_word*)t0)[6],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1]);}}}

/* k2743 in k2716 in pp-expr in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2745,2,t0,t1);}
if(C_truep(t1)){
/* extras.scm: 454  proc */
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 455  ##sys#symbol->qualified-string */
t3=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k2769 in k2743 in k2716 in pp-expr in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fix((C_word)C_header_size(t1));
if(C_truep((C_word)C_i_greaterp(t2,C_fix(5)))){
/* extras.scm: 457  pp-general */
t3=((C_word*)((C_word*)t0)[8])[1];
f_2890(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1]);}
else{
/* extras.scm: 458  pp-call */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2776(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k2727 in k2716 in pp-expr in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 446  pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2624(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* pr in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2624(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2624,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?t6:(C_word)C_i_vectorp(t2));
if(C_truep(t7)){
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t5,a[7]=t2,a[8]=t9,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[3],t3);
t12=(C_word)C_a_i_minus(&a,2,t11,t4);
t13=(C_word)C_a_i_plus(&a,2,t12,C_fix(1));
/* extras.scm: 431  max */
t14=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t10,t13,C_fix(50));}
else{
/* extras.scm: 442  wr */
t8=((C_word*)((C_word*)t0)[2])[1];
f_2048(t8,t1,t2,t3);}}

/* k2635 in pr in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2675,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 432  generic-write */
t6=lf[36];
f_1935(t6,t4,((C_word*)t0)[7],((C_word*)t0)[2],C_SCHEME_FALSE,t5);}

/* a2674 in k2635 in pr in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2675,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=(C_word)C_fix((C_word)C_header_size(t2));
t6=(C_word)C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)));}

/* k2638 in k2635 in pr in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2640,2,t0,t1);}
if(C_truep((C_word)C_i_greaterp(((C_word*)((C_word*)t0)[11])[1],C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2653,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 438  reverse-string-append */
t3=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
/* extras.scm: 440  pp-pair */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[9],((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 441  vector->list */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}}

/* k2667 in k2638 in k2635 in pr in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 441  out */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2029(t3,t2,lf[87],((C_word*)t0)[2]);}

/* k2671 in k2667 in k2638 in k2635 in pr in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 441  pp-list */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2804(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2651 in k2638 in k2635 in pr in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 438  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* indent in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2592(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2592,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_lessp(t2,t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2608,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2615,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 425  make-string */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(1),C_make_character(10));}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,t3);
/* extras.scm: 426  spaces */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2559(t5,t1,t4,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2613 in indent in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 425  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2606 in indent in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 425  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2559(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spaces in pp in generic-write in k893 in k890 in k887 */
static void C_fcall f_2559(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2559,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
if(C_truep((C_word)C_i_greaterp(t2,C_fix(7)))){
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(8));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2583,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 418  out */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2029(t6,t5,lf[84],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2590,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 419  ##sys#substring */
t5=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[85],C_fix(0),t2);}}
else{
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2588 in spaces in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 419  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2581 in spaces in pp in generic-write in k893 in k890 in k887 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 418  spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2559(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr in generic-write in k893 in k890 in k887 */
static void C_fcall f_2048(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2048,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp));
if(C_truep((C_word)C_i_pairp(t2))){
/* extras.scm: 351  wr-expr */
t9=t4;
f_2051(t9,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 352  wr-lst */
t9=((C_word*)t6)[1];
f_2078(t9,t1,t2,t3);}
else{
if(C_truep((C_word)C_eofp(t2))){
/* extras.scm: 353  out */
t9=((C_word*)((C_word*)t0)[6])[1];
f_2029(t9,t1,lf[51],t3);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2204,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 354  vector->list */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
if(C_truep((C_word)C_booleanp(t2))){
if(C_truep(t2)){
/* extras.scm: 355  out */
t9=((C_word*)((C_word*)t0)[6])[1];
f_2029(t9,t1,lf[54],t3);}
else{
/* extras.scm: 355  out */
t9=((C_word*)((C_word*)t0)[6])[1];
f_2029(t9,t1,lf[55],t3);}}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 356  ##sys#number? */
t10=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}}}}}}

/* k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 356  ##sys#number->string */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 358  open-output-string */
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 361  ##sys#procedure->string */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
/* extras.scm: 363  out */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2029(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 364  out */
t3=((C_word*)((C_word*)t0)[8])[1];
f_2029(t3,t2,lf[61],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2369,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 378  make-string */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[5]);}
else{
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2375,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 380  out */
t4=((C_word*)((C_word*)t0)[8])[1];
f_2029(t4,t3,lf[66],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[5]))){
/* extras.scm: 391  out */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2029(t2,((C_word*)t0)[7],lf[67],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_undefinedp(((C_word*)t0)[5]))){
/* extras.scm: 392  out */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2029(t2,((C_word*)t0)[7],lf[68],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 393  ##sys#pointer->string */
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(lf[70],C_fix(0));
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* extras.scm: 395  out */
t4=((C_word*)((C_word*)t0)[8])[1];
f_2029(t4,((C_word*)t0)[7],lf[71],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2482,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 397  open-output-string */
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2498,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 400  port? */
t5=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}}}}}}}}}}

/* k2496 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2498,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
/* extras.scm: 400  string-append */
t4=*((C_word*)lf[73]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[74],t3,lf[75]);}
else{
if(C_truep((C_word)C_bytevectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[2]))){
/* extras.scm: 403  out */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2029(t3,t2,lf[77],((C_word*)t0)[3]);}
else{
/* extras.scm: 404  out */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2029(t3,t2,lf[78],((C_word*)t0)[3]);}}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 408  out */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2029(t3,t2,lf[81],((C_word*)t0)[3]);}
else{
/* extras.scm: 411  out */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2029(t2,((C_word*)t0)[4],lf[82],((C_word*)t0)[3]);}}}}

/* k2535 in k2496 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 409  ##sys#lambda-info->string */
t4=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2545 in k2535 in k2496 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 409  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2538 in k2535 in k2496 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 410  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],lf[79],((C_word*)t0)[2]);}

/* k2513 in k2496 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2525,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 405  number->string */
C_number_to_string(3,0,t3,(C_word)C_block_size(((C_word*)t0)[2]));}

/* k2523 in k2513 in k2496 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 405  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2516 in k2513 in k2496 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 406  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],lf[76],((C_word*)t0)[2]);}

/* k2503 in k2496 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 400  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2480 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2485,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 398  ##sys#user-print-hook */
t3=*((C_word*)lf[72]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k2483 in k2480 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 399  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2490 in k2483 in k2480 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 399  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2462 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 393  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2373 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2378,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 381  char-name */
t3=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2376 in k2373 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2378,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2382,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* g524525 */
t3=t2;
f_2382(t3,((C_word*)t0)[4],t1);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(32)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 385  out */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2029(t3,t2,lf[62],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(255)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2418,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(65535)))){
/* extras.scm: 388  out */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2029(t3,t2,lf[63],((C_word*)t0)[5]);}
else{
/* extras.scm: 388  out */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2029(t3,t2,lf[64],((C_word*)t0)[5]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 390  make-string */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(1),((C_word*)t0)[2]);}}}}

/* k2437 in k2376 in k2373 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 390  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2416 in k2376 in k2373 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 389  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k2423 in k2416 in k2376 in k2373 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 389  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2400 in k2376 in k2373 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 386  number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k2407 in k2400 in k2376 in k2373 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 386  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* g524 in k2376 in k2373 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_fcall f_2382(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2382,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
/* extras.scm: 383  out */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2029(t4,t1,t3,((C_word*)t0)[2]);}

/* k2367 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 378  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2283 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2287(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1);}

/* loop in k2283 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_fcall f_2287(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2287,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2294,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t7=t5;
f_2294(t7,(C_word)C_i_lessp(t3,t6));}
else{
t6=t5;
f_2294(t6,C_SCHEME_FALSE);}}

/* k2292 in loop in k2283 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_fcall f_2294(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2294,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_subchar(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(34)));
if(C_truep(t4)){
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2317,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2321,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2325,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 372  ##sys#substring */
t9=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* extras.scm: 374  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2287(t6,((C_word*)t0)[5],((C_word*)t0)[2],t5,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2342,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 376  ##sys#substring */
t4=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k2344 in k2292 in loop in k2283 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 376  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2340 in k2292 in loop in k2283 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 375  out */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2029(t2,((C_word*)t0)[2],lf[60],t1);}

/* k2323 in k2292 in loop in k2283 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 372  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2319 in k2292 in loop in k2283 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 371  out */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2029(t2,((C_word*)t0)[2],lf[59],t1);}

/* k2315 in k2292 in loop in k2283 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 369  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2287(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2264 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 361  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2241 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2246,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 359  ##sys#print */
t3=*((C_word*)lf[57]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k2244 in k2241 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 360  get-output-string */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2251 in k2244 in k2241 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 360  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2232 in k2225 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 356  out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2029(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2202 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2208,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 354  out */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2029(t3,t2,lf[52],((C_word*)t0)[2]);}

/* k2206 in k2202 in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 354  wr-lst */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2078(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-lst in wr in generic-write in k893 in k890 in k887 */
static void C_fcall f_2078(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2078,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2096,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2161,a[2]=t6,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 343  out */
t8=((C_word*)((C_word*)t0)[2])[1];
f_2029(t8,t7,lf[49],t3);}
else{
t6=t5;
f_2096(2,t6,C_SCHEME_FALSE);}}
else{
/* extras.scm: 349  out */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2029(t4,t1,lf[50],t3);}}

/* k2159 in wr-lst in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 343  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2048(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2094 in wr-lst in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2098,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2098(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k2094 in wr-lst in wr in generic-write in k893 in k890 in k887 */
static void C_fcall f_2098(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2098,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep(t4)){
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2122,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_u_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2130,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 346  out */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2029(t9,t8,lf[45],t3);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* extras.scm: 347  out */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2029(t5,t1,lf[46],t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2146,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2150,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 348  out */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2029(t7,t6,lf[48],t3);}}}
else{
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k2148 in loop in k2094 in wr-lst in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 348  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2048(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2144 in loop in k2094 in wr-lst in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 348  out */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2029(t2,((C_word*)t0)[2],lf[47],t1);}

/* k2128 in loop in k2094 in wr-lst in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 346  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2048(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2120 in loop in k2094 in wr-lst in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 346  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2098(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-expr in wr in generic-write in k893 in k890 in k887 */
static void C_fcall f_2051(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2051,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 336  read-macro? */
f_1938(t4,t2);}

/* k2056 in wr-expr in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2058,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=(C_word)C_u_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2069,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t5=f_1996(((C_word*)t0)[8]);
/* extras.scm: 337  out */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2029(t6,t4,t5,((C_word*)t0)[3]);}
else{
/* extras.scm: 338  wr-lst */
t2=((C_word*)((C_word*)t0)[2])[1];
f_2078(t2,((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[3]);}}

/* k2067 in k2056 in wr-expr in wr in generic-write in k893 in k890 in k887 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 337  wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2048(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* out in generic-write in k893 in k890 in k887 */
static void C_fcall f_2029(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2029,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2039,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 331  output */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2037 in out in generic-write in k893 in k890 in k887 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2039,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* read-macro-prefix in generic-write in k893 in k890 in k887 */
static C_word C_fcall f_1996(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_eqp(t2,lf[37]);
if(C_truep(t4)){
return(lf[41]);}
else{
t5=(C_word)C_eqp(t2,lf[38]);
if(C_truep(t5)){
return(lf[42]);}
else{
t6=(C_word)C_eqp(t2,lf[39]);
if(C_truep(t6)){
return(lf[43]);}
else{
t7=(C_word)C_eqp(t2,lf[40]);
return((C_truep(t7)?lf[44]:C_SCHEME_UNDEFINED));}}}}

/* read-macro? in generic-write in k893 in k890 in k887 */
static void C_fcall f_1938(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1938,NULL,2,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(t3,lf[37]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1970,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_1970(t7,t5);}
else{
t7=(C_word)C_eqp(t3,lf[38]);
if(C_truep(t7)){
t8=t6;
f_1970(t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[39]);
t9=t6;
f_1970(t9,(C_truep(t8)?t8:(C_word)C_eqp(t3,lf[40])));}}}

/* k1968 in read-macro? in generic-write in k893 in k890 in k887 */
static void C_fcall f_1970(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* write-byte in k893 in k890 in k887 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1904r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1904r(t0,t1,t2,t3);}}

static void C_ccall f_1904r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?*((C_word*)lf[31]+1):(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_exact_2(t2,lf[35]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1914,a[2]=t5,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 292  ##sys#check-port */
t8=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t5,lf[35]);}

/* k1912 in write-byte in k893 in k890 in k887 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[4]));
/* extras.scm: 293  ##sys#write-char-0 */
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* read-byte in k893 in k890 in k887 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1871r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1871r(t0,t1,t2);}}

static void C_ccall f_1871r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?*((C_word*)lf[5]+1):(C_word)C_slot(t2,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1878,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 284  ##sys#check-port */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,lf[34]);}

/* k1876 in read-byte in k893 in k890 in k887 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* extras.scm: 285  ##sys#read-char-0 */
t3=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1879 in k1876 in read-byte in k893 in k890 in k887 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_eofp(t1))){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix((C_word)C_character_code(t1)));}}

/* write-line in k893 in k890 in k887 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1850r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1850r(t0,t1,t2,t3);}}

static void C_ccall f_1850r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))?*((C_word*)lf[31]+1):(C_word)C_slot(t3,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1857,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 275  ##sys#check-port */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,lf[33]);}

/* k1855 in write-line in k893 in k890 in k887 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1857,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[33]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 277  display */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[3]);}

/* k1861 in k1855 in write-line in k893 in k890 in k887 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 278  newline */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-string in k893 in k890 in k887 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_1764r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1764r(t0,t1,t2,t3);}}

static void C_ccall f_1764r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_string_2(t2,lf[26]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1769,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1800,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-n357374 */
t8=t7;
f_1805(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-port358372 */
t10=t6;
f_1800(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body355363 */
t12=t5;
f_1769(t12,t1,t8,t10);}}}

/* def-n357 in write-string in k893 in k890 in k887 */
static void C_fcall f_1805(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1805,NULL,2,t0,t1);}
/* def-port358372 */
t2=((C_word*)t0)[2];
f_1800(t2,t1,C_SCHEME_FALSE);}

/* def-port358 in write-string in k893 in k890 in k887 */
static void C_fcall f_1800(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1800,NULL,3,t0,t1,t2);}
/* body355363 */
t3=((C_word*)t0)[2];
f_1769(t3,t1,t2,*((C_word*)lf[31]+1));}

/* body355 in write-string in k893 in k890 in k887 */
static void C_fcall f_1769(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1769,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1773,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 260  ##sys#check-port */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[26]);}

/* k1771 in body355 in write-string in k893 in k890 in k887 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1773,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[26]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=(C_word)C_block_size(((C_word*)t0)[2]);
t6=t4;
f_1786(t6,(C_word)C_fixnum_lessp(((C_word*)t0)[6],t5));}
else{
t5=t4;
f_1786(t5,C_SCHEME_FALSE);}}

/* k1784 in k1771 in body355 in write-string in k893 in k890 in k887 */
static void C_fcall f_1786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 264  ##sys#substring */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],((C_word*)t0)[6],C_fix(0),((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[6];
/* extras.scm: 262  display */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* k1781 in k1771 in body355 in write-string in k893 in k890 in k887 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 262  display */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* read-token in k893 in k890 in k887 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1702r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1702r(t0,t1,t2,t3);}}

static void C_ccall f_1702r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?*((C_word*)lf[5]+1):(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 245  ##sys#check-port */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[27]);}

/* k1707 in read-token in k893 in k890 in k887 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1712,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 246  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1710 in k1707 in read-token in k893 in k890 in k887 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1712,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1717,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1717(t5,((C_word*)t0)[2]);}

/* loop in k1710 in k1707 in read-token in k893 in k890 in k887 */
static void C_fcall f_1717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1717,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 248  ##sys#peek-char-0 */
t3=*((C_word*)lf[29]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k1719 in loop in k1710 in k1707 in read-token in k893 in k890 in k887 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1727,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_eofp(t1))){
t3=t2;
f_1727(2,t3,C_SCHEME_FALSE);}
else{
/* extras.scm: 249  pred */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k1725 in k1719 in loop in k1710 in k1707 in read-token in k893 in k890 in k887 */
static void C_ccall f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1727,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1737,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 251  ##sys#read-char-0 */
t4=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
/* extras.scm: 253  get-output-string */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k1735 in k1725 in k1719 in loop in k1710 in k1707 in read-token in k893 in k890 in k887 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 251  ##sys#write-char-0 */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1728 in k1725 in k1719 in loop in k1710 in k1707 in read-token in k893 in k890 in k887 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 252  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1717(t2,((C_word*)t0)[2]);}

/* read-string in k893 in k890 in k887 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_1645r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1645r(t0,t1,t2);}}

static void C_ccall f_1645r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
t4=*((C_word*)lf[5]+1);
/* extras.scm: 238  ##sys#read-string/port */
t5=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_SCHEME_FALSE,t4);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
t6=*((C_word*)lf[5]+1);
/* extras.scm: 238  ##sys#read-string/port */
t7=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}
else{
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_slot(t4,C_fix(1));
t7=t1;
/* extras.scm: 238  ##sys#read-string/port */
t8=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t3,t5);}}}

/* ##sys#read-string/port in k893 in k890 in k887 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1588,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 218  ##sys#check-port */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[25]);}

/* k1590 in ##sys#read-string/port in k893 in k890 in k887 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[25]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 220  ##sys#make-string */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 226  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1614 in k1590 in ##sys#read-string/port in k893 in k890 in k887 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 227  make-string */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(2048));}

/* k1617 in k1614 in k1590 in ##sys#read-string/port in k893 in k890 in k887 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1619,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1624(t5,((C_word*)t0)[2]);}

/* loop in k1617 in k1614 in k1590 in ##sys#read-string/port in k893 in k890 in k887 */
static void C_fcall f_1624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1624,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 229  ##sys#read-string! */
t3=*((C_word*)lf[20]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(2048),((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k1626 in loop in k1617 in k1614 in k1590 in ##sys#read-string/port in k893 in k890 in k887 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
/* extras.scm: 232  get-output-string */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 234  write-string */
t4=*((C_word*)lf[26]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t1,((C_word*)t0)[4]);}}

/* k1638 in k1626 in loop in k1617 in k1614 in k1590 in ##sys#read-string/port in k893 in k890 in k887 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 235  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1624(t2,((C_word*)t0)[2]);}

/* k1599 in k1590 in ##sys#read-string/port in k893 in k890 in k887 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1604,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 221  ##sys#read-string! */
t3=*((C_word*)lf[20]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[2],C_fix(0));}

/* k1602 in k1599 in k1590 in ##sys#read-string/port in k893 in k890 in k887 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
/* extras.scm: 224  ##sys#substring */
t3=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* read-string! in k893 in k890 in k887 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_1494r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1494r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1494r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1496,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1538,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1543,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port247267 */
t9=t8;
f_1543(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start248265 */
t11=t7;
f_1538(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
/* body245253 */
t13=t6;
f_1496(t13,t1,t9,t11);}}}

/* def-port247 in read-string! in k893 in k890 in k887 */
static void C_fcall f_1543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1543,NULL,2,t0,t1);}
/* def-start248265 */
t2=((C_word*)t0)[2];
f_1538(t2,t1,*((C_word*)lf[5]+1));}

/* def-start248 in read-string! in k893 in k890 in k887 */
static void C_fcall f_1538(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1538,NULL,3,t0,t1,t2);}
/* body245253 */
t3=((C_word*)t0)[2];
f_1496(t3,t1,t2,C_fix(0));}

/* body245 in read-string! in k893 in k890 in k887 */
static void C_fcall f_1496(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1496,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1500,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 203  ##sys#check-port */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[21]);}

/* k1498 in body245 in read-string! in k893 in k890 in k887 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=(C_word)C_i_check_string_2(((C_word*)t0)[6],lf[21]);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[21]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_block_size(((C_word*)t0)[6]);
if(C_truep((C_word)C_fixnum_greaterp(t4,t5))){
t6=(C_word)C_block_size(((C_word*)t0)[6]);
t7=(C_word)C_u_fixnum_difference(t6,((C_word*)t0)[4]);
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[21]);
/* extras.scm: 210  ##sys#read-string! */
t10=*((C_word*)lf[20]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,((C_word*)t0)[3],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t6=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[21]);
/* extras.scm: 210  ##sys#read-string! */
t7=*((C_word*)lf[20]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,((C_word*)t0)[3],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[4]);}}
else{
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[21]);
/* extras.scm: 210  ##sys#read-string! */
t4=*((C_word*)lf[20]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* ##sys#read-string! in k893 in k890 in k887 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1348,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1358,a[2]=t2,a[3]=t6,a[4]=t1,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_slot(t4,C_fix(6)))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1488,a[2]=t8,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 178  ##sys#read-char-0 */
t10=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t8;
f_1358(t9,C_SCHEME_UNDEFINED);}}}

/* k1486 in ##sys#read-string! in k893 in k890 in k887 */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1358(t5,t4);}

/* k1356 in ##sys#read-string! in k893 in k890 in k887 */
static void C_fcall f_1358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1358,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_slot(t2,C_fix(7));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1369(t7,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_fix(0));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1428,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1428(t7,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_fix(0));}}

/* loop in k1356 in ##sys#read-string! in k893 in k890 in k887 */
static void C_fcall f_1428(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1428,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 191  ##sys#read-char-0 */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k1430 in loop in k1356 in ##sys#read-string! in k893 in k890 in k887 */
static void C_ccall f_1432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_eofp(t1))){
t3=t2;
f_1435(t3,C_fix(0));}
else{
t3=(C_word)C_setsubchar(((C_word*)t0)[2],((C_word*)t0)[4],t1);
t4=t2;
f_1435(t4,C_fix(1));}}

/* k1433 in k1430 in loop in k1356 in ##sys#read-string! in k893 in k890 in k887 */
static void C_fcall f_1435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_i_not(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_fixnum_lessp(t1,((C_word*)t0)[4]));
if(C_truep(t4)){
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t6=(C_truep(((C_word*)t0)[4])?(C_word)C_u_fixnum_difference(((C_word*)t0)[4],t1):C_SCHEME_FALSE);
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
/* extras.scm: 199  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1428(t8,((C_word*)t0)[5],t5,t6,t7);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_fixnum_plus(t1,((C_word*)t0)[6]));}}}

/* loop in k1356 in ##sys#read-string! in k893 in k890 in k887 */
static void C_fcall f_1369(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1369,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* extras.scm: 183  rdstring */
t6=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,((C_word*)t0)[5],t3,((C_word*)t0)[2],t2);}

/* k1371 in loop in k1356 in ##sys#read-string! in k893 in k890 in k887 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(5));
t3=(C_word)C_u_fixnum_plus(t2,t1);
t4=(C_word)C_i_set_i_slot(((C_word*)t0)[7],C_fix(5),t3);
t5=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(C_word)C_i_not(((C_word*)t0)[4]);
t7=(C_truep(t6)?t6:(C_word)C_fixnum_lessp(t1,((C_word*)t0)[4]));
if(C_truep(t7)){
t8=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t9=(C_truep(((C_word*)t0)[4])?(C_word)C_u_fixnum_difference(((C_word*)t0)[4],t1):C_SCHEME_FALSE);
t10=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t1);
/* extras.scm: 188  loop */
t11=((C_word*)((C_word*)t0)[2])[1];
f_1369(t11,((C_word*)t0)[5],t8,t9,t10);}
else{
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_u_fixnum_plus(t1,((C_word*)t0)[6]));}}}

/* read-lines in k893 in k890 in k887 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_1258r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1258r(t0,t1,t2);}}

static void C_ccall f_1258r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):*((C_word*)lf[5]+1));
t5=(C_word)C_i_pairp(t2);
t6=(C_truep(t5)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
t7=(C_word)C_i_pairp(t6);
t8=(C_truep(t7)?(C_word)C_slot(t6,C_fix(0)):C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t4))){
/* extras.scm: 166  call-with-input-file */
t10=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,t4,t9);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1325,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 168  ##sys#check-port */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t4,lf[19]);}}

/* k1323 in read-lines in k893 in k890 in k887 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 169  doread */
t2=((C_word*)t0)[4];
f_1270(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doread in read-lines in k893 in k890 in k887 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1270,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:C_fix(1000000000));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1280,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1280(t7,t1,C_SCHEME_END_OF_LIST,t3);}

/* loop in doread in read-lines in k893 in k890 in k887 */
static void C_fcall f_1280(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1280,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
/* extras.scm: 160  reverse */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1293,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 161  read-line */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k1291 in loop in doread in read-lines in k893 in k890 in k887 */
static void C_ccall f_1293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1293,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
/* extras.scm: 163  reverse */
t2=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* extras.scm: 164  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1280(t4,((C_word*)t0)[5],t2,t3);}}

/* read-line in k893 in k890 in k887 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1109r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1109r(t0,t1,t2);}}

static void C_ccall f_1109r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_u_i_car(t2):*((C_word*)lf[5]+1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1119,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_i_pairp(t6);
t8=t5;
f_1119(t8,(C_truep(t7)?(C_word)C_u_i_cadr(t2):C_SCHEME_FALSE));}
else{
t6=t5;
f_1119(t6,C_SCHEME_FALSE);}}

/* k1117 in read-line in k893 in k890 in k887 */
static void C_fcall f_1119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1119,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 120  ##sys#check-port */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[12]);}

/* k1120 in k1117 in read-line in k893 in k890 in k887 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1122,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_slot(t2,C_fix(8));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1129,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* g123124 */
t5=t4;
f_1129(t5,((C_word*)t0)[3],t3);}
else{
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:C_fix(256));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1142,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 124  ##sys#make-string */
t8=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t6)[1]);}}

/* k1140 in k1120 in k1117 in read-line in k893 in k890 in k887 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1142,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_1147(t7,((C_word*)t0)[2],C_fix(0));}

/* loop in k1140 in k1120 in k1117 in read-line in k893 in k890 in k887 */
static void C_fcall f_1147(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1147,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[7])?(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* extras.scm: 127  ##sys#substring */
t4=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)((C_word*)t0)[6])[1],C_fix(0),t2);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* extras.scm: 128  ##sys#read-char-0 */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}}

/* k1158 in loop in k1140 in k1120 in k1117 in read-line in k893 in k890 in k887 */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1160,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(C_word)C_eqp(((C_word*)t0)[8],C_fix(0));
if(C_truep(t2)){
t3=t1;
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* extras.scm: 132  ##sys#substring */
t3=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);}}
else{
switch(t1){
case C_make_character(10):
/* extras.scm: 134  ##sys#substring */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);
case C_make_character(13):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1193,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 136  peek-char */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);
default:
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1211,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[8],((C_word*)((C_word*)t0)[3])[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1225,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 143  make-string */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_1211(t3,C_SCHEME_UNDEFINED);}}}}

/* k1231 in k1158 in loop in k1140 in k1120 in k1117 in read-line in k893 in k890 in k887 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 143  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1223 in k1158 in loop in k1140 in k1120 in k1117 in read-line in k893 in k890 in k887 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1211(t5,t4);}

/* k1209 in k1158 in loop in k1140 in k1120 in k1117 in read-line in k893 in k890 in k887 */
static void C_fcall f_1211(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_setsubchar(((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm: 146  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1147(t4,((C_word*)t0)[2],t3);}

/* k1191 in k1158 in loop in k1140 in k1120 in k1117 in read-line in k893 in k890 in k887 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1193,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_make_character(10));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1202,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm: 138  ##sys#read-char-0 */
t4=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* extras.scm: 140  ##sys#substring */
t3=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_fix(0),((C_word*)t0)[3]);}}

/* k1200 in k1191 in k1158 in loop in k1140 in k1120 in k1117 in read-line in k893 in k890 in k887 */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm: 139  ##sys#substring */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],C_fix(0),((C_word*)t0)[2]);}

/* g123 in k1120 in k1117 in read-line in k893 in k890 in k887 */
static void C_fcall f_1129(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1129,NULL,3,t0,t1,t2);}
/* extras.scm: 121  rl */
t3=t2;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* random in k893 in k890 in k887 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1070,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[10]);
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(0));}
else{
t5=(C_word)C_random_fixnum(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* randomize in k893 in k890 in k887 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1052r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1052r(t0,t1,t2);}}

static void C_ccall f_1052r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?(C_word)C_fudge(C_fix(2)):(C_word)C_slot(t2,C_fix(0)));
t5=(C_word)C_i_check_exact_2(t4,lf[9]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_randomize(t4));}

/* random-seed in k893 in k890 in k887 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1031r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1031r(t0,t1,t2);}}

static void C_ccall f_1031r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1035,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* extras.scm: 90   current-seconds */
t4=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=t3;
f_1035(2,t4,(C_word)C_slot(t2,C_fix(0)));}}

/* k1033 in random-seed in k893 in k890 in k887 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1038,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm: 91   ##sys#check-integer */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[6]);}

/* k1036 in k1033 in random-seed in k893 in k890 in k887 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub87(C_SCHEME_UNDEFINED,t3));}

/* read-file in k893 in k890 in k887 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr2r,(void*)f_897r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_897r(t0,t1,t2);}}

static void C_ccall f_897r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_959,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_969,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-port4377 */
t7=t6;
f_969(t7,t1);}
else{
t7=(C_word)C_u_i_car(t2);
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-reader4475 */
t9=t5;
f_964(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-max4572 */
t11=t4;
f_959(t11,t1,t7,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
/* body4150 */
t13=t3;
f_899(t13,t1,t7,t9,t11);}}}}

/* def-port43 in read-file in k893 in k890 in k887 */
static void C_fcall f_969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_969,NULL,2,t0,t1);}
/* def-reader4475 */
t2=((C_word*)t0)[2];
f_964(t2,t1,*((C_word*)lf[5]+1));}

/* def-reader44 in read-file in k893 in k890 in k887 */
static void C_fcall f_964(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_964,NULL,3,t0,t1,t2);}
/* def-max4572 */
t3=((C_word*)t0)[3];
f_959(t3,t1,t2,((C_word*)t0)[2]);}

/* def-max45 in read-file in k893 in k890 in k887 */
static void C_fcall f_959(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_959,NULL,4,t0,t1,t2,t3);}
/* body4150 */
t4=((C_word*)t0)[2];
f_899(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body41 in read-file in k893 in k890 in k887 */
static void C_fcall f_899(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_899,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_902,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_952,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm: 80   port? */
t7=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k950 in body41 in read-file in k893 in k890 in k887 */
static void C_ccall f_952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm: 81   slurp */
t2=((C_word*)t0)[5];
f_902(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* extras.scm: 82   call-with-input-file */
t2=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* slurp in body41 in read-file in k893 in k890 in k887 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_902,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_910,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 76   reader */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k908 in slurp in body41 in read-file in k893 in k890 in k887 */
static void C_ccall f_910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_910,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_912(t5,((C_word*)t0)[2],t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* doloop56 in k908 in slurp in body41 in read-file in k893 in k890 in k887 */
static void C_fcall f_912(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_912,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eofp(t2);
t6=(C_truep(t5)?t5:(C_truep(((C_word*)t0)[6])?(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]):C_SCHEME_FALSE));
if(C_truep(t6)){
/* extras.scm: 79   reverse */
t7=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_932,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* extras.scm: 76   reader */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}}

/* k930 in doloop56 in k908 in slurp in body41 in read-file in k893 in k890 in k887 */
static void C_ccall f_932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_932,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_912(t4,((C_word*)t0)[2],t1,t2,t3);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[233] = {
{"toplevel:extras_scm",(void*)C_extras_toplevel},
{"f_889:extras_scm",(void*)f_889},
{"f_892:extras_scm",(void*)f_892},
{"f_895:extras_scm",(void*)f_895},
{"f_3214:extras_scm",(void*)f_3214},
{"f_3604:extras_scm",(void*)f_3604},
{"f_3561:extras_scm",(void*)f_3561},
{"f_3594:extras_scm",(void*)f_3594},
{"f_3569:extras_scm",(void*)f_3569},
{"f_3555:extras_scm",(void*)f_3555},
{"f_3549:extras_scm",(void*)f_3549},
{"f_3543:extras_scm",(void*)f_3543},
{"f_3245:extras_scm",(void*)f_3245},
{"f_3249:extras_scm",(void*)f_3249},
{"f_3532:extras_scm",(void*)f_3532},
{"f_3252:extras_scm",(void*)f_3252},
{"f_3283:extras_scm",(void*)f_3283},
{"f_3318:extras_scm",(void*)f_3318},
{"f_3496:extras_scm",(void*)f_3496},
{"f_3451:extras_scm",(void*)f_3451},
{"f_3454:extras_scm",(void*)f_3454},
{"f_3460:extras_scm",(void*)f_3460},
{"f_3433:extras_scm",(void*)f_3433},
{"f_3429:extras_scm",(void*)f_3429},
{"f_3416:extras_scm",(void*)f_3416},
{"f_3412:extras_scm",(void*)f_3412},
{"f_3399:extras_scm",(void*)f_3399},
{"f_3395:extras_scm",(void*)f_3395},
{"f_3382:extras_scm",(void*)f_3382},
{"f_3369:extras_scm",(void*)f_3369},
{"f_3356:extras_scm",(void*)f_3356},
{"f_3331:extras_scm",(void*)f_3331},
{"f_3299:extras_scm",(void*)f_3299},
{"f_3292:extras_scm",(void*)f_3292},
{"f_3255:extras_scm",(void*)f_3255},
{"f_3277:extras_scm",(void*)f_3277},
{"f_3216:extras_scm",(void*)f_3216},
{"f_3220:extras_scm",(void*)f_3220},
{"f_3227:extras_scm",(void*)f_3227},
{"f_3229:extras_scm",(void*)f_3229},
{"f_3233:extras_scm",(void*)f_3233},
{"f_3223:extras_scm",(void*)f_3223},
{"f_1935:extras_scm",(void*)f_1935},
{"f_3203:extras_scm",(void*)f_3203},
{"f_3207:extras_scm",(void*)f_3207},
{"f_2556:extras_scm",(void*)f_2556},
{"f_3111:extras_scm",(void*)f_3111},
{"f_3121:extras_scm",(void*)f_3121},
{"f_3102:extras_scm",(void*)f_3102},
{"f_3096:extras_scm",(void*)f_3096},
{"f_3074:extras_scm",(void*)f_3074},
{"f_3068:extras_scm",(void*)f_3068},
{"f_3062:extras_scm",(void*)f_3062},
{"f_3056:extras_scm",(void*)f_3056},
{"f_3050:extras_scm",(void*)f_3050},
{"f_3044:extras_scm",(void*)f_3044},
{"f_3038:extras_scm",(void*)f_3038},
{"f_2890:extras_scm",(void*)f_2890},
{"f_3036:extras_scm",(void*)f_3036},
{"f_2988:extras_scm",(void*)f_2988},
{"f_3018:extras_scm",(void*)f_3018},
{"f_3003:extras_scm",(void*)f_3003},
{"f_2975:extras_scm",(void*)f_2975},
{"f_2934:extras_scm",(void*)f_2934},
{"f_2961:extras_scm",(void*)f_2961},
{"f_2957:extras_scm",(void*)f_2957},
{"f_2893:extras_scm",(void*)f_2893},
{"f_2920:extras_scm",(void*)f_2920},
{"f_2916:extras_scm",(void*)f_2916},
{"f_2813:extras_scm",(void*)f_2813},
{"f_2819:extras_scm",(void*)f_2819},
{"f_2888:extras_scm",(void*)f_2888},
{"f_2884:extras_scm",(void*)f_2884},
{"f_2876:extras_scm",(void*)f_2876},
{"f_2872:extras_scm",(void*)f_2872},
{"f_2850:extras_scm",(void*)f_2850},
{"f_2842:extras_scm",(void*)f_2842},
{"f_2804:extras_scm",(void*)f_2804},
{"f_2808:extras_scm",(void*)f_2808},
{"f_2776:extras_scm",(void*)f_2776},
{"f_2802:extras_scm",(void*)f_2802},
{"f_2780:extras_scm",(void*)f_2780},
{"f_2711:extras_scm",(void*)f_2711},
{"f_2718:extras_scm",(void*)f_2718},
{"f_2745:extras_scm",(void*)f_2745},
{"f_2771:extras_scm",(void*)f_2771},
{"f_2729:extras_scm",(void*)f_2729},
{"f_2624:extras_scm",(void*)f_2624},
{"f_2637:extras_scm",(void*)f_2637},
{"f_2675:extras_scm",(void*)f_2675},
{"f_2640:extras_scm",(void*)f_2640},
{"f_2669:extras_scm",(void*)f_2669},
{"f_2673:extras_scm",(void*)f_2673},
{"f_2653:extras_scm",(void*)f_2653},
{"f_2592:extras_scm",(void*)f_2592},
{"f_2615:extras_scm",(void*)f_2615},
{"f_2608:extras_scm",(void*)f_2608},
{"f_2559:extras_scm",(void*)f_2559},
{"f_2590:extras_scm",(void*)f_2590},
{"f_2583:extras_scm",(void*)f_2583},
{"f_2048:extras_scm",(void*)f_2048},
{"f_2227:extras_scm",(void*)f_2227},
{"f_2498:extras_scm",(void*)f_2498},
{"f_2537:extras_scm",(void*)f_2537},
{"f_2547:extras_scm",(void*)f_2547},
{"f_2540:extras_scm",(void*)f_2540},
{"f_2515:extras_scm",(void*)f_2515},
{"f_2525:extras_scm",(void*)f_2525},
{"f_2518:extras_scm",(void*)f_2518},
{"f_2505:extras_scm",(void*)f_2505},
{"f_2482:extras_scm",(void*)f_2482},
{"f_2485:extras_scm",(void*)f_2485},
{"f_2492:extras_scm",(void*)f_2492},
{"f_2464:extras_scm",(void*)f_2464},
{"f_2375:extras_scm",(void*)f_2375},
{"f_2378:extras_scm",(void*)f_2378},
{"f_2439:extras_scm",(void*)f_2439},
{"f_2418:extras_scm",(void*)f_2418},
{"f_2425:extras_scm",(void*)f_2425},
{"f_2402:extras_scm",(void*)f_2402},
{"f_2409:extras_scm",(void*)f_2409},
{"f_2382:extras_scm",(void*)f_2382},
{"f_2369:extras_scm",(void*)f_2369},
{"f_2285:extras_scm",(void*)f_2285},
{"f_2287:extras_scm",(void*)f_2287},
{"f_2294:extras_scm",(void*)f_2294},
{"f_2346:extras_scm",(void*)f_2346},
{"f_2342:extras_scm",(void*)f_2342},
{"f_2325:extras_scm",(void*)f_2325},
{"f_2321:extras_scm",(void*)f_2321},
{"f_2317:extras_scm",(void*)f_2317},
{"f_2266:extras_scm",(void*)f_2266},
{"f_2243:extras_scm",(void*)f_2243},
{"f_2246:extras_scm",(void*)f_2246},
{"f_2253:extras_scm",(void*)f_2253},
{"f_2234:extras_scm",(void*)f_2234},
{"f_2204:extras_scm",(void*)f_2204},
{"f_2208:extras_scm",(void*)f_2208},
{"f_2078:extras_scm",(void*)f_2078},
{"f_2161:extras_scm",(void*)f_2161},
{"f_2096:extras_scm",(void*)f_2096},
{"f_2098:extras_scm",(void*)f_2098},
{"f_2150:extras_scm",(void*)f_2150},
{"f_2146:extras_scm",(void*)f_2146},
{"f_2130:extras_scm",(void*)f_2130},
{"f_2122:extras_scm",(void*)f_2122},
{"f_2051:extras_scm",(void*)f_2051},
{"f_2058:extras_scm",(void*)f_2058},
{"f_2069:extras_scm",(void*)f_2069},
{"f_2029:extras_scm",(void*)f_2029},
{"f_2039:extras_scm",(void*)f_2039},
{"f_1996:extras_scm",(void*)f_1996},
{"f_1938:extras_scm",(void*)f_1938},
{"f_1970:extras_scm",(void*)f_1970},
{"f_1904:extras_scm",(void*)f_1904},
{"f_1914:extras_scm",(void*)f_1914},
{"f_1871:extras_scm",(void*)f_1871},
{"f_1878:extras_scm",(void*)f_1878},
{"f_1881:extras_scm",(void*)f_1881},
{"f_1850:extras_scm",(void*)f_1850},
{"f_1857:extras_scm",(void*)f_1857},
{"f_1863:extras_scm",(void*)f_1863},
{"f_1764:extras_scm",(void*)f_1764},
{"f_1805:extras_scm",(void*)f_1805},
{"f_1800:extras_scm",(void*)f_1800},
{"f_1769:extras_scm",(void*)f_1769},
{"f_1773:extras_scm",(void*)f_1773},
{"f_1786:extras_scm",(void*)f_1786},
{"f_1783:extras_scm",(void*)f_1783},
{"f_1702:extras_scm",(void*)f_1702},
{"f_1709:extras_scm",(void*)f_1709},
{"f_1712:extras_scm",(void*)f_1712},
{"f_1717:extras_scm",(void*)f_1717},
{"f_1721:extras_scm",(void*)f_1721},
{"f_1727:extras_scm",(void*)f_1727},
{"f_1737:extras_scm",(void*)f_1737},
{"f_1730:extras_scm",(void*)f_1730},
{"f_1645:extras_scm",(void*)f_1645},
{"f_1588:extras_scm",(void*)f_1588},
{"f_1592:extras_scm",(void*)f_1592},
{"f_1616:extras_scm",(void*)f_1616},
{"f_1619:extras_scm",(void*)f_1619},
{"f_1624:extras_scm",(void*)f_1624},
{"f_1628:extras_scm",(void*)f_1628},
{"f_1640:extras_scm",(void*)f_1640},
{"f_1601:extras_scm",(void*)f_1601},
{"f_1604:extras_scm",(void*)f_1604},
{"f_1494:extras_scm",(void*)f_1494},
{"f_1543:extras_scm",(void*)f_1543},
{"f_1538:extras_scm",(void*)f_1538},
{"f_1496:extras_scm",(void*)f_1496},
{"f_1500:extras_scm",(void*)f_1500},
{"f_1348:extras_scm",(void*)f_1348},
{"f_1488:extras_scm",(void*)f_1488},
{"f_1358:extras_scm",(void*)f_1358},
{"f_1428:extras_scm",(void*)f_1428},
{"f_1432:extras_scm",(void*)f_1432},
{"f_1435:extras_scm",(void*)f_1435},
{"f_1369:extras_scm",(void*)f_1369},
{"f_1373:extras_scm",(void*)f_1373},
{"f_1258:extras_scm",(void*)f_1258},
{"f_1325:extras_scm",(void*)f_1325},
{"f_1270:extras_scm",(void*)f_1270},
{"f_1280:extras_scm",(void*)f_1280},
{"f_1293:extras_scm",(void*)f_1293},
{"f_1109:extras_scm",(void*)f_1109},
{"f_1119:extras_scm",(void*)f_1119},
{"f_1122:extras_scm",(void*)f_1122},
{"f_1142:extras_scm",(void*)f_1142},
{"f_1147:extras_scm",(void*)f_1147},
{"f_1160:extras_scm",(void*)f_1160},
{"f_1233:extras_scm",(void*)f_1233},
{"f_1225:extras_scm",(void*)f_1225},
{"f_1211:extras_scm",(void*)f_1211},
{"f_1193:extras_scm",(void*)f_1193},
{"f_1202:extras_scm",(void*)f_1202},
{"f_1129:extras_scm",(void*)f_1129},
{"f_1070:extras_scm",(void*)f_1070},
{"f_1052:extras_scm",(void*)f_1052},
{"f_1031:extras_scm",(void*)f_1031},
{"f_1035:extras_scm",(void*)f_1035},
{"f_1038:extras_scm",(void*)f_1038},
{"f_897:extras_scm",(void*)f_897},
{"f_969:extras_scm",(void*)f_969},
{"f_964:extras_scm",(void*)f_964},
{"f_959:extras_scm",(void*)f_959},
{"f_899:extras_scm",(void*)f_899},
{"f_952:extras_scm",(void*)f_952},
{"f_902:extras_scm",(void*)f_902},
{"f_910:extras_scm",(void*)f_910},
{"f_912:extras_scm",(void*)f_912},
{"f_932:extras_scm",(void*)f_932},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
