/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:17
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: lolevel.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file ulolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[129];
static double C_possibly_force_alignment;


/* from k2808 */
static C_word C_fcall stub869(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub869(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from f_2556 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static C_word C_fcall stub759(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub759(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k3125 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub630(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub630(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_ret:
#undef return

return C_r;}

/* from k3135 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub623(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub623(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_ret:
#undef return

return C_r;}

/* from k3145 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub616(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub616(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3155 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub609(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub609(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3165 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub603(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub603(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_ret:
#undef return

return C_r;}

/* from k3175 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub597(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub597(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_ret:
#undef return

return C_r;}

/* from k3185 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub591(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub591(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((signed char *)p));
C_ret:
#undef return

return C_r;}

/* from k3195 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub585(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub585(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_ret:
#undef return

return C_r;}

/* from k2099 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub578(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub578(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2089 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub570(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub570(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2079 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub562(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub562(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2069 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub554(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub554(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2059 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub546(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub546(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2049 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub538(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub538(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2039 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub530(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub530(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2029 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub522(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub522(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from align */
static C_word C_fcall stub433(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub433(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k1839 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub424(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub424(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

/* from g407 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub410(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub410(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k1752 */
static C_word C_fcall stub377(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub377(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from allocate in k1086 in k1083 */
static C_word C_fcall stub372(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub372(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1297 */
static C_word C_fcall stub151(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub151(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1284 */
static C_word C_fcall stub135(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub135(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1271 */
static C_word C_fcall stub119(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub119(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1255 */
static C_word C_fcall stub103(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub103(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3037)
static void C_ccall f_3037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static void C_ccall f_3047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1118)
static void C_fcall f_1118(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_fcall f_2911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_fcall f_2982(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_fcall f_2824(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_fcall f_2843(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_fcall f_2856(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_fcall f_2858(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2732)
static void C_fcall f_2732(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2777)
static void C_fcall f_2777(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f3610)
static void C_ccall f3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_fcall f_2566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_fcall f_2580(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_fcall f_2599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2605)
static void C_fcall f_2605(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_fcall f_2621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_fcall f_2623(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_fcall f_2460(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_fcall f_2486(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_fcall f_2499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_fcall f_2501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static C_word C_fcall f_2419(C_word t0,C_word t1);
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2380)
static void C_ccall f_2380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2327)
static void C_fcall f_2327(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1209)
static void C_fcall f_1209(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1955)
static void C_fcall f_1955(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_fcall f_1901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1870)
static void C_fcall f_1870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1671)
static void C_fcall f_1671(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1701)
static void C_ccall f_1701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_fcall f_1716(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1737)
static void C_ccall f_1737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1605)
static void C_fcall f_1605(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_fcall f_1600(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1595)
static void C_fcall f_1595(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1307)
static void C_fcall f_1307(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1371)
static void C_ccall f_1371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1374)
static void C_ccall f_1374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_fcall f_1379(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1448)
static void C_fcall f_1448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_fcall f_1535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_fcall f_1464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1338)
static void C_fcall f_1338(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1345)
static void C_fcall f_1345(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_fcall f_1322(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1316)
static void C_fcall f_1316(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1310)
static void C_fcall f_1310(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1163)
static void C_fcall f_1163(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1175)
static void C_fcall f_1175(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_fcall f_1090(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_1118)
static void C_fcall trf_1118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1118(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1118(t0,t1,t2);}

C_noret_decl(trf_2911)
static void C_fcall trf_2911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2911(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2911(t0,t1,t2);}

C_noret_decl(trf_2982)
static void C_fcall trf_2982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2982(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2982(t0,t1,t2);}

C_noret_decl(trf_2824)
static void C_fcall trf_2824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2824(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2824(t0,t1,t2);}

C_noret_decl(trf_2843)
static void C_fcall trf_2843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2843(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2843(t0,t1);}

C_noret_decl(trf_2856)
static void C_fcall trf_2856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2856(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2856(t0,t1);}

C_noret_decl(trf_2858)
static void C_fcall trf_2858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2858(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2858(t0,t1,t2);}

C_noret_decl(trf_2732)
static void C_fcall trf_2732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2732(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2732(t0,t1,t2);}

C_noret_decl(trf_2777)
static void C_fcall trf_2777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2777(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2777(t0,t1,t2);}

C_noret_decl(trf_2566)
static void C_fcall trf_2566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2566(t0,t1);}

C_noret_decl(trf_2580)
static void C_fcall trf_2580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2580(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2580(t0,t1,t2);}

C_noret_decl(trf_2599)
static void C_fcall trf_2599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2599(t0,t1);}

C_noret_decl(trf_2605)
static void C_fcall trf_2605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2605(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2605(t0,t1);}

C_noret_decl(trf_2621)
static void C_fcall trf_2621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2621(t0,t1);}

C_noret_decl(trf_2623)
static void C_fcall trf_2623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2623(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2623(t0,t1,t2);}

C_noret_decl(trf_2460)
static void C_fcall trf_2460(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2460(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2460(t0,t1,t2);}

C_noret_decl(trf_2486)
static void C_fcall trf_2486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2486(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2486(t0,t1);}

C_noret_decl(trf_2499)
static void C_fcall trf_2499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2499(t0,t1);}

C_noret_decl(trf_2501)
static void C_fcall trf_2501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2501(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2501(t0,t1,t2);}

C_noret_decl(trf_2327)
static void C_fcall trf_2327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2327(t0,t1);}

C_noret_decl(trf_1209)
static void C_fcall trf_1209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1209(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1209(t0,t1);}

C_noret_decl(trf_1955)
static void C_fcall trf_1955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1955(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1955(t0,t1);}

C_noret_decl(trf_1901)
static void C_fcall trf_1901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1901(t0,t1);}

C_noret_decl(trf_1870)
static void C_fcall trf_1870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1870(t0,t1);}

C_noret_decl(trf_1671)
static void C_fcall trf_1671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1671(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1671(t0,t1,t2);}

C_noret_decl(trf_1716)
static void C_fcall trf_1716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1716(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1716(t0,t1,t2);}

C_noret_decl(trf_1605)
static void C_fcall trf_1605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1605(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1605(t0,t1);}

C_noret_decl(trf_1600)
static void C_fcall trf_1600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1600(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1600(t0,t1,t2);}

C_noret_decl(trf_1595)
static void C_fcall trf_1595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1595(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1595(t0,t1,t2,t3);}

C_noret_decl(trf_1307)
static void C_fcall trf_1307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1307(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1307(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1379)
static void C_fcall trf_1379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1379(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1379(t0,t1,t2,t3);}

C_noret_decl(trf_1448)
static void C_fcall trf_1448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1448(t0,t1);}

C_noret_decl(trf_1535)
static void C_fcall trf_1535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1535(t0,t1);}

C_noret_decl(trf_1464)
static void C_fcall trf_1464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1464(t0,t1);}

C_noret_decl(trf_1338)
static void C_fcall trf_1338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1338(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1338(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1345)
static void C_fcall trf_1345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1345(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1345(t0,t1);}

C_noret_decl(trf_1322)
static void C_fcall trf_1322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1322(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1322(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1316)
static void C_fcall trf_1316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1316(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1316(t0,t1,t2);}

C_noret_decl(trf_1310)
static void C_fcall trf_1310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1310(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1310(t0,t1);}

C_noret_decl(trf_1163)
static void C_fcall trf_1163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1163(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1163(t0,t1,t2);}

C_noret_decl(trf_1175)
static void C_fcall trf_1175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1175(t0,t1);}

C_noret_decl(trf_1090)
static void C_fcall trf_1090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1090(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1090(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1247)){
C_save(t1);
C_rereclaim2(1247*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,129);
lf[1]=C_h_intern(&lf[1],14,"\003syserror-hook");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],11,"\000type-error");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a structure");
lf[6]=C_h_intern(&lf[6],17,"\003syscheck-pointer");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[8]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[9]=C_h_intern(&lf[9],12,"move-memory!");
lf[10]=C_h_intern(&lf[10],9,"\003syserror");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[13]=C_h_intern(&lf[13],15,"\003sysbytevector\077");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\033negative destination offset");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\026negative source offset");
lf[16]=C_h_intern(&lf[16],11,"object-copy");
lf[17]=C_h_intern(&lf[17],15,"\003sysmake-vector");
lf[18]=C_h_intern(&lf[18],8,"allocate");
lf[19]=C_h_intern(&lf[19],4,"free");
lf[20]=C_h_intern(&lf[20],8,"pointer\077");
lf[21]=C_h_intern(&lf[21],13,"pointer-like\077");
lf[22]=C_h_intern(&lf[22],16,"address->pointer");
lf[23]=C_h_intern(&lf[23],20,"\003sysaddress->pointer");
lf[24]=C_h_intern(&lf[24],17,"\003syscheck-integer");
lf[25]=C_h_intern(&lf[25],16,"pointer->address");
lf[26]=C_h_intern(&lf[26],20,"\003syspointer->address");
lf[27]=C_h_intern(&lf[27],17,"\003syscheck-special");
lf[28]=C_h_intern(&lf[28],12,"null-pointer");
lf[29]=C_h_intern(&lf[29],16,"\003sysnull-pointer");
lf[30]=C_h_intern(&lf[30],13,"null-pointer\077");
lf[31]=C_h_intern(&lf[31],15,"object->pointer");
lf[32]=C_h_intern(&lf[32],15,"pointer->object");
lf[33]=C_h_intern(&lf[33],9,"pointer=\077");
lf[34]=C_h_intern(&lf[34],8,"pointer+");
lf[35]=C_h_intern(&lf[35],14,"pointer-offset");
lf[36]=C_h_intern(&lf[36],13,"align-to-word");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a pointer or integer");
lf[38]=C_h_intern(&lf[38],11,"tag-pointer");
lf[39]=C_h_intern(&lf[39],23,"\003sysmake-tagged-pointer");
lf[40]=C_h_intern(&lf[40],15,"tagged-pointer\077");
lf[41]=C_h_intern(&lf[41],11,"pointer-tag");
lf[42]=C_h_intern(&lf[42],13,"make-locative");
lf[43]=C_h_intern(&lf[43],17,"\003sysmake-locative");
lf[44]=C_h_intern(&lf[44],18,"make-weak-locative");
lf[45]=C_h_intern(&lf[45],13,"locative-set!");
lf[46]=C_h_intern(&lf[46],12,"locative-ref");
lf[47]=C_h_intern(&lf[47],16,"locative->object");
lf[48]=C_h_intern(&lf[48],9,"locative\077");
lf[49]=C_h_intern(&lf[49],15,"pointer-u8-set!");
lf[50]=C_h_intern(&lf[50],15,"pointer-s8-set!");
lf[51]=C_h_intern(&lf[51],16,"pointer-u16-set!");
lf[52]=C_h_intern(&lf[52],16,"pointer-s16-set!");
lf[53]=C_h_intern(&lf[53],16,"pointer-u32-set!");
lf[54]=C_h_intern(&lf[54],16,"pointer-s32-set!");
lf[55]=C_h_intern(&lf[55],16,"pointer-f32-set!");
lf[56]=C_h_intern(&lf[56],16,"pointer-f64-set!");
lf[57]=C_h_intern(&lf[57],14,"pointer-u8-ref");
lf[58]=C_h_intern(&lf[58],14,"pointer-s8-ref");
lf[59]=C_h_intern(&lf[59],15,"pointer-u16-ref");
lf[60]=C_h_intern(&lf[60],15,"pointer-s16-ref");
lf[61]=C_h_intern(&lf[61],15,"pointer-u32-ref");
lf[62]=C_h_intern(&lf[62],15,"pointer-s32-ref");
lf[63]=C_h_intern(&lf[63],15,"pointer-f32-ref");
lf[64]=C_h_intern(&lf[64],15,"pointer-f64-ref");
lf[65]=C_h_intern(&lf[65],8,"extended");
lf[67]=C_h_intern(&lf[67],16,"extend-procedure");
lf[68]=C_h_intern(&lf[68],19,"\003sysdecorate-lambda");
lf[69]=C_h_intern(&lf[69],17,"\003syscheck-closure");
lf[70]=C_h_intern(&lf[70],19,"extended-procedure\077");
lf[71]=C_h_intern(&lf[71],21,"\003syslambda-decoration");
lf[72]=C_h_intern(&lf[72],14,"procedure-data");
lf[73]=C_h_intern(&lf[73],19,"set-procedure-data!");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[75]=C_h_intern(&lf[75],10,"block-set!");
lf[76]=C_h_intern(&lf[76],14,"\003sysblock-set!");
lf[77]=C_h_intern(&lf[77],9,"block-ref");
lf[78]=C_h_intern(&lf[78],15,"number-of-slots");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a vector-like object");
lf[80]=C_h_intern(&lf[80],15,"number-of-bytes");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\0002cannot compute number of bytes of immediate object");
lf[82]=C_h_intern(&lf[82],20,"make-record-instance");
lf[83]=C_h_intern(&lf[83],18,"\003sysmake-structure");
lf[84]=C_h_intern(&lf[84],16,"record-instance\077");
lf[85]=C_h_intern(&lf[85],20,"record-instance-type");
lf[86]=C_h_intern(&lf[86],22,"record-instance-length");
lf[87]=C_h_intern(&lf[87],25,"record-instance-slot-set!");
lf[88]=C_h_intern(&lf[88],15,"\003syscheck-range");
lf[89]=C_h_intern(&lf[89],20,"record-instance-slot");
lf[90]=C_h_intern(&lf[90],14,"record->vector");
lf[91]=C_h_intern(&lf[91],15,"object-evicted\077");
lf[92]=C_h_intern(&lf[92],12,"object-evict");
lf[93]=C_h_intern(&lf[93],15,"hash-table-set!");
lf[94]=C_h_intern(&lf[94],19,"\003sysundefined-value");
lf[95]=C_h_intern(&lf[95],22,"hash-table-ref/default");
lf[96]=C_h_intern(&lf[96],15,"make-hash-table");
lf[97]=C_h_intern(&lf[97],3,"eq\077");
lf[98]=C_h_intern(&lf[98],24,"object-evict-to-location");
lf[99]=C_h_intern(&lf[99],24,"\003sysset-pointer-address!");
lf[100]=C_h_intern(&lf[100],6,"signal");
lf[101]=C_h_intern(&lf[101],24,"make-composite-condition");
lf[102]=C_h_intern(&lf[102],23,"make-property-condition");
lf[103]=C_h_intern(&lf[103],5,"evict");
lf[104]=C_h_intern(&lf[104],5,"limit");
lf[105]=C_h_intern(&lf[105],3,"exn");
lf[106]=C_h_intern(&lf[106],8,"location");
lf[107]=C_h_intern(&lf[107],7,"message");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000$cannot evict object - limit exceeded");
lf[109]=C_h_intern(&lf[109],9,"arguments");
lf[110]=C_h_intern(&lf[110],14,"object-release");
lf[111]=C_h_intern(&lf[111],11,"object-size");
lf[112]=C_h_intern(&lf[112],14,"object-unevict");
lf[113]=C_h_intern(&lf[113],15,"\003sysmake-string");
lf[114]=C_h_intern(&lf[114],14,"object-become!");
lf[115]=C_h_intern(&lf[115],11,"\003sysbecome!");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000:bad argument type - not an a-list of non-immediate objects");
lf[117]=C_h_intern(&lf[117],16,"mutate-procedure");
lf[118]=C_h_intern(&lf[118],10,"global-ref");
lf[119]=C_h_intern(&lf[119],11,"global-set!");
lf[120]=C_h_intern(&lf[120],13,"global-bound\077");
lf[121]=C_h_intern(&lf[121],32,"\003syssymbol-has-toplevel-binding\077");
lf[122]=C_h_intern(&lf[122],20,"global-make-unbound!");
lf[123]=C_h_intern(&lf[123],28,"\003sysarbitrary-unbound-symbol");
lf[124]=C_h_intern(&lf[124],18,"getter-with-setter");
lf[125]=C_h_intern(&lf[125],13,"\003sysblock-ref");
lf[126]=C_h_intern(&lf[126],15,"pointer-s6-set!");
lf[127]=C_h_intern(&lf[127],17,"register-feature!");
lf[128]=C_h_intern(&lf[128],7,"lolevel");
C_register_lf2(lf,129,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1085,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1083 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 75   register-feature! */
t3=*((C_word*)lf[127]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[128]);}

/* k1086 in k1083 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[52],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1088,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! check-block ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1090,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[2] /* (set! check-generic-structure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1163,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! check-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1224,tmp=(C_word)a,a+=2,tmp));
t5=lf[8];
t6=C_mutate((C_word*)lf[9]+1 /* (set! move-memory! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1305,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[16]+1 /* (set! object-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1665,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[18]+1 /* (set! allocate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1746,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[19]+1 /* (set! free ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1749,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[20]+1 /* (set! pointer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1759,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[21]+1 /* (set! pointer-like? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1767,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[22]+1 /* (set! address->pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1778,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[25]+1 /* (set! pointer->address ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1787,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[28]+1 /* (set! null-pointer ...) */,*((C_word*)lf[29]+1));
t15=C_mutate((C_word*)lf[30]+1 /* (set! null-pointer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1797,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[31]+1 /* (set! object->pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1810,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[32]+1 /* (set! pointer->object ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1821,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[33]+1 /* (set! pointer=? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1827,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[34]+1 /* (set! pointer+ ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1836,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[35]+1 /* (set! pointer-offset ...) */,*((C_word*)lf[34]+1));
t21=C_mutate((C_word*)lf[36]+1 /* (set! align-to-word ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1849,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[38]+1 /* (set! tag-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1886,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[40]+1 /* (set! tagged-pointer? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1906,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[41]+1 /* (set! pointer-tag ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1943,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[42]+1 /* (set! make-locative ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1966,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[44]+1 /* (set! make-weak-locative ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1988,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[45]+1 /* (set! locative-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2010,tmp=(C_word)a,a+=2,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)C_locative_ref,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 353  getter-with-setter */
t30=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t30+1)))(4,t30,t28,t29,*((C_word*)lf[45]+1));}

/* k2013 in k1086 in k1083 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2015,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1 /* (set! locative-ref ...) */,t1);
t3=C_mutate((C_word*)lf[47]+1 /* (set! locative->object ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2017,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[48]+1 /* (set! locative? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2020,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[49]+1 /* (set! pointer-u8-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2026,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[50]+1 /* (set! pointer-s8-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2036,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[51]+1 /* (set! pointer-u16-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2046,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[52]+1 /* (set! pointer-s16-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2056,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[53]+1 /* (set! pointer-u32-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2066,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[54]+1 /* (set! pointer-s32-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2076,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[55]+1 /* (set! pointer-f32-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2086,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[56]+1 /* (set! pointer-f64-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2096,tmp=(C_word)a,a+=2,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2108,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3192,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 370  getter-with-setter */
t15=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,*((C_word*)lf[49]+1));}

/* a3191 in k2013 in k1086 in k1083 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3192,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub585(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub585(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2108,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! pointer-u8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2112,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3182,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 375  getter-with-setter */
t5=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[50]+1));}

/* a3181 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3182,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub591(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub591(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2112,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! pointer-s8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3172,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 380  getter-with-setter */
t5=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[51]+1));}

/* a3171 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3172,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub597(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub597(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2116,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1 /* (set! pointer-u16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3162,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 385  getter-with-setter */
t5=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[126]+1));}

/* a3161 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3162,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub603(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub603(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2120,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* (set! pointer-s16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3152,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 390  getter-with-setter */
t5=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[53]+1));}

/* a3151 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3152,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub609(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub609(t3,C_SCHEME_FALSE));}}

/* k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2124,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! pointer-u32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3142,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 395  getter-with-setter */
t5=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[54]+1));}

/* a3141 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3142,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub616(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub616(t3,C_SCHEME_FALSE));}}

/* k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2128,2,t0,t1);}
t2=C_mutate((C_word*)lf[62]+1 /* (set! pointer-s32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3132,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 400  getter-with-setter */
t5=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[55]+1));}

/* a3131 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3132,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub623(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub623(t3,C_SCHEME_FALSE));}}

/* k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2132,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! pointer-f32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3122,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 405  getter-with-setter */
t5=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[56]+1));}

/* a3121 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3122,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub630(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub630(t3,C_SCHEME_FALSE));}}

/* k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2136,2,t0,t1);}
t2=C_mutate((C_word*)lf[64]+1 /* (set! pointer-f64-ref ...) */,t1);
t3=(C_word)C_a_i_vector(&a,1,lf[65]);
t4=C_mutate(&lf[66] /* (set! xproc-tag ...) */,t3);
t5=C_mutate((C_word*)lf[67]+1 /* (set! extend-procedure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2142,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[70]+1 /* (set! extended-procedure? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2177,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[72]+1 /* (set! procedure-data ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2213,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[67]+1);
t9=C_mutate((C_word*)lf[73]+1 /* (set! set-procedure-data! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2252,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[75]+1 /* (set! block-set! ...) */,*((C_word*)lf[76]+1));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 449  getter-with-setter */
t12=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[125]+1),*((C_word*)lf[76]+1));}

/* k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2270,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! block-ref ...) */,t1);
t3=C_mutate((C_word*)lf[78]+1 /* (set! number-of-slots ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2272,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[80]+1 /* (set! number-of-bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2281,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[82]+1 /* (set! make-record-instance ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2303,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[84]+1 /* (set! record-instance? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2312,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[85]+1 /* (set! record-instance-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2354,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[86]+1 /* (set! record-instance-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2363,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[87]+1 /* (set! record-instance-slot-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2376,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3098,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 496  getter-with-setter */
t12=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,*((C_word*)lf[87]+1));}

/* a3097 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3098,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3102,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 498  ##sys#check-generic-structure */
f_1163(t4,t2,(C_word)C_a_i_list(&a,1,lf[89]));}

/* k3100 in a3097 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 499  ##sys#check-range */
t5=*((C_word*)lf[88]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,((C_word*)t0)[4],C_fix(0),t4,lf[89]);}

/* k3103 in k3100 in a3097 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! record-instance-slot ...) */,t1);
t3=C_mutate((C_word*)lf[90]+1 /* (set! record->vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2404,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[91]+1 /* (set! object-evicted? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2442,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[92]+1 /* (set! object-evict ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2445,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[98]+1 /* (set! object-evict-to-location ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2559,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[110]+1 /* (set! object-release ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2723,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[111]+1 /* (set! object-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2815,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[112]+1 /* (set! object-unevict ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2899,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[114]+1 /* (set! object-become! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3021,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[117]+1 /* (set! mutate-procedure ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3030,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[118]+1 /* (set! global-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3061,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[119]+1 /* (set! global-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3067,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[120]+1 /* (set! global-bound? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3076,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[122]+1 /* (set! global-make-unbound! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3085,tmp=(C_word)a,a+=2,tmp));
t16=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3085,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[122]);
t4=(C_word)C_slot(lf[123],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3076,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[120]);
/* lolevel.scm: 667  ##sys#symbol-has-toplevel-binding? */
t4=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* global-set! in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3067,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[119]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3061,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[118]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* mutate-procedure in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3030,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3034,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 646  ##sys#check-closure */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[117]);}

/* k3032 in mutate-procedure in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 647  ##sys#check-closure */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[117]);}

/* k3035 in k3032 in mutate-procedure in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3037,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 650  ##sys#make-vector */
t5=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3042 in k3035 in k3032 in mutate-procedure in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3044,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3047,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3059,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 651  proc */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3057 in k3042 in k3035 in k3032 in mutate-procedure in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* lolevel.scm: 651  ##sys#become! */
t4=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k3045 in k3042 in k3035 in k3032 in mutate-procedure in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3021,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3025,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_i_check_list_2(t4,lf[114]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1118,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1118(t9,t3,t4);}

/* loop in object-become! in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_1118(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1118,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_pair_2(t4,lf[114]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1140,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_i_car(t4);
/* lolevel.scm: 116  ##sys#check-block */
f_1090(t6,t7,(C_word)C_a_i_list(&a,1,lf[114]));}
else{
/* lolevel.scm: 120  ##sys#signal-hook */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[4],lf[114],lf[116],((C_word*)t0)[2]);}}}

/* k1138 in loop in object-become! in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* lolevel.scm: 117  ##sys#check-block */
f_1090(t2,t3,(C_word)C_a_i_list(&a,1,lf[114]));}

/* k1141 in k1138 in loop in object-become! in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lolevel.scm: 118  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1118(t3,((C_word*)t0)[2],t2);}

/* k3023 in object-become! in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 643  ##sys#become! */
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2899r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2899r(t0,t1,t2,t3);}}

static void C_ccall f_2899r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2906,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 614  make-hash-table */
t7=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[97]+1));}

/* k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2906,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2911,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2911(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2911,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 618  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2925 in copy in k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2940,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 621  ##sys#make-string */
t4=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm: 626  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 631  ##sys#make-vector */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k2968 in k2925 in copy in k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 632  hash-table-set! */
t4=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2971 in k2968 in k2925 in copy in k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_2982(t7,t2,t3);}

/* doloop961 in k2971 in k2968 in k2925 in copy in k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2982(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2982,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3003,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 635  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2911(t5,t3,t4);}}

/* k3001 in doloop961 in k2971 in k2968 in k2925 in copy in k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2982(t4,((C_word*)t0)[2],t3);}

/* k2974 in k2971 in k2968 in k2925 in copy in k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2954 in k2925 in copy in k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 627  hash-table-set! */
t3=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2957 in k2954 in k2925 in copy in k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2938 in k2925 in copy in k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2940,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2943,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 622  hash-table-set! */
t4=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k2941 in k2938 in k2925 in copy in k2904 in object-unevict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2815,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2819,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 597  make-hash-table */
t4=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[97]+1));}

/* k2817 in object-size in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2819,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2824,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2824(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2817 in object-size in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2824(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2824,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 600  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2835 in evict in k2817 in object-size in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2837,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2894,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm: 604  align-to-word */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t5=(C_word)C_bytes(t2);
t6=t3;
f_2843(t6,(C_word)C_u_fixnum_plus(t5,(C_word)C_bytes(C_fix(1))));}}}

/* k2892 in k2835 in evict in k2817 in object-size in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2843(t2,(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1))));}

/* k2841 in k2835 in evict in k2817 in object-size in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2843(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2843,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 606  hash-table-set! */
t5=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k2844 in k2841 in k2835 in evict in k2817 in object-size in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2849,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2856,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2856(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=(C_word)C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2856(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2854 in k2844 in k2841 in k2835 in evict in k2817 in object-size in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2856(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2856,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2858(t5,((C_word*)t0)[2],t1);}

/* doloop911 in k2854 in k2844 in k2841 in k2835 in evict in k2817 in object-size in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2858(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2858,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2880,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 610  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2824(t5,t3,t4);}}

/* k2878 in doloop911 in k2854 in k2844 in k2841 in k2835 in evict in k2817 in object-size in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_u_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2858(t5,((C_word*)t0)[2],t4);}

/* k2847 in k2844 in k2841 in k2835 in evict in k2817 in object-size in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-release in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2723r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2723r(t0,t1,t2,t3);}}

static void C_ccall f_2723r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2805,tmp=(C_word)a,a+=2,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2732,a[2]=t9,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2732(t11,t1,t2);}

/* release in object-release in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2732(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2732,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
if(C_truep((C_word)C_u_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2761,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3610,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 594  ##sys#address->pointer */
t8=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,(C_word)C_block_address(&a,1,t2));}
else{
t7=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2777,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2777(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* doloop885 in release in object-release in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2777(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2777,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2787,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 593  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2732(t5,t3,t4);}}

/* k2785 in doloop885 in release in object-release in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2777(t3,((C_word*)t0)[2],t2);}

/* f3610 in release in object-release in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 594  free */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2759 in release in object-release in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 594  ##sys#address->pointer */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2766 in k2759 in release in object-release in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 594  free */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_2805 in object-release in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2805,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub869(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub869(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2559r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2559r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2559r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2563,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 541  ##sys#check-special */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[98]);}

/* k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[98]);
t5=t2;
f_2566(t5,t3);}
else{
t3=t2;
f_2566(t3,C_SCHEME_FALSE);}}

/* k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2566,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2712,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 546  ##sys#pointer->address */
t6=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2710 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 546  ##sys#address->pointer */
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 547  make-hash-table */
t3=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[97]+1));}

/* k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2580,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2580(t6,t2,((C_word*)t0)[2]);}

/* evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2580(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2580,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 551  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2590,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2705,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 555  align-to-word */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t5=(C_word)C_bytes(t2);
t6=t3;
f_2599(t6,(C_word)C_u_fixnum_plus(t5,(C_word)C_bytes(C_fix(1))));}}}

/* k2703 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2599(t2,(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1))));}

/* k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2599,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2602,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t1);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2689,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2693,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm: 562  make-property-condition */
t8=*((C_word*)lf[102]+1);
((C_proc9)(void*)(*((C_word*)t8+1)))(9,t8,t6,lf[105],lf[106],lf[98],lf[107],lf[108],lf[109],t7);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t2;
f_2602(2,t6,t5);}}
else{
t3=t2;
f_2602(2,t3,C_SCHEME_UNDEFINED);}}

/* k2691 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2697,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 566  make-property-condition */
t3=*((C_word*)lf[102]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[103],lf[104],((C_word*)((C_word*)t0)[2])[1]);}

/* k2695 in k2691 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 561  make-composite-condition */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2687 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 560  signal */
t2=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2600 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2605,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[8]))){
t4=*((C_word*)lf[94]+1);
t5=t3;
f_2605(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2605(t4,C_SCHEME_UNDEFINED);}}

/* k2603 in k2600 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2605(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2605,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2608,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 569  ##sys#pointer->address */
t4=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2660 in k2603 in k2600 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 569  ##sys#set-pointer-address! */
t3=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2606 in k2603 in k2600 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 570  hash-table-set! */
t3=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2609 in k2606 in k2603 in k2600 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2621,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2621(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=(C_word)C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2621(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2619 in k2609 in k2606 in k2603 in k2600 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2621,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2623(t5,((C_word*)t0)[2],t1);}

/* doloop844 in k2619 in k2609 in k2606 in k2603 in k2600 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2623(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2623,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2644,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 574  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2580(t5,t3,t4);}}

/* k2642 in doloop844 in k2619 in k2609 in k2606 in k2603 in k2600 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2623(t4,((C_word*)t0)[2],t3);}

/* k2612 in k2609 in k2606 in k2603 in k2600 in k2597 in k2588 in evict in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2573 in k2570 in k2567 in k2564 in k2561 in object-evict-to-location in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 576  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2445r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2445r(t0,t1,t2,t3);}}

static void C_ccall f_2445r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2556,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2452,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 522  make-hash-table */
t7=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[97]+1));}

/* k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 523  ##sys#check-closure */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[92]);}

/* k2453 in k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2455,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2460(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2453 in k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2460(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2460,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 526  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm: 529  align-to-word */
t4=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_2479(2,t4,(C_word)C_bytes(t2));}}}

/* k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 530  allocator */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
t4=*((C_word*)lf[94]+1);
t5=t3;
f_2486(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2486(t4,C_SCHEME_UNDEFINED);}}

/* k2484 in k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2486(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2486,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 532  hash-table-set! */
t3=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2487 in k2484 in k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2499,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2499(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=(C_word)C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2499(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2497 in k2487 in k2484 in k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2499,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2501(t5,((C_word*)t0)[2],t1);}

/* doloop784 in k2497 in k2487 in k2484 in k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2501,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2522,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 537  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2460(t5,t3,t4);}}

/* k2520 in doloop784 in k2497 in k2487 in k2484 in k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2501(t4,((C_word*)t0)[2],t3);}

/* k2490 in k2487 in k2484 in k2481 in k2477 in k2468 in evict in k2453 in k2450 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2556 in object-evict in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2556,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub759(t3,t2));}

/* object-evicted? in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2442,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* record->vector in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2404,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2408,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 504  ##sys#check-generic-structure */
f_1163(t3,t2,(C_word)C_a_i_list(&a,1,lf[90]));}

/* k2406 in record->vector in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 506  ##sys#make-vector */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2412 in k2406 in record->vector in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2419(t2,C_fix(0)));}

/* doloop743 in k2412 in k2406 in record->vector in k2400 in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static C_word C_fcall f_2419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
return(t2);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t7=t4;
t1=t7;
goto loop;}}

/* record-instance-slot-set! in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2376,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2380,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 491  ##sys#check-generic-structure */
f_1163(t5,t2,(C_word)C_a_i_list(&a,1,lf[87]));}

/* k2378 in record-instance-slot-set! in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 492  ##sys#check-range */
t5=*((C_word*)lf[88]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,((C_word*)t0)[5],C_fix(0),t4,lf[87]);}

/* k2381 in k2378 in record-instance-slot-set! in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],t2,((C_word*)t0)[2]));}

/* record-instance-length in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2363,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2367,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 487  ##sys#check-generic-structure */
f_1163(t3,t2,(C_word)C_a_i_list(&a,1,lf[86]));}

/* k2365 in record-instance-length in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_fixnum_difference(t2,C_fix(1)));}

/* record-instance-type in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2354,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2358,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 483  ##sys#check-generic-structure */
f_1163(t3,t2,(C_word)C_a_i_list(&a,1,lf[85]));}

/* k2356 in record-instance-type in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* record-instance? in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2312r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2312r(t0,t1,t2,t3);}}

static void C_ccall f_2312r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2327,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=t2;
if(C_truep((C_word)C_blockp(t7))){
t8=(C_word)C_structurep(t7);
t9=t6;
f_2327(t9,t8);}
else{
t8=t6;
f_2327(t8,C_SCHEME_FALSE);}}

/* k2325 in record-instance? in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_2327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_not(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(((C_word*)t0)[4],t3));}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* make-record-instance in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2303r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2303r(t0,t1,t2,t3);}}

static void C_ccall f_2303r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[82]);
C_apply(5,0,t1,*((C_word*)lf[83]+1),t2,t3);}

/* number-of-bytes in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2281,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
/* lolevel.scm: 457  ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[4],lf[80],lf[81],t2);}}

/* number-of-slots in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2272,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2276,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_list(&a,1,lf[78]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1209,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_blockp(t4))){
t7=(C_word)C_specialp(t4);
if(C_truep(t7)){
t8=t6;
f_1209(t8,(C_word)C_i_not(t7));}
else{
t8=(C_word)C_byteblockp(t4);
t9=t6;
f_1209(t9,(C_word)C_i_not(t8));}}
else{
t7=t6;
f_1209(t7,C_SCHEME_FALSE);}}

/* k1207 in number-of-slots in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_fcall f_1209(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[5]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* lolevel.scm: 134  ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[4],t2,lf[79],((C_word*)t0)[2]);}
else{
/* lolevel.scm: 134  ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[4],C_SCHEME_FALSE,lf[79],((C_word*)t0)[2]);}}}

/* k2274 in number-of-slots in k2268 in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* set-procedure-data! in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2252,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2256,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 438  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k2254 in set-procedure-data! in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* lolevel.scm: 441  ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[4],lf[73],lf[74],((C_word*)t0)[3]);}}

/* procedure-data in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2213,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2244,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2227,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 423  ##sys#lambda-decoration */
t6=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2226 in procedure-data in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2227,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[66],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2242 in procedure-data in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2177,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2211,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2194,tmp=(C_word)a,a+=2,tmp);
/* lolevel.scm: 423  ##sys#lambda-decoration */
t6=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2193 in extended-procedure? in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2194,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[66],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2209 in extended-procedure? in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2142,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2146,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 416  ##sys#check-closure */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[67]);}

/* k2144 in extend-procedure in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2151,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2167,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 417  ##sys#decorate-lambda */
t4=*((C_word*)lf[68]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2166 in k2144 in extend-procedure in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2167,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[66],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a2150 in k2144 in extend-procedure in k2134 in k2130 in k2126 in k2122 in k2118 in k2114 in k2110 in k2106 in k2013 in k1086 in k1083 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2151,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[66],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-f64-set! in k2013 in k1086 in k1083 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2096,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub578(C_SCHEME_UNDEFINED,t4,t3));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub578(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t3));}}

/* pointer-f32-set! in k2013 in k1086 in k1083 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2086,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub570(C_SCHEME_UNDEFINED,t4,t3));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub570(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t3));}}

/* pointer-s32-set! in k2013 in k1086 in k1083 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2076,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub562(C_SCHEME_UNDEFINED,t4,t3));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub562(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t3));}}

/* pointer-u32-set! in k2013 in k1086 in k1083 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2066,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub554(C_SCHEME_UNDEFINED,t4,t3));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub554(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t3));}}

/* pointer-s16-set! in k2013 in k1086 in k1083 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2056,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub546(C_SCHEME_UNDEFINED,t4,t3));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub546(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t3));}}

/* pointer-u16-set! in k2013 in k1086 in k1083 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2046,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub538(C_SCHEME_UNDEFINED,t4,t3));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub538(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t3));}}

/* pointer-s8-set! in k2013 in k1086 in k1083 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2036,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub530(C_SCHEME_UNDEFINED,t4,t3));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub530(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t3));}}

/* pointer-u8-set! in k2013 in k1086 in k1083 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2026,4,t0,t1,t2,t3);}
if(C_truep(t2)){
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub522(C_SCHEME_UNDEFINED,t4,t3));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub522(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t3));}}

/* locative? in k2013 in k1086 in k1083 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2020,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_locativep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* locative->object in k2013 in k1086 in k1083 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2017,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k1086 in k1083 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2010,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k1086 in k1083 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1988r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1988r(t0,t1,t2,t3);}}

static void C_ccall f_1988r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
if(C_truep((C_word)C_vemptyp(t3))){
/* lolevel.scm: 350  ##sys#make-locative */
t4=*((C_word*)lf[43]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,t2,C_fix(0),C_SCHEME_TRUE,lf[44]);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
/* lolevel.scm: 350  ##sys#make-locative */
t5=*((C_word*)lf[43]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,t2,t4,C_SCHEME_TRUE,lf[44]);}}

/* make-locative in k1086 in k1083 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1966r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1966r(t0,t1,t2,t3);}}

static void C_ccall f_1966r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
if(C_truep((C_word)C_vemptyp(t3))){
/* lolevel.scm: 347  ##sys#make-locative */
t4=*((C_word*)lf[43]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,t2,C_fix(0),C_SCHEME_FALSE,lf[42]);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
/* lolevel.scm: 347  ##sys#make-locative */
t5=*((C_word*)lf[43]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,t2,t4,C_SCHEME_FALSE,lf[42]);}}

/* pointer-tag in k1086 in k1083 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1943,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1955,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
if(C_truep((C_word)C_blockp(t4))){
t5=(C_word)C_specialp(t4);
t6=t3;
f_1955(t6,t5);}
else{
t5=t3;
f_1955(t5,C_SCHEME_FALSE);}}

/* k1953 in pointer-tag in k1086 in k1083 */
static void C_fcall f_1955(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep((C_word)C_taggedpointerp(((C_word*)t0)[2]))?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 324  ##sys#error-hook */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[41],((C_word*)t0)[2]);}}

/* tagged-pointer? in k1086 in k1083 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1906r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1906r(t0,t1,t2,t3);}}

static void C_ccall f_1906r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_equalp(t5,t7));}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* tag-pointer in k1086 in k1083 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1886,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1890,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 309  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1888 in tag-pointer in k1086 in k1083 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1893,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1901,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
if(C_truep((C_word)C_blockp(t4))){
t5=(C_word)C_specialp(t4);
t6=t3;
f_1901(t6,t5);}
else{
t5=t3;
f_1901(t5,C_SCHEME_FALSE);}}

/* k1899 in k1888 in tag-pointer in k1086 in k1083 */
static void C_fcall f_1901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_copy_pointer(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
/* lolevel.scm: 312  ##sys#error-hook */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[38],((C_word*)t0)[5]);}}

/* k1891 in k1888 in tag-pointer in k1086 in k1083 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* align-to-word in k1086 in k1083 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1849,3,t0,t1,t2);}
if(C_truep((C_word)C_i_integerp(t2))){
t3=t1;
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub433(t5,t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1870,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
if(C_truep((C_word)C_blockp(t4))){
t5=(C_word)C_specialp(t4);
t6=t3;
f_1870(t6,t5);}
else{
t5=t3;
f_1870(t5,C_SCHEME_FALSE);}}}

/* k1868 in align-to-word in k1086 in k1083 */
static void C_fcall f_1870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1870,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 299  ##sys#pointer->address */
t3=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
/* lolevel.scm: 301  ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[4],lf[36],lf[37],((C_word*)t0)[2]);}}

/* k1879 in k1868 in align-to-word in k1086 in k1083 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t3=(C_word)stub433(t2,t1);
/* lolevel.scm: 299  ##sys#address->pointer */
t4=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* pointer+ in k1086 in k1083 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1836,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
if(C_truep(t2)){
t5=(C_word)C_i_foreign_pointer_argumentp(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub424(t4,t5,t3));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub424(t4,C_SCHEME_FALSE,t3));}}

/* pointer=? in k1086 in k1083 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1827,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1831,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 283  ##sys#check-special */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[33]);}

/* k1829 in pointer=? in k1086 in k1083 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 284  ##sys#check-special */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[33]);}

/* k1832 in k1829 in pointer=? in k1086 in k1083 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k1086 in k1083 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1821,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1825,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 279  ##sys#check-pointer */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[32]);}

/* k1823 in pointer->object in k1086 in k1083 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k1086 in k1083 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1810,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=t1;
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub410(t5,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* null-pointer? in k1086 in k1083 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1797,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1801,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 271  ##sys#check-special */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[30]);}

/* k1799 in null-pointer? in k1086 in k1083 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 272  ##sys#pointer->address */
t3=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1806 in k1799 in null-pointer? in k1086 in k1083 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k1086 in k1083 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1787,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1791,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 265  ##sys#check-special */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[25]);}

/* k1789 in pointer->address in k1086 in k1083 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 266  ##sys#pointer->address */
t2=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k1086 in k1083 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1778,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1782,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 261  ##sys#check-integer */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[22]);}

/* k1780 in address->pointer in k1086 in k1083 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 262  ##sys#address->pointer */
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer-like? in k1086 in k1083 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1767,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_specialp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer? in k1086 in k1083 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1759,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_safe_pointerp(t2));}

/* free in k1086 in k1083 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1749,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub377(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub377(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* allocate in k1086 in k1083 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1746,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub372(t3,t2));}

/* object-copy in k1086 in k1083 */
static void C_ccall f_1665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1665,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1671,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1671(t6,t1,t2);}

/* copy in object-copy in k1086 in k1083 */
static void C_fcall f_1671(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1671,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 239  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1701,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 243  ##sys#make-vector */
t6=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1699 in copy in object-copy in k1086 in k1083 */
static void C_ccall f_1701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1701,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1704,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_1716(t10,t3,t6);}}

/* doloop362 in k1699 in copy in object-copy in k1086 in k1083 */
static void C_fcall f_1716(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1716,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1737,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 247  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1671(t5,t3,t4);}}

/* k1735 in doloop362 in k1699 in copy in object-copy in k1086 in k1083 */
static void C_ccall f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1716(t4,((C_word*)t0)[2],t3);}

/* k1702 in k1699 in copy in object-copy in k1086 in k1083 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* move-memory! in k1086 in k1083 */
static void C_ccall f_1305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr4r,(void*)f_1305r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1305r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1305r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(14);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1595,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1600,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1605,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-n183333 */
t9=t8;
f_1605(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-foffset184331 */
t11=t7;
f_1600(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-toffset185328 */
t13=t6;
f_1595(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body181190 */
t15=t5;
f_1307(t15,t1,t9,t11,t13);}}}}

/* def-n183 in move-memory! in k1086 in k1083 */
static void C_fcall f_1605(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1605,NULL,2,t0,t1);}
/* def-foffset184331 */
t2=((C_word*)t0)[2];
f_1600(t2,t1,C_SCHEME_FALSE);}

/* def-foffset184 in move-memory! in k1086 in k1083 */
static void C_fcall f_1600(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1600,NULL,3,t0,t1,t2);}
/* def-toffset185328 */
t3=((C_word*)t0)[2];
f_1595(t3,t1,t2,C_fix(0));}

/* def-toffset185 in move-memory! in k1086 in k1083 */
static void C_fcall f_1595(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1595,NULL,4,t0,t1,t2,t3);}
/* body181190 */
t4=((C_word*)t0)[2];
f_1307(t4,t1,t2,t3,C_fix(0));}

/* body181 in move-memory! in k1086 in k1083 */
static void C_fcall f_1307(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[37],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1307,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1322,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1338,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t17=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1365,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t12,a[6]=t10,a[7]=t6,a[8]=t3,a[9]=t4,a[10]=t2,a[11]=((C_word*)t0)[2],tmp=(C_word)a,a+=12,tmp);
/* lolevel.scm: 197  ##sys#check-block */
f_1090(t17,((C_word*)t0)[4],(C_word)C_a_i_list(&a,1,lf[9]));}

/* k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* lolevel.scm: 198  ##sys#check-block */
f_1090(t2,((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,lf[9]));}

/* k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[8],C_fix(0)))){
/* lolevel.scm: 201  ##sys#error */
t3=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[9],lf[15],((C_word*)t0)[8]);}
else{
t3=t2;
f_1371(2,t3,C_SCHEME_UNDEFINED);}}

/* k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[9],C_fix(0)))){
/* lolevel.scm: 204  ##sys#error */
t3=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[9],lf[14],((C_word*)t0)[9]);}
else{
t3=t2;
f_1374(2,t3,C_SCHEME_UNDEFINED);}}

/* k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1374,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_1379(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_fcall f_1379(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1379,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_u_i_memq(t4,((C_word*)t0)[9]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 208  move */
t17=t1;
t18=t5;
t19=t3;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t5=t1;
t6=t2;
/* lolevel.scm: 173  ##sys#error-hook */
t7=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[9],t6);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_u_i_memq(t4,((C_word*)t0)[9]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 212  move */
t17=t1;
t18=t2;
t19=t5;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t5=t1;
t6=t3;
/* lolevel.scm: 173  ##sys#error-hook */
t7=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[9],t6);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=t2;
t6=(C_word)C_i_safe_pointerp(t5);
if(C_truep(t6)){
t7=t4;
f_1448(t7,t6);}
else{
t7=(C_word)C_locativep(t5);
t8=t4;
f_1448(t8,t7);}}}}

/* k1446 in move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_fcall f_1448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1448,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[8];
t4=(C_word)C_i_safe_pointerp(t3);
if(C_truep(t4)){
t5=t2;
f_1464(t5,t4);}
else{
t5=(C_word)C_locativep(t3);
t6=t2;
f_1464(t6,t5);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm: 221  ##sys#bytevector? */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}}

/* k1511 in k1446 in move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1513,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1535,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=((C_word*)t0)[7];
t6=(C_word)C_i_safe_pointerp(t5);
if(C_truep(t6)){
t7=t4;
f_1535(t7,t6);}
else{
t7=(C_word)C_locativep(t5);
t8=t4;
f_1535(t8,t7);}}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
/* lolevel.scm: 173  ##sys#error-hook */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[9],t4);}}

/* k1533 in k1511 in k1446 in move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_fcall f_1535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1535,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[5];
if(C_truep(t3)){
/* lolevel.scm: 224  checkn1 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1322(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
/* lolevel.scm: 224  checkn1 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1322(t4,t2,((C_word*)t0)[3],((C_word*)t0)[3],((C_word*)t0)[6]);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm: 225  ##sys#bytevector? */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}}

/* k1550 in k1533 in k1511 in k1446 in move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1562,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[4];
t5=(C_truep(t4)?t4:((C_word*)t0)[3]);
t6=(C_word)C_block_size(((C_word*)t0)[9]);
/* lolevel.scm: 226  checkn2 */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1338(t7,t3,t5,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
/* lolevel.scm: 173  ##sys#error-hook */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[9],t4);}}

/* k1560 in k1550 in k1533 in k1511 in k1446 in move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?t3:C_SCHEME_FALSE);
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_truep(t4)?(C_word)stub151(C_SCHEME_UNDEFINED,t7,t4,t1,t5,t6):(C_word)stub151(C_SCHEME_UNDEFINED,t7,C_SCHEME_FALSE,t1,t5,t6)));}

/* k1540 in k1533 in k1511 in k1446 in move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_truep(t4)?(C_word)stub119(C_SCHEME_UNDEFINED,t7,t4,t1,t5,t6):(C_word)stub119(C_SCHEME_UNDEFINED,t7,C_SCHEME_FALSE,t1,t5,t6)));}

/* k1462 in k1446 in move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_fcall f_1464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1464,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_1471(2,t4,t2);}
else{
/* lolevel.scm: 216  nosizerr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1310(t4,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1480,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm: 217  ##sys#bytevector? */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}}

/* k1478 in k1462 in k1446 in move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1490,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1494,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=(C_word)C_block_size(((C_word*)t0)[9]);
/* lolevel.scm: 218  checkn1 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_1322(t7,t3,t4,t6,((C_word*)t0)[6]);}
else{
/* lolevel.scm: 218  nosizerr */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1310(t6,t5);}}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
/* lolevel.scm: 173  ##sys#error-hook */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[9],t4);}}

/* k1492 in k1478 in k1462 in k1446 in move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 218  checkn1 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1322(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k1488 in k1478 in k1462 in k1446 in move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?t3:C_SCHEME_FALSE);
if(C_truep(t4)){
t8=(C_word)C_i_foreign_pointer_argumentp(t4);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub135(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}
else{
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub135(C_SCHEME_UNDEFINED,t7,C_SCHEME_FALSE,t1,t5,t6));}}

/* k1469 in k1462 in k1446 in move in k1372 in k1369 in k1366 in k1363 in body181 in move-memory! in k1086 in k1083 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t8=(C_word)C_i_foreign_pointer_argumentp(t4);
t9=t2;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)stub103(C_SCHEME_UNDEFINED,t7,t8,t1,t5,t6));}
else{
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub103(C_SCHEME_UNDEFINED,t7,C_SCHEME_FALSE,t1,t5,t6));}}

/* checkn2 in body181 in move-memory! in k1086 in k1083 */
static void C_fcall f_1338(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1338,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1345,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_u_fixnum_difference(t3,t5);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t8))){
t9=(C_word)C_u_fixnum_difference(t4,t6);
t10=t7;
f_1345(t10,(C_word)C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_1345(t9,C_SCHEME_FALSE);}}

/* k1343 in checkn2 in body181 in move-memory! in k1086 in k1083 */
static void C_fcall f_1345(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1345,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* lolevel.scm: 195  sizerr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1316(t2,((C_word*)t0)[5],(C_word)C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* checkn1 in body181 in move-memory! in k1086 in k1083 */
static void C_fcall f_1322(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1322,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_difference(t3,t4);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t5))){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* lolevel.scm: 190  sizerr */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1316(t6,t1,(C_word)C_a_i_list(&a,2,t2,t3));}}

/* sizerr in body181 in move-memory! in k1086 in k1083 */
static void C_fcall f_1316(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1316,NULL,3,t0,t1,t2);}
C_apply(8,0,t1,*((C_word*)lf[10]+1),lf[9],lf[12],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* nosizerr in body181 in move-memory! in k1086 in k1083 */
static void C_fcall f_1310(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1310,NULL,2,t0,t1);}
/* lolevel.scm: 182  ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[9],lf[11],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#check-pointer in k1086 in k1083 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1224r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1224r(t0,t1,t2,t3);}}

static void C_ccall f_1224r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=t2;
if(C_truep((C_word)C_i_safe_pointerp(t4))){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_word)C_notvemptyp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* lolevel.scm: 140  ##sys#error-hook */
t6=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),t5,lf[7],t2);}
else{
/* lolevel.scm: 140  ##sys#error-hook */
t5=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),C_SCHEME_FALSE,lf[7],t2);}}}

/* ##sys#check-generic-structure in k1086 in k1083 */
static void C_fcall f_1163(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1163,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1175,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
if(C_truep((C_word)C_blockp(t5))){
t6=(C_word)C_structurep(t5);
t7=t4;
f_1175(t7,t6);}
else{
t6=t4;
f_1175(t6,C_SCHEME_FALSE);}}

/* k1173 in ##sys#check-generic-structure in k1086 in k1083 */
static void C_fcall f_1175(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* lolevel.scm: 126  ##sys#signal-hook */
t3=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[4],t2,lf[5],((C_word*)t0)[2]);}
else{
/* lolevel.scm: 126  ##sys#signal-hook */
t2=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[4],C_SCHEME_FALSE,lf[5],((C_word*)t0)[2]);}}}

/* ##sys#check-block in k1086 in k1083 */
static void C_fcall f_1090(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1090,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
/* lolevel.scm: 105  ##sys#error-hook */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),t4,t2);}
else{
/* lolevel.scm: 105  ##sys#error-hook */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),C_SCHEME_FALSE,t2);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[218] = {
{"toplevel:lolevel_scm",(void*)C_lolevel_toplevel},
{"f_1085:lolevel_scm",(void*)f_1085},
{"f_1088:lolevel_scm",(void*)f_1088},
{"f_2015:lolevel_scm",(void*)f_2015},
{"f_3192:lolevel_scm",(void*)f_3192},
{"f_2108:lolevel_scm",(void*)f_2108},
{"f_3182:lolevel_scm",(void*)f_3182},
{"f_2112:lolevel_scm",(void*)f_2112},
{"f_3172:lolevel_scm",(void*)f_3172},
{"f_2116:lolevel_scm",(void*)f_2116},
{"f_3162:lolevel_scm",(void*)f_3162},
{"f_2120:lolevel_scm",(void*)f_2120},
{"f_3152:lolevel_scm",(void*)f_3152},
{"f_2124:lolevel_scm",(void*)f_2124},
{"f_3142:lolevel_scm",(void*)f_3142},
{"f_2128:lolevel_scm",(void*)f_2128},
{"f_3132:lolevel_scm",(void*)f_3132},
{"f_2132:lolevel_scm",(void*)f_2132},
{"f_3122:lolevel_scm",(void*)f_3122},
{"f_2136:lolevel_scm",(void*)f_2136},
{"f_2270:lolevel_scm",(void*)f_2270},
{"f_3098:lolevel_scm",(void*)f_3098},
{"f_3102:lolevel_scm",(void*)f_3102},
{"f_3105:lolevel_scm",(void*)f_3105},
{"f_2402:lolevel_scm",(void*)f_2402},
{"f_3085:lolevel_scm",(void*)f_3085},
{"f_3076:lolevel_scm",(void*)f_3076},
{"f_3067:lolevel_scm",(void*)f_3067},
{"f_3061:lolevel_scm",(void*)f_3061},
{"f_3030:lolevel_scm",(void*)f_3030},
{"f_3034:lolevel_scm",(void*)f_3034},
{"f_3037:lolevel_scm",(void*)f_3037},
{"f_3044:lolevel_scm",(void*)f_3044},
{"f_3059:lolevel_scm",(void*)f_3059},
{"f_3047:lolevel_scm",(void*)f_3047},
{"f_3021:lolevel_scm",(void*)f_3021},
{"f_1118:lolevel_scm",(void*)f_1118},
{"f_1140:lolevel_scm",(void*)f_1140},
{"f_1143:lolevel_scm",(void*)f_1143},
{"f_3025:lolevel_scm",(void*)f_3025},
{"f_2899:lolevel_scm",(void*)f_2899},
{"f_2906:lolevel_scm",(void*)f_2906},
{"f_2911:lolevel_scm",(void*)f_2911},
{"f_2927:lolevel_scm",(void*)f_2927},
{"f_2970:lolevel_scm",(void*)f_2970},
{"f_2973:lolevel_scm",(void*)f_2973},
{"f_2982:lolevel_scm",(void*)f_2982},
{"f_3003:lolevel_scm",(void*)f_3003},
{"f_2976:lolevel_scm",(void*)f_2976},
{"f_2956:lolevel_scm",(void*)f_2956},
{"f_2959:lolevel_scm",(void*)f_2959},
{"f_2940:lolevel_scm",(void*)f_2940},
{"f_2943:lolevel_scm",(void*)f_2943},
{"f_2815:lolevel_scm",(void*)f_2815},
{"f_2819:lolevel_scm",(void*)f_2819},
{"f_2824:lolevel_scm",(void*)f_2824},
{"f_2837:lolevel_scm",(void*)f_2837},
{"f_2894:lolevel_scm",(void*)f_2894},
{"f_2843:lolevel_scm",(void*)f_2843},
{"f_2846:lolevel_scm",(void*)f_2846},
{"f_2856:lolevel_scm",(void*)f_2856},
{"f_2858:lolevel_scm",(void*)f_2858},
{"f_2880:lolevel_scm",(void*)f_2880},
{"f_2849:lolevel_scm",(void*)f_2849},
{"f_2723:lolevel_scm",(void*)f_2723},
{"f_2732:lolevel_scm",(void*)f_2732},
{"f_2777:lolevel_scm",(void*)f_2777},
{"f_2787:lolevel_scm",(void*)f_2787},
{"f3610:lolevel_scm",(void*)f3610},
{"f_2761:lolevel_scm",(void*)f_2761},
{"f_2768:lolevel_scm",(void*)f_2768},
{"f_2805:lolevel_scm",(void*)f_2805},
{"f_2559:lolevel_scm",(void*)f_2559},
{"f_2563:lolevel_scm",(void*)f_2563},
{"f_2566:lolevel_scm",(void*)f_2566},
{"f_2712:lolevel_scm",(void*)f_2712},
{"f_2569:lolevel_scm",(void*)f_2569},
{"f_2572:lolevel_scm",(void*)f_2572},
{"f_2580:lolevel_scm",(void*)f_2580},
{"f_2590:lolevel_scm",(void*)f_2590},
{"f_2705:lolevel_scm",(void*)f_2705},
{"f_2599:lolevel_scm",(void*)f_2599},
{"f_2693:lolevel_scm",(void*)f_2693},
{"f_2697:lolevel_scm",(void*)f_2697},
{"f_2689:lolevel_scm",(void*)f_2689},
{"f_2602:lolevel_scm",(void*)f_2602},
{"f_2605:lolevel_scm",(void*)f_2605},
{"f_2662:lolevel_scm",(void*)f_2662},
{"f_2608:lolevel_scm",(void*)f_2608},
{"f_2611:lolevel_scm",(void*)f_2611},
{"f_2621:lolevel_scm",(void*)f_2621},
{"f_2623:lolevel_scm",(void*)f_2623},
{"f_2644:lolevel_scm",(void*)f_2644},
{"f_2614:lolevel_scm",(void*)f_2614},
{"f_2575:lolevel_scm",(void*)f_2575},
{"f_2445:lolevel_scm",(void*)f_2445},
{"f_2452:lolevel_scm",(void*)f_2452},
{"f_2455:lolevel_scm",(void*)f_2455},
{"f_2460:lolevel_scm",(void*)f_2460},
{"f_2470:lolevel_scm",(void*)f_2470},
{"f_2479:lolevel_scm",(void*)f_2479},
{"f_2483:lolevel_scm",(void*)f_2483},
{"f_2486:lolevel_scm",(void*)f_2486},
{"f_2489:lolevel_scm",(void*)f_2489},
{"f_2499:lolevel_scm",(void*)f_2499},
{"f_2501:lolevel_scm",(void*)f_2501},
{"f_2522:lolevel_scm",(void*)f_2522},
{"f_2492:lolevel_scm",(void*)f_2492},
{"f_2556:lolevel_scm",(void*)f_2556},
{"f_2442:lolevel_scm",(void*)f_2442},
{"f_2404:lolevel_scm",(void*)f_2404},
{"f_2408:lolevel_scm",(void*)f_2408},
{"f_2414:lolevel_scm",(void*)f_2414},
{"f_2419:lolevel_scm",(void*)f_2419},
{"f_2376:lolevel_scm",(void*)f_2376},
{"f_2380:lolevel_scm",(void*)f_2380},
{"f_2383:lolevel_scm",(void*)f_2383},
{"f_2363:lolevel_scm",(void*)f_2363},
{"f_2367:lolevel_scm",(void*)f_2367},
{"f_2354:lolevel_scm",(void*)f_2354},
{"f_2358:lolevel_scm",(void*)f_2358},
{"f_2312:lolevel_scm",(void*)f_2312},
{"f_2327:lolevel_scm",(void*)f_2327},
{"f_2303:lolevel_scm",(void*)f_2303},
{"f_2281:lolevel_scm",(void*)f_2281},
{"f_2272:lolevel_scm",(void*)f_2272},
{"f_1209:lolevel_scm",(void*)f_1209},
{"f_2276:lolevel_scm",(void*)f_2276},
{"f_2252:lolevel_scm",(void*)f_2252},
{"f_2256:lolevel_scm",(void*)f_2256},
{"f_2213:lolevel_scm",(void*)f_2213},
{"f_2227:lolevel_scm",(void*)f_2227},
{"f_2244:lolevel_scm",(void*)f_2244},
{"f_2177:lolevel_scm",(void*)f_2177},
{"f_2194:lolevel_scm",(void*)f_2194},
{"f_2211:lolevel_scm",(void*)f_2211},
{"f_2142:lolevel_scm",(void*)f_2142},
{"f_2146:lolevel_scm",(void*)f_2146},
{"f_2167:lolevel_scm",(void*)f_2167},
{"f_2151:lolevel_scm",(void*)f_2151},
{"f_2096:lolevel_scm",(void*)f_2096},
{"f_2086:lolevel_scm",(void*)f_2086},
{"f_2076:lolevel_scm",(void*)f_2076},
{"f_2066:lolevel_scm",(void*)f_2066},
{"f_2056:lolevel_scm",(void*)f_2056},
{"f_2046:lolevel_scm",(void*)f_2046},
{"f_2036:lolevel_scm",(void*)f_2036},
{"f_2026:lolevel_scm",(void*)f_2026},
{"f_2020:lolevel_scm",(void*)f_2020},
{"f_2017:lolevel_scm",(void*)f_2017},
{"f_2010:lolevel_scm",(void*)f_2010},
{"f_1988:lolevel_scm",(void*)f_1988},
{"f_1966:lolevel_scm",(void*)f_1966},
{"f_1943:lolevel_scm",(void*)f_1943},
{"f_1955:lolevel_scm",(void*)f_1955},
{"f_1906:lolevel_scm",(void*)f_1906},
{"f_1886:lolevel_scm",(void*)f_1886},
{"f_1890:lolevel_scm",(void*)f_1890},
{"f_1901:lolevel_scm",(void*)f_1901},
{"f_1893:lolevel_scm",(void*)f_1893},
{"f_1849:lolevel_scm",(void*)f_1849},
{"f_1870:lolevel_scm",(void*)f_1870},
{"f_1881:lolevel_scm",(void*)f_1881},
{"f_1836:lolevel_scm",(void*)f_1836},
{"f_1827:lolevel_scm",(void*)f_1827},
{"f_1831:lolevel_scm",(void*)f_1831},
{"f_1834:lolevel_scm",(void*)f_1834},
{"f_1821:lolevel_scm",(void*)f_1821},
{"f_1825:lolevel_scm",(void*)f_1825},
{"f_1810:lolevel_scm",(void*)f_1810},
{"f_1797:lolevel_scm",(void*)f_1797},
{"f_1801:lolevel_scm",(void*)f_1801},
{"f_1808:lolevel_scm",(void*)f_1808},
{"f_1787:lolevel_scm",(void*)f_1787},
{"f_1791:lolevel_scm",(void*)f_1791},
{"f_1778:lolevel_scm",(void*)f_1778},
{"f_1782:lolevel_scm",(void*)f_1782},
{"f_1767:lolevel_scm",(void*)f_1767},
{"f_1759:lolevel_scm",(void*)f_1759},
{"f_1749:lolevel_scm",(void*)f_1749},
{"f_1746:lolevel_scm",(void*)f_1746},
{"f_1665:lolevel_scm",(void*)f_1665},
{"f_1671:lolevel_scm",(void*)f_1671},
{"f_1701:lolevel_scm",(void*)f_1701},
{"f_1716:lolevel_scm",(void*)f_1716},
{"f_1737:lolevel_scm",(void*)f_1737},
{"f_1704:lolevel_scm",(void*)f_1704},
{"f_1305:lolevel_scm",(void*)f_1305},
{"f_1605:lolevel_scm",(void*)f_1605},
{"f_1600:lolevel_scm",(void*)f_1600},
{"f_1595:lolevel_scm",(void*)f_1595},
{"f_1307:lolevel_scm",(void*)f_1307},
{"f_1365:lolevel_scm",(void*)f_1365},
{"f_1368:lolevel_scm",(void*)f_1368},
{"f_1371:lolevel_scm",(void*)f_1371},
{"f_1374:lolevel_scm",(void*)f_1374},
{"f_1379:lolevel_scm",(void*)f_1379},
{"f_1448:lolevel_scm",(void*)f_1448},
{"f_1513:lolevel_scm",(void*)f_1513},
{"f_1535:lolevel_scm",(void*)f_1535},
{"f_1552:lolevel_scm",(void*)f_1552},
{"f_1562:lolevel_scm",(void*)f_1562},
{"f_1542:lolevel_scm",(void*)f_1542},
{"f_1464:lolevel_scm",(void*)f_1464},
{"f_1480:lolevel_scm",(void*)f_1480},
{"f_1494:lolevel_scm",(void*)f_1494},
{"f_1490:lolevel_scm",(void*)f_1490},
{"f_1471:lolevel_scm",(void*)f_1471},
{"f_1338:lolevel_scm",(void*)f_1338},
{"f_1345:lolevel_scm",(void*)f_1345},
{"f_1322:lolevel_scm",(void*)f_1322},
{"f_1316:lolevel_scm",(void*)f_1316},
{"f_1310:lolevel_scm",(void*)f_1310},
{"f_1224:lolevel_scm",(void*)f_1224},
{"f_1163:lolevel_scm",(void*)f_1163},
{"f_1175:lolevel_scm",(void*)f_1175},
{"f_1090:lolevel_scm",(void*)f_1090},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
