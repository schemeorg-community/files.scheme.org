/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: posixunix.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -unsafe -no-lambda-info -output-file uposixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>
#include <utime.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)      C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)       (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)      C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)    (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_do_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_test_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_unsetenv(s)      (unsetenv((char *)C_data_pointer(s)), C_SCHEME_TRUE)
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
# define C_unsetenv(s)      C_fix(putenv((char *)C_data_pointer(s)))
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

/* It is assumed that 'int' is-a 'long' */
#define C_ftell(p)          C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_num_to_int(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define cpy_tmvec_to_tmstc08(ptm, v) \
    (memset((ptm), 0, sizeof(struct tm)), \
    (ptm)->tm_sec = C_unfix(C_block_item((v), 0)), \
    (ptm)->tm_min = C_unfix(C_block_item((v), 1)), \
    (ptm)->tm_hour = C_unfix(C_block_item((v), 2)), \
    (ptm)->tm_mday = C_unfix(C_block_item((v), 3)), \
    (ptm)->tm_mon = C_unfix(C_block_item((v), 4)), \
    (ptm)->tm_year = C_unfix(C_block_item((v), 5)), \
    (ptm)->tm_wday = C_unfix(C_block_item((v), 6)), \
    (ptm)->tm_yday = C_unfix(C_block_item((v), 7)), \
    (ptm)->tm_isdst = (C_block_item((v), 8) != C_SCHEME_FALSE))

#define cpy_tmvec_to_tmstc9(ptm, v) \
    (((struct tm *)ptm)->tm_gmtoff = C_unfix(C_block_item((v), 9)))

#define cpy_tmstc08_to_tmvec(v, ptm) \
    (C_set_block_item((v), 0, C_fix(((struct tm *)ptm)->tm_sec)), \
    C_set_block_item((v), 1, C_fix((ptm)->tm_min)), \
    C_set_block_item((v), 2, C_fix((ptm)->tm_hour)), \
    C_set_block_item((v), 3, C_fix((ptm)->tm_mday)), \
    C_set_block_item((v), 4, C_fix((ptm)->tm_mon)), \
    C_set_block_item((v), 5, C_fix((ptm)->tm_year)), \
    C_set_block_item((v), 6, C_fix((ptm)->tm_wday)), \
    C_set_block_item((v), 7, C_fix((ptm)->tm_yday)), \
    C_set_block_item((v), 8, ((ptm)->tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define cpy_tmstc9_to_tmvec(v, ptm) \
    (C_set_block_item((v), 9, C_fix((ptm)->tm_gmtoff)))

#define C_tm_set_08(v)  cpy_tmvec_to_tmstc08( &C_tm, (v) )
#define C_tm_set_9(v)   cpy_tmvec_to_tmstc9( &C_tm, (v) )

#define C_tm_get_08(v)  cpy_tmstc08_to_tmvec( (v), &C_tm )
#define C_tm_get_9(v)   cpy_tmstc9_to_tmvec( (v), &C_tm )

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  return v;
}

#else

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  C_tm_set_9( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  C_tm_get_9( v );
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_a_mktime(ptr, c, v)  C_flonum(ptr, mktime(C_tm_set(v)))
#define C_a_timegm(ptr, c, v)  C_flonum(ptr, timegm(C_tm_set(v)))

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#ifdef __linux__
extern char *strptime(const char *s, const char *format, struct tm *tm);
extern pid_t getpgid(pid_t pid);
#endif

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif

static int set_file_mtime(char *filename, C_word tm)
{
  struct utimbuf tb;

  tb.actime = tb.modtime = C_num_to_int(tm);
  return utime(filename, &tb);
}


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[460];
static double C_possibly_force_alignment;


/* from k8236 in set-root-directory! in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub2249(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2249(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from sleep in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub1910(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1910(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub1907(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1907(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub1905(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1905(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub1800(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1800(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k7203 */
static C_word C_fcall stub1793(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1793(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub1788(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1788(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k7195 */
static C_word C_fcall stub1781(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1781(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from g1766 */
static C_word C_fcall stub1769(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1769(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub1752(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1752(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1692(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1692(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k6990 */
static C_word C_fcall stub1673(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1673(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from ttyname */
static C_word C_fcall stub1663(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1663(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from set-alarm! in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub1630(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1630(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from ex0 */
static C_word C_fcall stub1625(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1625(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1620(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1620(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = time(NULL);struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub1592(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub1592(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub1562(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1562(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub1556(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1556(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub1535(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1535(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k6523 */
static C_word C_fcall stub1482(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1482(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k6465 */
static C_word C_fcall stub1451(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub1451(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from get */
static C_word C_fcall stub1433(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1433(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k5152 in k5148 in file-link in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub1014(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1014(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k4866 in initialize-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub920(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub920(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from _ensure-groups */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub877(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub877(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from _get-groups */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub873(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub873(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from group-member */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub844(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub844(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a8303 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub815(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub815(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a8321 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub809(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub809(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a8339 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub803(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub803(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a8357 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub797(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub797(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k8433 in k8452 in a8424 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall stub286(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub286(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_fix((C_word)set_file_mtime(t0,t1));
return C_r;}

/* from fd_test */
static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub127(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from fd_set */
static C_word C_fcall stub121(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub121(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from fd_zero */
static C_word C_fcall stub116(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub116(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from fcntl */
static C_word C_fcall stub33(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub33(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from ##sys#file-select-one in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub26(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub26(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from ##sys#file-nonblocking! in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub22(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub22(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from strerror */
static C_word C_fcall stub12(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub12(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8425)
static void C_ccall f_8425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8454)
static void C_ccall f_8454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8435)
static void C_ccall f_8435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8441)
static void C_fcall f_8441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8419)
static void C_ccall f_8419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8423)
static void C_ccall f_8423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8382)
static void C_ccall f_8382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8398)
static void C_ccall f_8398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8386)
static void C_ccall f_8386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8389)
static void C_ccall f_8389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8376)
static void C_ccall f_8376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8371)
static void C_ccall f_8371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8358)
static void C_ccall f_8358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8343)
static void C_ccall f_8343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8353)
static void C_ccall f_8353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_ccall f_8340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8325)
static void C_ccall f_8325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8335)
static void C_ccall f_8335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8322)
static void C_ccall f_8322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8307)
static void C_ccall f_8307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8317)
static void C_ccall f_8317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8304)
static void C_ccall f_8304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8283)
static void C_ccall f_8283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8299)
static void C_ccall f_8299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8272)
static void C_ccall f_8272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8242)
static void C_ccall f_8242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8238)
static void C_ccall f_8238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8252)
static void C_fcall f_8252(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8167)
static void C_fcall f_8167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8173)
static void C_ccall f_8173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8162)
static void C_fcall f_8162(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8157)
static void C_fcall f_8157(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7992)
static void C_fcall f_7992(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8144)
static void C_ccall f_8144(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8152)
static void C_ccall f_8152(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7999)
static void C_fcall f_7999(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8132)
static void C_ccall f_8132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8126)
static void C_ccall f_8126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8009)
static void C_ccall f_8009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8011)
static void C_fcall f_8011(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8030)
static void C_ccall f_8030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8112)
static void C_ccall f_8112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8119)
static void C_ccall f_8119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8106)
static void C_ccall f_8106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8045)
static void C_ccall f_8045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8099)
static void C_ccall f_8099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8096)
static void C_ccall f_8096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8062)
static void C_ccall f_8062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8084)
static void C_ccall f_8084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8070)
static void C_ccall f_8070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8077)
static void C_ccall f_8077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8074)
static void C_ccall f_8074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8057)
static void C_ccall f_8057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8055)
static void C_ccall f_8055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7933)
static void C_ccall f_7933(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7933)
static void C_ccall f_7933r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7945)
static void C_fcall f_7945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7940)
static void C_fcall f_7940(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7935)
static void C_fcall f_7935(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7876)
static void C_ccall f_7876r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7888)
static void C_fcall f_7888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7883)
static void C_fcall f_7883(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7878)
static void C_fcall f_7878(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7815)
static void C_fcall f_7815(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7870)
static void C_ccall f_7870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7874)
static void C_ccall f_7874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7836)
static void C_ccall f_7836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7850)
static void C_ccall f_7850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7844)
static void C_ccall f_7844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7817)
static void C_fcall f_7817(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7757)
static void C_ccall f_7757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7769)
static void C_ccall f_7769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7800)
static void C_ccall f_7800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7796)
static void C_ccall f_7796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7784)
static void C_ccall f_7784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7792)
static void C_ccall f_7792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7788)
static void C_ccall f_7788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7763)
static void C_ccall f_7763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7746)
static void C_fcall f_7746(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_fcall f_7735(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7690)
static void C_fcall f_7690(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7694)
static void C_ccall f_7694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7697)
static void C_ccall f_7697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7700)
static void C_ccall f_7700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7707)
static void C_fcall f_7707(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7713)
static void C_ccall f_7713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7720)
static void C_ccall f_7720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7723)
static void C_ccall f_7723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7657)
static void C_fcall f_7657(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7670)
static void C_ccall f_7670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7582)
static void C_ccall f_7582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7643)
static void C_fcall f_7643(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7656)
static void C_ccall f_7656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7623)
static void C_fcall f_7623(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7638)
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7632)
static void C_ccall f_7632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7586)
static void C_fcall f_7586(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7609)
static void C_ccall f_7609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7603)
static void C_ccall f_7603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7556)
static void C_ccall f_7556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7560)
static void C_ccall f_7560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7524)
static void C_ccall f_7524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7488)
static void C_ccall f_7488(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7488)
static void C_ccall f_7488r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7482)
static void C_ccall f_7482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7387)
static void C_ccall f_7387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7342)
static void C_fcall f_7342(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7337)
static void C_fcall f_7337(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7210)
static void C_fcall f_7210(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7220)
static void C_ccall f_7220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7228)
static void C_fcall f_7228(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7274)
static C_word C_fcall f_7274(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7241)
static void C_fcall f_7241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7266)
static void C_ccall f_7266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7244)
static void C_ccall f_7244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7200)
static C_word C_fcall f_7200(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7192)
static C_word C_fcall f_7192(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7154)
static void C_ccall f_7154(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7154)
static void C_ccall f_7154r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7179)
static void C_ccall f_7179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7046)
static void C_fcall f_7046(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7146)
static void C_ccall f_7146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_ccall f_7074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7081)
static void C_ccall f_7081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7083)
static void C_fcall f_7083(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7104)
static void C_fcall f_7104(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_ccall f_7116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7028)
static void C_ccall f_7028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7032)
static void C_ccall f_7032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6997)
static void C_ccall f_6997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7021)
static void C_ccall f_7021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6978)
static void C_ccall f_6978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6947)
static void C_fcall f_6947(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6951)
static void C_ccall f_6951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6928)
static void C_ccall f_6928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6932)
static void C_ccall f_6932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6935)
static void C_ccall f_6935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6873)
static void C_ccall f_6873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6888)
static void C_fcall f_6888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6866)
static void C_ccall f_6866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6827)
static void C_ccall f_6827(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6831)
static void C_ccall f_6831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6812)
static void C_ccall f_6812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6816)
static void C_ccall f_6816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6773)
static void C_ccall f_6773(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6773)
static void C_ccall f_6773r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6790)
static void C_ccall f_6790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6711)
static void C_ccall f_6711r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6718)
static void C_ccall f_6718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6727)
static void C_ccall f_6727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6657)
static void C_ccall f_6657(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6657)
static void C_ccall f_6657r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6629)
static void C_ccall f_6629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6598)
static void C_ccall f_6598r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6602)
static void C_ccall f_6602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6579)
static void C_fcall f_6579(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6564)
static void C_ccall f_6564(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6542)
static void C_fcall f_6542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6484)
static void C_fcall f_6484(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6500)
static void C_ccall f_6500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static void C_fcall f_6393(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6397)
static void C_ccall f_6397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6405)
static void C_fcall f_6405(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6435)
static void C_ccall f_6435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6380)
static void C_ccall f_6380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6329)
static void C_ccall f_6329(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6293)
static void C_fcall f_6293(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6314)
static void C_ccall f_6314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6235)
static void C_ccall f_6235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6216)
static void C_ccall f_6216(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6216)
static void C_ccall f_6216r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6201)
static void C_ccall f_6201(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6201)
static void C_ccall f_6201r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6183)
static void C_fcall f_6183(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6112)
static void C_fcall f_6112(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6131)
static void C_ccall f_6131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_fcall f_6137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6073)
static void C_ccall f_6073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6101)
static void C_ccall f_6101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6097)
static void C_ccall f_6097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6083)
static void C_fcall f_6083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6013)
static void C_fcall f_6013(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6008)
static void C_fcall f_6008(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6003)
static void C_fcall f_6003(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5819)
static void C_fcall f_5819(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5947)
static void C_fcall f_5947(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5915)
static void C_ccall f_5915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5871)
static void C_fcall f_5871(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5907)
static void C_ccall f_5907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5896)
static void C_ccall f_5896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5875)
static void C_ccall f_5875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5825)
static void C_fcall f_5825(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5860)
static void C_ccall f_5860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5742)
static void C_fcall f_5742(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5737)
static void C_fcall f_5737(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5732)
static void C_fcall f_5732(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5727)
static void C_fcall f_5727(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5340)
static void C_fcall f_5340(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5350)
static void C_ccall f_5350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5600)
static void C_ccall f_5600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5606)
static void C_fcall f_5606(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5658)
static void C_ccall f_5658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5615)
static void C_ccall f_5615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5532)
static void C_fcall f_5532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_fcall f_5534(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5482)
static void C_ccall f_5482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_fcall f_5382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_fcall f_5394(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_ccall f_5431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5374)
static C_word C_fcall f_5374(C_word t0);
C_noret_decl(f_5351)
static void C_fcall f_5351(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5318)
static void C_fcall f_5318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5288)
static void C_ccall f_5288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_fcall f_5223(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_fcall f_5186(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5150)
static void C_ccall f_5150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_fcall f_5174(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5131)
static void C_ccall f_5131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_ccall f_5054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_ccall f_5029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4993)
static void C_fcall f_4993(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4957)
static void C_ccall f_4957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_fcall f_4885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_ccall f_4806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4815)
static void C_fcall f_4815(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_ccall f_4753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_fcall f_4758(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_fcall f_4672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_fcall f_4695(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_fcall f_4578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4591)
static void C_ccall f_4591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4603)
static void C_ccall f_4603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4528)
static void C_ccall f_4528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4544)
static void C_ccall f_4544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_fcall f_4452(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4418)
static C_word C_fcall f_4418(C_word t0);
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4151)
static void C_ccall f_4151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_fcall f_4122(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3787)
static void C_ccall f_3787(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3914)
static void C_fcall f_3914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_fcall f_3933(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_fcall f_3977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3943)
static void C_ccall f_3943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3801)
static void C_ccall f_3801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_fcall f_3803(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3810)
static void C_ccall f_3810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_fcall f_3731(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3746)
static void C_ccall f_3746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3599)
static void C_fcall f_3599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_fcall f_3594(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3496)
static void C_fcall f_3496(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_ccall f_3513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_fcall f_3527(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_fcall f_3549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_fcall f_3317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_fcall f_3329(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_fcall f_3336(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3255)
static void C_ccall f_3255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_fcall f_3086(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3045)
static void C_fcall f_3045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3053)
static C_word C_fcall f_3053(C_word t0,C_word t1);
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_fcall f_2997(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3005)
static C_word C_fcall f_3005(C_word t0,C_word t1);
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_fcall f_2831(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_fcall f_2935(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2943)
static C_word C_fcall f_2943(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_fcall f_2870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_fcall f_2888(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2896)
static C_word C_fcall f_2896(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8441)
static void C_fcall trf_8441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8441(t0,t1);}

C_noret_decl(trf_8252)
static void C_fcall trf_8252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8252(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8252(t0,t1);}

C_noret_decl(trf_8167)
static void C_fcall trf_8167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8167(t0,t1);}

C_noret_decl(trf_8162)
static void C_fcall trf_8162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8162(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8162(t0,t1,t2);}

C_noret_decl(trf_8157)
static void C_fcall trf_8157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8157(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8157(t0,t1,t2,t3);}

C_noret_decl(trf_7992)
static void C_fcall trf_7992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7992(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7992(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7999)
static void C_fcall trf_7999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7999(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7999(t0,t1);}

C_noret_decl(trf_8011)
static void C_fcall trf_8011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8011(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8011(t0,t1,t2,t3);}

C_noret_decl(trf_7945)
static void C_fcall trf_7945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7945(t0,t1);}

C_noret_decl(trf_7940)
static void C_fcall trf_7940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7940(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7940(t0,t1,t2);}

C_noret_decl(trf_7935)
static void C_fcall trf_7935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7935(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7935(t0,t1,t2,t3);}

C_noret_decl(trf_7888)
static void C_fcall trf_7888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7888(t0,t1);}

C_noret_decl(trf_7883)
static void C_fcall trf_7883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7883(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7883(t0,t1,t2);}

C_noret_decl(trf_7878)
static void C_fcall trf_7878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7878(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7878(t0,t1,t2,t3);}

C_noret_decl(trf_7815)
static void C_fcall trf_7815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7815(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7815(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7817)
static void C_fcall trf_7817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7817(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7817(t0,t1,t2);}

C_noret_decl(trf_7746)
static void C_fcall trf_7746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7746(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7746(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7735)
static void C_fcall trf_7735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7735(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7735(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7690)
static void C_fcall trf_7690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7690(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7690(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7707)
static void C_fcall trf_7707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7707(t0,t1);}

C_noret_decl(trf_7657)
static void C_fcall trf_7657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7657(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7657(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7643)
static void C_fcall trf_7643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7643(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7643(t0,t1,t2,t3);}

C_noret_decl(trf_7623)
static void C_fcall trf_7623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7623(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7623(t0,t1,t2);}

C_noret_decl(trf_7586)
static void C_fcall trf_7586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7586(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_7586(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_7342)
static void C_fcall trf_7342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7342(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7342(t0,t1);}

C_noret_decl(trf_7337)
static void C_fcall trf_7337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7337(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7337(t0,t1,t2);}

C_noret_decl(trf_7210)
static void C_fcall trf_7210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7210(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7210(t0,t1,t2,t3);}

C_noret_decl(trf_7228)
static void C_fcall trf_7228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7228(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7228(t0,t1,t2,t3);}

C_noret_decl(trf_7241)
static void C_fcall trf_7241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7241(t0,t1);}

C_noret_decl(trf_7046)
static void C_fcall trf_7046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7046(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7046(t0,t1,t2);}

C_noret_decl(trf_7083)
static void C_fcall trf_7083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7083(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7083(t0,t1,t2);}

C_noret_decl(trf_7104)
static void C_fcall trf_7104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7104(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7104(t0,t1,t2);}

C_noret_decl(trf_6947)
static void C_fcall trf_6947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6947(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6947(t0,t1,t2);}

C_noret_decl(trf_6888)
static void C_fcall trf_6888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6888(t0,t1);}

C_noret_decl(trf_6579)
static void C_fcall trf_6579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6579(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6579(t0,t1,t2);}

C_noret_decl(trf_6542)
static void C_fcall trf_6542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6542(t0,t1);}

C_noret_decl(trf_6484)
static void C_fcall trf_6484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6484(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6484(t0,t1);}

C_noret_decl(trf_6393)
static void C_fcall trf_6393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6393(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6393(t0,t1,t2);}

C_noret_decl(trf_6405)
static void C_fcall trf_6405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6405(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6405(t0,t1,t2);}

C_noret_decl(trf_6293)
static void C_fcall trf_6293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6293(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6293(t0,t1);}

C_noret_decl(trf_6183)
static void C_fcall trf_6183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6183(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6183(t0,t1,t2,t3);}

C_noret_decl(trf_6112)
static void C_fcall trf_6112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6112(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6112(t0,t1,t2,t3);}

C_noret_decl(trf_6137)
static void C_fcall trf_6137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6137(t0,t1);}

C_noret_decl(trf_6083)
static void C_fcall trf_6083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6083(t0,t1);}

C_noret_decl(trf_6013)
static void C_fcall trf_6013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6013(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6013(t0,t1);}

C_noret_decl(trf_6008)
static void C_fcall trf_6008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6008(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6008(t0,t1,t2);}

C_noret_decl(trf_6003)
static void C_fcall trf_6003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6003(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6003(t0,t1,t2,t3);}

C_noret_decl(trf_5819)
static void C_fcall trf_5819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5819(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5819(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5947)
static void C_fcall trf_5947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5947(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5947(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5871)
static void C_fcall trf_5871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5871(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5871(t0,t1);}

C_noret_decl(trf_5825)
static void C_fcall trf_5825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5825(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5825(t0,t1,t2,t3);}

C_noret_decl(trf_5742)
static void C_fcall trf_5742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5742(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5742(t0,t1);}

C_noret_decl(trf_5737)
static void C_fcall trf_5737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5737(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5737(t0,t1,t2);}

C_noret_decl(trf_5732)
static void C_fcall trf_5732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5732(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5732(t0,t1,t2,t3);}

C_noret_decl(trf_5727)
static void C_fcall trf_5727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5727(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5727(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5340)
static void C_fcall trf_5340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5340(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5340(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5606)
static void C_fcall trf_5606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5606(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5606(t0,t1,t2);}

C_noret_decl(trf_5532)
static void C_fcall trf_5532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5532(t0,t1);}

C_noret_decl(trf_5534)
static void C_fcall trf_5534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5534(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5534(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5382)
static void C_fcall trf_5382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5382(t0,t1);}

C_noret_decl(trf_5394)
static void C_fcall trf_5394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5394(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5394(t0,t1);}

C_noret_decl(trf_5351)
static void C_fcall trf_5351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5351(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5351(t0,t1);}

C_noret_decl(trf_5318)
static void C_fcall trf_5318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5318(t0,t1);}

C_noret_decl(trf_5223)
static void C_fcall trf_5223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5223(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5223(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5186)
static void C_fcall trf_5186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5186(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5186(t0,t1,t2);}

C_noret_decl(trf_5174)
static void C_fcall trf_5174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5174(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5174(t0,t1);}

C_noret_decl(trf_4993)
static void C_fcall trf_4993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4993(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4993(t0,t1,t2,t3);}

C_noret_decl(trf_4885)
static void C_fcall trf_4885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4885(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4885(t0,t1);}

C_noret_decl(trf_4815)
static void C_fcall trf_4815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4815(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4815(t0,t1,t2,t3);}

C_noret_decl(trf_4758)
static void C_fcall trf_4758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4758(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4758(t0,t1,t2);}

C_noret_decl(trf_4672)
static void C_fcall trf_4672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4672(t0,t1);}

C_noret_decl(trf_4695)
static void C_fcall trf_4695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4695(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4695(t0,t1,t2);}

C_noret_decl(trf_4578)
static void C_fcall trf_4578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4578(t0,t1);}

C_noret_decl(trf_4452)
static void C_fcall trf_4452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4452(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4452(t0,t1,t2,t3);}

C_noret_decl(trf_4122)
static void C_fcall trf_4122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4122(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4122(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3914)
static void C_fcall trf_3914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3914(t0,t1);}

C_noret_decl(trf_3933)
static void C_fcall trf_3933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3933(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3933(t0,t1);}

C_noret_decl(trf_3977)
static void C_fcall trf_3977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3977(t0,t1);}

C_noret_decl(trf_3803)
static void C_fcall trf_3803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3803(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3803(t0,t1,t2,t3);}

C_noret_decl(trf_3731)
static void C_fcall trf_3731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3731(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3731(t0,t1);}

C_noret_decl(trf_3599)
static void C_fcall trf_3599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3599(t0,t1);}

C_noret_decl(trf_3594)
static void C_fcall trf_3594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3594(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3594(t0,t1,t2);}

C_noret_decl(trf_3496)
static void C_fcall trf_3496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3496(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3496(t0,t1,t2,t3);}

C_noret_decl(trf_3527)
static void C_fcall trf_3527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3527(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3527(t0,t1);}

C_noret_decl(trf_3549)
static void C_fcall trf_3549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3549(t0,t1);}

C_noret_decl(trf_3317)
static void C_fcall trf_3317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3317(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3317(t0,t1);}

C_noret_decl(trf_3329)
static void C_fcall trf_3329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3329(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3329(t0,t1,t2);}

C_noret_decl(trf_3336)
static void C_fcall trf_3336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3336(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3336(t0,t1);}

C_noret_decl(trf_3086)
static void C_fcall trf_3086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3086(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3086(t0,t1,t2,t3);}

C_noret_decl(trf_3045)
static void C_fcall trf_3045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3045(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3045(t0,t1,t2);}

C_noret_decl(trf_2997)
static void C_fcall trf_2997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2997(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2997(t0,t1,t2);}

C_noret_decl(trf_2831)
static void C_fcall trf_2831(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2831(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2831(t0,t1);}

C_noret_decl(trf_2935)
static void C_fcall trf_2935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2935(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2935(t0,t1,t2);}

C_noret_decl(trf_2870)
static void C_fcall trf_2870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2870(t0,t1);}

C_noret_decl(trf_2888)
static void C_fcall trf_2888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2888(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2888(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3348)){
C_save(t1);
C_rereclaim2(3348*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,460);
lf[0]=C_h_intern(&lf[0],13,"string-append");
lf[2]=C_h_intern(&lf[2],15,"\003syssignal-hook");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[4]=C_h_intern(&lf[4],17,"\003syspeek-c-string");
lf[5]=C_h_intern(&lf[5],16,"\003sysupdate-errno");
lf[6]=C_h_intern(&lf[6],15,"\003sysposix-error");
lf[7]=C_h_intern(&lf[7],21,"\003sysfile-nonblocking!");
lf[8]=C_h_intern(&lf[8],19,"\003sysfile-select-one");
lf[9]=C_h_intern(&lf[9],8,"pipe/buf");
lf[10]=C_h_intern(&lf[10],11,"fcntl/dupfd");
lf[11]=C_h_intern(&lf[11],11,"fcntl/getfd");
lf[12]=C_h_intern(&lf[12],11,"fcntl/setfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfl");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfl");
lf[15]=C_h_intern(&lf[15],11,"open/rdonly");
lf[16]=C_h_intern(&lf[16],11,"open/wronly");
lf[17]=C_h_intern(&lf[17],9,"open/rdwr");
lf[18]=C_h_intern(&lf[18],9,"open/read");
lf[19]=C_h_intern(&lf[19],10,"open/write");
lf[20]=C_h_intern(&lf[20],10,"open/creat");
lf[21]=C_h_intern(&lf[21],11,"open/append");
lf[22]=C_h_intern(&lf[22],9,"open/excl");
lf[23]=C_h_intern(&lf[23],11,"open/noctty");
lf[24]=C_h_intern(&lf[24],13,"open/nonblock");
lf[25]=C_h_intern(&lf[25],10,"open/trunc");
lf[26]=C_h_intern(&lf[26],9,"open/sync");
lf[27]=C_h_intern(&lf[27],10,"open/fsync");
lf[28]=C_h_intern(&lf[28],11,"open/binary");
lf[29]=C_h_intern(&lf[29],9,"open/text");
lf[30]=C_h_intern(&lf[30],10,"perm/irusr");
lf[31]=C_h_intern(&lf[31],10,"perm/iwusr");
lf[32]=C_h_intern(&lf[32],10,"perm/ixusr");
lf[33]=C_h_intern(&lf[33],10,"perm/irgrp");
lf[34]=C_h_intern(&lf[34],10,"perm/iwgrp");
lf[35]=C_h_intern(&lf[35],10,"perm/ixgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iroth");
lf[37]=C_h_intern(&lf[37],10,"perm/iwoth");
lf[38]=C_h_intern(&lf[38],10,"perm/ixoth");
lf[39]=C_h_intern(&lf[39],10,"perm/irwxu");
lf[40]=C_h_intern(&lf[40],10,"perm/irwxg");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxo");
lf[42]=C_h_intern(&lf[42],10,"perm/isvtx");
lf[43]=C_h_intern(&lf[43],10,"perm/isuid");
lf[44]=C_h_intern(&lf[44],10,"perm/isgid");
lf[45]=C_h_intern(&lf[45],12,"file-control");
lf[46]=C_h_intern(&lf[46],11,"\000file-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[48]=C_h_intern(&lf[48],9,"file-open");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[50]=C_h_intern(&lf[50],17,"\003sysmake-c-string");
lf[51]=C_h_intern(&lf[51],20,"\003sysexpand-home-path");
lf[52]=C_h_intern(&lf[52],10,"file-close");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[54]=C_h_intern(&lf[54],11,"make-string");
lf[55]=C_h_intern(&lf[55],9,"file-read");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[57]=C_h_intern(&lf[57],11,"\000type-error");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[59]=C_h_intern(&lf[59],10,"file-write");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],12,"file-mkstemp");
lf[63]=C_h_intern(&lf[63],13,"\003syssubstring");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[65]=C_h_intern(&lf[65],11,"file-select");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[67]=C_h_intern(&lf[67],8,"seek/set");
lf[68]=C_h_intern(&lf[68],8,"seek/end");
lf[69]=C_h_intern(&lf[69],8,"seek/cur");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[73]=C_h_intern(&lf[73],9,"file-stat");
lf[74]=C_h_intern(&lf[74],9,"file-size");
lf[75]=C_h_intern(&lf[75],22,"file-modification-time");
lf[76]=C_h_intern(&lf[76],16,"file-access-time");
lf[77]=C_h_intern(&lf[77],16,"file-change-time");
lf[78]=C_h_intern(&lf[78],10,"file-owner");
lf[79]=C_h_intern(&lf[79],16,"file-permissions");
lf[80]=C_h_intern(&lf[80],13,"regular-file\077");
lf[81]=C_h_intern(&lf[81],14,"symbolic-link\077");
lf[82]=C_h_intern(&lf[82],17,"character-device\077");
lf[83]=C_h_intern(&lf[83],13,"block-device\077");
lf[84]=C_h_intern(&lf[84],5,"fifo\077");
lf[85]=C_h_intern(&lf[85],10,"stat-fifo\077");
lf[86]=C_h_intern(&lf[86],7,"socket\077");
lf[87]=C_h_intern(&lf[87],18,"set-file-position!");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[89]=C_h_intern(&lf[89],6,"stream");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[91]=C_h_intern(&lf[91],5,"port\077");
lf[92]=C_h_intern(&lf[92],13,"\000bounds-error");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[94]=C_h_intern(&lf[94],13,"file-position");
lf[95]=C_h_intern(&lf[95],18,"decompose-pathname");
lf[96]=C_h_intern(&lf[96],18,"pathname-directory");
lf[97]=C_h_intern(&lf[97],16,"create-directory");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[99]=C_h_intern(&lf[99],13,"make-pathname");
lf[100]=C_h_intern(&lf[100],16,"change-directory");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[102]=C_h_intern(&lf[102],16,"delete-directory");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[104]=C_h_intern(&lf[104],10,"string-ref");
lf[105]=C_h_intern(&lf[105],6,"string");
lf[106]=C_h_intern(&lf[106],9,"directory");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[108]=C_h_intern(&lf[108],16,"\003sysmake-pointer");
lf[109]=C_h_intern(&lf[109],17,"current-directory");
lf[110]=C_h_intern(&lf[110],10,"directory\077");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[112]=C_h_intern(&lf[112],5,"null\077");
lf[113]=C_h_intern(&lf[113],6,"char=\077");
lf[114]=C_h_intern(&lf[114],8,"string=\077");
lf[115]=C_h_intern(&lf[115],16,"char-alphabetic\077");
lf[116]=C_h_intern(&lf[116],24,"get-environment-variable");
lf[117]=C_h_intern(&lf[117],17,"current-user-name");
lf[118]=C_h_intern(&lf[118],9,"condition");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[120]=C_h_intern(&lf[120],22,"with-exception-handler");
lf[121]=C_h_intern(&lf[121],30,"call-with-current-continuation");
lf[122]=C_h_intern(&lf[122],14,"canonical-path");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[125]=C_h_intern(&lf[125],18,"string-intersperse");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[128]=C_h_intern(&lf[128],7,"reverse");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[132]=C_h_intern(&lf[132],12,"string-split");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[141]=C_h_intern(&lf[141],13,"\003sysmake-port");
lf[142]=C_h_intern(&lf[142],21,"\003sysstream-port-class");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[144]=C_h_intern(&lf[144],15,"open-input-pipe");
lf[145]=C_h_intern(&lf[145],5,"\000text");
lf[146]=C_h_intern(&lf[146],7,"\000binary");
lf[147]=C_h_intern(&lf[147],9,"\003syserror");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[149]=C_h_intern(&lf[149],16,"open-output-pipe");
lf[150]=C_h_intern(&lf[150],16,"close-input-pipe");
lf[151]=C_h_intern(&lf[151],23,"close-input/output-pipe");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[153]=C_h_intern(&lf[153],14,"\003syscheck-port");
lf[154]=C_h_intern(&lf[154],17,"close-output-pipe");
lf[155]=C_h_intern(&lf[155],20,"call-with-input-pipe");
lf[156]=C_h_intern(&lf[156],21,"call-with-output-pipe");
lf[157]=C_h_intern(&lf[157],20,"with-input-from-pipe");
lf[158]=C_h_intern(&lf[158],18,"\003sysstandard-input");
lf[159]=C_h_intern(&lf[159],19,"with-output-to-pipe");
lf[160]=C_h_intern(&lf[160],19,"\003sysstandard-output");
lf[161]=C_h_intern(&lf[161],11,"create-pipe");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[163]=C_h_intern(&lf[163],11,"signal/term");
lf[164]=C_h_intern(&lf[164],11,"signal/kill");
lf[165]=C_h_intern(&lf[165],10,"signal/int");
lf[166]=C_h_intern(&lf[166],10,"signal/hup");
lf[167]=C_h_intern(&lf[167],10,"signal/fpe");
lf[168]=C_h_intern(&lf[168],10,"signal/ill");
lf[169]=C_h_intern(&lf[169],11,"signal/segv");
lf[170]=C_h_intern(&lf[170],11,"signal/abrt");
lf[171]=C_h_intern(&lf[171],11,"signal/trap");
lf[172]=C_h_intern(&lf[172],11,"signal/quit");
lf[173]=C_h_intern(&lf[173],11,"signal/alrm");
lf[174]=C_h_intern(&lf[174],13,"signal/vtalrm");
lf[175]=C_h_intern(&lf[175],11,"signal/prof");
lf[176]=C_h_intern(&lf[176],9,"signal/io");
lf[177]=C_h_intern(&lf[177],10,"signal/urg");
lf[178]=C_h_intern(&lf[178],11,"signal/chld");
lf[179]=C_h_intern(&lf[179],11,"signal/cont");
lf[180]=C_h_intern(&lf[180],11,"signal/stop");
lf[181]=C_h_intern(&lf[181],11,"signal/tstp");
lf[182]=C_h_intern(&lf[182],11,"signal/pipe");
lf[183]=C_h_intern(&lf[183],11,"signal/xcpu");
lf[184]=C_h_intern(&lf[184],11,"signal/xfsz");
lf[185]=C_h_intern(&lf[185],11,"signal/usr1");
lf[186]=C_h_intern(&lf[186],11,"signal/usr2");
lf[187]=C_h_intern(&lf[187],12,"signal/winch");
lf[188]=C_h_intern(&lf[188],12,"signals-list");
lf[189]=C_h_intern(&lf[189],18,"\003sysinterrupt-hook");
lf[190]=C_h_intern(&lf[190],14,"signal-handler");
lf[191]=C_h_intern(&lf[191],19,"set-signal-handler!");
lf[192]=C_h_intern(&lf[192],16,"set-signal-mask!");
lf[193]=C_h_intern(&lf[193],14,"\000process-error");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[195]=C_h_intern(&lf[195],11,"signal-mask");
lf[196]=C_h_intern(&lf[196],14,"signal-masked\077");
lf[197]=C_h_intern(&lf[197],12,"signal-mask!");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[199]=C_h_intern(&lf[199],14,"signal-unmask!");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[201]=C_h_intern(&lf[201],18,"system-information");
lf[202]=C_h_intern(&lf[202],25,"\003syspeek-nonnull-c-string");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[204]=C_h_intern(&lf[204],15,"current-user-id");
lf[205]=C_h_intern(&lf[205],25,"current-effective-user-id");
lf[206]=C_h_intern(&lf[206],16,"current-group-id");
lf[207]=C_h_intern(&lf[207],26,"current-effective-group-id");
lf[208]=C_h_intern(&lf[208],16,"user-information");
lf[209]=C_h_intern(&lf[209],6,"vector");
lf[210]=C_h_intern(&lf[210],4,"list");
lf[211]=C_h_intern(&lf[211],27,"current-effective-user-name");
lf[212]=C_h_intern(&lf[212],17,"group-information");
lf[213]=C_h_intern(&lf[213],10,"get-groups");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[217]=C_h_intern(&lf[217],11,"set-groups!");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[220]=C_h_intern(&lf[220],17,"initialize-groups");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[222]=C_h_intern(&lf[222],10,"errno/perm");
lf[223]=C_h_intern(&lf[223],11,"errno/noent");
lf[224]=C_h_intern(&lf[224],10,"errno/srch");
lf[225]=C_h_intern(&lf[225],10,"errno/intr");
lf[226]=C_h_intern(&lf[226],8,"errno/io");
lf[227]=C_h_intern(&lf[227],12,"errno/noexec");
lf[228]=C_h_intern(&lf[228],10,"errno/badf");
lf[229]=C_h_intern(&lf[229],11,"errno/child");
lf[230]=C_h_intern(&lf[230],11,"errno/nomem");
lf[231]=C_h_intern(&lf[231],11,"errno/acces");
lf[232]=C_h_intern(&lf[232],11,"errno/fault");
lf[233]=C_h_intern(&lf[233],10,"errno/busy");
lf[234]=C_h_intern(&lf[234],12,"errno/notdir");
lf[235]=C_h_intern(&lf[235],11,"errno/isdir");
lf[236]=C_h_intern(&lf[236],11,"errno/inval");
lf[237]=C_h_intern(&lf[237],11,"errno/mfile");
lf[238]=C_h_intern(&lf[238],11,"errno/nospc");
lf[239]=C_h_intern(&lf[239],11,"errno/spipe");
lf[240]=C_h_intern(&lf[240],10,"errno/pipe");
lf[241]=C_h_intern(&lf[241],11,"errno/again");
lf[242]=C_h_intern(&lf[242],10,"errno/rofs");
lf[243]=C_h_intern(&lf[243],11,"errno/exist");
lf[244]=C_h_intern(&lf[244],16,"errno/wouldblock");
lf[245]=C_h_intern(&lf[245],10,"errno/2big");
lf[246]=C_h_intern(&lf[246],12,"errno/deadlk");
lf[247]=C_h_intern(&lf[247],9,"errno/dom");
lf[248]=C_h_intern(&lf[248],10,"errno/fbig");
lf[249]=C_h_intern(&lf[249],11,"errno/ilseq");
lf[250]=C_h_intern(&lf[250],11,"errno/mlink");
lf[251]=C_h_intern(&lf[251],17,"errno/nametoolong");
lf[252]=C_h_intern(&lf[252],11,"errno/nfile");
lf[253]=C_h_intern(&lf[253],11,"errno/nodev");
lf[254]=C_h_intern(&lf[254],11,"errno/nolck");
lf[255]=C_h_intern(&lf[255],11,"errno/nosys");
lf[256]=C_h_intern(&lf[256],14,"errno/notempty");
lf[257]=C_h_intern(&lf[257],11,"errno/notty");
lf[258]=C_h_intern(&lf[258],10,"errno/nxio");
lf[259]=C_h_intern(&lf[259],11,"errno/range");
lf[260]=C_h_intern(&lf[260],10,"errno/xdev");
lf[261]=C_h_intern(&lf[261],16,"change-file-mode");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[263]=C_h_intern(&lf[263],17,"change-file-owner");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[265]=C_h_intern(&lf[265],17,"file-read-access\077");
lf[266]=C_h_intern(&lf[266],18,"file-write-access\077");
lf[267]=C_h_intern(&lf[267],20,"file-execute-access\077");
lf[268]=C_h_intern(&lf[268],14,"create-session");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[270]=C_h_intern(&lf[270],16,"process-group-id");
lf[271]=C_h_intern(&lf[271],20,"create-symbolic-link");
lf[272]=C_h_intern(&lf[272],18,"create-symbol-link");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[274]=C_h_intern(&lf[274],9,"substring");
lf[275]=C_h_intern(&lf[275],18,"read-symbolic-link");
lf[276]=C_h_intern(&lf[276],12,"canonicalize");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[278]=C_h_intern(&lf[278],9,"file-link");
lf[279]=C_h_intern(&lf[279],9,"hard-link");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[281]=C_h_intern(&lf[281],12,"fileno/stdin");
lf[282]=C_h_intern(&lf[282],13,"fileno/stdout");
lf[283]=C_h_intern(&lf[283],13,"fileno/stderr");
lf[284]=C_h_intern(&lf[284],7,"\000append");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[292]=C_h_intern(&lf[292],16,"open-input-file*");
lf[293]=C_h_intern(&lf[293],17,"open-output-file*");
lf[294]=C_h_intern(&lf[294],12,"port->fileno");
lf[295]=C_h_intern(&lf[295],6,"socket");
lf[296]=C_h_intern(&lf[296],20,"\003systcp-port->fileno");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[299]=C_h_intern(&lf[299],25,"\003syspeek-unsigned-integer");
lf[300]=C_h_intern(&lf[300],16,"duplicate-fileno");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[302]=C_h_intern(&lf[302],15,"make-input-port");
lf[303]=C_h_intern(&lf[303],14,"set-port-name!");
lf[304]=C_h_intern(&lf[304],21,"\003syscustom-input-port");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[306]=C_h_intern(&lf[306],17,"\003systhread-yield!");
lf[307]=C_h_intern(&lf[307],25,"\003systhread-block-for-i/o!");
lf[308]=C_h_intern(&lf[308],18,"\003syscurrent-thread");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[313]=C_h_intern(&lf[313],17,"\003sysstring-append");
lf[314]=C_h_intern(&lf[314],15,"\003sysmake-string");
lf[315]=C_h_intern(&lf[315],20,"\003sysscan-buffer-line");
lf[316]=C_h_intern(&lf[316],4,"noop");
lf[317]=C_h_intern(&lf[317],16,"make-output-port");
lf[318]=C_h_intern(&lf[318],22,"\003syscustom-output-port");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[321]=C_h_intern(&lf[321],13,"file-truncate");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[324]=C_h_intern(&lf[324],4,"lock");
lf[325]=C_h_intern(&lf[325],9,"file-lock");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[327]=C_h_intern(&lf[327],18,"file-lock/blocking");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[329]=C_h_intern(&lf[329],14,"file-test-lock");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[331]=C_h_intern(&lf[331],11,"file-unlock");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[333]=C_h_intern(&lf[333],11,"create-fifo");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[336]=C_h_intern(&lf[336],13,"\003sysfile-info");
lf[337]=C_h_intern(&lf[337],6,"setenv");
lf[338]=C_h_intern(&lf[338],8,"unsetenv");
lf[339]=C_h_intern(&lf[339],25,"get-environment-variables");
lf[340]=C_h_intern(&lf[340],19,"current-environment");
lf[341]=C_h_intern(&lf[341],9,"prot/read");
lf[342]=C_h_intern(&lf[342],10,"prot/write");
lf[343]=C_h_intern(&lf[343],9,"prot/exec");
lf[344]=C_h_intern(&lf[344],9,"prot/none");
lf[345]=C_h_intern(&lf[345],9,"map/fixed");
lf[346]=C_h_intern(&lf[346],10,"map/shared");
lf[347]=C_h_intern(&lf[347],11,"map/private");
lf[348]=C_h_intern(&lf[348],13,"map/anonymous");
lf[349]=C_h_intern(&lf[349],8,"map/file");
lf[350]=C_h_intern(&lf[350],18,"map-file-to-memory");
lf[351]=C_h_intern(&lf[351],4,"mmap");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[353]=C_h_intern(&lf[353],20,"\003syspointer->address");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[355]=C_h_intern(&lf[355],16,"\003sysnull-pointer");
lf[356]=C_h_intern(&lf[356],22,"unmap-file-from-memory");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[358]=C_h_intern(&lf[358],26,"memory-mapped-file-pointer");
lf[359]=C_h_intern(&lf[359],19,"memory-mapped-file\077");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[362]=C_h_intern(&lf[362],19,"seconds->local-time");
lf[363]=C_h_intern(&lf[363],18,"\003sysdecode-seconds");
lf[364]=C_h_intern(&lf[364],15,"current-seconds");
lf[365]=C_h_intern(&lf[365],17,"seconds->utc-time");
lf[366]=C_h_intern(&lf[366],15,"seconds->string");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[368]=C_h_intern(&lf[368],12,"time->string");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[371]=C_h_intern(&lf[371],12,"string->time");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[373]=C_h_intern(&lf[373],19,"local-time->seconds");
lf[374]=C_decode_literal(C_heaptop,"\376U-1.0\000");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[376]=C_h_intern(&lf[376],17,"utc-time->seconds");
lf[377]=C_decode_literal(C_heaptop,"\376U-1.0\000");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[379]=C_h_intern(&lf[379],27,"local-timezone-abbreviation");
lf[380]=C_h_intern(&lf[380],5,"_exit");
lf[381]=C_h_intern(&lf[381],10,"set-alarm!");
lf[382]=C_h_intern(&lf[382],19,"set-buffering-mode!");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[384]=C_h_intern(&lf[384],5,"\000full");
lf[385]=C_h_intern(&lf[385],5,"\000line");
lf[386]=C_h_intern(&lf[386],5,"\000none");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[388]=C_h_intern(&lf[388],14,"terminal-port\077");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[391]=C_h_intern(&lf[391],13,"terminal-name");
lf[392]=C_h_intern(&lf[392],13,"terminal-size");
lf[393]=C_h_intern(&lf[393],6,"\000error");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[395]=C_h_intern(&lf[395],17,"\003sysmake-locative");
lf[396]=C_h_intern(&lf[396],8,"location");
lf[397]=C_h_intern(&lf[397],13,"get-host-name");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[399]=C_h_intern(&lf[399],6,"regexp");
lf[400]=C_h_intern(&lf[400],12,"string-match");
lf[401]=C_h_intern(&lf[401],12,"glob->regexp");
lf[402]=C_h_intern(&lf[402],4,"glob");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[405]=C_h_intern(&lf[405],12,"process-fork");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[407]=C_h_intern(&lf[407],24,"pathname-strip-directory");
lf[408]=C_h_intern(&lf[408],15,"process-execute");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[410]=C_h_intern(&lf[410],16,"\003sysprocess-wait");
lf[411]=C_h_intern(&lf[411],12,"process-wait");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[413]=C_h_intern(&lf[413],18,"current-process-id");
lf[414]=C_h_intern(&lf[414],17,"parent-process-id");
lf[415]=C_h_intern(&lf[415],5,"sleep");
lf[416]=C_h_intern(&lf[416],14,"process-signal");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[418]=C_h_intern(&lf[418],17,"\003sysshell-command");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[421]=C_h_intern(&lf[421],27,"\003sysshell-command-arguments");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[423]=C_h_intern(&lf[423],11,"process-run");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[425]=C_h_intern(&lf[425],11,"\003sysprocess");
lf[426]=C_h_intern(&lf[426],7,"process");
lf[427]=C_h_intern(&lf[427],8,"process*");
lf[428]=C_h_intern(&lf[428],16,"\003syscheck-string");
lf[429]=C_h_intern(&lf[429],12,"\003sysfor-each");
lf[430]=C_h_intern(&lf[430],13,"pathname-file");
lf[431]=C_h_intern(&lf[431],10,"find-files");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[435]=C_h_intern(&lf[435],16,"\003sysdynamic-wind");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[437]=C_h_intern(&lf[437],7,"regexp\077");
lf[438]=C_h_intern(&lf[438],19,"set-root-directory!");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[441]=C_h_intern(&lf[441],21,"set-process-group-id!");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[443]=C_h_intern(&lf[443],18,"getter-with-setter");
lf[444]=C_h_intern(&lf[444],26,"effective-group-id!-setter");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[446]=C_h_intern(&lf[446],12,"set-user-id!");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[448]=C_h_intern(&lf[448],25,"effective-user-id!-setter");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[451]=C_h_intern(&lf[451],23,"\003sysuser-interrupt-hook");
lf[452]=C_h_intern(&lf[452],11,"make-vector");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[455]=C_h_intern(&lf[455],26,"set-file-modification-time");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000!cannot set file modification-time");
lf[457]=C_h_intern(&lf[457],4,"file");
lf[458]=C_h_intern(&lf[458],17,"register-feature!");
lf[459]=C_h_intern(&lf[459],5,"posix");
C_register_lf2(lf,460,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2508,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2506 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2509 in k2506 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2512 in k2509 in k2506 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2520,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2523,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 516  register-feature! */
t3=*((C_word*)lf[458]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[459]);}

/* k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[44],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2526,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=C_mutate(&lf[1] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2533,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! posix-error ...) */,lf[1]);
t5=C_mutate((C_word*)lf[7]+1 /* (set! file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2551,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[8]+1 /* (set! file-select-one ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2554,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[9]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[10]+1 /* (set! fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[11]+1 /* (set! fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[12]+1 /* (set! fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[13]+1 /* (set! fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[14]+1 /* (set! fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[15]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[16]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[17]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[18]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[19]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[20]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[21]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[22]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[23]+1 /* (set! open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[24]+1 /* (set! open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[25]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[26]+1 /* (set! open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[27]+1 /* (set! open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[28]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[29]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[30]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[31]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[32]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[33]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[34]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[35]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[36]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[37]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[38]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[39]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[40]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[41]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[42]+1 /* (set! perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[43]+1 /* (set! perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[44]+1 /* (set! perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[45]+1 /* (set! file-control ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2595,tmp=(C_word)a,a+=2,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[48]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2634,a[2]=t45,tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[52]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2672,tmp=(C_word)a,a+=2,tmp));
t48=*((C_word*)lf[54]+1);
t49=C_mutate((C_word*)lf[55]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2687,a[2]=t48,tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[59]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2729,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[62]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2768,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[65]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2806,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[67]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t54=C_mutate((C_word*)lf[68]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t55=C_mutate((C_word*)lf[69]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t56=C_mutate(&lf[70] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3086,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[73]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3123,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[74]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3148,tmp=(C_word)a,a+=2,tmp));
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t60=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8419,tmp=(C_word)a,a+=2,tmp);
t61=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8425,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 793  getter-with-setter */
t62=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t62+1)))(4,t62,t59,t60,t61);}

/* a8424 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8425,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[455]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8441,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8454,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 799  ##sys#expand-home-path */
t7=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[457]+1));}

/* k8452 in a8424 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8454,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8435,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
/* ##sys#make-c-string */
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}
else{
t4=((C_word*)t0)[2];
f_8441(t4,(C_word)stub286(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t2));}}

/* k8433 in k8452 in a8424 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_8441(t2,(C_word)stub286(C_SCHEME_UNDEFINED,t1,((C_word*)t0)[2]));}

/* k8439 in a8424 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 801  posix-error */
t2=lf[1];
f_2533(7,t2,((C_word*)t0)[4],lf[46],lf[455],lf[456],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* a8418 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8419,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8423,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 795  ##sys#stat */
f_3086(t3,t2,C_SCHEME_FALSE,lf[75]);}

/* k8421 in a8418 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8423,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3156,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! file-modification-time ...) */,t1);
t3=C_mutate((C_word*)lf[76]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3158,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[77]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3164,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[78]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3170,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[79]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3176,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[80]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3182,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[81]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3191,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[82]+1 /* (set! character-device? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3200,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[83]+1 /* (set! block-device? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3209,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[84]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3218,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[86]+1 /* (set! socket? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3227,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[87]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3236,tmp=(C_word)a,a+=2,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3296,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8382,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 857  getter-with-setter */
t16=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t14,t15,*((C_word*)lf[87]+1));}

/* a8381 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8382,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8386,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8398,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 859  port? */
t5=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k8396 in a8381 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[89]);
if(C_truep(t3)){
t4=(C_word)C_ftell(((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
f_8386(2,t5,t4);}
else{
t4=((C_word*)t0)[2];
f_8386(2,t4,C_fix(-1));}}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR));
t3=((C_word*)t0)[2];
f_8386(2,t3,t2);}
else{
/* posixunix.scm: 866  ##sys#signal-hook */
t2=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[57],lf[94],lf[454],((C_word*)t0)[3]);}}}

/* k8384 in a8381 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8389,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_lessp(t1,C_fix(0)))){
/* posixunix.scm: 868  posix-error */
t3=lf[1];
f_2533(6,t3,t2,lf[46],lf[94],lf[453],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k8387 in k8384 in a8381 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word ab[138],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3296,2,t0,t1);}
t2=C_mutate((C_word*)lf[94]+1 /* (set! file-position ...) */,t1);
t3=*((C_word*)lf[95]+1);
t4=*((C_word*)lf[96]+1);
t5=C_mutate((C_word*)lf[97]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3298,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=C_mutate((C_word*)lf[100]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3450,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[102]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3472,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[104]+1);
t9=*((C_word*)lf[54]+1);
t10=*((C_word*)lf[105]+1);
t11=C_mutate((C_word*)lf[106]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3494,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t12=C_mutate((C_word*)lf[110]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3648,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[54]+1);
t14=C_mutate((C_word*)lf[109]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3674,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[112]+1);
t16=*((C_word*)lf[113]+1);
t17=*((C_word*)lf[114]+1);
t18=*((C_word*)lf[115]+1);
t19=*((C_word*)lf[104]+1);
t20=*((C_word*)lf[0]+1);
t21=*((C_word*)lf[116]+1);
t22=*((C_word*)lf[117]+1);
t23=*((C_word*)lf[109]+1);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3731,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
t25=C_mutate((C_word*)lf[122]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3787,a[2]=t18,a[3]=t16,a[4]=t21,a[5]=t22,a[6]=t24,a[7]=t17,a[8]=t15,a[9]=t19,a[10]=t20,tmp=(C_word)a,a+=11,tmp));
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4122,tmp=(C_word)a,a+=2,tmp);
t27=C_mutate((C_word*)lf[144]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4137,a[2]=t26,tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[149]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4173,a[2]=t26,tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[150]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4209,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[154]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[150]+1));
t31=*((C_word*)lf[144]+1);
t32=*((C_word*)lf[149]+1);
t33=*((C_word*)lf[150]+1);
t34=*((C_word*)lf[154]+1);
t35=C_mutate((C_word*)lf[155]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4225,a[2]=t31,a[3]=t33,tmp=(C_word)a,a+=4,tmp));
t36=C_mutate((C_word*)lf[156]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4249,a[2]=t32,a[3]=t34,tmp=(C_word)a,a+=4,tmp));
t37=C_mutate((C_word*)lf[157]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4273,a[2]=t31,a[3]=t33,tmp=(C_word)a,a+=4,tmp));
t38=C_mutate((C_word*)lf[159]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4293,a[2]=t32,a[3]=t34,tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[161]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4313,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[163]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t41=C_mutate((C_word*)lf[164]+1 /* (set! signal/kill ...) */,C_fix((C_word)SIGKILL));
t42=C_mutate((C_word*)lf[165]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t43=C_mutate((C_word*)lf[166]+1 /* (set! signal/hup ...) */,C_fix((C_word)SIGHUP));
t44=C_mutate((C_word*)lf[167]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t45=C_mutate((C_word*)lf[168]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t46=C_mutate((C_word*)lf[169]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t47=C_mutate((C_word*)lf[170]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t48=C_mutate((C_word*)lf[171]+1 /* (set! signal/trap ...) */,C_fix((C_word)SIGTRAP));
t49=C_mutate((C_word*)lf[172]+1 /* (set! signal/quit ...) */,C_fix((C_word)SIGQUIT));
t50=C_mutate((C_word*)lf[173]+1 /* (set! signal/alrm ...) */,C_fix((C_word)SIGALRM));
t51=C_mutate((C_word*)lf[174]+1 /* (set! signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t52=C_mutate((C_word*)lf[175]+1 /* (set! signal/prof ...) */,C_fix((C_word)SIGPROF));
t53=C_mutate((C_word*)lf[176]+1 /* (set! signal/io ...) */,C_fix((C_word)SIGIO));
t54=C_mutate((C_word*)lf[177]+1 /* (set! signal/urg ...) */,C_fix((C_word)SIGURG));
t55=C_mutate((C_word*)lf[178]+1 /* (set! signal/chld ...) */,C_fix((C_word)SIGCHLD));
t56=C_mutate((C_word*)lf[179]+1 /* (set! signal/cont ...) */,C_fix((C_word)SIGCONT));
t57=C_mutate((C_word*)lf[180]+1 /* (set! signal/stop ...) */,C_fix((C_word)SIGSTOP));
t58=C_mutate((C_word*)lf[181]+1 /* (set! signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t59=C_mutate((C_word*)lf[182]+1 /* (set! signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t60=C_mutate((C_word*)lf[183]+1 /* (set! signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t61=C_mutate((C_word*)lf[184]+1 /* (set! signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t62=C_mutate((C_word*)lf[185]+1 /* (set! signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t63=C_mutate((C_word*)lf[186]+1 /* (set! signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t64=C_mutate((C_word*)lf[187]+1 /* (set! signal/winch ...) */,C_fix((C_word)SIGWINCH));
t65=(C_word)C_a_i_list(&a,25,*((C_word*)lf[163]+1),*((C_word*)lf[164]+1),*((C_word*)lf[165]+1),*((C_word*)lf[166]+1),*((C_word*)lf[167]+1),*((C_word*)lf[168]+1),*((C_word*)lf[169]+1),*((C_word*)lf[170]+1),*((C_word*)lf[171]+1),*((C_word*)lf[172]+1),*((C_word*)lf[173]+1),*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1));
t66=C_mutate((C_word*)lf[188]+1 /* (set! signals-list ...) */,t65);
t67=*((C_word*)lf[189]+1);
t68=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4358,a[2]=((C_word*)t0)[2],a[3]=t67,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1182 make-vector */
t69=*((C_word*)lf[452]+1);
((C_proc4)(void*)(*((C_word*)t69+1)))(4,t69,t68,C_fix(256),C_SCHEME_FALSE);}

/* k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4358,2,t0,t1);}
t2=C_mutate((C_word*)lf[190]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4360,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[191]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4369,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[189]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[192]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4400,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[195]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4446,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[196]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4478,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[197]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4484,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[199]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4499,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4515,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8376,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1238 set-signal-handler! */
t12=*((C_word*)lf[191]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,*((C_word*)lf[165]+1),t11);}

/* a8375 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8376,3,t0,t1,t2);}
/* posixunix.scm: 1240 ##sys#user-interrupt-hook */
t3=*((C_word*)lf[451]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4515,2,t0,t1);}
t2=C_mutate((C_word*)lf[201]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4517,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4557,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8358,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8361,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1264 getter-with-setter */
t6=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8360 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8361,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8371,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1268 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8369 in a8360 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1269 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[446],lf[450],((C_word*)t0)[2]);}

/* a8357 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8358,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub797(C_SCHEME_UNDEFINED));}

/* k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4557,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1 /* (set! current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4561,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8340,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8343,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1272 getter-with-setter */
t6=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8342 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8343,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8353,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1276 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8351 in a8342 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1277 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[448],lf[449],((C_word*)t0)[2]);}

/* a8339 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8340,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub803(C_SCHEME_UNDEFINED));}

/* k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4561,2,t0,t1);}
t2=C_mutate((C_word*)lf[205]+1 /* (set! current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4565,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8322,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8325,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1281 getter-with-setter */
t6=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8324 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8325,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8335,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1285 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8333 in a8324 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1286 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[446],lf[447],((C_word*)t0)[2]);}

/* a8321 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8322,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub809(C_SCHEME_UNDEFINED));}

/* k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=C_mutate((C_word*)lf[206]+1 /* (set! current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8304,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8307,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1289 getter-with-setter */
t6=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a8306 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8307,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8317,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1293 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8315 in a8306 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1294 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[444],lf[445],((C_word*)t0)[2]);}

/* a8303 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8304,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub815(C_SCHEME_UNDEFINED));}

/* k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4569,2,t0,t1);}
t2=C_mutate((C_word*)lf[207]+1 /* (set! current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[208]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4571,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[117]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4631,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[211]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4645,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[212]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4665,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[213]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4743,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[217]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4806,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[220]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4872,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[222]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t11=C_mutate((C_word*)lf[223]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t12=C_mutate((C_word*)lf[224]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t13=C_mutate((C_word*)lf[225]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t14=C_mutate((C_word*)lf[226]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t15=C_mutate((C_word*)lf[227]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t16=C_mutate((C_word*)lf[228]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t17=C_mutate((C_word*)lf[229]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t18=C_mutate((C_word*)lf[230]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t19=C_mutate((C_word*)lf[231]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t20=C_mutate((C_word*)lf[232]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t21=C_mutate((C_word*)lf[233]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t22=C_mutate((C_word*)lf[234]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t23=C_mutate((C_word*)lf[235]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t24=C_mutate((C_word*)lf[236]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t25=C_mutate((C_word*)lf[237]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t26=C_mutate((C_word*)lf[238]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t27=C_mutate((C_word*)lf[239]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t28=C_mutate((C_word*)lf[240]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t29=C_mutate((C_word*)lf[241]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t30=C_mutate((C_word*)lf[242]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t31=C_mutate((C_word*)lf[243]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t32=C_mutate((C_word*)lf[244]+1 /* (set! errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t33=C_set_block_item(lf[245] /* errno/2big */,0,C_fix(0));
t34=C_set_block_item(lf[246] /* errno/deadlk */,0,C_fix(0));
t35=C_set_block_item(lf[247] /* errno/dom */,0,C_fix(0));
t36=C_set_block_item(lf[248] /* errno/fbig */,0,C_fix(0));
t37=C_set_block_item(lf[249] /* errno/ilseq */,0,C_fix(0));
t38=C_set_block_item(lf[250] /* errno/mlink */,0,C_fix(0));
t39=C_set_block_item(lf[251] /* errno/nametoolong */,0,C_fix(0));
t40=C_set_block_item(lf[252] /* errno/nfile */,0,C_fix(0));
t41=C_set_block_item(lf[253] /* errno/nodev */,0,C_fix(0));
t42=C_set_block_item(lf[254] /* errno/nolck */,0,C_fix(0));
t43=C_set_block_item(lf[255] /* errno/nosys */,0,C_fix(0));
t44=C_set_block_item(lf[256] /* errno/notempty */,0,C_fix(0));
t45=C_set_block_item(lf[257] /* errno/notty */,0,C_fix(0));
t46=C_set_block_item(lf[258] /* errno/nxio */,0,C_fix(0));
t47=C_set_block_item(lf[259] /* errno/range */,0,C_fix(0));
t48=C_set_block_item(lf[260] /* errno/xdev */,0,C_fix(0));
t49=C_mutate((C_word*)lf[261]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4936,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[263]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4963,tmp=(C_word)a,a+=2,tmp));
t51=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4993,tmp=(C_word)a,a+=2,tmp);
t52=C_mutate((C_word*)lf[265]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5017,a[2]=t51,tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[266]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5023,a[2]=t51,tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[267]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5029,a[2]=t51,tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[268]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5035,tmp=(C_word)a,a+=2,tmp));
t56=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5052,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t57=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8265,tmp=(C_word)a,a+=2,tmp);
t58=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8283,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1509 getter-with-setter */
t59=*((C_word*)lf[443]+1);
((C_proc4)(void*)(*((C_word*)t59+1)))(4,t59,t56,t57,t58);}

/* a8282 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8283,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[441]);
t5=(C_word)C_i_check_exact_2(t3,lf[441]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8299,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1521 ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8297 in a8282 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1522 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[441],lf[442],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8264 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8265,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[270]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8272,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8278,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1514 ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t4);}}

/* k8276 in a8264 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1515 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[270],lf[440],((C_word*)t0)[2]);}

/* k8270 in a8264 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5052,2,t0,t1);}
t2=C_mutate((C_word*)lf[270]+1 /* (set! process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[271]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5054,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[274]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5091,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_u_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1542 make-string */
t7=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word ab[196],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5091,2,t0,t1);}
t2=C_mutate((C_word*)lf[275]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5092,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[278]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5161,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[281]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[282]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[283]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5186,tmp=(C_word)a,a+=2,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5223,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[292]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5238,a[2]=t8,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t14=C_mutate((C_word*)lf[293]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5252,a[2]=t8,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t15=C_mutate((C_word*)lf[294]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5266,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[300]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5311,tmp=(C_word)a,a+=2,tmp));
t17=*((C_word*)lf[302]+1);
t18=*((C_word*)lf[303]+1);
t19=C_mutate((C_word*)lf[304]+1 /* (set! custom-input-port ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5338,a[2]=t17,a[3]=t18,tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[317]+1);
t21=*((C_word*)lf[303]+1);
t22=C_mutate((C_word*)lf[318]+1 /* (set! custom-output-port ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5817,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[321]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6073,tmp=(C_word)a,a+=2,tmp));
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6112,tmp=(C_word)a,a+=2,tmp));
t29=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6183,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[325]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6201,a[2]=t25,a[3]=t27,tmp=(C_word)a,a+=4,tmp));
t31=C_mutate((C_word*)lf[327]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6216,a[2]=t25,a[3]=t27,tmp=(C_word)a,a+=4,tmp));
t32=C_mutate((C_word*)lf[329]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6231,a[2]=t25,a[3]=t27,tmp=(C_word)a,a+=4,tmp));
t33=C_mutate((C_word*)lf[331]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6258,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[333]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6286,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[84]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6329,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[337]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6355,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[338]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6372,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[339]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6387,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[340]+1 /* (set! current-environment ...) */,*((C_word*)lf[339]+1));
t40=C_mutate((C_word*)lf[341]+1 /* (set! prot/read ...) */,C_fix((C_word)PROT_READ));
t41=C_mutate((C_word*)lf[342]+1 /* (set! prot/write ...) */,C_fix((C_word)PROT_WRITE));
t42=C_mutate((C_word*)lf[343]+1 /* (set! prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t43=C_mutate((C_word*)lf[344]+1 /* (set! prot/none ...) */,C_fix((C_word)PROT_NONE));
t44=C_mutate((C_word*)lf[345]+1 /* (set! map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t45=C_mutate((C_word*)lf[346]+1 /* (set! map/shared ...) */,C_fix((C_word)MAP_SHARED));
t46=C_mutate((C_word*)lf[347]+1 /* (set! map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t47=C_mutate((C_word*)lf[348]+1 /* (set! map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t48=C_mutate((C_word*)lf[349]+1 /* (set! map/file ...) */,C_fix((C_word)MAP_FILE));
t49=C_mutate((C_word*)lf[350]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6471,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[356]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6529,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[358]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6564,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[359]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6573,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate(&lf[360] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6579,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[362]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6598,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[365]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6625,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[366]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6657,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[368]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6711,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[371]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6773,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[373]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6812,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[376]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6827,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[379]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6842,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[380]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6850,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[381]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6866,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[382]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6869,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[388]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6928,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate(&lf[389] /* (set! terminal-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6947,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[391]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6974,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[392]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6993,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[397]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7028,tmp=(C_word)a,a+=2,tmp));
t70=*((C_word*)lf[399]+1);
t71=*((C_word*)lf[400]+1);
t72=*((C_word*)lf[401]+1);
t73=*((C_word*)lf[106]+1);
t74=*((C_word*)lf[99]+1);
t75=*((C_word*)lf[95]+1);
t76=C_mutate((C_word*)lf[402]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7040,a[2]=t72,a[3]=t70,a[4]=t73,a[5]=t71,a[6]=t74,a[7]=t75,tmp=(C_word)a,a+=8,tmp));
t77=C_mutate((C_word*)lf[405]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7154,tmp=(C_word)a,a+=2,tmp));
t78=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7192,tmp=(C_word)a,a+=2,tmp);
t79=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7200,tmp=(C_word)a,a+=2,tmp);
t80=*((C_word*)lf[407]+1);
t81=C_mutate((C_word*)lf[408]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7208,a[2]=t80,a[3]=t79,a[4]=t78,tmp=(C_word)a,a+=5,tmp));
t82=C_mutate((C_word*)lf[410]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7387,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[411]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7404,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[413]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7479,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[414]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7482,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[415]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7485,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[416]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7488,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[418]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7515,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[421]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7524,tmp=(C_word)a,a+=2,tmp));
t90=*((C_word*)lf[405]+1);
t91=*((C_word*)lf[408]+1);
t92=C_mutate((C_word*)lf[423]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7530,a[2]=t90,a[3]=t91,tmp=(C_word)a,a+=4,tmp));
t93=*((C_word*)lf[161]+1);
t94=*((C_word*)lf[411]+1);
t95=*((C_word*)lf[405]+1);
t96=*((C_word*)lf[408]+1);
t97=*((C_word*)lf[300]+1);
t98=*((C_word*)lf[52]+1);
t99=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7586,a[2]=t94,tmp=(C_word)a,a+=3,tmp);
t100=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7623,a[2]=t93,tmp=(C_word)a,a+=3,tmp);
t101=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7643,a[2]=t98,tmp=(C_word)a,a+=3,tmp);
t102=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7657,a[2]=t98,tmp=(C_word)a,a+=3,tmp);
t103=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7690,a[2]=t100,a[3]=t95,a[4]=t102,a[5]=t96,tmp=(C_word)a,a+=6,tmp);
t104=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7735,a[2]=t101,tmp=(C_word)a,a+=3,tmp);
t105=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7746,a[2]=t101,tmp=(C_word)a,a+=3,tmp);
t106=C_mutate((C_word*)lf[425]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7757,a[2]=t105,a[3]=t99,a[4]=t104,a[5]=t103,tmp=(C_word)a,a+=6,tmp));
t107=C_set_block_item(lf[426] /* process */,0,C_SCHEME_UNDEFINED);
t108=C_set_block_item(lf[427] /* process* */,0,C_SCHEME_UNDEFINED);
t109=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7815,tmp=(C_word)a,a+=2,tmp);
t110=C_mutate((C_word*)lf[426]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7876,a[2]=t109,tmp=(C_word)a,a+=3,tmp));
t111=C_mutate((C_word*)lf[427]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7933,a[2]=t109,tmp=(C_word)a,a+=3,tmp));
t112=*((C_word*)lf[402]+1);
t113=*((C_word*)lf[400]+1);
t114=*((C_word*)lf[99]+1);
t115=*((C_word*)lf[430]+1);
t116=*((C_word*)lf[110]+1);
t117=C_mutate((C_word*)lf[431]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7990,a[2]=t116,a[3]=t115,a[4]=t114,a[5]=t112,a[6]=t113,tmp=(C_word)a,a+=7,tmp));
t118=C_mutate((C_word*)lf[438]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8242,tmp=(C_word)a,a+=2,tmp));
t119=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t119+1)))(2,t119,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8242,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[438]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8252,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8238,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
/* ##sys#make-c-string */
t7=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t7=(C_word)stub2249(C_SCHEME_UNDEFINED,C_SCHEME_FALSE);
t8=t4;
f_8252(t8,(C_word)C_fixnum_lessp(t7,C_fix(0)));}}

/* k8236 in set-root-directory! in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub2249(C_SCHEME_UNDEFINED,t1);
t3=((C_word*)t0)[2];
f_8252(t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* k8250 in set-root-directory! in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8252(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2409 posix-error */
t2=lf[1];
f_2533(6,t2,((C_word*)t0)[3],lf[46],lf[438],lf[439],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_7990r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7990r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7990r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8157,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8162,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8167,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action21732238 */
t9=t8;
f_8167(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id21742236 */
t11=t7;
f_8162(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit21752233 */
t13=t6;
f_8157(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body21712180 */
t15=t5;
f_7992(t15,t1,t9,t11,t13);}}}}

/* def-action2173 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8167,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8173,tmp=(C_word)a,a+=2,tmp);
/* def-id21742236 */
t3=((C_word*)t0)[2];
f_8162(t3,t1,t2);}

/* a8172 in def-action2173 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8173,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id2174 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8162,NULL,3,t0,t1,t2);}
/* def-limit21752233 */
t3=((C_word*)t0)[2];
f_8157(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit2175 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8157(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8157,NULL,4,t0,t1,t2,t3);}
/* body21712180 */
t4=((C_word*)t0)[2];
f_7992(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7992(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7992,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[8],lf[431]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7999,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=t7,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
t9=t4;
if(C_truep(t9)){
if(C_truep((C_word)C_fixnump(t4))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8152,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t11=t8;
f_7999(t11,t10);}
else{
t10=t4;
t11=t8;
f_7999(t11,t10);}}
else{
t10=t8;
f_7999(t10,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8144,tmp=(C_word)a,a+=2,tmp));}}

/* f_8144 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8144(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8144,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_8152 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8152(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8152,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7999(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7999,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=t3;
f_8132(2,t4,t2);}
else{
/* posixunix.scm: 2381 regexp? */
t4=*((C_word*)lf[437]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[12]);}}

/* k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8132,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8133,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t2,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8126,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2384 make-pathname */
t5=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[436]);}

/* k8124 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2384 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8009,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8011,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_8011(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_8011(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8011,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t4,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=t5,a[12]=t1,a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2390 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8030,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2391 pathname-file */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8112,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2398 pproc */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}}

/* k8110 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8112,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8119,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2398 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2399 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_8011(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k8117 in k8110 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2398 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8011(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8106,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[432]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[433]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2391 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_8011(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8045,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2392 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8043 in k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8045,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8055,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8057,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8086,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[435]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8096,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8099,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2397 pproc */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}}

/* k8097 in k8043 in k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2397 action */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[5];
/* posixunix.scm: 2397 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8011(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k8094 in k8043 in k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2397 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8011(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8085 in k8043 in k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8086,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8061 in k8043 in k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8070,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8084,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2395 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],lf[434]);}

/* k8082 in a8061 in k8043 in k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2395 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8068 in a8061 in k8043 in k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8074,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8077,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2396 pproc */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k8075 in k8068 in a8061 in k8043 in k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2396 action */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[5];
/* posixunix.scm: 2395 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_8011(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k8072 in k8068 in a8061 in k8043 in k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2395 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8011(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8056 in k8043 in k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8057,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8053 in k8043 in k8104 in k8028 in loop in k8007 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2393 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8011(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8133 in k8130 in k7997 in body2171 in find-files in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8133,3,t0,t1,t2);}
/* posixunix.scm: 2382 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7933(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_7933r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7933r(t0,t1,t2,t3);}}

static void C_ccall f_7933r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7935,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7940,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7945,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args21402151 */
t7=t6;
f_7945(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env21412149 */
t9=t5;
f_7940(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body21382146 */
t11=t4;
f_7935(t11,t1,t7,t9);}}}

/* def-args2140 in process* in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7945(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7945,NULL,2,t0,t1);}
/* def-env21412149 */
t2=((C_word*)t0)[2];
f_7940(t2,t1,C_SCHEME_FALSE);}

/* def-env2141 in process* in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7940(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7940,NULL,3,t0,t1,t2);}
/* body21382146 */
t3=((C_word*)t0)[2];
f_7935(t3,t1,t2,C_SCHEME_FALSE);}

/* body2138 in process* in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7935(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7935,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2358 %process */
f_7815(t1,lf[427],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7876(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_7876r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7876r(t0,t1,t2,t3);}}

static void C_ccall f_7876r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7878,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7883,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7888,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args21092120 */
t7=t6;
f_7888(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env21102118 */
t9=t5;
f_7883(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body21072115 */
t11=t4;
f_7878(t11,t1,t7,t9);}}}

/* def-args2109 in process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7888,NULL,2,t0,t1);}
/* def-env21102118 */
t2=((C_word*)t0)[2];
f_7883(t2,t1,C_SCHEME_FALSE);}

/* def-env2110 in process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7883(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7883,NULL,3,t0,t1,t2);}
/* body21072115 */
t3=((C_word*)t0)[2];
f_7878(t3,t1,t2,C_SCHEME_FALSE);}

/* body2107 in process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7878(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7878,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2355 %process */
f_7815(t1,lf[426],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7815(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7815,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7817,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7836,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2344 chkstrlst */
t12=t9;
f_7817(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7870,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2346 ##sys#shell-command-arguments */
t13=*((C_word*)lf[421]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t7)[1]);}}

/* k7868 in %process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7870,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2347 ##sys#shell-command */
t4=*((C_word*)lf[418]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7872 in k7868 in %process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7836(2,t3,t2);}

/* k7834 in %process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2348 chkstrlst */
t3=((C_word*)t0)[2];
f_7817(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_7839(2,t3,C_SCHEME_UNDEFINED);}}

/* k7837 in k7834 in %process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7844,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7850,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a7849 in k7837 in k7834 in %process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7850,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2351 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2352 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a7843 in k7837 in k7834 in %process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7844,2,t0,t1);}
/* posixunix.scm: 2349 ##sys#process */
t2=*((C_word*)lf[425]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7817(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7817,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7826,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[429]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a7825 in chkstrlst in %process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7826(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7826,3,t0,t1,t2);}
t3=*((C_word*)lf[428]+1);
/* g20792080 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* ##sys#process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_7757,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7763,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a7768 in ##sys#process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7769(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7769,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7780,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7800,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2325 make-on-close */
t12=((C_word*)t0)[3];
f_7586(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k7798 in a7768 in ##sys#process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2324 input-port */
t2=((C_word*)t0)[7];
f_7735(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7778 in a7768 in ##sys#process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7784,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2327 make-on-close */
t4=((C_word*)t0)[6];
f_7586(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k7794 in k7778 in a7768 in ##sys#process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2326 output-port */
t2=((C_word*)t0)[7];
f_7746(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7782 in k7778 in a7768 in ##sys#process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7788,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7792,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2330 make-on-close */
t4=((C_word*)t0)[3];
f_7586(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k7790 in k7782 in k7778 in a7768 in ##sys#process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2329 input-port */
t2=((C_word*)t0)[7];
f_7735(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7786 in k7782 in k7778 in a7768 in ##sys#process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2323 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7762 in ##sys#process in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7763,2,t0,t1);}
/* posixunix.scm: 2318 spawn */
t2=((C_word*)t0)[8];
f_7690(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7746(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7746,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7750,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2314 connect-parent */
t8=((C_word*)t0)[2];
f_7643(t8,t7,t4,t5);}

/* k7748 in output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2315 ##sys#custom-output-port */
t2=*((C_word*)lf[318]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7735(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7735,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7739,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2310 connect-parent */
t8=((C_word*)t0)[2];
f_7643(t8,t7,t4,t5);}

/* k7737 in input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2311 ##sys#custom-input-port */
t2=*((C_word*)lf[304]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7690(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7690,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2297 needed-pipe */
t9=((C_word*)t0)[2];
f_7623(t9,t8,t6);}

/* k7692 in spawn in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2298 needed-pipe */
t3=((C_word*)t0)[2];
f_7623(t3,t2,((C_word*)t0)[5]);}

/* k7695 in k7692 in spawn in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_7700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2299 needed-pipe */
t3=((C_word*)t0)[2];
f_7623(t3,t2,((C_word*)t0)[6]);}

/* k7698 in k7695 in k7692 in spawn in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_7707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=((C_word*)t0)[4];
if(C_truep(t3)){
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_u_i_car(t3);
t6=t2;
f_7707(t6,(C_word)C_a_i_cons(&a,2,t4,t5));}
else{
t4=t2;
f_7707(t4,C_SCHEME_FALSE);}}

/* k7705 in k7698 in k7695 in k7692 in spawn in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7707,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7711,a[2]=((C_word*)t0)[12],a[3]=t1,a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7713,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2302 process-fork */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a7712 in k7705 in k7698 in k7695 in k7692 in spawn in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7717,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t1,a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2304 connect-child */
t3=((C_word*)t0)[7];
f_7657(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[281]+1));}

/* k7715 in a7712 in k7705 in k7698 in k7695 in k7692 in spawn in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7720,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
/* posixunix.scm: 2305 connect-child */
t7=((C_word*)t0)[5];
f_7657(t7,t2,t6,((C_word*)t0)[2],*((C_word*)lf[282]+1));}
else{
/* posixunix.scm: 2305 connect-child */
t4=((C_word*)t0)[5];
f_7657(t4,t2,C_SCHEME_FALSE,((C_word*)t0)[2],*((C_word*)lf[282]+1));}}

/* k7718 in k7715 in a7712 in k7705 in k7698 in k7695 in k7692 in spawn in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7723,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[4];
if(C_truep(t3)){
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
/* posixunix.scm: 2306 connect-child */
t7=((C_word*)t0)[3];
f_7657(t7,t2,t6,((C_word*)t0)[2],*((C_word*)lf[283]+1));}
else{
/* posixunix.scm: 2306 connect-child */
t4=((C_word*)t0)[3];
f_7657(t4,t2,C_SCHEME_FALSE,((C_word*)t0)[2],*((C_word*)lf[283]+1));}}

/* k7721 in k7718 in k7715 in a7712 in k7705 in k7698 in k7695 in k7692 in spawn in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2307 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7709 in k7705 in k7698 in k7695 in k7692 in spawn in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2300 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* connect-child in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7657(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7657,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7670,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2288 file-close */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k7668 in connect-child in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7670,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7582,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2262 duplicate-fileno */
t6=*((C_word*)lf[300]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k7580 in k7668 in connect-child in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2263 file-close */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7643(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7643,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7656,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2282 file-close */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k7654 in connect-parent in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7623(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7623,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7638,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a7637 in needed-pipe in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7638,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a7631 in needed-pipe in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7632,2,t0,t1);}
/* posixunix.scm: 2277 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* make-on-close in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7586(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7586,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7588,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,tmp=(C_word)a,a+=9,tmp));}

/* f_7588 in make-on-close in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7588,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* a7608 */
static void C_ccall f_7609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7609,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* posixunix.scm: 2272 ##sys#signal-hook */
t5=*((C_word*)lf[2]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[193],((C_word*)t0)[3],lf[424],((C_word*)t0)[2],t4);}}

/* a7602 */
static void C_ccall f_7603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7603,2,t0,t1);}
/* posixunix.scm: 2270 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7530r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7530r(t0,t1,t2,t3);}}

static void C_ccall f_7530r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7537,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2226 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k7535 in process-run in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7537,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2228 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2230 ##sys#shell-command */
t4=*((C_word*)lf[418]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t3=t1;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7554 in k7535 in process-run in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7560,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2230 ##sys#shell-command-arguments */
t3=*((C_word*)lf[421]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7558 in k7554 in k7535 in process-run in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2230 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7524,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[422],t2));}

/* ##sys#shell-command in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7519,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2216 get-environment-variable */
t3=*((C_word*)lf[116]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[420]);}

/* k7517 in ##sys#shell-command in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[419]);}}

/* process-signal in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7488(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7488r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7488r(t0,t1,t2,t3);}}

static void C_ccall f_7488r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[416]);
t7=(C_word)C_i_check_exact_2(t5,lf[416]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2213 posix-error */
t10=lf[1];
f_2533(7,t10,t1,lf[193],lf[416],lf[417],t2,t5);}
else{
t10=C_SCHEME_UNDEFINED;
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}}

/* sleep in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7485,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub1910(C_SCHEME_UNDEFINED,t2));}

/* parent-process-id in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7482,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1907(C_SCHEME_UNDEFINED));}

/* current-process-id in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7479,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1905(C_SCHEME_UNDEFINED));}

/* process-wait in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_7404r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7404r(t0,t1,t2);}}

static void C_ccall f_7404r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(7);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t2,C_fix(1)));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[411]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7431,a[2]=t8,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7437,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t13,t14);}

/* a7436 in process-wait in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7437,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2199 posix-error */
t6=lf[1];
f_2533(6,t6,t1,lf[193],lf[411],lf[412],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2200 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a7430 in process-wait in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7431,2,t0,t1);}
/* posixunix.scm: 2197 ##sys#process-wait */
t2=*((C_word*)lf[410]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7387,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
if(C_truep(t6)){
t7=(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status));
/* posixunix.scm: 2184 values */
C_values(5,0,t1,t5,t6,t7);}
else{
if(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))){
t7=(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status));
/* posixunix.scm: 2184 values */
C_values(5,0,t1,t5,t6,t7);}
else{
t7=(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status));
/* posixunix.scm: 2184 values */
C_values(5,0,t1,t5,t6,t7);}}}

/* process-execute in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_7208r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7208r(t0,t1,t2,t3);}}

static void C_ccall f_7208r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7337,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7342,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist18171864 */
t7=t6;
f_7342(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist18181862 */
t9=t5;
f_7337(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body18151823 */
t11=t4;
f_7210(t11,t1,t7,t9);}}}

/* def-arglist1817 in process-execute in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7342(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7342,NULL,2,t0,t1);}
/* def-envlist18181862 */
t2=((C_word*)t0)[2];
f_7337(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist1818 in process-execute in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7337(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7337,NULL,3,t0,t1,t2);}
/* body18151823 */
t3=((C_word*)t0)[2];
f_7210(t3,t1,t2,C_SCHEME_FALSE);}

/* body1815 in process-execute in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7210(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7210,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[408]);
t5=(C_word)C_i_check_list_2(t2,lf[408]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7220,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2152 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}

/* k7218 in body1815 in process-execute in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7220,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_7192(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7228,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_7228(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* doloop1827 in k7218 in body1815 in process-execute in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7228(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7228,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_7192(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7241,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[408]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7274,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=t5;
f_7241(t8,f_7274(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_7241(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[408]);
t6=(C_word)C_block_size(t4);
t7=f_7192(t3,t4,t6);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* doloop1835 in doloop1827 in k7218 in body1815 in process-execute in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_7274(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(f_7200(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[408]);
t5=(C_word)C_block_size(t3);
t6=f_7200(t2,t3,t5);
t7=(C_word)C_slot(t1,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k7239 in doloop1827 in k7218 in body1815 in process-execute in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7241,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7266,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2166 ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k7264 in k7239 in doloop1827 in k7218 in body1815 in process-execute in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2166 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7242 in k7239 in doloop1827 in k7218 in body1815 in process-execute in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub1788(C_SCHEME_UNDEFINED);
t5=(C_word)stub1800(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2173 posix-error */
t6=lf[1];
f_2533(6,t6,((C_word*)t0)[3],lf[193],lf[408],lf[409],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_7200(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
if(C_truep(t2)){
t4=t2;
return((C_word)stub1793(C_SCHEME_UNDEFINED,t1,t4,t3));}
else{
return((C_word)stub1793(C_SCHEME_UNDEFINED,t1,C_SCHEME_FALSE,t3));}}

/* setarg in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_7192(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
if(C_truep(t2)){
t4=t2;
return((C_word)stub1781(C_SCHEME_UNDEFINED,t1,t4,t3));}
else{
return((C_word)stub1781(C_SCHEME_UNDEFINED,t1,C_SCHEME_FALSE,t3));}}

/* process-fork in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7154(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7154r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7154r(t0,t1,t2);}}

static void C_ccall f_7154r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub1752(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2137 posix-error */
t5=lf[1];
f_2533(5,t5,t1,lf[193],lf[405],lf[406]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(0));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7179,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* g17641765 */
t9=t7;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k7177 in process-fork in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub1769(C_SCHEME_UNDEFINED,C_fix(0)));}

/* glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_7040r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7040r(t0,t1,t2);}}

static void C_ccall f_7040r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_7046(t6,t1,t2);}

/* conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7046(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7046,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7061,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a7066 in conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7067,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7146,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t7=t3;
/* posixunix.scm: 2122 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}
else{
/* posixunix.scm: 2122 make-pathname */
t7=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,C_SCHEME_FALSE,lf[404],t4);}}

/* k7144 in a7066 in conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2122 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7069 in a7066 in conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2123 regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k7072 in k7069 in a7066 in conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7081,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=((C_word*)t0)[5];
/* posixunix.scm: 2124 directory */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}
else{
/* posixunix.scm: 2124 directory */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[403],C_SCHEME_TRUE);}}

/* k7079 in k7072 in k7069 in a7066 in conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7081,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7083,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7083(t5,((C_word*)t0)[2],t1);}

/* loop in k7079 in k7072 in k7069 in a7066 in conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7083(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7083,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* posixunix.scm: 2125 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_7046(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7100,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixunix.scm: 2126 string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k7098 in loop in k7079 in k7072 in k7069 in a7066 in conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7100,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7104,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* g17411742 */
t3=t2;
f_7104(t3,((C_word*)t0)[2],t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* posixunix.scm: 2128 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7083(t3,((C_word*)t0)[2],t2);}}

/* g1741 in k7098 in loop in k7079 in k7072 in k7069 in a7066 in conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_7104(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7104,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7112,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixunix.scm: 2127 make-pathname */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k7110 in g1741 in k7098 in loop in k7079 in k7072 in k7069 in a7066 in conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7116,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 2127 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7083(t4,t2,t3);}

/* k7114 in k7110 in g1741 in k7098 in loop in k7079 in k7072 in k7069 in a7066 in conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7116,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a7060 in conc-loop in glob in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7061,2,t0,t1);}
/* posixunix.scm: 2121 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7032,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub1692(t3),C_fix(0));}

/* k7030 in get-host-name in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7035,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* posixunix.scm: 2103 posix-error */
t3=lf[1];
f_2533(5,t3,t2,lf[393],lf[397],lf[398]);}}

/* k7033 in k7030 in get-host-name in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6993,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6997,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2084 ##sys#terminal-check */
f_6947(t3,lf[392],t2);}

/* k6995 in terminal-size in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6997,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7017,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
t5=*((C_word*)lf[395]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[396]);}

/* k7015 in k6995 in terminal-size in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[395]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[396]);}

/* k7019 in k7015 in k6995 in terminal-size in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_7021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_pointer_argumentp(t3);
t5=(C_word)C_i_foreign_pointer_argumentp(t1);
t6=(C_word)stub1673(C_SCHEME_UNDEFINED,t2,t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* posixunix.scm: 2091 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2092 posix-error */
t8=lf[1];
f_2533(6,t8,((C_word*)t0)[4],lf[393],lf[392],lf[394],((C_word*)t0)[6]);}}

/* terminal-name in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6974,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6978,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2076 ##sys#terminal-check */
f_6947(t3,lf[391],t2);}

/* k6976 in terminal-name in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6978,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-nonnull-c-string */
t5=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1663(t4,t3),C_fix(0));}

/* ##sys#terminal-check in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6947(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6947,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6951,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2068 ##sys#check-port */
t5=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k6949 in ##sys#terminal-check in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[89],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
/* posixunix.scm: 2071 ##sys#error */
t5=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[390],((C_word*)t0)[4]);}}

/* terminal-port? in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6928,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6932,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2063 ##sys#check-port */
t4=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[388]);}

/* k6930 in terminal-port? in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2064 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k6933 in k6930 in terminal-port? in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_tty_portp(((C_word*)t0)[2]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* set-buffering-mode! in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_6869r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_6869r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6869r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6873,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2048 ##sys#check-port */
t6=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[382]);}

/* k6871 in set-buffering-mode! in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6873,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[384]);
if(C_truep(t6)){
t7=t5;
f_6879(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[385]);
if(C_truep(t7)){
t8=C_fix((C_word)_IOLBF);
t9=t5;
f_6879(2,t9,t8);}
else{
t8=(C_word)C_eqp(t4,lf[386]);
if(C_truep(t8)){
t9=t5;
f_6879(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2054 ##sys#error */
t9=*((C_word*)lf[147]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[382],lf[387],((C_word*)t0)[4],((C_word*)t0)[2]);}}}}

/* k6877 in k6871 in set-buffering-mode! in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6879,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[382]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6888,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(7));
t5=(C_word)C_eqp(lf[89],t4);
if(C_truep(t5)){
t6=(C_word)C_setvbuf(((C_word*)t0)[2],t1,((C_word*)t0)[4]);
t7=t3;
f_6888(t7,(C_word)C_fixnum_lessp(t6,C_fix(0)));}
else{
t6=t3;
f_6888(t6,C_SCHEME_TRUE);}}

/* k6886 in k6877 in k6871 in set-buffering-mode! in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2060 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],lf[382],lf[383],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-alarm! in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6866,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub1630(C_SCHEME_UNDEFINED,t2));}

/* _exit in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6850r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6850r(t0,t1,t2);}}

static void C_ccall f_6850r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub1625(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1625(C_SCHEME_UNDEFINED,C_fix(0)));}}

/* local-timezone-abbreviation in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6842,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub1620(t2),C_fix(0));}

/* utc-time->seconds in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6827(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6827,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6831,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2015 check-time-vector */
f_6579(t3,lf[376],t2);}

/* k6829 in utc-time->seconds in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6831,2,t0,t1);}
t2=(C_word)C_a_timegm(&a,1,((C_word*)t0)[3]);
if(C_truep((C_word)C_flonum_equalp(lf[377],t2))){
/* posixunix.scm: 2018 ##sys#error */
t3=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[376],lf[378],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* local-time->seconds in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6812,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6816,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2008 check-time-vector */
f_6579(t3,lf[373],t2);}

/* k6814 in local-time->seconds in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6816,2,t0,t1);}
t2=(C_word)C_a_mktime(&a,1,((C_word*)t0)[3]);
if(C_truep((C_word)C_flonum_equalp(lf[374],t2))){
/* posixunix.scm: 2011 ##sys#error */
t3=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[373],lf[375],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* string->time in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6773(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6773r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6773r(t0,t1,t2,t3);}}

static void C_ccall f_6773r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[372]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[371]);
t7=(C_word)C_i_check_string_2(t5,lf[371]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6790,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2005 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k6788 in string->time in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6794,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2005 ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6792 in k6788 in string->time in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6794,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub1592(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6711(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6711r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6711r(t0,t1,t2,t3);}}

static void C_ccall f_6711r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6718,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1989 check-time-vector */
f_6579(t6,lf[368],t2);}

/* k6716 in time->string in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6718,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[368]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6737,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1993 ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub1556(t4,t3),C_fix(0));}}

/* k6738 in k6716 in time->string in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1997 ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1998 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[368],lf[370],((C_word*)t0)[2]);}}

/* k6735 in k6716 in time->string in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6737,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub1562(t3,t2,t1),C_fix(0));}

/* k6725 in k6716 in time->string in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1994 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[368],lf[369],((C_word*)t0)[2]);}}

/* seconds->string in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6657(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6657r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6657r(t0,t1,t2);}}

static void C_ccall f_6657r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6661,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixunix.scm: 1978 current-seconds */
t4=*((C_word*)lf[364]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=t3;
f_6661(2,t4,(C_word)C_slot(t2,C_fix(0)));}}

/* k6659 in seconds->string in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6661,2,t0,t1);}
t2=(C_word)C_i_check_number_2(t1,lf[366]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6667,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=t1;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub1535(t5,t4),C_fix(0));}

/* k6665 in k6659 in seconds->string in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1982 ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1983 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[366],lf[367],((C_word*)t0)[2]);}}

/* seconds->utc-time in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6625r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6625r(t0,t1,t2);}}

static void C_ccall f_6625r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6629,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixunix.scm: 1972 current-seconds */
t4=*((C_word*)lf[364]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_number_2(t4,lf[365]);
/* posixunix.scm: 1974 ##sys#decode-seconds */
t6=*((C_word*)lf[363]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,C_SCHEME_TRUE);}}

/* k6627 in seconds->utc-time in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_number_2(t1,lf[365]);
/* posixunix.scm: 1974 ##sys#decode-seconds */
t3=*((C_word*)lf[363]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* seconds->local-time in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6598(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_6598r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_6598r(t0,t1,t2);}}

static void C_ccall f_6598r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6602,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t2))){
/* posixunix.scm: 1968 current-seconds */
t4=*((C_word*)lf[364]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_number_2(t4,lf[362]);
/* posixunix.scm: 1970 ##sys#decode-seconds */
t6=*((C_word*)lf[363]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,C_SCHEME_FALSE);}}

/* k6600 in seconds->local-time in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_check_number_2(t1,lf[362]);
/* posixunix.scm: 1970 ##sys#decode-seconds */
t3=*((C_word*)lf[363]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* check-time-vector in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6579(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6579,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1966 ##sys#error */
t6=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[361],t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* memory-mapped-file? in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6573,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[351]));}

/* memory-mapped-file-pointer in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6564(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6564,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[351],lf[358]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6529r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6529r(t0,t1,t2,t3);}}

static void C_ccall f_6529r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[351],lf[356]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6542,a[2]=t6,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t8)){
t9=(C_word)C_i_foreign_pointer_argumentp(t8);
t10=(C_word)stub1482(C_SCHEME_UNDEFINED,t9,t6);
t11=t7;
f_6542(t11,(C_word)C_eqp(C_fix(0),t10));}
else{
t9=(C_word)stub1482(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t6);
t10=t7;
f_6542(t10,(C_word)C_eqp(C_fix(0),t9));}}

/* k6540 in unmap-file-from-memory in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1952 posix-error */
t2=lf[1];
f_2533(7,t2,((C_word*)t0)[4],lf[46],lf[356],lf[357],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* map-file-to-memory in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_6471r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_6471r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_6471r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6475,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_6475(2,t10,t2);}
else{
/* posixunix.scm: 1937 ##sys#null-pointer */
t10=*((C_word*)lf[355]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k6473 in map-file-to-memory in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6475,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6481,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_blockp(t1))){
if(C_truep((C_word)C_specialp(t1))){
t5=t4;
f_6481(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1940 ##sys#signal-hook */
t5=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[57],lf[350],lf[354],t1);}}
else{
/* posixunix.scm: 1940 ##sys#signal-hook */
t5=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[57],lf[350],lf[354],t1);}}

/* k6479 in k6473 in map-file-to-memory in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[7];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=((C_word*)t0)[3];
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
if(C_truep(t3)){
t9=(C_word)C_i_foreign_pointer_argumentp(t3);
t10=t2;
f_6484(t10,(C_word)stub1451(t8,t9,t4,t5,t6,t7,((C_word*)t0)[2]));}
else{
t9=t2;
f_6484(t9,(C_word)stub1451(t8,C_SCHEME_FALSE,t4,t5,t6,t7,((C_word*)t0)[2]));}}

/* k6482 in k6479 in k6473 in map-file-to-memory in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6484(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6484,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6500,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[6],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1942 ##sys#pointer->address */
t4=*((C_word*)lf[353]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k6498 in k6482 in k6479 in k6473 in map-file-to-memory in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6500,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1943 posix-error */
t3=lf[1];
f_2533(11,t3,((C_word*)t0)[10],lf[46],lf[350],lf[352],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,3,lf[351],((C_word*)t0)[2],((C_word*)t0)[8]));}}

/* k6485 in k6482 in k6479 in k6473 in map-file-to-memory in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6487,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[351],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* get-environment-variables in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6393,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6393(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6393(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6393,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6397,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub1433(t5,t4),C_fix(0));}

/* k6395 in loop in get-environment-variables in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6397,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6405,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6405(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k6395 in loop in get-environment-variables in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6405(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6405,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6431,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1901 ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1904 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k6429 in scan in k6395 in loop in get-environment-variables in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6435,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1902 ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k6433 in k6429 in scan in k6395 in loop in get-environment-variables in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6435,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6423,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1903 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6393(t5,t3,t4);}

/* k6421 in k6433 in k6429 in scan in k6395 in loop in get-environment-variables in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6423,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6372,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[338]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6380,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1890 ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6378 in unsetenv in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_unsetenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6355,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[337]);
t5=(C_word)C_i_check_string_2(t3,lf[337]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6366,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1885 ##sys#make-c-string */
t7=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k6364 in setenv in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6370,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1885 ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6368 in k6364 in setenv in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6329(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6329,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6336,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6353,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1873 ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k6351 in fifo? in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1873 ##sys#file-info */
t2=*((C_word*)lf[336]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6334 in fifo? in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1876 posix-error */
t2=lf[1];
f_2533(6,t2,((C_word*)t0)[3],lf[46],lf[84],lf[335],((C_word*)t0)[2]);}}

/* create-fifo in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6286(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6286r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6286r(t0,t1,t2,t3);}}

static void C_ccall f_6286r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[333]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6293,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_6293(t6,(C_word)C_slot(t3,C_fix(0)));}
else{
t6=(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_6293(t7,(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k6291 in create-fifo in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6293(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6293,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[333]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6314,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1867 ##sys#expand-home-path */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k6312 in k6291 in create-fifo in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1867 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6308 in k6291 in create-fifo in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1868 posix-error */
t3=lf[1];
f_2533(7,t3,((C_word*)t0)[3],lf[46],lf[333],lf[334],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* file-unlock in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6258,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[324],lf[331]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1857 posix-error */
t9=lf[1];
f_2533(6,t9,t1,lf[46],lf[331],lf[332],t2);}
else{
t9=C_SCHEME_UNDEFINED;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* file-test-lock in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6231r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6231r(t0,t1,t2,t3);}}

static void C_ccall f_6231r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6235,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1848 setup */
f_6112(t4,t2,t3,lf[329]);}

/* k6233 in file-test-lock in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t2,C_fix(0));
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1850 err */
f_6183(((C_word*)t0)[3],lf[330],t1,lf[329]);}}

/* file-lock/blocking in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6216(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6216r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6216r(t0,t1,t2,t3);}}

static void C_ccall f_6216r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6220,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1842 setup */
f_6112(t4,t2,t3,lf[327]);}

/* k6218 in file-lock/blocking in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1844 err */
f_6183(((C_word*)t0)[2],lf[328],t1,lf[327]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* file-lock in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6201(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6201r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6201r(t0,t1,t2,t3);}}

static void C_ccall f_6201r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6205,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1836 setup */
f_6112(t4,t2,t3,lf[325]);}

/* k6203 in file-lock in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1838 err */
f_6183(((C_word*)t0)[2],lf[326],t1,lf[325]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* err in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6183(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6183,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1833 posix-error */
t8=lf[1];
f_2533(8,t8,t1,lf[46],t4,t2,t5,t6,t7);}

/* setup in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6112(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6112,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_u_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_u_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t8,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6131,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1825 ##sys#check-port */
t16=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}

/* k6129 in setup in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6131,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_6137(t6,t5);}
else{
t5=t3;
f_6137(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k6135 in k6129 in setup in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6137,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[324],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6073,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[321]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6083,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6090,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6097,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6101,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1808 ##sys#expand-home-path */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t7=(C_word)C_ftruncate(t2,t3);
t8=t5;
f_6083(t8,(C_word)C_fixnum_lessp(t7,C_fix(0)));}
else{
/* posixunix.scm: 1810 ##sys#error */
t7=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[321],lf[323],t2);}}}

/* k6099 in file-truncate in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1808 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6095 in file-truncate in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_truncate(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_6083(t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* k6088 in file-truncate in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6083(t2,(C_word)C_fixnum_lessp(t1,C_fix(0)));}

/* k6081 in file-truncate in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 1812 posix-error */
t2=lf[1];
f_2533(7,t2,((C_word*)t0)[4],lf[46],lf[321],lf[322],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr5r,(void*)f_5817r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5817r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5817r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6003,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6008,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6013,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?12741340 */
t10=t9;
f_6013(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi12751338 */
t12=t8;
f_6008(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close12761335 */
t14=t7;
f_6003(t14,t1,t10,t12);}
else{
t14=(C_word)C_u_i_car(t13);
t15=(C_word)C_slot(t13,C_fix(1));
/* body12721281 */
t16=t6;
f_5819(t16,t1,t10,t12,t14);}}}}

/* def-nonblocking?1274 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6013(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6013,NULL,2,t0,t1);}
/* def-bufi12751338 */
t2=((C_word*)t0)[2];
f_6008(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1275 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6008(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6008,NULL,3,t0,t1,t2);}
/* def-on-close12761335 */
t3=((C_word*)t0)[2];
f_6003(t3,t1,t2,C_fix(0));}

/* def-on-close1276 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_6003(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6003,NULL,4,t0,t1,t2,t3);}
/* body12721281 */
t4=((C_word*)t0)[2];
f_5819(t4,t1,t2,t3,*((C_word*)lf[316]+1));}

/* body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5819(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5819,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5823,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1750 ##sys#file-nonblocking! */
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_5823(2,t6,C_SCHEME_UNDEFINED);}}

/* k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5823,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5825,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_5871(t11,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5915,a[2]=t3,tmp=(C_word)a,a+=3,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5929,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1769 ##sys#make-string */
t12=*((C_word*)lf[314]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_5929(2,t12,((C_word*)t0)[6]);}}}

/* k5927 in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5929,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_5871(t4,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5930,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));}

/* f_5930 in k5927 in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5930,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5947,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_5947(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1785 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5825(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_5947(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5947,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5957,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1775 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_5825(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_difference(t4,t2);
/* posixunix.scm: 1780 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k5955 in loop */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1777 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_5947(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_5915 in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5915,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1768 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5825(t4,t1,t2,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5869 in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5871(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5871,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5875,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5880,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5886,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5907,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1788 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t5,t6,t7,t8);}

/* a5906 in k5869 in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5907,2,t0,t1);}
/* posixunix.scm: 1798 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* a5885 in k5869 in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5886,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5896,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1795 posix-error */
t3=lf[1];
f_2533(7,t3,t2,lf[46],((C_word*)t0)[3],lf[320],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1796 on-close */
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}}

/* k5894 in a5885 in k5869 in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1796 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a5879 in k5869 in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5880,3,t0,t1,t2);}
/* posixunix.scm: 1790 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* k5873 in k5869 in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5875,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5878,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1799 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k5876 in k5873 in k5869 in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5825(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5825,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5841,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1758 ##sys#thread-yield! */
t8=*((C_word*)lf[306]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1760 posix-error */
t7=lf[1];
f_2533(7,t7,t1,((C_word*)t0)[3],lf[46],lf[319],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5860,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1762 ##sys#substring */
t7=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k5858 in poke in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1762 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5825(t3,((C_word*)t0)[2],t1,t2);}

/* k5839 in poke in k5821 in body1272 in ##sys#custom-output-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1759 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5825(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr5r,(void*)f_5338r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5338r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5338r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(19);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5727,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5732,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5737,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5742,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?11011245 */
t11=t10;
f_5742(t11,t1);}
else{
t11=(C_word)C_u_i_car(t5);
t12=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi11021243 */
t13=t9;
f_5737(t13,t1,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close11031240 */
t15=t8;
f_5732(t15,t1,t11,t13);}
else{
t15=(C_word)C_u_i_car(t14);
t16=(C_word)C_slot(t14,C_fix(1));
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?11041236 */
t17=t7;
f_5727(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_u_i_car(t16);
t18=(C_word)C_slot(t16,C_fix(1));
/* body10991109 */
t19=t6;
f_5340(t19,t1,t11,t13,t15,t17);}}}}}

/* def-nonblocking?1101 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5742(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5742,NULL,2,t0,t1);}
/* def-bufi11021243 */
t2=((C_word*)t0)[2];
f_5737(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1102 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5737(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5737,NULL,3,t0,t1,t2);}
/* def-on-close11031240 */
t3=((C_word*)t0)[2];
f_5732(t3,t1,t2,C_fix(1));}

/* def-on-close1103 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5732(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5732,NULL,4,t0,t1,t2,t3);}
/* def-more?11041236 */
t4=((C_word*)t0)[2];
f_5727(t4,t1,t2,t3,*((C_word*)lf[316]+1));}

/* def-more?1104 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5727(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5727,NULL,5,t0,t1,t2,t3,t4);}
/* body10991109 */
t5=((C_word*)t0)[2];
f_5340(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5340(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5340,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5344,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1624 ##sys#file-nonblocking! */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_5344(2,t7,C_SCHEME_UNDEFINED);}}

/* k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5344,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1626 ##sys#make-string */
t5=*((C_word*)lf[314]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_5350(2,t5,((C_word*)t0)[10]);}}

/* k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5350,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5351,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5374,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5382,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5464,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5469,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5482,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5494,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5515,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5524,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5600,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1674 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)(void*)(*((C_word*)t18+1)))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a5599 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5600,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5606,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_5606(t7,t1,C_SCHEME_FALSE);}

/* loop in a5599 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5606(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5606,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5608,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5686,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5702,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1739 fetch */
t5=((C_word*)t0)[5];
f_5382(t5,t4);}}

/* k5700 in loop in a5599 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1741 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5606(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a5691 in loop in a5599 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5692,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1736 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5606(t4,t1,t2);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* a5685 in loop in a5599 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5686,2,t0,t1);}
/* posixunix.scm: 1734 ##sys#scan-buffer-line */
t2=*((C_word*)lf[315]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a5599 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5608,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5615,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_5615(2,t8,(C_truep(t7)?t7:lf[312]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5658,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1716 ##sys#make-string */
t8=*((C_word*)lf[314]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k5656 in bumper in loop in a5599 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_u_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1722 ##sys#string-append */
t6=*((C_word*)lf[313]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=t1;
t7=((C_word*)t0)[2];
f_5615(2,t7,t6);}}

/* k5613 in bumper in loop in a5599 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5615,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5625,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1726 fetch */
t5=((C_word*)t0)[3];
f_5382(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_u_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1731 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k5623 in k5613 in bumper in loop in a5599 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1727 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5523 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5524,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5532,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_5532(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_5532(t8,(C_word)C_u_fixnum_difference(t7,t5));}}

/* k5530 in a5523 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5532,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5534,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5534(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k5530 in a5523 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5534(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5534,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_u_fixnum_difference(t2,t8);
t14=(C_word)C_u_fixnum_plus(t3,t8);
t15=(C_word)C_u_fixnum_plus(t4,t8);
/* posixunix.scm: 1702 loop */
t19=t1;
t20=t13;
t21=t14;
t22=t15;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5582,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1704 fetch */
t7=((C_word*)t0)[2];
f_5382(t7,t6);}}}

/* k5580 in loop in k5530 in a5523 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* posixunix.scm: 1707 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5534(t3,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* a5514 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5519,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1692 fetch */
t3=((C_word*)t0)[2];
f_5382(t3,t2);}

/* k5517 in a5514 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1693 peek */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_5374(((C_word*)t0)[2]));}

/* a5493 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5504,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1689 posix-error */
t3=lf[1];
f_2533(7,t3,t2,lf[46],((C_word*)t0)[3],lf[311],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1690 on-close */
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}}

/* k5502 in a5493 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1690 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a5481 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5482,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1684 ready? */
t3=((C_word*)t0)[2];
f_5351(t3,t1);}}

/* a5468 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5473,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1676 fetch */
t3=((C_word*)t0)[2];
f_5382(t3,t2);}

/* k5471 in a5468 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_5374(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k5462 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5464,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5467,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1743 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k5465 in k5462 in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5382,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5394,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5394(t5,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop in fetch in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5394(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5394,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5410,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1651 ##sys#thread-block-for-i/o! */
t6=*((C_word*)lf[307]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[308]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1654 posix-error */
t5=lf[1];
f_2533(7,t5,t1,lf[46],((C_word*)t0)[6],lf[309],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5431,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1658 more? */
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k5429 in loop in fetch in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5431,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5434,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1660 ##sys#thread-yield! */
t3=*((C_word*)lf[306]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5440,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t3)[1]);
t9=C_set_block_item(((C_word*)t0)[4],0,C_fix(0));
t10=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
/* posixunix.scm: 1666 posix-error */
t7=lf[1];
f_2533(7,t7,t4,lf[46],((C_word*)t0)[3],lf[310],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t3)[1]);
t7=C_set_block_item(((C_word*)t0)[4],0,C_fix(0));
t8=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}}

/* k5438 in k5429 in loop in fetch in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5432 in k5429 in loop in fetch in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1661 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5394(t2,((C_word*)t0)[2]);}

/* k5408 in loop in fetch in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1652 ##sys#thread-yield! */
t3=*((C_word*)lf[306]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5411 in k5408 in loop in fetch in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1653 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5394(t2,((C_word*)t0)[2]);}

/* peek in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_5374(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]))){
return(C_SCHEME_END_OF_FILE);}
else{
t1=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);
return(t1);}}

/* ready? in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5351(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5351,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1632 ##sys#file-select-one */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5353 in ready? in k5348 in k5342 in body1099 in ##sys#custom-input-port in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* posixunix.scm: 1636 posix-error */
t4=lf[1];
f_2533(7,t4,((C_word*)t0)[5],lf[46],((C_word*)t0)[4],lf[305],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t1));}}

/* duplicate-fileno in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5311r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5311r(t0,t1,t2,t3);}}

static void C_ccall f_5311r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[300]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5318,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_5318(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[300]);
t8=t5;
f_5318(t8,(C_word)C_dup2(t2,t6));}}

/* k5316 in duplicate-fileno in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5318,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5321,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1617 posix-error */
t3=lf[1];
f_2533(6,t3,t2,lf[46],lf[300],lf[301],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k5319 in k5316 in duplicate-fileno in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5266,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5270,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1599 ##sys#check-port */
t4=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[294]);}

/* k5268 in port->fileno in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5270,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[295],t2);
if(C_truep(t3)){
/* posixunix.scm: 1600 ##sys#tcp-port->fileno */
t4=*((C_word*)lf[296]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5305,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1601 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[299]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k5303 in k5268 in port->fileno in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5305,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1606 posix-error */
t2=lf[1];
f_2533(6,t2,((C_word*)t0)[3],lf[57],lf[294],lf[297],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5288,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1604 posix-error */
t4=lf[1];
f_2533(6,t4,t3,lf[46],lf[294],lf[298],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}}

/* k5286 in k5303 in k5268 in port->fileno in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5252r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5252r(t0,t1,t2,t3);}}

static void C_ccall f_5252r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[293]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5264,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1595 mode */
f_5186(t5,C_SCHEME_FALSE,t3);}

/* k5262 in open-output-file* in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5264,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1595 check */
f_5223(((C_word*)t0)[2],lf[293],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5238(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5238r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5238r(t0,t1,t2,t3);}}

static void C_ccall f_5238r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[292]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5250,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1591 mode */
f_5186(t5,C_SCHEME_TRUE,t3);}

/* k5248 in open-input-file* in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5250,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1591 check */
f_5223(((C_word*)t0)[2],lf[292],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5223(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5223,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1584 posix-error */
t6=lf[1];
f_2533(6,t6,t1,lf[46],t2,lf[290],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5236,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1585 ##sys#make-port */
t7=*((C_word*)lf[141]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[142]+1),lf[291],lf[89]);}}

/* k5234 in check in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* mode in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5186(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5186,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5194,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[284]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1578 ##sys#error */
t8=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[285],t5);}
else{
/* posixunix.scm: 1574 ##sys#make-c-string */
t8=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,lf[286]);}}
else{
/* posixunix.scm: 1579 ##sys#error */
t7=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[287],t5);}}
else{
if(C_truep(t2)){
/* posixunix.scm: 1574 ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[288]);}
else{
/* posixunix.scm: 1574 ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[289]);}}}

/* k5192 in mode in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1574 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5161,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[278]);
t5=(C_word)C_i_check_string_2(t3,lf[278]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5174,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=t3;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5150,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
/* ##sys#make-c-string */
t10=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t7);}
else{
t10=t9;
f_5150(2,t10,C_SCHEME_FALSE);}}

/* k5148 in file-link in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5154,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=(C_word)stub1014(C_SCHEME_UNDEFINED,t1,C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
f_5174(t4,(C_word)C_fixnum_lessp(t3,C_fix(0)));}}

/* k5152 in k5148 in file-link in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1014(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_5174(t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* k5172 in file-link in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_5174(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 1559 posix-error */
t2=lf[1];
f_2533(7,t2,((C_word*)t0)[4],lf[46],lf[279],lf[280],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* read-symbolic-link in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5092r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5092r(t0,t1,t2,t3);}}

static void C_ccall f_5092r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(10);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[275]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5103,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5131,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1545 ##sys#expand-home-path */
t9=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k5129 in read-symbolic-link in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1545 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5101 in read-symbolic-link in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5103,2,t0,t1);}
t2=(C_word)C_do_readlink(t1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5106,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1547 posix-error */
t4=lf[1];
f_2533(6,t4,t3,lf[46],lf[275],lf[277],((C_word*)t0)[2]);}
else{
t4=t3;
f_5106(2,t4,C_SCHEME_UNDEFINED);}}

/* k5104 in k5101 in read-symbolic-link in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5109,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1548 substring */
t3=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5107 in k5104 in k5101 in read-symbolic-link in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5115,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 1549 symbolic-link? */
t3=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t3=t1;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5113 in k5107 in k5104 in k5101 in read-symbolic-link in k5089 in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 1550 read-symbolic-link */
t2=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[276]);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* create-symbolic-link in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5054,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[271]);
t5=(C_word)C_i_check_string_2(t3,lf[271]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5075,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5087,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1533 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5085 in create-symbolic-link in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1533 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5073 in create-symbolic-link in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5083,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1534 ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5081 in k5073 in create-symbolic-link in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1534 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5077 in k5073 in create-symbolic-link in k5050 in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1536 posix-error */
t3=lf[1];
f_2533(7,t3,((C_word*)t0)[4],lf[46],lf[272],lf[273],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* create-session in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5035,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5039,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5045,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1504 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k5043 in create-session in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1505 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[268],lf[269]);}

/* k5037 in create-session in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5029,3,t0,t1,t2);}
/* posixunix.scm: 1499 check */
f_4993(t1,t2,C_fix((C_word)X_OK),lf[267]);}

/* file-write-access? in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5023,3,t0,t1,t2);}
/* posixunix.scm: 1498 check */
f_4993(t1,t2,C_fix((C_word)W_OK),lf[266]);}

/* file-read-access? in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5017(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5017,3,t0,t1,t2);}
/* posixunix.scm: 1497 check */
f_4993(t1,t2,C_fix((C_word)R_OK),lf[265]);}

/* check in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4993(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4993,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5011,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5015,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1494 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5013 in check in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1494 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5009 in check in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
t2=(C_word)C_test_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5003,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* posixunix.scm: 1495 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5001 in k5009 in check in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4963,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[263]);
t6=(C_word)C_i_check_exact_2(t3,lf[263]);
t7=(C_word)C_i_check_exact_2(t4,lf[263]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4987,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4991,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1484 ##sys#expand-home-path */
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k4989 in change-file-owner in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1484 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4985 in change-file-owner in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1485 posix-error */
t3=lf[1];
f_2533(8,t3,((C_word*)t0)[3],lf[46],lf[263],lf[264],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* change-file-mode in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4936,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[261]);
t5=(C_word)C_i_check_exact_2(t3,lf[261]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4957,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4961,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1476 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k4959 in change-file-mode in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1476 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4955 in change-file-mode in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1477 posix-error */
t3=lf[1];
f_2533(7,t3,((C_word*)t0)[3],lf[46],lf[261],lf[262],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* initialize-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4872,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[220]);
t5=(C_word)C_i_check_exact_2(t3,lf[220]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4885,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=t3;
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4868,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t7)){
/* ##sys#make-c-string */
t10=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t7);}
else{
t10=(C_word)stub920(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t8);
t11=t6;
f_4885(t11,(C_word)C_fixnum_lessp(t10,C_fix(0)));}}

/* k4866 in initialize-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub920(C_SCHEME_UNDEFINED,t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4885(t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* k4883 in initialize-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4885,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1397 ##sys#update-errno */
t3=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4886 in k4883 in initialize-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1398 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[220],lf[221],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4806,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4810,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
if(C_truep((C_word)stub877(C_SCHEME_UNDEFINED,t4))){
t5=t3;
f_4810(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1380 ##sys#error */
t5=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[217],lf[219]);}}

/* k4808 in set-groups! in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4815,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4815(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop903 in k4808 in set-groups! in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4815(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4815,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4831,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1385 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[217]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k4829 in doloop903 in k4808 in set-groups! in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1386 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[217],lf[218],((C_word*)t0)[2]);}

/* get-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4743,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4747,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4801,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1366 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_4747(2,t4,C_SCHEME_UNDEFINED);}}

/* k4799 in get-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1367 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[213],lf[216]);}

/* k4745 in get-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)stub877(C_SCHEME_UNDEFINED,((C_word*)t0)[3]))){
t3=t2;
f_4750(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1369 ##sys#error */
t3=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[213],lf[215]);}}

/* k4748 in k4745 in get-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)stub873(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4782,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1371 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_4753(2,t4,C_SCHEME_UNDEFINED);}}

/* k4780 in k4748 in k4745 in get-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1372 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[213],lf[214]);}

/* k4751 in k4748 in k4745 in get-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4753,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4758,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4758(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k4751 in k4748 in k4745 in get-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4758(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4758,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4772,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1376 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k4770 in loop in k4751 in k4748 in k4745 in get-groups in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4772,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* group-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4665r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4665r(t0,t1,t2,t3);}}

static void C_ccall f_4665r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4672,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_4672(t7,(C_word)C_getgrgid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[212]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4723,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1340 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k4721 in group-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4672(t2,(C_word)C_getgrnam(t1));}

/* k4670 in group-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4672,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[3])?*((C_word*)lf[209]+1):*((C_word*)lf[210]+1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t4=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4683 in k4670 in group-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4689,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k4687 in k4683 in k4670 in group-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4693,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4695,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4695(t6,t2,C_fix(0));}

/* loop in k4687 in k4683 in k4670 in group-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4695(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4695,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4699,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub844(t5,t4),C_fix(0));}

/* k4697 in loop in k4687 in k4683 in k4670 in group-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4699,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4709,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1349 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4695(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k4707 in k4697 in loop in k4687 in k4683 in k4670 in group-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4709,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4691 in k4687 in k4683 in k4670 in group-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g866867 */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4653,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4657,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1325 current-effective-user-id */
t4=*((C_word*)lf[205]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4655 in current-effective-user-name in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1325 user-information */
t2=*((C_word*)lf[208]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4651 in current-effective-user-name in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_car(t1));}

/* current-user-name in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4639,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4643,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1322 current-user-id */
t4=*((C_word*)lf[204]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4641 in current-user-name in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1322 user-information */
t2=*((C_word*)lf[208]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4637 in current-user-name in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_car(t1));}

/* user-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4571r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4571r(t0,t1,t2,t3);}}

static void C_ccall f_4571r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4578,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_4578(t7,(C_word)C_getpwuid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[208]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4617,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1310 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k4615 in user-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4578(t2,(C_word)C_getpwnam(t1));}

/* k4576 in user-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4578,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[3])?*((C_word*)lf[209]+1):*((C_word*)lf[210]+1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4591,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t4=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4589 in k4576 in user-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4595,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k4593 in k4589 in k4576 in user-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4599,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k4597 in k4593 in k4589 in k4576 in user-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4603,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k4601 in k4597 in k4593 in k4589 in k4576 in user-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4607,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k4605 in k4601 in k4597 in k4593 in k4589 in k4576 in user-information in k4567 in k4563 in k4559 in k4555 in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g839840 */
t2=((C_word*)t0)[7];
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* system-information in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4521,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4550,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1255 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_4521(2,t3,C_SCHEME_UNDEFINED);}}

/* k4548 in system-information in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1256 ##sys#error */
t2=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[201],lf[203]);}

/* k4519 in system-information in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4528,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k4526 in k4519 in system-information in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4532,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k4530 in k4526 in k4519 in system-information in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4536,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k4534 in k4530 in k4526 in k4519 in system-information in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4540,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k4538 in k4534 in k4530 in k4526 in k4519 in system-information in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4544,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k4542 in k4538 in k4534 in k4530 in k4526 in k4519 in system-information in k4513 in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4544,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4499,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[199]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1234 posix-error */
t5=lf[1];
f_2533(5,t5,t1,lf[193],lf[199],lf[200]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* signal-mask! in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4484,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[197]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1228 posix-error */
t5=lf[1];
f_2533(5,t5,t1,lf[193],lf[197],lf[198]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* signal-masked? in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4478,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[196]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4452,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4452(t5,t1,*((C_word*)lf[188]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4452(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4452,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_sigismember(t4))){
t6=(C_word)C_a_i_cons(&a,2,t4,t3);
/* posixunix.scm: 1218 loop */
t10=t1;
t11=t5;
t12=t6;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
t6=t3;
/* posixunix.scm: 1218 loop */
t10=t1;
t11=t5;
t12=t6;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}}

/* set-signal-mask! in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4400,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[192]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4418,tmp=(C_word)a,a+=2,tmp);
t6=f_4418(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1211 posix-error */
t7=lf[1];
f_2533(5,t7,t1,lf[193],lf[192],lf[194]);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* loop753 in set-signal-mask! in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_4418(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_i_check_exact_2(t2,lf[192]);
t4=(C_word)C_sigaddset(t2);
t5=(C_word)C_slot(t1,C_fix(1));
t8=t5;
t1=t8;
goto loop;}
else{
t2=C_SCHEME_UNDEFINED;
return(t2);}}

/* ##sys#interrupt-hook in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4382,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4392,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1197 h */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1199 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k4390 in ##sys#interrupt-hook in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1198 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4369,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[191]);
if(C_truep(t3)){
t5=t2;
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}
else{
t5=(C_word)C_establish_signal_handler(t2,C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}}

/* signal-handler in k4356 in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4360,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[190]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4317,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1114 posix-error */
t3=lf[1];
f_2533(5,t3,t2,lf[46],lf[161],lf[162]);}
else{
/* posixunix.scm: 1115 values */
C_values(4,0,t1,C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}}

/* k4315 in create-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1115 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4293r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4293r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4293r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[160]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4297,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4295 in with-output-to-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4297,2,t0,t1);}
t2=C_mutate((C_word*)lf[160]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4303,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1102 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4302 in k4295 in with-output-to-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4303r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4303r(t0,t1,t2);}}

static void C_ccall f_4303r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4307,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1104 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4305 in a4302 in k4295 in with-output-to-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[160]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_4273r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4273r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4273r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[158]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4277,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k4275 in with-input-from-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4277,2,t0,t1);}
t2=C_mutate((C_word*)lf[158]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4283,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1092 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a4282 in k4275 in with-input-from-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4283r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4283r(t0,t1,t2);}}

static void C_ccall f_4283r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4287,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1094 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4285 in a4282 in k4275 in with-input-from-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[158]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4249r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4249r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4249r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4253,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4251 in call-with-output-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4258,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4264,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1082 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4263 in k4251 in call-with-output-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4264r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4264r(t0,t1,t2);}}

static void C_ccall f_4264r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4268,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1085 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4266 in a4263 in k4251 in call-with-output-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4257 in k4251 in call-with-output-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4258,2,t0,t1);}
/* posixunix.scm: 1083 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4225r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4225r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4225r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4229,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k4227 in call-with-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4234,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4240,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1074 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4239 in k4227 in call-with-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4240r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4240r(t0,t1,t2);}}

static void C_ccall f_4240r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4244,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1077 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4242 in a4239 in k4227 in call-with-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4233 in k4227 in call-with-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
/* posixunix.scm: 1075 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4209,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4213,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1061 ##sys#check-port */
t4=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[150]);}

/* k4211 in close-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4213,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4216,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1063 posix-error */
t5=lf[1];
f_2533(6,t5,t3,lf[46],lf[151],lf[152],((C_word*)t0)[3]);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k4214 in k4211 in close-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4173r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4173r(t0,t1,t2,t3);}}

static void C_ccall f_4173r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_string_2(t2,lf[149]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[145]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4187,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[145]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4194,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1056 ##sys#make-c-string */
t10=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[146]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4204,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1057 ##sys#make-c-string */
t11=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixunix.scm: 1030 ##sys#error */
t10=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,lf[148],t6);}}}

/* k4202 in open-output-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=(C_word)open_binary_output_pipe(&a,1,t1);
/* posixunix.scm: 1052 check */
f_4122(((C_word*)t0)[3],lf[149],((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* k4192 in open-output-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4194,2,t0,t1);}
t2=(C_word)open_text_output_pipe(&a,1,t1);
/* posixunix.scm: 1052 check */
f_4122(((C_word*)t0)[3],lf[149],((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* k4185 in open-output-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1052 check */
f_4122(((C_word*)t0)[3],lf[149],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4137r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4137r(t0,t1,t2,t3);}}

static void C_ccall f_4137r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_string_2(t2,lf[144]);
t5=(C_word)C_i_pairp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):lf[145]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4151,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_eqp(t6,lf[145]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4158,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1045 ##sys#make-c-string */
t10=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=(C_word)C_eqp(t6,lf[146]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4168,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1046 ##sys#make-c-string */
t11=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t2);}
else{
/* posixunix.scm: 1030 ##sys#error */
t10=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,lf[148],t6);}}}

/* k4166 in open-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=(C_word)open_binary_input_pipe(&a,1,t1);
/* posixunix.scm: 1041 check */
f_4122(((C_word*)t0)[3],lf[144],((C_word*)t0)[2],C_SCHEME_TRUE,t2);}

/* k4156 in open-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4158,2,t0,t1);}
t2=(C_word)open_text_input_pipe(&a,1,t1);
/* posixunix.scm: 1041 check */
f_4122(((C_word*)t0)[3],lf[144],((C_word*)t0)[2],C_SCHEME_TRUE,t2);}

/* k4149 in open-input-pipe in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1041 check */
f_4122(((C_word*)t0)[3],lf[144],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_4122(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4122,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1033 posix-error */
t6=lf[1];
f_2533(6,t6,t1,lf[46],t2,lf[140],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4135,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1034 ##sys#make-port */
t7=*((C_word*)lf[141]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[142]+1),lf[143],lf[89]);}}

/* k4133 in check in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3787(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3787,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[122]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3794,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3908,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 978  cwd */
t8=((C_word*)t0)[6];
f_3731(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=t4,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4094,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 980  sref */
t10=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_3914(t9,C_SCHEME_FALSE);}}}

/* k4092 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3914(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3914,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
t3=((C_word*)t0)[9];
f_3794(2,t3,t2);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 983  cwd */
t5=((C_word*)t0)[7];
f_3731(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4069,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4080,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 984  sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k4078 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 984  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k4067 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4069,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 985  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[4];
f_3933(t2,C_SCHEME_FALSE);}}

/* k4074 in k4067 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3933(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3933(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3933,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 987  get-environment-variable */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[137]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 992  cwd */
t5=((C_word*)t0)[5];
f_3731(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4062,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 993  sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k4060 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 993  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4039 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4041,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4058,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 994  sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3977(t2,C_SCHEME_FALSE);}}

/* k4056 in k4039 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 994  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4045 in k4039 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 995  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3977(t2,C_SCHEME_FALSE);}}

/* k4052 in k4045 in k4039 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=((C_word*)t0)[2];
f_3977(t3,(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* k3975 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3977,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[8]);
/* posixunix.scm: 996  ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[7],((C_word*)t0)[8],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4038,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 997  sref */
t5=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k4036 in k3975 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 997  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k4015 in k3975 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4017,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4034,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 998  sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_3990(2,t2,C_SCHEME_FALSE);}}

/* k4032 in k4015 in k3975 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 998  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4021 in k4015 in k3975 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4023,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4030,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 999  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_3990(2,t2,C_SCHEME_FALSE);}}

/* k4028 in k4021 in k4015 in k3975 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 999  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k3988 in k3975 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[6]);
/* posixunix.scm: 1000 ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[5],((C_word*)t0)[6],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1001 sref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[6],C_fix(0));}}

/* k4012 in k3988 in k3975 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4014,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
f_3794(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1004 cwd */
t5=((C_word*)t0)[2];
f_3731(t5,t4);}}

/* k4008 in k4012 in k3988 in k3975 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1004 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[139],((C_word*)t0)[2]);}

/* k3969 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 992  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[138],((C_word*)t0)[2]);}

/* k3938 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_3943(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3958,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 988  user */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3956 in k3938 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 988  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[136],t1);}

/* k3941 in k3938 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3947,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 989  ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k3945 in k3941 in k3938 in k3931 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 986  sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3925 in k3912 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 983  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[135],((C_word*)t0)[2]);}

/* k3906 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 978  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[134]);}

/* k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=t1;
t4=*((C_word*)lf[132]+1);
/* g580581 */
t5=t4;
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,lf[133]);}

/* k3799 in k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3801,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3803(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k3799 in k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3803(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3803,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1007 null? */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3808 in loop in k3799 in k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3810,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3816,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1008 null? */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 1019 string=? */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[131],t4);}}

/* k3872 in k3808 in loop in k3799 in k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* posixunix.scm: 1017 loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3803(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 1021 string=? */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[130],t3);}}

/* k3881 in k3872 in k3808 in loop in k3799 in k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
/* posixunix.scm: 1017 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3803(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[6]);
/* posixunix.scm: 1017 loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3803(t4,((C_word*)t0)[4],((C_word*)t0)[3],t3);}}

/* k3814 in k3808 in loop in k3799 in k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3816,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[123]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3852,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 1010 sref */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k3850 in k3814 in k3808 in loop in k3799 in k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3852,2,t0,t1);}
t2=(C_word)C_eqp(C_make_character(47),t1);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3829,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3833,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_a_i_cons(&a,2,lf[127],((C_word*)t0)[2]);
/* posixunix.scm: 1013 reverse */
t7=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3844,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3848,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1016 reverse */
t6=*((C_word*)lf[128]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k3846 in k3850 in k3814 in k3808 in loop in k3799 in k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[125]+1);
/* g589590 */
t3=t2;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,lf[126]);}

/* k3842 in k3850 in k3814 in k3808 in loop in k3799 in k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1014 sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[129],t1);}

/* k3831 in k3850 in k3814 in k3808 in loop in k3799 in k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[125]+1);
/* g589590 */
t3=t2;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,lf[126]);}

/* k3827 in k3850 in k3814 in k3808 in loop in k3799 in k3792 in canonical-path in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1011 sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[124],t1);}

/* cwd in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3731(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3731,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3735,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3740,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a3739 in cwd in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3740,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3746,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3764,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a3763 in a3739 in cwd in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a3775 in a3763 in a3739 in cwd in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3776(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3776r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3776r(t0,t1,t2);}}

static void C_ccall f_3776r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3782,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k605610 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a3781 in a3775 in a3763 in a3739 in cwd in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3782,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3769 in a3763 in a3739 in cwd in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3770,2,t0,t1);}
/* posixunix.scm: 973  cw */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a3745 in a3739 in cwd in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3746,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3752,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k605610 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a3751 in a3745 in a3739 in cwd in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3752,2,t0,t1);}
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[2],lf[118]))){
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[119]);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[119]);}}

/* k3733 in cwd in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g608609 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* current-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3674(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3674r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3674r(t0,t1,t2);}}

static void C_ccall f_3674r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
/* posixunix.scm: 952  change-directory */
t5=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3687,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 953  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}}

/* k3685 in current-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 956  ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 957  posix-error */
t3=lf[1];
f_2533(5,t3,((C_word*)t0)[2],lf[46],lf[109],lf[111]);}}

/* directory? in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3648,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[110]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3672,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 946  ##sys#expand-home-path */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3670 in directory? in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3672,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3665,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 876  ##sys#make-c-string */
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k3663 in k3670 in directory? in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_stat(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_mk_bool(C_isdir);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_3494r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3494r(t0,t1,t2);}}

static void C_ccall f_3494r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3594,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3599,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec487528 */
t6=t5;
f_3599(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?488526 */
t8=t4;
f_3594(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body485493 */
t10=t3;
f_3496(t10,t1,t6,t8);}}}

/* def-spec487 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3599,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3607,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 919  current-directory */
t3=*((C_word*)lf[109]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3605 in def-spec487 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?488526 */
t2=((C_word*)t0)[3];
f_3594(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?488 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3594(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3594,NULL,3,t0,t1,t2);}
/* body485493 */
t3=((C_word*)t0)[2];
f_3496(t3,t1,t2,C_SCHEME_FALSE);}

/* body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3496(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3496,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[106]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3503,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 921  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}

/* k3501 in body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 922  ##sys#make-pointer */
t3=*((C_word*)lf[108]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3504 in k3501 in body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 923  ##sys#make-pointer */
t3=*((C_word*)lf[108]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3507 in k3504 in k3501 in body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3593,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 924  ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k3591 in k3507 in k3504 in k3501 in body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 924  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3511 in k3507 in k3504 in k3501 in body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3513,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 926  posix-error */
t3=lf[1];
f_2533(6,t3,((C_word*)t0)[7],lf[46],lf[106],lf[107],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3527(t6,((C_word*)t0)[7]);}}

/* loop in k3511 in k3507 in k3504 in k3501 in body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3527(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3527,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 934  ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k3535 in loop in k3511 in k3507 in k3504 in k3501 in body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 935  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(0));}

/* k3538 in k3535 in loop in k3511 in k3507 in k3504 in k3501 in body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3543,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 936  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_3543(2,t3,C_SCHEME_FALSE);}}

/* k3541 in k3538 in k3535 in loop in k3511 in k3507 in k3504 in k3501 in body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3549,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_3549(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]);
t7=t2;
f_3549(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}
else{
t6=t2;
f_3549(t6,(C_word)C_i_not(((C_word*)t0)[2]));}}}
else{
t4=t2;
f_3549(t4,C_SCHEME_FALSE);}}

/* k3547 in k3541 in k3538 in k3535 in loop in k3511 in k3507 in k3504 in k3501 in body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3549,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 941  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3527(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 942  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3527(t3,t2);}}

/* k3557 in k3547 in k3541 in k3538 in k3535 in loop in k3511 in k3507 in k3504 in k3501 in body485 in directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3472,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[102]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3479,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3492,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 910  ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3490 in delete-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 910  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3477 in delete-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3482,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(0),(C_word)C_rmdir(t1));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
/* posixunix.scm: 912  posix-error */
t4=lf[1];
f_2533(6,t4,t2,lf[46],lf[102],lf[103],t1);}}

/* k3480 in k3477 in delete-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3450,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[100]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3457,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3470,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 902  ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3468 in change-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 902  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3455 in change-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3460,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(C_fix(0),(C_word)C_chdir(t1));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
/* posixunix.scm: 904  posix-error */
t4=lf[1];
f_2533(6,t4,t2,lf[46],lf[100],lf[101],t1);}}

/* k3458 in k3455 in change-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3298r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3298r(t0,t1,t2,t3);}}

static void C_ccall f_3298r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[97]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 888  ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3311,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_block_size(t1);
t4=(C_word)C_eqp(C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_3317(t6,t4);}
else{
t6=t1;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3429,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 876  ##sys#make-c-string */
t8=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}}

/* k3427 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_stat(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_mk_bool(C_isdir);
t5=((C_word*)t0)[2];
f_3317(t5,t4);}
else{
t4=((C_word*)t0)[2];
f_3317(t4,C_SCHEME_FALSE);}}

/* k3315 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3317,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3390,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3413,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 880  ##sys#make-c-string */
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}

/* k3411 in k3315 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_mkdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}
else{
/* posixunix.scm: 881  posix-error */
t4=lf[1];
f_2533(6,t4,((C_word*)t0)[3],lf[46],lf[97],lf[98],((C_word*)t0)[2]);}}

/* a3389 in k3315 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3390,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
/* posixunix.scm: 892  make-pathname */
t5=*((C_word*)lf[99]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,t4);}
else{
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* a3383 in k3315 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
/* posixunix.scm: 891  decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k3325 in k3315 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3329,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3329(t5,((C_word*)t0)[2],t1);}

/* loop in k3325 in k3315 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3329(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3329,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t2;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3379,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 876  ##sys#make-c-string */
t6=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=t3;
f_3336(t4,C_SCHEME_FALSE);}}

/* k3377 in loop in k3325 in k3315 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_stat(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_mk_bool(C_isdir);
t5=((C_word*)t0)[2];
f_3336(t5,(C_word)C_i_not(t4));}
else{
t4=((C_word*)t0)[2];
f_3336(t4,C_SCHEME_TRUE);}}

/* k3334 in loop in k3325 in k3315 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3336(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3336,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3362,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 894  pathname-directory */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3360 in k3334 in loop in k3325 in k3315 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 894  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3329(t2,((C_word*)t0)[2],t1);}

/* k3337 in k3334 in loop in k3325 in k3315 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3355,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 880  ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3353 in k3337 in k3334 in loop in k3325 in k3315 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_mkdir(t1);
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* posixunix.scm: 881  posix-error */
t4=lf[1];
f_2533(6,t4,((C_word*)t0)[3],lf[46],lf[97],lf[98],((C_word*)t0)[2]);}}

/* k3309 in k3306 in create-directory in k3294 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* set-file-position! in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3236r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3236r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3236r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[87]);
t8=(C_word)C_i_check_exact_2(t6,lf[87]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3249,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_negativep(t3))){
/* posixunix.scm: 846  ##sys#signal-hook */
t10=*((C_word*)lf[2]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[92],lf[87],lf[93],t3,t2);}
else{
t10=t9;
f_3249(2,t10,C_SCHEME_UNDEFINED);}}

/* k3247 in set-file-position! in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3261,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 847  port? */
t4=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k3259 in k3247 in set-file-position! in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[89]);
if(C_truep(t3)){
t4=(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
f_3255(2,t5,t4);}
else{
t4=((C_word*)t0)[2];
f_3255(2,t4,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3255(2,t3,t2);}
else{
/* posixunix.scm: 853  ##sys#signal-hook */
t2=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[57],lf[87],lf[90],((C_word*)t0)[5]);}}}

/* k3253 in k3247 in set-file-position! in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 854  posix-error */
t2=lf[1];
f_2533(7,t2,((C_word*)t0)[4],lf[46],lf[87],lf[88],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* socket? in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3227,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3234,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 837  ##sys#stat */
f_3086(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k3232 in socket? in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* f_3218 in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3218,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3225,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 832  ##sys#stat */
f_3086(t4,t2,C_SCHEME_FALSE,lf[85]);}

/* k3223 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* block-device? in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3209,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[83]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3216,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 827  ##sys#stat */
f_3086(t4,t2,C_SCHEME_FALSE,lf[83]);}

/* k3214 in block-device? in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* character-device? in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3200,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[82]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3207,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 822  ##sys#stat */
f_3086(t4,t2,C_SCHEME_FALSE,lf[82]);}

/* k3205 in character-device? in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* symbolic-link? in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3191,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[81]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3198,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 817  ##sys#stat */
f_3086(t4,t2,C_SCHEME_TRUE,lf[81]);}

/* k3196 in symbolic-link? in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3182,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[80]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3189,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 812  ##sys#stat */
f_3086(t4,t2,C_SCHEME_TRUE,lf[80]);}

/* k3187 in regular-file? in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3176,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 808  ##sys#stat */
f_3086(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k3178 in file-permissions in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3170,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3174,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 807  ##sys#stat */
f_3086(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k3172 in file-owner in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3164,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3168,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 806  ##sys#stat */
f_3086(t3,t2,C_SCHEME_FALSE,lf[77]);}

/* k3166 in file-change-time in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3168,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3158,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3162,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 805  ##sys#stat */
f_3086(t3,t2,C_SCHEME_FALSE,lf[76]);}

/* k3160 in file-access-time in k3154 in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3162,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-size in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3148,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3152,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 790  ##sys#stat */
f_3086(t3,t2,C_SCHEME_FALSE,lf[74]);}

/* k3150 in file-size in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3152,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3123r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3123r(t0,t1,t2,t3);}}

static void C_ccall f_3123r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3127,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
/* posixunix.scm: 783  ##sys#stat */
f_3086(t4,t2,C_SCHEME_FALSE,lf[73]);}
else{
t5=(C_word)C_slot(t3,C_fix(0));
/* posixunix.scm: 783  ##sys#stat */
f_3086(t4,t2,t5,lf[73]);}}

/* k3125 in file-stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3127,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3086(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3086,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3090,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_3090(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3111,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3118,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 774  ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 778  ##sys#signal-hook */
t6=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[57],lf[72],t2);}}}

/* k3116 in ##sys#stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 774  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3109 in ##sys#stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3090(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k3088 in ##sys#stat in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 780  posix-error */
t2=lf[1];
f_2533(6,t2,((C_word*)t0)[4],lf[46],((C_word*)t0)[3],lf[71],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2806r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2806r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2806r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(15);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=(C_word)stub116(C_SCHEME_UNDEFINED,C_fix(0));
t10=(C_word)stub116(C_SCHEME_UNDEFINED,C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2822,a[2]=t6,a[3]=t8,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t11)){
t13=t12;
f_2822(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
t14=t2;
t15=t12;
f_2822(2,t15,(C_word)stub121(C_SCHEME_UNDEFINED,C_fix(0),t14));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[65]);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3045,a[2]=t15,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_3045(t17,t12,t2);}}}

/* loop150 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_3045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3045,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_3053(t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g157 in loop150 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_3053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
t2=(C_word)C_i_check_exact_2(t1,lf[65]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[2])[1],t1));
t4=t1;
return((C_word)stub121(C_SCHEME_UNDEFINED,C_fix(0),t4));}

/* k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2828(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[6]);
t5=((C_word*)t0)[6];
t6=t3;
f_2828(2,t6,(C_word)stub121(C_SCHEME_UNDEFINED,C_fix(1),t5));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[6],lf[65]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2997,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2997(t8,t3,((C_word*)t0)[6]);}}}

/* loop179 in k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_2997(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2997,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_3005(t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g186 in loop179 in k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_3005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
t2=(C_word)C_i_check_exact_2(t1,lf[65]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[2])[1],t1));
t4=t1;
return((C_word)stub121(C_SCHEME_UNDEFINED,C_fix(1),t4));}

/* k2826 in k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[65]);
t4=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_2831(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_2831(t4,(C_word)C_C_select(t3));}}

/* k2829 in k2826 in k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_2831(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2831,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 729  posix-error */
t2=lf[1];
f_2533(7,t2,((C_word*)t0)[4],lf[46],lf[65],lf[66],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[3]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
/* posixunix.scm: 730  values */
C_values(4,0,((C_word*)t0)[4],t4,C_SCHEME_END_OF_LIST);}
else{
/* posixunix.scm: 730  values */
C_values(4,0,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2870,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t4=((C_word*)t0)[3];
t5=t3;
f_2870(t5,(C_word)stub127(C_SCHEME_UNDEFINED,C_fix(0),t4));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2933,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2935,a[2]=t8,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_2935(t10,t6,((C_word*)t0)[3]);}}
else{
t4=t3;
f_2870(t4,C_SCHEME_FALSE);}}}}

/* loop213 in k2829 in k2826 in k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_2935(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2935,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2943,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_2943(C_a_i(&a,3),t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g220 in loop213 in k2829 in k2826 in k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_2943(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t2=t1;
if(C_truep((C_word)stub127(C_SCHEME_UNDEFINED,C_fix(0),t2))){
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
return(t4);}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* k2931 in k2829 in k2826 in k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
f_2870(t3,t2);}

/* k2868 in k2829 in k2826 in k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_2870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2870,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[3];
t3=(C_word)stub127(C_SCHEME_UNDEFINED,C_fix(1),t2);
/* posixunix.scm: 732  values */
C_values(4,0,((C_word*)t0)[2],t1,t3);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2886,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2888,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2888(t8,t4,((C_word*)t0)[3]);}}
else{
/* posixunix.scm: 732  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* loop233 in k2868 in k2829 in k2826 in k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_fcall f_2888(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2888,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=f_2896(C_a_i(&a,3),t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g240 in loop233 in k2868 in k2829 in k2826 in k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static C_word C_fcall f_2896(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t2=t1;
if(C_truep((C_word)stub127(C_SCHEME_UNDEFINED,C_fix(1),t2))){
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
return(t4);}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* k2884 in k2868 in k2829 in k2826 in k2820 in file-select in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
/* posixunix.scm: 732  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* file-mkstemp in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2768,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[62]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2775,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 681  ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2773 in file-mkstemp in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2775,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2781,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 685  posix-error */
t6=lf[1];
f_2533(6,t6,t4,lf[46],lf[62],lf[64],((C_word*)t0)[2]);}
else{
t6=t4;
f_2781(2,t6,C_SCHEME_UNDEFINED);}}

/* k2779 in k2773 in file-mkstemp in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 686  ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k2786 in k2779 in k2773 in file-mkstemp in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 686  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2729r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2729r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2729r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[59]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2736,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_byteblockp(t3))){
t7=t6;
f_2736(2,t7,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 670  ##sys#signal-hook */
t7=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[57],lf[59],lf[61],t3);}}
else{
/* posixunix.scm: 670  ##sys#signal-hook */
t7=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,lf[57],lf[59],lf[61],t3);}}

/* k2734 in file-write in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2736,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[59]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2745,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 675  posix-error */
t8=lf[1];
f_2533(7,t8,t6,lf[46],lf[59],lf[60],((C_word*)t0)[3],t3);}
else{
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t5);}}

/* k2743 in k2734 in file-write in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2687r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2687r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2687r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[55]);
t6=(C_word)C_i_check_exact_2(t3,lf[55]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2697,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_2697(2,t8,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixunix.scm: 658  make-string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k2695 in file-read in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(t1))){
if(C_truep((C_word)C_byteblockp(t1))){
t3=t2;
f_2700(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 660  ##sys#signal-hook */
t3=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[57],lf[55],lf[58],t1);}}
else{
/* posixunix.scm: 660  ##sys#signal-hook */
t3=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[57],lf[55],lf[58],t1);}}

/* k2698 in k2695 in file-read in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2700,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2703,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 663  posix-error */
t5=lf[1];
f_2533(7,t5,t3,lf[46],lf[55],lf[56],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2));}}

/* k2701 in k2698 in k2695 in file-read in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2703,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2672,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[52]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 651  posix-error */
t4=lf[1];
f_2533(6,t4,t1,lf[46],lf[52],lf[53],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* file-open in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2634r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2634r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2634r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[48]);
t8=(C_word)C_i_check_exact_2(t3,lf[48]);
t9=(C_word)C_i_check_exact_2(t6,lf[48]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2651,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2664,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 642  ##sys#expand-home-path */
t12=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k2662 in file-open in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 642  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2649 in file-open in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2651,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2654,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 644  posix-error */
t5=lf[1];
f_2533(8,t5,t3,lf[46],lf[48],lf[49],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k2652 in k2649 in file-open in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2595r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2595r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2595r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_fix(0):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_exact_2(t2,lf[45]);
t8=(C_word)C_i_check_exact_2(t3,lf[45]);
t9=t2;
t10=t3;
t11=(C_word)stub33(C_SCHEME_UNDEFINED,t9,t10,t6);
t12=(C_word)C_eqp(t11,C_fix(-1));
if(C_truep(t12)){
/* posixunix.scm: 632  posix-error */
t13=lf[1];
f_2533(7,t13,t1,lf[46],lf[45],lf[47],t2,t3);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t11);}}

/* ##sys#file-select-one in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2554,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub26(C_SCHEME_UNDEFINED,t2));}

/* ##sys#file-nonblocking! in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2551,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub22(C_SCHEME_UNDEFINED,t2));}

/* posix-error in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_2533r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2533r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2533r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2537,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 522  ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k2535 in posix-error in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub12(t4,t1),C_fix(0));}

/* k2546 in k2535 in posix-error in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 523  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[3],t1);}

/* k2542 in k2535 in posix-error in k2524 in k2521 in k2518 in k2515 in k2512 in k2509 in k2506 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[2]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[620] = {
{"toplevel:posixunix_scm",(void*)C_posix_toplevel},
{"f_2508:posixunix_scm",(void*)f_2508},
{"f_2511:posixunix_scm",(void*)f_2511},
{"f_2514:posixunix_scm",(void*)f_2514},
{"f_2517:posixunix_scm",(void*)f_2517},
{"f_2520:posixunix_scm",(void*)f_2520},
{"f_2523:posixunix_scm",(void*)f_2523},
{"f_2526:posixunix_scm",(void*)f_2526},
{"f_8425:posixunix_scm",(void*)f_8425},
{"f_8454:posixunix_scm",(void*)f_8454},
{"f_8435:posixunix_scm",(void*)f_8435},
{"f_8441:posixunix_scm",(void*)f_8441},
{"f_8419:posixunix_scm",(void*)f_8419},
{"f_8423:posixunix_scm",(void*)f_8423},
{"f_3156:posixunix_scm",(void*)f_3156},
{"f_8382:posixunix_scm",(void*)f_8382},
{"f_8398:posixunix_scm",(void*)f_8398},
{"f_8386:posixunix_scm",(void*)f_8386},
{"f_8389:posixunix_scm",(void*)f_8389},
{"f_3296:posixunix_scm",(void*)f_3296},
{"f_4358:posixunix_scm",(void*)f_4358},
{"f_8376:posixunix_scm",(void*)f_8376},
{"f_4515:posixunix_scm",(void*)f_4515},
{"f_8361:posixunix_scm",(void*)f_8361},
{"f_8371:posixunix_scm",(void*)f_8371},
{"f_8358:posixunix_scm",(void*)f_8358},
{"f_4557:posixunix_scm",(void*)f_4557},
{"f_8343:posixunix_scm",(void*)f_8343},
{"f_8353:posixunix_scm",(void*)f_8353},
{"f_8340:posixunix_scm",(void*)f_8340},
{"f_4561:posixunix_scm",(void*)f_4561},
{"f_8325:posixunix_scm",(void*)f_8325},
{"f_8335:posixunix_scm",(void*)f_8335},
{"f_8322:posixunix_scm",(void*)f_8322},
{"f_4565:posixunix_scm",(void*)f_4565},
{"f_8307:posixunix_scm",(void*)f_8307},
{"f_8317:posixunix_scm",(void*)f_8317},
{"f_8304:posixunix_scm",(void*)f_8304},
{"f_4569:posixunix_scm",(void*)f_4569},
{"f_8283:posixunix_scm",(void*)f_8283},
{"f_8299:posixunix_scm",(void*)f_8299},
{"f_8265:posixunix_scm",(void*)f_8265},
{"f_8278:posixunix_scm",(void*)f_8278},
{"f_8272:posixunix_scm",(void*)f_8272},
{"f_5052:posixunix_scm",(void*)f_5052},
{"f_5091:posixunix_scm",(void*)f_5091},
{"f_8242:posixunix_scm",(void*)f_8242},
{"f_8238:posixunix_scm",(void*)f_8238},
{"f_8252:posixunix_scm",(void*)f_8252},
{"f_7990:posixunix_scm",(void*)f_7990},
{"f_8167:posixunix_scm",(void*)f_8167},
{"f_8173:posixunix_scm",(void*)f_8173},
{"f_8162:posixunix_scm",(void*)f_8162},
{"f_8157:posixunix_scm",(void*)f_8157},
{"f_7992:posixunix_scm",(void*)f_7992},
{"f_8144:posixunix_scm",(void*)f_8144},
{"f_8152:posixunix_scm",(void*)f_8152},
{"f_7999:posixunix_scm",(void*)f_7999},
{"f_8132:posixunix_scm",(void*)f_8132},
{"f_8126:posixunix_scm",(void*)f_8126},
{"f_8009:posixunix_scm",(void*)f_8009},
{"f_8011:posixunix_scm",(void*)f_8011},
{"f_8030:posixunix_scm",(void*)f_8030},
{"f_8112:posixunix_scm",(void*)f_8112},
{"f_8119:posixunix_scm",(void*)f_8119},
{"f_8106:posixunix_scm",(void*)f_8106},
{"f_8045:posixunix_scm",(void*)f_8045},
{"f_8099:posixunix_scm",(void*)f_8099},
{"f_8096:posixunix_scm",(void*)f_8096},
{"f_8086:posixunix_scm",(void*)f_8086},
{"f_8062:posixunix_scm",(void*)f_8062},
{"f_8084:posixunix_scm",(void*)f_8084},
{"f_8070:posixunix_scm",(void*)f_8070},
{"f_8077:posixunix_scm",(void*)f_8077},
{"f_8074:posixunix_scm",(void*)f_8074},
{"f_8057:posixunix_scm",(void*)f_8057},
{"f_8055:posixunix_scm",(void*)f_8055},
{"f_8133:posixunix_scm",(void*)f_8133},
{"f_7933:posixunix_scm",(void*)f_7933},
{"f_7945:posixunix_scm",(void*)f_7945},
{"f_7940:posixunix_scm",(void*)f_7940},
{"f_7935:posixunix_scm",(void*)f_7935},
{"f_7876:posixunix_scm",(void*)f_7876},
{"f_7888:posixunix_scm",(void*)f_7888},
{"f_7883:posixunix_scm",(void*)f_7883},
{"f_7878:posixunix_scm",(void*)f_7878},
{"f_7815:posixunix_scm",(void*)f_7815},
{"f_7870:posixunix_scm",(void*)f_7870},
{"f_7874:posixunix_scm",(void*)f_7874},
{"f_7836:posixunix_scm",(void*)f_7836},
{"f_7839:posixunix_scm",(void*)f_7839},
{"f_7850:posixunix_scm",(void*)f_7850},
{"f_7844:posixunix_scm",(void*)f_7844},
{"f_7817:posixunix_scm",(void*)f_7817},
{"f_7826:posixunix_scm",(void*)f_7826},
{"f_7757:posixunix_scm",(void*)f_7757},
{"f_7769:posixunix_scm",(void*)f_7769},
{"f_7800:posixunix_scm",(void*)f_7800},
{"f_7780:posixunix_scm",(void*)f_7780},
{"f_7796:posixunix_scm",(void*)f_7796},
{"f_7784:posixunix_scm",(void*)f_7784},
{"f_7792:posixunix_scm",(void*)f_7792},
{"f_7788:posixunix_scm",(void*)f_7788},
{"f_7763:posixunix_scm",(void*)f_7763},
{"f_7746:posixunix_scm",(void*)f_7746},
{"f_7750:posixunix_scm",(void*)f_7750},
{"f_7735:posixunix_scm",(void*)f_7735},
{"f_7739:posixunix_scm",(void*)f_7739},
{"f_7690:posixunix_scm",(void*)f_7690},
{"f_7694:posixunix_scm",(void*)f_7694},
{"f_7697:posixunix_scm",(void*)f_7697},
{"f_7700:posixunix_scm",(void*)f_7700},
{"f_7707:posixunix_scm",(void*)f_7707},
{"f_7713:posixunix_scm",(void*)f_7713},
{"f_7717:posixunix_scm",(void*)f_7717},
{"f_7720:posixunix_scm",(void*)f_7720},
{"f_7723:posixunix_scm",(void*)f_7723},
{"f_7711:posixunix_scm",(void*)f_7711},
{"f_7657:posixunix_scm",(void*)f_7657},
{"f_7670:posixunix_scm",(void*)f_7670},
{"f_7582:posixunix_scm",(void*)f_7582},
{"f_7643:posixunix_scm",(void*)f_7643},
{"f_7656:posixunix_scm",(void*)f_7656},
{"f_7623:posixunix_scm",(void*)f_7623},
{"f_7638:posixunix_scm",(void*)f_7638},
{"f_7632:posixunix_scm",(void*)f_7632},
{"f_7586:posixunix_scm",(void*)f_7586},
{"f_7588:posixunix_scm",(void*)f_7588},
{"f_7609:posixunix_scm",(void*)f_7609},
{"f_7603:posixunix_scm",(void*)f_7603},
{"f_7530:posixunix_scm",(void*)f_7530},
{"f_7537:posixunix_scm",(void*)f_7537},
{"f_7556:posixunix_scm",(void*)f_7556},
{"f_7560:posixunix_scm",(void*)f_7560},
{"f_7524:posixunix_scm",(void*)f_7524},
{"f_7515:posixunix_scm",(void*)f_7515},
{"f_7519:posixunix_scm",(void*)f_7519},
{"f_7488:posixunix_scm",(void*)f_7488},
{"f_7485:posixunix_scm",(void*)f_7485},
{"f_7482:posixunix_scm",(void*)f_7482},
{"f_7479:posixunix_scm",(void*)f_7479},
{"f_7404:posixunix_scm",(void*)f_7404},
{"f_7437:posixunix_scm",(void*)f_7437},
{"f_7431:posixunix_scm",(void*)f_7431},
{"f_7387:posixunix_scm",(void*)f_7387},
{"f_7208:posixunix_scm",(void*)f_7208},
{"f_7342:posixunix_scm",(void*)f_7342},
{"f_7337:posixunix_scm",(void*)f_7337},
{"f_7210:posixunix_scm",(void*)f_7210},
{"f_7220:posixunix_scm",(void*)f_7220},
{"f_7228:posixunix_scm",(void*)f_7228},
{"f_7274:posixunix_scm",(void*)f_7274},
{"f_7241:posixunix_scm",(void*)f_7241},
{"f_7266:posixunix_scm",(void*)f_7266},
{"f_7244:posixunix_scm",(void*)f_7244},
{"f_7200:posixunix_scm",(void*)f_7200},
{"f_7192:posixunix_scm",(void*)f_7192},
{"f_7154:posixunix_scm",(void*)f_7154},
{"f_7179:posixunix_scm",(void*)f_7179},
{"f_7040:posixunix_scm",(void*)f_7040},
{"f_7046:posixunix_scm",(void*)f_7046},
{"f_7067:posixunix_scm",(void*)f_7067},
{"f_7146:posixunix_scm",(void*)f_7146},
{"f_7071:posixunix_scm",(void*)f_7071},
{"f_7074:posixunix_scm",(void*)f_7074},
{"f_7081:posixunix_scm",(void*)f_7081},
{"f_7083:posixunix_scm",(void*)f_7083},
{"f_7100:posixunix_scm",(void*)f_7100},
{"f_7104:posixunix_scm",(void*)f_7104},
{"f_7112:posixunix_scm",(void*)f_7112},
{"f_7116:posixunix_scm",(void*)f_7116},
{"f_7061:posixunix_scm",(void*)f_7061},
{"f_7028:posixunix_scm",(void*)f_7028},
{"f_7032:posixunix_scm",(void*)f_7032},
{"f_7035:posixunix_scm",(void*)f_7035},
{"f_6993:posixunix_scm",(void*)f_6993},
{"f_6997:posixunix_scm",(void*)f_6997},
{"f_7017:posixunix_scm",(void*)f_7017},
{"f_7021:posixunix_scm",(void*)f_7021},
{"f_6974:posixunix_scm",(void*)f_6974},
{"f_6978:posixunix_scm",(void*)f_6978},
{"f_6947:posixunix_scm",(void*)f_6947},
{"f_6951:posixunix_scm",(void*)f_6951},
{"f_6928:posixunix_scm",(void*)f_6928},
{"f_6932:posixunix_scm",(void*)f_6932},
{"f_6935:posixunix_scm",(void*)f_6935},
{"f_6869:posixunix_scm",(void*)f_6869},
{"f_6873:posixunix_scm",(void*)f_6873},
{"f_6879:posixunix_scm",(void*)f_6879},
{"f_6888:posixunix_scm",(void*)f_6888},
{"f_6866:posixunix_scm",(void*)f_6866},
{"f_6850:posixunix_scm",(void*)f_6850},
{"f_6842:posixunix_scm",(void*)f_6842},
{"f_6827:posixunix_scm",(void*)f_6827},
{"f_6831:posixunix_scm",(void*)f_6831},
{"f_6812:posixunix_scm",(void*)f_6812},
{"f_6816:posixunix_scm",(void*)f_6816},
{"f_6773:posixunix_scm",(void*)f_6773},
{"f_6790:posixunix_scm",(void*)f_6790},
{"f_6794:posixunix_scm",(void*)f_6794},
{"f_6711:posixunix_scm",(void*)f_6711},
{"f_6718:posixunix_scm",(void*)f_6718},
{"f_6740:posixunix_scm",(void*)f_6740},
{"f_6737:posixunix_scm",(void*)f_6737},
{"f_6727:posixunix_scm",(void*)f_6727},
{"f_6657:posixunix_scm",(void*)f_6657},
{"f_6661:posixunix_scm",(void*)f_6661},
{"f_6667:posixunix_scm",(void*)f_6667},
{"f_6625:posixunix_scm",(void*)f_6625},
{"f_6629:posixunix_scm",(void*)f_6629},
{"f_6598:posixunix_scm",(void*)f_6598},
{"f_6602:posixunix_scm",(void*)f_6602},
{"f_6579:posixunix_scm",(void*)f_6579},
{"f_6573:posixunix_scm",(void*)f_6573},
{"f_6564:posixunix_scm",(void*)f_6564},
{"f_6529:posixunix_scm",(void*)f_6529},
{"f_6542:posixunix_scm",(void*)f_6542},
{"f_6471:posixunix_scm",(void*)f_6471},
{"f_6475:posixunix_scm",(void*)f_6475},
{"f_6481:posixunix_scm",(void*)f_6481},
{"f_6484:posixunix_scm",(void*)f_6484},
{"f_6500:posixunix_scm",(void*)f_6500},
{"f_6487:posixunix_scm",(void*)f_6487},
{"f_6387:posixunix_scm",(void*)f_6387},
{"f_6393:posixunix_scm",(void*)f_6393},
{"f_6397:posixunix_scm",(void*)f_6397},
{"f_6405:posixunix_scm",(void*)f_6405},
{"f_6431:posixunix_scm",(void*)f_6431},
{"f_6435:posixunix_scm",(void*)f_6435},
{"f_6423:posixunix_scm",(void*)f_6423},
{"f_6372:posixunix_scm",(void*)f_6372},
{"f_6380:posixunix_scm",(void*)f_6380},
{"f_6355:posixunix_scm",(void*)f_6355},
{"f_6366:posixunix_scm",(void*)f_6366},
{"f_6370:posixunix_scm",(void*)f_6370},
{"f_6329:posixunix_scm",(void*)f_6329},
{"f_6353:posixunix_scm",(void*)f_6353},
{"f_6336:posixunix_scm",(void*)f_6336},
{"f_6286:posixunix_scm",(void*)f_6286},
{"f_6293:posixunix_scm",(void*)f_6293},
{"f_6314:posixunix_scm",(void*)f_6314},
{"f_6310:posixunix_scm",(void*)f_6310},
{"f_6258:posixunix_scm",(void*)f_6258},
{"f_6231:posixunix_scm",(void*)f_6231},
{"f_6235:posixunix_scm",(void*)f_6235},
{"f_6216:posixunix_scm",(void*)f_6216},
{"f_6220:posixunix_scm",(void*)f_6220},
{"f_6201:posixunix_scm",(void*)f_6201},
{"f_6205:posixunix_scm",(void*)f_6205},
{"f_6183:posixunix_scm",(void*)f_6183},
{"f_6112:posixunix_scm",(void*)f_6112},
{"f_6131:posixunix_scm",(void*)f_6131},
{"f_6137:posixunix_scm",(void*)f_6137},
{"f_6073:posixunix_scm",(void*)f_6073},
{"f_6101:posixunix_scm",(void*)f_6101},
{"f_6097:posixunix_scm",(void*)f_6097},
{"f_6090:posixunix_scm",(void*)f_6090},
{"f_6083:posixunix_scm",(void*)f_6083},
{"f_5817:posixunix_scm",(void*)f_5817},
{"f_6013:posixunix_scm",(void*)f_6013},
{"f_6008:posixunix_scm",(void*)f_6008},
{"f_6003:posixunix_scm",(void*)f_6003},
{"f_5819:posixunix_scm",(void*)f_5819},
{"f_5823:posixunix_scm",(void*)f_5823},
{"f_5929:posixunix_scm",(void*)f_5929},
{"f_5930:posixunix_scm",(void*)f_5930},
{"f_5947:posixunix_scm",(void*)f_5947},
{"f_5957:posixunix_scm",(void*)f_5957},
{"f_5915:posixunix_scm",(void*)f_5915},
{"f_5871:posixunix_scm",(void*)f_5871},
{"f_5907:posixunix_scm",(void*)f_5907},
{"f_5886:posixunix_scm",(void*)f_5886},
{"f_5896:posixunix_scm",(void*)f_5896},
{"f_5880:posixunix_scm",(void*)f_5880},
{"f_5875:posixunix_scm",(void*)f_5875},
{"f_5878:posixunix_scm",(void*)f_5878},
{"f_5825:posixunix_scm",(void*)f_5825},
{"f_5860:posixunix_scm",(void*)f_5860},
{"f_5841:posixunix_scm",(void*)f_5841},
{"f_5338:posixunix_scm",(void*)f_5338},
{"f_5742:posixunix_scm",(void*)f_5742},
{"f_5737:posixunix_scm",(void*)f_5737},
{"f_5732:posixunix_scm",(void*)f_5732},
{"f_5727:posixunix_scm",(void*)f_5727},
{"f_5340:posixunix_scm",(void*)f_5340},
{"f_5344:posixunix_scm",(void*)f_5344},
{"f_5350:posixunix_scm",(void*)f_5350},
{"f_5600:posixunix_scm",(void*)f_5600},
{"f_5606:posixunix_scm",(void*)f_5606},
{"f_5702:posixunix_scm",(void*)f_5702},
{"f_5692:posixunix_scm",(void*)f_5692},
{"f_5686:posixunix_scm",(void*)f_5686},
{"f_5608:posixunix_scm",(void*)f_5608},
{"f_5658:posixunix_scm",(void*)f_5658},
{"f_5615:posixunix_scm",(void*)f_5615},
{"f_5625:posixunix_scm",(void*)f_5625},
{"f_5524:posixunix_scm",(void*)f_5524},
{"f_5532:posixunix_scm",(void*)f_5532},
{"f_5534:posixunix_scm",(void*)f_5534},
{"f_5582:posixunix_scm",(void*)f_5582},
{"f_5515:posixunix_scm",(void*)f_5515},
{"f_5519:posixunix_scm",(void*)f_5519},
{"f_5494:posixunix_scm",(void*)f_5494},
{"f_5504:posixunix_scm",(void*)f_5504},
{"f_5482:posixunix_scm",(void*)f_5482},
{"f_5469:posixunix_scm",(void*)f_5469},
{"f_5473:posixunix_scm",(void*)f_5473},
{"f_5464:posixunix_scm",(void*)f_5464},
{"f_5467:posixunix_scm",(void*)f_5467},
{"f_5382:posixunix_scm",(void*)f_5382},
{"f_5394:posixunix_scm",(void*)f_5394},
{"f_5431:posixunix_scm",(void*)f_5431},
{"f_5440:posixunix_scm",(void*)f_5440},
{"f_5434:posixunix_scm",(void*)f_5434},
{"f_5410:posixunix_scm",(void*)f_5410},
{"f_5413:posixunix_scm",(void*)f_5413},
{"f_5374:posixunix_scm",(void*)f_5374},
{"f_5351:posixunix_scm",(void*)f_5351},
{"f_5355:posixunix_scm",(void*)f_5355},
{"f_5311:posixunix_scm",(void*)f_5311},
{"f_5318:posixunix_scm",(void*)f_5318},
{"f_5321:posixunix_scm",(void*)f_5321},
{"f_5266:posixunix_scm",(void*)f_5266},
{"f_5270:posixunix_scm",(void*)f_5270},
{"f_5305:posixunix_scm",(void*)f_5305},
{"f_5288:posixunix_scm",(void*)f_5288},
{"f_5252:posixunix_scm",(void*)f_5252},
{"f_5264:posixunix_scm",(void*)f_5264},
{"f_5238:posixunix_scm",(void*)f_5238},
{"f_5250:posixunix_scm",(void*)f_5250},
{"f_5223:posixunix_scm",(void*)f_5223},
{"f_5236:posixunix_scm",(void*)f_5236},
{"f_5186:posixunix_scm",(void*)f_5186},
{"f_5194:posixunix_scm",(void*)f_5194},
{"f_5161:posixunix_scm",(void*)f_5161},
{"f_5150:posixunix_scm",(void*)f_5150},
{"f_5154:posixunix_scm",(void*)f_5154},
{"f_5174:posixunix_scm",(void*)f_5174},
{"f_5092:posixunix_scm",(void*)f_5092},
{"f_5131:posixunix_scm",(void*)f_5131},
{"f_5103:posixunix_scm",(void*)f_5103},
{"f_5106:posixunix_scm",(void*)f_5106},
{"f_5109:posixunix_scm",(void*)f_5109},
{"f_5115:posixunix_scm",(void*)f_5115},
{"f_5054:posixunix_scm",(void*)f_5054},
{"f_5087:posixunix_scm",(void*)f_5087},
{"f_5075:posixunix_scm",(void*)f_5075},
{"f_5083:posixunix_scm",(void*)f_5083},
{"f_5079:posixunix_scm",(void*)f_5079},
{"f_5035:posixunix_scm",(void*)f_5035},
{"f_5045:posixunix_scm",(void*)f_5045},
{"f_5039:posixunix_scm",(void*)f_5039},
{"f_5029:posixunix_scm",(void*)f_5029},
{"f_5023:posixunix_scm",(void*)f_5023},
{"f_5017:posixunix_scm",(void*)f_5017},
{"f_4993:posixunix_scm",(void*)f_4993},
{"f_5015:posixunix_scm",(void*)f_5015},
{"f_5011:posixunix_scm",(void*)f_5011},
{"f_5003:posixunix_scm",(void*)f_5003},
{"f_4963:posixunix_scm",(void*)f_4963},
{"f_4991:posixunix_scm",(void*)f_4991},
{"f_4987:posixunix_scm",(void*)f_4987},
{"f_4936:posixunix_scm",(void*)f_4936},
{"f_4961:posixunix_scm",(void*)f_4961},
{"f_4957:posixunix_scm",(void*)f_4957},
{"f_4872:posixunix_scm",(void*)f_4872},
{"f_4868:posixunix_scm",(void*)f_4868},
{"f_4885:posixunix_scm",(void*)f_4885},
{"f_4888:posixunix_scm",(void*)f_4888},
{"f_4806:posixunix_scm",(void*)f_4806},
{"f_4810:posixunix_scm",(void*)f_4810},
{"f_4815:posixunix_scm",(void*)f_4815},
{"f_4831:posixunix_scm",(void*)f_4831},
{"f_4743:posixunix_scm",(void*)f_4743},
{"f_4801:posixunix_scm",(void*)f_4801},
{"f_4747:posixunix_scm",(void*)f_4747},
{"f_4750:posixunix_scm",(void*)f_4750},
{"f_4782:posixunix_scm",(void*)f_4782},
{"f_4753:posixunix_scm",(void*)f_4753},
{"f_4758:posixunix_scm",(void*)f_4758},
{"f_4772:posixunix_scm",(void*)f_4772},
{"f_4665:posixunix_scm",(void*)f_4665},
{"f_4723:posixunix_scm",(void*)f_4723},
{"f_4672:posixunix_scm",(void*)f_4672},
{"f_4685:posixunix_scm",(void*)f_4685},
{"f_4689:posixunix_scm",(void*)f_4689},
{"f_4695:posixunix_scm",(void*)f_4695},
{"f_4699:posixunix_scm",(void*)f_4699},
{"f_4709:posixunix_scm",(void*)f_4709},
{"f_4693:posixunix_scm",(void*)f_4693},
{"f_4645:posixunix_scm",(void*)f_4645},
{"f_4657:posixunix_scm",(void*)f_4657},
{"f_4653:posixunix_scm",(void*)f_4653},
{"f_4631:posixunix_scm",(void*)f_4631},
{"f_4643:posixunix_scm",(void*)f_4643},
{"f_4639:posixunix_scm",(void*)f_4639},
{"f_4571:posixunix_scm",(void*)f_4571},
{"f_4617:posixunix_scm",(void*)f_4617},
{"f_4578:posixunix_scm",(void*)f_4578},
{"f_4591:posixunix_scm",(void*)f_4591},
{"f_4595:posixunix_scm",(void*)f_4595},
{"f_4599:posixunix_scm",(void*)f_4599},
{"f_4603:posixunix_scm",(void*)f_4603},
{"f_4607:posixunix_scm",(void*)f_4607},
{"f_4517:posixunix_scm",(void*)f_4517},
{"f_4550:posixunix_scm",(void*)f_4550},
{"f_4521:posixunix_scm",(void*)f_4521},
{"f_4528:posixunix_scm",(void*)f_4528},
{"f_4532:posixunix_scm",(void*)f_4532},
{"f_4536:posixunix_scm",(void*)f_4536},
{"f_4540:posixunix_scm",(void*)f_4540},
{"f_4544:posixunix_scm",(void*)f_4544},
{"f_4499:posixunix_scm",(void*)f_4499},
{"f_4484:posixunix_scm",(void*)f_4484},
{"f_4478:posixunix_scm",(void*)f_4478},
{"f_4446:posixunix_scm",(void*)f_4446},
{"f_4452:posixunix_scm",(void*)f_4452},
{"f_4400:posixunix_scm",(void*)f_4400},
{"f_4418:posixunix_scm",(void*)f_4418},
{"f_4382:posixunix_scm",(void*)f_4382},
{"f_4392:posixunix_scm",(void*)f_4392},
{"f_4369:posixunix_scm",(void*)f_4369},
{"f_4360:posixunix_scm",(void*)f_4360},
{"f_4313:posixunix_scm",(void*)f_4313},
{"f_4317:posixunix_scm",(void*)f_4317},
{"f_4293:posixunix_scm",(void*)f_4293},
{"f_4297:posixunix_scm",(void*)f_4297},
{"f_4303:posixunix_scm",(void*)f_4303},
{"f_4307:posixunix_scm",(void*)f_4307},
{"f_4273:posixunix_scm",(void*)f_4273},
{"f_4277:posixunix_scm",(void*)f_4277},
{"f_4283:posixunix_scm",(void*)f_4283},
{"f_4287:posixunix_scm",(void*)f_4287},
{"f_4249:posixunix_scm",(void*)f_4249},
{"f_4253:posixunix_scm",(void*)f_4253},
{"f_4264:posixunix_scm",(void*)f_4264},
{"f_4268:posixunix_scm",(void*)f_4268},
{"f_4258:posixunix_scm",(void*)f_4258},
{"f_4225:posixunix_scm",(void*)f_4225},
{"f_4229:posixunix_scm",(void*)f_4229},
{"f_4240:posixunix_scm",(void*)f_4240},
{"f_4244:posixunix_scm",(void*)f_4244},
{"f_4234:posixunix_scm",(void*)f_4234},
{"f_4209:posixunix_scm",(void*)f_4209},
{"f_4213:posixunix_scm",(void*)f_4213},
{"f_4216:posixunix_scm",(void*)f_4216},
{"f_4173:posixunix_scm",(void*)f_4173},
{"f_4204:posixunix_scm",(void*)f_4204},
{"f_4194:posixunix_scm",(void*)f_4194},
{"f_4187:posixunix_scm",(void*)f_4187},
{"f_4137:posixunix_scm",(void*)f_4137},
{"f_4168:posixunix_scm",(void*)f_4168},
{"f_4158:posixunix_scm",(void*)f_4158},
{"f_4151:posixunix_scm",(void*)f_4151},
{"f_4122:posixunix_scm",(void*)f_4122},
{"f_4135:posixunix_scm",(void*)f_4135},
{"f_3787:posixunix_scm",(void*)f_3787},
{"f_4094:posixunix_scm",(void*)f_4094},
{"f_3914:posixunix_scm",(void*)f_3914},
{"f_4080:posixunix_scm",(void*)f_4080},
{"f_4069:posixunix_scm",(void*)f_4069},
{"f_4076:posixunix_scm",(void*)f_4076},
{"f_3933:posixunix_scm",(void*)f_3933},
{"f_4062:posixunix_scm",(void*)f_4062},
{"f_4041:posixunix_scm",(void*)f_4041},
{"f_4058:posixunix_scm",(void*)f_4058},
{"f_4047:posixunix_scm",(void*)f_4047},
{"f_4054:posixunix_scm",(void*)f_4054},
{"f_3977:posixunix_scm",(void*)f_3977},
{"f_4038:posixunix_scm",(void*)f_4038},
{"f_4017:posixunix_scm",(void*)f_4017},
{"f_4034:posixunix_scm",(void*)f_4034},
{"f_4023:posixunix_scm",(void*)f_4023},
{"f_4030:posixunix_scm",(void*)f_4030},
{"f_3990:posixunix_scm",(void*)f_3990},
{"f_4014:posixunix_scm",(void*)f_4014},
{"f_4010:posixunix_scm",(void*)f_4010},
{"f_3971:posixunix_scm",(void*)f_3971},
{"f_3940:posixunix_scm",(void*)f_3940},
{"f_3958:posixunix_scm",(void*)f_3958},
{"f_3943:posixunix_scm",(void*)f_3943},
{"f_3947:posixunix_scm",(void*)f_3947},
{"f_3927:posixunix_scm",(void*)f_3927},
{"f_3908:posixunix_scm",(void*)f_3908},
{"f_3794:posixunix_scm",(void*)f_3794},
{"f_3801:posixunix_scm",(void*)f_3801},
{"f_3803:posixunix_scm",(void*)f_3803},
{"f_3810:posixunix_scm",(void*)f_3810},
{"f_3874:posixunix_scm",(void*)f_3874},
{"f_3883:posixunix_scm",(void*)f_3883},
{"f_3816:posixunix_scm",(void*)f_3816},
{"f_3852:posixunix_scm",(void*)f_3852},
{"f_3848:posixunix_scm",(void*)f_3848},
{"f_3844:posixunix_scm",(void*)f_3844},
{"f_3833:posixunix_scm",(void*)f_3833},
{"f_3829:posixunix_scm",(void*)f_3829},
{"f_3731:posixunix_scm",(void*)f_3731},
{"f_3740:posixunix_scm",(void*)f_3740},
{"f_3764:posixunix_scm",(void*)f_3764},
{"f_3776:posixunix_scm",(void*)f_3776},
{"f_3782:posixunix_scm",(void*)f_3782},
{"f_3770:posixunix_scm",(void*)f_3770},
{"f_3746:posixunix_scm",(void*)f_3746},
{"f_3752:posixunix_scm",(void*)f_3752},
{"f_3735:posixunix_scm",(void*)f_3735},
{"f_3674:posixunix_scm",(void*)f_3674},
{"f_3687:posixunix_scm",(void*)f_3687},
{"f_3648:posixunix_scm",(void*)f_3648},
{"f_3672:posixunix_scm",(void*)f_3672},
{"f_3665:posixunix_scm",(void*)f_3665},
{"f_3494:posixunix_scm",(void*)f_3494},
{"f_3599:posixunix_scm",(void*)f_3599},
{"f_3607:posixunix_scm",(void*)f_3607},
{"f_3594:posixunix_scm",(void*)f_3594},
{"f_3496:posixunix_scm",(void*)f_3496},
{"f_3503:posixunix_scm",(void*)f_3503},
{"f_3506:posixunix_scm",(void*)f_3506},
{"f_3509:posixunix_scm",(void*)f_3509},
{"f_3593:posixunix_scm",(void*)f_3593},
{"f_3513:posixunix_scm",(void*)f_3513},
{"f_3527:posixunix_scm",(void*)f_3527},
{"f_3537:posixunix_scm",(void*)f_3537},
{"f_3540:posixunix_scm",(void*)f_3540},
{"f_3543:posixunix_scm",(void*)f_3543},
{"f_3549:posixunix_scm",(void*)f_3549},
{"f_3559:posixunix_scm",(void*)f_3559},
{"f_3472:posixunix_scm",(void*)f_3472},
{"f_3492:posixunix_scm",(void*)f_3492},
{"f_3479:posixunix_scm",(void*)f_3479},
{"f_3482:posixunix_scm",(void*)f_3482},
{"f_3450:posixunix_scm",(void*)f_3450},
{"f_3470:posixunix_scm",(void*)f_3470},
{"f_3457:posixunix_scm",(void*)f_3457},
{"f_3460:posixunix_scm",(void*)f_3460},
{"f_3298:posixunix_scm",(void*)f_3298},
{"f_3308:posixunix_scm",(void*)f_3308},
{"f_3429:posixunix_scm",(void*)f_3429},
{"f_3317:posixunix_scm",(void*)f_3317},
{"f_3413:posixunix_scm",(void*)f_3413},
{"f_3390:posixunix_scm",(void*)f_3390},
{"f_3384:posixunix_scm",(void*)f_3384},
{"f_3327:posixunix_scm",(void*)f_3327},
{"f_3329:posixunix_scm",(void*)f_3329},
{"f_3379:posixunix_scm",(void*)f_3379},
{"f_3336:posixunix_scm",(void*)f_3336},
{"f_3362:posixunix_scm",(void*)f_3362},
{"f_3339:posixunix_scm",(void*)f_3339},
{"f_3355:posixunix_scm",(void*)f_3355},
{"f_3311:posixunix_scm",(void*)f_3311},
{"f_3236:posixunix_scm",(void*)f_3236},
{"f_3249:posixunix_scm",(void*)f_3249},
{"f_3261:posixunix_scm",(void*)f_3261},
{"f_3255:posixunix_scm",(void*)f_3255},
{"f_3227:posixunix_scm",(void*)f_3227},
{"f_3234:posixunix_scm",(void*)f_3234},
{"f_3218:posixunix_scm",(void*)f_3218},
{"f_3225:posixunix_scm",(void*)f_3225},
{"f_3209:posixunix_scm",(void*)f_3209},
{"f_3216:posixunix_scm",(void*)f_3216},
{"f_3200:posixunix_scm",(void*)f_3200},
{"f_3207:posixunix_scm",(void*)f_3207},
{"f_3191:posixunix_scm",(void*)f_3191},
{"f_3198:posixunix_scm",(void*)f_3198},
{"f_3182:posixunix_scm",(void*)f_3182},
{"f_3189:posixunix_scm",(void*)f_3189},
{"f_3176:posixunix_scm",(void*)f_3176},
{"f_3180:posixunix_scm",(void*)f_3180},
{"f_3170:posixunix_scm",(void*)f_3170},
{"f_3174:posixunix_scm",(void*)f_3174},
{"f_3164:posixunix_scm",(void*)f_3164},
{"f_3168:posixunix_scm",(void*)f_3168},
{"f_3158:posixunix_scm",(void*)f_3158},
{"f_3162:posixunix_scm",(void*)f_3162},
{"f_3148:posixunix_scm",(void*)f_3148},
{"f_3152:posixunix_scm",(void*)f_3152},
{"f_3123:posixunix_scm",(void*)f_3123},
{"f_3127:posixunix_scm",(void*)f_3127},
{"f_3086:posixunix_scm",(void*)f_3086},
{"f_3118:posixunix_scm",(void*)f_3118},
{"f_3111:posixunix_scm",(void*)f_3111},
{"f_3090:posixunix_scm",(void*)f_3090},
{"f_2806:posixunix_scm",(void*)f_2806},
{"f_3045:posixunix_scm",(void*)f_3045},
{"f_3053:posixunix_scm",(void*)f_3053},
{"f_2822:posixunix_scm",(void*)f_2822},
{"f_2997:posixunix_scm",(void*)f_2997},
{"f_3005:posixunix_scm",(void*)f_3005},
{"f_2828:posixunix_scm",(void*)f_2828},
{"f_2831:posixunix_scm",(void*)f_2831},
{"f_2935:posixunix_scm",(void*)f_2935},
{"f_2943:posixunix_scm",(void*)f_2943},
{"f_2933:posixunix_scm",(void*)f_2933},
{"f_2870:posixunix_scm",(void*)f_2870},
{"f_2888:posixunix_scm",(void*)f_2888},
{"f_2896:posixunix_scm",(void*)f_2896},
{"f_2886:posixunix_scm",(void*)f_2886},
{"f_2768:posixunix_scm",(void*)f_2768},
{"f_2775:posixunix_scm",(void*)f_2775},
{"f_2781:posixunix_scm",(void*)f_2781},
{"f_2788:posixunix_scm",(void*)f_2788},
{"f_2729:posixunix_scm",(void*)f_2729},
{"f_2736:posixunix_scm",(void*)f_2736},
{"f_2745:posixunix_scm",(void*)f_2745},
{"f_2687:posixunix_scm",(void*)f_2687},
{"f_2697:posixunix_scm",(void*)f_2697},
{"f_2700:posixunix_scm",(void*)f_2700},
{"f_2703:posixunix_scm",(void*)f_2703},
{"f_2672:posixunix_scm",(void*)f_2672},
{"f_2634:posixunix_scm",(void*)f_2634},
{"f_2664:posixunix_scm",(void*)f_2664},
{"f_2651:posixunix_scm",(void*)f_2651},
{"f_2654:posixunix_scm",(void*)f_2654},
{"f_2595:posixunix_scm",(void*)f_2595},
{"f_2554:posixunix_scm",(void*)f_2554},
{"f_2551:posixunix_scm",(void*)f_2551},
{"f_2533:posixunix_scm",(void*)f_2533},
{"f_2537:posixunix_scm",(void*)f_2537},
{"f_2548:posixunix_scm",(void*)f_2548},
{"f_2544:posixunix_scm",(void*)f_2544},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
