/* Generated from setup-api.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: setup-api.scm -optimize-level 2 -include-path . -include-path ./ -inline -feature chicken-compile-shared -dynamic -emit-import-library setup-api -ignore-repository -output-file setup-api.c
   used units: library eval srfi_1 regex utils posix srfi_13 extras ports data_structures files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[349];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,115,104,101,108,108,112,97,116,104,32,115,116,114,56,53,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,25),40,115,101,116,117,112,45,97,112,105,35,99,114,111,115,115,45,99,104,105,99,107,101,110,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,117,115,101,114,45,105,110,115,116,97,108,108,45,115,101,116,117,112,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,97,112,105,35,115,117,100,111,45,105,110,115,116,97,108,108,32,46,32,97,114,103,115,49,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,7),40,97,50,48,56,52,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,121,101,115,45,111,114,45,110,111,63,32,115,116,114,49,51,49,32,46,32,116,109,112,49,51,48,49,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,7),40,97,50,49,49,57,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,97,50,49,48,57,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,112,97,116,99,104,32,119,104,105,99,104,49,55,54,32,114,120,49,55,55,32,115,117,98,115,116,49,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,102,105,120,109,97,107,101,116,97,114,103,101,116,32,102,105,108,101,50,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,50,57,32,103,50,51,51,50,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,51,57,32,103,50,52,57,50,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,55,56,32,103,50,56,56,50,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,101,120,101,99,117,116,101,32,101,120,112,108,105,115,116,50,50,54,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,102,111,114,109,45,101,114,114,111,114,32,115,51,55,57,32,112,51,56,48,41,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,108,105,110,101,45,101,114,114,111,114,32,115,51,57,48,32,112,51,57,49,32,110,51,57,50,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,7),40,97,50,56,53,48,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,14),40,97,50,56,52,52,32,101,120,110,53,56,51,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,50,56,57,49,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,50,57,48,54,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,20),40,97,50,57,48,48,32,46,32,97,114,103,115,53,55,56,53,57,52,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,7),40,97,50,56,56,53,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,15),40,97,50,56,51,56,32,107,53,55,55,53,56,50,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,14),40,97,50,57,56,48,32,100,101,112,53,51,48,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,12),40,97,51,48,50,52,32,100,53,50,51,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,13),40,109,97,116,99,104,63,32,115,51,54,53,41,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,105,110,101,115,51,54,55,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,23),40,102,95,50,55,56,52,32,115,52,57,50,32,105,110,100,101,110,116,52,57,51,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,54,51,50,32,103,54,51,54,54,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,11),40,103,54,50,51,32,102,54,50,53,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,54,49,54,32,103,54,50,48,54,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,14),40,97,50,54,55,55,32,100,101,112,52,53,52,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,15),40,97,50,54,48,56,32,108,105,110,101,52,49,57,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,109,97,107,101,47,112,114,111,99,47,104,101,108,112,101,114,32,115,112,101,99,52,56,52,32,97,114,103,118,52,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,47,112,114,111,99,32,103,54,53,55,54,53,56,54,54,54,32,46,32,114,118,97,114,54,53,57,54,54,55,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,13),40,118,101,114,98,32,100,105,114,55,52,56,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,15),40,102,95,53,55,51,56,32,100,105,114,55,53,55,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,15),40,102,95,53,55,52,54,32,100,105,114,55,53,57,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,51,51,54,51,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,97,51,51,55,50,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,119,114,105,116,101,45,105,110,102,111,32,105,100,55,54,57,32,102,105,108,101,115,55,55,48,32,105,110,102,111,55,55,49,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,19),40,98,111,100,121,56,52,49,32,112,114,101,102,105,120,56,53,49,41,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,112,114,101,102,105,120,56,52,52,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,114,114,56,52,51,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,47),40,115,101,116,117,112,45,97,112,105,35,99,111,112,121,45,102,105,108,101,32,102,114,111,109,56,51,51,32,116,111,56,51,52,32,46,32,116,109,112,56,51,50,56,51,53,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,109,111,118,101,45,102,105,108,101,32,102,114,111,109,56,55,49,32,116,111,56,55,50,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,31),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,102,105,108,101,42,32,100,105,114,56,56,51,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,45,100,101,115,116,45,112,97,116,104,110,97,109,101,32,112,97,116,104,56,57,49,32,102,105,108,101,56,57,50,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,56,57,55,32,103,57,48,55,57,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,99,104,101,99,107,45,102,105,108,101,108,105,115,116,32,102,108,105,115,116,56,57,52,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,51,57,54,48,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,7),40,97,51,57,54,51,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,61),40,115,101,116,117,112,45,97,112,105,35,115,116,97,110,100,97,114,100,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,57,54,50,32,118,101,114,115,105,111,110,57,54,51,32,46,32,116,109,112,57,54,49,57,54,52,41,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,103,49,48,52,57,32,102,49,48,53,49,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,48,51,51,32,103,49,48,52,51,49,48,52,55,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,60),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,101,120,116,101,110,115,105,111,110,32,105,100,49,48,49,54,32,102,105,108,101,115,49,48,49,55,32,46,32,116,109,112,49,48,49,53,49,48,49,56,41,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,13),40,101,120,105,102,121,32,102,49,49,49,51,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,103,49,49,54,50,32,102,49,49,54,52,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,49,52,54,32,103,49,49,53,54,49,49,54,48,41,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,103,49,49,51,55,32,102,49,49,51,57,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,49,50,49,32,103,49,49,51,49,49,49,51,53,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,112,114,111,103,114,97,109,32,105,100,49,49,48,50,32,102,105,108,101,115,49,49,48,51,32,46,32,116,109,112,49,49,48,49,49,49,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,13),40,103,49,50,50,49,32,102,49,50,50,51,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,50,48,53,32,103,49,50,49,53,49,50,49,57,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,115,99,114,105,112,116,32,105,100,49,49,56,56,32,102,105,108,101,115,49,49,56,57,32,46,32,116,109,112,49,49,56,55,49,49,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,114,101,112,111,45,112,97,116,104,32,116,109,112,49,50,53,52,49,50,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,101,110,115,117,114,101,45,100,105,114,101,99,116,111,114,121,32,112,97,116,104,49,50,55,49,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,7),40,97,52,55,57,51,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,7),40,97,52,55,57,57,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,7),40,97,52,56,48,50,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,7),40,97,52,56,48,56,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,7),40,97,52,56,49,49,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,7),40,97,52,56,49,52,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,116,114,121,45,99,111,109,112,105,108,101,32,99,111,100,101,49,50,57,53,32,46,32,116,109,112,49,50,57,52,49,50,57,54,41,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,99,104,105,99,107,101,110,45,118,101,114,115,105,111,110,32,118,49,51,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,55),40,115,101,116,117,112,45,97,112,105,35,117,112,103,114,97,100,101,45,109,101,115,115,97,103,101,32,101,120,116,49,51,53,48,32,109,115,103,49,51,53,49,32,116,109,112,49,51,52,57,49,51,53,50,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,97,114,103,115,49,51,55,57,41,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,97,114,103,115,49,51,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,108,105,98,114,97,114,121,32,110,97,109,101,49,52,49,52,32,112,114,111,99,49,52,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,104,101,97,100,101,114,32,110,97,109,101,49,52,51,54,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,52,53,50,32,103,49,52,54,50,49,52,54,54,41,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,21),40,118,101,114,115,105,111,110,45,62,108,105,115,116,32,118,49,52,52,57,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,112,49,49,52,56,48,32,112,50,49,52,56,49,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,118,101,114,115,105,111,110,62,61,63,32,118,49,49,52,52,54,32,118,50,49,52,52,55,41,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,26),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,110,97,109,101,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,116,109,112,49,53,52,55,49,53,52,56,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,29),40,115,101,116,117,112,45,97,112,105,35,114,101,97,100,45,105,110,102,111,32,101,103,103,49,53,53,56,41,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,38),40,115,101,116,117,112,45,97,112,105,35,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,13),40,103,49,54,50,55,32,102,49,54,50,57,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,54,50,48,32,103,49,54,50,52,49,54,50,54,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,14),40,119,97,108,107,32,100,105,114,49,54,49,54,41,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,50),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,49,53,57,53,32,46,32,116,109,112,49,53,57,52,49,53,57,54,41,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,54,53,48,32,103,49,54,53,52,49,54,53,54,41,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,101,120,116,101,110,115,105,111,110,32,101,103,103,49,54,52,51,41,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,36,115,121,115,116,101,109,32,115,116,114,49,54,54,51,41,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,21),40,101,110,115,117,114,101,45,115,116,114,105,110,103,32,120,49,53,51,51,41,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,13),40,97,53,54,54,55,32,120,49,53,49,54,41,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,7),40,97,53,55,56,49,41,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5849)
static void C_ccall f_5849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5845)
static void C_ccall f_5845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_ccall f_1832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5684)
static void C_fcall f_5684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5721)
static void C_ccall f_5721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5718)
static void C_ccall f_5718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5691)
static void C_fcall f_5691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_fcall f_5643(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5660)
static void C_ccall f_5660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5647)
static void C_ccall f_5647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_fcall f_5616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5607)
static void C_ccall f_5607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_ccall f_5603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_fcall f_5502(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_fcall f_5514(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_fcall f_5522(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5487)
static void C_ccall f_5487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5490)
static void C_ccall f_5490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_fcall f_5412(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_fcall f_5417(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5337)
static void C_ccall f_5337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5207)
static void C_fcall f_5207(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5139)
static void C_fcall f_5139(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5149)
static void C_fcall f_5149(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_fcall f_5159(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5131)
static void C_ccall f_5131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5069)
static void C_ccall f_5069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5072)
static void C_ccall f_5072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5081)
static void C_ccall f_5081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5090)
static void C_ccall f_5090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5093)
static void C_ccall f_5093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5099)
static void C_ccall f_5099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5105)
static void C_ccall f_5105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4940)
static void C_fcall f_4940(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4953)
static void C_fcall f_4953(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_fcall f_4971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_fcall f_4986(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4993)
static void C_ccall f_4993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_fcall f_4853(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4864)
static void C_ccall f_4864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4870)
static void C_ccall f_4870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4897)
static void C_ccall f_4897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4828)
static void C_ccall f_4828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4719)
static void C_ccall f_4719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4771)
static void C_ccall f_4771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_ccall f_4753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_fcall f_4644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_fcall f_4577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4603)
static void C_ccall f_4603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4423)
static void C_ccall f_4423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4429)
static void C_ccall f_4429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4466)
static void C_fcall f_4466(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_fcall f_4493(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4435)
static void C_ccall f_4435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_fcall f_4315(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4374)
static void C_ccall f_4374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_fcall f_4342(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_fcall f_4234(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4261)
static void C_fcall f_4261(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4200)
static void C_fcall f_4200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_fcall f_3994(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_fcall f_4021(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4121)
static void C_fcall f_4121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_fcall f_4052(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_fcall f_3644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3650)
static void C_fcall f_3650(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_fcall f_3693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_fcall f_3660(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_fcall f_3619(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3494)
static void C_fcall f_3494(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_fcall f_3485(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_fcall f_3418(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_fcall f_3287(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3300)
static void C_ccall f_3300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5750)
static void C_ccall f_5750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5738)
static void C_ccall f_5738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_fcall f_3263(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_fcall f_2763(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_fcall f_2767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2628)
static void C_ccall f_2628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_fcall f_3149(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_fcall f_3157(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_fcall f_3093(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3108)
static void C_ccall f_3108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2490)
static void C_fcall f_2490(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2503)
static void C_fcall f_2503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3054)
static void C_ccall f_3054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_ccall f_2797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_ccall f_3051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3014)
static void C_ccall f_3014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3020)
static void C_ccall f_3020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2845)
static void C_ccall f_2845(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2867)
static void C_ccall f_2867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2557)
static void C_fcall f_2557(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_fcall f_2535(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2444)
static void C_fcall f_2444(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2356)
static void C_fcall f_2356(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_fcall f_2232(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_fcall f_2398(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_fcall f_2302(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_fcall f_2309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2110)
static void C_ccall f_2110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_fcall f_2126(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_fcall f_2005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_fcall f_2027(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1942)
static void C_fcall f_1942(C_word t0) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_5684)
static void C_fcall trf_5684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5684(t0,t1);}

C_noret_decl(trf_5691)
static void C_fcall trf_5691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5691(t0,t1);}

C_noret_decl(trf_5643)
static void C_fcall trf_5643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5643(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5643(t0,t1);}

C_noret_decl(trf_5616)
static void C_fcall trf_5616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5616(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5616(t0,t1,t2);}

C_noret_decl(trf_5502)
static void C_fcall trf_5502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5502(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5502(t0,t1,t2);}

C_noret_decl(trf_5514)
static void C_fcall trf_5514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5514(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5514(t0,t1,t2);}

C_noret_decl(trf_5522)
static void C_fcall trf_5522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5522(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5522(t0,t1,t2);}

C_noret_decl(trf_5412)
static void C_fcall trf_5412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5412(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5412(t0,t1);}

C_noret_decl(trf_5417)
static void C_fcall trf_5417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5417(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5417(t0,t1);}

C_noret_decl(trf_5207)
static void C_fcall trf_5207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5207(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5207(t0,t1,t2,t3);}

C_noret_decl(trf_5139)
static void C_fcall trf_5139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5139(t0,t1);}

C_noret_decl(trf_5149)
static void C_fcall trf_5149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5149(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5149(t0,t1,t2);}

C_noret_decl(trf_5159)
static void C_fcall trf_5159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5159(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5159(t0,t1);}

C_noret_decl(trf_4940)
static void C_fcall trf_4940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4940(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4940(t0,t1,t2);}

C_noret_decl(trf_4953)
static void C_fcall trf_4953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4953(t0,t1);}

C_noret_decl(trf_4971)
static void C_fcall trf_4971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4971(t0,t1);}

C_noret_decl(trf_4986)
static void C_fcall trf_4986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4986(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4986(t0,t1);}

C_noret_decl(trf_4853)
static void C_fcall trf_4853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4853(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4853(t0,t1,t2,t3);}

C_noret_decl(trf_4644)
static void C_fcall trf_4644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4644(t0,t1);}

C_noret_decl(trf_4577)
static void C_fcall trf_4577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4577(t0,t1);}

C_noret_decl(trf_4466)
static void C_fcall trf_4466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4466(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4466(t0,t1,t2);}

C_noret_decl(trf_4493)
static void C_fcall trf_4493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4493(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4493(t0,t1,t2);}

C_noret_decl(trf_4315)
static void C_fcall trf_4315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4315(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4315(t0,t1,t2);}

C_noret_decl(trf_4342)
static void C_fcall trf_4342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4342(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4342(t0,t1,t2);}

C_noret_decl(trf_4234)
static void C_fcall trf_4234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4234(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4234(t0,t1,t2);}

C_noret_decl(trf_4261)
static void C_fcall trf_4261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4261(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4261(t0,t1,t2);}

C_noret_decl(trf_4200)
static void C_fcall trf_4200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4200(t0,t1);}

C_noret_decl(trf_3994)
static void C_fcall trf_3994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3994(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3994(t0,t1,t2);}

C_noret_decl(trf_4021)
static void C_fcall trf_4021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4021(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4021(t0,t1,t2);}

C_noret_decl(trf_4121)
static void C_fcall trf_4121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4121(t0,t1);}

C_noret_decl(trf_4052)
static void C_fcall trf_4052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4052(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4052(t0,t1);}

C_noret_decl(trf_3644)
static void C_fcall trf_3644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3644(t0,t1);}

C_noret_decl(trf_3650)
static void C_fcall trf_3650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3650(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3650(t0,t1,t2);}

C_noret_decl(trf_3693)
static void C_fcall trf_3693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3693(t0,t1);}

C_noret_decl(trf_3660)
static void C_fcall trf_3660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3660(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3660(t0,t1);}

C_noret_decl(trf_3619)
static void C_fcall trf_3619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3619(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3619(t0,t1,t2);}

C_noret_decl(trf_3494)
static void C_fcall trf_3494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3494(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3494(t0,t1);}

C_noret_decl(trf_3485)
static void C_fcall trf_3485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3485(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3485(t0,t1);}

C_noret_decl(trf_3418)
static void C_fcall trf_3418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3418(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3418(t0,t1,t2);}

C_noret_decl(trf_3287)
static void C_fcall trf_3287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3287(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3287(t0,t1,t2,t3);}

C_noret_decl(trf_3263)
static void C_fcall trf_3263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3263(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3263(t0,t1);}

C_noret_decl(trf_2763)
static void C_fcall trf_2763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2763(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2763(t0,t1,t2);}

C_noret_decl(trf_2767)
static void C_fcall trf_2767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2767(t0,t1);}

C_noret_decl(trf_3149)
static void C_fcall trf_3149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3149(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3149(t0,t1,t2);}

C_noret_decl(trf_3157)
static void C_fcall trf_3157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3157(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3157(t0,t1,t2);}

C_noret_decl(trf_3093)
static void C_fcall trf_3093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3093(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3093(t0,t1,t2);}

C_noret_decl(trf_2490)
static void C_fcall trf_2490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2490(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2490(t0,t1,t2);}

C_noret_decl(trf_2503)
static void C_fcall trf_2503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2503(t0,t1);}

C_noret_decl(trf_2557)
static void C_fcall trf_2557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2557(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2557(t0,t1,t2,t3);}

C_noret_decl(trf_2535)
static void C_fcall trf_2535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2535(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2535(t0,t1,t2);}

C_noret_decl(trf_2444)
static void C_fcall trf_2444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2444(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2444(t0,t1,t2);}

C_noret_decl(trf_2356)
static void C_fcall trf_2356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2356(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2356(t0,t1,t2);}

C_noret_decl(trf_2232)
static void C_fcall trf_2232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2232(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2232(t0,t1);}

C_noret_decl(trf_2398)
static void C_fcall trf_2398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2398(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2398(t0,t1,t2);}

C_noret_decl(trf_2302)
static void C_fcall trf_2302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2302(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2302(t0,t1);}

C_noret_decl(trf_2309)
static void C_fcall trf_2309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2309(t0,t1);}

C_noret_decl(trf_2126)
static void C_fcall trf_2126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2126(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2126(t0,t1);}

C_noret_decl(trf_2005)
static void C_fcall trf_2005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2005(t0,t1);}

C_noret_decl(trf_2027)
static void C_fcall trf_2027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2027(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2027(t0,t1);}

C_noret_decl(trf_1942)
static void C_fcall trf_1942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1942(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1942(t0);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1502)){
C_save(t1);
C_rereclaim2(1502*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,349);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\003csi");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\013chicken-bug");
lf[15]=C_h_intern(&lf[15],24,"setup-api#host-extension");
lf[17]=C_h_intern(&lf[17],24,"setup-api#chicken-prefix");
lf[18]=C_h_intern(&lf[18],19,"setup-api#shellpath");
lf[19]=C_h_intern(&lf[19],2,"qs");
lf[20]=C_h_intern(&lf[20],18,"normalize-pathname");
lf[21]=C_h_intern(&lf[21],23,"setup-api#cross-chicken");
lf[23]=C_h_intern(&lf[23],30,"setup-api#setup-root-directory");
lf[24]=C_h_intern(&lf[24],28,"setup-api#setup-verbose-mode");
lf[25]=C_h_intern(&lf[25],28,"setup-api#setup-install-mode");
lf[26]=C_h_intern(&lf[26],25,"setup-api#deployment-mode");
lf[27]=C_h_intern(&lf[27],22,"setup-api#program-path");
lf[28]=C_h_intern(&lf[28],28,"setup-api#keep-intermediates");
lf[36]=C_h_intern(&lf[36],4,"copy");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\011del /Q /S");
lf[38]=C_h_intern(&lf[38],4,"move");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\006rm -fr");
lf[43]=C_h_intern(&lf[43],2,"mv");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\005mkdir");
lf[47]=C_h_intern(&lf[47],22,"setup-api#sudo-install");
lf[48]=C_h_intern(&lf[48],5,"print");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: cannot install as superuser with Windows");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo cp -r");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo rm -fr");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\007sudo mv");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo chmod");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo ranlib");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo mkdir");
lf[56]=C_h_intern(&lf[56],21,"setup-api#abort-setup");
lf[57]=C_h_intern(&lf[57],20,"setup-api#yes-or-no\077");
lf[58]=C_h_intern(&lf[58],19,"\003sysstandard-output");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[62]=C_h_intern(&lf[62],19,"\003syswrite-char/port");
lf[63]=C_h_intern(&lf[63],7,"display");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000$Please enter \042yes\042, \042no\042 or \042abort\042.");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[67]=C_h_intern(&lf[67],9,"read-line");
lf[68]=C_h_intern(&lf[68],12,"flush-output");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\002] ");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\020 (yes/no/abort) ");
lf[71]=C_h_intern(&lf[71],15,"\003sysget-keyword");
lf[72]=C_h_intern(&lf[72],6,"\000abort");
lf[73]=C_h_intern(&lf[73],8,"\000default");
lf[74]=C_h_intern(&lf[74],15,"setup-api#patch");
lf[75]=C_h_intern(&lf[75],10,"write-line");
lf[76]=C_h_intern(&lf[76],17,"string-substitute");
lf[77]=C_h_intern(&lf[77],20,"with-input-from-file");
lf[78]=C_h_intern(&lf[78],19,"with-output-to-file");
lf[80]=C_h_intern(&lf[80],17,"get-output-string");
lf[81]=C_h_intern(&lf[81],18,"open-output-string");
lf[82]=C_h_intern(&lf[82],21,"create-temporary-file");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\011patching ");
lf[85]=C_h_intern(&lf[85],21,"setup-api#run-verbose");
lf[87]=C_h_intern(&lf[87],26,"pathname-replace-extension");
lf[88]=C_h_intern(&lf[88],26,"\003sysload-dynamic-extension");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[91]=C_h_intern(&lf[91],18,"pathname-extension");
lf[92]=C_h_intern(&lf[92],17,"setup-api#execute");
lf[93]=C_h_intern(&lf[93],16,"\003sysflush-output");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[95]=C_h_intern(&lf[95],18,"string-intersperse");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[103]=C_h_intern(&lf[103],5,"cons*");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\023compiling-extension");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\011-deployed");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[110]=C_h_intern(&lf[110],8,"feature\077");
lf[111]=C_h_intern(&lf[111],14,"\000cross-chicken");
lf[112]=C_h_intern(&lf[112],13,"make-pathname");
lf[113]=C_h_intern(&lf[113],8,"->string");
lf[115]=C_h_intern(&lf[115],5,"error");
lf[116]=C_h_intern(&lf[116],5,"write");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\013 for line: ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[122]=C_h_intern(&lf[122],6,"signal");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\025make: Failed to make ");
lf[125]=C_h_intern(&lf[125],22,"with-exception-handler");
lf[126]=C_h_intern(&lf[126],30,"call-with-current-continuation");
lf[127]=C_h_intern(&lf[127],13,"string-append");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\010 changed");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\007 date: ");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\027 just because (reason: ");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\017 does not exist");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\007making ");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\006make: ");
lf[136]=C_h_intern(&lf[136],22,"file-modification-time");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\015 was not made");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\013dependancy ");
lf[139]=C_h_intern(&lf[139],12,"file-exists\077");
lf[140]=C_h_intern(&lf[140],3,"any");
lf[141]=C_h_intern(&lf[141],12,"\003sysfor-each");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\027don\047t know how to make ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\011checking ");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\006make: ");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\013make: made ");
lf[147]=C_h_intern(&lf[147],7,"reverse");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[150]=C_h_intern(&lf[150],4,"caar");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[152]=C_h_intern(&lf[152],27,"condition-property-accessor");
lf[153]=C_h_intern(&lf[153],3,"exn");
lf[154]=C_h_intern(&lf[154],7,"message");
lf[155]=C_h_intern(&lf[155],19,"condition-predicate");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\047argument is not a string or string list");
lf[157]=C_h_intern(&lf[157],5,"every");
lf[158]=C_h_intern(&lf[158],7,"string\077");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000#command part of line is not a thunk");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\037dependency item is not a string");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000!second part of line is not a list");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\0004line does not start with a string or list of strings");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000$list is not a list with 2 or 3 parts");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\036specification is an empty list");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\033specification is not a list");
lf[166]=C_h_intern(&lf[166],12,"vector->list");
lf[167]=C_h_intern(&lf[167],19,"setup-api#make/proc");
lf[168]=C_h_intern(&lf[168],9,"\003syserror");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\0000no matching clause in call to \047case-lambda\047 form");
lf[170]=C_h_intern(&lf[170],29,"setup-api#installation-prefix");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\010  mkdir ");
lf[172]=C_h_intern(&lf[172],16,"create-directory");
lf[173]=C_h_intern(&lf[173],2,"-p");
lf[174]=C_h_intern(&lf[174],34,"setup-api#create-directory/parents");
lf[176]=C_h_intern(&lf[176],5,"files");
lf[177]=C_h_intern(&lf[177],3,"a+r");
lf[178]=C_h_intern(&lf[178],2,"pp");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[180]=C_h_intern(&lf[180],15,"repository-path");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\015writing info ");
lf[185]=C_h_intern(&lf[185],10,"\003sysappend");
lf[186]=C_h_intern(&lf[186],19,"setup-api#copy-file");
lf[188]=C_h_intern(&lf[188],14,"string-prefix\077");
lf[189]=C_h_intern(&lf[189],19,"setup-api#move-file");
lf[190]=C_h_intern(&lf[190],22,"setup-api#remove-file*");
lf[192]=C_h_intern(&lf[192],18,"absolute-pathname\077");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid file-specification");
lf[195]=C_h_intern(&lf[195],28,"setup-api#standard-extension");
lf[196]=C_h_intern(&lf[196],7,"version");
lf[197]=C_h_intern(&lf[197],27,"setup-api#install-extension");
lf[198]=C_h_intern(&lf[198],6,"static");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[202]=C_h_intern(&lf[202],3,"-d0");
lf[203]=C_h_intern(&lf[203],3,"-O2");
lf[204]=C_h_intern(&lf[204],2,"-s");
lf[205]=C_h_intern(&lf[205],3,"csc");
lf[206]=C_h_intern(&lf[206],5,"-unit");
lf[207]=C_h_intern(&lf[207],2,"-j");
lf[208]=C_h_intern(&lf[208],3,"-d1");
lf[209]=C_h_intern(&lf[209],2,"-c");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\012import.scm");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\003scm");
lf[212]=C_h_intern(&lf[212],5,"\000info");
lf[213]=C_h_intern(&lf[213],7,"\000static");
lf[214]=C_h_intern(&lf[214],6,"macosx");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[216]=C_h_intern(&lf[216],16,"software-version");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[218]=C_h_intern(&lf[218],25,"setup-api#install-program");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[225]=C_h_intern(&lf[225],24,"setup-api#install-script");
lf[226]=C_h_intern(&lf[226],4,"a+rx");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000Acannot create directory: a file with the same name already exists");
lf[231]=C_h_intern(&lf[231],10,"directory\077");
lf[232]=C_h_intern(&lf[232],3,"a+x");
lf[233]=C_h_intern(&lf[233],18,"pathname-directory");
lf[234]=C_h_intern(&lf[234],21,"setup-api#try-compile");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\012succeeded.");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\007failed.");
lf[237]=C_h_intern(&lf[237],6,"system");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\0042>&1");
lf[243]=C_h_intern(&lf[243],4,"conc");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\014 >/dev/null ");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[256]=C_h_intern(&lf[256],13,"\000compile-only");
lf[257]=C_h_intern(&lf[257],5,"\000verb");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[259]=C_h_intern(&lf[259],8,"\000ldflags");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[261]=C_h_intern(&lf[261],7,"\000cflags");
lf[262]=C_h_intern(&lf[262],3,"\000cc");
lf[263]=C_h_intern(&lf[263],4,"\000c++");
lf[264]=C_h_intern(&lf[264],34,"setup-api#required-chicken-version");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\026 or higher is required");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\020CHICKEN version ");
lf[267]=C_h_intern(&lf[267],20,"setup-api#version>=\077");
lf[268]=C_h_intern(&lf[268],15,"chicken-version");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000.and repeat the current installation operation.");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\022  chicken-install ");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\015 - please run");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\002\047 ");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\030the required extension `");
lf[277]=C_h_intern(&lf[277],36,"setup-api#required-extension-version");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\047, which is what this extension requires");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\016is older than ");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000%has no associated version information");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\020is not installed");
lf[282]=C_h_intern(&lf[282],21,"extension-information");
lf[283]=C_h_intern(&lf[283],30,"required-extension-information");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\023bad argument format");
lf[285]=C_h_intern(&lf[285],22,"setup-api#test-compile");
lf[286]=C_h_intern(&lf[286],22,"setup-api#find-library");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\017(); return 0; }");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\015int main() { ");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\003();");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\005char ");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\012extern \042C\042");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\022#ifdef __cplusplus");
lf[295]=C_h_intern(&lf[295],21,"setup-api#find-header");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\033>\012int main() { return 0; }\012");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\012#include <");
lf[298]=C_h_intern(&lf[298],19,"string-split-fields");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\006[-\134._]");
lf[300]=C_h_intern(&lf[300],6,"\000infix");
lf[301]=C_h_intern(&lf[301],8,"string>\077");
lf[302]=C_h_intern(&lf[302],36,"setup-api#extension-name-and-version");
lf[303]=C_h_intern(&lf[303],24,"setup-api#extension-name");
lf[304]=C_h_intern(&lf[304],27,"setup-api#extension-version");
lf[305]=C_h_intern(&lf[305],12,"string-null\077");
lf[306]=C_h_intern(&lf[306],19,"setup-api#read-info");
lf[307]=C_h_intern(&lf[307],4,"read");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\013.setup-info");
lf[309]=C_h_intern(&lf[309],36,"setup-api#create-temporary-directory");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install-");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\004/tmp");
lf[313]=C_h_intern(&lf[313],24,"get-environment-variable");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[317]=C_h_intern(&lf[317],26,"setup-api#remove-directory");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\014sudo rm -fr ");
lf[319]=C_h_intern(&lf[319],16,"delete-directory");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[322]=C_h_intern(&lf[322],11,"delete-file");
lf[323]=C_h_intern(&lf[323],9,"directory");
lf[324]=C_h_intern(&lf[324],16,"remove-directory");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000#cannot remove - directory not found");
lf[326]=C_h_intern(&lf[326],26,"setup-api#remove-extension");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000-shell command failed with nonzero exit status");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[331]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[333]=C_h_intern(&lf[333],7,"warning");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid extension-name-and-version");
lf[335]=C_h_intern(&lf[335],14,"make-parameter");
lf[336]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_INSTALL_PREFIX");
lf[338]=C_h_intern(&lf[338],4,"exit");
lf[339]=C_h_intern(&lf[339],17,"current-directory");
lf[340]=C_h_intern(&lf[340],17,"\003syspeek-c-string");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[344]=C_h_intern(&lf[344],17,"register-feature!");
lf[345]=C_h_intern(&lf[345],13,"chicken-setup");
lf[346]=C_h_intern(&lf[346],7,"windows");
lf[347]=C_h_intern(&lf[347],14,"build-platform");
lf[348]=C_h_intern(&lf[348],13,"software-type");
C_register_lf2(lf,349,create_ptable());
t2=C_mutate(&lf[0] /* (set! c741 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1771,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1769 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1772 in k1769 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1777,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1775 in k1772 in k1769 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1789,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1792,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5849,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[2],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5845,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5845,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[3],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5841,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[4],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_BUG_PROGRAM),C_fix(0));}

/* k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5837,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=C_mutate(&lf[6] /* (set! setup-api#*installed-executables* ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1810,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t9=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1810,2,t0,t1);}
t2=C_mutate(&lf[7] /* (set! setup-api#*cc* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}

/* k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=C_mutate(&lf[8] /* (set! setup-api#*cxx* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}

/* k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=C_mutate(&lf[9] /* (set! setup-api#*target-cflags* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}

/* k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
t2=C_mutate(&lf[10] /* (set! setup-api#*target-libs* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1826,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}

/* k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1826,2,t0,t1);}
t2=C_mutate(&lf[11] /* (set! setup-api#*target-lib-home* ...) */,t1);
t3=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
t4=C_mutate(&lf[13] /* (set! setup-api#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1832,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5805,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 89   software-type");
((C_proc2)C_retrieve_symbol_proc(lf[348]))(2,*((C_word*)lf[348]+1),t6);}

/* k5803 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,lf[346]);
if(C_truep(t2)){
C_trace("setup-api.scm: 90   build-platform");
((C_proc2)C_retrieve_symbol_proc(lf[347]))(2,*((C_word*)lf[347]+1),((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
f_1832(2,t3,C_SCHEME_FALSE);}}

/* k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1832,2,t0,t1);}
t2=C_mutate(&lf[14] /* (set! setup-api#*windows* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 92   register-feature!");
((C_proc3)C_retrieve_symbol_proc(lf[344]))(3,*((C_word*)lf[344]+1),t3,lf[345]);}

/* k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 94   make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),t2,C_SCHEME_FALSE);}

/* k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=C_mutate((C_word*)lf[15]+1 /* (set! setup-api#host-extension ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 97   get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),t3,lf[343]);}

/* k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
C_trace("setup-api.scm: 98   make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t2,t1,lf[342]);}
else{
t3=t2;
f_1846(2,t3,C_SCHEME_FALSE);}}

/* k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1849(2,t3,t1);}
else{
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1849,2,t0,t1);}
t2=C_mutate(&lf[16] /* (set! setup-api#*chicken-bin-path* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1853,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 102  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),t3,lf[341]);}

/* k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1856(2,t3,t1);}
else{
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[340]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_PREFIX),C_fix(0));}}

/* k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=C_mutate((C_word*)lf[17]+1 /* (set! setup-api#chicken-prefix ...) */,t1);
t3=C_mutate((C_word*)lf[18]+1 /* (set! setup-api#shellpath ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1858,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[21]+1 /* (set! setup-api#cross-chicken ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1868,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 111  current-directory");
((C_proc2)C_retrieve_symbol_proc(lf[339]))(2,*((C_word*)lf[339]+1),t5);}

/* k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
t2=C_mutate(&lf[22] /* (set! setup-api#*base-directory* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 113  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),t3,C_retrieve2(lf[22],"setup-api#*base-directory*"));}

/* k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=C_mutate((C_word*)lf[23]+1 /* (set! setup-api#setup-root-directory ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 114  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),t3,C_SCHEME_FALSE);}

/* k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! setup-api#setup-verbose-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 115  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),t3,C_SCHEME_TRUE);}

/* k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1 /* (set! setup-api#setup-install-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 116  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),t3,C_SCHEME_FALSE);}

/* k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1 /* (set! setup-api#deployment-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 117  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),t3,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"));}

/* k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1 /* (set! setup-api#program-path ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 118  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),t3,C_SCHEME_FALSE);}

/* k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! setup-api#keep-intermediates ...) */,t1);
t3=lf[29] /* setup-api#*copy-command* */ =C_SCHEME_UNDEFINED;;
t4=lf[30] /* setup-api#*remove-command* */ =C_SCHEME_UNDEFINED;;
t5=lf[31] /* setup-api#*move-command* */ =C_SCHEME_UNDEFINED;;
t6=lf[32] /* setup-api#*chmod-command* */ =C_SCHEME_UNDEFINED;;
t7=lf[33] /* setup-api#*ranlib-command* */ =C_SCHEME_UNDEFINED;;
t8=lf[34] /* setup-api#*mkdir-command* */ =C_SCHEME_UNDEFINED;;
t9=C_mutate(&lf[35] /* (set! setup-api#user-install-setup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1942,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[47]+1 /* (set! setup-api#sudo-install ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1968,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5782,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 173  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),t11,t12);}

/* a5781 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5782,2,t0,t1);}
t2=C_retrieve(lf[338]);
C_trace("g122123");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,C_fix(1));}

/* k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1991,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1 /* (set! setup-api#abort-setup ...) */,t1);
t3=C_mutate((C_word*)lf[57]+1 /* (set! setup-api#yes-or-no? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1993,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[74]+1 /* (set! setup-api#patch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2091,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2208,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 208  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),t5,C_SCHEME_TRUE);}

/* k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2208,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! setup-api#run-verbose ...) */,t1);
t3=C_mutate(&lf[86] /* (set! setup-api#fixmaketarget ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2302,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[92]+1 /* (set! setup-api#execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2328,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[114] /* (set! setup-api#make:form-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2535,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[118] /* (set! setup-api#make:line-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2557,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[121] /* (set! setup-api#make:make/proc/helper ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2763,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[167]+1 /* (set! setup-api#make/proc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3184,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3260,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5777,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 416  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),t10,lf[337]);}

/* k5775 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
C_trace("setup-api.scm: 415  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),((C_word*)t0)[2],t2);}
else{
t2=C_retrieve(lf[17]);
C_trace("setup-api.scm: 415  make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[335]))(3,*((C_word*)lf[335]+1),((C_word*)t0)[2],t2);}}

/* k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[70],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3260,2,t0,t1);}
t2=C_mutate((C_word*)lf[170]+1 /* (set! setup-api#installation-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3263,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5738,a[2]=t3,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5746,a[2]=t3,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[174]+1 /* (set! setup-api#create-directory/parents ...) */,t4);
t6=C_mutate(&lf[175] /* (set! setup-api#write-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3287,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[186]+1 /* (set! setup-api#copy-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3416,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[189]+1 /* (set! setup-api#move-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3542,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[190]+1 /* (set! setup-api#remove-file* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3597,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[191] /* (set! setup-api#make-dest-pathname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3619,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[193] /* (set! setup-api#check-filelist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3644,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[195]+1 /* (set! setup-api#standard-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3781,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[197]+1 /* (set! setup-api#install-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3967,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[218]+1 /* (set! setup-api#install-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4194,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[225]+1 /* (set! setup-api#install-script ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4413,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[181] /* (set! setup-api#repo-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4577,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[187] /* (set! setup-api#ensure-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4644,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[234]+1 /* (set! setup-api#try-compile ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4697,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[264]+1 /* (set! setup-api#required-chicken-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4821,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[269] /* (set! setup-api#upgrade-message ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4853,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[277]+1 /* (set! setup-api#required-extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4934,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[285]+1 /* (set! setup-api#test-compile ...) */,C_retrieve(lf[234]));
t23=C_mutate((C_word*)lf[286]+1 /* (set! setup-api#find-library ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5055,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[295]+1 /* (set! setup-api#find-header ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5114,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[267]+1 /* (set! setup-api#version>=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5136,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5335,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5668,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 689  make-parameter");
((C_proc4)C_retrieve_symbol_proc(lf[335]))(4,*((C_word*)lf[335]+1),t26,lf[336],t27);}

/* a5667 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5668,3,t0,t1,t2);}
t3=(C_word)C_i_not(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[331]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5684,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t6=(C_word)C_i_length(t2);
t7=t5;
f_5684(t7,(C_word)C_i_nequalp(C_fix(2),t6));}
else{
t6=t5;
f_5684(t6,C_SCHEME_FALSE);}}}

/* k5682 in a5667 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5684,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5691,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5714,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 697  ensure-string");
f_5691(t5,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 699  warning");
((C_proc4)C_retrieve_symbol_proc(lf[333]))(4,*((C_word*)lf[333]+1),t2,lf[334],((C_word*)t0)[3]);}}

/* k5719 in k5682 in a5667 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 700  extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[302]))(2,*((C_word*)lf[302]+1),((C_word*)t0)[2]);}

/* k5712 in k5682 in a5667 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5718,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 697  ensure-string");
f_5691(t2,((C_word*)t0)[2]);}

/* k5716 in k5712 in k5682 in a5667 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5718,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* ensure-string in k5682 in a5667 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5691(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5691,NULL,2,t1,t2);}
t3=(C_word)C_i_not(t2);
if(C_truep(t3)){
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[332]);}
else{
C_trace("setup-api.scm: 696  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),t1,t2);}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[332]);}
else{
C_trace("setup-api.scm: 696  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),t1,t2);}}}

/* k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5335,2,t0,t1);}
t2=C_mutate((C_word*)lf[302]+1 /* (set! setup-api#extension-name-and-version ...) */,t1);
t3=C_mutate((C_word*)lf[303]+1 /* (set! setup-api#extension-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5337,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[304]+1 /* (set! setup-api#extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5347,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[306]+1 /* (set! setup-api#read-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5391,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[309]+1 /* (set! setup-api#create-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5405,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[317]+1 /* (set! setup-api#remove-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5458,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[326]+1 /* (set! setup-api#remove-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5589,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[79] /* (set! setup-api#$system ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5643,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5666,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 763  user-install-setup");
f_1942(t10);}

/* k5664 in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* setup-api#$system in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5643(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5643,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5647,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5660,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
C_trace("setup-api.scm: 755  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[127]+1)))(5,*((C_word*)lf[127]+1),t4,lf[329],t2,lf[330]);}
else{
t5=t2;
C_trace("setup-api.scm: 753  system");
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t3,t5);}}

/* k5658 in setup-api#$system in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 753  system");
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),((C_word*)t0)[2],t1);}

/* k5645 in setup-api#$system in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
C_trace("setup-api.scm: 758  error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[328],t1,((C_word*)t0)[2]);}}

/* setup-api#remove-extension in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5589,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5641,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 748  read-info");
((C_proc3)C_retrieve_symbol_proc(lf[306]))(3,*((C_word*)lf[306]+1),t3,t2);}

/* k5639 in setup-api#remove-extension in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5641,2,t0,t1);}
t2=(C_word)C_i_assq(lf[176],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5616,a[2]=t6,a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5616(t8,t3,t4);}
else{
t4=t3;
f_5596(2,t4,C_SCHEME_FALSE);}}

/* loop1650 in k5639 in setup-api#remove-extension in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5616,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[190]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5626,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
C_trace("g16571658");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5624 in loop1650 in k5639 in setup-api#remove-extension in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5616(t3,((C_word*)t0)[2],t2);}

/* k5594 in k5639 in setup-api#remove-extension in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5607,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 750  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[180]))(2,*((C_word*)lf[180]+1),t3);}

/* k5605 in k5594 in k5639 in setup-api#remove-extension in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 750  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[327]);}

/* k5601 in k5594 in k5639 in setup-api#remove-extension in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 750  remove-file*");
((C_proc3)C_retrieve_symbol_proc(lf[190]))(3,*((C_word*)lf[190]+1),((C_word*)t0)[2],t1);}

/* setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5458r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5458r(t0,t1,t2,t3);}}

static void C_ccall f_5458r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5462,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5462(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5462(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5568,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 728  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t2,((C_word*)t0)[2]);}

/* k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5568,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve2(lf[12],"setup-api#*sudo*"))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5502,a[2]=t3,a[3]=((C_word)li93),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5502(t5,((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-api.scm: 730  error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[4],lf[324],lf[325],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* walk in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5502(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5502,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5506,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 736  directory");
((C_proc4)C_retrieve_symbol_proc(lf[323]))(4,*((C_word*)lf[323]+1),t3,t2,C_SCHEME_TRUE);}

/* k5504 in walk in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5514,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word)li92),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5514(t6,t2,t1);}

/* loop1620 in k5504 in walk in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5514(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5514,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5522,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5553,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
C_trace("g16271628");
t6=t3;
f_5522(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5551 in loop1620 in k5504 in walk in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5514(t3,((C_word*)t0)[2],t2);}

/* g1627 in loop1620 in k5504 in walk in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5522(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5522,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_string_equal_p(lf[320],t2);
t4=(C_truep(t3)?t3:(C_word)C_i_string_equal_p(lf[321],t2));
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5535,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 740  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t5,((C_word*)t0)[2],t2);}}

/* k5533 in g1627 in loop1620 in k5504 in walk in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5541,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 741  directory?");
((C_proc3)C_retrieve_symbol_proc(lf[231]))(3,*((C_word*)lf[231]+1),t2,t1);}

/* k5539 in k5533 in g1627 in loop1620 in k5504 in walk in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 742  walk");
t2=((C_word*)((C_word*)t0)[4])[1];
f_5502(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("setup-api.scm: 743  delete-file");
((C_proc3)C_retrieve_symbol_proc(lf[322]))(3,*((C_word*)lf[322]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5507 in k5504 in walk in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 745  delete-directory");
((C_proc3)C_retrieve_symbol_proc(lf[319]))(3,*((C_word*)lf[319]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5482 in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5487,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[318],t1);}

/* k5485 in k5482 in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5490,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5497,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 733  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}

/* k5495 in k5485 in k5482 in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5488 in k5485 in k5482 in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k5491 in k5488 in k5485 in k5482 in k5566 in k5460 in setup-api#remove-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 733  $system");
f_5643(((C_word*)t0)[2],t1);}

/* setup-api#create-temporary-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5409,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 717  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),t2,lf[316]);}

/* k5407 in setup-api#create-temporary-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5412,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5412(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 718  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),t3,lf[315]);}}

/* k5445 in k5407 in setup-api#create-temporary-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5447,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_5412(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5453,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 719  get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),t2,lf[314]);}}

/* k5451 in k5445 in k5407 in setup-api#create-temporary-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5412(t2,(C_truep(t1)?t1:lf[312]));}

/* k5410 in k5407 in setup-api#create-temporary-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5412(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5412,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5417,a[2]=t1,a[3]=t3,a[4]=((C_word)li89),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5417(t5,((C_word*)t0)[2]);}

/* loop in k5410 in k5407 in setup-api#create-temporary-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5417(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5417,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5424,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5440,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5444,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 723  number->string");
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k5442 in loop in k5410 in k5407 in setup-api#create-temporary-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 723  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),((C_word*)t0)[2],lf[311],t1);}

/* k5438 in loop in k5410 in k5407 in setup-api#create-temporary-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 723  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[310]);}

/* k5422 in loop in k5410 in k5407 in setup-api#create-temporary-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5430,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 724  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t2,t1);}

/* k5428 in k5422 in loop in k5410 in k5407 in setup-api#create-temporary-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
if(C_truep(t1)){
C_trace("setup-api.scm: 724  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_5417(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 725  create-directory");
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t2,((C_word*)t0)[2]);}}

/* k5434 in k5428 in k5422 in loop in k5410 in k5407 in setup-api#create-temporary-directory in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* setup-api#read-info in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5391,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5399,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5403,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 713  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[180]))(2,*((C_word*)lf[180]+1),t4);}

/* k5401 in setup-api#read-info in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 713  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[308]);}

/* k5397 in setup-api#read-info in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 712  with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),((C_word*)t0)[2],t1,*((C_word*)lf[307]+1));}

/* setup-api#extension-version in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5347r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5347r(t0,t1,t2);}}

static void C_ccall f_5347r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5351,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_5351(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_5351(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k5349 in setup-api#extension-version in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5370,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 706  extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[302]))(2,*((C_word*)lf[302]+1),t2);}

/* k5368 in k5349 in setup-api#extension-version in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5370,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5360,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 707  string-null?");
((C_proc3)C_retrieve_symbol_proc(lf[305]))(3,*((C_word*)lf[305]+1),t3,t2);}

/* k5358 in k5368 in k5349 in setup-api#extension-version in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-api.scm: 708  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* setup-api#extension-name in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5345,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 703  extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[302]))(2,*((C_word*)lf[302]+1),t2);}

/* k5343 in setup-api#extension-name in k5333 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}

/* setup-api#version>=? in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5136,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5139,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5201,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 673  version->list");
f_5139(t5,t2);}

/* k5199 in setup-api#version>=? in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5205,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 674  version->list");
f_5139(t2,((C_word*)t0)[2]);}

/* k5203 in k5199 in setup-api#version>=? in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5205,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5207,a[2]=t3,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5207(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k5203 in k5199 in setup-api#version>=? in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5207(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5207,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_numberp(t5))){
t6=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_numberp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_greaterp(t7,t8);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t10=(C_word)C_i_car(t2);
t11=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_nequalp(t10,t11))){
t12=(C_word)C_i_cdr(t2);
t13=(C_word)C_i_cdr(t3);
C_trace("setup-api.scm: 681  loop");
t20=t1;
t21=t12;
t22=t13;
t1=t20;
t2=t21;
t3=t22;
goto loop;}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_numberp(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5287,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_car(t3);
C_trace("setup-api.scm: 683  string>?");
((C_proc4)C_retrieve_proc(*((C_word*)lf[301]+1)))(4,*((C_word*)lf[301]+1),t8,t9,t10);}}}}}

/* k5285 in loop in k5203 in k5199 in setup-api#version>=? in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_string_equal_p(t2,t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 686  loop");
t6=((C_word*)((C_word*)t0)[2])[1];
f_5207(t6,((C_word*)t0)[5],t4,t5);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* version->list in setup-api#version>=? in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5139(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5139,NULL,2,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5147,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5194,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 672  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),t8,t2);}

/* k5192 in version->list in setup-api#version>=? in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 672  string-split-fields");
((C_proc5)C_retrieve_symbol_proc(lf[298]))(5,*((C_word*)lf[298]+1),((C_word*)t0)[2],lf[299],t1,lf[300]);}

/* k5145 in version->list in setup-api#version>=? in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5147,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5149,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5149(t5,((C_word*)t0)[2],t1);}

/* loop1452 in k5145 in version->list in setup-api#version>=? in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5149(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5149,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5159,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5180,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 671  string->number");
C_string_to_number(3,0,t5,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5178 in loop1452 in k5145 in version->list in setup-api#version>=? in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5180,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_5159(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
t2=((C_word*)t0)[3];
f_5159(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}}

/* k5157 in loop1452 in k5145 in version->list in setup-api#version>=? in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_5159(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop14521465");
t5=((C_word*)((C_word*)t0)[4])[1];
f_5149(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop14521465");
t5=((C_word*)((C_word*)t0)[4])[1];
f_5149(t5,((C_word*)t0)[3],t4);}}

/* setup-api#find-header in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5114,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5122,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t3);}

/* k5120 in setup-api#find-header in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5125,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[297],t1);}

/* k5123 in k5120 in setup-api#find-header in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5126 in k5123 in k5120 in setup-api#find-header in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[296],((C_word*)t0)[2]);}

/* k5129 in k5126 in k5123 in k5120 in setup-api#find-header in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k5132 in k5129 in k5126 in k5123 in k5120 in setup-api#find-header in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 665  test-compile");
((C_proc5)C_retrieve_symbol_proc(lf[285]))(5,*((C_word*)lf[285]+1),((C_word*)t0)[2],t1,lf[256],C_SCHEME_TRUE);}

/* setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5055,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5063,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t4);}

/* k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5066,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[294],t1);}

/* k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[293],((C_word*)t0)[3]);}

/* k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[292],((C_word*)t0)[3]);}

/* k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[291],((C_word*)t0)[3]);}

/* k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5090,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[290],((C_word*)t0)[3]);}

/* k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[289],((C_word*)t0)[3]);}

/* k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5099,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[288],((C_word*)t0)[2]);}

/* k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5108,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5112,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 662  conc");
((C_proc4)C_retrieve_symbol_proc(lf[243]))(4,*((C_word*)lf[243]+1),t2,lf[287],((C_word*)t0)[2]);}

/* k5110 in k5106 in k5103 in k5100 in k5097 in k5094 in k5091 in k5088 in k5085 in k5082 in k5079 in k5076 in k5073 in k5070 in k5067 in k5064 in k5061 in setup-api#find-library in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 660  test-compile");
((C_proc5)C_retrieve_symbol_proc(lf[285]))(5,*((C_word*)lf[285]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[259],t1);}

/* setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_4934r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4934r(t0,t1,t2);}}

static void C_ccall f_4934r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4940,a[2]=t4,a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4940(t6,t1,t2);}

/* loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4940(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4940,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4953,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=t3;
f_4953(t5,(C_word)C_i_greater_or_equalp(t4,C_fix(2)));}
else{
t4=t3;
f_4953(t4,C_SCHEME_FALSE);}}}

/* k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4953,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4965,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 642  extension-information");
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t5,t2);}
else{
C_trace("setup-api.scm: 655  error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[115]+1)))(5,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[283],lf[284],((C_word*)t0)[4]);}}

/* k4963 in k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[196],t1))){
t3=(C_word)C_i_assq(lf[196],t1);
t4=t2;
f_4971(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_4971(t3,C_SCHEME_FALSE);}}
else{
C_trace("setup-api.scm: 653  upgrade-message");
f_4853(((C_word*)t0)[6],((C_word*)t0)[5],lf[281],C_SCHEME_END_OF_LIST);}}

/* k4969 in k4963 in k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4971,NULL,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5011,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 646  version>=?");
((C_proc4)C_retrieve_symbol_proc(lf[267]))(4,*((C_word*)lf[267]+1),t4,((C_word*)t0)[4],t1);}
else{
C_trace("setup-api.scm: 645  upgrade-message");
f_4853(((C_word*)t0)[6],((C_word*)t0)[5],lf[280],C_SCHEME_END_OF_LIST);}}

/* k5009 in k4969 in k4963 in k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 646  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_4986(t2,C_SCHEME_FALSE);}}

/* k5020 in k5009 in k4969 in k4963 in k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5026,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 646  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2]);}

/* k5024 in k5020 in k5009 in k4969 in k4963 in k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_4986(t3,(C_word)C_i_not(t2));}

/* k4984 in k4969 in k4963 in k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4986(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4986,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4993,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t2);}
else{
C_trace("setup-api.scm: 652  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_4940(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k4991 in k4984 in k4969 in k4963 in k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4996,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[279],t1);}

/* k4994 in k4991 in k4984 in k4969 in k4963 in k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4997 in k4994 in k4991 in k4984 in k4969 in k4963 in k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[278],((C_word*)t0)[2]);}

/* k5000 in k4997 in k4994 in k4991 in k4984 in k4969 in k4963 in k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k5003 in k5000 in k4997 in k4994 in k4991 in k4984 in k4969 in k4963 in k4951 in loop in setup-api#required-extension-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5005,2,t0,t1);}
C_trace("setup-api.scm: 647  upgrade-message");
f_4853(((C_word*)t0)[4],((C_word*)t0)[3],t1,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4853(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4853,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4857,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_4857(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4857(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t2);}

/* k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4867,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[276],t1);}

/* k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),t2,((C_word*)t0)[3],((C_word*)t0)[5]);}

/* k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[275],((C_word*)t0)[5]);}

/* k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[274],((C_word*)t0)[4]);}

/* k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k4880 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k4883 in k4880 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[273],((C_word*)t0)[4]);}

/* k4886 in k4883 in k4880 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4891,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4889 in k4886 in k4883 in k4880 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-api.scm: 633  conc");
((C_proc4)C_retrieve_symbol_proc(lf[243]))(4,*((C_word*)lf[243]+1),t3,lf[271],((C_word*)t0)[2]);}
else{
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[272],((C_word*)t0)[3]);}}

/* k4908 in k4889 in k4886 in k4883 in k4880 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4892 in k4889 in k4886 in k4883 in k4880 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4895 in k4892 in k4889 in k4886 in k4883 in k4880 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4898 in k4895 in k4892 in k4889 in k4886 in k4883 in k4880 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[270],((C_word*)t0)[2]);}

/* k4901 in k4898 in k4895 in k4892 in k4889 in k4886 in k4883 in k4880 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4906,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k4904 in k4901 in k4898 in k4895 in k4892 in k4889 in k4886 in k4883 in k4880 in k4877 in k4874 in k4871 in k4868 in k4865 in k4862 in k4855 in setup-api#upgrade-message in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 630  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* setup-api#required-chicken-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4821,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4828,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4851,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 626  chicken-version");
((C_proc2)C_retrieve_symbol_proc(lf[268]))(2,*((C_word*)lf[268]+1),t4);}

/* k4849 in setup-api#required-chicken-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 626  version>=?");
((C_proc4)C_retrieve_symbol_proc(lf[267]))(4,*((C_word*)lf[267]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4826 in setup-api#required-chicken-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4828,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4833 in k4826 in setup-api#required-chicken-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4838,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[266],t1);}

/* k4836 in k4833 in k4826 in setup-api#required-chicken-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4839 in k4836 in k4833 in k4826 in setup-api#required-chicken-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[265],((C_word*)t0)[2]);}

/* k4842 in k4839 in k4836 in k4833 in k4826 in setup-api#required-chicken-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4847,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k4845 in k4842 in k4839 in k4836 in k4833 in k4826 in setup-api#required-chicken-version in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 627  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4697r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4697r(t0,t1,t2,t3);}}

static void C_ccall f_4697r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4701,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[71]))(4,*((C_word*)lf[71]+1),t4,lf[263],t3);}

/* k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4815,a[2]=t1,a[3]=((C_word)li74),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[71]))(5,*((C_word*)lf[71]+1),t2,lf[262],((C_word*)t0)[2],t3);}

/* a4814 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4815,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_retrieve2(lf[8],"setup-api#*cxx*");
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve2(lf[8],"setup-api#*cxx*"));}
else{
t2=C_retrieve2(lf[7],"setup-api#*cc*");
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve2(lf[7],"setup-api#*cc*"));}}

/* k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4812,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[71]))(5,*((C_word*)lf[71]+1),t2,lf[261],((C_word*)t0)[2],t3);}

/* a4811 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4812,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[260]);}

/* k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4809,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[71]))(5,*((C_word*)lf[71]+1),t2,lf[259],((C_word*)t0)[2],t3);}

/* a4808 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4809,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[258]);}

/* k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4803,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[71]))(5,*((C_word*)lf[71]+1),t2,lf[257],((C_word*)t0)[2],t3);}

/* a4802 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
C_trace("setup-api.scm: 603  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t1);}

/* k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4800,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[71]))(5,*((C_word*)lf[71]+1),t2,lf[256],((C_word*)t0)[2],t3);}

/* a4799 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4800,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 604  create-temporary-file");
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t2,lf[255]);}

/* k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm: 605  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),t2,t1,lf[254]);}

/* k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4725,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4794,a[2]=((C_word*)t0)[2],a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 607  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t2,((C_word*)t0)[8],t3);}

/* a4793 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4794,2,t0,t1);}
t2=*((C_word*)lf[63]+1);
C_trace("g13121313");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4771,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(((C_word*)t0)[5])?lf[239]:lf[240]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4785,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=t5;
f_4785(2,t6,lf[250]);}
else{
C_trace("setup-api.scm: 616  conc");
((C_proc8)C_retrieve_symbol_proc(lf[243]))(8,*((C_word*)lf[243]+1),t5,lf[251],C_retrieve2(lf[11],"setup-api#*target-lib-home*"),lf[252],((C_word*)t0)[2],lf[253],C_retrieve2(lf[10],"setup-api#*target-libs*"));}}

/* k4783 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?lf[241]:lf[242]);
C_trace("setup-api.scm: 609  conc");
((C_proc15)C_retrieve_symbol_proc(lf[243]))(15,*((C_word*)lf[243]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[244],((C_word*)t0)[4],lf[245],((C_word*)t0)[3],lf[246],C_retrieve2(lf[9],"setup-api#*target-cflags*"),lf[247],((C_word*)t0)[2],lf[248],t1,lf[249],t2);}

/* k4769 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4774,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-api.scm: 619  print");
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t2,t1,lf[238]);}
else{
t3=t1;
C_trace("setup-api.scm: 608  system");
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),((C_word*)t0)[3],t3);}}

/* k4772 in k4769 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 608  system");
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep((C_word)C_i_zerop(t1))){
C_trace("setup-api.scm: 621  print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t2,lf[235]);}
else{
C_trace("setup-api.scm: 621  print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t2,lf[236]);}}
else{
t3=t2;
f_4731(2,t3,C_SCHEME_UNDEFINED);}}

/* k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4741,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t3);}

/* k4739 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,C_retrieve2(lf[30],"setup-api#*remove-command*"),t1);}

/* k4742 in k4739 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k4745 in k4742 in k4739 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4757,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 622  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}

/* k4755 in k4745 in k4742 in k4739 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4748 in k4745 in k4742 in k4739 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4753,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k4751 in k4748 in k4745 in k4742 in k4739 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 622  $system");
f_5643(((C_word*)t0)[2],t1);}

/* k4732 in k4729 in k4726 in k4723 in k4720 in k4717 in k4714 in k4711 in k4708 in k4705 in k4702 in k4699 in setup-api#try-compile in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_zerop(((C_word*)t0)[2]));}

/* setup-api#ensure-directory in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4644(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4644,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4648,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 592  pathname-directory");
((C_proc3)C_retrieve_symbol_proc(lf[233]))(3,*((C_word*)lf[233]+1),t3,t2);}

/* k4646 in setup-api#ensure-directory in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4657,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 593  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t3,t1);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* k4655 in k4646 in setup-api#ensure-directory in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 594  directory?");
((C_proc3)C_retrieve_symbol_proc(lf[231]))(3,*((C_word*)lf[231]+1),t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 597  create-directory/parents");
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t2,((C_word*)t0)[2]);}}

/* k4667 in k4655 in k4646 in setup-api#ensure-directory in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4669,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4695,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 599  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}}

/* k4693 in k4667 in k4655 in k4646 in setup-api#ensure-directory in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4695,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[232],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k4661 in k4655 in k4646 in setup-api#ensure-directory in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
C_trace("setup-api.scm: 595  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],lf[230]);}}

/* k4649 in k4646 in setup-api#ensure-directory in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#repo-path in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4577(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4577,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4581,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4581(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4581(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4579 in setup-api#repo-path in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4584,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4593,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 582  deployment-mode");
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t3);}
else{
C_trace("setup-api.scm: 587  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[180]))(2,*((C_word*)lf[180]+1),t2);}}

/* k4591 in k4579 in setup-api#repo-path in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
if(C_truep(t1)){
C_trace("setup-api.scm: 583  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[170]))(2,*((C_word*)lf[170]+1),((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4603,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 585  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[170]))(2,*((C_word*)lf[170]+1),t2);}}

/* k4601 in k4591 in k4579 in setup-api#repo-path in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4607,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t2);}

/* k4605 in k4601 in k4591 in k4579 in setup-api#repo-path in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4610,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[229],t1);}

/* k4608 in k4605 in k4601 in k4591 in k4579 in setup-api#repo-path in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_fudge(C_fix(42));
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[2]);}

/* k4611 in k4608 in k4605 in k4601 in k4591 in k4579 in setup-api#repo-path in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k4614 in k4611 in k4608 in k4605 in k4601 in k4591 in k4579 in setup-api#repo-path in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 584  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4582 in k4579 in setup-api#repo-path in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4587,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 588  ensure-directory");
f_4644(t2,t1);}

/* k4585 in k4582 in k4579 in setup-api#repo-path in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4413r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4413r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4413r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4417,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_4417(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4417(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4423,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 561  setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t2);}

/* k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4423,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4426,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
C_trace("setup-api.scm: 562  check-filelist");
f_3644(t2,t3);}
else{
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("setup-api.scm: 562  check-filelist");
f_3644(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4429,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 563  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[170]))(2,*((C_word*)lf[170]+1),t2);}

/* k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4546,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 564  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t3,t1,lf[228]);}

/* k4544 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 564  ensure-directory");
f_4644(((C_word*)t0)[2],t1);}

/* k4430 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4432,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4466,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=((C_word)li65),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_4466(t10,t6,((C_word*)t0)[2]);}

/* loop1205 in k4430 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4466(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4466,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4493,a[2]=((C_word*)t0)[5],a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4538,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
C_trace("g12211222");
t6=t3;
f_4493(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4536 in loop1205 in k4430 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4538,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop12051218");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4466(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop12051218");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4466(t6,((C_word*)t0)[3],t5);}}

/* g1221 in loop1205 in k4430 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4493(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4493,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4500,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 567  make-dest-pathname");
f_3619(t5,((C_word*)t0)[2],t2);}

/* k4498 in g1221 in loop1205 in k4430 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4503,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 568  copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[186]))(4,*((C_word*)lf[186]+1),t2,((C_word*)t0)[2],t1);}

/* k4501 in k4498 in g1221 in loop1205 in k4430 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4529,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 570  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}}

/* k4527 in k4501 in k4498 in g1221 in loop1205 in k4430 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4529,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[177],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k4504 in k4501 in k4498 in g1221 in loop1205 in k4430 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4433 in k4430 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4438,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
C_trace("setup-api.scm: 575  write-info");
f_3287(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4464,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 574  string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t3,t1,lf[227]);}}

/* k4462 in k4433 in k4430 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4464,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[226],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k4436 in k4433 in k4430 in k4427 in k4424 in k4421 in k4415 in setup-api#install-script in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 575  write-info");
f_3287(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4194r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4194r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4194r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4198,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_4198(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4198(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4200,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4214,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 539  setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t3);}

/* k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4214,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
C_trace("setup-api.scm: 540  check-filelist");
f_3644(t2,t3);}
else{
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("setup-api.scm: 540  check-filelist");
f_3644(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4220,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 541  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[170]))(2,*((C_word*)lf[170]+1),t2);}

/* k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4382,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 542  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t3,t1,lf[224]);}

/* k4380 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 542  ensure-directory");
f_4644(((C_word*)t0)[2],t1);}

/* k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4226,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4315,a[2]=t4,a[3]=t8,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word)li62),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_4315(t10,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_4226(2,t3,((C_word*)t0)[2]);}}

/* loop1121 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4315(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4315,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4342,a[2]=((C_word*)t0)[5],a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4374,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
C_trace("g11371138");
t6=t3;
f_4342(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4372 in loop1121 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4374,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop11211134");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4315(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop11211134");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4315(t6,((C_word*)t0)[3],t5);}}

/* g1137 in loop1121 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4342(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4342,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4356,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
C_trace("setup-api.scm: 546  exify");
f_4200(t3,t4);}
else{
C_trace("setup-api.scm: 547  exify");
f_4200(t1,t2);}}

/* k4354 in g1137 in loop1121 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4360,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 546  exify");
f_4200(t2,t3);}

/* k4358 in k4354 in g1137 in loop1121 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4360,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k4224 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4226,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4229,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4234,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li60),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_4234(t10,t6,t1);}

/* loop1146 in k4224 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4234(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4234,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4261,a[2]=((C_word*)t0)[5],a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
C_trace("g11621163");
t6=t3;
f_4261(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4304 in loop1146 in k4224 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop11461159");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4234(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop11461159");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4234(t6,((C_word*)t0)[3],t5);}}

/* g1162 in loop1146 in k4224 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4261(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4261,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4268,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 552  make-dest-pathname");
f_3619(t5,((C_word*)t0)[2],t2);}

/* k4266 in g1162 in loop1146 in k4224 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4271,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 553  copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[186]))(4,*((C_word*)lf[186]+1),t2,((C_word*)t0)[2],t1);}

/* k4269 in k4266 in g1162 in loop1146 in k4224 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4297,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 555  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}}

/* k4295 in k4269 in k4266 in g1162 in loop1146 in k4224 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4297,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[177],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k4272 in k4269 in k4266 in g1162 in loop1146 in k4224 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4227 in k4224 in k4221 in k4218 in k4215 in k4212 in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 558  write-info");
f_3287(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* exify in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4200(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4200,NULL,2,t1,t2);}
t3=(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?lf[219]:C_SCHEME_FALSE);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3732,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3732(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3732(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3730 in exify in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3739,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 482  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[91]))(3,*((C_word*)lf[91]+1),t2,((C_word*)t0)[2]);}

/* k3737 in k3730 in exify in k4196 in setup-api#install-program in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=t1;
if(C_truep(t2)){
if(C_truep((C_word)C_i_equalp(lf[220],t1))){
t3=C_retrieve(lf[88]);
C_trace("setup-api.scm: 481  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3);}
else{
if(C_truep((C_word)C_i_equalp(lf[221],t1))){
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
C_trace("setup-api.scm: 481  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[222]);}
else{
C_trace("setup-api.scm: 481  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[223]);}}
else{
t3=t1;
C_trace("setup-api.scm: 481  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3);}}}
else{
t3=((C_word*)t0)[2];
C_trace("setup-api.scm: 481  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3);}}

/* setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3967r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3967r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3967r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3971,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3971(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3971(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 512  setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t2);}

/* k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
C_trace("setup-api.scm: 513  check-filelist");
f_3644(t2,t3);}
else{
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("setup-api.scm: 513  check-filelist");
f_3644(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3983,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 514  repo-path");
f_4577(t2,C_SCHEME_END_OF_LIST);}

/* k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3986,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 515  repo-path");
f_4577(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3986,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3994,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word)li56),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_3994(t10,t6,((C_word*)t0)[2]);}

/* loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3994(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3994,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4159,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
C_trace("g10491050");
t6=t3;
f_4021(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4157 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4159,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop10331046");
t6=((C_word*)((C_word*)t0)[4])[1];
f_3994(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop10331046");
t6=((C_word*)((C_word*)t0)[4])[1];
f_3994(t6,((C_word*)t0)[3],t5);}}

/* g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4021(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4021,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4028,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 518  make-dest-pathname");
f_3619(t5,((C_word*)t0)[2],t2);}

/* k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4121,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[14],"setup-api#*windows*");
if(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))){
t5=t3;
f_4121(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4150,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 520  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[91]))(3,*((C_word*)lf[91]+1),t5,t1);}}

/* k4148 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4121(t2,(C_word)C_i_equalp(lf[217],t1));}

/* k4119 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4121,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4140,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 521  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4031(2,t2,C_SCHEME_UNDEFINED);}}

/* k4138 in k4119 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4140,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[30],"setup-api#*remove-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t4);}

/* k4029 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-api.scm: 522  copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[186]))(4,*((C_word*)lf[186]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4032 in k4029 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_4037(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4118,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 524  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[3]);}}

/* k4116 in k4032 in k4029 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4118,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[177],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k4035 in k4032 in k4029 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4037,2,t0,t1);}
t2=(C_word)C_i_assq(lf[198],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4095,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 526  software-version");
((C_proc2)C_retrieve_symbol_proc(lf[216]))(2,*((C_word*)lf[216]+1),t5);}
else{
C_trace("setup-api.scm: 530  make-dest-pathname");
f_3619(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k4093 in k4035 in k4032 in k4029 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[214]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_equalp(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4087,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 528  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[91]))(3,*((C_word*)lf[91]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
f_4052(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_4052(t3,C_SCHEME_FALSE);}}

/* k4085 in k4093 in k4035 in k4032 in k4029 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4052(t2,(C_word)C_i_equalp(t1,lf[215]));}

/* k4050 in k4035 in k4032 in k4029 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_4052(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4052,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 529  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[5]);}
else{
C_trace("setup-api.scm: 530  make-dest-pathname");
f_3619(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4069 in k4050 in k4035 in k4032 in k4029 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4071,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*ranlib-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t4);}

/* k4041 in k4035 in k4032 in k4029 in k4026 in g1049 in loop1033 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 530  make-dest-pathname");
f_3619(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3987 in k3984 in k3981 in k3978 in k3975 in k3969 in setup-api#install-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 532  write-info");
f_3287(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_3781r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3781r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3781r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3785,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3964,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[71]))(5,*((C_word*)lf[71]+1),t5,lf[213],t4,t6);}

/* a3963 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3964,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3788,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3961,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[71]))(5,*((C_word*)lf[71]+1),t2,lf[212],((C_word*)t0)[2],t3);}

/* a3960 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3791,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 492  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),t2,((C_word*)t0)[3]);}

/* k3789 in k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3794,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-api.scm: 493  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),t2,C_SCHEME_FALSE,t1,lf[211]);}

/* k3792 in k3789 in k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 494  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),t2,C_SCHEME_FALSE,((C_word*)t0)[2],lf[210]);}

/* k3795 in k3792 in k3789 in k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3800,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[207],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[208],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[203],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[204],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[205],t8);
t10=(C_word)C_a_i_list(&a,1,t9);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t2,t10);}

/* k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[40],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[206],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[207],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[208],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[203],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[209],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[205],t10);
t12=(C_word)C_a_i_list(&a,1,t11);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t2,t12);}
else{
t3=t2;
f_3803(2,t3,C_SCHEME_UNDEFINED);}}

/* k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[202],t3);
t5=(C_word)C_a_i_cons(&a,2,lf[203],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[204],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[205],t6);
t8=(C_word)C_a_i_list(&a,1,t7);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),t2,t8);}

/* k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 502  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),t2,((C_word*)t0)[2],lf[201]);}

/* k3854 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 503  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),t2,C_SCHEME_FALSE,((C_word*)t0)[2],lf[200]);}

/* k3858 in k3854 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3860,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[8],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[196],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3825,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3829,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3848,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 506  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),t7,C_SCHEME_FALSE,((C_word*)t0)[8],lf[199]);}
else{
C_trace("##sys#append");
t7=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k3846 in k3858 in k3854 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3848,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[198],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t5=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t4,C_SCHEME_END_OF_LIST);}

/* k3827 in k3858 in k3854 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3823 in k3858 in k3854 in k3804 in k3801 in k3798 in k3795 in k3792 in k3789 in k3786 in k3783 in setup-api#standard-extension in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3825,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
C_trace("setup-api.scm: 499  install-extension");
((C_proc5)C_retrieve_symbol_proc(lf[197]))(5,*((C_word*)lf[197]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* setup-api#check-filelist in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3644(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3644,NULL,2,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3650,a[2]=t4,a[3]=t8,a[4]=t6,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3650(t10,t1,t2);}

/* loop897 in setup-api#check-filelist in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3650(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3650,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3660,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3722,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_stringp(t5))){
t6=t3;
f_3660(t6,(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST));}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3690,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t5))){
C_trace("setup-api.scm: 475  every");
((C_proc4)C_retrieve_symbol_proc(lf[157]))(4,*((C_word*)lf[157]+1),t6,*((C_word*)lf[158]+1),t5);}
else{
t7=t6;
f_3690(2,t7,C_SCHEME_FALSE);}}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3688 in loop897 in setup-api#check-filelist in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3690,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3660(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
t5=t2;
f_3693(t5,(C_word)C_a_i_list(&a,2,t3,t4));}
else{
t3=t2;
f_3693(t3,C_SCHEME_FALSE);}}}

/* k3691 in k3688 in loop897 in setup-api#check-filelist in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3693,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
f_3660(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
C_trace("setup-api.scm: 477  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[194],((C_word*)t0)[2]);}}

/* k3720 in loop897 in setup-api#check-filelist in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3722,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3660(t2,(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k3658 in loop897 in setup-api#check-filelist in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3660(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop897910");
t5=((C_word*)((C_word*)t0)[4])[1];
f_3650(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop897910");
t5=((C_word*)((C_word*)t0)[4])[1];
f_3650(t5,((C_word*)t0)[3],t4);}}

/* setup-api#make-dest-pathname in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3619(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3619,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cadr(t3);
C_trace("setup-api.scm: 467  make-dest-pathname");
t7=t1;
t8=t2;
t9=t4;
t1=t7;
t2=t8;
t3=t9;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3639,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 468  absolute-pathname?");
((C_proc3)C_retrieve_symbol_proc(lf[192]))(3,*((C_word*)lf[192]+1),t4,t3);}}

/* k3637 in setup-api#make-dest-pathname in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
C_trace("setup-api.scm: 470  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* setup-api#remove-file* in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3597,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3617,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 463  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,t2);}

/* k3615 in setup-api#remove-file* in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3617,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[30],"setup-api#*remove-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t4);}

/* setup-api#move-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3542,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_car(t2):t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3549,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_cadr(t2);
C_trace("setup-api.scm: 458  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t6,t3,t7);}
else{
t7=t6;
f_3549(2,t7,t3);}}

/* k3547 in setup-api#move-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3552,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 459  ensure-directory");
f_4644(t2,t1);}

/* k3550 in k3547 in setup-api#move-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 460  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k3569 in k3550 in k3547 in setup-api#move-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3579,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 460  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k3577 in k3569 in k3550 in k3547 in setup-api#move-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3579,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[31],"setup-api#*move-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3416r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3416r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3416r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3418,a[2]=t3,a[3]=t2,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3485,a[2]=t5,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3494,a[2]=t6,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-err843865");
t8=t7;
f_3494(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
C_trace("def-prefix844863");
t10=t6;
f_3485(t10,t1);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
C_trace("body841849");
t12=t5;
f_3418(t12,t1,t10);}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-err843 in setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3494(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3494,NULL,2,t0,t1);}
C_trace("def-prefix844863");
t2=((C_word*)t0)[2];
f_3485(t2,t1);}

/* def-prefix844 in setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3485(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3485,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3493,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 445  installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[170]))(2,*((C_word*)lf[170]+1),t2);}

/* k3491 in def-prefix844 in setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("body841849");
t2=((C_word*)t0)[3];
f_3418(t2,((C_word*)t0)[2],t1);}

/* body841 in setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3418(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3418,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_i_car(((C_word*)t0)[3]):((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3425,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 448  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t5,((C_word*)t0)[2],t6);}
else{
t6=t5;
f_3425(2,t6,((C_word*)t0)[2]);}}

/* k3423 in body841 in setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3468,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 449  string-prefix?");
((C_proc4)C_retrieve_symbol_proc(lf[188]))(4,*((C_word*)lf[188]+1),t3,((C_word*)t0)[2],t1);}

/* k3466 in k3423 in body841 in setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3428(2,t2,((C_word*)t0)[3]);}
else{
C_trace("setup-api.scm: 450  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k3426 in k3423 in body841 in setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 452  ensure-directory");
f_4644(t2,t1);}

/* k3429 in k3426 in k3423 in body841 in setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3434,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 453  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}

/* k3448 in k3429 in k3426 in k3423 in body841 in setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3458,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 453  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k3456 in k3448 in k3429 in k3426 in k3423 in body841 in setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3458,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[29],"setup-api#*copy-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k3432 in k3429 in k3426 in k3423 in body841 in setup-api#copy-file in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3287(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3287,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3414,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t6=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_END_OF_LIST);}

/* k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3414,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[176],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[185]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3410,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3294,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 435  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t4);}

/* k3382 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[58]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t3,lf[184],t2);}
else{
t2=((C_word*)t0)[4];
f_3294(2,t2,C_SCHEME_UNDEFINED);}}

/* k3385 in k3382 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3388 in k3385 in k3382 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[183],((C_word*)t0)[3]);}

/* k3391 in k3388 in k3385 in k3382 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3396,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3394 in k3391 in k3388 in k3385 in k3382 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[182],((C_word*)t0)[2]);}

/* k3397 in k3394 in k3391 in k3388 in k3385 in k3382 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 436  ->string");
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2]);}

/* k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3381,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 437  repo-path");
f_4577(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k3379 in k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3231,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
C_trace("setup-api.scm: 411  repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[180]))(2,*((C_word*)lf[180]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(C_word)C_i_car(t3);
C_trace("setup-api.scm: 412  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),((C_word*)t0)[2],t6,t2,lf[179]);}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3229 in k3379 in k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 412  make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[179]);}

/* k3298 in k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3303,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[12],"setup-api#*sudo*"))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 439  create-temporary-file");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[2],a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 442  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t2,t1,t3);}}

/* a3372 in k3298 in k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3373,2,t0,t1);}
t2=C_retrieve(lf[178]);
C_trace("g814815");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k3330 in k3298 in k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3335,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3364,a[2]=((C_word*)t0)[2],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 440  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t2,t1,t3);}

/* a3363 in k3330 in k3298 in k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3364,2,t0,t1);}
t2=C_retrieve(lf[178]);
C_trace("g801802");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k3333 in k3330 in k3298 in k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3354,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 441  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k3352 in k3333 in k3330 in k3298 in k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 441  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k3360 in k3352 in k3333 in k3330 in k3298 in k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[31],"setup-api#*move-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* k3301 in k3298 in k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3303,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3329,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 443  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}}

/* k3327 in k3301 in k3298 in k3295 in k3292 in k3408 in k3412 in setup-api#write-info in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[177],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* f_5746 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5746,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5750,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 429  verb");
f_3263(t3,t2);}

/* k5748 */
static void C_ccall f_5750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5773,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 430  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k5771 in k5748 */
static void C_ccall f_5773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5773,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[173],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*mkdir-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[92]))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t5);}

/* f_5738 in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_5738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5738,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5742,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 426  verb");
f_3263(t3,t2);}

/* k5740 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 427  create-directory");
((C_proc4)C_retrieve_symbol_proc(lf[172]))(4,*((C_word*)lf[172]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* verb in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3263(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3263,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3270,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 422  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t3);}

/* k3268 in verb in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3270,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[58]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3273,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t3,lf[171],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3271 in k3268 in verb in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3274 in k3271 in k3268 in verb in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k3277 in k3274 in k3271 in k3268 in verb in k3258 in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#flush-output");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#make/proc in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3184r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3184r(t0,t1,t2,t3);}}

static void C_ccall f_3184r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=(C_word)C_i_length(t3);
switch(t4){
case C_fix(0):
t5=t2;
C_trace("setup-api.scm: 370  make:make/proc/helper");
f_2763(t1,t5,C_SCHEME_END_OF_LIST);
case C_fix(1):
t5=t2;
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3216,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t6))){
C_trace("setup-api.scm: 375  vector->list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t8,t6);}
else{
C_trace("setup-api.scm: 372  make:make/proc/helper");
f_2763(t1,t5,t6);}
default:
C_trace("##sys#error");
t5=*((C_word*)lf[168]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[169]);}}

/* k3214 in setup-api#make/proc in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 372  make:make/proc/helper");
f_2763(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2763(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2763,NULL,3,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2767,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3182,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 304  vector->list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[166]+1)))(3,*((C_word*)lf[166]+1),t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_2767(t6,C_SCHEME_UNDEFINED);}}

/* k3180 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2767(t3,t2);}

/* k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2767,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2595,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2595(2,t6,t4);}
else{
C_trace("setup-api.scm: 276  make:form-error");
f_2535(t5,lf[165],t3);}}

/* k2593 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2595,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_pairp(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2604(2,t4,t2);}
else{
C_trace("setup-api.scm: 277  make:form-error");
f_2535(t3,lf[164],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
f_2770(2,t2,C_SCHEME_FALSE);}}

/* k2602 in k2593 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2604,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2609,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 278  every");
((C_proc4)C_retrieve_symbol_proc(lf[157]))(4,*((C_word*)lf[157]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2770(2,t2,C_SCHEME_FALSE);}}

/* a2608 in k2602 in k2593 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2609,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2616,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
C_trace("setup-api.scm: 280  <=");
C_less_or_equal_p(5,0,t3,C_fix(2),t4,C_fix(3));}
else{
t4=t3;
f_2616(2,t4,C_SCHEME_FALSE);}}

/* k2614 in a2608 in k2602 in k2593 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2619(2,t3,t1);}
else{
C_trace("setup-api.scm: 281  make:form-error");
f_2535(t2,lf[163],((C_word*)t0)[3]);}}

/* k2617 in k2614 in a2608 in k2602 in k2593 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2619,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_stringp(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2628(2,t5,t3);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_listp(t5))){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("setup-api.scm: 284  every");
((C_proc4)C_retrieve_symbol_proc(lf[157]))(4,*((C_word*)lf[157]+1),t4,*((C_word*)lf[158]+1),t6);}
else{
t6=t4;
f_2628(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2626 in k2617 in k2614 in a2608 in k2602 in k2593 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2631(2,t3,t1);}
else{
C_trace("setup-api.scm: 285  make:form-error");
f_2535(t2,lf[162],((C_word*)t0)[3]);}}

/* k2629 in k2626 in k2617 in k2614 in a2608 in k2602 in k2593 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2631,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2640,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2640(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 288  make:line-error");
f_2557(t6,lf[161],t7,t2);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2668 in k2629 in k2626 in k2617 in k2614 in a2608 in k2602 in k2593 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_2640(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2678,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
C_trace("setup-api.scm: 289  every");
((C_proc4)C_retrieve_symbol_proc(lf[157]))(4,*((C_word*)lf[157]+1),((C_word*)t0)[3],t2,t3);}}

/* a2677 in k2668 in k2629 in k2626 in k2617 in k2614 in a2608 in k2602 in k2593 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2678,3,t0,t1,t2);}
t3=(C_word)C_i_stringp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
C_trace("setup-api.scm: 291  make:form-error");
f_2535(t1,lf[160],t2);}}

/* k2638 in k2629 in k2626 in k2617 in k2614 in a2608 in k2602 in k2593 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_closurep(t4);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_caddr(((C_word*)t0)[4]);
C_trace("setup-api.scm: 295  make:line-error");
f_2557(((C_word*)t0)[3],lf[159],t6,((C_word*)t0)[2]);}}}

/* k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_stringp(t3);
if(C_truep(t4)){
t5=t2;
f_2773(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2755,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 300  every");
((C_proc4)C_retrieve_symbol_proc(lf[157]))(4,*((C_word*)lf[157]+1),t5,*((C_word*)lf[158]+1),t3);}}

/* k2753 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2773(2,t2,t1);}
else{
C_trace("setup-api.scm: 301  error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[115]+1)))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],lf[156],((C_word*)t0)[2]);}}

/* k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2773,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t9,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 308  condition-predicate");
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),t11,lf[153]);}

/* k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2778,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-api.scm: 309  condition-property-accessor");
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t3,lf[153],lf[154]);}

/* k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word)li29),tmp=(C_word)a,a+=8,tmp));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3078,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[2])[1]))){
C_trace("setup-api.scm: 360  make-file");
t5=((C_word*)((C_word*)t0)[7])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[2])[1],lf[148]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3144,a[2]=t4,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 361  caar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[150]+1)))(3,*((C_word*)lf[150]+1),t5,((C_word*)t0)[4]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3149,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3149(t8,t4,((C_word*)((C_word*)t0)[2])[1]);}}}

/* loop616 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3149(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3149,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3157,a[2]=((C_word*)t0)[3],a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3164,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
C_trace("g623624");
t6=t3;
f_3157(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3162 in loop616 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3149(t3,((C_word*)t0)[2],t2);}

/* g623 in loop616 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3157(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3157,NULL,3,t0,t1,t2);}
C_trace("setup-api.scm: 362  make-file");
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[151]);}

/* k3142 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 361  make-file");
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[149]);}

/* k3076 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 363  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t2);}

/* k3082 in k3076 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3084,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 366  reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[147]+1)))(3,*((C_word*)lf[147]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3089 in k3082 in k3076 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3091,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3093,a[2]=t3,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3093(t5,((C_word*)t0)[2],t1);}

/* loop632 in k3089 in k3082 in k3076 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_3093(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3093,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3114,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=*((C_word*)lf[58]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3105,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t6,lf[146],t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3103 in loop632 in k3089 in k3082 in k3076 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3108,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3106 in k3103 in loop632 in k3089 in k3082 in k3076 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k3112 in loop632 in k3089 in k3082 in k3076 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_3114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3093(t3,((C_word*)t0)[2],t2);}

/* f_2784 in k2780 in k2776 in k2771 in k2768 in k2765 in setup-api#make:make/proc/helper in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2784,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=t2;
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2481,a[2]=t5,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2490,a[2]=t7,a[3]=t9,a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2490(t11,t4,t6);}

/* loop */
static void C_fcall f_2490(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2490,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_stringp(t5))){
t6=(C_word)C_i_car(t3);
t7=t4;
f_2503(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t4;
f_2503(t6,(C_word)C_i_car(t3));}}}

/* k2501 in loop */
static void C_fcall f_2503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2503,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 268  any");
((C_proc4)C_retrieve_symbol_proc(lf[140]))(4,*((C_word*)lf[140]+1),t2,((C_word*)t0)[2],t1);}

/* k2507 in k2501 in loop */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("setup-api.scm: 270  loop");
t3=((C_word*)((C_word*)t0)[2])[1];
f_2490(t3,((C_word*)t0)[5],t2);}}

/* match? */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2481,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,((C_word*)t0)[2]));}

/* k2786 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api.scm: 313  fixmaketarget");
f_2302(t2,((C_word*)t0)[7]);}

/* k2789 in k2786 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3072,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 314  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t3,t1);}

/* k3070 in k2789 in k2786 */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 315  file-modification-time");
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2794(2,t2,C_SCHEME_FALSE);}}

/* k2792 in k2789 in k2786 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3054,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 316  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t3);}

/* k3052 in k2792 in k2789 in k2786 */
static void C_ccall f_3054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3054,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[58]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t3,lf[145],t2);}
else{
t2=((C_word*)t0)[4];
f_2797(2,t2,C_SCHEME_UNDEFINED);}}

/* k3055 in k3052 in k2792 in k2789 in k2786 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3058 in k3055 in k3052 in k2792 in k2789 in k2786 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[144],((C_word*)t0)[3]);}

/* k3061 in k3058 in k3055 in k3052 in k2792 in k2789 in k2786 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3064 in k3061 in k3058 in k3055 in k3052 in k2792 in k2789 in k2786 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2797,2,t0,t1);}
if(C_truep(((C_word*)t0)[11])){
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2806,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3027,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 320  string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[127]+1)))(4,*((C_word*)lf[127]+1),t4,lf[142],((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[10])){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3042,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t2);}}}

/* k3040 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3045,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[143],t1);}

/* k3043 in k3040 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3048,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3046 in k3043 in k3040 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3051,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k3049 in k3046 in k3043 in k3040 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 358  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* k3025 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3028,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li26),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t3=*((C_word*)lf[141]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3024 in k3025 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3028,3,t0,t1,t2);}
C_trace("setup-api.scm: 321  make-file");
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2806,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_2812(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[11],a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 325  any");
((C_proc4)C_retrieve_symbol_proc(lf[140]))(4,*((C_word*)lf[140]+1),t3,t4,((C_word*)t0)[2]);}}

/* a2980 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2981,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2985,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 326  fixmaketarget");
f_2302(t3,t2);}

/* k2983 in a2980 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3001,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 327  file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[139]))(3,*((C_word*)lf[139]+1),t3,t1);}

/* k2999 in k2983 in a2980 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3001,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2988(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t2);}}

/* k3006 in k2999 in k2983 in a2980 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3011,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[138],t1);}

/* k3009 in k3006 in k2999 in k2983 in a2980 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3012 in k3009 in k3006 in k2999 in k2983 in a2980 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[137],((C_word*)t0)[2]);}

/* k3015 in k3012 in k3009 in k3006 in k2999 in k2983 in a2980 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k3018 in k3015 in k3012 in k3009 in k3006 in k2999 in k2983 in a2980 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3023,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k3021 in k3018 in k3015 in k3012 in k3009 in k3006 in k2999 in k2983 in a2980 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 328  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* k2986 in k2983 in a2980 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 329  file-modification-time");
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t2,((C_word*)t0)[3]);}

/* k2996 in k2986 in k2983 in a2980 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_greaterp(t1,((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2831,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 336  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t6);}}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[58]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t3,lf[135],t2);}
else{
t2=((C_word*)t0)[6];
f_2831(2,t2,C_SCHEME_UNDEFINED);}}

/* k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[134],((C_word*)t0)[5]);}

/* k2921 in k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k2924 in k2921 in k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2929,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
if(C_truep(t4)){
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
C_trace("setup-api.scm: 344  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[127]+1)))(5,*((C_word*)lf[127]+1),t3,lf[128],((C_word*)t0)[3],lf[129]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t5);}}
else{
C_trace("setup-api.scm: 342  string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[127]+1)))(5,*((C_word*)lf[127]+1),t3,lf[132],((C_word*)t0)[2],lf[133]);}}

/* k2956 in k2924 in k2921 in k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[131],t1);}

/* k2959 in k2956 in k2924 in k2921 in k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2962 in k2959 in k2956 in k2924 in k2921 in k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[130],((C_word*)t0)[3]);}

/* k2965 in k2962 in k2959 in k2956 in k2924 in k2921 in k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2968 in k2965 in k2962 in k2959 in k2956 in k2924 in k2921 in k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k2971 in k2968 in k2965 in k2962 in k2959 in k2956 in k2924 in k2921 in k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in k2956 in k2924 in k2921 in k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 346  string-append");
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),((C_word*)t0)[2],t1);}

/* k2934 in k2924 in k2921 in k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2927 in k2924 in k2921 in k2918 in k2915 in k2912 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2834,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li24),tmp=(C_word)a,a+=7,tmp);
C_trace("call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,t3);}

/* a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2839,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2845,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li19),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2886,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
((C_proc4)C_retrieve_symbol_proc(lf[125]))(4,*((C_word*)lf[125]+1),t1,t3,t4);}

/* a2885 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2892,a[2]=((C_word*)t0)[3],a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2901,a[2]=((C_word*)t0)[2],a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a2900 in a2885 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2901r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2901r(t0,t1,t2);}}

static void C_ccall f_2901r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2907,a[2]=t2,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
C_trace("k577582");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2906 in a2900 in a2885 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2907,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2891 in a2885 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("g592593");
t3=t2;
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* a2844 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2845(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2845,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li18),tmp=(C_word)a,a+=7,tmp);
C_trace("k577582");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2850 in a2844 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
t2=*((C_word*)lf[58]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t3,lf[124],t2);}

/* k2853 in a2850 in a2844 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[5]);}

/* k2856 in k2853 in a2850 in a2844 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[123],((C_word*)t0)[4]);}

/* k2859 in k2856 in k2853 in a2850 in a2844 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2874,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 352  exn?");
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}

/* k2875 in k2859 in k2856 in k2853 in a2850 in a2844 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 353  exn-message");
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[4];
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* k2872 in k2859 in k2856 in k2853 in a2850 in a2844 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2862 in k2859 in k2856 in k2853 in a2850 in a2844 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2865 in k2862 in k2859 in k2856 in k2853 in a2850 in a2844 in a2838 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 355  signal");
((C_proc3)C_retrieve_symbol_proc(lf[122]))(3,*((C_word*)lf[122]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2832 in k2829 in k2810 in k2804 in k2795 in k2792 in k2789 in k2786 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("g580581");
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* setup-api#make:line-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2557(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2557,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2565,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t5);}

/* k2563 in setup-api#make:line-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],t1);}

/* k2566 in k2563 in setup-api#make:line-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[120],((C_word*)t0)[4]);}

/* k2569 in k2566 in k2563 in setup-api#make:line-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2572 in k2569 in k2566 in k2563 in setup-api#make:line-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[119],((C_word*)t0)[3]);}

/* k2575 in k2572 in k2569 in k2566 in k2563 in setup-api#make:line-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2580,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2578 in k2575 in k2572 in k2569 in k2566 in k2563 in setup-api#make:line-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k2581 in k2578 in k2575 in k2572 in k2569 in k2566 in k2563 in setup-api#make:line-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 273  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* setup-api#make:form-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2535(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2535,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2543,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t4);}

/* k2541 in setup-api#make:form-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],t1);}

/* k2544 in k2541 in setup-api#make:form-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[117],((C_word*)t0)[3]);}

/* k2547 in k2544 in k2541 in setup-api#make:form-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[116]+1)))(4,*((C_word*)lf[116]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2550 in k2547 in k2544 in k2541 in setup-api#make:form-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2555,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k2553 in k2550 in k2547 in k2544 in k2541 in setup-api#make:form-error in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 272  error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),((C_word*)t0)[2],t1);}

/* setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2328,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2444,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2444(t11,t7,t2);}

/* loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2444(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2444,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2473,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2335,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2356,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word)li13),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_2356(t13,t9,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop239 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2356(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2356,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[113]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2385,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
C_trace("g255256");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2383 in loop239 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2385,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop239252");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2356(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop239252");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2356(t6,((C_word*)t0)[3],t5);}}

/* k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_string_equal_p(t3,lf[97]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2224,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_assoc(t3,lf[6]);
t8=(C_word)C_i_cdr(t7);
C_trace("setup-api.scm: 214  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t6,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"),t8);}
else{
t4=(C_word)C_i_assoc(t3,lf[6]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2293,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t4);
C_trace("setup-api.scm: 227  make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t5,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"),t6);}
else{
t5=(C_word)C_i_cdr(t1);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
C_trace("setup-api.scm: 239  string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],t6,lf[96]);}}}

/* k2291 in k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 227  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),((C_word*)t0)[2],t1);}

/* k2268 in k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 213  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),((C_word*)t0)[2],t1);}

/* k2226 in k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2232,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2259,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 218  feature?");
((C_proc3)C_retrieve_symbol_proc(lf[110]))(3,*((C_word*)lf[110]+1),t3,lf[111]);}

/* k2257 in k2226 in k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2259,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 219  host-extension");
((C_proc2)C_retrieve_symbol_proc(lf[15]))(2,*((C_word*)lf[15]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_2232(t2,lf[108]);}}

/* k2264 in k2257 in k2226 in k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2232(t2,(C_truep(t1)?lf[108]:lf[109]));}

/* k2230 in k2226 in k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2232(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2232,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2253,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 221  keep-intermediates");
((C_proc2)C_retrieve_symbol_proc(lf[28]))(2,*((C_word*)lf[28]+1),t2);}

/* k2251 in k2230 in k2226 in k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=(C_truep(t1)?lf[99]:lf[100]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2250,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 222  host-extension");
((C_proc2)C_retrieve_symbol_proc(lf[15]))(2,*((C_word*)lf[15]+1),t3);}

/* k2248 in k2251 in k2230 in k2226 in k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2250,2,t0,t1);}
t2=(C_truep(t1)?lf[101]:lf[102]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2247,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api.scm: 223  deployment-mode");
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t3);}

/* k2245 in k2248 in k2251 in k2230 in k2226 in k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 213  cons*");
((C_proc10)C_retrieve_symbol_proc(lf[103]))(10,*((C_word*)lf[103]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[104],lf[105],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[106],C_SCHEME_END_OF_LIST);}
else{
C_trace("setup-api.scm: 213  cons*");
((C_proc10)C_retrieve_symbol_proc(lf[103]))(10,*((C_word*)lf[103]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[104],lf[105],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[107],C_SCHEME_END_OF_LIST);}}

/* k2222 in k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 212  string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],t1,lf[98]);}

/* k2344 in k2333 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2346,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
C_trace("setup-api.scm: 239  string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],t3,lf[96]);}

/* k2471 in loop278 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2473,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop278291");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2444(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop278291");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2444(t6,((C_word*)t0)[3],t5);}}

/* k2394 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2396,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2398,a[2]=t3,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2398(t5,((C_word*)t0)[2],t1);}

/* loop229 in k2394 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2398(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2398,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2431,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2410,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2416,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 242  run-verbose");
((C_proc2)C_retrieve_symbol_proc(lf[85]))(2,*((C_word*)lf[85]+1),t6);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2414 in loop229 in k2394 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[58]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t3,lf[94],t2);}
else{
C_trace("setup-api.scm: 243  $system");
f_5643(((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k2417 in k2414 in loop229 in k2394 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2420 in k2417 in k2414 in loop229 in k2394 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2423 in k2420 in k2417 in k2414 in loop229 in k2394 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#flush-output");
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2408 in loop229 in k2394 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 243  $system");
f_5643(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2429 in loop229 in k2394 in setup-api#execute in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2398(t3,((C_word*)t0)[2],t2);}

/* setup-api#fixmaketarget in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2302(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2302,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2309,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2326,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 231  pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[91]))(3,*((C_word*)lf[91]+1),t4,t2);}

/* k2324 in setup-api#fixmaketarget in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_equalp(lf[89],t1))){
t2=(C_word)C_i_string_equal_p(lf[90],C_retrieve(lf[88]));
t3=((C_word*)t0)[2];
f_2309(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_2309(t2,C_SCHEME_FALSE);}}

/* k2307 in setup-api#fixmaketarget in k2206 in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("setup-api.scm: 233  pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_retrieve(lf[88]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2091,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2095,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2192,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 191  setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t6);}

/* k2190 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[58]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t3,lf[84],t2);}
else{
t2=((C_word*)t0)[3];
f_2095(2,t2,C_SCHEME_UNDEFINED);}}

/* k2193 in k2190 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2196 in k2193 in k2190 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[83],((C_word*)t0)[2]);}

/* k2199 in k2196 in k2193 in k2190 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2095,2,t0,t1);}
if(C_truep((C_word)C_i_listp(((C_word*)t0)[5]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li9),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 193  with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 202  create-temporary-file");
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t2);}}

/* k2147 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2152,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,t1,t1);
C_trace("setup-api.scm: 203  patch");
((C_proc5)C_retrieve_symbol_proc(lf[74]))(5,*((C_word*)lf[74]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2150 in k2147 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),t2);}

/* k2157 in k2150 in k2147 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,C_retrieve2(lf[31],"setup-api#*move-command*"),t1);}

/* k2160 in k2157 in k2150 in k2147 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k2163 in k2160 in k2157 in k2150 in k2147 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 205  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}

/* k2183 in k2163 in k2160 in k2157 in k2150 in k2147 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2166 in k2163 in k2160 in k2157 in k2150 in k2147 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k2169 in k2166 in k2163 in k2160 in k2157 in k2150 in k2147 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api.scm: 206  shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,((C_word*)t0)[2]);}

/* k2179 in k2169 in k2166 in k2163 in k2160 in k2157 in k2150 in k2147 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2150 in k2147 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t2,((C_word*)t0)[2]);}

/* k2175 in k2172 in k2169 in k2166 in k2163 in k2160 in k2157 in k2150 in k2147 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 204  $system");
f_5643(((C_word*)t0)[2],t1);}

/* a2109 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2110,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api.scm: 195  with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t1,t2,t3);}

/* a2119 in a2109 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2120,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li7),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2126(t5,t1);}

/* loop in a2119 in a2109 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2126(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2126,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 198  read-line");
((C_proc2)C_retrieve_symbol_proc(lf[67]))(2,*((C_word*)lf[67]+1),t2);}

/* k2128 in loop in a2119 in a2109 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2130,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2146,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 200  string-substitute");
((C_proc6)C_retrieve_symbol_proc(lf[76]))(6,*((C_word*)lf[76]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}}

/* k2144 in k2128 in loop in a2119 in a2109 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 200  write-line");
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),((C_word*)t0)[2],t1);}

/* k2137 in k2128 in loop in a2119 in a2109 in k2093 in setup-api#patch in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 201  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2126(t2,((C_word*)t0)[2]);}

/* setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1993r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1993r(t0,t1,t2,t3);}}

static void C_ccall f_1993r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1997,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#get-keyword");
((C_proc4)C_retrieve_symbol_proc(lf[71]))(4,*((C_word*)lf[71]+1),t4,lf[73],t3);}

/* k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2085,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_symbol_proc(lf[71]))(5,*((C_word*)lf[71]+1),t2,lf[72],((C_word*)t0)[2],t3);}

/* a2084 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
C_trace("setup-api.scm: 175  abort-setup");
((C_proc2)C_retrieve_symbol_proc(lf[56]))(2,*((C_word*)lf[56]+1),t1);}

/* k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li4),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2005(t5,((C_word*)t0)[2]);}

/* loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2005,NULL,2,t0,t1);}
t2=*((C_word*)lf[58]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2009,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("write-char/port");
t4=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(10),t2);}

/* k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2010 in k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[70],((C_word*)t0)[2]);}

/* k2013 in k2010 in k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[58]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t5=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(91),t3);}
else{
t3=t2;
f_2018(2,t3,C_SCHEME_UNDEFINED);}}

/* k2075 in k2013 in k2010 in k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2078 in k2075 in k2013 in k2010 in k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],lf[69],((C_word*)t0)[2]);}

/* k2016 in k2013 in k2010 in k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 179  flush-output");
((C_proc2)C_retrieve_proc(*((C_word*)lf[68]+1)))(2,*((C_word*)lf[68]+1),t2);}

/* k2019 in k2016 in k2013 in k2010 in k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api.scm: 180  read-line");
((C_proc2)C_retrieve_symbol_proc(lf[67]))(2,*((C_word*)lf[67]+1),t2);}

/* k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_eofp(((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,lf[65]);
t6=t4;
f_2027(t6,t5);}
else{
if(C_truep(((C_word*)t0)[2])){
if(C_truep((C_word)C_i_string_equal_p(lf[66],((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,((C_word*)t0)[2]);
t6=t4;
f_2027(t6,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t4;
f_2027(t6,t5);}}
else{
t5=C_SCHEME_UNDEFINED;
t6=t4;
f_2027(t6,t5);}}}

/* k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_2027(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2027,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_string_ci_equal_p(lf[59],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_string_ci_equal_p(lf[60],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_string_ci_equal_p(lf[61],((C_word*)((C_word*)t0)[5])[1]))){
C_trace("setup-api.scm: 185  abort");
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}
else{
t2=*((C_word*)lf[58]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2051,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t4=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(10),t2);}}}}

/* k2049 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t2,lf[64],((C_word*)t0)[2]);}

/* k2052 in k2049 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[62]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2055 in k2052 in k2049 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in loop in k1998 in k1995 in setup-api#yes-or-no? in k1989 in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 188  loop");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2005(t2,((C_word*)t0)[2]);}

/* setup-api#sudo-install in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1968r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1968r(t0,t1,t2);}}

static void C_ccall f_1968r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
if(C_truep((C_word)C_vemptyp(t2))){
t3=C_retrieve2(lf[12],"setup-api#*sudo*");
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_vector_ref(t2,C_fix(0)))){
t3=t1;
t4=lf[12] /* setup-api#*sudo* */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t5=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
C_trace("setup-api.scm: 146  print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t3,lf[49]);}
else{
t5=C_mutate(&lf[29] /* (set! setup-api#*copy-command* ...) */,lf[50]);
t6=C_mutate(&lf[30] /* (set! setup-api#*remove-command* ...) */,lf[51]);
t7=C_mutate(&lf[31] /* (set! setup-api#*move-command* ...) */,lf[52]);
t8=C_mutate(&lf[32] /* (set! setup-api#*chmod-command* ...) */,lf[53]);
t9=C_mutate(&lf[33] /* (set! setup-api#*ranlib-command* ...) */,lf[54]);
t10=C_mutate(&lf[34] /* (set! setup-api#*mkdir-command* ...) */,lf[55]);
t11=t3;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}}
else{
C_trace("setup-api.scm: 171  user-install-setup");
f_1942(t1);}}}

/* setup-api#user-install-setup in k1899 in k1895 in k1891 in k1887 in k1883 in k1879 in k1875 in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_fcall f_1942(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1942,NULL,1,t1);}
t2=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t1;
t4=C_mutate(&lf[29] /* (set! setup-api#*copy-command* ...) */,lf[36]);
t5=C_mutate(&lf[30] /* (set! setup-api#*remove-command* ...) */,lf[37]);
t6=C_mutate(&lf[31] /* (set! setup-api#*move-command* ...) */,lf[38]);
t7=C_mutate(&lf[32] /* (set! setup-api#*chmod-command* ...) */,lf[39]);
t8=C_mutate(&lf[33] /* (set! setup-api#*ranlib-command* ...) */,lf[40]);
t9=t3;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t3=t1;
t4=C_mutate(&lf[29] /* (set! setup-api#*copy-command* ...) */,lf[41]);
t5=C_mutate(&lf[30] /* (set! setup-api#*remove-command* ...) */,lf[42]);
t6=C_mutate(&lf[31] /* (set! setup-api#*move-command* ...) */,lf[43]);
t7=C_mutate(&lf[32] /* (set! setup-api#*chmod-command* ...) */,lf[44]);
t8=C_mutate(&lf[33] /* (set! setup-api#*ranlib-command* ...) */,lf[45]);
t9=C_mutate(&lf[34] /* (set! setup-api#*mkdir-command* ...) */,lf[46]);
t10=t3;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* setup-api#cross-chicken in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1868,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fudge(C_fix(39)));}

/* setup-api#shellpath in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api.scm: 106  normalize-pathname");
((C_proc3)C_retrieve_symbol_proc(lf[20]))(3,*((C_word*)lf[20]+1),t3,t2);}

/* k1864 in setup-api#shellpath in k1854 in k1851 in k1847 in k1844 in k1841 in k1837 in k1833 in k1830 in k1824 in k1820 in k1816 in k1812 in k1808 in k5835 in k5839 in k5843 in k5847 in k1799 in k1796 in k1793 in k1790 in k1787 in k1784 in k1781 in k1778 in k1775 in k1772 in k1769 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api.scm: 106  qs");
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[538] = {
{"toplevel:setup_api_scm",(void*)C_toplevel},
{"f_1771:setup_api_scm",(void*)f_1771},
{"f_1774:setup_api_scm",(void*)f_1774},
{"f_1777:setup_api_scm",(void*)f_1777},
{"f_1780:setup_api_scm",(void*)f_1780},
{"f_1783:setup_api_scm",(void*)f_1783},
{"f_1786:setup_api_scm",(void*)f_1786},
{"f_1789:setup_api_scm",(void*)f_1789},
{"f_1792:setup_api_scm",(void*)f_1792},
{"f_1795:setup_api_scm",(void*)f_1795},
{"f_1798:setup_api_scm",(void*)f_1798},
{"f_1801:setup_api_scm",(void*)f_1801},
{"f_5849:setup_api_scm",(void*)f_5849},
{"f_5845:setup_api_scm",(void*)f_5845},
{"f_5841:setup_api_scm",(void*)f_5841},
{"f_5837:setup_api_scm",(void*)f_5837},
{"f_1810:setup_api_scm",(void*)f_1810},
{"f_1814:setup_api_scm",(void*)f_1814},
{"f_1818:setup_api_scm",(void*)f_1818},
{"f_1822:setup_api_scm",(void*)f_1822},
{"f_1826:setup_api_scm",(void*)f_1826},
{"f_5805:setup_api_scm",(void*)f_5805},
{"f_1832:setup_api_scm",(void*)f_1832},
{"f_1835:setup_api_scm",(void*)f_1835},
{"f_1839:setup_api_scm",(void*)f_1839},
{"f_1843:setup_api_scm",(void*)f_1843},
{"f_1846:setup_api_scm",(void*)f_1846},
{"f_1849:setup_api_scm",(void*)f_1849},
{"f_1853:setup_api_scm",(void*)f_1853},
{"f_1856:setup_api_scm",(void*)f_1856},
{"f_1877:setup_api_scm",(void*)f_1877},
{"f_1881:setup_api_scm",(void*)f_1881},
{"f_1885:setup_api_scm",(void*)f_1885},
{"f_1889:setup_api_scm",(void*)f_1889},
{"f_1893:setup_api_scm",(void*)f_1893},
{"f_1897:setup_api_scm",(void*)f_1897},
{"f_1901:setup_api_scm",(void*)f_1901},
{"f_5782:setup_api_scm",(void*)f_5782},
{"f_1991:setup_api_scm",(void*)f_1991},
{"f_2208:setup_api_scm",(void*)f_2208},
{"f_5777:setup_api_scm",(void*)f_5777},
{"f_3260:setup_api_scm",(void*)f_3260},
{"f_5668:setup_api_scm",(void*)f_5668},
{"f_5684:setup_api_scm",(void*)f_5684},
{"f_5721:setup_api_scm",(void*)f_5721},
{"f_5714:setup_api_scm",(void*)f_5714},
{"f_5718:setup_api_scm",(void*)f_5718},
{"f_5691:setup_api_scm",(void*)f_5691},
{"f_5335:setup_api_scm",(void*)f_5335},
{"f_5666:setup_api_scm",(void*)f_5666},
{"f_5643:setup_api_scm",(void*)f_5643},
{"f_5660:setup_api_scm",(void*)f_5660},
{"f_5647:setup_api_scm",(void*)f_5647},
{"f_5589:setup_api_scm",(void*)f_5589},
{"f_5641:setup_api_scm",(void*)f_5641},
{"f_5616:setup_api_scm",(void*)f_5616},
{"f_5626:setup_api_scm",(void*)f_5626},
{"f_5596:setup_api_scm",(void*)f_5596},
{"f_5607:setup_api_scm",(void*)f_5607},
{"f_5603:setup_api_scm",(void*)f_5603},
{"f_5458:setup_api_scm",(void*)f_5458},
{"f_5462:setup_api_scm",(void*)f_5462},
{"f_5568:setup_api_scm",(void*)f_5568},
{"f_5502:setup_api_scm",(void*)f_5502},
{"f_5506:setup_api_scm",(void*)f_5506},
{"f_5514:setup_api_scm",(void*)f_5514},
{"f_5553:setup_api_scm",(void*)f_5553},
{"f_5522:setup_api_scm",(void*)f_5522},
{"f_5535:setup_api_scm",(void*)f_5535},
{"f_5541:setup_api_scm",(void*)f_5541},
{"f_5509:setup_api_scm",(void*)f_5509},
{"f_5484:setup_api_scm",(void*)f_5484},
{"f_5487:setup_api_scm",(void*)f_5487},
{"f_5497:setup_api_scm",(void*)f_5497},
{"f_5490:setup_api_scm",(void*)f_5490},
{"f_5493:setup_api_scm",(void*)f_5493},
{"f_5405:setup_api_scm",(void*)f_5405},
{"f_5409:setup_api_scm",(void*)f_5409},
{"f_5447:setup_api_scm",(void*)f_5447},
{"f_5453:setup_api_scm",(void*)f_5453},
{"f_5412:setup_api_scm",(void*)f_5412},
{"f_5417:setup_api_scm",(void*)f_5417},
{"f_5444:setup_api_scm",(void*)f_5444},
{"f_5440:setup_api_scm",(void*)f_5440},
{"f_5424:setup_api_scm",(void*)f_5424},
{"f_5430:setup_api_scm",(void*)f_5430},
{"f_5436:setup_api_scm",(void*)f_5436},
{"f_5391:setup_api_scm",(void*)f_5391},
{"f_5403:setup_api_scm",(void*)f_5403},
{"f_5399:setup_api_scm",(void*)f_5399},
{"f_5347:setup_api_scm",(void*)f_5347},
{"f_5351:setup_api_scm",(void*)f_5351},
{"f_5370:setup_api_scm",(void*)f_5370},
{"f_5360:setup_api_scm",(void*)f_5360},
{"f_5337:setup_api_scm",(void*)f_5337},
{"f_5345:setup_api_scm",(void*)f_5345},
{"f_5136:setup_api_scm",(void*)f_5136},
{"f_5201:setup_api_scm",(void*)f_5201},
{"f_5205:setup_api_scm",(void*)f_5205},
{"f_5207:setup_api_scm",(void*)f_5207},
{"f_5287:setup_api_scm",(void*)f_5287},
{"f_5139:setup_api_scm",(void*)f_5139},
{"f_5194:setup_api_scm",(void*)f_5194},
{"f_5147:setup_api_scm",(void*)f_5147},
{"f_5149:setup_api_scm",(void*)f_5149},
{"f_5180:setup_api_scm",(void*)f_5180},
{"f_5159:setup_api_scm",(void*)f_5159},
{"f_5114:setup_api_scm",(void*)f_5114},
{"f_5122:setup_api_scm",(void*)f_5122},
{"f_5125:setup_api_scm",(void*)f_5125},
{"f_5128:setup_api_scm",(void*)f_5128},
{"f_5131:setup_api_scm",(void*)f_5131},
{"f_5134:setup_api_scm",(void*)f_5134},
{"f_5055:setup_api_scm",(void*)f_5055},
{"f_5063:setup_api_scm",(void*)f_5063},
{"f_5066:setup_api_scm",(void*)f_5066},
{"f_5069:setup_api_scm",(void*)f_5069},
{"f_5072:setup_api_scm",(void*)f_5072},
{"f_5075:setup_api_scm",(void*)f_5075},
{"f_5078:setup_api_scm",(void*)f_5078},
{"f_5081:setup_api_scm",(void*)f_5081},
{"f_5084:setup_api_scm",(void*)f_5084},
{"f_5087:setup_api_scm",(void*)f_5087},
{"f_5090:setup_api_scm",(void*)f_5090},
{"f_5093:setup_api_scm",(void*)f_5093},
{"f_5096:setup_api_scm",(void*)f_5096},
{"f_5099:setup_api_scm",(void*)f_5099},
{"f_5102:setup_api_scm",(void*)f_5102},
{"f_5105:setup_api_scm",(void*)f_5105},
{"f_5108:setup_api_scm",(void*)f_5108},
{"f_5112:setup_api_scm",(void*)f_5112},
{"f_4934:setup_api_scm",(void*)f_4934},
{"f_4940:setup_api_scm",(void*)f_4940},
{"f_4953:setup_api_scm",(void*)f_4953},
{"f_4965:setup_api_scm",(void*)f_4965},
{"f_4971:setup_api_scm",(void*)f_4971},
{"f_5011:setup_api_scm",(void*)f_5011},
{"f_5022:setup_api_scm",(void*)f_5022},
{"f_5026:setup_api_scm",(void*)f_5026},
{"f_4986:setup_api_scm",(void*)f_4986},
{"f_4993:setup_api_scm",(void*)f_4993},
{"f_4996:setup_api_scm",(void*)f_4996},
{"f_4999:setup_api_scm",(void*)f_4999},
{"f_5002:setup_api_scm",(void*)f_5002},
{"f_5005:setup_api_scm",(void*)f_5005},
{"f_4853:setup_api_scm",(void*)f_4853},
{"f_4857:setup_api_scm",(void*)f_4857},
{"f_4864:setup_api_scm",(void*)f_4864},
{"f_4867:setup_api_scm",(void*)f_4867},
{"f_4870:setup_api_scm",(void*)f_4870},
{"f_4873:setup_api_scm",(void*)f_4873},
{"f_4876:setup_api_scm",(void*)f_4876},
{"f_4879:setup_api_scm",(void*)f_4879},
{"f_4882:setup_api_scm",(void*)f_4882},
{"f_4885:setup_api_scm",(void*)f_4885},
{"f_4888:setup_api_scm",(void*)f_4888},
{"f_4891:setup_api_scm",(void*)f_4891},
{"f_4910:setup_api_scm",(void*)f_4910},
{"f_4894:setup_api_scm",(void*)f_4894},
{"f_4897:setup_api_scm",(void*)f_4897},
{"f_4900:setup_api_scm",(void*)f_4900},
{"f_4903:setup_api_scm",(void*)f_4903},
{"f_4906:setup_api_scm",(void*)f_4906},
{"f_4821:setup_api_scm",(void*)f_4821},
{"f_4851:setup_api_scm",(void*)f_4851},
{"f_4828:setup_api_scm",(void*)f_4828},
{"f_4835:setup_api_scm",(void*)f_4835},
{"f_4838:setup_api_scm",(void*)f_4838},
{"f_4841:setup_api_scm",(void*)f_4841},
{"f_4844:setup_api_scm",(void*)f_4844},
{"f_4847:setup_api_scm",(void*)f_4847},
{"f_4697:setup_api_scm",(void*)f_4697},
{"f_4701:setup_api_scm",(void*)f_4701},
{"f_4815:setup_api_scm",(void*)f_4815},
{"f_4704:setup_api_scm",(void*)f_4704},
{"f_4812:setup_api_scm",(void*)f_4812},
{"f_4707:setup_api_scm",(void*)f_4707},
{"f_4809:setup_api_scm",(void*)f_4809},
{"f_4710:setup_api_scm",(void*)f_4710},
{"f_4803:setup_api_scm",(void*)f_4803},
{"f_4713:setup_api_scm",(void*)f_4713},
{"f_4800:setup_api_scm",(void*)f_4800},
{"f_4716:setup_api_scm",(void*)f_4716},
{"f_4719:setup_api_scm",(void*)f_4719},
{"f_4722:setup_api_scm",(void*)f_4722},
{"f_4794:setup_api_scm",(void*)f_4794},
{"f_4725:setup_api_scm",(void*)f_4725},
{"f_4785:setup_api_scm",(void*)f_4785},
{"f_4771:setup_api_scm",(void*)f_4771},
{"f_4774:setup_api_scm",(void*)f_4774},
{"f_4728:setup_api_scm",(void*)f_4728},
{"f_4731:setup_api_scm",(void*)f_4731},
{"f_4741:setup_api_scm",(void*)f_4741},
{"f_4744:setup_api_scm",(void*)f_4744},
{"f_4747:setup_api_scm",(void*)f_4747},
{"f_4757:setup_api_scm",(void*)f_4757},
{"f_4750:setup_api_scm",(void*)f_4750},
{"f_4753:setup_api_scm",(void*)f_4753},
{"f_4734:setup_api_scm",(void*)f_4734},
{"f_4644:setup_api_scm",(void*)f_4644},
{"f_4648:setup_api_scm",(void*)f_4648},
{"f_4657:setup_api_scm",(void*)f_4657},
{"f_4669:setup_api_scm",(void*)f_4669},
{"f_4695:setup_api_scm",(void*)f_4695},
{"f_4663:setup_api_scm",(void*)f_4663},
{"f_4651:setup_api_scm",(void*)f_4651},
{"f_4577:setup_api_scm",(void*)f_4577},
{"f_4581:setup_api_scm",(void*)f_4581},
{"f_4593:setup_api_scm",(void*)f_4593},
{"f_4603:setup_api_scm",(void*)f_4603},
{"f_4607:setup_api_scm",(void*)f_4607},
{"f_4610:setup_api_scm",(void*)f_4610},
{"f_4613:setup_api_scm",(void*)f_4613},
{"f_4616:setup_api_scm",(void*)f_4616},
{"f_4584:setup_api_scm",(void*)f_4584},
{"f_4587:setup_api_scm",(void*)f_4587},
{"f_4413:setup_api_scm",(void*)f_4413},
{"f_4417:setup_api_scm",(void*)f_4417},
{"f_4423:setup_api_scm",(void*)f_4423},
{"f_4426:setup_api_scm",(void*)f_4426},
{"f_4429:setup_api_scm",(void*)f_4429},
{"f_4546:setup_api_scm",(void*)f_4546},
{"f_4432:setup_api_scm",(void*)f_4432},
{"f_4466:setup_api_scm",(void*)f_4466},
{"f_4538:setup_api_scm",(void*)f_4538},
{"f_4493:setup_api_scm",(void*)f_4493},
{"f_4500:setup_api_scm",(void*)f_4500},
{"f_4503:setup_api_scm",(void*)f_4503},
{"f_4529:setup_api_scm",(void*)f_4529},
{"f_4506:setup_api_scm",(void*)f_4506},
{"f_4435:setup_api_scm",(void*)f_4435},
{"f_4464:setup_api_scm",(void*)f_4464},
{"f_4438:setup_api_scm",(void*)f_4438},
{"f_4194:setup_api_scm",(void*)f_4194},
{"f_4198:setup_api_scm",(void*)f_4198},
{"f_4214:setup_api_scm",(void*)f_4214},
{"f_4217:setup_api_scm",(void*)f_4217},
{"f_4220:setup_api_scm",(void*)f_4220},
{"f_4382:setup_api_scm",(void*)f_4382},
{"f_4223:setup_api_scm",(void*)f_4223},
{"f_4315:setup_api_scm",(void*)f_4315},
{"f_4374:setup_api_scm",(void*)f_4374},
{"f_4342:setup_api_scm",(void*)f_4342},
{"f_4356:setup_api_scm",(void*)f_4356},
{"f_4360:setup_api_scm",(void*)f_4360},
{"f_4226:setup_api_scm",(void*)f_4226},
{"f_4234:setup_api_scm",(void*)f_4234},
{"f_4306:setup_api_scm",(void*)f_4306},
{"f_4261:setup_api_scm",(void*)f_4261},
{"f_4268:setup_api_scm",(void*)f_4268},
{"f_4271:setup_api_scm",(void*)f_4271},
{"f_4297:setup_api_scm",(void*)f_4297},
{"f_4274:setup_api_scm",(void*)f_4274},
{"f_4229:setup_api_scm",(void*)f_4229},
{"f_4200:setup_api_scm",(void*)f_4200},
{"f_3732:setup_api_scm",(void*)f_3732},
{"f_3739:setup_api_scm",(void*)f_3739},
{"f_3967:setup_api_scm",(void*)f_3967},
{"f_3971:setup_api_scm",(void*)f_3971},
{"f_3977:setup_api_scm",(void*)f_3977},
{"f_3980:setup_api_scm",(void*)f_3980},
{"f_3983:setup_api_scm",(void*)f_3983},
{"f_3986:setup_api_scm",(void*)f_3986},
{"f_3994:setup_api_scm",(void*)f_3994},
{"f_4159:setup_api_scm",(void*)f_4159},
{"f_4021:setup_api_scm",(void*)f_4021},
{"f_4028:setup_api_scm",(void*)f_4028},
{"f_4150:setup_api_scm",(void*)f_4150},
{"f_4121:setup_api_scm",(void*)f_4121},
{"f_4140:setup_api_scm",(void*)f_4140},
{"f_4031:setup_api_scm",(void*)f_4031},
{"f_4034:setup_api_scm",(void*)f_4034},
{"f_4118:setup_api_scm",(void*)f_4118},
{"f_4037:setup_api_scm",(void*)f_4037},
{"f_4095:setup_api_scm",(void*)f_4095},
{"f_4087:setup_api_scm",(void*)f_4087},
{"f_4052:setup_api_scm",(void*)f_4052},
{"f_4071:setup_api_scm",(void*)f_4071},
{"f_4043:setup_api_scm",(void*)f_4043},
{"f_3989:setup_api_scm",(void*)f_3989},
{"f_3781:setup_api_scm",(void*)f_3781},
{"f_3964:setup_api_scm",(void*)f_3964},
{"f_3785:setup_api_scm",(void*)f_3785},
{"f_3961:setup_api_scm",(void*)f_3961},
{"f_3788:setup_api_scm",(void*)f_3788},
{"f_3791:setup_api_scm",(void*)f_3791},
{"f_3794:setup_api_scm",(void*)f_3794},
{"f_3797:setup_api_scm",(void*)f_3797},
{"f_3800:setup_api_scm",(void*)f_3800},
{"f_3803:setup_api_scm",(void*)f_3803},
{"f_3806:setup_api_scm",(void*)f_3806},
{"f_3856:setup_api_scm",(void*)f_3856},
{"f_3860:setup_api_scm",(void*)f_3860},
{"f_3848:setup_api_scm",(void*)f_3848},
{"f_3829:setup_api_scm",(void*)f_3829},
{"f_3825:setup_api_scm",(void*)f_3825},
{"f_3644:setup_api_scm",(void*)f_3644},
{"f_3650:setup_api_scm",(void*)f_3650},
{"f_3690:setup_api_scm",(void*)f_3690},
{"f_3693:setup_api_scm",(void*)f_3693},
{"f_3722:setup_api_scm",(void*)f_3722},
{"f_3660:setup_api_scm",(void*)f_3660},
{"f_3619:setup_api_scm",(void*)f_3619},
{"f_3639:setup_api_scm",(void*)f_3639},
{"f_3597:setup_api_scm",(void*)f_3597},
{"f_3617:setup_api_scm",(void*)f_3617},
{"f_3542:setup_api_scm",(void*)f_3542},
{"f_3549:setup_api_scm",(void*)f_3549},
{"f_3552:setup_api_scm",(void*)f_3552},
{"f_3571:setup_api_scm",(void*)f_3571},
{"f_3579:setup_api_scm",(void*)f_3579},
{"f_3416:setup_api_scm",(void*)f_3416},
{"f_3494:setup_api_scm",(void*)f_3494},
{"f_3485:setup_api_scm",(void*)f_3485},
{"f_3493:setup_api_scm",(void*)f_3493},
{"f_3418:setup_api_scm",(void*)f_3418},
{"f_3425:setup_api_scm",(void*)f_3425},
{"f_3468:setup_api_scm",(void*)f_3468},
{"f_3428:setup_api_scm",(void*)f_3428},
{"f_3431:setup_api_scm",(void*)f_3431},
{"f_3450:setup_api_scm",(void*)f_3450},
{"f_3458:setup_api_scm",(void*)f_3458},
{"f_3434:setup_api_scm",(void*)f_3434},
{"f_3287:setup_api_scm",(void*)f_3287},
{"f_3414:setup_api_scm",(void*)f_3414},
{"f_3410:setup_api_scm",(void*)f_3410},
{"f_3384:setup_api_scm",(void*)f_3384},
{"f_3387:setup_api_scm",(void*)f_3387},
{"f_3390:setup_api_scm",(void*)f_3390},
{"f_3393:setup_api_scm",(void*)f_3393},
{"f_3396:setup_api_scm",(void*)f_3396},
{"f_3399:setup_api_scm",(void*)f_3399},
{"f_3294:setup_api_scm",(void*)f_3294},
{"f_3297:setup_api_scm",(void*)f_3297},
{"f_3381:setup_api_scm",(void*)f_3381},
{"f_3231:setup_api_scm",(void*)f_3231},
{"f_3300:setup_api_scm",(void*)f_3300},
{"f_3373:setup_api_scm",(void*)f_3373},
{"f_3332:setup_api_scm",(void*)f_3332},
{"f_3364:setup_api_scm",(void*)f_3364},
{"f_3335:setup_api_scm",(void*)f_3335},
{"f_3354:setup_api_scm",(void*)f_3354},
{"f_3362:setup_api_scm",(void*)f_3362},
{"f_3303:setup_api_scm",(void*)f_3303},
{"f_3329:setup_api_scm",(void*)f_3329},
{"f_5746:setup_api_scm",(void*)f_5746},
{"f_5750:setup_api_scm",(void*)f_5750},
{"f_5773:setup_api_scm",(void*)f_5773},
{"f_5738:setup_api_scm",(void*)f_5738},
{"f_5742:setup_api_scm",(void*)f_5742},
{"f_3263:setup_api_scm",(void*)f_3263},
{"f_3270:setup_api_scm",(void*)f_3270},
{"f_3273:setup_api_scm",(void*)f_3273},
{"f_3276:setup_api_scm",(void*)f_3276},
{"f_3279:setup_api_scm",(void*)f_3279},
{"f_3184:setup_api_scm",(void*)f_3184},
{"f_3216:setup_api_scm",(void*)f_3216},
{"f_2763:setup_api_scm",(void*)f_2763},
{"f_3182:setup_api_scm",(void*)f_3182},
{"f_2767:setup_api_scm",(void*)f_2767},
{"f_2595:setup_api_scm",(void*)f_2595},
{"f_2604:setup_api_scm",(void*)f_2604},
{"f_2609:setup_api_scm",(void*)f_2609},
{"f_2616:setup_api_scm",(void*)f_2616},
{"f_2619:setup_api_scm",(void*)f_2619},
{"f_2628:setup_api_scm",(void*)f_2628},
{"f_2631:setup_api_scm",(void*)f_2631},
{"f_2670:setup_api_scm",(void*)f_2670},
{"f_2678:setup_api_scm",(void*)f_2678},
{"f_2640:setup_api_scm",(void*)f_2640},
{"f_2770:setup_api_scm",(void*)f_2770},
{"f_2755:setup_api_scm",(void*)f_2755},
{"f_2773:setup_api_scm",(void*)f_2773},
{"f_2778:setup_api_scm",(void*)f_2778},
{"f_2782:setup_api_scm",(void*)f_2782},
{"f_3149:setup_api_scm",(void*)f_3149},
{"f_3164:setup_api_scm",(void*)f_3164},
{"f_3157:setup_api_scm",(void*)f_3157},
{"f_3144:setup_api_scm",(void*)f_3144},
{"f_3078:setup_api_scm",(void*)f_3078},
{"f_3084:setup_api_scm",(void*)f_3084},
{"f_3091:setup_api_scm",(void*)f_3091},
{"f_3093:setup_api_scm",(void*)f_3093},
{"f_3105:setup_api_scm",(void*)f_3105},
{"f_3108:setup_api_scm",(void*)f_3108},
{"f_3114:setup_api_scm",(void*)f_3114},
{"f_2784:setup_api_scm",(void*)f_2784},
{"f_2490:setup_api_scm",(void*)f_2490},
{"f_2503:setup_api_scm",(void*)f_2503},
{"f_2509:setup_api_scm",(void*)f_2509},
{"f_2481:setup_api_scm",(void*)f_2481},
{"f_2788:setup_api_scm",(void*)f_2788},
{"f_2791:setup_api_scm",(void*)f_2791},
{"f_3072:setup_api_scm",(void*)f_3072},
{"f_2794:setup_api_scm",(void*)f_2794},
{"f_3054:setup_api_scm",(void*)f_3054},
{"f_3057:setup_api_scm",(void*)f_3057},
{"f_3060:setup_api_scm",(void*)f_3060},
{"f_3063:setup_api_scm",(void*)f_3063},
{"f_3066:setup_api_scm",(void*)f_3066},
{"f_2797:setup_api_scm",(void*)f_2797},
{"f_3042:setup_api_scm",(void*)f_3042},
{"f_3045:setup_api_scm",(void*)f_3045},
{"f_3048:setup_api_scm",(void*)f_3048},
{"f_3051:setup_api_scm",(void*)f_3051},
{"f_3027:setup_api_scm",(void*)f_3027},
{"f_3028:setup_api_scm",(void*)f_3028},
{"f_2806:setup_api_scm",(void*)f_2806},
{"f_2981:setup_api_scm",(void*)f_2981},
{"f_2985:setup_api_scm",(void*)f_2985},
{"f_3001:setup_api_scm",(void*)f_3001},
{"f_3008:setup_api_scm",(void*)f_3008},
{"f_3011:setup_api_scm",(void*)f_3011},
{"f_3014:setup_api_scm",(void*)f_3014},
{"f_3017:setup_api_scm",(void*)f_3017},
{"f_3020:setup_api_scm",(void*)f_3020},
{"f_3023:setup_api_scm",(void*)f_3023},
{"f_2988:setup_api_scm",(void*)f_2988},
{"f_2998:setup_api_scm",(void*)f_2998},
{"f_2812:setup_api_scm",(void*)f_2812},
{"f_2914:setup_api_scm",(void*)f_2914},
{"f_2917:setup_api_scm",(void*)f_2917},
{"f_2920:setup_api_scm",(void*)f_2920},
{"f_2923:setup_api_scm",(void*)f_2923},
{"f_2926:setup_api_scm",(void*)f_2926},
{"f_2958:setup_api_scm",(void*)f_2958},
{"f_2961:setup_api_scm",(void*)f_2961},
{"f_2964:setup_api_scm",(void*)f_2964},
{"f_2967:setup_api_scm",(void*)f_2967},
{"f_2970:setup_api_scm",(void*)f_2970},
{"f_2973:setup_api_scm",(void*)f_2973},
{"f_2976:setup_api_scm",(void*)f_2976},
{"f_2936:setup_api_scm",(void*)f_2936},
{"f_2929:setup_api_scm",(void*)f_2929},
{"f_2831:setup_api_scm",(void*)f_2831},
{"f_2839:setup_api_scm",(void*)f_2839},
{"f_2886:setup_api_scm",(void*)f_2886},
{"f_2901:setup_api_scm",(void*)f_2901},
{"f_2907:setup_api_scm",(void*)f_2907},
{"f_2892:setup_api_scm",(void*)f_2892},
{"f_2845:setup_api_scm",(void*)f_2845},
{"f_2851:setup_api_scm",(void*)f_2851},
{"f_2855:setup_api_scm",(void*)f_2855},
{"f_2858:setup_api_scm",(void*)f_2858},
{"f_2861:setup_api_scm",(void*)f_2861},
{"f_2877:setup_api_scm",(void*)f_2877},
{"f_2874:setup_api_scm",(void*)f_2874},
{"f_2864:setup_api_scm",(void*)f_2864},
{"f_2867:setup_api_scm",(void*)f_2867},
{"f_2834:setup_api_scm",(void*)f_2834},
{"f_2557:setup_api_scm",(void*)f_2557},
{"f_2565:setup_api_scm",(void*)f_2565},
{"f_2568:setup_api_scm",(void*)f_2568},
{"f_2571:setup_api_scm",(void*)f_2571},
{"f_2574:setup_api_scm",(void*)f_2574},
{"f_2577:setup_api_scm",(void*)f_2577},
{"f_2580:setup_api_scm",(void*)f_2580},
{"f_2583:setup_api_scm",(void*)f_2583},
{"f_2535:setup_api_scm",(void*)f_2535},
{"f_2543:setup_api_scm",(void*)f_2543},
{"f_2546:setup_api_scm",(void*)f_2546},
{"f_2549:setup_api_scm",(void*)f_2549},
{"f_2552:setup_api_scm",(void*)f_2552},
{"f_2555:setup_api_scm",(void*)f_2555},
{"f_2328:setup_api_scm",(void*)f_2328},
{"f_2444:setup_api_scm",(void*)f_2444},
{"f_2356:setup_api_scm",(void*)f_2356},
{"f_2385:setup_api_scm",(void*)f_2385},
{"f_2335:setup_api_scm",(void*)f_2335},
{"f_2293:setup_api_scm",(void*)f_2293},
{"f_2270:setup_api_scm",(void*)f_2270},
{"f_2228:setup_api_scm",(void*)f_2228},
{"f_2259:setup_api_scm",(void*)f_2259},
{"f_2266:setup_api_scm",(void*)f_2266},
{"f_2232:setup_api_scm",(void*)f_2232},
{"f_2253:setup_api_scm",(void*)f_2253},
{"f_2250:setup_api_scm",(void*)f_2250},
{"f_2247:setup_api_scm",(void*)f_2247},
{"f_2224:setup_api_scm",(void*)f_2224},
{"f_2346:setup_api_scm",(void*)f_2346},
{"f_2473:setup_api_scm",(void*)f_2473},
{"f_2396:setup_api_scm",(void*)f_2396},
{"f_2398:setup_api_scm",(void*)f_2398},
{"f_2416:setup_api_scm",(void*)f_2416},
{"f_2419:setup_api_scm",(void*)f_2419},
{"f_2422:setup_api_scm",(void*)f_2422},
{"f_2425:setup_api_scm",(void*)f_2425},
{"f_2410:setup_api_scm",(void*)f_2410},
{"f_2431:setup_api_scm",(void*)f_2431},
{"f_2302:setup_api_scm",(void*)f_2302},
{"f_2326:setup_api_scm",(void*)f_2326},
{"f_2309:setup_api_scm",(void*)f_2309},
{"f_2091:setup_api_scm",(void*)f_2091},
{"f_2192:setup_api_scm",(void*)f_2192},
{"f_2195:setup_api_scm",(void*)f_2195},
{"f_2198:setup_api_scm",(void*)f_2198},
{"f_2201:setup_api_scm",(void*)f_2201},
{"f_2095:setup_api_scm",(void*)f_2095},
{"f_2149:setup_api_scm",(void*)f_2149},
{"f_2152:setup_api_scm",(void*)f_2152},
{"f_2159:setup_api_scm",(void*)f_2159},
{"f_2162:setup_api_scm",(void*)f_2162},
{"f_2165:setup_api_scm",(void*)f_2165},
{"f_2185:setup_api_scm",(void*)f_2185},
{"f_2168:setup_api_scm",(void*)f_2168},
{"f_2171:setup_api_scm",(void*)f_2171},
{"f_2181:setup_api_scm",(void*)f_2181},
{"f_2174:setup_api_scm",(void*)f_2174},
{"f_2177:setup_api_scm",(void*)f_2177},
{"f_2110:setup_api_scm",(void*)f_2110},
{"f_2120:setup_api_scm",(void*)f_2120},
{"f_2126:setup_api_scm",(void*)f_2126},
{"f_2130:setup_api_scm",(void*)f_2130},
{"f_2146:setup_api_scm",(void*)f_2146},
{"f_2139:setup_api_scm",(void*)f_2139},
{"f_1993:setup_api_scm",(void*)f_1993},
{"f_1997:setup_api_scm",(void*)f_1997},
{"f_2085:setup_api_scm",(void*)f_2085},
{"f_2000:setup_api_scm",(void*)f_2000},
{"f_2005:setup_api_scm",(void*)f_2005},
{"f_2009:setup_api_scm",(void*)f_2009},
{"f_2012:setup_api_scm",(void*)f_2012},
{"f_2015:setup_api_scm",(void*)f_2015},
{"f_2077:setup_api_scm",(void*)f_2077},
{"f_2080:setup_api_scm",(void*)f_2080},
{"f_2018:setup_api_scm",(void*)f_2018},
{"f_2021:setup_api_scm",(void*)f_2021},
{"f_2024:setup_api_scm",(void*)f_2024},
{"f_2027:setup_api_scm",(void*)f_2027},
{"f_2051:setup_api_scm",(void*)f_2051},
{"f_2054:setup_api_scm",(void*)f_2054},
{"f_2057:setup_api_scm",(void*)f_2057},
{"f_1968:setup_api_scm",(void*)f_1968},
{"f_1942:setup_api_scm",(void*)f_1942},
{"f_1868:setup_api_scm",(void*)f_1868},
{"f_1858:setup_api_scm",(void*)f_1858},
{"f_1866:setup_api_scm",(void*)f_1866},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
