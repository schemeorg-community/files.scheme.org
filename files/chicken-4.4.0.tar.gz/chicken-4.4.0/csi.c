/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: csi.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -output-file csi.c -extend ./private-namespace.scm
   used units: library eval chicken_syntax srfi_69 ports extras
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[350];
static double C_possibly_force_alignment;


/* from k1469 */
static C_word C_fcall stub75(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub75(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_ccall f_1304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1310)
static void C_ccall f_1310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5129)
static void C_ccall f_5129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2584)
static void C_ccall f_2584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5124)
static void C_ccall f_5124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5121)
static void C_ccall f_5121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_fcall f_2266(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_fcall f_2180(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_fcall f_2190(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5010)
static void C_ccall f_5010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_fcall f_4161(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4167)
static void C_fcall f_4167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_fcall f_4173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_fcall f_4949(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4333)
static void C_fcall f_4333(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_fcall f_4342(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_fcall f_4348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5651)
static void C_ccall f5651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_fcall f_4855(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4828)
static void C_fcall f_4828(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_fcall f_4789(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_ccall f_4740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_fcall f_4750(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_ccall f_4637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_fcall f_4384(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4544)
static void C_ccall f_4544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4498)
static void C_ccall f_4498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4263)
static void C_fcall f_4263(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_fcall f_4279(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_fcall f_4178(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4184)
static void C_fcall f_4184(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4192)
static void C_fcall f_4192(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_fcall f_4000(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_fcall f_4006(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4028)
static void C_fcall f_4028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static C_word C_fcall f_4117(C_word t0);
C_noret_decl(f_3943)
static void C_fcall f_3943(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3949)
static void C_fcall f_3949(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3961)
static void C_fcall f_3961(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_fcall f_3893(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3852)
static void C_fcall f_3852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3669)
static void C_fcall f_3669(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_fcall f_3754(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3791)
static void C_fcall f_3791(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3801)
static void C_ccall f_3801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_fcall f_3703(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3716)
static void C_ccall f_3716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_fcall f_3640(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3589)
static void C_fcall f_3589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_fcall f_3584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3478)
static void C_fcall f_3478(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_fcall f_3546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3510)
static void C_ccall f_3510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_fcall f_3481(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_fcall f_3345(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3367)
static void C_fcall f_3367(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_fcall f_3331(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_fcall f_3232(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_fcall f_3240(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_fcall f_2985(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_fcall f_2870(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2895)
static void C_ccall f_2895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_fcall f_2604(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_fcall f_2636(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_fcall f_2537(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_fcall f_2454(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_fcall f_2462(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_fcall f_2471(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_fcall f_2479(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2387)
static void C_ccall f_2387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_fcall f_2329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1782)
static void C_fcall f_1782(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_fcall f_1932(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_fcall f_1640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1584)
static void C_fcall f_1584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1594)
static void C_ccall f_1594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1503)
static C_word C_fcall f_1503(C_word t0,C_word t1);
C_noret_decl(f_1476)
static void C_fcall f_1476(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1439)
static void C_fcall f_1439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1414)
static void C_ccall f_1414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1412)
static void C_ccall f_1412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1358)
static void C_ccall f_1358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_ccall f_1330(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2266)
static void C_fcall trf_2266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2266(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2266(t0,t1,t2,t3);}

C_noret_decl(trf_2180)
static void C_fcall trf_2180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2180(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2180(t0,t1,t2);}

C_noret_decl(trf_2190)
static void C_fcall trf_2190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2190(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2190(t0,t1);}

C_noret_decl(trf_4161)
static void C_fcall trf_4161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4161(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4161(t0,t1);}

C_noret_decl(trf_4167)
static void C_fcall trf_4167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4167(t0,t1);}

C_noret_decl(trf_4173)
static void C_fcall trf_4173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4173(t0,t1);}

C_noret_decl(trf_4949)
static void C_fcall trf_4949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4949(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4949(t0,t1,t2);}

C_noret_decl(trf_4333)
static void C_fcall trf_4333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4333(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4333(t0,t1);}

C_noret_decl(trf_4342)
static void C_fcall trf_4342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4342(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4342(t0,t1);}

C_noret_decl(trf_4348)
static void C_fcall trf_4348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4348(t0,t1);}

C_noret_decl(trf_4855)
static void C_fcall trf_4855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4855(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4855(t0,t1,t2);}

C_noret_decl(trf_4828)
static void C_fcall trf_4828(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4828(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4828(t0,t1,t2);}

C_noret_decl(trf_4789)
static void C_fcall trf_4789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4789(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4789(t0,t1,t2);}

C_noret_decl(trf_4750)
static void C_fcall trf_4750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4750(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4750(t0,t1,t2);}

C_noret_decl(trf_4384)
static void C_fcall trf_4384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4384(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4384(t0,t1,t2);}

C_noret_decl(trf_4263)
static void C_fcall trf_4263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4263(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4263(t0,t1,t2);}

C_noret_decl(trf_4279)
static void C_fcall trf_4279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4279(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4279(t0,t1,t2);}

C_noret_decl(trf_4178)
static void C_fcall trf_4178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4178(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4178(t0,t1,t2);}

C_noret_decl(trf_4184)
static void C_fcall trf_4184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4184(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4184(t0,t1,t2);}

C_noret_decl(trf_4192)
static void C_fcall trf_4192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4192(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4192(t0,t1,t2);}

C_noret_decl(trf_4000)
static void C_fcall trf_4000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4000(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4000(t0,t1);}

C_noret_decl(trf_4006)
static void C_fcall trf_4006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4006(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4006(t0,t1,t2);}

C_noret_decl(trf_4028)
static void C_fcall trf_4028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4028(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4028(t0,t1);}

C_noret_decl(trf_3943)
static void C_fcall trf_3943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3943(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3943(t0,t1,t2);}

C_noret_decl(trf_3949)
static void C_fcall trf_3949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3949(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3949(t0,t1,t2);}

C_noret_decl(trf_3961)
static void C_fcall trf_3961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3961(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3961(t0,t1,t2);}

C_noret_decl(trf_3893)
static void C_fcall trf_3893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3893(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3893(t0,t1,t2);}

C_noret_decl(trf_3852)
static void C_fcall trf_3852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3852(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3852(t0,t1,t2);}

C_noret_decl(trf_3669)
static void C_fcall trf_3669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3669(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3669(t0,t1,t2);}

C_noret_decl(trf_3754)
static void C_fcall trf_3754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3754(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3754(t0,t1,t2,t3);}

C_noret_decl(trf_3791)
static void C_fcall trf_3791(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3791(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3791(t0,t1,t2);}

C_noret_decl(trf_3703)
static void C_fcall trf_3703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3703(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3703(t0,t1,t2,t3);}

C_noret_decl(trf_3640)
static void C_fcall trf_3640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3640(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3640(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3589)
static void C_fcall trf_3589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3589(t0,t1);}

C_noret_decl(trf_3584)
static void C_fcall trf_3584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3584(t0,t1,t2);}

C_noret_decl(trf_3478)
static void C_fcall trf_3478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3478(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3478(t0,t1,t2,t3);}

C_noret_decl(trf_3546)
static void C_fcall trf_3546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3546(t0,t1);}

C_noret_decl(trf_3481)
static void C_fcall trf_3481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3481(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3481(t0,t1,t2);}

C_noret_decl(trf_3345)
static void C_fcall trf_3345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3345(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3345(t0,t1,t2);}

C_noret_decl(trf_3367)
static void C_fcall trf_3367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3367(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3367(t0,t1,t2);}

C_noret_decl(trf_3331)
static void C_fcall trf_3331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3331(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3331(t0,t1,t2);}

C_noret_decl(trf_3232)
static void C_fcall trf_3232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3232(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3232(t0,t1,t2);}

C_noret_decl(trf_3240)
static void C_fcall trf_3240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3240(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3240(t0,t1,t2);}

C_noret_decl(trf_3253)
static void C_fcall trf_3253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3253(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3253(t0,t1,t2);}

C_noret_decl(trf_2985)
static void C_fcall trf_2985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2985(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2985(t0,t1);}

C_noret_decl(trf_2870)
static void C_fcall trf_2870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2870(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2870(t0,t1,t2);}

C_noret_decl(trf_2604)
static void C_fcall trf_2604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2604(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2604(t0,t1,t2);}

C_noret_decl(trf_2636)
static void C_fcall trf_2636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2636(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2636(t0,t1,t2,t3);}

C_noret_decl(trf_2537)
static void C_fcall trf_2537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2537(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2537(t0,t1,t2);}

C_noret_decl(trf_2454)
static void C_fcall trf_2454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2454(t0,t1,t2);}

C_noret_decl(trf_2462)
static void C_fcall trf_2462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2462(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2462(t0,t1,t2);}

C_noret_decl(trf_2471)
static void C_fcall trf_2471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2471(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2471(t0,t1,t2);}

C_noret_decl(trf_2479)
static void C_fcall trf_2479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2479(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2479(t0,t1,t2);}

C_noret_decl(trf_2329)
static void C_fcall trf_2329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2329(t0,t1);}

C_noret_decl(trf_1782)
static void C_fcall trf_1782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1782(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1782(t0,t1);}

C_noret_decl(trf_1932)
static void C_fcall trf_1932(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1932(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1932(t0,t1,t2);}

C_noret_decl(trf_1640)
static void C_fcall trf_1640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1640(t0,t1);}

C_noret_decl(trf_1584)
static void C_fcall trf_1584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1584(t0,t1,t2);}

C_noret_decl(trf_1476)
static void C_fcall trf_1476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1476(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1476(t0,t1);}

C_noret_decl(trf_1439)
static void C_fcall trf_1439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1439(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2419)){
C_save(t1);
C_rereclaim2(2419*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,350);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[4]=C_h_intern(&lf[4],27,"\003sysrepl-print-length-limit");
lf[5]=C_h_intern(&lf[5],4,"\000csi");
lf[6]=C_h_intern(&lf[6],12,"\003sysfeatures");
lf[7]=C_h_intern(&lf[7],15,"\003csiprint-usage");
lf[8]=C_h_intern(&lf[8],7,"display");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\004V    -b  -batch                    terminate after command-line processing\012 "
"   -w  -no-warnings              disable all warnings\012    -K  -keyword-style STY"
"LE      enable alternative keyword-syntax\012                                   (pr"
"efix, suffix or none)\012        -no-parentheses-synonyms  disables list delimiter "
"synonyms\012        -no-symbol-escape         disables support for escaped symbols\012"
"        -r5rs-syntax              disables the Chicken extensions to\012           "
"                        R5RS syntax\012    -s  -script PATHNAME          use interp"
"reter for shell scripts\012        -ss PATHNAME              shell script with `mai"
"n\047 procedure\012        -sx PATHNAME              same as `-s\047, but print each expr"
"ession\012                                   as it is evaluated\012        -setup-mode"
"               prefer the current directory when locating extensions\012    -R  -re"
"quire-extension NAME   require extension and import before\012                     "
"              executing code\012    -I  -include-path PATHNAME    add PATHNAME to i"
"nclude path\012    --                            ignore all following options\012");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\003 \047\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000D    -n  -no-init                  do not load initialization file ` ");
lf[12]=C_h_intern(&lf[12],19,"\003sysprint-to-string");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\002\344usage: csi [FILENAME | OPTION ...]\012\012  `csi\047 is the CHICKEN interpreter.\012  \012"
"  FILENAME is a Scheme source file name with optional extension. OPTION may be\012 "
" one of the following:\012\012    -h  -help  --help             display this text and "
"exit\012    -v  -version                  display version and exit\012        -release"
"                  print release number and exit\012    -i  -case-insensitive       "
"  enable case-insensitive reading\012    -e  -eval EXPRESSION          evaluate giv"
"en expression\012    -p  -print EXPRESSION         evaluate and print result(s)\012   "
" -P  -pretty-print EXPRESSION  evaluate and print result(s) prettily\012    -D  -fe"
"ature SYMBOL           register feature identifier\012    -q  -quiet               "
"     do not print banner\012");
lf[14]=C_h_intern(&lf[14],16,"\003csiprint-banner");
lf[15]=C_h_intern(&lf[15],5,"print");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2010 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[18]=C_h_intern(&lf[18],15,"chicken-version");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\007CHICKEN");
lf[20]=C_h_intern(&lf[20],7,"newline");
lf[21]=C_h_intern(&lf[21],9,"read-char");
lf[22]=C_h_intern(&lf[22],4,"read");
lf[23]=C_h_intern(&lf[23],18,"\003sysuser-read-hook");
lf[24]=C_h_intern(&lf[24],5,"quote");
lf[25]=C_h_intern(&lf[25],17,"\003csihistory-count");
lf[26]=C_h_intern(&lf[26],15,"\003csihistory-ref");
lf[27]=C_h_intern(&lf[27],21,"\003syssharp-number-hook");
lf[29]=C_h_intern(&lf[29],9,"substring");
lf[30]=C_h_intern(&lf[30],18,"\003csichop-separator");
lf[31]=C_h_intern(&lf[31],1,"@");
lf[32]=C_h_intern(&lf[32],12,"file-exists\077");
lf[33]=C_h_intern(&lf[33],13,"string-append");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[35]=C_h_intern(&lf[35],22,"\003csilookup-script-file");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[37]=C_h_intern(&lf[37],25,"\003syspeek-nonnull-c-string");
lf[38]=C_h_intern(&lf[38],12,"string-split");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[41]=C_h_intern(&lf[41],24,"get-environment-variable");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[43]=C_h_intern(&lf[43],16,"\003csihistory-list");
lf[44]=C_h_intern(&lf[44],13,"vector-resize");
lf[45]=C_h_intern(&lf[45],15,"\003csihistory-add");
lf[46]=C_h_intern(&lf[46],19,"\003sysundefined-value");
lf[47]=C_h_intern(&lf[47],9,"\003syserror");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[49]=C_h_intern(&lf[49],14,"\003csitty-input\077");
lf[50]=C_h_intern(&lf[50],13,"\003systty-port\077");
lf[51]=C_h_intern(&lf[51],18,"\003sysstandard-input");
lf[52]=C_h_intern(&lf[52],18,"\003sysbreak-on-error");
lf[53]=C_h_intern(&lf[53],20,"\003sysread-prompt-hook");
lf[55]=C_h_intern(&lf[55],16,"toplevel-command");
lf[56]=C_h_intern(&lf[56],19,"\003syshash-table-set!");
lf[57]=C_h_intern(&lf[57],4,"eval");
lf[58]=C_h_intern(&lf[58],12,"load-noisily");
lf[59]=C_h_intern(&lf[59],9,"read-line");
lf[60]=C_h_intern(&lf[60],6,"length");
lf[61]=C_h_intern(&lf[61],5,"write");
lf[62]=C_h_intern(&lf[62],6,"printf");
lf[63]=C_h_intern(&lf[63],6,"expand");
lf[64]=C_h_intern(&lf[64],12,"pretty-print");
lf[65]=C_h_intern(&lf[65],8,"integer\077");
lf[66]=C_h_intern(&lf[66],6,"values");
lf[67]=C_h_intern(&lf[67],18,"\003sysrepl-eval-hook");
lf[68]=C_h_intern(&lf[68],4,"exit");
lf[69]=C_h_intern(&lf[69],1,"x");
lf[70]=C_h_intern(&lf[70],16,"\003sysstrip-syntax");
lf[71]=C_h_intern(&lf[71],1,"p");
lf[72]=C_h_intern(&lf[72],1,"d");
lf[73]=C_h_intern(&lf[73],12,"\003csidescribe");
lf[74]=C_h_intern(&lf[74],2,"du");
lf[75]=C_h_intern(&lf[75],8,"\003csidump");
lf[76]=C_h_intern(&lf[76],3,"dur");
lf[77]=C_h_intern(&lf[77],1,"r");
lf[78]=C_h_intern(&lf[78],10,"\003csireport");
lf[79]=C_h_intern(&lf[79],1,"q");
lf[80]=C_h_intern(&lf[80],1,"l");
lf[81]=C_h_intern(&lf[81],4,"load");
lf[82]=C_h_intern(&lf[82],2,"ln");
lf[83]=C_h_intern(&lf[83],6,"print*");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[85]=C_h_intern(&lf[85],8,"\000printer");
lf[86]=C_h_intern(&lf[86],12,"\003sysfor-each");
lf[87]=C_h_intern(&lf[87],1,"t");
lf[88]=C_h_intern(&lf[88],17,"\003sysdisplay-times");
lf[89]=C_h_intern(&lf[89],14,"\003sysstop-timer");
lf[90]=C_h_intern(&lf[90],15,"\003sysstart-timer");
lf[91]=C_h_intern(&lf[91],3,"exn");
lf[92]=C_h_intern(&lf[92],18,"\003syslast-exception");
lf[93]=C_h_intern(&lf[93],1,"s");
lf[94]=C_h_intern(&lf[94],6,"system");
lf[95]=C_h_intern(&lf[95],1,"\077");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[97]=C_h_intern(&lf[97],23,"\003syshash-table-for-each");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\002\220Toplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,s TEXT ...   "
"    Execute shell-command\012 ,exn              Describe last exception\012 ,t EXP    "
"        Evaluate form and print elapsed time\012 ,x EXP            Pretty print exp"
"anded expression EXP\012");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[100]=C_h_intern(&lf[100],18,"\003syshash-table-ref");
lf[101]=C_h_intern(&lf[101],7,"unquote");
lf[102]=C_h_intern(&lf[102],4,"chop");
lf[103]=C_h_intern(&lf[103],4,"sort");
lf[104]=C_h_intern(&lf[104],19,"with-output-to-port");
lf[105]=C_h_intern(&lf[105],19,"current-output-port");
lf[106]=C_h_intern(&lf[106],8,"truncate");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[109]=C_h_intern(&lf[109],16,"\003syswrite-char-0");
lf[110]=C_h_intern(&lf[110],19,"\003sysstandard-output");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\002\134~%~%~\012                   Machine type:    \011~A ~A~%~\012                   Soft"
"ware type:   \011~A~%~\012                   Software version:\011~A~%~\012                 "
"  Build platform:  \011~A~%~\012                   Installation prefix:\011~A~%~\012        "
"           Extension path:  \011~A~%~\012                   Include path:    \011~A~%~\012  "
"                 Symbol-table load:\011~S~%  ~\012                     Avg bucket leng"
"th:\011~S~%  ~\012                     Total symbol count:\011~S~%~\012                   Me"
"mory:\011heap size is ~S bytes~A with ~S bytes currently in use~%~  \012              "
"       nursery size is ~S bytes, stack grows ~A~%");
lf[118]=C_h_intern(&lf[118],21,"\003sysinclude-pathnames");
lf[119]=C_h_intern(&lf[119],15,"repository-path");
lf[120]=C_h_intern(&lf[120],14,"build-platform");
lf[121]=C_h_intern(&lf[121],16,"software-version");
lf[122]=C_h_intern(&lf[122],13,"software-type");
lf[123]=C_h_intern(&lf[123],12,"machine-type");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[125]=C_h_intern(&lf[125],11,"make-string");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[127]=C_h_intern(&lf[127],8,"string<\077");
lf[128]=C_h_intern(&lf[128],15,"keyword->string");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\012Features:\012");
lf[130]=C_h_intern(&lf[130],17,"memory-statistics");
lf[131]=C_h_intern(&lf[131],21,"\003syssymbol-table-info");
lf[132]=C_h_intern(&lf[132],2,"gc");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[136]=C_h_intern(&lf[136],7,"sprintf");
lf[137]=C_h_intern(&lf[137],7,"fprintf");
lf[138]=C_h_intern(&lf[138],8,"list-ref");
lf[139]=C_h_intern(&lf[139],10,"string-ref");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[154]=C_h_intern(&lf[154],28,"\003sysarbitrary-unbound-symbol");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[158]=C_h_intern(&lf[158],8,"\003syssize");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[160]=C_h_intern(&lf[160],8,"\003sysslot");
lf[161]=C_h_intern(&lf[161],27,"\003syswith-print-length-limit");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\005  ~s\011");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\020  \012properties:\012\012");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\013uninterned ");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\027~asymbol with name ~S~%");
lf[167]=C_h_intern(&lf[167],18,"\003syssymbol->string");
lf[168]=C_h_intern(&lf[168],20,"\003sysinterned-symbol\077");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\010keyword ");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[171]=C_h_intern(&lf[171],32,"\003syssymbol-has-toplevel-binding\077");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\035pair with car ~S and cdr ~S~%");
lf[174]=C_h_intern(&lf[174],15,"describe-object");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[176]=C_h_intern(&lf[176],25,"\003syspeek-unsigned-integer");
lf[177]=C_h_intern(&lf[177],9,"\000tinyclos");
lf[178]=C_h_intern(&lf[178],19,"\010tinyclosentity-tag");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[194]=C_h_intern(&lf[194],11,"\003csihexdump");
lf[195]=C_h_intern(&lf[195],8,"\003sysbyte");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[198]=C_h_intern(&lf[198],23,"\003syslambda-info->string");
lf[199]=C_h_intern(&lf[199],10,"hash-table");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[201]=C_h_intern(&lf[201],15,"hash-table-walk");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[206]=C_h_intern(&lf[206],9,"condition");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[208]=C_h_intern(&lf[208],4,"cdar");
lf[209]=C_h_intern(&lf[209],4,"caar");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[212]=C_h_intern(&lf[212],6,"unveil");
lf[213]=C_h_intern(&lf[213],6,"append");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[216]=C_h_intern(&lf[216],15,"meroon-instance");
lf[217]=C_h_intern(&lf[217],9,"provided\077");
lf[218]=C_h_intern(&lf[218],6,"meroon");
lf[219]=C_h_intern(&lf[219],15,"\003sysbytevector\077");
lf[220]=C_h_intern(&lf[220],13,"\003syslocative\077");
lf[221]=C_h_intern(&lf[221],9,"instance\077");
lf[222]=C_h_intern(&lf[222],5,"port\077");
lf[223]=C_h_intern(&lf[223],11,"\003sysnumber\077");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[225]=C_h_intern(&lf[225],17,"\003sysblock-address");
lf[226]=C_h_intern(&lf[226],14,"set-describer!");
lf[227]=C_h_intern(&lf[227],16,"\003syscheck-symbol");
lf[228]=C_h_intern(&lf[228],6,"symbol");
lf[229]=C_h_intern(&lf[229],3,"min");
lf[230]=C_h_intern(&lf[230],4,"dump");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot dump immediate object");
lf[232]=C_h_intern(&lf[232],13,"\003syspeek-byte");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot dump object");
lf[234]=C_h_intern(&lf[234],10,"write-char");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[236]=C_h_intern(&lf[236],5,"fxmod");
lf[237]=C_h_intern(&lf[237],7,"\003csidel");
lf[238]=C_h_intern(&lf[238],11,"\003csideldups");
lf[239]=C_h_intern(&lf[239],6,"equal\077");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[247]=C_h_intern(&lf[247],6,"string");
lf[248]=C_h_intern(&lf[248],7,"\003sysmap");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[250]=C_h_intern(&lf[250],16,"\003sysstring->list");
lf[251]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000"
"\002\376B\000\000\006--help\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-case-insensitive\376\003\000\000\002\376B\000"
"\000\016-keyword-style\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000"
"\000\002\376B\000\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\022-require-extension\376\003\000\000\002\376B\000\000\006-b"
"atch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\015-include-p"
"ath\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-print\376\003\000\000\002\376B\000\000\002--\376\377\016");
lf[252]=C_h_intern(&lf[252],7,"\003csirun");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[254]=C_h_intern(&lf[254],8,"\003syslist");
lf[255]=C_h_intern(&lf[255],17,"open-input-string");
lf[256]=C_h_intern(&lf[256],4,"repl");
lf[257]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\002-n"
"\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-"
"insensitive\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000\000\002\376B\000"
"\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B"
"\000\000\007-script\376\377\016");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\002-K");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[266]=C_h_intern(&lf[266],22,"\004corerequire-extension");
lf[267]=C_h_intern(&lf[267],14,"string->symbol");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[272]=C_h_intern(&lf[272],8,"for-each");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[276]=C_h_intern(&lf[276],4,"main");
lf[277]=C_h_intern(&lf[277],22,"command-line-arguments");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[279]=C_h_intern(&lf[279],18,"\003sysstandard-error");
lf[280]=C_h_intern(&lf[280],8,"\003sysload");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[284]=C_h_intern(&lf[284],17,"\003sysstring-append");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[286]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[287]=C_h_intern(&lf[287],13,"symbol-escape");
lf[288]=C_h_intern(&lf[288],20,"parentheses-synonyms");
lf[289]=C_h_intern(&lf[289],13,"keyword-style");
lf[290]=C_h_intern(&lf[290],5,"\000none");
lf[291]=C_h_intern(&lf[291],14,"case-sensitive");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000/Disabled the Chicken extensions to R5RS syntax\012");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000%Disabled support for escaped symbols\012");
lf[295]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\377\016");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000*Disabled support for parentheses synonyms\012");
lf[297]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\377\016");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[299]=C_h_intern(&lf[299],7,"\000prefix");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[302]=C_h_intern(&lf[302],7,"\000suffix");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[304]=C_h_intern(&lf[304],8,"string=\077");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[307]=C_h_intern(&lf[307],17,"register-feature!");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[310]=C_h_intern(&lf[310],16,"case-insensitive");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[312]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[313]=C_h_intern(&lf[313],12,"load-verbose");
lf[314]=C_h_intern(&lf[314],20,"\003syswarnings-enabled");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[316]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[319]=C_h_intern(&lf[319],14,"\003syssetup-mode");
lf[320]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[321]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[322]=C_h_intern(&lf[322],20,"\003syseval-debug-level");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[326]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[327]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[328]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[329]=C_h_intern(&lf[329],20,"\003syswindows-platform");
lf[330]=C_h_intern(&lf[330],6,"script");
lf[331]=C_h_intern(&lf[331],12,"program-name");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[334]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[335]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[337]=C_h_intern(&lf[337],17,"get-output-string");
lf[338]=C_h_intern(&lf[338],18,"open-output-string");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[340]=C_h_intern(&lf[340],7,"reverse");
lf[341]=C_h_intern(&lf[341],22,"with-exception-handler");
lf[342]=C_h_intern(&lf[342],30,"call-with-current-continuation");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[344]=C_h_intern(&lf[344],25,"\003sysimplicit-exit-handler");
lf[345]=C_h_intern(&lf[345],11,"make-vector");
lf[346]=C_h_intern(&lf[346],17,"\003syspeek-c-string");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[349]=C_h_intern(&lf[349],11,"repl-prompt");
C_register_lf2(lf,350,create_ptable());
t2=C_mutate(&lf[0] /* (set! c172 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1298,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1296 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1301,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1299 in k1296 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1302 in k1299 in k1296 */
static void C_ccall f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! constant23 ...) */,lf[3]);
t3=C_set_block_item(lf[4] /* repl-print-length-limit */,0,C_fix(2048));
t4=(C_word)C_a_i_cons(&a,2,lf[5],*((C_word*)lf[6]+1));
t5=C_mutate((C_word*)lf[6]+1 /* (set! features ...) */,t4);
t6=C_mutate((C_word*)lf[7]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1323,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[14]+1 /* (set! print-banner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1351,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[21]+1);
t9=*((C_word*)lf[22]+1);
t10=C_retrieve(lf[23]);
t11=C_mutate((C_word*)lf[23]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1367,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[27]+1 /* (set! sharp-number-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1400,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[28] /* (set! dirseparator? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1414,tmp=(C_word)a,a+=2,tmp));
t14=*((C_word*)lf[29]+1);
t15=C_mutate((C_word*)lf[30]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t14,tmp=(C_word)a,a+=3,tmp));
t16=C_set_block_item(lf[31] /* @ */,0,C_SCHEME_FALSE);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 178  make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[125]+1)))(3,*((C_word*)lf[125]+1),t17,C_fix(256));}

/* k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1476,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[35]+1 /* (set! lookup-script-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1524,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[43]+1 /* (set! history-list ...) */,t5);
t7=C_set_block_item(lf[25] /* history-count */,0,C_fix(1));
t8=C_retrieve(lf[44]);
t9=C_mutate((C_word*)lf[45]+1 /* (set! history-add ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1630,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[26]+1 /* (set! history-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1669,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=*((C_word*)lf[136]+1);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5129,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 230  repl-prompt */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t11,t13);}

/* a5128 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5129,2,t0,t1);}
/* csi.scm: 233  sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[348],C_retrieve(lf[25]));}

/* k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1694,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1 /* (set! tty-input? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1696,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[52] /* break-on-error */,0,C_SCHEME_FALSE);
t4=C_retrieve(lf[53]);
t5=C_mutate((C_word*)lf[53]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1709,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 245  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[345]+1)))(4,*((C_word*)lf[345]+1),t6,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=C_mutate(&lf[54] /* (set! command-table ...) */,t1);
t3=C_mutate((C_word*)lf[55]+1 /* (set! toplevel-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1725,tmp=(C_word)a,a+=2,tmp));
t4=C_retrieve(lf[57]);
t5=C_retrieve(lf[58]);
t6=*((C_word*)lf[22]+1);
t7=C_retrieve(lf[59]);
t8=*((C_word*)lf[60]+1);
t9=*((C_word*)lf[8]+1);
t10=*((C_word*)lf[61]+1);
t11=C_retrieve(lf[38]);
t12=*((C_word*)lf[62]+1);
t13=C_retrieve(lf[63]);
t14=C_retrieve(lf[64]);
t15=*((C_word*)lf[65]+1);
t16=*((C_word*)lf[66]+1);
t17=C_mutate((C_word*)lf[67]+1 /* (set! repl-eval-hook ...) */,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1766,a[2]=t12,a[3]=t9,a[4]=t16,a[5]=t5,a[6]=t7,a[7]=t11,a[8]=t4,a[9]=t6,a[10]=t13,a[11]=t14,tmp=(C_word)a,a+=12,tmp));
t18=*((C_word*)lf[62]+1);
t19=C_retrieve(lf[102]);
t20=C_retrieve(lf[103]);
t21=C_retrieve(lf[104]);
t22=*((C_word*)lf[105]+1);
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[2],a[3]=t22,a[4]=t21,a[5]=t20,a[6]=t19,a[7]=t18,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 386  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t23,lf[347]);}

/* k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_2306(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[346]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_PREFIX),C_fix(0));}}

/* k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2306,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! report ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t3=C_mutate(&lf[133] /* (set! bytevector-data ...) */,lf[134]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2584,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 453  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[345]+1)))(4,*((C_word*)lf[345]+1),t4,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2584,2,t0,t1);}
t2=C_mutate(&lf[135] /* (set! describer-table ...) */,t1);
t3=*((C_word*)lf[136]+1);
t4=*((C_word*)lf[62]+1);
t5=C_retrieve(lf[137]);
t6=*((C_word*)lf[60]+1);
t7=*((C_word*)lf[138]+1);
t8=*((C_word*)lf[139]+1);
t9=C_mutate((C_word*)lf[73]+1 /* (set! describe ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2586,a[2]=t3,a[3]=t7,a[4]=t6,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=C_mutate((C_word*)lf[226]+1 /* (set! set-describer! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3467,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[75]+1 /* (set! dump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3476,tmp=(C_word)a,a+=2,tmp));
t12=*((C_word*)lf[8]+1);
t13=*((C_word*)lf[33]+1);
t14=*((C_word*)lf[125]+1);
t15=*((C_word*)lf[234]+1);
t16=C_mutate((C_word*)lf[194]+1 /* (set! hexdump ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3637,a[2]=t12,a[3]=t15,a[4]=t14,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t17=C_mutate((C_word*)lf[237]+1 /* (set! del ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3846,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[238]+1 /* (set! deldups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3884,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[240] /* (set! member* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3943,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[241] /* (set! canonicalize-args ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4000,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[252]+1 /* (set! run ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4145,tmp=(C_word)a,a+=2,tmp));
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 869  run */
((C_proc2)C_retrieve_symbol_proc(lf[252]))(2,*((C_word*)lf[252]+1),t22);}

/* k5116 in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5121,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5124,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[344]))(2,*((C_word*)lf[344]+1),t3);}

/* k5122 in k5116 in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5119 in k5116 in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4149,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5112,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 730  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[343]);}

/* k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5112,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[336]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2168,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 364  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t3,t2);}

/* k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2175,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2232,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[342]+1)))(3,*((C_word*)lf[342]+1),t6,t7);}

/* a2231 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2232,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2238,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2250,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[341]))(4,*((C_word*)lf[341]+1),t1,t3,t4);}

/* a2249 in a2231 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2288 in a2249 in a2231 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2289r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2289r(t0,t1,t2);}}

static void C_ccall f_2289r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2295,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k337342 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2294 in a2288 in a2249 in a2231 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2295,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2255 in a2249 in a2231 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2264,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 372  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,((C_word*)t0)[2]);}

/* k2262 in a2255 in a2249 in a2231 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2266(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop344 in k2262 in a2255 in a2249 in a2231 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2266(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2266,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 374  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[340]+1)))(3,*((C_word*)lf[340]+1),t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2283,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 372  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t4,((C_word*)t0)[2]);}}

/* k2281 in doloop344 in k2262 in a2255 in a2249 in a2231 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2283,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2266(t3,((C_word*)t0)[2],t1,t2);}

/* a2237 in a2231 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2238,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* k337342 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2243 in a2237 in a2231 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2244,2,t0,t1);}
/* csi.scm: 371  ##sys#error */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[339],((C_word*)t0)[2]);}

/* k2173 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g340341 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2176 in k2173 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2178,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2180,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2180(t5,((C_word*)t0)[2],t1);}

/* loop313 in k2176 in k2173 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2180(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2180,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2226,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_stringp(t5))){
t6=t3;
f_2190(t6,(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST));}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2217,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 368  open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[338]))(2,*((C_word*)lf[338]+1),t6);}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2215 in loop313 in k2176 in k2173 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2220,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 369  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),t2,((C_word*)t0)[2],t1);}

/* k2218 in k2215 in loop313 in k2176 in k2173 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 370  get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[337]))(3,*((C_word*)lf[337]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2224 in loop313 in k2176 in k2173 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2226,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2190(t2,(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k2188 in loop313 in k2176 in k2173 in k2166 in k5110 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2190(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop313326 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2180(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop313326 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2180(t5,((C_word*)t0)[3],t4);}}

/* k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4152,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5108,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 731  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[277]))(2,*((C_word*)lf[277]+1),t3);}

/* k5106 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 731  canonicalize-args */
f_4000(((C_word*)t0)[2],t1);}

/* k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4152,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 733  member* */
f_3943(t4,lf[335],((C_word*)t3)[1]);}

/* k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 734  member* */
f_3943(t2,lf[334],((C_word*)((C_word*)t0)[4])[1]);}

/* k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5001,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_i_pairp(t4);
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
if(C_truep(t6)){
/* csi.scm: 739  ##sys#error */
t7=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t3,lf[332]);}
else{
t7=t3;
f_5001(2,t7,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_i_cadr(t1);
t8=(C_word)C_i_string_length(t7);
t9=(C_word)C_i_zerop(t8);
if(C_truep(t9)){
if(C_truep(t9)){
/* csi.scm: 739  ##sys#error */
t10=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t3,lf[332]);}
else{
t10=t3;
f_5001(2,t10,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_i_cadr(t1);
t11=(C_word)C_i_string_ref(t10,C_fix(0));
t12=(C_word)C_eqp(C_make_character(45),t11);
if(C_truep(t12)){
/* csi.scm: 739  ##sys#error */
t13=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t3,lf[332]);}
else{
t13=t3;
f_5001(2,t13,C_SCHEME_UNDEFINED);}}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5091,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5104,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 748  canonicalize-args */
f_4000(t4,((C_word*)t0)[2]);}}

/* k5102 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 748  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[213]+1)))(4,*((C_word*)lf[213]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5089 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_i_member(lf[333],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_4161(t4,(C_truep(t3)?(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k4999 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 740  program-name */
((C_proc3)C_retrieve_symbol_proc(lf[331]))(3,*((C_word*)lf[331]+1),t2,t3);}

/* k5002 in k4999 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* csi.scm: 741  command-line-arguments */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,t3);}

/* k5005 in k5002 in k4999 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 742  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t2,lf[330]);}

/* k5008 in k5005 in k5002 in k4999 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5010,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[329]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 745  lookup-script-file */
((C_proc3)C_retrieve_symbol_proc(lf[35]))(3,*((C_word*)lf[35]+1),t4,t5);}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
f_4161(t5,t4);}}

/* k5017 in k5008 in k5005 in k5002 in k4999 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4161(t3,(C_word)C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_4161(t2,C_SCHEME_FALSE);}}

/* k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4161(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4161,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 751  member* */
f_3943(t2,lf[328],((C_word*)((C_word*)t0)[5])[1]);}

/* k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4167,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_4167(t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4995,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 752  member* */
f_3943(t3,lf[327],((C_word*)((C_word*)t0)[5])[1]);}}

/* k4993 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_4167(t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
f_4167(t3,t2);}}

/* k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4167,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 753  member* */
f_3943(t2,lf[326],((C_word*)((C_word*)t0)[6])[1]);}

/* k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4173,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4173(t3,((C_word*)t0)[5]);}
else{
if(C_truep(t1)){
t3=t1;
t4=t2;
f_4173(t4,t3);}
else{
t3=((C_word*)t0)[2];
t4=t2;
f_4173(t4,t3);}}}

/* k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4173,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4947,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4986,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 755  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t8,lf[325]);}

/* k4984 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csi.scm: 755  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2,lf[323]);}
else{
/* csi.scm: 755  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),((C_word*)t0)[2],lf[324],lf[323]);}}

/* k4945 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4947,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4949(t5,((C_word*)t0)[2],t1);}

/* loop925 in k4945 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4949(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4949,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[30]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g941942 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4976 in loop925 in k4945 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4978,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop925938 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4949(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop925938 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4949(t6,((C_word*)t0)[3],t5);}}

/* k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4176,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4178,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4263,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4333,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t5,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t9=C_set_block_item(lf[322] /* eval-debug-level */,0,C_fix(0));
t10=t8;
f_4333(t10,t9);}
else{
t9=t8;
f_4333(t9,C_SCHEME_UNDEFINED);}}

/* k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4333(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4333,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4936,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 778  member* */
f_3943(t3,lf[321],((C_word*)((C_word*)t0)[6])[1]);}

/* k4934 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4936,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4939,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 779  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_4336(2,t2,C_SCHEME_UNDEFINED);}}

/* k4937 in k4934 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 780  exit */
((C_proc3)C_retrieve_symbol_proc(lf[68]))(3,*((C_word*)lf[68]+1),((C_word*)t0)[2],C_fix(0));}

/* k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4927,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 781  member* */
f_3943(t3,lf[320],((C_word*)((C_word*)t0)[6])[1]);}

/* k4925 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4930,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 782  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_4339(2,t2,C_SCHEME_UNDEFINED);}}

/* k4928 in k4925 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 783  exit */
((C_proc3)C_retrieve_symbol_proc(lf[68]))(3,*((C_word*)lf[68]+1),((C_word*)t0)[2],C_fix(0));}

/* k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[318],((C_word*)((C_word*)t0)[6])[1]))){
t3=C_set_block_item(lf[319] /* setup-mode */,0,C_SCHEME_TRUE);
t4=t2;
f_4342(t4,t3);}
else{
t3=t2;
f_4342(t3,C_SCHEME_UNDEFINED);}}

/* k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4342(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4342,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[317],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4913,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4920,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 787  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[18]))(2,*((C_word*)lf[18]+1),t4);}
else{
t3=t2;
f_4345(2,t3,C_SCHEME_UNDEFINED);}}

/* k4918 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 787  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),((C_word*)t0)[2],t1);}

/* k4911 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 788  exit */
((C_proc3)C_retrieve_symbol_proc(lf[68]))(3,*((C_word*)lf[68]+1),((C_word*)t0)[2],C_fix(0));}

/* k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4900,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 789  member* */
f_3943(t3,lf[316],((C_word*)((C_word*)t0)[6])[1]);}

/* k4898 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4900,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4903,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_set_block_item(lf[314] /* warnings-enabled */,0,C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
f_4348(t4,t3);}
else{
/* csi.scm: 790  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[315]);}}
else{
t2=((C_word*)t0)[3];
f_4348(t2,C_SCHEME_UNDEFINED);}}

/* k4901 in k4898 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[314] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_4348(t3,t2);}

/* k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4348,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4351(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4894,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 793  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),t3,C_SCHEME_TRUE);}}

/* k4892 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 794  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 795  member* */
f_3943(t3,lf[312],((C_word*)((C_word*)t0)[6])[1]);}

/* k4877 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4879,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4882,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5651,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 797  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t3,lf[310]);}
else{
/* csi.scm: 796  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[311]);}}
else{
t2=((C_word*)t0)[3];
f_4354(2,t2,C_SCHEME_UNDEFINED);}}

/* f5651 in k4877 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f5651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 798  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[291]))(3,*((C_word*)lf[291]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4880 in k4877 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4885,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 797  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[307]))(3,*((C_word*)lf[307]+1),t2,lf[310]);}

/* k4883 in k4880 in k4877 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 798  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[291]))(3,*((C_word*)lf[291]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4853,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 799  collect-options */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4178(t4,t3,lf[309]);}

/* k4851 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4855,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4855(t5,((C_word*)t0)[2],t1);}

/* loop1033 in k4851 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4855(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4855,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[307]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4865,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g10401041 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4863 in loop1033 in k4851 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4855(t3,((C_word*)t0)[2],t2);}

/* k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4826,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 800  collect-options */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4178(t4,t3,lf[308]);}

/* k4824 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4826,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4828,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4828(t5,((C_word*)t0)[2],t1);}

/* loop1046 in k4824 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4828(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4828,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[307]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4838,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g10531054 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4836 in loop1046 in k4824 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4828(t3,((C_word*)t0)[2],t2);}

/* k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4736,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4787,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 803  collect-options */
t10=((C_word*)((C_word*)t0)[2])[1];
f_4178(t10,t9,lf[306]);}

/* k4785 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4787,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4789,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4789(t5,((C_word*)t0)[2],t1);}

/* loop1059 in k4785 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4789(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4789,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[30]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4818,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g10751076 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4816 in loop1059 in k4785 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4818,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10591072 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4789(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10591072 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4789(t6,((C_word*)t0)[3],t5);}}

/* k4738 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4740,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4748,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 804  collect-options */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4178(t8,t7,lf[305]);}

/* k4746 in k4738 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4748,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4750(t5,((C_word*)t0)[2],t1);}

/* loop1082 in k4746 in k4738 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4750(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4750,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[30]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g10981099 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4777 in loop1082 in k4746 in k4738 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4779,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10821095 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4750(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10821095 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4750(t6,((C_word*)t0)[3],t5);}}

/* k4742 in k4738 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 803  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[213]+1)))(6,*((C_word*)lf[213]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[118]),((C_word*)t0)[2]);}

/* k4734 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 802  deldups */
((C_proc4)C_retrieve_symbol_proc(lf[238]))(4,*((C_word*)lf[238]+1),((C_word*)t0)[2],t1,*((C_word*)lf[304]+1));}

/* k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[298],t5))){
/* csi.scm: 812  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),t3,lf[299]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[300],t6))){
/* csi.scm: 814  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),t3,lf[290]);}
else{
t7=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[301],t7))){
/* csi.scm: 816  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),t3,lf[302]);}
else{
t8=t3;
f_4367(2,t8,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm: 810  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,lf[303]);}}
else{
t4=t3;
f_4367(2,t4,C_SCHEME_UNDEFINED);}}

/* k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4667,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 817  member* */
f_3943(t3,lf[297],((C_word*)((C_word*)t0)[3])[1]);}

/* k4665 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4667,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 819  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[288]))(3,*((C_word*)lf[288]+1),((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
/* csi.scm: 818  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[296]);}}
else{
t2=((C_word*)t0)[3];
f_4370(2,t2,C_SCHEME_UNDEFINED);}}

/* k4668 in k4665 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 819  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[288]))(3,*((C_word*)lf[288]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 820  member* */
f_3943(t3,lf[295],((C_word*)((C_word*)t0)[3])[1]);}

/* k4653 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4655,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 822  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
/* csi.scm: 821  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[294]);}}
else{
t2=((C_word*)t0)[3];
f_4373(2,t2,C_SCHEME_UNDEFINED);}}

/* k4656 in k4653 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 822  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 823  member* */
f_3943(t3,lf[293],((C_word*)((C_word*)t0)[3])[1]);}

/* k4632 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4634,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4637,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4637(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 824  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[292]);}}
else{
t2=((C_word*)t0)[3];
f_4376(2,t2,C_SCHEME_UNDEFINED);}}

/* k4635 in k4632 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 825  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[291]))(3,*((C_word*)lf[291]+1),t2,C_SCHEME_FALSE);}

/* k4638 in k4635 in k4632 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4643,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 826  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[289]))(3,*((C_word*)lf[289]+1),t2,lf[290]);}

/* k4641 in k4638 in k4635 in k4632 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 827  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[288]))(3,*((C_word*)lf[288]+1),t2,C_SCHEME_FALSE);}

/* k4644 in k4641 in k4638 in k4635 in k4632 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 828  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[287]))(3,*((C_word*)lf[287]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4625,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 829  member* */
f_3943(t3,lf[286],((C_word*)((C_word*)t0)[2])[1]);}

/* k4623 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4625,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_4379(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4230,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 765  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[284]))(4,*((C_word*)lf[284]+1),t3,lf[285],lf[2]);}}

/* k4228 in k4623 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4236,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 766  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k4234 in k4228 in k4623 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4236,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 767  load */
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4242,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4258,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 768  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[283]);}}

/* k4256 in k4234 in k4228 in k4623 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csi.scm: 768  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),((C_word*)t0)[2],t2);}
else{
/* csi.scm: 768  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),((C_word*)t0)[2],lf[282]);}}

/* k4240 in k4234 in k4228 in k4623 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 769  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),t2,t1,lf[281],lf[2]);}

/* k4243 in k4240 in k4234 in k4228 in k4623 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4251,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 770  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k4249 in k4243 in k4240 in k4234 in k4228 in k4623 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 771  load */
((C_proc3)C_retrieve_symbol_proc(lf[81]))(3,*((C_word*)lf[81]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4379(2,t2,C_SCHEME_UNDEFINED);}}

/* k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4379,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4384(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
loop:
a=C_alloc(17);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4384,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4397,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 833  repl */
((C_proc2)C_retrieve_symbol_proc(lf[256]))(2,*((C_word*)lf[256]+1),t4);}}
else{
t4=(C_word)C_i_car(((C_word*)t3)[1]);
t5=(C_word)C_i_member(t4,lf[257]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4409,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=(C_word)C_i_cdr(((C_word*)t3)[1]);
t35=t1;
t36=t7;
t1=t35;
t2=t36;
goto loop;}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t4,lf[258]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[259]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[260]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[261]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[262]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[263]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t7=(C_word)C_i_cdr(((C_word*)t3)[1]);
t8=C_set_block_item(t3,0,t7);
t9=(C_word)C_i_cdr(((C_word*)t3)[1]);
t35=t1;
t36=t9;
t1=t35;
t2=t36;
goto loop;}
else{
t7=(C_word)C_i_string_equal_p(lf[264],t4);
t8=(C_truep(t7)?t7:(C_word)C_i_string_equal_p(lf[265],t4));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4438,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4462,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 840  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[267]+1)))(3,*((C_word*)lf[267]+1),t10,t11);}
else{
t9=(C_word)C_i_string_equal_p(lf[268],t4);
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(lf[269],t4));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4478,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 843  evalstring */
f_4263(t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_i_string_equal_p(lf[270],t4);
t12=(C_truep(t11)?t11:(C_word)C_i_string_equal_p(lf[271],t4));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4498,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_i_cadr(((C_word*)t3)[1]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4508,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 846  evalstring */
f_4263(t13,t14,(C_word)C_a_i_list(&a,1,t15));}
else{
t13=(C_word)C_i_string_equal_p(lf[273],t4);
t14=(C_truep(t13)?t13:(C_word)C_i_string_equal_p(lf[274],t4));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4524,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_i_cadr(((C_word*)t3)[1]);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4534,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 849  evalstring */
f_4263(t15,t16,(C_word)C_a_i_list(&a,1,t17));}
else{
t15=(C_truep(((C_word*)t0)[2])?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4544,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t6,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_equalp(lf[278],t15))){
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4597,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 853  ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[280]))(5,*((C_word*)lf[280]+1),t16,t4,t17,C_SCHEME_FALSE);}
else{
/* csi.scm: 853  ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[280]))(5,*((C_word*)lf[280]+1),t16,t4,C_SCHEME_FALSE,C_SCHEME_FALSE);}}}}}}}}}

/* f_4597 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4597,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4601,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 857  pretty-print */
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t3,t2,*((C_word*)lf[279]+1));}

/* k4599 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 858  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,*((C_word*)lf[279]+1));}

/* k4602 in k4599 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 859  eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4542 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4544,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(lf[275],((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4555,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4565,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 862  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t2,t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4384(t3,((C_word*)t0)[2],t2);}}

/* a4564 in k4542 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4565r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4565r(t0,t1,t2);}}

static void C_ccall f_4565r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
if(C_truep((C_word)C_fixnump(t3))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
/* csi.scm: 864  exit */
((C_proc3)C_retrieve_symbol_proc(lf[68]))(3,*((C_word*)lf[68]+1),t1,t4);}
else{
/* csi.scm: 864  exit */
((C_proc3)C_retrieve_symbol_proc(lf[68]))(3,*((C_word*)lf[68]+1),t1,C_fix(0));}}
else{
/* csi.scm: 864  exit */
((C_proc3)C_retrieve_symbol_proc(lf[68]))(3,*((C_word*)lf[68]+1),t1,C_fix(0));}}

/* a4554 in k4542 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4555,2,t0,t1);}
t2=C_retrieve(lf[276]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4563,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 862  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[277]))(2,*((C_word*)lf[277]+1),t3);}

/* k4561 in a4554 in k4542 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g12131214 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* a4533 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4534r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4534r(t0,t1,t2);}}

static void C_ccall f_4534r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[272]+1),C_retrieve(lf[64]),t2);}

/* k4522 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_4384(t5,((C_word*)t0)[2],t4);}

/* a4507 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_4508r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4508r(t0,t1,t2);}}

static void C_ccall f_4508r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[272]+1),*((C_word*)lf[15]+1),t2);}

/* k4496 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_4384(t5,((C_word*)t0)[2],t4);}

/* k4476 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_4384(t5,((C_word*)t0)[2],t4);}

/* k4460 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[266],t4);
/* csi.scm: 840  eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[2],t5);}

/* k4436 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_4384(t5,((C_word*)t0)[2],t4);}

/* k4407 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4384(t3,((C_word*)t0)[2],t2);}

/* k4395 in doloop1136 in k4377 in k4374 in k4371 in k4368 in k4365 in k4362 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in k4340 in k4337 in k4334 in k4331 in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 834  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[110]+1));}

/* evalstring in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4263(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4263,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4267,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4267(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4310,tmp=(C_word)a,a+=2,tmp));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4267(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_4310 in evalstring in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k4265 in evalstring in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4270,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 773  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t2,((C_word*)t0)[2]);}

/* k4268 in k4265 in evalstring in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 774  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,t1);}

/* k4275 in k4268 in k4265 in evalstring in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4277,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4279(t5,((C_word*)t0)[2],t1);}

/* doloop997 in k4275 in k4268 in k4265 in evalstring in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4279(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4279,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4300,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4302,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[254]+1));}}

/* a4301 in doloop997 in k4275 in k4268 in k4265 in evalstring in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4302,2,t0,t1);}
/* csi.scm: 776  eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t1,((C_word*)t0)[2]);}

/* k4298 in doloop997 in k4275 in k4268 in k4265 in evalstring in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 776  rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4287 in doloop997 in k4275 in k4268 in k4265 in evalstring in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 774  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,((C_word*)t0)[2]);}

/* k4294 in k4287 in doloop997 in k4275 in k4268 in k4265 in evalstring in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4279(t2,((C_word*)t0)[2],t1);}

/* collect-options in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4178(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4178,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4184,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4184(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4184(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4184,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* g967968 */
t5=t4;
f_4192(t5,t1,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* g967 in loop in collect-options in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4192(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4192,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
/* csi.scm: 761  ##sys#error */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[253],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4213,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cddr(t2);
/* csi.scm: 762  loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_4184(t7,t5,t6);}}

/* k4211 in g967 in loop in collect-options in k4174 in k4171 in k4168 in k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in ##csi#run in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4213,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4000(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4000,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4006,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4006(t6,t1,t2);}

/* loop in canonicalize-args in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4006(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4006,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[242]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[243]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[244]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[245]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[246]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4028,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t6=(C_word)C_eqp(C_make_character(45),(C_word)C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=(C_word)C_i_member(t3,lf[251]);
t8=t4;
f_4028(t8,(C_word)C_i_not(t7));}
else{
t7=t4;
f_4028(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_4028(t6,C_SCHEME_FALSE);}}}}

/* k4026 in loop in canonicalize-args in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_4028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4028,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(C_make_character(58),(C_word)C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 707  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4006(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4044,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4078,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 708  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[29]+1)))(4,*((C_word*)lf[29]+1),t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 712  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4006(t4,t2,t3);}}

/* k4083 in k4026 in loop in canonicalize-args in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4085,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4076 in k4026 in loop in canonicalize-args in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[250]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4042 in k4026 in loop in canonicalize-args in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4044,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4117,tmp=(C_word)a,a+=2,tmp);
t4=f_4117(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4067,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[248]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm: 711  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[249],((C_word*)t0)[2]);}}

/* a4066 in k4042 in k4026 in loop in canonicalize-args in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4067,3,t0,t1,t2);}
t3=*((C_word*)lf[247]+1);
/* g821822 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(45),t2);}

/* k4055 in k4042 in k4026 in loop in canonicalize-args in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4061,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 710  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4006(t4,t2,t3);}

/* k4059 in k4055 in k4042 in k4026 in loop in canonicalize-args in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 710  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[213]+1)))(4,*((C_word*)lf[213]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4042 in k4026 in loop in canonicalize-args in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static C_word C_fcall f_4117(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3943(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3943,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3949,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3949(t7,t1,t3);}

/* loop in member* in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3949(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3949,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3961,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3961(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3961(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3961,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 683  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3949(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_i_cdr(t2);
/* csi.scm: 685  find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3884r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3884r(t0,t1,t2,t3);}}

static void C_ccall f_3884r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3888,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3888(2,t5,*((C_word*)lf[239]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3888(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3886 in ##csi#deldups in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3888,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3893,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3893(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k3886 in ##csi#deldups in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3893(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3893,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3909,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3922,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 676  del */
((C_proc5)C_retrieve_symbol_proc(lf[237]))(5,*((C_word*)lf[237]+1),t6,t3,t4,((C_word*)t0)[2]);}}

/* k3920 in recur in k3886 in ##csi#deldups in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 676  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3893(t2,((C_word*)t0)[2],t1);}

/* k3907 in recur in k3886 in ##csi#deldups in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#del in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3846,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3852,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3852(t8,t1,t3);}

/* loop in ##csi#del in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3852(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3852,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 666  tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k3866 in loop in ##csi#del in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 668  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3852(t4,t2,t3);}}

/* k3876 in k3866 in loop in ##csi#del in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3878,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3637,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3640,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3669,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3669(t10,t1,C_fix(0));}

/* doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3669(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3669,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3844,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 635  justify */
t5=((C_word*)t0)[2];
f_3640(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k3842 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 635  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 636  write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[8]);}

/* k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3754(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* doloop686 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3754(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3754,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3773,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 641  fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[236]+1)))(4,*((C_word*)lf[236]+1),t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 646  write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k3813 in doloop686 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3818,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3833,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3837,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 647  ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k3835 in k3813 in doloop686 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 647  justify */
t2=((C_word*)t0)[3];
f_3640(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k3831 in k3813 in doloop686 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 647  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3816 in k3813 in doloop686 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3754(t4,((C_word*)t0)[2],t2,t3);}

/* k3771 in doloop686 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3773,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3791(t7,((C_word*)t0)[4],t3);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* doloop701 in k3771 in doloop686 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3791(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3791,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3801,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 645  display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[235],((C_word*)t0)[2]);}}

/* k3799 in doloop701 in k3771 in doloop686 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3791(t3,((C_word*)t0)[2],t2);}

/* k3683 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 648  write-char */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[6]);}

/* k3686 in k3683 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3691,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3703(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* doloop711 in k3686 in k3683 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3703(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3703,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3716,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 652  ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k3714 in doloop711 in k3686 in k3683 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3719,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_make_character((C_word)C_unfix(t1));
/* csi.scm: 654  write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm: 655  write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k3717 in k3714 in doloop711 in k3686 in k3683 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3703(t4,((C_word*)t0)[2],t2,t3);}

/* k3689 in k3686 in k3683 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 656  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t2,C_make_character(10),((C_word*)t0)[2]);}

/* k3692 in k3689 in k3686 in k3683 in k3680 in k3677 in doloop673 in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3669(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3640(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3640,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3644,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 627  number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k3642 in justify in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3644,2,t0,t1);}
t2=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3660,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm: 630  make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=t1;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3658 in k3642 in justify in ##csi#hexdump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 630  string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3476r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3476r(t0,t1,t2,t3);}}

static void C_ccall f_3476r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3478,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3584,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3589,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-len635660 */
t7=t6;
f_3589(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-out636658 */
t9=t5;
f_3584(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body633641 */
t11=t4;
f_3478(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len635 in ##csi#dump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3589,NULL,2,t0,t1);}
/* def-out636658 */
t2=((C_word*)t0)[2];
f_3584(t2,t1,C_SCHEME_FALSE);}

/* def-out636 in ##csi#dump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3584,NULL,3,t0,t1,t2);}
/* body633641 */
t3=((C_word*)t0)[2];
f_3478(t3,t1,t2,*((C_word*)lf[110]+1));}

/* body633 in ##csi#dump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3478(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3478,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3481,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_immp(((C_word*)t0)[2]))){
/* csi.scm: 609  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[230],lf[231],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3503,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 610  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[219]+1)))(3,*((C_word*)lf[219]+1),t5,((C_word*)t0)[2]);}}

/* k3501 in body633 in ##csi#dump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3503,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 610  bestlen */
t4=((C_word*)t0)[2];
f_3481(t4,t2,t3);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 611  bestlen */
t4=((C_word*)t0)[2];
f_3481(t4,t2,t3);}
else{
t2=(C_word)C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_anypointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm: 613  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[194]))(6,*((C_word*)lf[194]+1),((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[232]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_3546(t6,(C_word)C_i_assq(t5,C_retrieve2(lf[133],"bytevector-data")));}
else{
t5=t4;
f_3546(t5,C_SCHEME_FALSE);}}}}}

/* k3544 in k3501 in body633 in ##csi#dump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3546,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 616  bestlen */
t5=((C_word*)t0)[2];
f_3481(t5,t3,t4);}
else{
/* csi.scm: 617  ##sys#error */
t2=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[230],lf[233],((C_word*)t0)[5]);}}

/* k3554 in k3544 in k3501 in body633 in ##csi#dump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 616  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[194]))(6,*((C_word*)lf[194]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[195]+1),((C_word*)t0)[2]);}

/* k3525 in k3501 in body633 in ##csi#dump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 611  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[194]))(6,*((C_word*)lf[194]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[195]+1),((C_word*)t0)[2]);}

/* k3508 in k3501 in body633 in ##csi#dump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 610  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[194]))(6,*((C_word*)lf[194]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[195]+1),((C_word*)t0)[2]);}

/* bestlen in body633 in ##csi#dump in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3481(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3481,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 608  min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[229]+1)))(4,*((C_word*)lf[229]+1),t1,((C_word*)t0)[2],t2);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* set-describer! in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3467,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3471,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 597  ##sys#check-symbol */
((C_proc5)C_retrieve_proc(*((C_word*)lf[227]+1)))(5,*((C_word*)lf[227]+1),t4,t2,lf[228],lf[226]);}

/* k3469 in set-describer! in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 598  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[4],C_retrieve2(lf[135],"describer-table"),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_2586r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2586r(t0,t1,t2,t3);}}

static void C_ccall f_2586r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2590(2,t5,*((C_word*)lf[110]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2590(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[7]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3446,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 484  ##sys#block-address */
((C_proc3)C_retrieve_symbol_proc(lf[225]))(3,*((C_word*)lf[225]+1),t4,((C_word*)t0)[7]);}
else{
t4=t3;
f_2718(2,t4,C_SCHEME_UNDEFINED);}}

/* k3444 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 484  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[224],t1);}

/* k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[9]));
/* csi.scm: 487  fprintf */
t4=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[7],lf[146],((C_word*)t0)[9],t3,t3,t3);}
else{
switch(((C_word*)t0)[9]){
case C_SCHEME_TRUE:
/* csi.scm: 488  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[147]);
case C_SCHEME_FALSE:
/* csi.scm: 489  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[148]);
default:
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[9]))){
/* csi.scm: 490  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[149]);}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[9]))){
/* csi.scm: 491  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[150]);}
else{
t3=C_retrieve(lf[46]);
t4=(C_word)C_eqp(t3,((C_word*)t0)[9]);
if(C_truep(t4)){
/* csi.scm: 492  fprintf */
t5=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],lf[151]);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2787,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 494  fprintf */
t6=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[7],lf[153],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9]);}
else{
t5=(C_word)C_slot(lf[154],C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[9],t5);
if(C_truep(t6)){
/* csi.scm: 499  fprintf */
t7=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[7],lf[155]);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=t2,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 500  ##sys#number? */
((C_proc3)C_retrieve_symbol_proc(lf[223]))(3,*((C_word*)lf[223]+1),t7,((C_word*)t0)[9]);}}}}}}}}

/* k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2817,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 500  fprintf */
t2=((C_word*)t0)[11];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[10],((C_word*)t0)[9],lf[156],((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[8]))){
/* csi.scm: 501  descseq */
t2=((C_word*)t0)[7];
f_2592(6,t2,((C_word*)t0)[10],lf[157],*((C_word*)lf[158]+1),((C_word*)t0)[6],C_fix(0));}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[8]))){
/* csi.scm: 502  descseq */
t2=((C_word*)t0)[7];
f_2592(6,t2,((C_word*)t0)[10],lf[159],*((C_word*)lf[158]+1),*((C_word*)lf[160]+1),C_fix(0));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2941,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 504  ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),t3,((C_word*)t0)[8]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
/* csi.scm: 521  descseq */
t2=((C_word*)t0)[7];
f_2592(6,t2,((C_word*)t0)[10],lf[172],((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[8]))){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* csi.scm: 522  fprintf */
t4=((C_word*)t0)[11];
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[10],((C_word*)t0)[9],lf[173],t2,t3);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[8]))){
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
if(C_truep((C_word)C_i_memq(lf[177],*((C_word*)lf[6]+1)))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[8],t4);
t6=t3;
f_2985(t6,(C_word)C_eqp(C_retrieve(lf[178]),t5));}
else{
t4=t3;
f_2985(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2985(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 532  port? */
((C_proc3)C_retrieve_symbol_proc(lf[222]))(3,*((C_word*)lf[222]+1),t2,((C_word*)t0)[8]);}}}}}}}}

/* k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3025,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_truep(t2)?lf[179]:lf[180]);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(7));
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3044,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 538  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),t6,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(lf[177],*((C_word*)lf[6]+1)))){
/* csi.scm: 539  instance? */
((C_proc3)C_retrieve_symbol_proc(lf[221]))(3,*((C_word*)lf[221]+1),t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_3053(2,t3,C_SCHEME_FALSE);}}}

/* k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3053,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 540  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 541  ##sys#locative? */
((C_proc3)C_retrieve_symbol_proc(lf[220]))(3,*((C_word*)lf[220]+1),t2,((C_word*)t0)[5]);}}

/* k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3062,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 543  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 556  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 557  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[219]+1)))(3,*((C_word*)lf[219]+1),t2,((C_word*)t0)[6]);}}}

/* k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3156,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 559  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],lf[196],t2);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 562  ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[198]))(3,*((C_word*)lf[198]+1),t2,((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[199]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3187,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[203]:lf[204]);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* csi.scm: 565  fprintf */
t7=((C_word*)t0)[3];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[4],lf[205],t2,t5,t6);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[206]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* csi.scm: 572  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[211],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3312,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[216]))){
/* csi.scm: 582  provided? */
((C_proc3)C_retrieve_symbol_proc(lf[217]))(3,*((C_word*)lf[217]+1),t2,lf[218]);}
else{
t3=t2;
f_3312(2,t3,C_SCHEME_FALSE);}}}}}}

/* k3310 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3312,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 583  unveil */
((C_proc4)C_retrieve_symbol_proc(lf[212]))(4,*((C_word*)lf[212]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 586  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[100]))(4,*((C_word*)lf[100]+1),t3,C_retrieve2(lf[135],"describer-table"),t2);}
else{
/* csi.scm: 593  fprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],lf[215]);}}}

/* k3325 in k3310 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* g580581 */
t3=t2;
f_3331(t3,((C_word*)t0)[5],t1);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve2(lf[133],"bytevector-data"));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3345,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* g592593 */
t4=t3;
f_3345(t4,((C_word*)t0)[5],t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3406,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
/* csi.scm: 591  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],lf[214],t4);}}}

/* k3404 in k3325 in k3310 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 592  descseq */
t2=((C_word*)t0)[3];
f_2592(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[158]+1),*((C_word*)lf[160]+1),C_fix(1));}

/* g592 in k3325 in k3310 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3345(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3345,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3353,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3357,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cdr(t2);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3367,a[2]=t5,a[3]=t11,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_3367(t13,t8,t9);}

/* loop597 in g592 in k3325 in k3310 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3367(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3367,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[57]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3396,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g613614 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3394 in loop597 in g592 in k3325 in k3310 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3396,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop597610 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3367(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop597610 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3367(t6,((C_word*)t0)[3],t5);}}

/* k3355 in g592 in k3325 in k3310 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3357,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_fix(0));
/* csi.scm: 589  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[213]+1)))(4,*((C_word*)lf[213]+1),((C_word*)t0)[2],t1,t2);}

/* k3351 in g592 in k3325 in k3310 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g580 in k3325 in k3310 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3331(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3331,NULL,3,t0,t1,t2);}
/* g589590 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3221 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3223,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3232,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3232(t6,((C_word*)t0)[2],t2);}

/* loop547 in k3221 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3232(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3232,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3291,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g554555 */
t6=t3;
f_3240(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3289 in loop547 in k3221 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3232(t3,((C_word*)t0)[2],t2);}

/* g554 in loop547 in k3221 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3240(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3240,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3244,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 575  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[210],t2);}

/* k3242 in g554 in loop547 in k3221 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3253(t6,((C_word*)t0)[2],t2);}

/* loop in k3242 in g554 in loop547 in k3221 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3253,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3263,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3288,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 578  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[209]+1)))(3,*((C_word*)lf[209]+1),t4,t2);}}

/* k3286 in loop in k3242 in g554 in loop547 in k3221 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3288,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[8],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3280,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 579  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[208]+1)))(3,*((C_word*)lf[208]+1),t3,((C_word*)t0)[7]);}
else{
t3=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* csi.scm: 580  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3253(t4,((C_word*)t0)[2],t3);}}

/* k3278 in k3286 in loop in k3242 in g554 in loop547 in k3221 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* csi.scm: 579  fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[207],t1,t2);}

/* k3261 in loop in k3242 in g554 in loop547 in k3221 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* csi.scm: 580  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3253(t3,((C_word*)t0)[2],t2);}

/* k3185 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm: 567  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[202],t3);}

/* k3188 in k3185 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3195,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 568  hash-table-walk */
((C_proc4)C_retrieve_symbol_proc(lf[201]))(4,*((C_word*)lf[201]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3194 in k3188 in k3185 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3195,4,t0,t1,t2,t3);}
/* csi.scm: 570  fprintf */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],lf[200],t2,t3);}

/* k3173 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 562  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[197],t1);}

/* k3160 in k3154 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 560  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[194]))(6,*((C_word*)lf[194]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[195]+1),((C_word*)t0)[2]);}

/* k3148 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 556  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[193],t1);}

/* k3067 in k3060 in k3051 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
switch(t3){
case C_fix(0):
/* csi.scm: 542  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,t2,lf[183]);
case C_fix(1):
/* csi.scm: 542  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,t2,lf[184]);
case C_fix(2):
/* csi.scm: 542  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,t2,lf[185]);
case C_fix(3):
/* csi.scm: 542  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,t2,lf[186]);
case C_fix(4):
/* csi.scm: 542  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,t2,lf[187]);
case C_fix(5):
/* csi.scm: 542  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,t2,lf[188]);
case C_fix(6):
/* csi.scm: 542  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,t2,lf[189]);
case C_fix(7):
/* csi.scm: 542  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,t2,lf[190]);
case C_fix(8):
/* csi.scm: 542  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,t2,lf[191]);
case C_fix(9):
/* csi.scm: 542  fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,t2,lf[192]);
default:
t4=C_SCHEME_UNDEFINED;
/* csi.scm: 542  fprintf */
t5=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,t2,t4);}}

/* k3042 in k3023 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 533  fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[181],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2983 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2985,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 528  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2999,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 530  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),t3,((C_word*)t0)[5],C_fix(0));}}

/* k2997 in k2983 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 530  sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[175],t1);}

/* k2993 in k2983 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 529  descseq */
t2=((C_word*)t0)[3];
f_2592(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[158]+1),*((C_word*)lf[160]+1),C_fix(1));}

/* k2939 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2847(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 504  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[170],((C_word*)t0)[2]);}}

/* k2845 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_subbyte(t3,C_fix(0));
t5=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* csi.scm: 506  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),t2,lf[169],((C_word*)t0)[4]);}
else{
t6=t2;
f_2850(2,t6,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2850(2,t3,C_SCHEME_UNDEFINED);}}

/* k2848 in k2845 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2918,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 508  ##sys#interned-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[168]))(3,*((C_word*)lf[168]+1),t3,((C_word*)t0)[6]);}

/* k2916 in k2848 in k2845 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2918,2,t0,t1);}
t2=(C_truep(t1)?lf[164]:lf[165]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2915,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 509  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[167]))(3,*((C_word*)lf[167]+1),t3,((C_word*)t0)[2]);}

/* k2913 in k2916 in k2848 in k2845 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 507  fprintf */
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[166],((C_word*)t0)[2],t1);}

/* k2851 in k2848 in k2845 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2853,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[46]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2865,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 512  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),t3,lf[163],((C_word*)t0)[4]);}}

/* k2863 in k2851 in k2848 in k2845 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2865,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2870,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2870(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop513 in k2863 in k2851 in k2848 in k2845 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2870(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2870,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2880,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* csi.scm: 515  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[3],lf[162],t4);}}

/* k2878 in doloop513 in k2863 in k2851 in k2848 in k2845 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 516  ##sys#with-print-length-limit */
((C_proc4)C_retrieve_symbol_proc(lf[161]))(4,*((C_word*)lf[161]+1),t2,C_fix(1000),t3);}

/* a2894 in k2878 in doloop513 in k2863 in k2851 in k2848 in k2845 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2895,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 519  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),t1,t2,((C_word*)t0)[2]);}

/* k2881 in k2878 in doloop513 in k2863 in k2851 in k2848 in k2845 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 520  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,((C_word*)t0)[2]);}

/* k2884 in k2881 in k2878 in doloop513 in k2863 in k2851 in k2848 in k2845 in k2815 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2870(t3,((C_word*)t0)[2],t2);}

/* k2785 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2787,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[5],C_fix(65536)))){
/* csi.scm: 496  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[152],t2);}
else{
/* csi.scm: 497  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[4],C_make_character(10),*((C_word*)lf[110]+1));}}

/* k2791 in k2785 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 497  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[110]+1));}

/* k2719 in k2716 in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* descseq in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2592,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2715,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 464  plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2713 in descseq in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2715,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 465  fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[145],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_2599(2,t4,C_SCHEME_UNDEFINED);}}

/* k2597 in k2713 in descseq in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2599,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_2604(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k2597 in k2713 in descseq in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2604(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2604,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm: 469  fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[140],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2627,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm: 471  pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k2625 in loop1 in k2597 in k2713 in descseq in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2627,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_2636(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k2625 in loop1 in k2597 in k2713 in descseq in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2636(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2636,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 474  fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[144],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 481  pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2698 in loop2 in k2625 in loop1 in k2597 in k2713 in descseq in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm: 481  loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2636(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm: 482  loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2636(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k2644 in loop2 in k2625 in loop1 in k2597 in k2713 in descseq in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2649,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(2));
if(C_truep(t4)){
/* csi.scm: 476  fprintf */
t5=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[2],lf[141],t3,lf[142]);}
else{
/* csi.scm: 476  fprintf */
t5=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[2],lf[141],t3,lf[143]);}}
else{
/* csi.scm: 479  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,((C_word*)t0)[2]);}}

/* k2647 in k2644 in loop2 in k2625 in loop1 in k2597 in k2713 in descseq in k2588 in ##csi#describe in k2582 in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm: 480  loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2604(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2307r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2307r(t0,t1,t2);}}

static void C_ccall f_2307r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2315,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_2315(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* csi.scm: 389  current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2317,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 389  with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 391  gc */
((C_proc2)C_retrieve_symbol_proc(lf[132]))(2,*((C_word*)lf[132]+1),t2);}

/* k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 392  ##sys#symbol-table-info */
((C_proc2)C_retrieve_symbol_proc(lf[131]))(2,*((C_word*)lf[131]+1),t2);}

/* k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 393  memory-statistics */
((C_proc2)C_retrieve_symbol_proc(lf[130]))(2,*((C_word*)lf[130]+1),t2);}

/* k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2329,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 395  printf */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[129]);}

/* k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2347,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2452,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2531,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2535,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2537,a[2]=t6,a[3]=t11,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_2537(t13,t9,*((C_word*)lf[6]+1));}

/* loop402 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2537(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2537,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[128]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g418419 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2564 in loop402 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop402415 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2537(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop402415 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2537(t6,((C_word*)t0)[3],t5);}}

/* k2533 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 403  sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[127]+1));}

/* k2529 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 403  chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k2450 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2454,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2454(t5,((C_word*)t0)[2],t1);}

/* loop373 in k2450 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2454,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2462,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2516,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g380381 */
t6=t3;
f_2462(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2514 in loop373 in k2450 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2454(t3,((C_word*)t0)[2],t2);}

/* g380 in loop373 in k2450 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2462(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2462,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2466,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 398  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t3,lf[126]);}

/* k2464 in g380 in loop373 in k2450 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2466,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2471,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2471(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop385 in k2464 in g380 in loop373 in k2450 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2471(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2471,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2502,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g392393 */
t6=t3;
f_2479(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2500 in loop385 in k2464 in g380 in loop373 in k2450 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2471(t3,((C_word*)t0)[2],t2);}

/* g392 in loop385 in k2464 in g380 in loop373 in k2450 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2479(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2479,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2487,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* csi.scm: 401  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[125]+1)))(4,*((C_word*)lf[125]+1),t3,t6,C_make_character(32));}

/* k2485 in g392 in loop385 in k2464 in g380 in loop373 in k2450 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 401  printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[124],((C_word*)t0)[2],t1);}

/* k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2350,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 417  machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t3);}

/* k2373 in k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[111]:lf[112]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 419  software-type */
((C_proc2)C_retrieve_symbol_proc(lf[122]))(2,*((C_word*)lf[122]+1),t4);}

/* k2381 in k2373 in k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 420  software-version */
((C_proc2)C_retrieve_symbol_proc(lf[121]))(2,*((C_word*)lf[121]+1),t2);}

/* k2385 in k2381 in k2373 in k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 421  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[120]))(2,*((C_word*)lf[120]+1),t2);}

/* k2389 in k2385 in k2381 in k2373 in k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* csi.scm: 423  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[119]))(2,*((C_word*)lf[119]+1),t2);}

/* k2393 in k2389 in k2385 in k2381 in k2373 in k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2399,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[12],C_fix(0));
/* csi.scm: 425  shorten */
f_2329(t2,t3);}

/* k2397 in k2393 in k2389 in k2385 in k2381 in k2373 in k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2403,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[13],C_fix(1));
/* csi.scm: 426  shorten */
f_2329(t2,t3);}

/* k2401 in k2397 in k2393 in k2389 in k2385 in k2381 in k2373 in k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[13],C_fix(2));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[12],C_fix(0));
t4=(C_word)C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[113]:lf[114]);
t6=(C_word)C_i_vector_ref(((C_word*)t0)[12],C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[12],C_fix(2));
t8=(C_word)C_fudge(C_fix(18));
t9=(C_word)C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[115]:lf[116]);
/* csi.scm: 404  printf */
t11=((C_word*)t0)[11];
((C_proc19)C_retrieve_proc(t11))(19,t11,((C_word*)t0)[10],lf[117],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_retrieve(lf[118]),((C_word*)t0)[2],t1,t2,t3,t5,t6,t7,t10);}

/* k2348 in k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 433  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t2,C_make_character(10),*((C_word*)lf[110]+1));}

/* k2351 in k2348 in k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(14)))){
/* csi.scm: 434  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[108]);}
else{
t3=t2;
f_2356(2,t3,C_SCHEME_UNDEFINED);}}

/* k2354 in k2351 in k2348 in k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(15)))){
/* csi.scm: 435  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[107]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2357 in k2354 in k2351 in k2348 in k2345 in k2342 in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_2329(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2329,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2337,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm: 394  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[106]+1)))(3,*((C_word*)lf[106]+1),t3,t4);}

/* k2335 in shorten in k2325 in k2322 in k2319 in a2316 in k2313 in ##csi#report in k2304 in k2301 in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_divide(&a,2,t1,C_fix(100)));}

/* ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1766,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 267  exit */
((C_proc2)C_retrieve_symbol_proc(lf[68]))(2,*((C_word*)lf[68]+1),t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1782(t5,(C_word)C_eqp(lf[101],t4));}
else{
t4=t3;
f_1782(t4,C_SCHEME_FALSE);}}}

/* k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_1782(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1782,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* csi.scm: 271  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[100]))(4,*((C_word*)lf[100]+1),t3,C_retrieve2(lf[54],"command-table"),t2);}
else{
t4=t3;
f_1788(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2125,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2131,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[12],t2,t3);}}

/* a2130 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2131r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2131r(t0,t1,t2);}}

static void C_ccall f_2131r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2135,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 354  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,t2);}

/* k2133 in a2130 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2124 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
/* csi.scm: 353  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[14];
t3=t1;
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1799,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g213214 */
t6=t4;
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[13],lf[69]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1814,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 278  read */
t4=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[71]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 282  read */
t5=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[13],lf[72]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 287  read */
t6=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[13],lf[74]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 291  read */
t7=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[13],lf[76]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 295  read */
t8=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[13],lf[77]);
if(C_truep(t7)){
/* csi.scm: 300  report */
((C_proc2)C_retrieve_symbol_proc(lf[78]))(2,*((C_word*)lf[78]+1),((C_word*)t0)[14]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[13],lf[79]);
if(C_truep(t8)){
/* csi.scm: 301  exit */
((C_proc2)C_retrieve_symbol_proc(lf[68]))(2,*((C_word*)lf[68]+1),((C_word*)t0)[14]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[13],lf[80]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1924,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1957,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 303  read-line */
t12=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[13],lf[82]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1991,a[2]=t11,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 307  read-line */
t13=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[13],lf[87]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 311  read */
t13=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[13],lf[91]);
if(C_truep(t12)){
if(C_truep(C_retrieve(lf[92]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_a_i_list(&a,1,C_retrieve(lf[92]));
/* csi.scm: 317  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t13,t14);}
else{
t13=C_SCHEME_UNDEFINED;
t14=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}}
else{
t13=(C_word)C_eqp(((C_word*)t0)[13],lf[93]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 320  read-line */
t15=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t15))(2,t15,t14);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[13],lf[95]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2087,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 325  display */
t16=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,lf[98]);}
else{
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 350  printf */
t16=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t16))(4,t16,t15,lf[99],((C_word*)t0)[2]);}}}}}}}}}}}}}}}

/* k2109 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2085 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2095,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 341  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[97]))(4,*((C_word*)lf[97]+1),t2,t3,C_retrieve2(lf[54],"command-table"));}

/* a2094 in k2085 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2095,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm: 345  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t1,C_make_character(32),t4);}
else{
/* csi.scm: 346  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t1,lf[96],t2);}}

/* k2088 in k2085 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2066 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 321  system */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),t2,t1);}

/* k2069 in k2066 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2074,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* csi.scm: 322  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t2,t3);}

/* k2072 in k2069 in k2066 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2050 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 318  describe */
((C_proc3)C_retrieve_symbol_proc(lf[73]))(3,*((C_word*)lf[73]+1),((C_word*)t0)[2],C_retrieve(lf[92]));}

/* k1998 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2005,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2032 in k1998 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2033r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2033r(t0,t1,t2);}}

static void C_ccall f_2033r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2037,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 313  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,t2);}

/* k2035 in a2032 in k1998 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2004 in k1998 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2009,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2007 in a2004 in k1998 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2020,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2019 in k2007 in a2004 in k1998 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2020r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2020r(t0,t1,t2);}}

static void C_ccall f_2020r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2024,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2031,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[89]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2029 in a2019 in k2007 in a2004 in k1998 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[88]))(3,*((C_word*)lf[88]+1),((C_word*)t0)[2],t1);}

/* k2022 in a2019 in k2007 in a2004 in k1998 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2013 in k2007 in a2004 in k1998 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
/* csi.scm: 312  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1989 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 307  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1964 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1969,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a1973 in k1964 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1974,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* g273274 */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,lf[85],t3);}

/* a1979 in a1973 in k1964 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1980,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1984,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 308  pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1982 in a1979 in a1973 in k1964 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 308  print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),((C_word*)t0)[2],lf[84]);}

/* k1967 in k1964 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k1955 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 303  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1922 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1932,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1932(t6,t2,t1);}

/* loop241 in k1922 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_1932(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1932,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[81]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1942,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g248249 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1940 in loop241 in k1922 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1932(t3,((C_word*)t0)[2],t2);}

/* k1925 in k1922 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k1883 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1888,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 296  read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1886 in k1883 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1891,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 297  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1889 in k1886 in k1883 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 298  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1892 in k1889 in k1886 in k1883 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 299  dump */
((C_proc4)C_retrieve_symbol_proc(lf[75]))(4,*((C_word*)lf[75]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1868 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 292  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1871 in k1868 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 293  dump */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),((C_word*)t0)[2],t1);}

/* k1853 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 288  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1856 in k1853 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 289  describe */
((C_proc3)C_retrieve_symbol_proc(lf[73]))(3,*((C_word*)lf[73]+1),((C_word*)t0)[2],t1);}

/* k1835 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 283  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1838 in k1835 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 284  pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1841 in k1838 in k1835 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k1812 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1824,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1828,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 279  expand */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k1826 in k1812 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 279  ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],t1);}

/* k1822 in k1812 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 279  pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1815 in k1812 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k1797 in k1786 in k1780 in ##sys#repl-eval-hook in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* toplevel-command in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1725r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1725r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1725r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1729,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1729(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1729(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1727 in toplevel-command in k1721 in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[4],lf[55]);
t3=(C_truep(t1)?(C_word)C_i_check_string_2(t1,lf[55]):C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* csi.scm: 250  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[2],C_retrieve2(lf[54],"command-table"),((C_word*)t0)[4],t4);}

/* ##sys#read-prompt-hook in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1716,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fudge(C_fix(12));
if(C_truep(t3)){
if(C_truep(t3)){
/* csi.scm: 243  old */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
/* csi.scm: 236  ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t2,*((C_word*)lf[51]+1));}}

/* k1714 in ##sys#read-prompt-hook in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 243  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##csi#tty-input? in k1692 in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm: 236  ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t1,*((C_word*)lf[51]+1));}}

/* ##csi#history-ref in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1669,3,t0,t1,t2);}
t3=(C_word)C_i_inexact_to_exact(t2);
t4=(C_word)C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(t3,C_retrieve(lf[25])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_ref(C_retrieve(lf[43]),t3));}
else{
/* csi.scm: 228  ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[48],t2);}}

/* ##csi#history-add in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1630,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[46]):(C_word)C_slot(t2,C_fix(0)));
t5=(C_word)C_block_size(C_retrieve(lf[43]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1640,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_retrieve(lf[25]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1654,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_times(C_fix(2),t5);
/* csi.scm: 219  vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[43]),t8);}
else{
t7=t6;
f_1640(t7,C_SCHEME_UNDEFINED);}}

/* k1652 in ##csi#history-add in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[43]+1 /* (set! history-list ...) */,t1);
t3=((C_word*)t0)[2];
f_1640(t3,t2);}

/* k1638 in ##csi#history-add in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_1640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_vector_set(C_retrieve(lf[43]),C_retrieve(lf[25]),((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(C_retrieve(lf[25]),C_fix(1));
t4=C_mutate((C_word*)lf[25]+1 /* (set! history-count ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1524,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 192  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[42]);}

/* k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1528,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=(C_word)C_eqp(t3,C_make_character(92));
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,C_make_character(47)));
if(C_truep(t5)){
/* csi.scm: 194  addext */
f_1476(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t6=C_retrieve2(lf[28],"dirseparator\077");
t7=((C_word*)t0)[5];
t8=(C_word)C_block_size(t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1503,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=f_1503(t9,C_fix(0));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1552,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t12=((C_word*)t0)[2];
t13=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t14=(C_truep(t12)?(C_word)C_i_foreign_block_argumentp(t12):C_SCHEME_FALSE);
t15=(C_word)C_i_foreign_fixnum_argumentp(C_fix(256));
t16=(C_word)stub75(t13,t14,t15);
/* ##sys#peek-nonnull-c-string */
t17=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t11,t16,C_fix(0));}
else{
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 198  addext */
f_1476(t11,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1567 in k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1569,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 200  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t2,lf[40],((C_word*)t0)[2]);}}

/* k1573 in k1567 in k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 201  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2],lf[39]);}

/* k1580 in k1573 in k1567 in k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1584(t5,((C_word*)t0)[2],t1);}

/* loop in k1580 in k1573 in k1567 in k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_1584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1584,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 203  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1609 in loop in k1580 in k1573 in k1567 in k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 203  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1592 in loop in k1580 in k1573 in k1567 in k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 204  addext */
f_1476(t2,t1);}

/* k1595 in k1592 in loop in k1580 in k1573 in k1567 in k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 205  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1584(t3,((C_word*)t0)[4],t2);}}

/* k1550 in k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1566,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 197  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1564 in k1550 in k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 197  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),((C_word*)t0)[3],t1,lf[36],((C_word*)t0)[2]);}

/* k1560 in k1550 in k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 197  addext */
f_1476(((C_word*)t0)[2],t1);}

/* loop in k1526 in ##csi#lookup-script-file in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static C_word C_fcall f_1503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(47)));
if(C_truep(t4)){
return(t1);}
else{
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* addext in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_1476(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1476,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1483,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 181  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t3,t2);}

/* k1481 in addext in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1483,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1486,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 183  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t2,((C_word*)t0)[3],lf[34]);}}

/* k1484 in k1481 in addext in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1492,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 184  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k1490 in k1484 in k1481 in addext in k1455 in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1426,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
t5=(C_word)C_i_string_ref(t2,t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1439,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t4,C_fix(0)))){
t7=(C_word)C_eqp(t5,C_make_character(92));
t8=t6;
f_1439(t8,(C_truep(t7)?t7:(C_word)C_eqp(t5,C_make_character(47))));}
else{
t7=t6;
f_1439(t7,C_SCHEME_FALSE);}}

/* k1437 in ##csi#chop-separator in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_fcall f_1439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 169  substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* dirseparator? in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1414,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(47))));}

/* ##sys#sharp-number-hook in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1400,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1412,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 155  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,t3);}

/* k1410 in ##sys#sharp-number-hook in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1412,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[24],t2));}

/* ##sys#user-read-hook in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1367,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:(C_word)C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1388,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_difference(C_retrieve(lf[25]),C_fix(1));
/* csi.scm: 150  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,t7);}
else{
/* csi.scm: 151  old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1386 in ##sys#user-read-hook in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1388,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[24],t2));}

/* ##csi#print-banner in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1355,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 120  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[20]+1)))(2,*((C_word*)lf[20]+1),t2);}

/* k1353 in ##csi#print-banner in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1358,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 138  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,lf[19]);}

/* k1356 in k1353 in ##csi#print-banner in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1365,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 139  chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,C_SCHEME_TRUE);}

/* k1363 in k1356 in k1353 in ##csi#print-banner in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 139  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[15]+1)))(5,*((C_word*)lf[15]+1),((C_word*)t0)[2],lf[16],t1,lf[17]);}

/* ##csi#print-usage in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 72   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[13]);}

/* k1325 in ##csi#print-usage in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1337,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[10],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[2],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[11],t5);
/* csi.scm: 92   ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),t3,t6);}

/* k1335 in k1325 in ##csi#print-usage in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 92   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],t1);}

/* k1328 in k1325 in ##csi#print-usage in k1311 in k1308 in k1305 in k1302 in k1299 in k1296 */
static void C_ccall f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 97   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[9]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[396] = {
{"toplevel:csi_scm",(void*)C_toplevel},
{"f_1298:csi_scm",(void*)f_1298},
{"f_1301:csi_scm",(void*)f_1301},
{"f_1304:csi_scm",(void*)f_1304},
{"f_1307:csi_scm",(void*)f_1307},
{"f_1310:csi_scm",(void*)f_1310},
{"f_1313:csi_scm",(void*)f_1313},
{"f_1457:csi_scm",(void*)f_1457},
{"f_5129:csi_scm",(void*)f_5129},
{"f_1694:csi_scm",(void*)f_1694},
{"f_1723:csi_scm",(void*)f_1723},
{"f_2303:csi_scm",(void*)f_2303},
{"f_2306:csi_scm",(void*)f_2306},
{"f_2584:csi_scm",(void*)f_2584},
{"f_5118:csi_scm",(void*)f_5118},
{"f_5124:csi_scm",(void*)f_5124},
{"f_5121:csi_scm",(void*)f_5121},
{"f_4145:csi_scm",(void*)f_4145},
{"f_5112:csi_scm",(void*)f_5112},
{"f_2168:csi_scm",(void*)f_2168},
{"f_2232:csi_scm",(void*)f_2232},
{"f_2250:csi_scm",(void*)f_2250},
{"f_2289:csi_scm",(void*)f_2289},
{"f_2295:csi_scm",(void*)f_2295},
{"f_2256:csi_scm",(void*)f_2256},
{"f_2264:csi_scm",(void*)f_2264},
{"f_2266:csi_scm",(void*)f_2266},
{"f_2283:csi_scm",(void*)f_2283},
{"f_2238:csi_scm",(void*)f_2238},
{"f_2244:csi_scm",(void*)f_2244},
{"f_2175:csi_scm",(void*)f_2175},
{"f_2178:csi_scm",(void*)f_2178},
{"f_2180:csi_scm",(void*)f_2180},
{"f_2217:csi_scm",(void*)f_2217},
{"f_2220:csi_scm",(void*)f_2220},
{"f_2226:csi_scm",(void*)f_2226},
{"f_2190:csi_scm",(void*)f_2190},
{"f_4149:csi_scm",(void*)f_4149},
{"f_5108:csi_scm",(void*)f_5108},
{"f_4152:csi_scm",(void*)f_4152},
{"f_4155:csi_scm",(void*)f_4155},
{"f_4158:csi_scm",(void*)f_4158},
{"f_5104:csi_scm",(void*)f_5104},
{"f_5091:csi_scm",(void*)f_5091},
{"f_5001:csi_scm",(void*)f_5001},
{"f_5004:csi_scm",(void*)f_5004},
{"f_5007:csi_scm",(void*)f_5007},
{"f_5010:csi_scm",(void*)f_5010},
{"f_5019:csi_scm",(void*)f_5019},
{"f_4161:csi_scm",(void*)f_4161},
{"f_4164:csi_scm",(void*)f_4164},
{"f_4995:csi_scm",(void*)f_4995},
{"f_4167:csi_scm",(void*)f_4167},
{"f_4170:csi_scm",(void*)f_4170},
{"f_4173:csi_scm",(void*)f_4173},
{"f_4986:csi_scm",(void*)f_4986},
{"f_4947:csi_scm",(void*)f_4947},
{"f_4949:csi_scm",(void*)f_4949},
{"f_4978:csi_scm",(void*)f_4978},
{"f_4176:csi_scm",(void*)f_4176},
{"f_4333:csi_scm",(void*)f_4333},
{"f_4936:csi_scm",(void*)f_4936},
{"f_4939:csi_scm",(void*)f_4939},
{"f_4336:csi_scm",(void*)f_4336},
{"f_4927:csi_scm",(void*)f_4927},
{"f_4930:csi_scm",(void*)f_4930},
{"f_4339:csi_scm",(void*)f_4339},
{"f_4342:csi_scm",(void*)f_4342},
{"f_4920:csi_scm",(void*)f_4920},
{"f_4913:csi_scm",(void*)f_4913},
{"f_4345:csi_scm",(void*)f_4345},
{"f_4900:csi_scm",(void*)f_4900},
{"f_4903:csi_scm",(void*)f_4903},
{"f_4348:csi_scm",(void*)f_4348},
{"f_4894:csi_scm",(void*)f_4894},
{"f_4351:csi_scm",(void*)f_4351},
{"f_4879:csi_scm",(void*)f_4879},
{"f5651:csi_scm",(void*)f5651},
{"f_4882:csi_scm",(void*)f_4882},
{"f_4885:csi_scm",(void*)f_4885},
{"f_4354:csi_scm",(void*)f_4354},
{"f_4853:csi_scm",(void*)f_4853},
{"f_4855:csi_scm",(void*)f_4855},
{"f_4865:csi_scm",(void*)f_4865},
{"f_4357:csi_scm",(void*)f_4357},
{"f_4826:csi_scm",(void*)f_4826},
{"f_4828:csi_scm",(void*)f_4828},
{"f_4838:csi_scm",(void*)f_4838},
{"f_4360:csi_scm",(void*)f_4360},
{"f_4787:csi_scm",(void*)f_4787},
{"f_4789:csi_scm",(void*)f_4789},
{"f_4818:csi_scm",(void*)f_4818},
{"f_4740:csi_scm",(void*)f_4740},
{"f_4748:csi_scm",(void*)f_4748},
{"f_4750:csi_scm",(void*)f_4750},
{"f_4779:csi_scm",(void*)f_4779},
{"f_4744:csi_scm",(void*)f_4744},
{"f_4736:csi_scm",(void*)f_4736},
{"f_4364:csi_scm",(void*)f_4364},
{"f_4367:csi_scm",(void*)f_4367},
{"f_4667:csi_scm",(void*)f_4667},
{"f_4670:csi_scm",(void*)f_4670},
{"f_4370:csi_scm",(void*)f_4370},
{"f_4655:csi_scm",(void*)f_4655},
{"f_4658:csi_scm",(void*)f_4658},
{"f_4373:csi_scm",(void*)f_4373},
{"f_4634:csi_scm",(void*)f_4634},
{"f_4637:csi_scm",(void*)f_4637},
{"f_4640:csi_scm",(void*)f_4640},
{"f_4643:csi_scm",(void*)f_4643},
{"f_4646:csi_scm",(void*)f_4646},
{"f_4376:csi_scm",(void*)f_4376},
{"f_4625:csi_scm",(void*)f_4625},
{"f_4230:csi_scm",(void*)f_4230},
{"f_4236:csi_scm",(void*)f_4236},
{"f_4258:csi_scm",(void*)f_4258},
{"f_4242:csi_scm",(void*)f_4242},
{"f_4245:csi_scm",(void*)f_4245},
{"f_4251:csi_scm",(void*)f_4251},
{"f_4379:csi_scm",(void*)f_4379},
{"f_4384:csi_scm",(void*)f_4384},
{"f_4597:csi_scm",(void*)f_4597},
{"f_4601:csi_scm",(void*)f_4601},
{"f_4604:csi_scm",(void*)f_4604},
{"f_4544:csi_scm",(void*)f_4544},
{"f_4565:csi_scm",(void*)f_4565},
{"f_4555:csi_scm",(void*)f_4555},
{"f_4563:csi_scm",(void*)f_4563},
{"f_4534:csi_scm",(void*)f_4534},
{"f_4524:csi_scm",(void*)f_4524},
{"f_4508:csi_scm",(void*)f_4508},
{"f_4498:csi_scm",(void*)f_4498},
{"f_4478:csi_scm",(void*)f_4478},
{"f_4462:csi_scm",(void*)f_4462},
{"f_4438:csi_scm",(void*)f_4438},
{"f_4409:csi_scm",(void*)f_4409},
{"f_4397:csi_scm",(void*)f_4397},
{"f_4263:csi_scm",(void*)f_4263},
{"f_4310:csi_scm",(void*)f_4310},
{"f_4267:csi_scm",(void*)f_4267},
{"f_4270:csi_scm",(void*)f_4270},
{"f_4277:csi_scm",(void*)f_4277},
{"f_4279:csi_scm",(void*)f_4279},
{"f_4302:csi_scm",(void*)f_4302},
{"f_4300:csi_scm",(void*)f_4300},
{"f_4289:csi_scm",(void*)f_4289},
{"f_4296:csi_scm",(void*)f_4296},
{"f_4178:csi_scm",(void*)f_4178},
{"f_4184:csi_scm",(void*)f_4184},
{"f_4192:csi_scm",(void*)f_4192},
{"f_4213:csi_scm",(void*)f_4213},
{"f_4000:csi_scm",(void*)f_4000},
{"f_4006:csi_scm",(void*)f_4006},
{"f_4028:csi_scm",(void*)f_4028},
{"f_4085:csi_scm",(void*)f_4085},
{"f_4078:csi_scm",(void*)f_4078},
{"f_4044:csi_scm",(void*)f_4044},
{"f_4067:csi_scm",(void*)f_4067},
{"f_4057:csi_scm",(void*)f_4057},
{"f_4061:csi_scm",(void*)f_4061},
{"f_4117:csi_scm",(void*)f_4117},
{"f_3943:csi_scm",(void*)f_3943},
{"f_3949:csi_scm",(void*)f_3949},
{"f_3961:csi_scm",(void*)f_3961},
{"f_3884:csi_scm",(void*)f_3884},
{"f_3888:csi_scm",(void*)f_3888},
{"f_3893:csi_scm",(void*)f_3893},
{"f_3922:csi_scm",(void*)f_3922},
{"f_3909:csi_scm",(void*)f_3909},
{"f_3846:csi_scm",(void*)f_3846},
{"f_3852:csi_scm",(void*)f_3852},
{"f_3868:csi_scm",(void*)f_3868},
{"f_3878:csi_scm",(void*)f_3878},
{"f_3637:csi_scm",(void*)f_3637},
{"f_3669:csi_scm",(void*)f_3669},
{"f_3844:csi_scm",(void*)f_3844},
{"f_3679:csi_scm",(void*)f_3679},
{"f_3682:csi_scm",(void*)f_3682},
{"f_3754:csi_scm",(void*)f_3754},
{"f_3815:csi_scm",(void*)f_3815},
{"f_3837:csi_scm",(void*)f_3837},
{"f_3833:csi_scm",(void*)f_3833},
{"f_3818:csi_scm",(void*)f_3818},
{"f_3773:csi_scm",(void*)f_3773},
{"f_3791:csi_scm",(void*)f_3791},
{"f_3801:csi_scm",(void*)f_3801},
{"f_3685:csi_scm",(void*)f_3685},
{"f_3688:csi_scm",(void*)f_3688},
{"f_3703:csi_scm",(void*)f_3703},
{"f_3716:csi_scm",(void*)f_3716},
{"f_3719:csi_scm",(void*)f_3719},
{"f_3691:csi_scm",(void*)f_3691},
{"f_3694:csi_scm",(void*)f_3694},
{"f_3640:csi_scm",(void*)f_3640},
{"f_3644:csi_scm",(void*)f_3644},
{"f_3660:csi_scm",(void*)f_3660},
{"f_3476:csi_scm",(void*)f_3476},
{"f_3589:csi_scm",(void*)f_3589},
{"f_3584:csi_scm",(void*)f_3584},
{"f_3478:csi_scm",(void*)f_3478},
{"f_3503:csi_scm",(void*)f_3503},
{"f_3546:csi_scm",(void*)f_3546},
{"f_3556:csi_scm",(void*)f_3556},
{"f_3527:csi_scm",(void*)f_3527},
{"f_3510:csi_scm",(void*)f_3510},
{"f_3481:csi_scm",(void*)f_3481},
{"f_3467:csi_scm",(void*)f_3467},
{"f_3471:csi_scm",(void*)f_3471},
{"f_2586:csi_scm",(void*)f_2586},
{"f_2590:csi_scm",(void*)f_2590},
{"f_3446:csi_scm",(void*)f_3446},
{"f_2718:csi_scm",(void*)f_2718},
{"f_2817:csi_scm",(void*)f_2817},
{"f_3025:csi_scm",(void*)f_3025},
{"f_3053:csi_scm",(void*)f_3053},
{"f_3062:csi_scm",(void*)f_3062},
{"f_3156:csi_scm",(void*)f_3156},
{"f_3312:csi_scm",(void*)f_3312},
{"f_3327:csi_scm",(void*)f_3327},
{"f_3406:csi_scm",(void*)f_3406},
{"f_3345:csi_scm",(void*)f_3345},
{"f_3367:csi_scm",(void*)f_3367},
{"f_3396:csi_scm",(void*)f_3396},
{"f_3357:csi_scm",(void*)f_3357},
{"f_3353:csi_scm",(void*)f_3353},
{"f_3331:csi_scm",(void*)f_3331},
{"f_3223:csi_scm",(void*)f_3223},
{"f_3232:csi_scm",(void*)f_3232},
{"f_3291:csi_scm",(void*)f_3291},
{"f_3240:csi_scm",(void*)f_3240},
{"f_3244:csi_scm",(void*)f_3244},
{"f_3253:csi_scm",(void*)f_3253},
{"f_3288:csi_scm",(void*)f_3288},
{"f_3280:csi_scm",(void*)f_3280},
{"f_3263:csi_scm",(void*)f_3263},
{"f_3187:csi_scm",(void*)f_3187},
{"f_3190:csi_scm",(void*)f_3190},
{"f_3195:csi_scm",(void*)f_3195},
{"f_3175:csi_scm",(void*)f_3175},
{"f_3162:csi_scm",(void*)f_3162},
{"f_3150:csi_scm",(void*)f_3150},
{"f_3069:csi_scm",(void*)f_3069},
{"f_3044:csi_scm",(void*)f_3044},
{"f_2985:csi_scm",(void*)f_2985},
{"f_2999:csi_scm",(void*)f_2999},
{"f_2995:csi_scm",(void*)f_2995},
{"f_2941:csi_scm",(void*)f_2941},
{"f_2847:csi_scm",(void*)f_2847},
{"f_2850:csi_scm",(void*)f_2850},
{"f_2918:csi_scm",(void*)f_2918},
{"f_2915:csi_scm",(void*)f_2915},
{"f_2853:csi_scm",(void*)f_2853},
{"f_2865:csi_scm",(void*)f_2865},
{"f_2870:csi_scm",(void*)f_2870},
{"f_2880:csi_scm",(void*)f_2880},
{"f_2895:csi_scm",(void*)f_2895},
{"f_2883:csi_scm",(void*)f_2883},
{"f_2886:csi_scm",(void*)f_2886},
{"f_2787:csi_scm",(void*)f_2787},
{"f_2793:csi_scm",(void*)f_2793},
{"f_2721:csi_scm",(void*)f_2721},
{"f_2592:csi_scm",(void*)f_2592},
{"f_2715:csi_scm",(void*)f_2715},
{"f_2599:csi_scm",(void*)f_2599},
{"f_2604:csi_scm",(void*)f_2604},
{"f_2627:csi_scm",(void*)f_2627},
{"f_2636:csi_scm",(void*)f_2636},
{"f_2700:csi_scm",(void*)f_2700},
{"f_2646:csi_scm",(void*)f_2646},
{"f_2649:csi_scm",(void*)f_2649},
{"f_2307:csi_scm",(void*)f_2307},
{"f_2315:csi_scm",(void*)f_2315},
{"f_2317:csi_scm",(void*)f_2317},
{"f_2321:csi_scm",(void*)f_2321},
{"f_2324:csi_scm",(void*)f_2324},
{"f_2327:csi_scm",(void*)f_2327},
{"f_2344:csi_scm",(void*)f_2344},
{"f_2537:csi_scm",(void*)f_2537},
{"f_2566:csi_scm",(void*)f_2566},
{"f_2535:csi_scm",(void*)f_2535},
{"f_2531:csi_scm",(void*)f_2531},
{"f_2452:csi_scm",(void*)f_2452},
{"f_2454:csi_scm",(void*)f_2454},
{"f_2516:csi_scm",(void*)f_2516},
{"f_2462:csi_scm",(void*)f_2462},
{"f_2466:csi_scm",(void*)f_2466},
{"f_2471:csi_scm",(void*)f_2471},
{"f_2502:csi_scm",(void*)f_2502},
{"f_2479:csi_scm",(void*)f_2479},
{"f_2487:csi_scm",(void*)f_2487},
{"f_2347:csi_scm",(void*)f_2347},
{"f_2375:csi_scm",(void*)f_2375},
{"f_2383:csi_scm",(void*)f_2383},
{"f_2387:csi_scm",(void*)f_2387},
{"f_2391:csi_scm",(void*)f_2391},
{"f_2395:csi_scm",(void*)f_2395},
{"f_2399:csi_scm",(void*)f_2399},
{"f_2403:csi_scm",(void*)f_2403},
{"f_2350:csi_scm",(void*)f_2350},
{"f_2353:csi_scm",(void*)f_2353},
{"f_2356:csi_scm",(void*)f_2356},
{"f_2359:csi_scm",(void*)f_2359},
{"f_2329:csi_scm",(void*)f_2329},
{"f_2337:csi_scm",(void*)f_2337},
{"f_1766:csi_scm",(void*)f_1766},
{"f_1782:csi_scm",(void*)f_1782},
{"f_2131:csi_scm",(void*)f_2131},
{"f_2135:csi_scm",(void*)f_2135},
{"f_2125:csi_scm",(void*)f_2125},
{"f_1788:csi_scm",(void*)f_1788},
{"f_2111:csi_scm",(void*)f_2111},
{"f_2087:csi_scm",(void*)f_2087},
{"f_2095:csi_scm",(void*)f_2095},
{"f_2090:csi_scm",(void*)f_2090},
{"f_2068:csi_scm",(void*)f_2068},
{"f_2071:csi_scm",(void*)f_2071},
{"f_2074:csi_scm",(void*)f_2074},
{"f_2052:csi_scm",(void*)f_2052},
{"f_2000:csi_scm",(void*)f_2000},
{"f_2033:csi_scm",(void*)f_2033},
{"f_2037:csi_scm",(void*)f_2037},
{"f_2005:csi_scm",(void*)f_2005},
{"f_2009:csi_scm",(void*)f_2009},
{"f_2020:csi_scm",(void*)f_2020},
{"f_2031:csi_scm",(void*)f_2031},
{"f_2024:csi_scm",(void*)f_2024},
{"f_2014:csi_scm",(void*)f_2014},
{"f_1991:csi_scm",(void*)f_1991},
{"f_1966:csi_scm",(void*)f_1966},
{"f_1974:csi_scm",(void*)f_1974},
{"f_1980:csi_scm",(void*)f_1980},
{"f_1984:csi_scm",(void*)f_1984},
{"f_1969:csi_scm",(void*)f_1969},
{"f_1957:csi_scm",(void*)f_1957},
{"f_1924:csi_scm",(void*)f_1924},
{"f_1932:csi_scm",(void*)f_1932},
{"f_1942:csi_scm",(void*)f_1942},
{"f_1927:csi_scm",(void*)f_1927},
{"f_1885:csi_scm",(void*)f_1885},
{"f_1888:csi_scm",(void*)f_1888},
{"f_1891:csi_scm",(void*)f_1891},
{"f_1894:csi_scm",(void*)f_1894},
{"f_1870:csi_scm",(void*)f_1870},
{"f_1873:csi_scm",(void*)f_1873},
{"f_1855:csi_scm",(void*)f_1855},
{"f_1858:csi_scm",(void*)f_1858},
{"f_1837:csi_scm",(void*)f_1837},
{"f_1840:csi_scm",(void*)f_1840},
{"f_1843:csi_scm",(void*)f_1843},
{"f_1814:csi_scm",(void*)f_1814},
{"f_1828:csi_scm",(void*)f_1828},
{"f_1824:csi_scm",(void*)f_1824},
{"f_1817:csi_scm",(void*)f_1817},
{"f_1799:csi_scm",(void*)f_1799},
{"f_1725:csi_scm",(void*)f_1725},
{"f_1729:csi_scm",(void*)f_1729},
{"f_1709:csi_scm",(void*)f_1709},
{"f_1716:csi_scm",(void*)f_1716},
{"f_1696:csi_scm",(void*)f_1696},
{"f_1669:csi_scm",(void*)f_1669},
{"f_1630:csi_scm",(void*)f_1630},
{"f_1654:csi_scm",(void*)f_1654},
{"f_1640:csi_scm",(void*)f_1640},
{"f_1524:csi_scm",(void*)f_1524},
{"f_1528:csi_scm",(void*)f_1528},
{"f_1569:csi_scm",(void*)f_1569},
{"f_1575:csi_scm",(void*)f_1575},
{"f_1582:csi_scm",(void*)f_1582},
{"f_1584:csi_scm",(void*)f_1584},
{"f_1611:csi_scm",(void*)f_1611},
{"f_1594:csi_scm",(void*)f_1594},
{"f_1597:csi_scm",(void*)f_1597},
{"f_1552:csi_scm",(void*)f_1552},
{"f_1566:csi_scm",(void*)f_1566},
{"f_1562:csi_scm",(void*)f_1562},
{"f_1503:csi_scm",(void*)f_1503},
{"f_1476:csi_scm",(void*)f_1476},
{"f_1483:csi_scm",(void*)f_1483},
{"f_1486:csi_scm",(void*)f_1486},
{"f_1492:csi_scm",(void*)f_1492},
{"f_1426:csi_scm",(void*)f_1426},
{"f_1439:csi_scm",(void*)f_1439},
{"f_1414:csi_scm",(void*)f_1414},
{"f_1400:csi_scm",(void*)f_1400},
{"f_1412:csi_scm",(void*)f_1412},
{"f_1367:csi_scm",(void*)f_1367},
{"f_1388:csi_scm",(void*)f_1388},
{"f_1351:csi_scm",(void*)f_1351},
{"f_1355:csi_scm",(void*)f_1355},
{"f_1358:csi_scm",(void*)f_1358},
{"f_1365:csi_scm",(void*)f_1365},
{"f_1323:csi_scm",(void*)f_1323},
{"f_1327:csi_scm",(void*)f_1327},
{"f_1337:csi_scm",(void*)f_1337},
{"f_1330:csi_scm",(void*)f_1330},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
