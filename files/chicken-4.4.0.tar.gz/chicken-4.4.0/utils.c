/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:16
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: utils.scm -optimize-level 2 -include-path . -include-path ./ -inline -explicit-use -no-trace -output-file utils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[62];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,25),40,115,121,115,116,101,109,42,32,102,115,116,114,49,49,32,46,32,97,114,103,115,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,6),40,97,50,53,57,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,19),40,114,101,97,100,45,97,108,108,32,46,32,102,105,108,101,49,57,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,53,56,32,103,54,56,55,50,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,113,115,32,115,116,114,51,57,32,46,32,116,109,112,51,56,52,48,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,6),40,97,52,55,48,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,12),40,97,52,54,52,32,101,120,49,52,53,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,6),40,97,52,56,53,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,6),40,97,52,57,55,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,19),40,97,52,57,49,32,46,32,97,114,103,115,49,52,48,49,52,56,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,6),40,97,52,55,57,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,14),40,97,52,53,56,32,107,49,51,57,49,52,52,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,97,53,50,55,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,12),40,97,53,50,49,32,101,120,49,50,57,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,6),40,97,53,51,54,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,6),40,97,53,52,56,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,19),40,97,53,52,50,32,46,32,97,114,103,115,49,50,52,49,51,48,41,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,6),40,97,53,51,48,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,53,49,53,32,107,49,50,51,49,50,56,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,6),40,97,53,48,54,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,6),40,97,54,48,52,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,6),40,97,54,48,55,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,37),40,99,111,109,112,105,108,101,45,102,105,108,101,32,102,105,108,101,110,97,109,101,49,48,48,32,46,32,116,109,112,57,57,49,48,49,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,18),40,102,95,54,53,48,32,103,49,55,51,49,55,52,49,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,36),40,115,99,97,110,45,105,110,112,117,116,45,108,105,110,101,115,32,114,120,49,54,49,32,46,32,116,109,112,49,54,48,49,54,50,41,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_207)
static void C_ccall f_207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_210)
static void C_ccall f_210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_213)
static void C_ccall f_213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_216)
static void C_ccall f_216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_219)
static void C_ccall f_219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_222)
static void C_ccall f_222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_611)
static void C_ccall f_611(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_611)
static void C_ccall f_611r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_615)
static void C_ccall f_615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_623)
static void C_fcall f_623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_627)
static void C_ccall f_627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_636)
static void C_ccall f_636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_650)
static void C_ccall f_650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_658)
static void C_ccall f_658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_414)
static void C_ccall f_414(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_414)
static void C_ccall f_414r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_608)
static void C_ccall f_608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_418)
static void C_ccall f_418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_421)
static void C_ccall f_421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_605)
static void C_ccall f_605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_424)
static void C_ccall f_424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_603)
static void C_ccall f_603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_427)
static void C_ccall f_427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_433)
static void C_ccall f_433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_593)
static void C_ccall f_593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_439)
static void C_ccall f_439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_561)
static void C_ccall f_561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_589)
static void C_ccall f_589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_585)
static void C_ccall f_585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_565)
static void C_ccall f_565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_569)
static void C_ccall f_569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_573)
static void C_ccall f_573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_442)
static void C_ccall f_442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_507)
static void C_ccall f_507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_516)
static void C_ccall f_516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_531)
static void C_ccall f_531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_543)
static void C_ccall f_543(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_543)
static void C_ccall f_543r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_537)
static void C_ccall f_537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_522)
static void C_ccall f_522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_528)
static void C_ccall f_528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_511)
static void C_ccall f_511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_445)
static void C_ccall f_445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_459)
static void C_ccall f_459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_480)
static void C_ccall f_480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_492)
static void C_ccall f_492(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_492)
static void C_ccall f_492r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_486)
static void C_ccall f_486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_490)
static void C_ccall f_490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_471)
static void C_ccall f_471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_475)
static void C_ccall f_475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_454)
static void C_ccall f_454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_285)
static void C_ccall f_285(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_285)
static void C_ccall f_285r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_289)
static void C_ccall f_289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_318)
static void C_ccall f_318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_320)
static void C_fcall f_320(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_369)
static void C_fcall f_369(C_word t0,C_word t1) C_noret;
C_noret_decl(f_314)
static void C_ccall f_314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_242)
static void C_ccall f_242(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_242)
static void C_ccall f_242r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_246)
static void C_ccall f_246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_252)
static void C_ccall f_252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_260)
static void C_ccall f_260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_224)
static void C_ccall f_224(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_224)
static void C_ccall f_224r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_228)
static void C_ccall f_228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_231)
static void C_ccall f_231(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_623)
static void C_fcall trf_623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_623(t0,t1);}

C_noret_decl(trf_320)
static void C_fcall trf_320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_320(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_320(t0,t1,t2);}

C_noret_decl(trf_369)
static void C_fcall trf_369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_369(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_369(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(528)){
C_save(t1);
C_rereclaim2(528*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,62);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"sprintf");
lf[3]=C_h_intern(&lf[3],6,"system");
lf[4]=C_h_intern(&lf[4],7,"system*");
lf[5]=C_h_intern(&lf[5],9,"\003syserror");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[7]=C_h_intern(&lf[7],8,"read-all");
lf[8]=C_h_intern(&lf[8],20,"\003sysread-string/port");
lf[9]=C_h_intern(&lf[9],11,"read-string");
lf[10]=C_h_intern(&lf[10],20,"with-input-from-file");
lf[11]=C_h_intern(&lf[11],5,"port\077");
lf[12]=C_h_intern(&lf[12],18,"\003sysstandard-input");
lf[13]=C_h_intern(&lf[13],2,"qs");
lf[14]=C_h_intern(&lf[14],7,"mingw32");
lf[15]=C_h_intern(&lf[15],4,"msvc");
lf[16]=C_h_intern(&lf[16],13,"string-append");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\002\047\047");
lf[20]=C_h_intern(&lf[20],18,"string-concatenate");
lf[21]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000#\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000`\376\003\000\000\002\376\377\012\000\000\264\376\003\000\000\002\376\377\012\000\000~\376\003\000\000\002\376\377\012\000\000&\376\003\000"
"\000\002\376\377\012\000\000%\376\003\000\000\002\376\377\012\000\000$\376\003\000\000\002\376\377\012\000\000!\376\003\000\000\002\376\377\012\000\000*\376\003\000\000\002\376\377\012\000\000;\376\003\000\000\002\376\377\012\000\000<\376\003\000\000\002\376\377\012\000\000>\376\003\000\000\002\376"
"\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000(\376\003\000\000\002\376\377\012\000\000)\376\003\000\000\002\376\377\012\000\000[\376\003\000\000\002\376\377\012\000\000]\376\003\000\000\002\376\377\012\000\000{\376\003\000\000\002\376\377\012\000\000}\376\377\016");
lf[22]=C_h_intern(&lf[22],16,"\003sysstring->list");
lf[23]=C_h_intern(&lf[23],14,"build-platform");
lf[24]=C_h_intern(&lf[24],20,"compile-file-options");
lf[25]=C_h_intern(&lf[25],4,"load");
lf[26]=C_h_intern(&lf[26],12,"compile-file");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007mingw32\376\003\000\000\002\376\001\000\000\004msvc\376\377\016");
lf[29]=C_h_intern(&lf[29],5,"abort");
lf[30]=C_h_intern(&lf[30],12,"delete-file*");
lf[31]=C_h_intern(&lf[31],22,"with-exception-handler");
lf[32]=C_h_intern(&lf[32],30,"call-with-current-continuation");
lf[33]=C_h_intern(&lf[33],7,"on-exit");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\025~a~a -s ~a ~a -o ~a~a");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[39]=C_h_intern(&lf[39],18,"string-intersperse");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[41]=C_h_intern(&lf[41],6,"append");
lf[42]=C_h_intern(&lf[42],5,"print");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\014; compiling ");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[45]=C_h_intern(&lf[45],21,"create-temporary-file");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[47]=C_h_intern(&lf[47],12,"file-exists\077");
lf[48]=C_h_intern(&lf[48],13,"make-pathname");
lf[49]=C_h_intern(&lf[49],15,"\003sysget-keyword");
lf[50]=C_h_intern(&lf[50],5,"\000load");
lf[51]=C_h_intern(&lf[51],12,"\000output-file");
lf[52]=C_h_intern(&lf[52],8,"\000options");
lf[53]=C_h_intern(&lf[53],6,"regexp");
lf[54]=C_h_intern(&lf[54],9,"read-line");
lf[55]=C_h_intern(&lf[55],13,"string-search");
lf[56]=C_h_intern(&lf[56],16,"scan-input-lines");
lf[57]=C_h_intern(&lf[57],17,"\003syspeek-c-string");
lf[58]=C_h_intern(&lf[58],14,"make-parameter");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-S\376\003\000\000\002\376B\000\000\003-O2\376\003\000\000\002\376B\000\000\003-d2\376\377\016");
lf[60]=C_h_intern(&lf[60],17,"register-feature!");
lf[61]=C_h_intern(&lf[61],5,"utils");
C_register_lf2(lf,62,create_ptable());
t2=C_mutate(&lf[0] /* (set! c25 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_207,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k205 */
static void C_ccall f_207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k208 in k205 */
static void C_ccall f_210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_213,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k211 in k208 in k205 */
static void C_ccall f_213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k214 in k211 in k208 in k205 */
static void C_ccall f_216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_222,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 52   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t2,lf[61]);}

/* k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_222,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=*((C_word*)lf[3]+1);
t4=C_mutate((C_word*)lf[4]+1 /* (set! system* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_224,a[2]=t2,a[3]=t3,a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[7]+1 /* (set! read-all ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_242,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[13]+1 /* (set! qs ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_285,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 97   make-parameter */
((C_proc3)C_retrieve_proc(*((C_word*)lf[58]+1)))(3,*((C_word*)lf[58]+1),t7,lf[59]);}

/* k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_406,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! compile-file-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}

/* k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_413,2,t0,t1);}
t2=*((C_word*)lf[25]+1);
t3=C_mutate((C_word*)lf[26]+1 /* (set! compile-file ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_414,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp));
t4=*((C_word*)lf[53]+1);
t5=*((C_word*)lf[54]+1);
t6=*((C_word*)lf[55]+1);
t7=C_mutate((C_word*)lf[56]+1 /* (set! scan-input-lines ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_611,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=((C_word)li25),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}

/* scan-input-lines in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_611(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_611r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_611r(t0,t1,t2,t3);}}

static void C_ccall f_611r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_615,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_615(2,t5,*((C_word*)lf[12]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_615(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k613 in scan-input-lines in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_615,2,t0,t1);}
t2=(C_word)C_i_closurep(((C_word*)t0)[6]);
t3=(C_truep(t2)?((C_word*)t0)[6]:(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_650,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li23),tmp=(C_word)a,a+=6,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_623,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,a[6]=((C_word)li24),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_623(t7,((C_word*)t0)[2]);}

/* loop in k613 in scan-input-lines in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_fcall f_623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_623,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_627,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 141  read-line */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k625 in loop in k613 in scan-input-lines in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_627,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 143  rx */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k634 in k625 in loop in k613 in scan-input-lines in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* utils.scm: 144  loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_623(t2,((C_word*)t0)[3]);}}

/* f_650 in k613 in scan-input-lines in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_650,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_658,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 139  regexp */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k656 */
static void C_ccall f_658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g176177 */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_414(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_414r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_414r(t0,t1,t2,t3);}}

static void C_ccall f_414r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_418,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_608,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_proc(*((C_word*)lf[49]+1)))(5,*((C_word*)lf[49]+1),t4,lf[52],t3,t5);}

/* a607 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_608,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),t2,lf[51],((C_word*)t0)[2]);}

/* k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_424,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_605,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_proc(*((C_word*)lf[49]+1)))(5,*((C_word*)lf[49]+1),t2,lf[50],((C_word*)t0)[2],t3);}

/* a604 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_605,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_427,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_603,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 104  make-pathname */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k601 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 104  file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_427,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[27]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_433,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)t0)[6];
if(C_truep(t4)){
t5=t3;
f_433(2,t5,C_SCHEME_FALSE);}
else{
/* utils.scm: 105  create-temporary-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[45]+1)))(3,*((C_word*)lf[45]+1),t3,lf[46]);}}

/* k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* utils.scm: 106  build-platform */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t2);}

/* k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_593,2,t0,t1);}
t2=(C_word)C_i_memq(t1,lf[28]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* utils.scm: 107  print */
t4=*((C_word*)lf[42]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[43],((C_word*)t0)[4],lf[44]);}

/* k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_442,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(((C_word*)t0)[5])?lf[34]:lf[35]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* utils.scm: 111  qs */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t4,((C_word*)t0)[2]);}

/* k559 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_585,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_589,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 112  compile-file-options */
((C_proc2)C_retrieve_proc(*((C_word*)lf[24]+1)))(2,*((C_word*)lf[24]+1),t4);}

/* k587 in k559 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 112  append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k583 in k559 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 112  string-intersperse */
((C_proc4)C_retrieve_proc(*((C_word*)lf[39]+1)))(4,*((C_word*)lf[39]+1),((C_word*)t0)[2],t1,lf[40]);}

/* k563 in k559 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* utils.scm: 113  qs */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t2,((C_word*)t0)[2]);}

/* k567 in k563 in k559 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_573,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[3];
/* utils.scm: 114  qs */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t2,t3);}
else{
t3=((C_word*)t0)[2];
/* utils.scm: 114  qs */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t2,t3);}}

/* k571 in k567 in k563 in k559 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[7])){
/* utils.scm: 108  system* */
((C_proc9)C_retrieve_proc(*((C_word*)lf[4]+1)))(9,*((C_word*)lf[4]+1),((C_word*)t0)[6],lf[36],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[37]);}
else{
/* utils.scm: 108  system* */
((C_proc9)C_retrieve_proc(*((C_word*)lf[4]+1)))(9,*((C_word*)lf[4]+1),((C_word*)t0)[6],lf[36],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[38]);}}

/* k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_445(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_507,a[2]=((C_word*)t0)[4],a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 117  on-exit */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,t3);}}

/* a506 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_511,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_516,a[2]=((C_word*)t0)[2],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a515 in a506 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_516,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_522,a[2]=t2,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_531,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),t1,t3,t4);}

/* a530 in a515 in a506 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_537,a[2]=((C_word*)t0)[3],a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_543,a[2]=((C_word*)t0)[2],a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a542 in a530 in a515 in a506 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_543(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_543r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_543r(t0,t1,t2);}}

static void C_ccall f_543r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_549,a[2]=t2,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
/* k123128 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a548 in a542 in a530 in a515 in a506 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_549,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a536 in a530 in a515 in a506 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_537,2,t0,t1);}
/* utils.scm: 119  delete-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t1,((C_word*)t0)[2]);}

/* a521 in a515 in a506 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_522,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_528,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
/* k123128 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a527 in a521 in a515 in a506 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_528,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k509 in a506 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g126127 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k443 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_445,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_454,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_459,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* a458 in k443 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_459,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_465,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_480,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),t1,t3,t4);}

/* a479 in a458 in k443 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_492,a[2]=((C_word*)t0)[2],a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a491 in a479 in a458 in k443 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_492(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_492r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_492r(t0,t1,t2);}}

static void C_ccall f_492r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_498,a[2]=t2,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
/* k139144 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a497 in a491 in a479 in a458 in k443 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_498,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a485 in a479 in a458 in k443 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_490,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 126  load-file */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k488 in a485 in a479 in a458 in k443 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a464 in a458 in k443 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_465,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_471,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp);
/* k139144 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a470 in a464 in a458 in k443 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_475,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 124  delete-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t2,((C_word*)t0)[2]);}

/* k473 in a470 in a464 in a458 in k443 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 125  abort */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k452 in k443 in k440 in k437 in k591 in k431 in k425 in k422 in k419 in k416 in compile-file in k411 in k408 in k404 in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g142143 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_285(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_285r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_285r(t0,t1,t2,t3);}}

static void C_ccall f_285r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_289,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* utils.scm: 78   build-platform */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_289(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k287 in qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_289,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[14]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[15]));
if(C_truep(t3)){
/* utils.scm: 81   string-append */
t4=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[17],((C_word*)t0)[2],lf[18]);}
else{
t4=(C_word)C_i_string_length(((C_word*)t0)[2]);
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[19]);}
else{
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_314,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_318,a[2]=t10,a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* string->list */
t12=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[2]);}}}

/* k316 in k287 in qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_318,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_320,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_320(t5,((C_word*)t0)[2],t1);}

/* loop58 in k316 in k287 in qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_fcall f_320(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_320,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_369,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_u_i_char_whitespacep(t4);
if(C_truep(t5)){
t6=t3;
f_369(t6,(C_truep(t5)?(C_word)C_a_i_string(&a,2,C_make_character(92),t4):(C_word)C_a_i_string(&a,1,t4)));}
else{
t6=(C_word)C_i_memq(t4,lf[21]);
t7=t3;
f_369(t7,(C_truep(t6)?(C_word)C_a_i_string(&a,2,C_make_character(92),t4):(C_word)C_a_i_string(&a,1,t4)));}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k367 in loop58 in k316 in k287 in qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_fcall f_369(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_369,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop5871 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_320(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop5871 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_320(t6,((C_word*)t0)[3],t5);}}

/* k312 in k287 in qs in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 85   string-concatenate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),((C_word*)t0)[2],t1);}

/* read-all in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_242(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_242r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_242r(t0,t1,t2);}}

static void C_ccall f_242r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_246,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_246(2,t4,*((C_word*)lf[12]+1));}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_246(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k244 in read-all in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_252,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 71   port? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k250 in k244 in read-all in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_252,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_260,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 73   with-input-from-file */
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a259 in k250 in k244 in read-all in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_260,2,t0,t1);}
t2=*((C_word*)lf[9]+1);
/* g3031 */
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,C_SCHEME_FALSE);}

/* system* in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_224(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_224r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_224r(t0,t1,t2,t3);}}

static void C_ccall f_224r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_228,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k226 in system* in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_231,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 62   system */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k229 in k226 in system* in k220 in k217 in k214 in k211 in k208 in k205 */
static void C_ccall f_231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* utils.scm: 64   ##sys#error */
t3=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[6],((C_word*)t0)[2],t1);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[69] = {
{"toplevel:utils_scm",(void*)C_utils_toplevel},
{"f_207:utils_scm",(void*)f_207},
{"f_210:utils_scm",(void*)f_210},
{"f_213:utils_scm",(void*)f_213},
{"f_216:utils_scm",(void*)f_216},
{"f_219:utils_scm",(void*)f_219},
{"f_222:utils_scm",(void*)f_222},
{"f_406:utils_scm",(void*)f_406},
{"f_410:utils_scm",(void*)f_410},
{"f_413:utils_scm",(void*)f_413},
{"f_611:utils_scm",(void*)f_611},
{"f_615:utils_scm",(void*)f_615},
{"f_623:utils_scm",(void*)f_623},
{"f_627:utils_scm",(void*)f_627},
{"f_636:utils_scm",(void*)f_636},
{"f_650:utils_scm",(void*)f_650},
{"f_658:utils_scm",(void*)f_658},
{"f_414:utils_scm",(void*)f_414},
{"f_608:utils_scm",(void*)f_608},
{"f_418:utils_scm",(void*)f_418},
{"f_421:utils_scm",(void*)f_421},
{"f_605:utils_scm",(void*)f_605},
{"f_424:utils_scm",(void*)f_424},
{"f_603:utils_scm",(void*)f_603},
{"f_427:utils_scm",(void*)f_427},
{"f_433:utils_scm",(void*)f_433},
{"f_593:utils_scm",(void*)f_593},
{"f_439:utils_scm",(void*)f_439},
{"f_561:utils_scm",(void*)f_561},
{"f_589:utils_scm",(void*)f_589},
{"f_585:utils_scm",(void*)f_585},
{"f_565:utils_scm",(void*)f_565},
{"f_569:utils_scm",(void*)f_569},
{"f_573:utils_scm",(void*)f_573},
{"f_442:utils_scm",(void*)f_442},
{"f_507:utils_scm",(void*)f_507},
{"f_516:utils_scm",(void*)f_516},
{"f_531:utils_scm",(void*)f_531},
{"f_543:utils_scm",(void*)f_543},
{"f_549:utils_scm",(void*)f_549},
{"f_537:utils_scm",(void*)f_537},
{"f_522:utils_scm",(void*)f_522},
{"f_528:utils_scm",(void*)f_528},
{"f_511:utils_scm",(void*)f_511},
{"f_445:utils_scm",(void*)f_445},
{"f_459:utils_scm",(void*)f_459},
{"f_480:utils_scm",(void*)f_480},
{"f_492:utils_scm",(void*)f_492},
{"f_498:utils_scm",(void*)f_498},
{"f_486:utils_scm",(void*)f_486},
{"f_490:utils_scm",(void*)f_490},
{"f_465:utils_scm",(void*)f_465},
{"f_471:utils_scm",(void*)f_471},
{"f_475:utils_scm",(void*)f_475},
{"f_454:utils_scm",(void*)f_454},
{"f_285:utils_scm",(void*)f_285},
{"f_289:utils_scm",(void*)f_289},
{"f_318:utils_scm",(void*)f_318},
{"f_320:utils_scm",(void*)f_320},
{"f_369:utils_scm",(void*)f_369},
{"f_314:utils_scm",(void*)f_314},
{"f_242:utils_scm",(void*)f_242},
{"f_246:utils_scm",(void*)f_246},
{"f_252:utils_scm",(void*)f_252},
{"f_260:utils_scm",(void*)f_260},
{"f_224:utils_scm",(void*)f_224},
{"f_228:utils_scm",(void*)f_228},
{"f_231:utils_scm",(void*)f_231},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
