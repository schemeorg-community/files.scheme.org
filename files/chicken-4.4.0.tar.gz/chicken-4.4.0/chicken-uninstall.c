/* Generated from chicken-uninstall.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-03-08 22:18
   Version 4.3.0
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-03-08 on galinha (Linux)
   command line: chicken-uninstall.scm -optimize-level 2 -include-path . -include-path ./ -inline -no-lambda-info -local -no-trace -ignore-repository -output-file chicken-uninstall.c
   used units: library eval srfi_1 posix data_structures utils ports regex srfi_13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[55];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_358)
static void C_ccall f_358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_361)
static void C_ccall f_361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_364)
static void C_ccall f_364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_367)
static void C_ccall f_367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_370)
static void C_ccall f_370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_373)
static void C_ccall f_373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_376)
static void C_ccall f_376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_385)
static void C_ccall f_385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_388)
static void C_ccall f_388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_628)
static void C_fcall f_628(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_663)
static void C_fcall f_663(C_word t0,C_word t1) C_noret;
C_noret_decl(f_724)
static void C_fcall f_724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_793)
static void C_ccall f_793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f890)
static void C_ccall f890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_771)
static void C_ccall f_771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_733)
static void C_ccall f_733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f885)
static void C_ccall f885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_756)
static void C_ccall f_756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_746)
static void C_ccall f_746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_711)
static void C_ccall f_711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_685)
static void C_ccall f_685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_678)
static void C_ccall f_678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f880)
static void C_ccall f880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f875)
static void C_ccall f875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_642)
static void C_ccall f_642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_459)
static void C_ccall f_459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_455)
static void C_ccall f_455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_416)
static void C_ccall f_416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_418)
static void C_fcall f_418(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_447)
static void C_ccall f_447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_408)
static void C_ccall f_408(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_402)
static void C_ccall f_402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_552)
static void C_ccall f_552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_479)
static void C_ccall f_479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_506)
static void C_ccall f_506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_536)
static void C_ccall f_536(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_536)
static void C_ccall f_536r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_542)
static void C_ccall f_542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_512)
static void C_ccall f_512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_530)
static void C_ccall f_530(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_528)
static void C_ccall f_528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_524)
static void C_ccall f_524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_520)
static void C_ccall f_520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_485)
static void C_ccall f_485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_491)
static void C_ccall f_491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_ccall f_474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_567)
static void C_ccall f_567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_572)
static void C_fcall f_572(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_584)
static void C_ccall f_584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_590)
static void C_ccall f_590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_828)
static void C_ccall f_828(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_628)
static void C_fcall trf_628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_628(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_628(t0,t1,t2,t3);}

C_noret_decl(trf_663)
static void C_fcall trf_663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_663(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_663(t0,t1);}

C_noret_decl(trf_724)
static void C_fcall trf_724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_724(t0,t1);}

C_noret_decl(trf_418)
static void C_fcall trf_418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_418(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_418(t0,t1,t2);}

C_noret_decl(trf_572)
static void C_fcall trf_572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_572(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_572(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(352)){
C_save(t1);
C_rereclaim2(352*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,55);
lf[1]=C_h_intern(&lf[1],25,"\003sysimplicit-exit-handler");
lf[2]=C_h_intern(&lf[2],5,"print");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\022nothing to remove.");
lf[4]=C_h_intern(&lf[4],26,"setup-api#remove-extension");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\011removing ");
lf[6]=C_h_intern(&lf[6],7,"aborted");
lf[7]=C_h_intern(&lf[7],4,"exit");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\010aborted.");
lf[9]=C_h_intern(&lf[9],6,"signal");
lf[10]=C_h_intern(&lf[10],20,"setup-api#yes-or-no\077");
lf[11]=C_h_intern(&lf[11],8,"\000default");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[13]=C_h_intern(&lf[13],18,"string-concatenate");
lf[14]=C_h_intern(&lf[14],6,"append");
lf[15]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000+About to delete the following extensions:\012\012\376\377\016");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030\012Do you want to proceed\077\376\377\016");
lf[17]=C_h_intern(&lf[17],13,"string-append");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[20]=C_h_intern(&lf[20],7,"\003sysmap");
lf[21]=C_h_intern(&lf[21],22,"with-exception-handler");
lf[22]=C_h_intern(&lf[22],30,"call-with-current-continuation");
lf[23]=C_h_intern(&lf[23],17,"delete-duplicates");
lf[24]=C_h_intern(&lf[24],8,"string=\077");
lf[25]=C_h_intern(&lf[25],11,"concatenate");
lf[26]=C_h_intern(&lf[26],4,"grep");
lf[27]=C_h_intern(&lf[27],13,"pathname-file");
lf[28]=C_h_intern(&lf[28],4,"glob");
lf[29]=C_h_intern(&lf[29],13,"make-pathname");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[32]=C_h_intern(&lf[32],15,"repository-path");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\001#usage: chicken-uninstall [OPTION | PATTERN] ...\012\012  -h   -help              "
"      show this message and exit\012  -v   -version                 show version an"
"d exit\012       -force                   don\047t ask, delete whatever matches\012  -s  "
" -sudo                    use sudo(1) for deleting files");
lf[34]=C_h_intern(&lf[34],7,"reverse");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[38]=C_h_intern(&lf[38],15,"chicken-version");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[42]=C_h_intern(&lf[42],22,"setup-api#sudo-install");
lf[43]=C_h_intern(&lf[43],6,"string");
lf[44]=C_h_intern(&lf[44],17,"lset-intersection");
lf[45]=C_h_intern(&lf[45],3,"eq\077");
lf[46]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\377\016");
lf[47]=C_h_intern(&lf[47],16,"\003sysstring->list");
lf[48]=C_h_intern(&lf[48],9,"substring");
lf[49]=C_h_intern(&lf[49],12,"glob->regexp");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[52]=C_h_intern(&lf[52],22,"command-line-arguments");
lf[53]=C_h_intern(&lf[53],11,"\003sysrequire");
lf[54]=C_h_intern(&lf[54],9,"setup-api");
C_register_lf2(lf,55,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_358,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k356 */
static void C_ccall f_358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k359 in k356 */
static void C_ccall f_361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_364,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k362 in k359 in k356 */
static void C_ccall f_364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k365 in k362 in k359 in k356 */
static void C_ccall f_367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t2,lf[54]);}

/* k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_388,2,t0,t1);}
t2=lf[0] /* main#*force* */ =C_SCHEME_FALSE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_825,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_835,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 117  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[52]))(2,*((C_word*)lf[52]+1),t4);}

/* k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_835,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_628,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_628(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_fcall f_628(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_628,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_642,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f875,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 76   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t5,lf[33]);}
else{
/* chicken-uninstall.scm: 92   reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t4,t3);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[35]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_663,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_663(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[50]);
t8=t6;
f_663(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[51])));}}}

/* k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_fcall f_663(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_663,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f880,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 76   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t3,lf[33]);}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[36]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[37]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_678,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_685,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 99   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[38]))(2,*((C_word*)lf[38]+1),t5);}
else{
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[39]))){
t4=lf[0] /* main#*force* */ =C_SCHEME_TRUE;;
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-uninstall.scm: 103  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_628(t6,((C_word*)t0)[6],t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[40]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[41]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-uninstall.scm: 105  setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),t6,C_SCHEME_TRUE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_724,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_string_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_positivep(t7))){
t8=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t9=t6;
f_724(t9,(C_word)C_eqp(C_make_character(45),t8));}
else{
t8=t6;
f_724(t8,C_SCHEME_FALSE);}}}}}}

/* k722 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_fcall f_724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_724,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_771,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 110  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f890,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 76   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t4,lf[33]);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_793,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-uninstall.scm: 115  glob->regexp */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t3,((C_word*)t0)[6]);}}

/* k791 in k722 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_793,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-uninstall.scm: 115  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_628(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* f890 in k722 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 85   exit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],C_fix(1));}

/* k769 in k722 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k731 in k722 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_767,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-uninstall.scm: 111  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),t2,*((C_word*)lf[45]+1),lf[46],t1);}

/* k765 in k731 in k722 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_767,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_746,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_750,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_756,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f885,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 76   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t3,lf[33]);}}

/* f885 in k765 in k731 in k722 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 85   exit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],C_fix(1));}

/* a755 in k765 in k731 in k722 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_756,3,t0,t1,t2);}
t3=*((C_word*)lf[43]+1);
/* g329330 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(45),t2);}

/* k748 in k765 in k731 in k722 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-uninstall.scm: 112  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),((C_word*)t0)[2],t1,t2);}

/* k744 in k765 in k731 in k722 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 112  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_628(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k709 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-uninstall.scm: 106  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_628(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k683 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 99   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),((C_word*)t0)[2],t1);}

/* k676 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 100  exit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],C_fix(0));}

/* f880 in k661 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 85   exit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],C_fix(0));}

/* f875 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 85   exit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],C_fix(1));}

/* k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_642,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_552,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_395,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_416,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_455,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_459,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 42   repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[32]))(2,*((C_word*)lf[32]+1),t11);}

/* k457 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 42   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[29]))(5,*((C_word*)lf[29]+1),((C_word*)t0)[2],t1,lf[30],lf[31]);}

/* k453 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 42   glob */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),((C_word*)t0)[2],t1);}

/* k414 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_416,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_418,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_418(t5,((C_word*)t0)[2],t1);}

/* loop159 in k414 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_fcall f_418(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_418,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_retrieve(lf[27]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_447,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* g175176 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k445 in loop159 in k414 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_447,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(C_word)C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop159172 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_418(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* loop159172 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_418(t6,((C_word*)t0)[3],t5);}}

/* k393 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_402,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_406,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_408,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a407 in k393 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_408(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_408,3,t0,t1,t2);}
t3=C_retrieve(lf[26]);
/* g199200 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* k404 in k393 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 44   concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k400 in k393 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 43   delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1,*((C_word*)lf[24]+1));}

/* k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_552,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-uninstall.scm: 67   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),((C_word*)t0)[3],lf[3]);}
else{
t2=C_retrieve2(lf[0],"main#*force*");
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_567,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_567(2,t4,t2);}
else{
t4=(C_word)C_i_equalp(t1,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_567(2,t5,t4);}
else{
t5=t1;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_474,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_479,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t6,t7);}}}}

/* a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_479,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_485,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_506,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t1,t3,t4);}

/* a505 in a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_512,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_536,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a535 in a505 in a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_536(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_536r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_536r(t0,t1,t2);}}

static void C_ccall f_536r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_542,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k206211 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a541 in a535 in a505 in a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_542,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a511 in a505 in a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_520,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_524,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_528,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_530,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a529 in a511 in a505 in a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_530(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_530,3,t0,t1,t2);}
t3=*((C_word*)lf[17]+1);
/* g232233 */
t4=t3;
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[18],t2,lf[19]);}

/* k526 in a511 in a505 in a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 58   append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[14]+1)))(5,*((C_word*)lf[14]+1),((C_word*)t0)[2],lf[15],t1,lf[16]);}

/* k522 in a511 in a505 in a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 57   string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[13]))(3,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1);}

/* k518 in a511 in a505 in a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 56   setup-api#yes-or-no? */
((C_proc5)C_retrieve_symbol_proc(lf[10]))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],t1,lf[11],lf[12]);}

/* a484 in a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_485,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_491,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k206211 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a490 in a484 in a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_491,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[6]);
if(C_truep(t2)){
t3=t1;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_465,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 48   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t4,lf[8]);}
else{
/* chicken-uninstall.scm: 55   signal */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t1,((C_word*)t0)[2]);}}

/* k463 in a490 in a484 in a478 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 49   exit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],C_fix(1));}

/* k472 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g209210 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k565 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_567,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_572,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_572(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop256 in k565 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_fcall f_572(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_572,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_590,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_584,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-uninstall.scm: 71   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[2]+1)))(4,*((C_word*)lf[2]+1),t5,lf[5],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k582 in loop256 in k565 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 72   setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[4]))(3,*((C_word*)lf[4]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k588 in loop256 in k565 in k550 in k640 in loop in k833 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_572(t3,((C_word*)t0)[2],t2);}

/* k823 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_828,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_831,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[1]))(2,*((C_word*)lf[1]+1),t3);}

/* k829 in k823 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k826 in k823 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in k365 in k362 in k359 in k356 */
static void C_ccall f_828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[62] = {
{"toplevel:chicken_uninstall_scm",(void*)C_toplevel},
{"f_358:chicken_uninstall_scm",(void*)f_358},
{"f_361:chicken_uninstall_scm",(void*)f_361},
{"f_364:chicken_uninstall_scm",(void*)f_364},
{"f_367:chicken_uninstall_scm",(void*)f_367},
{"f_370:chicken_uninstall_scm",(void*)f_370},
{"f_373:chicken_uninstall_scm",(void*)f_373},
{"f_376:chicken_uninstall_scm",(void*)f_376},
{"f_379:chicken_uninstall_scm",(void*)f_379},
{"f_382:chicken_uninstall_scm",(void*)f_382},
{"f_385:chicken_uninstall_scm",(void*)f_385},
{"f_388:chicken_uninstall_scm",(void*)f_388},
{"f_835:chicken_uninstall_scm",(void*)f_835},
{"f_628:chicken_uninstall_scm",(void*)f_628},
{"f_663:chicken_uninstall_scm",(void*)f_663},
{"f_724:chicken_uninstall_scm",(void*)f_724},
{"f_793:chicken_uninstall_scm",(void*)f_793},
{"f890:chicken_uninstall_scm",(void*)f890},
{"f_771:chicken_uninstall_scm",(void*)f_771},
{"f_733:chicken_uninstall_scm",(void*)f_733},
{"f_767:chicken_uninstall_scm",(void*)f_767},
{"f885:chicken_uninstall_scm",(void*)f885},
{"f_756:chicken_uninstall_scm",(void*)f_756},
{"f_750:chicken_uninstall_scm",(void*)f_750},
{"f_746:chicken_uninstall_scm",(void*)f_746},
{"f_711:chicken_uninstall_scm",(void*)f_711},
{"f_685:chicken_uninstall_scm",(void*)f_685},
{"f_678:chicken_uninstall_scm",(void*)f_678},
{"f880:chicken_uninstall_scm",(void*)f880},
{"f875:chicken_uninstall_scm",(void*)f875},
{"f_642:chicken_uninstall_scm",(void*)f_642},
{"f_459:chicken_uninstall_scm",(void*)f_459},
{"f_455:chicken_uninstall_scm",(void*)f_455},
{"f_416:chicken_uninstall_scm",(void*)f_416},
{"f_418:chicken_uninstall_scm",(void*)f_418},
{"f_447:chicken_uninstall_scm",(void*)f_447},
{"f_395:chicken_uninstall_scm",(void*)f_395},
{"f_408:chicken_uninstall_scm",(void*)f_408},
{"f_406:chicken_uninstall_scm",(void*)f_406},
{"f_402:chicken_uninstall_scm",(void*)f_402},
{"f_552:chicken_uninstall_scm",(void*)f_552},
{"f_479:chicken_uninstall_scm",(void*)f_479},
{"f_506:chicken_uninstall_scm",(void*)f_506},
{"f_536:chicken_uninstall_scm",(void*)f_536},
{"f_542:chicken_uninstall_scm",(void*)f_542},
{"f_512:chicken_uninstall_scm",(void*)f_512},
{"f_530:chicken_uninstall_scm",(void*)f_530},
{"f_528:chicken_uninstall_scm",(void*)f_528},
{"f_524:chicken_uninstall_scm",(void*)f_524},
{"f_520:chicken_uninstall_scm",(void*)f_520},
{"f_485:chicken_uninstall_scm",(void*)f_485},
{"f_491:chicken_uninstall_scm",(void*)f_491},
{"f_465:chicken_uninstall_scm",(void*)f_465},
{"f_474:chicken_uninstall_scm",(void*)f_474},
{"f_567:chicken_uninstall_scm",(void*)f_567},
{"f_572:chicken_uninstall_scm",(void*)f_572},
{"f_584:chicken_uninstall_scm",(void*)f_584},
{"f_590:chicken_uninstall_scm",(void*)f_590},
{"f_825:chicken_uninstall_scm",(void*)f_825},
{"f_831:chicken_uninstall_scm",(void*)f_831},
{"f_828:chicken_uninstall_scm",(void*)f_828},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
