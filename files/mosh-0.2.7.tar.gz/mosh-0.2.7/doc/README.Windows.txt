(deprecated. use CMake to build mosh/nmosh with MSVC)

--

Get binary version of Mosh from http://mosh.monaos.org

If you want to build Mosh from source.
See the install section on http://mosh.monaos.org
