# Drive information viewer

This program scans for ATA devices and lists information.
