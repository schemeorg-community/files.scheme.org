# PS/2 keyboard and mouse demo for Loko on bare metal

This sample starts the i8042 driver and hooks it up to PS/2 keyboard
and mouse drivers. It then starts reading events from them and
presents them on the screen.
