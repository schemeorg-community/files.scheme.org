/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-03-23 21:48
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-01 on debian (Linux)
   command line: posixwin.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file uposixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)	    C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_tm_set_08(v) \
        (memset(&C_tm, 0, sizeof(struct tm)), \
        C_tm.tm_sec = C_unfix(C_block_item(v, 0)), \
        C_tm.tm_min = C_unfix(C_block_item(v, 1)), \
        C_tm.tm_hour = C_unfix(C_block_item(v, 2)), \
        C_tm.tm_mday = C_unfix(C_block_item(v, 3)), \
        C_tm.tm_mon = C_unfix(C_block_item(v, 4)), \
        C_tm.tm_year = C_unfix(C_block_item(v, 5)), \
        C_tm.tm_wday = C_unfix(C_block_item(v, 6)), \
        C_tm.tm_yday = C_unfix(C_block_item(v, 7)), \
        C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE))

#define C_tm_set(v) (C_tm_set_08(v), &C_tm)

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[393];
static double C_possibly_force_alignment;


/* from k3851 */
static C_word C_fcall stub615(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub615(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from close-handle in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static C_word C_fcall stub603(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub603(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_truep(C_a0);
C_r=C_fix((C_word)close_handle(t0));
return C_r;}

/* from current-process-id in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static C_word C_fcall stub591(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub591(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k3493 */
static C_word C_fcall stub494(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub494(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k3487 */
static C_word C_fcall stub484(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub484(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from ex0 */
static C_word C_fcall stub413(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub413(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub408(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub408(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (daylight ? _tzname[1] : _tzname[0]);return(z);
C_ret:
#undef return

return C_r;}

/* from strftime */
static C_word C_fcall stub388(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub388(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub382(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub382(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub373(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub373(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from get */
static C_word C_fcall stub356(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub356(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from strerror */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1124)
static void C_ccall f_1124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4798)
static void C_ccall f_4798(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4780)
static void C_ccall f_4780(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4768)
static void C_ccall f_4768(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4672)
static void C_ccall f_4672(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4600)
static void C_ccall f_4600(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4570)
static void C_ccall f_4570(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4474)
static void C_fcall f_4474(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4469)
static void C_fcall f_4469(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4464)
static void C_fcall f_4464(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4319)
static void C_fcall f_4319(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4326)
static void C_fcall f_4326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_fcall f_4338(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4127)
static void C_fcall f_4127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_fcall f_4122(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4117)
static void C_fcall f_4117(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4112)
static void C_fcall f_4112(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4050)
static void C_fcall f_4050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_fcall f_4045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4040)
static void C_fcall f_4040(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4035)
static void C_fcall f_4035(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3971)
static void C_fcall f_3971(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_fcall f_3973(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3702)
static void C_fcall f_3702(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_fcall f_3697(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3692)
static void C_fcall f_3692(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3680)
static void C_fcall f_3680(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_ccall f_3594(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3594)
static void C_ccall f_3594r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3618)
static void C_fcall f_3618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_fcall f_3613(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3608)
static void C_fcall f_3608(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3596)
static void C_fcall f_3596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3579)
static void C_fcall f_3579(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_fcall f_3546(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3562)
static void C_ccall f_3562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_fcall f_3496(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3508)
static void C_fcall f_3508(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3405)
static void C_fcall f_3405(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3448)
static void C_fcall f_3448(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3410)
static void C_fcall f_3410(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3419)
static void C_fcall f_3419(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3296)
static void C_fcall f_3296(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_fcall f_3336(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_fcall f_2991(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_fcall f_3003(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2930)
static void C_fcall f_2930(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_fcall f_2842(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_fcall f_2805(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2760)
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_fcall f_2386(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2380)
static void C_fcall f_2380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static C_word C_fcall f_2368(C_word t0);
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2157)
static void C_fcall f_2157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2187)
static void C_fcall f_2187(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_fcall f_2229(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2281)
static void C_ccall f_2281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2294)
static void C_ccall f_2294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_fcall f_2027(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_fcall f_2106(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_fcall f_1955(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static C_word C_fcall f_1944(C_word t0);
C_noret_decl(f_1939)
static void C_fcall f_1939(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1819)
static void C_fcall f_1819(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_fcall f_1814(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1713)
static void C_fcall f_1713(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_fcall f_1747(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1757)
static void C_ccall f_1757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_fcall f_1769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1682)
static void C_ccall f_1682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1496)
static void C_fcall f_1496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1442)
static void C_ccall f_1442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1408)
static void C_ccall f_1408(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1408)
static void C_ccall f_1408r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_fcall f_1370(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1374)
static void C_ccall f_1374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1362)
static void C_ccall f_1362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1240)
static void C_ccall f_1240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1219)
static void C_ccall f_1219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1206)
static void C_ccall f_1206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1151)
static void C_ccall f_1151(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_4474)
static void C_fcall trf_4474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4474(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4474(t0,t1);}

C_noret_decl(trf_4469)
static void C_fcall trf_4469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4469(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4469(t0,t1,t2);}

C_noret_decl(trf_4464)
static void C_fcall trf_4464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4464(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4464(t0,t1,t2,t3);}

C_noret_decl(trf_4319)
static void C_fcall trf_4319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4319(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4319(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4326)
static void C_fcall trf_4326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4326(t0,t1);}

C_noret_decl(trf_4338)
static void C_fcall trf_4338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4338(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4338(t0,t1,t2,t3);}

C_noret_decl(trf_4127)
static void C_fcall trf_4127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4127(t0,t1);}

C_noret_decl(trf_4122)
static void C_fcall trf_4122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4122(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4122(t0,t1,t2);}

C_noret_decl(trf_4117)
static void C_fcall trf_4117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4117(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4117(t0,t1,t2,t3);}

C_noret_decl(trf_4112)
static void C_fcall trf_4112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4112(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4112(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4050)
static void C_fcall trf_4050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4050(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4050(t0,t1);}

C_noret_decl(trf_4045)
static void C_fcall trf_4045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4045(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4045(t0,t1,t2);}

C_noret_decl(trf_4040)
static void C_fcall trf_4040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4040(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4040(t0,t1,t2,t3);}

C_noret_decl(trf_4035)
static void C_fcall trf_4035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4035(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4035(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3971)
static void C_fcall trf_3971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3971(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3971(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3973)
static void C_fcall trf_3973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3973(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3973(t0,t1,t2);}

C_noret_decl(trf_3702)
static void C_fcall trf_3702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3702(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3702(t0,t1);}

C_noret_decl(trf_3697)
static void C_fcall trf_3697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3697(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3697(t0,t1,t2);}

C_noret_decl(trf_3692)
static void C_fcall trf_3692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3692(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3692(t0,t1,t2,t3);}

C_noret_decl(trf_3680)
static void C_fcall trf_3680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3680(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3680(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3618)
static void C_fcall trf_3618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3618(t0,t1);}

C_noret_decl(trf_3613)
static void C_fcall trf_3613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3613(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3613(t0,t1,t2);}

C_noret_decl(trf_3608)
static void C_fcall trf_3608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3608(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3608(t0,t1,t2,t3);}

C_noret_decl(trf_3596)
static void C_fcall trf_3596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3596(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3596(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3579)
static void C_fcall trf_3579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3579(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3579(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3546)
static void C_fcall trf_3546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3546(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3546(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3496)
static void C_fcall trf_3496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3496(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3496(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3508)
static void C_fcall trf_3508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3508(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3508(t0,t1,t2,t3);}

C_noret_decl(trf_3405)
static void C_fcall trf_3405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3405(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3405(t0,t1,t2,t3);}

C_noret_decl(trf_3448)
static void C_fcall trf_3448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3448(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3448(t0,t1,t2,t3);}

C_noret_decl(trf_3410)
static void C_fcall trf_3410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3410(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3410(t0,t1,t2);}

C_noret_decl(trf_3419)
static void C_fcall trf_3419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3419(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3419(t0,t1,t2);}

C_noret_decl(trf_3296)
static void C_fcall trf_3296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3296(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3296(t0,t1,t2);}

C_noret_decl(trf_3336)
static void C_fcall trf_3336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3336(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3336(t0,t1,t2);}

C_noret_decl(trf_2991)
static void C_fcall trf_2991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2991(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2991(t0,t1,t2);}

C_noret_decl(trf_3003)
static void C_fcall trf_3003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3003(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3003(t0,t1,t2);}

C_noret_decl(trf_2930)
static void C_fcall trf_2930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2930(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2930(t0,t1);}

C_noret_decl(trf_2842)
static void C_fcall trf_2842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2842(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2842(t0,t1,t2,t3);}

C_noret_decl(trf_2805)
static void C_fcall trf_2805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2805(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2805(t0,t1,t2);}

C_noret_decl(trf_2760)
static void C_fcall trf_2760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2760(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2760(t0,t1,t2,t3);}

C_noret_decl(trf_2386)
static void C_fcall trf_2386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2386(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2386(t0,t1,t2,t3);}

C_noret_decl(trf_2380)
static void C_fcall trf_2380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2380(t0,t1);}

C_noret_decl(trf_2157)
static void C_fcall trf_2157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2157(t0,t1);}

C_noret_decl(trf_2187)
static void C_fcall trf_2187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2187(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2187(t0,t1);}

C_noret_decl(trf_2229)
static void C_fcall trf_2229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2229(t0,t1);}

C_noret_decl(trf_2027)
static void C_fcall trf_2027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2027(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2027(t0,t1,t2,t3);}

C_noret_decl(trf_2106)
static void C_fcall trf_2106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2106(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2106(t0,t1);}

C_noret_decl(trf_1955)
static void C_fcall trf_1955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1955(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1955(t0,t1);}

C_noret_decl(trf_1939)
static void C_fcall trf_1939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1939(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1939(t0,t1);}

C_noret_decl(trf_1819)
static void C_fcall trf_1819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1819(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1819(t0,t1);}

C_noret_decl(trf_1814)
static void C_fcall trf_1814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1814(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1814(t0,t1,t2);}

C_noret_decl(trf_1713)
static void C_fcall trf_1713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1713(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1713(t0,t1,t2,t3);}

C_noret_decl(trf_1747)
static void C_fcall trf_1747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1747(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1747(t0,t1);}

C_noret_decl(trf_1769)
static void C_fcall trf_1769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1769(t0,t1);}

C_noret_decl(trf_1496)
static void C_fcall trf_1496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1496(t0,t1);}

C_noret_decl(trf_1370)
static void C_fcall trf_1370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1370(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1370(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr9rv)
static void C_fcall tr9rv(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9rv(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n+1);
t9=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3080)){
C_save(t1);
C_rereclaim2(3080*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,393);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000/this function is not available on this platform");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],13,"string-append");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[8]=C_h_intern(&lf[8],17,"\003syspeek-c-string");
lf[9]=C_h_intern(&lf[9],16,"\003sysupdate-errno");
lf[10]=C_h_intern(&lf[10],15,"\003sysposix-error");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"open/rdonly");
lf[13]=C_h_intern(&lf[13],11,"open/wronly");
lf[14]=C_h_intern(&lf[14],9,"open/rdwr");
lf[15]=C_h_intern(&lf[15],9,"open/read");
lf[16]=C_h_intern(&lf[16],10,"open/write");
lf[17]=C_h_intern(&lf[17],10,"open/creat");
lf[18]=C_h_intern(&lf[18],11,"open/append");
lf[19]=C_h_intern(&lf[19],9,"open/excl");
lf[20]=C_h_intern(&lf[20],10,"open/trunc");
lf[21]=C_h_intern(&lf[21],11,"open/binary");
lf[22]=C_h_intern(&lf[22],9,"open/text");
lf[23]=C_h_intern(&lf[23],14,"open/noinherit");
lf[24]=C_h_intern(&lf[24],10,"perm/irusr");
lf[25]=C_h_intern(&lf[25],10,"perm/iwusr");
lf[26]=C_h_intern(&lf[26],10,"perm/ixusr");
lf[27]=C_h_intern(&lf[27],10,"perm/irgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iwgrp");
lf[29]=C_h_intern(&lf[29],10,"perm/ixgrp");
lf[30]=C_h_intern(&lf[30],10,"perm/iroth");
lf[31]=C_h_intern(&lf[31],10,"perm/iwoth");
lf[32]=C_h_intern(&lf[32],10,"perm/ixoth");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxu");
lf[34]=C_h_intern(&lf[34],10,"perm/irwxg");
lf[35]=C_h_intern(&lf[35],10,"perm/irwxo");
lf[36]=C_h_intern(&lf[36],9,"file-open");
lf[37]=C_h_intern(&lf[37],11,"\000file-error");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[39]=C_h_intern(&lf[39],17,"\003sysmake-c-string");
lf[40]=C_h_intern(&lf[40],20,"\003sysexpand-home-path");
lf[41]=C_h_intern(&lf[41],10,"file-close");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[43]=C_h_intern(&lf[43],11,"make-string");
lf[44]=C_h_intern(&lf[44],9,"file-read");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[46]=C_h_intern(&lf[46],11,"\000type-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[48]=C_h_intern(&lf[48],10,"file-write");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[51]=C_h_intern(&lf[51],13,"string-length");
lf[52]=C_h_intern(&lf[52],12,"file-mkstemp");
lf[53]=C_h_intern(&lf[53],13,"\003syssubstring");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[55]=C_h_intern(&lf[55],8,"seek/set");
lf[56]=C_h_intern(&lf[56],8,"seek/end");
lf[57]=C_h_intern(&lf[57],8,"seek/cur");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[61]=C_h_intern(&lf[61],9,"file-stat");
lf[62]=C_h_intern(&lf[62],9,"file-size");
lf[63]=C_h_intern(&lf[63],22,"file-modification-time");
lf[64]=C_h_intern(&lf[64],16,"file-access-time");
lf[65]=C_h_intern(&lf[65],16,"file-change-time");
lf[66]=C_h_intern(&lf[66],10,"file-owner");
lf[67]=C_h_intern(&lf[67],16,"file-permissions");
lf[68]=C_h_intern(&lf[68],13,"regular-file\077");
lf[69]=C_h_intern(&lf[69],13,"\003sysfile-info");
lf[70]=C_h_intern(&lf[70],14,"symbolic-link\077");
lf[71]=C_h_intern(&lf[71],13,"stat-regular\077");
lf[72]=C_h_intern(&lf[72],15,"stat-directory\077");
lf[73]=C_h_intern(&lf[73],17,"stat-char-device\077");
lf[74]=C_h_intern(&lf[74],18,"stat-block-device\077");
lf[75]=C_h_intern(&lf[75],10,"stat-fifo\077");
lf[76]=C_h_intern(&lf[76],13,"stat-symlink\077");
lf[77]=C_h_intern(&lf[77],12,"stat-socket\077");
lf[78]=C_h_intern(&lf[78],13,"file-position");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[80]=C_h_intern(&lf[80],6,"stream");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[82]=C_h_intern(&lf[82],5,"port\077");
lf[83]=C_h_intern(&lf[83],18,"set-file-position!");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[86]=C_h_intern(&lf[86],13,"\000bounds-error");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[88]=C_h_intern(&lf[88],16,"create-directory");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[90]=C_h_intern(&lf[90],16,"change-directory");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[92]=C_h_intern(&lf[92],16,"delete-directory");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[94]=C_h_intern(&lf[94],6,"string");
lf[95]=C_h_intern(&lf[95],9,"directory");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[97]=C_h_intern(&lf[97],16,"\003sysmake-pointer");
lf[98]=C_h_intern(&lf[98],17,"current-directory");
lf[99]=C_h_intern(&lf[99],10,"directory\077");
lf[100]=C_h_intern(&lf[100],27,"\003sysplatform-fixup-pathname");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[102]=C_h_intern(&lf[102],5,"null\077");
lf[103]=C_h_intern(&lf[103],6,"char=\077");
lf[104]=C_h_intern(&lf[104],8,"string=\077");
lf[105]=C_h_intern(&lf[105],16,"char-alphabetic\077");
lf[106]=C_h_intern(&lf[106],10,"string-ref");
lf[107]=C_h_intern(&lf[107],18,"string-intersperse");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[109]=C_h_intern(&lf[109],17,"current-user-name");
lf[110]=C_h_intern(&lf[110],9,"condition");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\003c:\134");
lf[112]=C_h_intern(&lf[112],22,"with-exception-handler");
lf[113]=C_h_intern(&lf[113],30,"call-with-current-continuation");
lf[114]=C_h_intern(&lf[114],14,"canonical-path");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[116]=C_h_intern(&lf[116],7,"reverse");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[119]=C_h_intern(&lf[119],12,"string-split");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\027Documents and Settings\134");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[127]=C_h_intern(&lf[127],5,"\000text");
lf[128]=C_h_intern(&lf[128],9,"\003syserror");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[131]=C_h_intern(&lf[131],13,"\003sysmake-port");
lf[132]=C_h_intern(&lf[132],21,"\003sysstream-port-class");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[134]=C_h_intern(&lf[134],15,"open-input-pipe");
lf[135]=C_h_intern(&lf[135],7,"\000binary");
lf[136]=C_h_intern(&lf[136],16,"open-output-pipe");
lf[137]=C_h_intern(&lf[137],16,"close-input-pipe");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[139]=C_h_intern(&lf[139],14,"\003syscheck-port");
lf[140]=C_h_intern(&lf[140],17,"close-output-pipe");
lf[141]=C_h_intern(&lf[141],20,"call-with-input-pipe");
lf[142]=C_h_intern(&lf[142],21,"call-with-output-pipe");
lf[143]=C_h_intern(&lf[143],20,"with-input-from-pipe");
lf[144]=C_h_intern(&lf[144],18,"\003sysstandard-input");
lf[145]=C_h_intern(&lf[145],19,"with-output-to-pipe");
lf[146]=C_h_intern(&lf[146],19,"\003sysstandard-output");
lf[147]=C_h_intern(&lf[147],11,"create-pipe");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[149]=C_h_intern(&lf[149],11,"signal/term");
lf[150]=C_h_intern(&lf[150],10,"signal/int");
lf[151]=C_h_intern(&lf[151],10,"signal/fpe");
lf[152]=C_h_intern(&lf[152],10,"signal/ill");
lf[153]=C_h_intern(&lf[153],11,"signal/segv");
lf[154]=C_h_intern(&lf[154],11,"signal/abrt");
lf[155]=C_h_intern(&lf[155],12,"signal/break");
lf[156]=C_h_intern(&lf[156],11,"signal/alrm");
lf[157]=C_h_intern(&lf[157],11,"signal/chld");
lf[158]=C_h_intern(&lf[158],11,"signal/cont");
lf[159]=C_h_intern(&lf[159],10,"signal/hup");
lf[160]=C_h_intern(&lf[160],9,"signal/io");
lf[161]=C_h_intern(&lf[161],11,"signal/kill");
lf[162]=C_h_intern(&lf[162],11,"signal/pipe");
lf[163]=C_h_intern(&lf[163],11,"signal/prof");
lf[164]=C_h_intern(&lf[164],11,"signal/quit");
lf[165]=C_h_intern(&lf[165],11,"signal/stop");
lf[166]=C_h_intern(&lf[166],11,"signal/trap");
lf[167]=C_h_intern(&lf[167],11,"signal/tstp");
lf[168]=C_h_intern(&lf[168],10,"signal/urg");
lf[169]=C_h_intern(&lf[169],11,"signal/usr1");
lf[170]=C_h_intern(&lf[170],11,"signal/usr2");
lf[171]=C_h_intern(&lf[171],13,"signal/vtalrm");
lf[172]=C_h_intern(&lf[172],12,"signal/winch");
lf[173]=C_h_intern(&lf[173],11,"signal/xcpu");
lf[174]=C_h_intern(&lf[174],11,"signal/xfsz");
lf[175]=C_h_intern(&lf[175],12,"signals-list");
lf[176]=C_h_intern(&lf[176],18,"\003sysinterrupt-hook");
lf[177]=C_h_intern(&lf[177],14,"signal-handler");
lf[178]=C_h_intern(&lf[178],19,"set-signal-handler!");
lf[179]=C_h_intern(&lf[179],10,"errno/perm");
lf[180]=C_h_intern(&lf[180],11,"errno/noent");
lf[181]=C_h_intern(&lf[181],10,"errno/srch");
lf[182]=C_h_intern(&lf[182],10,"errno/intr");
lf[183]=C_h_intern(&lf[183],8,"errno/io");
lf[184]=C_h_intern(&lf[184],12,"errno/noexec");
lf[185]=C_h_intern(&lf[185],10,"errno/badf");
lf[186]=C_h_intern(&lf[186],11,"errno/child");
lf[187]=C_h_intern(&lf[187],11,"errno/nomem");
lf[188]=C_h_intern(&lf[188],11,"errno/acces");
lf[189]=C_h_intern(&lf[189],11,"errno/fault");
lf[190]=C_h_intern(&lf[190],10,"errno/busy");
lf[191]=C_h_intern(&lf[191],11,"errno/exist");
lf[192]=C_h_intern(&lf[192],12,"errno/notdir");
lf[193]=C_h_intern(&lf[193],11,"errno/isdir");
lf[194]=C_h_intern(&lf[194],11,"errno/inval");
lf[195]=C_h_intern(&lf[195],11,"errno/mfile");
lf[196]=C_h_intern(&lf[196],11,"errno/nospc");
lf[197]=C_h_intern(&lf[197],11,"errno/spipe");
lf[198]=C_h_intern(&lf[198],10,"errno/pipe");
lf[199]=C_h_intern(&lf[199],11,"errno/again");
lf[200]=C_h_intern(&lf[200],10,"errno/rofs");
lf[201]=C_h_intern(&lf[201],10,"errno/nxio");
lf[202]=C_h_intern(&lf[202],10,"errno/2big");
lf[203]=C_h_intern(&lf[203],10,"errno/xdev");
lf[204]=C_h_intern(&lf[204],11,"errno/nodev");
lf[205]=C_h_intern(&lf[205],11,"errno/nfile");
lf[206]=C_h_intern(&lf[206],11,"errno/notty");
lf[207]=C_h_intern(&lf[207],10,"errno/fbig");
lf[208]=C_h_intern(&lf[208],11,"errno/mlink");
lf[209]=C_h_intern(&lf[209],9,"errno/dom");
lf[210]=C_h_intern(&lf[210],11,"errno/range");
lf[211]=C_h_intern(&lf[211],12,"errno/deadlk");
lf[212]=C_h_intern(&lf[212],17,"errno/nametoolong");
lf[213]=C_h_intern(&lf[213],11,"errno/nolck");
lf[214]=C_h_intern(&lf[214],11,"errno/nosys");
lf[215]=C_h_intern(&lf[215],14,"errno/notempty");
lf[216]=C_h_intern(&lf[216],11,"errno/ilseq");
lf[217]=C_h_intern(&lf[217],16,"change-file-mode");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[219]=C_h_intern(&lf[219],17,"file-read-access\077");
lf[220]=C_h_intern(&lf[220],18,"file-write-access\077");
lf[221]=C_h_intern(&lf[221],20,"file-execute-access\077");
lf[222]=C_h_intern(&lf[222],12,"fileno/stdin");
lf[223]=C_h_intern(&lf[223],13,"fileno/stdout");
lf[224]=C_h_intern(&lf[224],13,"fileno/stderr");
lf[225]=C_h_intern(&lf[225],7,"\000append");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[233]=C_h_intern(&lf[233],16,"open-input-file*");
lf[234]=C_h_intern(&lf[234],17,"open-output-file*");
lf[235]=C_h_intern(&lf[235],12,"port->fileno");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[238]=C_h_intern(&lf[238],25,"\003syspeek-unsigned-integer");
lf[239]=C_h_intern(&lf[239],16,"duplicate-fileno");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[241]=C_h_intern(&lf[241],6,"setenv");
lf[242]=C_h_intern(&lf[242],8,"unsetenv");
lf[243]=C_h_intern(&lf[243],9,"substring");
lf[244]=C_h_intern(&lf[244],19,"current-environment");
lf[245]=C_h_intern(&lf[245],19,"seconds->local-time");
lf[246]=C_h_intern(&lf[246],18,"\003sysdecode-seconds");
lf[247]=C_h_intern(&lf[247],17,"seconds->utc-time");
lf[248]=C_h_intern(&lf[248],15,"seconds->string");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[250]=C_h_intern(&lf[250],12,"time->string");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[254]=C_h_intern(&lf[254],19,"local-time->seconds");
lf[255]=C_h_intern(&lf[255],15,"\003syscons-flonum");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[258]=C_h_intern(&lf[258],27,"local-timezone-abbreviation");
lf[259]=C_h_intern(&lf[259],5,"_exit");
lf[260]=C_h_intern(&lf[260],19,"set-buffering-mode!");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[262]=C_h_intern(&lf[262],5,"\000full");
lf[263]=C_h_intern(&lf[263],5,"\000line");
lf[264]=C_h_intern(&lf[264],5,"\000none");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[266]=C_h_intern(&lf[266],6,"regexp");
lf[267]=C_h_intern(&lf[267],21,"make-anchored-pattern");
lf[268]=C_h_intern(&lf[268],12,"string-match");
lf[269]=C_h_intern(&lf[269],12,"glob->regexp");
lf[270]=C_h_intern(&lf[270],13,"make-pathname");
lf[271]=C_h_intern(&lf[271],18,"decompose-pathname");
lf[272]=C_h_intern(&lf[272],4,"glob");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[275]=C_h_intern(&lf[275],13,"spawn/overlay");
lf[276]=C_h_intern(&lf[276],10,"spawn/wait");
lf[277]=C_h_intern(&lf[277],12,"spawn/nowait");
lf[278]=C_h_intern(&lf[278],13,"spawn/nowaito");
lf[279]=C_h_intern(&lf[279],12,"spawn/detach");
lf[280]=C_h_intern(&lf[280],16,"char-whitespace\077");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[284]=C_h_intern(&lf[284],24,"pathname-strip-directory");
lf[287]=C_h_intern(&lf[287],15,"process-execute");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[289]=C_h_intern(&lf[289],13,"process-spawn");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[291]=C_h_intern(&lf[291],18,"current-process-id");
lf[292]=C_h_intern(&lf[292],17,"\003sysshell-command");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[294]=C_h_intern(&lf[294],6,"getenv");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[296]=C_h_intern(&lf[296],27,"\003sysshell-command-arguments");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[298]=C_h_intern(&lf[298],11,"process-run");
lf[300]=C_h_intern(&lf[300],11,"\003sysprocess");
lf[301]=C_h_intern(&lf[301],14,"\000process-error");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[303]=C_h_intern(&lf[303],17,"\003sysmake-locative");
lf[304]=C_h_intern(&lf[304],8,"location");
lf[305]=C_h_intern(&lf[305],12,"\003sysfor-each");
lf[306]=C_h_intern(&lf[306],7,"process");
lf[307]=C_h_intern(&lf[307],8,"process*");
lf[308]=C_h_intern(&lf[308],16,"\003sysprocess-wait");
lf[309]=C_h_intern(&lf[309],12,"process-wait");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[311]=C_h_intern(&lf[311],5,"sleep");
lf[312]=C_h_intern(&lf[312],13,"get-host-name");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[314]=C_h_intern(&lf[314],18,"system-information");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[318]=C_h_intern(&lf[318],10,"find-files");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[321]=C_h_intern(&lf[321],19,"\003sysundefined-value");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[323]=C_h_intern(&lf[323],16,"\003sysdynamic-wind");
lf[324]=C_h_intern(&lf[324],13,"pathname-file");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[326]=C_h_intern(&lf[326],17,"change-file-owner");
lf[327]=C_h_intern(&lf[327],5,"error");
lf[328]=C_h_intern(&lf[328],11,"create-fifo");
lf[329]=C_h_intern(&lf[329],14,"create-session");
lf[330]=C_h_intern(&lf[330],20,"create-symbolic-link");
lf[331]=C_h_intern(&lf[331],26,"current-effective-group-id");
lf[332]=C_h_intern(&lf[332],25,"current-effective-user-id");
lf[333]=C_h_intern(&lf[333],27,"current-effective-user-name");
lf[334]=C_h_intern(&lf[334],16,"current-group-id");
lf[335]=C_h_intern(&lf[335],15,"current-user-id");
lf[336]=C_h_intern(&lf[336],18,"map-file-to-memory");
lf[337]=C_h_intern(&lf[337],9,"file-link");
lf[338]=C_h_intern(&lf[338],9,"file-lock");
lf[339]=C_h_intern(&lf[339],18,"file-lock/blocking");
lf[340]=C_h_intern(&lf[340],11,"file-select");
lf[341]=C_h_intern(&lf[341],14,"file-test-lock");
lf[342]=C_h_intern(&lf[342],13,"file-truncate");
lf[343]=C_h_intern(&lf[343],11,"file-unlock");
lf[344]=C_h_intern(&lf[344],10,"get-groups");
lf[345]=C_h_intern(&lf[345],17,"group-information");
lf[346]=C_h_intern(&lf[346],17,"initialize-groups");
lf[347]=C_h_intern(&lf[347],26,"memory-mapped-file-pointer");
lf[348]=C_h_intern(&lf[348],17,"parent-process-id");
lf[349]=C_h_intern(&lf[349],12,"process-fork");
lf[350]=C_h_intern(&lf[350],16,"process-group-id");
lf[351]=C_h_intern(&lf[351],14,"process-signal");
lf[352]=C_h_intern(&lf[352],18,"read-symbolic-link");
lf[353]=C_h_intern(&lf[353],10,"set-alarm!");
lf[354]=C_h_intern(&lf[354],13,"set-group-id!");
lf[355]=C_h_intern(&lf[355],11,"set-groups!");
lf[356]=C_h_intern(&lf[356],21,"set-process-group-id!");
lf[357]=C_h_intern(&lf[357],19,"set-root-directory!");
lf[358]=C_h_intern(&lf[358],16,"set-signal-mask!");
lf[359]=C_h_intern(&lf[359],12,"set-user-id!");
lf[360]=C_h_intern(&lf[360],11,"signal-mask");
lf[361]=C_h_intern(&lf[361],12,"signal-mask!");
lf[362]=C_h_intern(&lf[362],14,"signal-masked\077");
lf[363]=C_h_intern(&lf[363],14,"signal-unmask!");
lf[364]=C_h_intern(&lf[364],13,"terminal-name");
lf[365]=C_h_intern(&lf[365],14,"terminal-port\077");
lf[366]=C_h_intern(&lf[366],13,"terminal-size");
lf[367]=C_h_intern(&lf[367],22,"unmap-file-from-memory");
lf[368]=C_h_intern(&lf[368],16,"user-information");
lf[369]=C_h_intern(&lf[369],17,"utc-time->seconds");
lf[370]=C_h_intern(&lf[370],12,"string->time");
lf[371]=C_h_intern(&lf[371],16,"errno/wouldblock");
lf[372]=C_h_intern(&lf[372],5,"fifo\077");
lf[373]=C_h_intern(&lf[373],19,"memory-mapped-file\077");
lf[374]=C_h_intern(&lf[374],13,"map/anonymous");
lf[375]=C_h_intern(&lf[375],8,"map/file");
lf[376]=C_h_intern(&lf[376],9,"map/fixed");
lf[377]=C_h_intern(&lf[377],11,"map/private");
lf[378]=C_h_intern(&lf[378],10,"map/shared");
lf[379]=C_h_intern(&lf[379],10,"open/fsync");
lf[380]=C_h_intern(&lf[380],11,"open/noctty");
lf[381]=C_h_intern(&lf[381],13,"open/nonblock");
lf[382]=C_h_intern(&lf[382],9,"open/sync");
lf[383]=C_h_intern(&lf[383],10,"perm/isgid");
lf[384]=C_h_intern(&lf[384],10,"perm/isuid");
lf[385]=C_h_intern(&lf[385],10,"perm/isvtx");
lf[386]=C_h_intern(&lf[386],9,"prot/exec");
lf[387]=C_h_intern(&lf[387],9,"prot/none");
lf[388]=C_h_intern(&lf[388],9,"prot/read");
lf[389]=C_h_intern(&lf[389],10,"prot/write");
lf[390]=C_h_intern(&lf[390],11,"make-vector");
lf[391]=C_h_intern(&lf[391],17,"register-feature!");
lf[392]=C_h_intern(&lf[392],5,"posix");
C_register_lf2(lf,393,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1121,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t4);}

/* k1119 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1124,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1122 in k1119 */
static void C_ccall f_1124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1125 in k1122 in k1119 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 944  register-feature! */
t3=*((C_word*)lf[391]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[392]);}

/* k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[46],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1133,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[10]+1,lf[5]);
t5=C_mutate((C_word*)lf[11]+1,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[12]+1,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[13]+1,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[14]+1,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[15]+1,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[16]+1,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[24]+1,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[25]+1,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[26]+1,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[27]+1,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[28]+1,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[29]+1,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[30]+1,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[31]+1,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_u_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1186,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1227,tmp=(C_word)a,a+=2,tmp));
t34=*((C_word*)lf[43]+1);
t35=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1245,a[2]=t34,tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1290,tmp=(C_word)a,a+=2,tmp));
t37=*((C_word*)lf[51]+1);
t38=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1332,a[2]=t37,tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[55]+1,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[56]+1,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[57]+1,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1370,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1408,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1432,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1438,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1444,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1450,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1456,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1462,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1468,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1491,tmp=(C_word)a,a+=2,tmp));
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1496,tmp=(C_word)a,a+=2,tmp);
t53=C_mutate((C_word*)lf[71]+1,*((C_word*)lf[68]+1));
t54=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1507,a[2]=t52,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1129 stat-type */
f_1496(t54,lf[72]);}

/* k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1507,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1130 stat-type */
f_1496(t3,lf[73]);}

/* k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1511,2,t0,t1);}
t2=C_mutate((C_word*)lf[73]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1131 stat-type */
f_1496(t3,lf[74]);}

/* k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1515,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1132 stat-type */
f_1496(t3,lf[75]);}

/* k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1519,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1133 stat-type */
f_1496(t3,lf[76]);}

/* k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1523,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1134 stat-type */
f_1496(t3,lf[77]);}

/* k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word ab[98],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1527,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1,t1);
t3=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1529,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1569,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1630,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1657,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1684,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[4]+1);
t9=*((C_word*)lf[43]+1);
t10=*((C_word*)lf[94]+1);
t11=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1868,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[43]+1);
t14=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1895,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[102]+1);
t16=*((C_word*)lf[103]+1);
t17=*((C_word*)lf[104]+1);
t18=*((C_word*)lf[105]+1);
t19=*((C_word*)lf[106]+1);
t20=*((C_word*)lf[4]+1);
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1939,tmp=(C_word)a,a+=2,tmp);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1944,tmp=(C_word)a,a+=2,tmp);
t23=*((C_word*)lf[109]+1);
t24=*((C_word*)lf[98]+1);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1955,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=C_mutate((C_word*)lf[114]+1,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2011,a[2]=t18,a[3]=t16,a[4]=t23,a[5]=t25,a[6]=t17,a[7]=t15,a[8]=t19,a[9]=t21,a[10]=t20,a[11]=t22,tmp=(C_word)a,a+=12,tmp));
t27=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2368,tmp=(C_word)a,a+=2,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2380,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2386,tmp=(C_word)a,a+=2,tmp);
t30=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2404,a[2]=t28,a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp));
t31=C_mutate((C_word*)lf[136]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2440,a[2]=t28,a[3]=t29,a[4]=t27,tmp=(C_word)a,a+=5,tmp));
t32=C_mutate((C_word*)lf[137]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2476,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[140]+1,*((C_word*)lf[137]+1));
t34=*((C_word*)lf[134]+1);
t35=*((C_word*)lf[136]+1);
t36=*((C_word*)lf[137]+1);
t37=*((C_word*)lf[140]+1);
t38=C_mutate((C_word*)lf[141]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2495,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[142]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2519,a[2]=t35,a[3]=t37,tmp=(C_word)a,a+=4,tmp));
t40=C_mutate((C_word*)lf[143]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2543,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t41=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2563,a[2]=t35,a[3]=t37,tmp=(C_word)a,a+=4,tmp));
t42=C_mutate((C_word*)lf[147]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2583,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[149]+1,C_fix((C_word)SIGTERM));
t44=C_mutate((C_word*)lf[150]+1,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[151]+1,C_fix((C_word)SIGFPE));
t46=C_mutate((C_word*)lf[152]+1,C_fix((C_word)SIGILL));
t47=C_mutate((C_word*)lf[153]+1,C_fix((C_word)SIGSEGV));
t48=C_mutate((C_word*)lf[154]+1,C_fix((C_word)SIGABRT));
t49=C_mutate((C_word*)lf[155]+1,C_fix((C_word)SIGBREAK));
t50=C_set_block_item(lf[156],0,C_fix(0));
t51=C_set_block_item(lf[157],0,C_fix(0));
t52=C_set_block_item(lf[158],0,C_fix(0));
t53=C_set_block_item(lf[159],0,C_fix(0));
t54=C_set_block_item(lf[160],0,C_fix(0));
t55=C_set_block_item(lf[161],0,C_fix(0));
t56=C_set_block_item(lf[162],0,C_fix(0));
t57=C_set_block_item(lf[163],0,C_fix(0));
t58=C_set_block_item(lf[164],0,C_fix(0));
t59=C_set_block_item(lf[165],0,C_fix(0));
t60=C_set_block_item(lf[166],0,C_fix(0));
t61=C_set_block_item(lf[167],0,C_fix(0));
t62=C_set_block_item(lf[168],0,C_fix(0));
t63=C_set_block_item(lf[169],0,C_fix(0));
t64=C_set_block_item(lf[170],0,C_fix(0));
t65=C_set_block_item(lf[171],0,C_fix(0));
t66=C_set_block_item(lf[172],0,C_fix(0));
t67=C_set_block_item(lf[173],0,C_fix(0));
t68=C_set_block_item(lf[174],0,C_fix(0));
t69=(C_word)C_a_i_list(&a,7,*((C_word*)lf[149]+1),*((C_word*)lf[150]+1),*((C_word*)lf[151]+1),*((C_word*)lf[152]+1),*((C_word*)lf[153]+1),*((C_word*)lf[154]+1),*((C_word*)lf[155]+1));
t70=C_mutate((C_word*)lf[175]+1,t69);
t71=*((C_word*)lf[176]+1);
t72=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[2],a[3]=t71,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1450 make-vector */
t73=*((C_word*)lf[390]+1);
((C_proc4)(void*)(*((C_word*)t73+1)))(4,t73,t72,C_fix(256),C_SCHEME_FALSE);}

/* k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word t180;
C_word ab[226],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=C_mutate((C_word*)lf[177]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2652,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[178]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[179]+1,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[180]+1,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[181]+1,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[182]+1,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[183]+1,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[184]+1,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[185]+1,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[186]+1,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[187]+1,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[188]+1,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[189]+1,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[190]+1,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[191]+1,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[192]+1,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[193]+1,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[194]+1,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[195]+1,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[196]+1,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[197]+1,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[198]+1,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[199]+1,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[200]+1,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[201]+1,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[202]+1,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[203]+1,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[204]+1,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[205]+1,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[206]+1,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[207]+1,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[208]+1,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[209]+1,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[210]+1,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[211]+1,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[212]+1,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[213]+1,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[214]+1,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[215]+1,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[216]+1,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[217]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2730,tmp=(C_word)a,a+=2,tmp));
t44=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2760,tmp=(C_word)a,a+=2,tmp);
t45=C_mutate((C_word*)lf[219]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2784,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2790,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2796,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[222]+1,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[223]+1,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[224]+1,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2805,tmp=(C_word)a,a+=2,tmp);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2842,tmp=(C_word)a,a+=2,tmp);
t53=C_mutate((C_word*)lf[233]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2860,a[2]=t51,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[234]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2874,a[2]=t51,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[235]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2888,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[239]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2923,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[241]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2953,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[242]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2970,tmp=(C_word)a,a+=2,tmp));
t59=*((C_word*)lf[243]+1);
t60=C_mutate((C_word*)lf[244]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2985,a[2]=t59,tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[245]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3050,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[247]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3059,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[248]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3073,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[250]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3106,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[254]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3179,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[258]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3207,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[259]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3215,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[260]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3231,tmp=(C_word)a,a+=2,tmp));
t69=*((C_word*)lf[266]+1);
t70=*((C_word*)lf[267]+1);
t71=*((C_word*)lf[268]+1);
t72=*((C_word*)lf[269]+1);
t73=*((C_word*)lf[95]+1);
t74=*((C_word*)lf[270]+1);
t75=*((C_word*)lf[271]+1);
t76=C_mutate((C_word*)lf[272]+1,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3290,a[2]=t72,a[3]=t70,a[4]=t69,a[5]=t73,a[6]=t71,a[7]=t74,a[8]=t75,tmp=(C_word)a,a+=9,tmp));
t77=C_mutate((C_word*)lf[275]+1,C_fix((C_word)P_OVERLAY));
t78=C_mutate((C_word*)lf[276]+1,C_fix((C_word)P_WAIT));
t79=C_mutate((C_word*)lf[277]+1,C_fix((C_word)P_NOWAIT));
t80=C_mutate((C_word*)lf[278]+1,C_fix((C_word)P_NOWAITO));
t81=C_mutate((C_word*)lf[279]+1,C_fix((C_word)P_DETACH));
t82=*((C_word*)lf[280]+1);
t83=*((C_word*)lf[51]+1);
t84=*((C_word*)lf[106]+1);
t85=*((C_word*)lf[4]+1);
t86=C_mutate(&lf[281],(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3405,a[2]=t85,a[3]=t83,a[4]=t84,a[5]=t82,tmp=(C_word)a,a+=6,tmp));
t87=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3484,tmp=(C_word)a,a+=2,tmp);
t88=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3490,tmp=(C_word)a,a+=2,tmp);
t89=*((C_word*)lf[284]+1);
t90=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3496,tmp=(C_word)a,a+=2,tmp);
t91=C_mutate(&lf[285],(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3546,a[2]=t89,a[3]=t87,a[4]=t88,a[5]=t90,tmp=(C_word)a,a+=6,tmp));
t92=C_mutate(&lf[286],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3579,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3594,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[289]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3678,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[291]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3762,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[292]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3765,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[296]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3786,tmp=(C_word)a,a+=2,tmp));
t98=*((C_word*)lf[289]+1);
t99=*((C_word*)lf[294]+1);
t100=C_mutate((C_word*)lf[298]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3792,a[2]=t98,tmp=(C_word)a,a+=3,tmp));
t101=C_mutate(&lf[299],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3821,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[300]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3875,tmp=(C_word)a,a+=2,tmp));
t103=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3971,tmp=(C_word)a,a+=2,tmp);
t104=C_mutate((C_word*)lf[306]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4033,a[2]=t103,tmp=(C_word)a,a+=3,tmp));
t105=C_mutate((C_word*)lf[307]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4110,a[2]=t103,tmp=(C_word)a,a+=3,tmp));
t106=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4187,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4199,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[311]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4256,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[312]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4259,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[314]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4271,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4302,tmp=(C_word)a,a+=2,tmp));
t112=*((C_word*)lf[272]+1);
t113=*((C_word*)lf[268]+1);
t114=*((C_word*)lf[270]+1);
t115=*((C_word*)lf[99]+1);
t116=C_mutate((C_word*)lf[318]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4317,a[2]=t115,a[3]=t114,a[4]=t112,a[5]=t113,tmp=(C_word)a,a+=6,tmp));
t117=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4540,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4546,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[329]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4552,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4558,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[331]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4564,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4570,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4576,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[334]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4582,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[335]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4588,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4594,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[337]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4600,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[338]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4606,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4612,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[340]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4618,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[341]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4624,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4630,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[343]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4636,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[344]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4642,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[345]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4648,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[346]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4654,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[347]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4660,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[348]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4666,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[349]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4672,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[350]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4678,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[351]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4684,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[352]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4690,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[353]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4696,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[354]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4702,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[355]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4708,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[356]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4714,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[357]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4720,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[358]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4726,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[359]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4732,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[360]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4738,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4744,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[362]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4750,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[363]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4756,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4762,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[365]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4768,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[366]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4774,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4780,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[368]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4786,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4792,tmp=(C_word)a,a+=2,tmp));
t160=C_mutate((C_word*)lf[370]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4798,tmp=(C_word)a,a+=2,tmp));
t161=C_set_block_item(lf[371],0,C_fix(0));
t162=C_mutate((C_word*)lf[372]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4805,tmp=(C_word)a,a+=2,tmp));
t163=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4808,tmp=(C_word)a,a+=2,tmp));
t164=C_set_block_item(lf[374],0,C_fix(0));
t165=C_set_block_item(lf[375],0,C_fix(0));
t166=C_set_block_item(lf[376],0,C_fix(0));
t167=C_set_block_item(lf[377],0,C_fix(0));
t168=C_set_block_item(lf[378],0,C_fix(0));
t169=C_set_block_item(lf[379],0,C_fix(0));
t170=C_set_block_item(lf[380],0,C_fix(0));
t171=C_set_block_item(lf[381],0,C_fix(0));
t172=C_set_block_item(lf[382],0,C_fix(0));
t173=C_set_block_item(lf[383],0,C_fix(0));
t174=C_set_block_item(lf[384],0,C_fix(0));
t175=C_set_block_item(lf[385],0,C_fix(0));
t176=C_set_block_item(lf[386],0,C_fix(0));
t177=C_set_block_item(lf[387],0,C_fix(0));
t178=C_set_block_item(lf[388],0,C_fix(0));
t179=C_set_block_item(lf[389],0,C_fix(0));
t180=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t180+1)))(2,t180,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4808,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4805,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* string->time in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4798(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4798,2,t0,t1);}
/* posixwin.scm: 2092 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[370],lf[0]);}

/* utc-time->seconds in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4792,2,t0,t1);}
/* posixwin.scm: 2091 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[369],lf[0]);}

/* user-information in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4786(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4786,2,t0,t1);}
/* posixwin.scm: 2090 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[368],lf[0]);}

/* unmap-file-from-memory in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4780(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4780,2,t0,t1);}
/* posixwin.scm: 2089 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[367],lf[0]);}

/* terminal-size in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4774,2,t0,t1);}
/* posixwin.scm: 2088 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[366],lf[0]);}

/* terminal-port? in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4768(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4768,2,t0,t1);}
/* posixwin.scm: 2087 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[365],lf[0]);}

/* terminal-name in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4762,2,t0,t1);}
/* posixwin.scm: 2086 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[364],lf[0]);}

/* signal-unmask! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4756,2,t0,t1);}
/* posixwin.scm: 2085 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[363],lf[0]);}

/* signal-masked? in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
/* posixwin.scm: 2084 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[362],lf[0]);}

/* signal-mask! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
/* posixwin.scm: 2083 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[361],lf[0]);}

/* signal-mask in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
/* posixwin.scm: 2082 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[360],lf[0]);}

/* set-user-id! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4732,2,t0,t1);}
/* posixwin.scm: 2081 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[359],lf[0]);}

/* set-signal-mask! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4726,2,t0,t1);}
/* posixwin.scm: 2080 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[358],lf[0]);}

/* set-root-directory! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
/* posixwin.scm: 2079 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[357],lf[0]);}

/* set-process-group-id! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4714(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4714,2,t0,t1);}
/* posixwin.scm: 2078 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[356],lf[0]);}

/* set-groups! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4708,2,t0,t1);}
/* posixwin.scm: 2077 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[355],lf[0]);}

/* set-group-id! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4702,2,t0,t1);}
/* posixwin.scm: 2076 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[354],lf[0]);}

/* set-alarm! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4696,2,t0,t1);}
/* posixwin.scm: 2075 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[353],lf[0]);}

/* read-symbolic-link in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4690,2,t0,t1);}
/* posixwin.scm: 2074 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[352],lf[0]);}

/* process-signal in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
/* posixwin.scm: 2073 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[351],lf[0]);}

/* process-group-id in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
/* posixwin.scm: 2072 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[350],lf[0]);}

/* process-fork in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4672(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4672,2,t0,t1);}
/* posixwin.scm: 2071 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[349],lf[0]);}

/* parent-process-id in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4666,2,t0,t1);}
/* posixwin.scm: 2070 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[348],lf[0]);}

/* memory-mapped-file-pointer in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4660,2,t0,t1);}
/* posixwin.scm: 2069 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[347],lf[0]);}

/* initialize-groups in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
/* posixwin.scm: 2068 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[346],lf[0]);}

/* group-information in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
/* posixwin.scm: 2067 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[345],lf[0]);}

/* get-groups in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4642(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4642,2,t0,t1);}
/* posixwin.scm: 2066 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[344],lf[0]);}

/* file-unlock in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4636,2,t0,t1);}
/* posixwin.scm: 2065 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[343],lf[0]);}

/* file-truncate in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4630,2,t0,t1);}
/* posixwin.scm: 2064 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[342],lf[0]);}

/* file-test-lock in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
/* posixwin.scm: 2063 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[341],lf[0]);}

/* file-select in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
/* posixwin.scm: 2062 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[340],lf[0]);}

/* file-lock/blocking in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4612,2,t0,t1);}
/* posixwin.scm: 2061 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[339],lf[0]);}

/* file-lock in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4606,2,t0,t1);}
/* posixwin.scm: 2060 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[338],lf[0]);}

/* file-link in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4600(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4600,2,t0,t1);}
/* posixwin.scm: 2059 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[337],lf[0]);}

/* map-file-to-memory in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4594,2,t0,t1);}
/* posixwin.scm: 2058 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[336],lf[0]);}

/* current-user-id in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4588,2,t0,t1);}
/* posixwin.scm: 2057 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[335],lf[0]);}

/* current-group-id in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4582,2,t0,t1);}
/* posixwin.scm: 2056 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[334],lf[0]);}

/* current-effective-user-name in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
/* posixwin.scm: 2055 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[333],lf[0]);}

/* current-effective-user-id in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4570(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4570,2,t0,t1);}
/* posixwin.scm: 2054 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[332],lf[0]);}

/* current-effective-group-id in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4564,2,t0,t1);}
/* posixwin.scm: 2053 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[331],lf[0]);}

/* create-symbolic-link in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4558,2,t0,t1);}
/* posixwin.scm: 2052 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[330],lf[0]);}

/* create-session in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4552(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4552,2,t0,t1);}
/* posixwin.scm: 2051 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[329],lf[0]);}

/* create-fifo in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
/* posixwin.scm: 2050 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[328],lf[0]);}

/* change-file-owner in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4540,2,t0,t1);}
/* posixwin.scm: 2049 error */
t2=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[326],lf[0]);}

/* find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_4317r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4317r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4317r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4464,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4469,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4474,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action786820 */
t9=t8;
f_4474(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id787818 */
t11=t7;
f_4469(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit788815 */
t13=t6;
f_4464(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body784790 */
t15=t5;
f_4319(t15,t1,t9,t11,t13);}}}}

/* def-action786 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4474(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4474,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4480,tmp=(C_word)a,a+=2,tmp);
/* def-id787818 */
t3=((C_word*)t0)[2];
f_4469(t3,t1,t2);}

/* a4479 in def-action786 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4480,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id787 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4469(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4469,NULL,3,t0,t1,t2);}
/* def-limit788815 */
t3=((C_word*)t0)[2];
f_4464(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit788 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4464(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4464,NULL,4,t0,t1,t2,t3);}
/* body784790 */
t4=((C_word*)t0)[2];
f_4319(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4319(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4319,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[318]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_4326(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4459,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp):t4));}
else{
t10=t8;
f_4326(t10,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4451,tmp=(C_word)a,a+=2,tmp));}}

/* f_4451 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4459 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4459(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4459,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4326,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4439,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2027 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],lf[325]);}

/* k4437 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2027 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4336,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4338,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_4338(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4338(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4338,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 2033 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k4355 in loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4357,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 2034 pathname-file */
t3=*((C_word*)lf[324]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 2040 pproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}

/* k4423 in k4355 in loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4425,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4432,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 2040 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 2041 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_4338(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4430 in k4423 in k4355 in loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2040 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4338(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4417 in k4355 in loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4419,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[319]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[320]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 2034 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_4338(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4372,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 2035 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k4370 in k4417 in k4355 in loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4372,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4384,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4406,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 2037 ##sys#dynamic-wind */
t11=*((C_word*)lf[323]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 2039 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_4338(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a4405 in k4370 in k4417 in k4355 in loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[321]+1));}

/* a4391 in k4370 in k4417 in k4355 in loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4404,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 2038 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[322]);}

/* k4402 in a4391 in k4370 in k4417 in k4355 in loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2038 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4398 in a4391 in k4370 in k4417 in k4355 in loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2038 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4338(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a4383 in k4370 in k4417 in k4355 in loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4384,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[321]+1));}

/* k4380 in k4370 in k4417 in k4355 in loop in k4334 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2036 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4338(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_4443 in k4324 in body784 in find-files in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4443,3,t0,t1,t2);}
/* posixwin.scm: 2025 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4302,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4312,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 2001 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4310 in current-user-name in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 2002 ##sys#error */
t2=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[109],lf[317]);}

/* system-information in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4271,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4282,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4297,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1992 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4295 in system-information in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1993 ##sys#error */
t2=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[314],lf[316]);}

/* k4280 in system-information in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4286,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k4284 in k4280 in system-information in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4290,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k4288 in k4284 in k4280 in system-information in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4294,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k4292 in k4288 in k4284 in k4280 in system-information in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4294,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[315],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4259,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 1982 ##sys#error */
t2=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[312],lf[313]);}}

/* sleep in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4256,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4199r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4199r(t0,t1,t2,t3);}}

static void C_ccall f_4199r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_check_exact_2(t2,lf[309]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4217,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4223,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1961 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a4222 in process-wait in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4223,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4233,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1964 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1966 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k4231 in a4222 in process-wait in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1965 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[301],lf[309],lf[310],((C_word*)t0)[2]);}

/* a4216 in process-wait in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
/* posixwin.scm: 1961 ##sys#process-wait */
t2=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4187,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 1954 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 1955 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_4110r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4110r(t0,t1,t2,t3);}}

static void C_ccall f_4110r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4112,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4117,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4122,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4127,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args735748 */
t8=t7;
f_4127(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env736746 */
t10=t6;
f_4122(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf737743 */
t12=t5;
f_4117(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body733739 */
t14=t4;
f_4112(t14,t1,t8,t10,t12);}}}}

/* def-args735 in process* in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4127,NULL,2,t0,t1);}
/* def-env736746 */
t2=((C_word*)t0)[2];
f_4122(t2,t1,C_SCHEME_FALSE);}

/* def-env736 in process* in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4122(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4122,NULL,3,t0,t1,t2);}
/* def-exactf737743 */
t3=((C_word*)t0)[2];
f_4117(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf737 in process* in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4117(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4117,NULL,4,t0,t1,t2,t3);}
/* body733739 */
t4=((C_word*)t0)[2];
f_4112(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body733 in process* in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4112(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4112,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1948 %process */
f_3971(t1,lf[307],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_4033r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4033r(t0,t1,t2,t3);}}

static void C_ccall f_4033r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4035,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4040,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4045,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4050,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args707720 */
t8=t7;
f_4050(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env708718 */
t10=t6;
f_4045(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf709715 */
t12=t5;
f_4040(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body705711 */
t14=t4;
f_4035(t14,t1,t8,t10,t12);}}}}

/* def-args707 in process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4050,NULL,2,t0,t1);}
/* def-env708718 */
t2=((C_word*)t0)[2];
f_4045(t2,t1,C_SCHEME_FALSE);}

/* def-env708 in process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4045,NULL,3,t0,t1,t2);}
/* def-exactf709715 */
t3=((C_word*)t0)[2];
f_4040(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf709 in process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4040(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4040,NULL,4,t0,t1,t2,t3);}
/* body705711 */
t4=((C_word*)t0)[2];
f_4035(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body705 in process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_4035(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4035,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1945 %process */
f_3971(t1,lf[306],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3971(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3971,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3973,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3992,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1933 chkstrlst */
t14=t11;
f_3973(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4027,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1936 ##sys#shell-command-arguments */
t16=*((C_word*)lf[296]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,((C_word*)t8)[1]);}}

/* k4025 in %process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4027,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1937 ##sys#shell-command */
t4=*((C_word*)lf[292]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4029 in k4025 in %process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3992(2,t3,t2);}

/* k3990 in %process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
/* posixwin.scm: 1938 chkstrlst */
t3=((C_word*)t0)[2];
f_3973(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_3995(2,t3,C_SCHEME_UNDEFINED);}}

/* k3993 in k3990 in %process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4006,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1939 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4005 in k3993 in k3990 in %process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4006,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1941 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1942 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a3999 in k3993 in k3990 in %process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
/* posixwin.scm: 1939 ##sys#process */
t2=*((C_word*)lf[300]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3973(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3973,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3982,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[305]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a3981 in chkstrlst in %process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3982,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr9rv,(void*)f_3875r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest_vector(a,C_rest_count(0));
f_3875r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_3875r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(14);
t10=(C_word)C_vemptyp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:(C_word)C_slot(t9,C_fix(0)));
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3882,a[2]=t2,a[3]=t6,a[4]=t7,a[5]=t8,a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3954,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_a_i_cons(&a,2,t3,t4);
/* posixwin.scm: 1905 $quote-args-list */
t15=lf[281];
f_3405(t15,t13,t14,t11);}

/* k3952 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1905 string-intersperse */
t2=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=((*(int *)C_data_pointer(t2))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t5=((*(int *)C_data_pointer(t4))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t7=((*(int *)C_data_pointer(t6))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=((*(int *)C_data_pointer(t8))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t10=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3922,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
t11=*((C_word*)lf[303]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,t2,C_fix(0),C_SCHEME_FALSE,lf[304]);}

/* k3920 in k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[303]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[304]);}

/* k3924 in k3920 in k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[303]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[304]);}

/* k3928 in k3924 in k3920 in k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[303]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[304]);}

/* k3932 in k3928 in k3924 in k3920 in k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
/* posixwin.scm: 1912 + */
C_plus(5,0,t2,t3,t4,t5);}

/* k3936 in k3932 in k3928 in k3924 in k3920 in k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3938,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3829,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t9=t8;
f_3829(2,t9,C_SCHEME_FALSE);}}

/* k3827 in k3936 in k3932 in k3928 in k3924 in k3920 in k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3833(2,t3,C_SCHEME_FALSE);}}

/* k3831 in k3827 in k3936 in k3932 in k3928 in k3924 in k3920 in k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3833,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
if(C_truep((C_word)stub615(C_SCHEME_UNDEFINED,((C_word*)t0)[13],t1,C_SCHEME_FALSE,t2,t3,t4,t5,((C_word*)t0)[12]))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1915 open-input-file* */
t7=*((C_word*)lf[233]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t7=t6;
f_3895(2,t7,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1920 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3913 in k3831 in k3827 in k3936 in k3932 in k3928 in k3924 in k3920 in k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1921 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[301],((C_word*)t0)[3],lf[302],((C_word*)t0)[2]);}

/* k3893 in k3831 in k3827 in k3936 in k3932 in k3928 in k3924 in k3920 in k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3899,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1916 open-output-file* */
t3=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_3899(2,t3,C_SCHEME_FALSE);}}

/* k3897 in k3893 in k3831 in k3827 in k3936 in k3932 in k3928 in k3924 in k3920 in k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3903,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1918 open-input-file* */
t3=*((C_word*)lf[233]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_3903(2,t3,C_SCHEME_FALSE);}}

/* k3901 in k3897 in k3893 in k3831 in k3827 in k3936 in k3932 in k3928 in k3924 in k3920 in k3880 in ##sys#process in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1914 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* close-handle in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3821,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub603(C_SCHEME_UNDEFINED,t2));}

/* process-run in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3792r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3792r(t0,t1,t2,t3);}}

static void C_ccall f_3792r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1873 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,*((C_word*)lf[277]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3809,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1874 ##sys#shell-command */
t7=*((C_word*)lf[292]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3807 in process-run in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3813,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1874 ##sys#shell-command-arguments */
t3=*((C_word*)lf[296]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3811 in k3807 in process-run in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1874 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[277]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3786,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[297],t2));}

/* ##sys#shell-command in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3769,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1857 getenv */
t3=*((C_word*)lf[294]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[295]);}

/* k3767 in ##sys#shell-command in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3769,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3781,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1861 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k3779 in k3767 in ##sys#shell-command in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1862 ##sys#error */
t2=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[292],lf[293]);}

/* current-process-id in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3762,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub591(C_SCHEME_UNDEFINED));}

/* process-spawn in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3678r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3678r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3678r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3680,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3692,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3697,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3702,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst570584 */
t9=t8;
f_3702(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst571582 */
t11=t7;
f_3697(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf572579 */
t13=t6;
f_3692(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body568574 */
t15=t5;
f_3680(t15,t1,t9,t11,t13);}}}}

/* def-arglst570 in process-spawn in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3702(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3702,NULL,2,t0,t1);}
/* def-envlst571582 */
t2=((C_word*)t0)[2];
f_3697(t2,t1,C_SCHEME_FALSE);}

/* def-envlst571 in process-spawn in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3697(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3697,NULL,3,t0,t1,t2);}
/* def-exactf572579 */
t3=((C_word*)t0)[2];
f_3692(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf572 in process-spawn in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3692(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3692,NULL,4,t0,t1,t2,t3);}
/* body568574 */
t4=((C_word*)t0)[2];
f_3680(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body568 in process-spawn in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3680(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3680,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3684,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1848 $exec-setup */
t6=lf[285];
f_3546(t6,t5,lf[289],((C_word*)t0)[2],t2,t3,t4);}

/* k3682 in body568 in process-spawn in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
/* posixwin.scm: 1849 $exec-teardown */
f_3579(((C_word*)t0)[3],lf[289],lf[290],((C_word*)t0)[2],t2);}

/* process-execute in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3594(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_3594r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3594r(t0,t1,t2,t3);}}

static void C_ccall f_3594r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3596,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3608,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3618,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst540554 */
t8=t7;
f_3618(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst541552 */
t10=t6;
f_3613(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf542549 */
t12=t5;
f_3608(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body538544 */
t14=t4;
f_3596(t14,t1,t8,t10,t12);}}}}

/* def-arglst540 in process-execute in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3618,NULL,2,t0,t1);}
/* def-envlst541552 */
t2=((C_word*)t0)[2];
f_3613(t2,t1,C_SCHEME_FALSE);}

/* def-envlst541 in process-execute in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3613(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3613,NULL,3,t0,t1,t2);}
/* def-exactf542549 */
t3=((C_word*)t0)[2];
f_3608(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf542 in process-execute in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3608(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3608,NULL,4,t0,t1,t2,t3);}
/* body538544 */
t4=((C_word*)t0)[2];
f_3596(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body538 in process-execute in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3596(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3596,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3600,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1843 $exec-setup */
t6=lf[285];
f_3546(t6,t5,lf[287],((C_word*)t0)[2],t2,t3,t4);}

/* k3598 in body538 in process-execute in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
/* posixwin.scm: 1844 $exec-teardown */
f_3579(((C_word*)t0)[3],lf[287],lf[288],((C_word*)t0)[2],t2);}

/* $exec-teardown in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3579(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3579,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3583,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1835 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3581 in $exec-teardown in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1839 ##sys#error */
t5=*((C_word*)lf[128]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3546(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3546,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3553,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1827 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}

/* k3551 in $exec-setup in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
/* posixwin.scm: 1828 setarg */
t4=((C_word*)t0)[4];
f_3484(5,t4,t2,C_fix(0),t1,t3);}

/* k3554 in k3551 in $exec-setup in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3559,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3573,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1829 $quote-args-list */
t4=lf[281];
f_3405(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3571 in k3554 in k3551 in $exec-setup in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1829 build-exec-argvec */
f_3496(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k3557 in k3554 in k3551 in $exec-setup in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1830 build-exec-argvec */
f_3496(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k3560 in k3557 in k3554 in k3551 in $exec-setup in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3562,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1832 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3567 in k3560 in k3557 in k3554 in k3551 in $exec-setup in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1832 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3496(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3496,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3508,a[2]=t8,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3508(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1824 argvec-setter */
t6=t4;
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* do505 in build-exec-argvec in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3508(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3508,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1820 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3527,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1823 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t3,t4,t7);}}

/* k3525 in do505 in build-exec-argvec in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3508(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3490,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub494(C_SCHEME_UNDEFINED,t2,t5,t4));}

/* setarg in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3484,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub484(C_SCHEME_UNDEFINED,t2,t5,t4));}

/* $quote-args-list in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3405(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3405,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3448,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3448(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3448(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3448,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1801 reverse */
t4=*((C_word*)lf[116]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3476,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3479,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1806 needs-quoting? */
t8=((C_word*)t0)[2];
f_3410(t8,t7,t4);}}

/* k3477 in loop in $quote-args-list in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1806 string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[282],((C_word*)t0)[2],lf[283]);}
else{
t2=((C_word*)t0)[3];
f_3476(2,t2,((C_word*)t0)[2]);}}

/* k3474 in loop in $quote-args-list in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3476,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1803 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3448(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3410(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3410,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3414,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1793 string-length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3412 in needs-quoting? in $quote-args-list in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3414,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3419,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3419(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k3412 in needs-quoting? in $quote-args-list in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3419(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3419,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3432,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3443,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1797 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k3441 in loop in k3412 in needs-quoting? in $quote-args-list in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1797 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3430 in loop in k3412 in needs-quoting? in $quote-args-list in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1798 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3419(t3,((C_word*)t0)[4],t2);}}

/* glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_3290r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3290r(t0,t1,t2);}}

static void C_ccall f_3290r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3296(t6,t1,t2);}

/* conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3296(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3296,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3311,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a3316 in conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3317,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3321,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3394,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[274]);
/* posixwin.scm: 1754 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k3392 in a3316 in conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1754 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3319 in a3316 in conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1755 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3322 in k3319 in a3316 in conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1756 regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3325 in k3322 in k3319 in a3316 in conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[273]);
/* posixwin.scm: 1757 directory */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k3332 in k3325 in k3322 in k3319 in a3316 in conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3334,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3336(t5,((C_word*)t0)[2],t1);}

/* loop in k3332 in k3325 in k3322 in k3319 in a3316 in conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3336(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3336,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* posixwin.scm: 1758 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3296(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3353,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixwin.scm: 1759 string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k3351 in loop in k3332 in k3325 in k3322 in k3319 in a3316 in conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3353,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(t1);
/* posixwin.scm: 1760 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* posixwin.scm: 1761 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3336(t3,((C_word*)t0)[6],t2);}}

/* k3361 in k3351 in loop in k3332 in k3325 in k3322 in k3319 in a3316 in conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3367,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1760 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3336(t4,t2,t3);}

/* k3365 in k3361 in k3351 in loop in k3332 in k3325 in k3322 in k3319 in a3316 in conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3367,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a3310 in conc-loop in glob in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
/* posixwin.scm: 1753 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3231r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3231r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3231r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3235,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1724 ##sys#check-port */
t6=*((C_word*)lf[139]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[260]);}

/* k3233 in set-buffering-mode! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[262]);
if(C_truep(t6)){
t7=t5;
f_3241(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[263]);
if(C_truep(t7)){
t8=t5;
f_3241(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[264]);
if(C_truep(t8)){
t9=t5;
f_3241(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1730 ##sys#error */
t9=*((C_word*)lf[128]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[260],lf[265],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k3239 in k3233 in set-buffering-mode! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[260]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[80],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1736 ##sys#error */
t6=*((C_word*)lf[128]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[260],lf[261],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* _exit in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3215r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3215r(t0,t1,t2);}}

static void C_ccall f_3215r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub413(C_SCHEME_UNDEFINED,t4));}

/* local-timezone-abbreviation in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3207,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub408(t2),C_fix(0));}

/* local-time->seconds in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3179,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[254]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3186,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1700 ##sys#error */
t6=*((C_word*)lf[128]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[254],lf[257],t2);}
else{
t6=t4;
f_3186(2,t6,C_SCHEME_UNDEFINED);}}

/* k3184 in local-time->seconds in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixwin.scm: 1702 ##sys#cons-flonum */
t2=*((C_word*)lf[255]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1703 ##sys#error */
t2=*((C_word*)lf[128]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[254],lf[256],((C_word*)t0)[3]);}}

/* time->string in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3106r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3106r(t0,t1,t2,t3);}}

static void C_ccall f_3106r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_vector_2(t2,lf[250]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3116,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(10)))){
/* posixwin.scm: 1687 ##sys#error */
t9=*((C_word*)lf[128]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,lf[250],lf[253],t2);}
else{
t9=t7;
f_3116(2,t9,C_SCHEME_UNDEFINED);}}

/* k3114 in time->string in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3116,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[250]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3135,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1691 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub382(t4,t3),C_fix(0));}}

/* k3136 in k3114 in time->string in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1695 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1696 ##sys#error */
t2=*((C_word*)lf[128]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[250],lf[252],((C_word*)t0)[2]);}}

/* k3133 in k3114 in time->string in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub388(t3,t2,t1),C_fix(0));}

/* k3123 in k3114 in time->string in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixwin.scm: 1692 ##sys#error */
t2=*((C_word*)lf[128]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[250],lf[251],((C_word*)t0)[2]);}}

/* seconds->string in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3073,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3077,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub373(t5,t4),C_fix(0));}

/* k3075 in seconds->string in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1679 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixwin.scm: 1680 ##sys#error */
t2=*((C_word*)lf[128]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[248],lf[249],((C_word*)t0)[2]);}}

/* seconds->utc-time in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3059,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[247]);
/* posixwin.scm: 1672 ##sys#decode-seconds */
t4=*((C_word*)lf[246]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3050,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[245]);
/* posixwin.scm: 1668 ##sys#decode-seconds */
t4=*((C_word*)lf[246]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* current-environment in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2985,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2991(t5,t1,C_fix(0));}

/* loop in current-environment in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2991(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2991,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2995,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub356(t5,t4),C_fix(0));}

/* k2993 in loop in current-environment in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2995,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3003,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3003(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k2993 in loop in current-environment in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_3003(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3003,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1660 substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1661 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k3027 in scan in k2993 in loop in current-environment in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1660 substring */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k3031 in k3027 in scan in k2993 in loop in current-environment in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3021,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1660 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2991(t5,t3,t4);}

/* k3019 in k3031 in k3027 in scan in k2993 in loop in current-environment in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3021,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2970,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[242]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2978,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1648 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2976 in unsetenv in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2953,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[241]);
t5=(C_word)C_i_check_string_2(t3,lf[241]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2964,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1643 ##sys#make-c-string */
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k2962 in setenv in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1643 ##sys#make-c-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2966 in k2962 in setenv in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2923r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2923r(t0,t1,t2,t3);}}

static void C_ccall f_2923r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[239]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2930,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_2930(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[239]);
t8=t5;
f_2930(t8,(C_word)C_dup2(t2,t6));}}

/* k2928 in duplicate-fileno in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2930(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2930,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2933,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1633 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2933(2,t3,C_SCHEME_UNDEFINED);}}

/* k2937 in k2928 in duplicate-fileno in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1634 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[239],lf[240],((C_word*)t0)[2]);}

/* k2931 in k2928 in duplicate-fileno in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2888,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2892,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1615 ##sys#check-port */
t4=*((C_word*)lf[139]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[235]);}

/* k2890 in port->fileno in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1616 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k2919 in k2890 in port->fileno in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2921,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1622 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[46],lf[235],lf[236],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2901,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2907,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1619 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_2901(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2905 in k2919 in k2890 in port->fileno in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1620 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[235],lf[237],((C_word*)t0)[2]);}

/* k2899 in k2919 in k2890 in port->fileno in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2874r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2874r(t0,t1,t2,t3);}}

static void C_ccall f_2874r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[234]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2886,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1611 mode */
f_2805(t5,C_SCHEME_FALSE,t3);}

/* k2884 in open-output-file* in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1611 check */
f_2842(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2860r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2860r(t0,t1,t2,t3);}}

static void C_ccall f_2860r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[233]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2872,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1607 mode */
f_2805(t5,C_SCHEME_TRUE,t3);}

/* k2870 in open-input-file* in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1607 check */
f_2842(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2842(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2842,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2846,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1598 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2844 in check in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1600 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[231],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1601 ##sys#make-port */
t3=*((C_word*)lf[131]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[132]+1),lf[232],lf[80]);}}

/* k2856 in k2844 in check in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2805(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2805,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2813,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[225]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1593 ##sys#error */
t8=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[226],t5);}
else{
t8=t4;
f_2813(2,t8,lf[227]);}}
else{
/* posixwin.scm: 1594 ##sys#error */
t7=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[228],t5);}}
else{
t5=t4;
f_2813(2,t5,(C_truep(t2)?lf[229]:lf[230]));}}

/* k2811 in mode in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1589 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2796,3,t0,t1,t2);}
/* posixwin.scm: 1573 check */
f_2760(t1,t2,C_fix((C_word)2),lf[221]);}

/* file-write-access? in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2790,3,t0,t1,t2);}
/* posixwin.scm: 1572 check */
f_2760(t1,t2,C_fix((C_word)4),lf[220]);}

/* file-read-access? in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2784,3,t0,t1,t2);}
/* posixwin.scm: 1571 check */
f_2760(t1,t2,C_fix((C_word)2),lf[219]);}

/* check in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2760(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2760,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2778,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2782,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1568 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k2780 in check in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1568 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2776 in check in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2778,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2770(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1569 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2768 in k2776 in check in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2730,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[217]);
t5=(C_word)C_i_check_exact_2(t3,lf[217]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2754,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2758,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1557 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k2756 in change-file-mode in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1557 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2752 in change-file-mode in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2746,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1558 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2744 in k2752 in change-file-mode in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1559 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[217],lf[218],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2674,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2684,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1465 h */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1467 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k2682 in ##sys#interrupt-hook in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1466 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2661,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[178]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k2648 in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2652,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[177]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2583r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2583r(t0,t1,t2);}}

static void C_ccall f_2583r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?(C_word)C_u_fixnum_or(*((C_word*)lf[21]+1),*((C_word*)lf[23]+1)):(C_word)C_slot(t2,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2590,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t4),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1402 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_2590(2,t6,C_SCHEME_UNDEFINED);}}

/* k2597 in create-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1403 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[37],lf[147],lf[148]);}

/* k2588 in create-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1404 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2563r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2563r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2563r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[146]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2567,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2565 in with-output-to-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2567,2,t0,t1);}
t2=C_mutate((C_word*)lf[146]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2573,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1387 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2572 in k2565 in with-output-to-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2573r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2573r(t0,t1,t2);}}

static void C_ccall f_2573r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2577,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1389 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2575 in a2572 in k2565 in with-output-to-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[146]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2543r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2543r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2543r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[144]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2547,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2545 in with-input-from-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2547,2,t0,t1);}
t2=C_mutate((C_word*)lf[144]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2553,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1377 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2552 in k2545 in with-input-from-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2553r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2553r(t0,t1,t2);}}

static void C_ccall f_2553r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2557,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1379 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2555 in a2552 in k2545 in with-input-from-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[144]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2519r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2519r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2519r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2523,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2521 in call-with-output-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2528,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2534,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1367 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2533 in k2521 in call-with-output-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2534r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2534r(t0,t1,t2);}}

static void C_ccall f_2534r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2538,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1370 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2536 in a2533 in k2521 in call-with-output-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2527 in k2521 in call-with-output-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2528,2,t0,t1);}
/* posixwin.scm: 1368 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2495r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2495r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2495r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2499,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2497 in call-with-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2504,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2510,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1359 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2509 in k2497 in call-with-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2510r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2510r(t0,t1,t2);}}

static void C_ccall f_2510r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2514,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1362 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2512 in a2509 in k2497 in call-with-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2503 in k2497 in call-with-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
/* posixwin.scm: 1360 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2476,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2480,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1346 ##sys#check-port */
t4=*((C_word*)lf[139]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[137]);}

/* k2478 in close-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1348 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2481 in k2478 in close-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1349 ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[37],lf[137],lf[138],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2440r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2440r(t0,t1,t2,t3);}}

static void C_ccall f_2440r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[136]);
t5=f_2368(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2454,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[127]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2461,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1341 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[135]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2471,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1342 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1343 badmode */
f_2380(t6,t5);}}}

/* k2469 in open-output-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2454(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k2459 in open-output-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2461,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2454(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k2452 in open-output-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1338 check */
f_2386(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2404r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2404r(t0,t1,t2,t3);}}

static void C_ccall f_2404r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[134]);
t5=f_2368(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2418,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[127]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2425,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1331 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[135]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2435,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1332 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1333 badmode */
f_2380(t6,t5);}}}

/* k2433 in open-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2435,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2418(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k2423 in open-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2425,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2418(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k2416 in open-input-pipe in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1328 check */
f_2386(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2386(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2386,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2390,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1318 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2388 in check in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2390,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1320 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[130],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1321 ##sys#make-port */
t3=*((C_word*)lf[131]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[132]+1),lf[133],lf[80]);}}

/* k2400 in k2388 in check in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2380(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2380,NULL,2,t1,t2);}
/* posixwin.scm: 1316 ##sys#error */
t3=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[129],t2);}

/* mode in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static C_word C_fcall f_2368(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[127]));}

/* canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2011,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[114]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2018,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2151,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1255 cwd */
t8=((C_word*)t0)[5];
f_1955(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t4,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2358,a[2]=((C_word*)t0)[11],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1257 sref */
t10=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_2157(t9,C_SCHEME_FALSE);}}}

/* k2356 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1257 sep? */
t2=((C_word*)t0)[3];
f_2157(t2,f_1944(t1));}

/* k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2157,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2164,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2168,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1259 cwd */
t4=((C_word*)t0)[7];
f_1955(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1262 cwd */
t5=((C_word*)t0)[7];
f_1955(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2344,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1263 sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k2342 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1263 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k2331 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1264 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_2187(t2,C_SCHEME_FALSE);}}

/* k2338 in k2331 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1264 sep? */
t2=((C_word*)t0)[3];
f_2187(t2,f_1944(t1));}

/* k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2187(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2187,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2210,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1266 cwd */
t4=((C_word*)t0)[6];
f_1955(t4,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1272 cwd */
t5=((C_word*)t0)[6];
f_1955(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2326,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1273 sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[8],C_fix(0));}}}

/* k2324 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1273 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2303 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2305,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2322,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1274 sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_2229(t2,C_SCHEME_FALSE);}}

/* k2320 in k2303 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1274 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k2309 in k2303 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2311,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1275 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_2229(t2,C_SCHEME_FALSE);}}

/* k2316 in k2309 in k2303 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1275 sep? */
t2=((C_word*)t0)[3];
f_2229(t2,f_1944(t1));}

/* k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2229(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2229,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_2018(2,t2,((C_word*)t0)[8]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2235,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2302,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1277 sref */
t5=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[8],C_fix(0));}}

/* k2300 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1277 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k2279 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2281,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2298,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1278 sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_2235(2,t2,C_SCHEME_FALSE);}}

/* k2296 in k2279 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1278 alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2285 in k2279 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2287,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2294,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1279 sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_2235(2,t2,C_SCHEME_FALSE);}}

/* k2292 in k2285 in k2279 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1279 char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k2233 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2235,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1281 ##sys#substring */
t3=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],C_fix(1),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1285 sref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],C_fix(0));}}

/* k2276 in k2233 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2278,2,t0,t1);}
t2=f_1944(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2267,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1287 cwd */
t5=((C_word*)t0)[2];
f_1955(t5,t4);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1290 cwd */
t4=((C_word*)t0)[2];
f_1955(t4,t3);}}

/* k2272 in k2276 in k2233 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1290 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[126],((C_word*)t0)[2]);}

/* k2265 in k2276 in k2233 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1287 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k2261 in k2276 in k2233 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1286 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2240 in k2233 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2246,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1283 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(3),t3);}

/* k2244 in k2240 in k2233 in k2227 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1280 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[125],t1);}

/* k2221 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1272 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[124],((C_word*)t0)[2]);}

/* k2208 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1266 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(3));}

/* k2192 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1268 user */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2196 in k2192 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2202,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixwin.scm: 1269 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k2200 in k2196 in k2192 in k2185 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1265 sappend */
t2=((C_word*)t0)[5];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[123],((C_word*)t0)[2],t1);}

/* k2179 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1262 sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[122],((C_word*)t0)[2]);}

/* k2166 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1259 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_fix(0),C_fix(2));}

/* k2162 in k2155 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1258 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2149 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1255 sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[121]);}

/* k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2137,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_block_size(t1);
/* posixwin.scm: 1291 ##sys#substring */
t5=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t1,C_fix(3),t4);}

/* k2135 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-split */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[120]);}

/* k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2025,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_2027(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2027(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2027,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1293 null? */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1294 null? */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2106,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* posixwin.scm: 1305 string=? */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[118],t5);}}

/* k2107 in k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2109,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_2106(t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* posixwin.scm: 1307 string=? */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[117],t3);}}

/* k2116 in k2107 in k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2118,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2106(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_2106(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k2104 in k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_2106(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1303 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2027(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2038 in k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2040,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1295 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[8],((C_word*)t0)[7],C_fix(0),C_fix(3));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2087,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[7]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixwin.scm: 1296 sref */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[7],t4);}}

/* k2085 in k2038 in k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2087,2,t0,t1);}
t2=f_1944(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2056,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1298 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2075,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1301 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],C_fix(0),C_fix(3));}}

/* k2073 in k2085 in k2038 in k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2079,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2083,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1302 reverse */
t4=*((C_word*)lf[116]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2081 in k2073 in k2085 in k2038 in k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1302 isperse */
f_1939(((C_word*)t0)[2],t1);}

/* k2077 in k2073 in k2085 in k2038 in k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1300 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2054 in k2085 in k2038 in k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2060,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2064,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[115],((C_word*)t0)[2]);
/* posixwin.scm: 1299 reverse */
t5=*((C_word*)lf[116]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k2062 in k2054 in k2085 in k2038 in k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1299 isperse */
f_1939(((C_word*)t0)[2],t1);}

/* k2058 in k2054 in k2085 in k2038 in k2032 in loop in k2023 in k2016 in canonical-path in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1297 sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* cwd in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_1955(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1955,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1962,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a1963 in cwd in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1964,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1970,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1988,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1987 in a1963 in cwd in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1994,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1999 in a1987 in a1963 in cwd in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2000r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2000r(t0,t1,t2);}}

static void C_ccall f_2000r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2006,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g187189 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a2005 in a1999 in a1987 in a1963 in cwd in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2006,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1993 in a1987 in a1963 in cwd in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
/* posixwin.scm: 1250 cw */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a1969 in a1963 in cwd in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1970,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1976,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g187189 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1975 in a1969 in a1963 in cwd in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[110]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[111]);}

/* k1960 in cwd in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* sep? in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static C_word C_fcall f_1944(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_1939(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1939,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[108]);}

/* current-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1895r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1895r(t0,t1,t2);}}

static void C_ccall f_1895r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
/* posixwin.scm: 1228 change-directory */
t5=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1229 make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}}

/* k1906 in current-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1911,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1231 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1909 in k1906 in current-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1233 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1234 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[98],lf[101]);}}

/* directory? in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1868,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[99]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1875,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1889,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1893,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1221 ##sys#expand-home-path */
t7=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k1891 in directory? in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1221 ##sys#platform-fixup-pathname */
t2=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1887 in directory? in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1220 ##sys#file-info */
t2=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1873 in directory? in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_1711r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1711r(t0,t1,t2);}}

static void C_ccall f_1711r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1713,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1814,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1819,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec123149 */
t6=t5;
f_1819(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?124147 */
t8=t4;
f_1814(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body121126 */
t10=t3;
f_1713(t10,t1,t6,t8);}}}

/* def-spec123 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_1819(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1819,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1827,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1191 current-directory */
t3=*((C_word*)lf[98]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1825 in def-spec123 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?124147 */
t2=((C_word*)t0)[3];
f_1814(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?124 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_1814(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1814,NULL,3,t0,t1,t2);}
/* body121126 */
t3=((C_word*)t0)[2];
f_1713(t3,t1,t2,C_SCHEME_FALSE);}

/* body121 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_1713(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1713,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[95]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1720,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1193 make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}

/* k1718 in body121 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1194 ##sys#make-pointer */
t3=*((C_word*)lf[97]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1721 in k1718 in body121 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1195 ##sys#make-pointer */
t3=*((C_word*)lf[97]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1724 in k1721 in k1718 in body121 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1813,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1196 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1811 in k1724 in k1721 in k1718 in body121 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1196 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1728 in k1724 in k1721 in k1718 in body121 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1730,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1739,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1199 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1747,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1747(t6,((C_word*)t0)[6]);}}

/* loop in k1728 in k1724 in k1721 in k1718 in body121 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_1747(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1747,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1757,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1208 ##sys#substring */
t5=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k1755 in loop in k1728 in k1724 in k1721 in k1718 in body121 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1757,2,t0,t1);}
t2=(C_word)C_subchar(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_subchar(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1769,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_1769(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_1769(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_1769(t7,C_SCHEME_FALSE);}}

/* k1767 in k1755 in loop in k1728 in k1724 in k1721 in k1718 in body121 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_1769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1769,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1215 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1747(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1216 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1747(t3,t2);}}

/* k1777 in k1767 in k1755 in loop in k1728 in k1724 in k1721 in k1718 in body121 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1737 in k1728 in k1724 in k1721 in k1718 in body121 in directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1200 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[95],lf[96],((C_word*)t0)[2]);}

/* delete-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1684,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[92]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1705,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1709,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1183 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1707 in delete-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1183 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1703 in delete-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1705,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1184 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1695 in k1703 in delete-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1185 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[92],lf[93],((C_word*)t0)[2]);}

/* change-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1657,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1678,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1682,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1176 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1680 in change-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1176 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1676 in change-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1678,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1177 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1668 in k1676 in change-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1178 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[90],lf[91],((C_word*)t0)[2]);}

/* create-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1630,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1651,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1655,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1169 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1653 in create-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1169 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1649 in create-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1651,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1170 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1641 in k1649 in create-directory in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1171 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[88],lf[89],((C_word*)t0)[2]);}

/* set-file-position! in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1569r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1569r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1569r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[83]);
t8=(C_word)C_i_check_exact_2(t6,lf[83]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1582,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 1154 ##sys#signal-hook */
t10=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[86],lf[83],lf[87],t3,t2);}
else{
t10=t9;
f_1582(2,t10,C_SCHEME_UNDEFINED);}}

/* k1580 in set-file-position! in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1155 port? */
t4=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1595 in k1580 in set-file-position! in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[80]);
t4=((C_word*)t0)[4];
f_1588(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_1588(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 1159 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[46],lf[83],lf[85],((C_word*)t0)[5]);}}}

/* k1586 in k1580 in set-file-position! in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1588,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1160 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1589 in k1586 in k1580 in set-file-position! in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1161 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[83],lf[84],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1529,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1533,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1548,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1138 port? */
t5=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1546 in file-position in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[80]);
t4=((C_word*)t0)[2];
f_1533(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_1533(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 1143 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[46],lf[78],lf[81],((C_word*)t0)[3]);}}}

/* k1531 in file-position in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1536,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1145 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1536(2,t3,C_SCHEME_UNDEFINED);}}

/* k1540 in k1531 in file-position in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1146 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[78],lf[79],((C_word*)t0)[2]);}

/* k1534 in k1531 in file-position in k1525 in k1521 in k1517 in k1513 in k1509 in k1505 in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* stat-type in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_1496(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1496,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1498,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1498 in stat-type in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1498,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* symbolic-link? in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1491,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[70]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1468,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[68]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1475,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1489,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1116 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1487 in regular-file? in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1116 ##sys#file-info */
t2=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1473 in regular-file? in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1462,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1466,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1112 ##sys#stat */
f_1370(t3,t2);}

/* k1464 in file-permissions in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1456,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1460,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1111 ##sys#stat */
f_1370(t3,t2);}

/* k1458 in file-owner in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1450,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1454,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1110 ##sys#stat */
f_1370(t3,t2);}

/* k1452 in file-change-time in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1454,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1444,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1448,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1109 ##sys#stat */
f_1370(t3,t2);}

/* k1446 in file-access-time in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1448,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1438,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1442,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1108 ##sys#stat */
f_1370(t3,t2);}

/* k1440 in file-modification-time in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1442,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1432,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1436,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1107 ##sys#stat */
f_1370(t3,t2);}

/* k1434 in file-size in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1408(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1408r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1408r(t0,t1,t2,t3);}}

static void C_ccall f_1408r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1415,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1101 ##sys#stat */
f_1370(t6,t2);}

/* k1413 in file-stat in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1415,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_fcall f_1370(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1370,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1374,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_1374(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1399,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1094 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1095 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[46],lf[60],t2);}}}

/* k1401 in ##sys#stat in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1094 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1397 in ##sys#stat in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1374(2,t2,(C_word)C_stat(t1));}

/* k1372 in ##sys#stat in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1374,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1097 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1381 in k1372 in ##sys#stat in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1098 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[59],((C_word*)t0)[2]);}

/* file-mkstemp in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1332,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[52]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1339,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1063 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1337 in file-mkstemp in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1339,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1342,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1065 string-length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k1340 in k1337 in file-mkstemp in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1362,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1067 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1345(2,t4,C_SCHEME_UNDEFINED);}}

/* k1360 in k1340 in k1337 in file-mkstemp in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1068 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[52],lf[54],((C_word*)t0)[2]);}

/* k1343 in k1340 in k1337 in file-mkstemp in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1352,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1069 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1350 in k1343 in k1340 in k1337 in file-mkstemp in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1069 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1290r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1290r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1290r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[48]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1297,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1297(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1050 ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[46],lf[48],lf[50],t3);}}

/* k1295 in file-write in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[48]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1306,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1312,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1055 ##sys#update-errno */
t9=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1306(2,t8,C_SCHEME_UNDEFINED);}}

/* k1310 in k1295 in file-write in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1056 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[48],lf[49],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1304 in k1295 in file-write in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1245r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1245r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1245r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[44]);
t6=(C_word)C_i_check_exact_2(t3,lf[44]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1255,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1255(2,t8,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixwin.scm: 1037 make-string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k1253 in file-read in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1258(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1039 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[46],lf[44],lf[47],t1);}}

/* k1256 in k1253 in file-read in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1258,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1261,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1042 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1261(2,t5,C_SCHEME_UNDEFINED);}}

/* k1268 in k1256 in k1253 in file-read in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1043 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[44],lf[45],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1259 in k1256 in k1253 in file-read in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1261,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1227,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[41]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1240,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1029 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1238 in file-close in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1030 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[41],lf[42],((C_word*)t0)[2]);}

/* file-open in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1186r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1186r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[36]);
t8=(C_word)C_i_check_exact_2(t3,lf[36]);
t9=(C_word)C_i_check_exact_2(t6,lf[36]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1203,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1219,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1019 ##sys#expand-home-path */
t12=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k1217 in file-open in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1019 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1201 in file-open in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1206,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1021 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1206(2,t5,C_SCHEME_UNDEFINED);}}

/* k1210 in k1201 in file-open in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1022 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[37],lf[36],lf[38],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1204 in k1201 in file-open in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1140r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1140r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1140r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1144,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 950  ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1142 in posix-error in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1155,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub3(t4,t1),C_fix(0));}

/* k1153 in k1142 in posix-error in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 951  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[7],t1);}

/* k1149 in k1142 in posix-error in k1131 in k1128 in k1125 in k1122 in k1119 */
static void C_ccall f_1151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[6]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[443] = {
{"toplevelposixwin.scm",(void*)C_posix_toplevel},
{"f_1121posixwin.scm",(void*)f_1121},
{"f_1124posixwin.scm",(void*)f_1124},
{"f_1127posixwin.scm",(void*)f_1127},
{"f_1130posixwin.scm",(void*)f_1130},
{"f_1133posixwin.scm",(void*)f_1133},
{"f_1507posixwin.scm",(void*)f_1507},
{"f_1511posixwin.scm",(void*)f_1511},
{"f_1515posixwin.scm",(void*)f_1515},
{"f_1519posixwin.scm",(void*)f_1519},
{"f_1523posixwin.scm",(void*)f_1523},
{"f_1527posixwin.scm",(void*)f_1527},
{"f_2650posixwin.scm",(void*)f_2650},
{"f_4808posixwin.scm",(void*)f_4808},
{"f_4805posixwin.scm",(void*)f_4805},
{"f_4798posixwin.scm",(void*)f_4798},
{"f_4792posixwin.scm",(void*)f_4792},
{"f_4786posixwin.scm",(void*)f_4786},
{"f_4780posixwin.scm",(void*)f_4780},
{"f_4774posixwin.scm",(void*)f_4774},
{"f_4768posixwin.scm",(void*)f_4768},
{"f_4762posixwin.scm",(void*)f_4762},
{"f_4756posixwin.scm",(void*)f_4756},
{"f_4750posixwin.scm",(void*)f_4750},
{"f_4744posixwin.scm",(void*)f_4744},
{"f_4738posixwin.scm",(void*)f_4738},
{"f_4732posixwin.scm",(void*)f_4732},
{"f_4726posixwin.scm",(void*)f_4726},
{"f_4720posixwin.scm",(void*)f_4720},
{"f_4714posixwin.scm",(void*)f_4714},
{"f_4708posixwin.scm",(void*)f_4708},
{"f_4702posixwin.scm",(void*)f_4702},
{"f_4696posixwin.scm",(void*)f_4696},
{"f_4690posixwin.scm",(void*)f_4690},
{"f_4684posixwin.scm",(void*)f_4684},
{"f_4678posixwin.scm",(void*)f_4678},
{"f_4672posixwin.scm",(void*)f_4672},
{"f_4666posixwin.scm",(void*)f_4666},
{"f_4660posixwin.scm",(void*)f_4660},
{"f_4654posixwin.scm",(void*)f_4654},
{"f_4648posixwin.scm",(void*)f_4648},
{"f_4642posixwin.scm",(void*)f_4642},
{"f_4636posixwin.scm",(void*)f_4636},
{"f_4630posixwin.scm",(void*)f_4630},
{"f_4624posixwin.scm",(void*)f_4624},
{"f_4618posixwin.scm",(void*)f_4618},
{"f_4612posixwin.scm",(void*)f_4612},
{"f_4606posixwin.scm",(void*)f_4606},
{"f_4600posixwin.scm",(void*)f_4600},
{"f_4594posixwin.scm",(void*)f_4594},
{"f_4588posixwin.scm",(void*)f_4588},
{"f_4582posixwin.scm",(void*)f_4582},
{"f_4576posixwin.scm",(void*)f_4576},
{"f_4570posixwin.scm",(void*)f_4570},
{"f_4564posixwin.scm",(void*)f_4564},
{"f_4558posixwin.scm",(void*)f_4558},
{"f_4552posixwin.scm",(void*)f_4552},
{"f_4546posixwin.scm",(void*)f_4546},
{"f_4540posixwin.scm",(void*)f_4540},
{"f_4317posixwin.scm",(void*)f_4317},
{"f_4474posixwin.scm",(void*)f_4474},
{"f_4480posixwin.scm",(void*)f_4480},
{"f_4469posixwin.scm",(void*)f_4469},
{"f_4464posixwin.scm",(void*)f_4464},
{"f_4319posixwin.scm",(void*)f_4319},
{"f_4451posixwin.scm",(void*)f_4451},
{"f_4459posixwin.scm",(void*)f_4459},
{"f_4326posixwin.scm",(void*)f_4326},
{"f_4439posixwin.scm",(void*)f_4439},
{"f_4336posixwin.scm",(void*)f_4336},
{"f_4338posixwin.scm",(void*)f_4338},
{"f_4357posixwin.scm",(void*)f_4357},
{"f_4425posixwin.scm",(void*)f_4425},
{"f_4432posixwin.scm",(void*)f_4432},
{"f_4419posixwin.scm",(void*)f_4419},
{"f_4372posixwin.scm",(void*)f_4372},
{"f_4406posixwin.scm",(void*)f_4406},
{"f_4392posixwin.scm",(void*)f_4392},
{"f_4404posixwin.scm",(void*)f_4404},
{"f_4400posixwin.scm",(void*)f_4400},
{"f_4384posixwin.scm",(void*)f_4384},
{"f_4382posixwin.scm",(void*)f_4382},
{"f_4443posixwin.scm",(void*)f_4443},
{"f_4302posixwin.scm",(void*)f_4302},
{"f_4312posixwin.scm",(void*)f_4312},
{"f_4271posixwin.scm",(void*)f_4271},
{"f_4297posixwin.scm",(void*)f_4297},
{"f_4282posixwin.scm",(void*)f_4282},
{"f_4286posixwin.scm",(void*)f_4286},
{"f_4290posixwin.scm",(void*)f_4290},
{"f_4294posixwin.scm",(void*)f_4294},
{"f_4259posixwin.scm",(void*)f_4259},
{"f_4256posixwin.scm",(void*)f_4256},
{"f_4199posixwin.scm",(void*)f_4199},
{"f_4223posixwin.scm",(void*)f_4223},
{"f_4233posixwin.scm",(void*)f_4233},
{"f_4217posixwin.scm",(void*)f_4217},
{"f_4187posixwin.scm",(void*)f_4187},
{"f_4110posixwin.scm",(void*)f_4110},
{"f_4127posixwin.scm",(void*)f_4127},
{"f_4122posixwin.scm",(void*)f_4122},
{"f_4117posixwin.scm",(void*)f_4117},
{"f_4112posixwin.scm",(void*)f_4112},
{"f_4033posixwin.scm",(void*)f_4033},
{"f_4050posixwin.scm",(void*)f_4050},
{"f_4045posixwin.scm",(void*)f_4045},
{"f_4040posixwin.scm",(void*)f_4040},
{"f_4035posixwin.scm",(void*)f_4035},
{"f_3971posixwin.scm",(void*)f_3971},
{"f_4027posixwin.scm",(void*)f_4027},
{"f_4031posixwin.scm",(void*)f_4031},
{"f_3992posixwin.scm",(void*)f_3992},
{"f_3995posixwin.scm",(void*)f_3995},
{"f_4006posixwin.scm",(void*)f_4006},
{"f_4000posixwin.scm",(void*)f_4000},
{"f_3973posixwin.scm",(void*)f_3973},
{"f_3982posixwin.scm",(void*)f_3982},
{"f_3875posixwin.scm",(void*)f_3875},
{"f_3954posixwin.scm",(void*)f_3954},
{"f_3882posixwin.scm",(void*)f_3882},
{"f_3922posixwin.scm",(void*)f_3922},
{"f_3926posixwin.scm",(void*)f_3926},
{"f_3930posixwin.scm",(void*)f_3930},
{"f_3934posixwin.scm",(void*)f_3934},
{"f_3938posixwin.scm",(void*)f_3938},
{"f_3829posixwin.scm",(void*)f_3829},
{"f_3833posixwin.scm",(void*)f_3833},
{"f_3915posixwin.scm",(void*)f_3915},
{"f_3895posixwin.scm",(void*)f_3895},
{"f_3899posixwin.scm",(void*)f_3899},
{"f_3903posixwin.scm",(void*)f_3903},
{"f_3821posixwin.scm",(void*)f_3821},
{"f_3792posixwin.scm",(void*)f_3792},
{"f_3809posixwin.scm",(void*)f_3809},
{"f_3813posixwin.scm",(void*)f_3813},
{"f_3786posixwin.scm",(void*)f_3786},
{"f_3765posixwin.scm",(void*)f_3765},
{"f_3769posixwin.scm",(void*)f_3769},
{"f_3781posixwin.scm",(void*)f_3781},
{"f_3762posixwin.scm",(void*)f_3762},
{"f_3678posixwin.scm",(void*)f_3678},
{"f_3702posixwin.scm",(void*)f_3702},
{"f_3697posixwin.scm",(void*)f_3697},
{"f_3692posixwin.scm",(void*)f_3692},
{"f_3680posixwin.scm",(void*)f_3680},
{"f_3684posixwin.scm",(void*)f_3684},
{"f_3594posixwin.scm",(void*)f_3594},
{"f_3618posixwin.scm",(void*)f_3618},
{"f_3613posixwin.scm",(void*)f_3613},
{"f_3608posixwin.scm",(void*)f_3608},
{"f_3596posixwin.scm",(void*)f_3596},
{"f_3600posixwin.scm",(void*)f_3600},
{"f_3579posixwin.scm",(void*)f_3579},
{"f_3583posixwin.scm",(void*)f_3583},
{"f_3546posixwin.scm",(void*)f_3546},
{"f_3553posixwin.scm",(void*)f_3553},
{"f_3556posixwin.scm",(void*)f_3556},
{"f_3573posixwin.scm",(void*)f_3573},
{"f_3559posixwin.scm",(void*)f_3559},
{"f_3562posixwin.scm",(void*)f_3562},
{"f_3569posixwin.scm",(void*)f_3569},
{"f_3496posixwin.scm",(void*)f_3496},
{"f_3508posixwin.scm",(void*)f_3508},
{"f_3527posixwin.scm",(void*)f_3527},
{"f_3490posixwin.scm",(void*)f_3490},
{"f_3484posixwin.scm",(void*)f_3484},
{"f_3405posixwin.scm",(void*)f_3405},
{"f_3448posixwin.scm",(void*)f_3448},
{"f_3479posixwin.scm",(void*)f_3479},
{"f_3476posixwin.scm",(void*)f_3476},
{"f_3410posixwin.scm",(void*)f_3410},
{"f_3414posixwin.scm",(void*)f_3414},
{"f_3419posixwin.scm",(void*)f_3419},
{"f_3443posixwin.scm",(void*)f_3443},
{"f_3432posixwin.scm",(void*)f_3432},
{"f_3290posixwin.scm",(void*)f_3290},
{"f_3296posixwin.scm",(void*)f_3296},
{"f_3317posixwin.scm",(void*)f_3317},
{"f_3394posixwin.scm",(void*)f_3394},
{"f_3321posixwin.scm",(void*)f_3321},
{"f_3324posixwin.scm",(void*)f_3324},
{"f_3327posixwin.scm",(void*)f_3327},
{"f_3334posixwin.scm",(void*)f_3334},
{"f_3336posixwin.scm",(void*)f_3336},
{"f_3353posixwin.scm",(void*)f_3353},
{"f_3363posixwin.scm",(void*)f_3363},
{"f_3367posixwin.scm",(void*)f_3367},
{"f_3311posixwin.scm",(void*)f_3311},
{"f_3231posixwin.scm",(void*)f_3231},
{"f_3235posixwin.scm",(void*)f_3235},
{"f_3241posixwin.scm",(void*)f_3241},
{"f_3215posixwin.scm",(void*)f_3215},
{"f_3207posixwin.scm",(void*)f_3207},
{"f_3179posixwin.scm",(void*)f_3179},
{"f_3186posixwin.scm",(void*)f_3186},
{"f_3106posixwin.scm",(void*)f_3106},
{"f_3116posixwin.scm",(void*)f_3116},
{"f_3138posixwin.scm",(void*)f_3138},
{"f_3135posixwin.scm",(void*)f_3135},
{"f_3125posixwin.scm",(void*)f_3125},
{"f_3073posixwin.scm",(void*)f_3073},
{"f_3077posixwin.scm",(void*)f_3077},
{"f_3059posixwin.scm",(void*)f_3059},
{"f_3050posixwin.scm",(void*)f_3050},
{"f_2985posixwin.scm",(void*)f_2985},
{"f_2991posixwin.scm",(void*)f_2991},
{"f_2995posixwin.scm",(void*)f_2995},
{"f_3003posixwin.scm",(void*)f_3003},
{"f_3029posixwin.scm",(void*)f_3029},
{"f_3033posixwin.scm",(void*)f_3033},
{"f_3021posixwin.scm",(void*)f_3021},
{"f_2970posixwin.scm",(void*)f_2970},
{"f_2978posixwin.scm",(void*)f_2978},
{"f_2953posixwin.scm",(void*)f_2953},
{"f_2964posixwin.scm",(void*)f_2964},
{"f_2968posixwin.scm",(void*)f_2968},
{"f_2923posixwin.scm",(void*)f_2923},
{"f_2930posixwin.scm",(void*)f_2930},
{"f_2939posixwin.scm",(void*)f_2939},
{"f_2933posixwin.scm",(void*)f_2933},
{"f_2888posixwin.scm",(void*)f_2888},
{"f_2892posixwin.scm",(void*)f_2892},
{"f_2921posixwin.scm",(void*)f_2921},
{"f_2907posixwin.scm",(void*)f_2907},
{"f_2901posixwin.scm",(void*)f_2901},
{"f_2874posixwin.scm",(void*)f_2874},
{"f_2886posixwin.scm",(void*)f_2886},
{"f_2860posixwin.scm",(void*)f_2860},
{"f_2872posixwin.scm",(void*)f_2872},
{"f_2842posixwin.scm",(void*)f_2842},
{"f_2846posixwin.scm",(void*)f_2846},
{"f_2858posixwin.scm",(void*)f_2858},
{"f_2805posixwin.scm",(void*)f_2805},
{"f_2813posixwin.scm",(void*)f_2813},
{"f_2796posixwin.scm",(void*)f_2796},
{"f_2790posixwin.scm",(void*)f_2790},
{"f_2784posixwin.scm",(void*)f_2784},
{"f_2760posixwin.scm",(void*)f_2760},
{"f_2782posixwin.scm",(void*)f_2782},
{"f_2778posixwin.scm",(void*)f_2778},
{"f_2770posixwin.scm",(void*)f_2770},
{"f_2730posixwin.scm",(void*)f_2730},
{"f_2758posixwin.scm",(void*)f_2758},
{"f_2754posixwin.scm",(void*)f_2754},
{"f_2746posixwin.scm",(void*)f_2746},
{"f_2674posixwin.scm",(void*)f_2674},
{"f_2684posixwin.scm",(void*)f_2684},
{"f_2661posixwin.scm",(void*)f_2661},
{"f_2652posixwin.scm",(void*)f_2652},
{"f_2583posixwin.scm",(void*)f_2583},
{"f_2599posixwin.scm",(void*)f_2599},
{"f_2590posixwin.scm",(void*)f_2590},
{"f_2563posixwin.scm",(void*)f_2563},
{"f_2567posixwin.scm",(void*)f_2567},
{"f_2573posixwin.scm",(void*)f_2573},
{"f_2577posixwin.scm",(void*)f_2577},
{"f_2543posixwin.scm",(void*)f_2543},
{"f_2547posixwin.scm",(void*)f_2547},
{"f_2553posixwin.scm",(void*)f_2553},
{"f_2557posixwin.scm",(void*)f_2557},
{"f_2519posixwin.scm",(void*)f_2519},
{"f_2523posixwin.scm",(void*)f_2523},
{"f_2534posixwin.scm",(void*)f_2534},
{"f_2538posixwin.scm",(void*)f_2538},
{"f_2528posixwin.scm",(void*)f_2528},
{"f_2495posixwin.scm",(void*)f_2495},
{"f_2499posixwin.scm",(void*)f_2499},
{"f_2510posixwin.scm",(void*)f_2510},
{"f_2514posixwin.scm",(void*)f_2514},
{"f_2504posixwin.scm",(void*)f_2504},
{"f_2476posixwin.scm",(void*)f_2476},
{"f_2480posixwin.scm",(void*)f_2480},
{"f_2483posixwin.scm",(void*)f_2483},
{"f_2440posixwin.scm",(void*)f_2440},
{"f_2471posixwin.scm",(void*)f_2471},
{"f_2461posixwin.scm",(void*)f_2461},
{"f_2454posixwin.scm",(void*)f_2454},
{"f_2404posixwin.scm",(void*)f_2404},
{"f_2435posixwin.scm",(void*)f_2435},
{"f_2425posixwin.scm",(void*)f_2425},
{"f_2418posixwin.scm",(void*)f_2418},
{"f_2386posixwin.scm",(void*)f_2386},
{"f_2390posixwin.scm",(void*)f_2390},
{"f_2402posixwin.scm",(void*)f_2402},
{"f_2380posixwin.scm",(void*)f_2380},
{"f_2368posixwin.scm",(void*)f_2368},
{"f_2011posixwin.scm",(void*)f_2011},
{"f_2358posixwin.scm",(void*)f_2358},
{"f_2157posixwin.scm",(void*)f_2157},
{"f_2344posixwin.scm",(void*)f_2344},
{"f_2333posixwin.scm",(void*)f_2333},
{"f_2340posixwin.scm",(void*)f_2340},
{"f_2187posixwin.scm",(void*)f_2187},
{"f_2326posixwin.scm",(void*)f_2326},
{"f_2305posixwin.scm",(void*)f_2305},
{"f_2322posixwin.scm",(void*)f_2322},
{"f_2311posixwin.scm",(void*)f_2311},
{"f_2318posixwin.scm",(void*)f_2318},
{"f_2229posixwin.scm",(void*)f_2229},
{"f_2302posixwin.scm",(void*)f_2302},
{"f_2281posixwin.scm",(void*)f_2281},
{"f_2298posixwin.scm",(void*)f_2298},
{"f_2287posixwin.scm",(void*)f_2287},
{"f_2294posixwin.scm",(void*)f_2294},
{"f_2235posixwin.scm",(void*)f_2235},
{"f_2278posixwin.scm",(void*)f_2278},
{"f_2274posixwin.scm",(void*)f_2274},
{"f_2267posixwin.scm",(void*)f_2267},
{"f_2263posixwin.scm",(void*)f_2263},
{"f_2242posixwin.scm",(void*)f_2242},
{"f_2246posixwin.scm",(void*)f_2246},
{"f_2223posixwin.scm",(void*)f_2223},
{"f_2210posixwin.scm",(void*)f_2210},
{"f_2194posixwin.scm",(void*)f_2194},
{"f_2198posixwin.scm",(void*)f_2198},
{"f_2202posixwin.scm",(void*)f_2202},
{"f_2181posixwin.scm",(void*)f_2181},
{"f_2168posixwin.scm",(void*)f_2168},
{"f_2164posixwin.scm",(void*)f_2164},
{"f_2151posixwin.scm",(void*)f_2151},
{"f_2018posixwin.scm",(void*)f_2018},
{"f_2137posixwin.scm",(void*)f_2137},
{"f_2025posixwin.scm",(void*)f_2025},
{"f_2027posixwin.scm",(void*)f_2027},
{"f_2034posixwin.scm",(void*)f_2034},
{"f_2109posixwin.scm",(void*)f_2109},
{"f_2118posixwin.scm",(void*)f_2118},
{"f_2106posixwin.scm",(void*)f_2106},
{"f_2040posixwin.scm",(void*)f_2040},
{"f_2087posixwin.scm",(void*)f_2087},
{"f_2075posixwin.scm",(void*)f_2075},
{"f_2083posixwin.scm",(void*)f_2083},
{"f_2079posixwin.scm",(void*)f_2079},
{"f_2056posixwin.scm",(void*)f_2056},
{"f_2064posixwin.scm",(void*)f_2064},
{"f_2060posixwin.scm",(void*)f_2060},
{"f_1955posixwin.scm",(void*)f_1955},
{"f_1964posixwin.scm",(void*)f_1964},
{"f_1988posixwin.scm",(void*)f_1988},
{"f_2000posixwin.scm",(void*)f_2000},
{"f_2006posixwin.scm",(void*)f_2006},
{"f_1994posixwin.scm",(void*)f_1994},
{"f_1970posixwin.scm",(void*)f_1970},
{"f_1976posixwin.scm",(void*)f_1976},
{"f_1962posixwin.scm",(void*)f_1962},
{"f_1944posixwin.scm",(void*)f_1944},
{"f_1939posixwin.scm",(void*)f_1939},
{"f_1895posixwin.scm",(void*)f_1895},
{"f_1908posixwin.scm",(void*)f_1908},
{"f_1911posixwin.scm",(void*)f_1911},
{"f_1868posixwin.scm",(void*)f_1868},
{"f_1893posixwin.scm",(void*)f_1893},
{"f_1889posixwin.scm",(void*)f_1889},
{"f_1875posixwin.scm",(void*)f_1875},
{"f_1711posixwin.scm",(void*)f_1711},
{"f_1819posixwin.scm",(void*)f_1819},
{"f_1827posixwin.scm",(void*)f_1827},
{"f_1814posixwin.scm",(void*)f_1814},
{"f_1713posixwin.scm",(void*)f_1713},
{"f_1720posixwin.scm",(void*)f_1720},
{"f_1723posixwin.scm",(void*)f_1723},
{"f_1726posixwin.scm",(void*)f_1726},
{"f_1813posixwin.scm",(void*)f_1813},
{"f_1730posixwin.scm",(void*)f_1730},
{"f_1747posixwin.scm",(void*)f_1747},
{"f_1757posixwin.scm",(void*)f_1757},
{"f_1769posixwin.scm",(void*)f_1769},
{"f_1779posixwin.scm",(void*)f_1779},
{"f_1739posixwin.scm",(void*)f_1739},
{"f_1684posixwin.scm",(void*)f_1684},
{"f_1709posixwin.scm",(void*)f_1709},
{"f_1705posixwin.scm",(void*)f_1705},
{"f_1697posixwin.scm",(void*)f_1697},
{"f_1657posixwin.scm",(void*)f_1657},
{"f_1682posixwin.scm",(void*)f_1682},
{"f_1678posixwin.scm",(void*)f_1678},
{"f_1670posixwin.scm",(void*)f_1670},
{"f_1630posixwin.scm",(void*)f_1630},
{"f_1655posixwin.scm",(void*)f_1655},
{"f_1651posixwin.scm",(void*)f_1651},
{"f_1643posixwin.scm",(void*)f_1643},
{"f_1569posixwin.scm",(void*)f_1569},
{"f_1582posixwin.scm",(void*)f_1582},
{"f_1597posixwin.scm",(void*)f_1597},
{"f_1588posixwin.scm",(void*)f_1588},
{"f_1591posixwin.scm",(void*)f_1591},
{"f_1529posixwin.scm",(void*)f_1529},
{"f_1548posixwin.scm",(void*)f_1548},
{"f_1533posixwin.scm",(void*)f_1533},
{"f_1542posixwin.scm",(void*)f_1542},
{"f_1536posixwin.scm",(void*)f_1536},
{"f_1496posixwin.scm",(void*)f_1496},
{"f_1498posixwin.scm",(void*)f_1498},
{"f_1491posixwin.scm",(void*)f_1491},
{"f_1468posixwin.scm",(void*)f_1468},
{"f_1489posixwin.scm",(void*)f_1489},
{"f_1475posixwin.scm",(void*)f_1475},
{"f_1462posixwin.scm",(void*)f_1462},
{"f_1466posixwin.scm",(void*)f_1466},
{"f_1456posixwin.scm",(void*)f_1456},
{"f_1460posixwin.scm",(void*)f_1460},
{"f_1450posixwin.scm",(void*)f_1450},
{"f_1454posixwin.scm",(void*)f_1454},
{"f_1444posixwin.scm",(void*)f_1444},
{"f_1448posixwin.scm",(void*)f_1448},
{"f_1438posixwin.scm",(void*)f_1438},
{"f_1442posixwin.scm",(void*)f_1442},
{"f_1432posixwin.scm",(void*)f_1432},
{"f_1436posixwin.scm",(void*)f_1436},
{"f_1408posixwin.scm",(void*)f_1408},
{"f_1415posixwin.scm",(void*)f_1415},
{"f_1370posixwin.scm",(void*)f_1370},
{"f_1403posixwin.scm",(void*)f_1403},
{"f_1399posixwin.scm",(void*)f_1399},
{"f_1374posixwin.scm",(void*)f_1374},
{"f_1383posixwin.scm",(void*)f_1383},
{"f_1332posixwin.scm",(void*)f_1332},
{"f_1339posixwin.scm",(void*)f_1339},
{"f_1342posixwin.scm",(void*)f_1342},
{"f_1362posixwin.scm",(void*)f_1362},
{"f_1345posixwin.scm",(void*)f_1345},
{"f_1352posixwin.scm",(void*)f_1352},
{"f_1290posixwin.scm",(void*)f_1290},
{"f_1297posixwin.scm",(void*)f_1297},
{"f_1312posixwin.scm",(void*)f_1312},
{"f_1306posixwin.scm",(void*)f_1306},
{"f_1245posixwin.scm",(void*)f_1245},
{"f_1255posixwin.scm",(void*)f_1255},
{"f_1258posixwin.scm",(void*)f_1258},
{"f_1270posixwin.scm",(void*)f_1270},
{"f_1261posixwin.scm",(void*)f_1261},
{"f_1227posixwin.scm",(void*)f_1227},
{"f_1240posixwin.scm",(void*)f_1240},
{"f_1186posixwin.scm",(void*)f_1186},
{"f_1219posixwin.scm",(void*)f_1219},
{"f_1203posixwin.scm",(void*)f_1203},
{"f_1212posixwin.scm",(void*)f_1212},
{"f_1206posixwin.scm",(void*)f_1206},
{"f_1140posixwin.scm",(void*)f_1140},
{"f_1144posixwin.scm",(void*)f_1144},
{"f_1155posixwin.scm",(void*)f_1155},
{"f_1151posixwin.scm",(void*)f_1151},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
